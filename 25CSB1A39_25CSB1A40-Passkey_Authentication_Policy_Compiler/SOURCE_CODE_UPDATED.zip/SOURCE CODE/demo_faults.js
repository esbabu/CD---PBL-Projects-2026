/**
 * demo_faults.js (Root entrypoint)
 * Dispatches to CODE/demo_faults.js
 */
const { runFaultDemos } = require('./CODE/demo_faults.js');

if (require.main === module) {
  runFaultDemos()
    .then(r => process.exit(r.success ? 0 : 1))
    .catch(err => {
      console.error('Fatal Fault Demo Error:', err);
      process.exit(1);
    });
}

module.exports = { runFaultDemos };
