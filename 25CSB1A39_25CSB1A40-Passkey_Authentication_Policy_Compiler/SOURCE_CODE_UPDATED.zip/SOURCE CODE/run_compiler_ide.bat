@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0CODE"

title Password Policy Compiler and AI Assistant
echo =======================================================
echo  Starting Password Policy Compiler and AI Assistant IDE
echo =======================================================

:: Locate Node.js executable if not already in PATH
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" (
        set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"
    ) else if exist "%ProgramFiles%\nodejs\node.exe" (
        set "PATH=%ProgramFiles%\nodejs;%PATH%"
    ) else if exist "%ProgramFiles(x86)%\nodejs\node.exe" (
        set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
    ) else if exist "%USERPROFILE%\AppData\Local\Programs\nodejs\node.exe" (
        set "PATH=%USERPROFILE%\AppData\Local\Programs\nodejs;%PATH%"
    )
)

:: Re-verify that node is available
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Node.js is not found in PATH or standard installation locations!
    echo Please install Node.js from https://nodejs.org or add node.exe to your PATH.
    echo.
    pause
    exit /b 1
)

:: Wait 3 seconds in background to allow Node.js to bind port 3000 before opening browser
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:3000"

:: Start the Node.js Express server
node server.js

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Server terminated with an error (Code: %ERRORLEVEL%).
)
pause
