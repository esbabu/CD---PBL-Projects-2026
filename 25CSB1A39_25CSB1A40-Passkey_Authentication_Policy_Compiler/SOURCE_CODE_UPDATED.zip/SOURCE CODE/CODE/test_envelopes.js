/**
 * test_envelopes.js
 * 
 * Comprehensive Verification Suite for Phase 3:
 * Signed Envelopes, Ed25519 Cryptographic Verification & Permission Boundaries.
 */

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const { JobBroker, sha256 } = require('./broker');
const { createPipelineAgents, AgentWorker } = require('./agent_workers');
const { createEnvelope, PERMITTED_ACTIONS } = require('./crypto_utils');

async function runEnvelopeTests() {
  console.log('--------------------------------------------------------------------------------');
  console.log('🛡️  PHASE 3: ZERO-TRUST SIGNED ENVELOPES & PERMISSION BOUNDARIES');
  console.log('--------------------------------------------------------------------------------');

  const testDb = path.join(__dirname, 'test_envelopes.db');
  if (fs.existsSync(testDb)) fs.unlinkSync(testDb);

  const broker = new JobBroker(testDb);
  console.log('  ✓ Initialized Broker with Ed25519 signing keypair');

  // 1. Create pipeline agents with their own Ed25519 keypairs
  const agents = createPipelineAgents(broker.publicKey);

  // Register only public keys with the broker
  for (const [st, agent] of Object.entries(agents)) {
    broker.registerAgent(agent.agentId, st, agent.getPublicKey());
  }

  // Verify broker stores ONLY public keys, never private keys
  const registeredKeys = broker.db.prepare('SELECT agent_id, stage, permitted_action, public_key_pem FROM agent_keys').all();
  assert.strictEqual(registeredKeys.length, 7);
  for (const row of registeredKeys) {
    assert.strictEqual(row.public_key_pem.includes('PUBLIC KEY'), true);
    assert.strictEqual(row.public_key_pem.includes('PRIVATE KEY'), false);
  }
  console.log('  ✓ Verified 7 agent public keys registered in broker (Zero private keys stored in broker)');

  // 2. Create Job
  const dsl = 'minLength 14\nrequireUpper true\nrequireDigit true\n';
  const job = broker.createJob(dsl);
  console.log(`  ✓ Created Job '${job.jobId}' with root hash ${job.initialHash.slice(0, 16)}...`);

  // -------------------------------------------------------------------------
  // REJECTION TEST A: BAD ED25519 SIGNATURE
  // -------------------------------------------------------------------------
  const task1 = broker.dispatchTaskEnvelope(job.jobId, 'lexer');
  const validResp = agents.lexer.processTaskEnvelope(task1);

  // Tamper with signature
  const badSigEnvelope = {
    ...validResp,
    signature: 'bad' + validResp.signature.slice(3)
  };

  let caughtBadSig = false;
  try {
    broker.processResponseEnvelope(badSigEnvelope);
  } catch (err) {
    caughtBadSig = true;
    console.log(`  ✓ [Defense A] Bad signature correctly rejected: ${err.message}`);
  }
  assert.strictEqual(caughtBadSig, true, 'Broker must reject bad Ed25519 signature');

  // -------------------------------------------------------------------------
  // REJECTION TEST B: WRONG INPUT HASH
  // -------------------------------------------------------------------------
  const badHashEnvelope = {
    ...validResp,
    inputHash: '0000000000000000000000000000000000000000000000000000000000000000'
  };

  let caughtBadHash = false;
  try {
    broker.processResponseEnvelope(badHashEnvelope);
  } catch (err) {
    caughtBadHash = true;
    console.log(`  ✓ [Defense B] Wrong input hash correctly rejected: ${err.message}`);
  }
  assert.strictEqual(caughtBadHash, true, 'Broker must reject mismatched input hash');

  // -------------------------------------------------------------------------
  // REJECTION TEST C: EXPIRED DEADLINE
  // -------------------------------------------------------------------------
  const expiredEnvelope = createEnvelope({
    jobId: job.jobId,
    stage: 'lexer',
    inputHash: task1.inputHash,
    deadline: Date.now() - 5000, // 5 seconds in the past!
    nonce: 'expired_nonce_' + Date.now(),
    permittedAction: 'EMIT_TOKENS',
    payload: validResp.payload,
    privateKey: agents.lexer._privateKey,
    senderId: agents.lexer.agentId
  });

  let caughtExpired = false;
  try {
    broker.processResponseEnvelope(expiredEnvelope);
  } catch (err) {
    caughtExpired = true;
    console.log(`  ✓ [Defense C] Expired deadline correctly rejected: ${err.message}`);
  }
  assert.strictEqual(caughtExpired, true, 'Broker must reject expired envelope');

  // -------------------------------------------------------------------------
  // VALID STAGE 1: LEXER PROCESSES AND SUBMITS VALID ENVELOPE
  // -------------------------------------------------------------------------
  const lexAccepted = broker.processResponseEnvelope(validResp);
  assert.strictEqual(lexAccepted.ok, true);
  console.log('  ✓ Valid signed envelope processed for [lexer] -> advanced to parser');

  // -------------------------------------------------------------------------
  // REJECTION TEST D: REPLAY ATTACK (REUSED NONCE)
  // -------------------------------------------------------------------------
  let caughtReplay = false;
  try {
    broker.processResponseEnvelope(validResp); // Replaying the exact same envelope!
  } catch (err) {
    caughtReplay = true;
    console.log(`  ✓ [Defense D] Replay attack correctly rejected: ${err.message}`);
  }
  assert.strictEqual(caughtReplay, true, 'Broker must reject reused nonce');

  // -------------------------------------------------------------------------
  // REJECTION TEST E: PERMISSION BOUNDARY VIOLATION
  // -------------------------------------------------------------------------
  // Try to make Lexer agent sign an EMIT_VALIDATOR action
  const unauthorizedActionEnvelope = createEnvelope({
    jobId: job.jobId,
    stage: 'parser',
    inputHash: broker.getStageResult(job.jobId, 'lexer').output_hash,
    deadline: Date.now() + 30000,
    nonce: 'unauth_' + Date.now(),
    permittedAction: 'EMIT_VALIDATOR', // Lexer is NOT authorized for codegen!
    payload: { code: 'int main() {}' },
    privateKey: agents.lexer._privateKey,
    senderId: agents.lexer.agentId
  });

  let caughtUnauthorized = false;
  try {
    broker.processResponseEnvelope(unauthorizedActionEnvelope);
  } catch (err) {
    caughtUnauthorized = true;
    console.log(`  ✓ [Defense E] Permission boundary enforced: ${err.message}`);
  }
  assert.strictEqual(caughtUnauthorized, true, 'Broker must reject unauthorized action');

  // -------------------------------------------------------------------------
  // REJECTION TEST F: INVALID STAGE TRANSITION (SKIPPED STAGE)
  // -------------------------------------------------------------------------
  // Try to submit Codegen response when parser has not run
  const outOfOrderEnvelope = createEnvelope({
    jobId: job.jobId,
    stage: 'codegen',
    inputHash: 'some_hash',
    deadline: Date.now() + 30000,
    nonce: 'ooo_' + Date.now(),
    permittedAction: 'EMIT_VALIDATOR',
    payload: { code: 'class Validator {}' },
    privateKey: agents.codegen._privateKey,
    senderId: agents.codegen.agentId
  });

  let caughtOutOfOrder = false;
  try {
    broker.processResponseEnvelope(outOfOrderEnvelope);
  } catch (err) {
    caughtOutOfOrder = true;
    console.log(`  ✓ [Defense F] Out-of-order stage correctly rejected: ${err.message}`);
  }
  assert.strictEqual(caughtOutOfOrder, true, 'Broker must reject out-of-order stage transition');

  // -------------------------------------------------------------------------
  // RUN FULL PIPELINE END-TO-END WITH SIGNED ENVELOPES
  // -------------------------------------------------------------------------
  // Stages remaining: parser, semantic, ir, codegen, test, audit
  for (const st of ['parser', 'semantic', 'ir', 'codegen', 'test', 'audit']) {
    const res = broker.runStageWithEnvelope(job.jobId, st, agents[st]);
    assert.strictEqual(res.ok, true);
    console.log(`  ✓ Stage [${st}] verified with bidirectional signed envelope`);
  }

  const finalJob = broker.getJob(job.jobId);
  assert.strictEqual(finalJob.status, 'COMPLETED');
  console.log(`  ✓ Full pipeline completed under Zero-Trust Envelope security (Final status: '${finalJob.status}')`);

  // Verify entire event chain is cryptographically intact
  const chain = broker.verifyChain();
  assert.strictEqual(chain.valid, true);
  console.log(`  ✓ Tamper-evident event chain verified: ${chain.count} records linked`);

  broker.close();
  if (fs.existsSync(testDb)) fs.unlinkSync(testDb);

  console.log('\n  ✅ ALL PHASE 3 SIGNED ENVELOPE CHECKS PASSED (100%)\n');
}

runEnvelopeTests().catch(err => {
  console.error('Phase 3 tests failed:', err);
  process.exit(1);
});
