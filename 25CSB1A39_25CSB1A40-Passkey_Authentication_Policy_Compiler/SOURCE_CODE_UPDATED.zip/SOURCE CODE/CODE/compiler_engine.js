/**
 * compiler_engine.js
 * 
 * Embedded execution engine mirroring the C++ Policy Compiler pipeline:
 * Lexer -> Parser -> Semantic Analyzer -> IR Generator -> IR Analyzer -> Target CodeGen -> Neuro-Symbolic Evaluator.
 * 
 * Used automatically by the backend when Windows Application Control / Device Guard prevents 
 * executing unsigned local binaries (spawn UNKNOWN), ensuring 100% reliable execution.
 */

const fs = require('fs');
const path = require('path');

let leetspeakBloomEngine = null;
try {
  leetspeakBloomEngine = require('./leetspeak_bloom_engine');
} catch (e) {
  // Graceful fallback
}

let AutomataEngine = null;
try {
  AutomataEngine = require('./automata_engine').AutomataEngine;
} catch (e) {
  // Graceful fallback
}

// 1. LEXER
class Lexer {
  constructor(input) {
    this.src = input;
    this.i = 0;
    this.line = 1;
    this.col = 1;
    this.errs = [];
  }

  peek() {
    if (this.i >= this.src.length) return '\0';
    return this.src[this.i];
  }

  get() {
    if (this.i >= this.src.length) return '\0';
    const c = this.src[this.i++];
    if (c === '\n') {
      this.line++;
      this.col = 1;
    } else {
      this.col++;
    }
    return c;
  }

  skipSpacesAndComments() {
    while (this.i < this.src.length) {
      const c = this.peek();
      if (c === ' ' || c === '\t' || c === '\r') {
        this.get();
        continue;
      }
      if (c === '#') {
        while (this.i < this.src.length && this.peek() !== '\n') {
          this.get();
        }
        continue;
      }
      if (c === '/' && this.i + 1 < this.src.length && this.src[this.i + 1] === '/') {
        while (this.i < this.src.length && this.peek() !== '\n') {
          this.get();
        }
        continue;
      }
      break;
    }
  }

  tokenize() {
    const out = [];

    while (this.i < this.src.length) {
      this.skipSpacesAndComments();
      if (this.i >= this.src.length) break;

      const c = this.peek();
      const start = { line: this.line, col: this.col };

      if (c === '\n') {
        this.get();
        out.push({ type: 'Newline', lexeme: '\\n', line: start.line, col: start.col });
        continue;
      }

      if (c === '[') {
        this.get();
        out.push({ type: 'LBracket', lexeme: '[', line: start.line, col: start.col });
        continue;
      }

      if (c === ']') {
        this.get();
        out.push({ type: 'RBracket', lexeme: ']', line: start.line, col: start.col });
        continue;
      }

      if (c === ',') {
        this.get();
        out.push({ type: 'Comma', lexeme: ',', line: start.line, col: start.col });
        continue;
      }

      if (c === '"' || c === "'") {
        const quote = this.get();
        let s = '';
        while (this.i < this.src.length && this.peek() !== quote && this.peek() !== '\n') {
          if (this.peek() === '\\' && this.i + 1 < this.src.length) {
            this.get();
            s += this.get();
          } else {
            s += this.get();
          }
        }
        if (this.peek() === quote) this.get();
        out.push({ type: 'String', lexeme: s, line: start.line, col: start.col });
        continue;
      }

      if (/[a-zA-Z_]/.test(c)) {
        let s = '';
        while (this.i < this.src.length && /[a-zA-Z0-9_]/.test(this.peek())) {
          s += this.get();
        }
        const type = (s === 'true' || s === 'false') ? 'Boolean' : 'Identifier';
        out.push({ type, lexeme: s, line: start.line, col: start.col });
        continue;
      }

      if (/[0-9]/.test(c)) {
        let s = '';
        while (this.i < this.src.length && /[0-9]/.test(this.peek())) {
          s += this.get();
        }
        out.push({ type: 'Number', lexeme: s, line: start.line, col: start.col });
        continue;
      }

      this.errs.push({ message: `Unexpected character: ${c}`, line: start.line, col: start.col });
      this.get();
      out.push({ type: 'Unknown', lexeme: c, line: start.line, col: start.col });
    }

    out.push({ type: 'End', lexeme: 'EOF', line: this.line, col: this.col });
    return out;
  }
}

// 2. PARSER
class Parser {
  constructor(tokens) {
    this.ts = tokens;
    this.k = 0;
    this.errs = [];
  }

  cur() {
    if (this.k >= this.ts.length) return this.ts[this.ts.length - 1];
    return this.ts[this.k];
  }

  skipNewlines() {
    while (this.cur().type === 'Newline') this.k++;
  }

  parseValue() {
    if (this.cur().type === 'Number' || this.cur().type === 'Boolean' || this.cur().type === 'String' || this.cur().type === 'Identifier') {
      return this.ts[this.k++].lexeme;
    }
    this.errs.push({ message: 'Expected value (number/boolean/string)', line: this.cur().line, col: this.cur().col });
    this.k++;
    return '';
  }

  parseRule() {
    const firstTok = this.cur();
    const startPos = { line: firstTok.line, col: firstTok.col };

    // DSL 2.0: require <uppercase|lowercase|digit|special> <count|bool>
    if (firstTok.lexeme === 'require' && this.ts[this.k + 1] && this.ts[this.k + 1].type === 'Identifier') {
      this.k++; // consume 'require'
      const catTok = this.cur();
      this.k++;
      let count = 1;
      if (this.cur().type === 'Number') {
        count = parseInt(this.cur().lexeme, 10);
        this.k++;
      } else if (this.cur().type === 'Boolean') {
        count = (this.cur().lexeme === 'true' ? 1 : 0);
        this.k++;
      }
      if (this.cur().type === 'Newline') this.k++;
      return {
        name: 'require_' + catTok.lexeme.toLowerCase(),
        value: count.toString(),
        pos: startPos
      };
    }

    // DSL 2.0: forbid <spaces|sequence|repeated> [threshold]
    if (firstTok.lexeme === 'forbid' && this.ts[this.k + 1] && this.ts[this.k + 1].type === 'Identifier') {
      this.k++; // consume 'forbid'
      const targetTok = this.cur();
      this.k++;
      let threshold = 3;
      if (this.cur().type === 'Number') {
        threshold = parseInt(this.cur().lexeme, 10);
        this.k++;
      }
      if (this.cur().type === 'Newline') this.k++;
      return {
        name: 'forbid_' + targetTok.lexeme.toLowerCase(),
        value: threshold.toString(),
        pos: startPos
      };
    }

    // DSL 2.0: blacklist <term> or blacklist [ "t1", "t2", ... ] or blacklist t1, t2
    if (firstTok.lexeme === 'blacklist') {
      this.k++;
      const words = [];
      if (this.cur().type === 'LBracket') {
        this.k++; // consume '['
        while (this.cur().type !== 'RBracket' && this.cur().type !== 'End') {
          this.skipNewlines();
          if (this.cur().type === 'String' || this.cur().type === 'Identifier') {
            words.push(this.cur().lexeme);
            this.k++;
          } else if (this.cur().type === 'Comma') {
            this.k++;
          } else if (this.cur().type !== 'RBracket') {
            this.k++;
          }
          this.skipNewlines();
        }
        if (this.cur().type === 'RBracket') this.k++;
      } else {
        while (this.cur().type === 'String' || this.cur().type === 'Identifier' || this.cur().type === 'Comma') {
          if (this.cur().type === 'String' || this.cur().type === 'Identifier') {
            words.push(this.cur().lexeme);
          }
          this.k++;
          if (this.cur().type === 'Newline' || this.cur().type === 'End') break;
        }
      }
      if (this.cur().type === 'Newline') this.k++;
      return {
        name: 'blacklist',
        value: JSON.stringify(words),
        pos: startPos
      };
    }

    // DSL 2.0: strength [minimum] <number | level> OR minStrength <number | level>
    if (firstTok.lexeme === 'strength' || firstTok.lexeme === 'minStrength' || firstTok.lexeme === 'min_strength') {
      this.k++;
      if (this.cur().lexeme === 'minimum' || this.cur().lexeme === 'min' || this.cur().lexeme === 'level') {
        this.k++;
      }
      let level = '80';
      if (this.cur().type === 'Number' || this.cur().type === 'Identifier' || this.cur().type === 'String') {
        level = this.cur().lexeme;
        this.k++;
      }
      if (this.cur().type === 'Newline') this.k++;
      return {
        name: 'strength',
        value: level,
        pos: startPos
      };
    }

    // Standard rule: name value
    this.k++;
    const value = this.parseValue();
    if (this.cur().type === 'Newline') this.k++;

    return {
      name: firstTok.lexeme,
      value,
      pos: startPos
    };
  }

  parse() {
    const rules = [];
    this.skipNewlines();

    while (this.cur().type !== 'End') {
      if (this.cur().type === 'Newline') {
        this.skipNewlines();
        continue;
      }

      if (this.cur().type === 'Unknown') {
        this.errs.push({ message: 'Unknown token in input', line: this.cur().line, col: this.cur().col });
        while (this.cur().type !== 'Newline' && this.cur().type !== 'End') this.k++;
        if (this.cur().type === 'Newline') this.k++;
        continue;
      }

      rules.push(this.parseRule());
      this.skipNewlines();
    }

    return { rules };
  }
}

// 3. SEMANTIC ANALYZER with Levenshtein typo suggestion
function levenshteinDistance(s1, s2) {
  const d = Array(s1.length + 1).fill(null).map(() => Array(s2.length + 1).fill(0));
  for (let i = 0; i <= s1.length; i++) d[i][0] = i;
  for (let j = 0; j <= s2.length; j++) d[0][j] = j;

  for (let i = 1; i <= s1.length; i++) {
    for (let j = 1; j <= s2.length; j++) {
      const cost = s1[i - 1].toLowerCase() === s2[j - 1].toLowerCase() ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
    }
  }
  return d[s1.length][s2.length];
}

function suggestRule(typo) {
  const validRules = [
    'minLength', 'maxLength', 'requireUpper', 'requireLower', 'requireDigit', 'requireSpecial',
    'noSpaces', 'max_sequence', 'maxSequence', 'max_repeated', 'maxRepeated', 'blacklist',
    'require', 'forbid', 'strength', 'minStrength', 'min_strength'
  ];
  let bestMatch = '';
  let minDistance = 3;

  for (const rule of validRules) {
    const dist = levenshteinDistance(typo, rule);
    if (dist < minDistance) {
      minDistance = dist;
      bestMatch = rule;
    }
  }
  return bestMatch;
}

class SemanticAnalyzer {
  constructor() {
    this.errs = [];
    this.constraints = {
      minLength: -1,
      maxLength: -1,
      requireUpper: -1,
      requireLower: -1,
      requireDigit: -1,
      requireSpecial: -1,
      minUpper: 0,
      minLower: 0,
      minDigit: 0,
      minSpecial: 0,
      noSpaces: -1,
      maxSequence: -1,
      maxRepeated: -1,
      blacklist: [],
      strength: '',
      minStrength: ''
    };
  }

  analyze(prog) {
    for (const rule of prog.rules) {
      const name = rule.name;
      const val = rule.value;

      if (name === 'minLength' || name === 'min_length') {
        const v = parseInt(val, 10);
        if (isNaN(v) || v <= 0) {
          this.errs.push({ message: `Invalid minLength '${val}'. Must be a positive integer.`, line: rule.pos.line, col: rule.pos.col });
        } else {
          this.constraints.minLength = v;
        }
      } else if (name === 'maxLength' || name === 'max_length') {
        const v = parseInt(val, 10);
        if (isNaN(v) || v <= 0) {
          this.errs.push({ message: `Invalid maxLength '${val}'. Must be a positive integer.`, line: rule.pos.line, col: rule.pos.col });
        } else {
          this.constraints.maxLength = v;
        }
      } else if (name === 'requireUpper' || name === 'require_upper' || name === 'require_uppercase') {
        const v = parseInt(val, 10);
        if (!isNaN(v)) {
          this.constraints.requireUpper = v > 0 ? 1 : 0;
          this.constraints.minUpper = Math.max(0, v);
        } else {
          this.constraints.requireUpper = (val === 'true' ? 1 : 0);
          this.constraints.minUpper = (val === 'true' ? 1 : 0);
        }
      } else if (name === 'requireLower' || name === 'require_lower' || name === 'require_lowercase') {
        const v = parseInt(val, 10);
        if (!isNaN(v)) {
          this.constraints.requireLower = v > 0 ? 1 : 0;
          this.constraints.minLower = Math.max(0, v);
        } else {
          this.constraints.requireLower = (val === 'true' ? 1 : 0);
          this.constraints.minLower = (val === 'true' ? 1 : 0);
        }
      } else if (name === 'requireDigit' || name === 'require_digit' || name === 'require_digits') {
        const v = parseInt(val, 10);
        if (!isNaN(v)) {
          this.constraints.requireDigit = v > 0 ? 1 : 0;
          this.constraints.minDigit = Math.max(0, v);
        } else {
          this.constraints.requireDigit = (val === 'true' ? 1 : 0);
          this.constraints.minDigit = (val === 'true' ? 1 : 0);
        }
      } else if (name === 'requireSpecial' || name === 'require_special' || name === 'require_specials') {
        const v = parseInt(val, 10);
        if (!isNaN(v)) {
          this.constraints.requireSpecial = v > 0 ? 1 : 0;
          this.constraints.minSpecial = Math.max(0, v);
        } else {
          this.constraints.requireSpecial = (val === 'true' ? 1 : 0);
          this.constraints.minSpecial = (val === 'true' ? 1 : 0);
        }
      } else if (name === 'noSpaces' || name === 'no_spaces' || name === 'forbid_spaces' || name === 'forbid_whitespace') {
        this.constraints.noSpaces = (val === 'false' ? 0 : 1);
      } else if (name === 'max_sequence' || name === 'maxSequence' || name === 'forbid_sequence' || name === 'forbid_sequences') {
        const v = parseInt(val, 10);
        if (isNaN(v) || v < 2) {
          this.errs.push({ message: `Invalid max_sequence threshold '${val}'. Must be >= 2.`, line: rule.pos.line, col: rule.pos.col });
        } else {
          this.constraints.maxSequence = v;
        }
      } else if (name === 'max_repeated' || name === 'maxRepeated' || name === 'forbid_repeated' || name === 'forbid_consecutive') {
        const v = parseInt(val, 10);
        if (isNaN(v) || v < 2) {
          this.errs.push({ message: `Invalid max_repeated threshold '${val}'. Must be >= 2.`, line: rule.pos.line, col: rule.pos.col });
        } else {
          this.constraints.maxRepeated = v;
        }
      } else if (name === 'blacklist') {
        try {
          const parsed = JSON.parse(val);
          if (Array.isArray(parsed)) {
            for (const item of parsed) {
              if (typeof item === 'string' && item.length > 0) {
                this.constraints.blacklist.push(item);
              }
            }
          }
        } catch (_) {
          if (val && val.length > 0) this.constraints.blacklist.push(val);
        }
      } else if (name === 'strength' || name === 'minStrength' || name === 'min_strength') {
        this.constraints.strength = val || '80';
        this.constraints.minStrength = val || '80';
      } else {
        let msg = `Unknown rule: '${name}'`;
        const suggestion = suggestRule(name);
        if (suggestion) {
          msg += `. Did you mean '${suggestion}'?`;
        }
        this.errs.push({ message: msg, line: rule.pos.line, col: rule.pos.col });
      }
    }

    if (this.constraints.minLength !== -1 && this.constraints.maxLength !== -1 && this.constraints.minLength > this.constraints.maxLength) {
      this.errs.push({ message: 'minLength cannot be greater than maxLength', line: 0, col: 0 });
    }
  }
}

// 4. IR ANALYZER
class IRAnalyzer {
  static analyze(c) {
    const warnings = [];
    if (c.minLength !== -1 && c.maxLength !== -1 && c.minLength === c.maxLength) {
      warnings.push(`Password length is fixed (${c.minLength})`);
    }
    if (c.minLength !== -1 && c.minLength < 6) {
      warnings.push('Weak policy: minimum length too small');
    }
    return warnings;
  }
}

// 5. TARGET CODE GENERATOR (POLYGLOT: C++, Python, TypeScript, Rust)
class CodeGenerator {
  static generateCpp(c, outputPath) {
    const code = `// --- AUTO-GENERATED TARGET CODE ---
// Generated by the Policy Compiler (Target: C++17)

#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <cmath>

struct ValidationResult {
    bool isValid;
    std::vector<std::string> errors;
    double entropyScore;
};

class CompiledPolicyValidator {
private:
    std::string password;

    int calculatePoolSize(int uppers, int lowers, int digits, int specials) {
        int pool = 0;
        if (uppers > 0) pool += 26;
        if (lowers > 0) pool += 26;
        if (digits > 0) pool += 10;
        if (specials > 0) pool += 32;
        return pool;
    }

public:
    CompiledPolicyValidator(const std::string& pwd) : password(pwd) {}

    ValidationResult validate() {
        ValidationResult result;
        result.isValid = true;

        int upperCount = 0, lowerCount = 0, digitCount = 0, specialCount = 0, spaceCount = 0;
        for (char ch : password) {
            if (std::isupper(ch)) upperCount++;
            else if (std::islower(ch)) lowerCount++;
            else if (std::isdigit(ch)) digitCount++;
            else if (std::isspace(ch)) spaceCount++;
            else specialCount++;
        }

        int pool = calculatePoolSize(upperCount, lowerCount, digitCount, specialCount);
        if (pool > 0) {
             result.entropyScore = password.length() * (std::log(pool) / std::log(2));
        } else {
             result.entropyScore = 0;
        }

        // --- COMPILED CONSTRAINTS INJECTION ---
${c.minLength !== -1 ? `        if (password.length() < ${c.minLength}) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Password is too short. Minimum length is ${c.minLength}.");
        }\n` : ''}${c.maxLength !== -1 ? `        if (password.length() > ${c.maxLength}) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Password is too long. Maximum length is ${c.maxLength}.");
        }\n` : ''}${c.requireUpper === 1 ? `        if (upperCount == 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing uppercase letter (A-Z).");
        }\n` : (c.requireUpper === 0 ? `        if (upperCount > 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Uppercase letter (A-Z) is forbidden.");
        }\n` : '')}${c.requireLower === 1 ? `        if (lowerCount == 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing lowercase letter (a-z).");
        }\n` : (c.requireLower === 0 ? `        if (lowerCount > 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Lowercase letter (a-z) is forbidden.");
        }\n` : '')}${c.requireDigit === 1 ? `        if (digitCount == 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing numeric digit (0-9).");
        }\n` : (c.requireDigit === 0 ? `        if (digitCount > 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Numeric digit (0-9) is forbidden.");
        }\n` : '')}${c.requireSpecial === 1 ? `        if (specialCount == 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing special character (!@#...).");
        }\n` : (c.requireSpecial === 0 ? `        if (specialCount > 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Special character (!@#...) is forbidden.");
        }\n` : '')}${c.noSpaces === 1 ? `        if (spaceCount > 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Password contains illegal whitespace characters.");
        }\n` : (c.noSpaces === 0 ? `        if (spaceCount == 0) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing required space character.");
        }\n` : '')}${c.minUpper > 1 ? `        if (upperCount < ${c.minUpper}) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing required uppercase count (requires at least ${c.minUpper}).");
        }\n` : ''}${c.minLower > 1 ? `        if (lowerCount < ${c.minLower}) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing required lowercase count (requires at least ${c.minLower}).");
        }\n` : ''}${c.minDigit > 1 ? `        if (digitCount < ${c.minDigit}) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing required numeric count (requires at least ${c.minDigit}).");
        }\n` : ''}${c.minSpecial > 1 ? `        if (specialCount < ${c.minSpecial}) {
            result.isValid = false;
            result.errors.push_back("[REJECTED] Missing required special character count (requires at least ${c.minSpecial}).");
        }\n` : ''}${c.maxSequence !== -1 ? `        for (size_t i = ${c.maxSequence}; i < password.length(); ++i) {
            bool asc = true, desc = true;
            for (int k = 1; k <= ${c.maxSequence}; ++k) {
                if (password[i - k + 1] != password[i - k] + 1) asc = false;
                if (password[i - k + 1] != password[i - k] - 1) desc = false;
            }
            if (asc || desc) {
                result.isValid = false;
                result.errors.push_back("[REJECTED] Sequential character run exceeds maximum allowed (${c.maxSequence}).");
                break;
            }
        }\n` : ''}${c.maxRepeated !== -1 ? `        int repRun = 1;
        for (size_t i = 1; i < password.length(); ++i) {
            if (password[i] == password[i - 1]) {
                repRun++;
                if (repRun > ${c.maxRepeated}) {
                    result.isValid = false;
                    result.errors.push_back("[REJECTED] Repeated character sequence exceeds maximum allowed (${c.maxRepeated}).");
                    break;
                }
            } else {
                repRun = 1;
            }
        }\n` : ''}${c.blacklist && c.blacklist.length > 0 ? `        static const std::vector<std::string> blacklistTerms = { ${c.blacklist.map(w => JSON.stringify(w)).join(', ')} };
        for (const auto& term : blacklistTerms) {
            if (password.find(term) != std::string::npos) {
                result.isValid = false;
                result.errors.push_back("[REJECTED] Contains blacklisted keyword: '" + term + "'.");
                break;
            }
        }\n` : ''}        // --------------------------------------

        return result;
    }
};

int main() {
    std::string inputPwd;
    std::cout << "========================================\\n";
    std::cout << "  Standalone Target Policy Evaluator (C++)\\n";
    std::cout << "========================================\\n";
    std::cout << "Enter a password to validate: ";
    std::getline(std::cin, inputPwd);

    CompiledPolicyValidator validator(inputPwd);
    ValidationResult res = validator.validate();

    if (res.isValid) {
        std::cout << "\\n✅ STATUS: VALID\\n";
    } else {
        std::cout << "\\n❌ STATUS: INVALID\\n";
        std::cout << "\\n-- Error Log --\\n";
        for (const auto& err : res.errors) {
             std::cout << "* " << err << "\\n";
        }
    }
    std::cout << "\\n-- Metrics --\\n";
    std::cout << "Calculated Entropy: " << res.entropyScore << " bits\\n";
    if (res.entropyScore > 80.0) std::cout << "Strength: VERY STRONG\\n";
    else if (res.entropyScore > 60.0) std::cout << "Strength: STRONG\\n";
    else if (res.entropyScore > 40.0) std::cout << "Strength: MODERATE\\n";
    else std::cout << "Strength: WEAK\\n";

    return 0;
}
`;
    if (outputPath) {
      try { fs.writeFileSync(outputPath, code, 'utf8'); } catch (_) {}
    }
    return code;
  }

  static generatePython(c, outputPath) {
    const code = `\"\"\"
AUTO-GENERATED TARGET CODE
Generated by the Policy Compiler (Target: Python 3)
\"\"\"

import math
import sys

class CompiledPolicyValidator:
    def __init__(self, password: str):
        self.password = password

    def calculate_pool_size(self, uppers: int, lowers: int, digits: int, specials: int) -> int:
        pool = 0
        if uppers > 0: pool += 26
        if lowers > 0: pool += 26
        if digits > 0: pool += 10
        if specials > 0: pool += 32
        return pool

    def validate(self) -> dict:
        errors = []
        upper_count = sum(1 for ch in self.password if ch.isupper())
        lower_count = sum(1 for ch in self.password if ch.islower())
        digit_count = sum(1 for ch in self.password if ch.isdigit())
        space_count = sum(1 for ch in self.password if ch.isspace())
        special_count = len(self.password) - (upper_count + lower_count + digit_count + space_count)

        pool = self.calculate_pool_size(upper_count, lower_count, digit_count, special_count)
        entropy = len(self.password) * math.log2(pool) if pool > 0 else 0.0

        # --- COMPILED CONSTRAINTS INJECTION ---
${c.minLength !== -1 ? `        if len(self.password) < ${c.minLength}:
            errors.append('[REJECTED] Password is too short. Minimum length is ${c.minLength}.')\n` : ''}${c.maxLength !== -1 ? `        if len(self.password) > ${c.maxLength}:
            errors.append('[REJECTED] Password is too long. Maximum length is ${c.maxLength}.')\n` : ''}${c.requireUpper === 1 ? `        if upper_count == 0:
            errors.append('[REJECTED] Missing uppercase letter (A-Z).')\n` : (c.requireUpper === 0 ? `        if upper_count > 0:
            errors.append('[REJECTED] Uppercase letter (A-Z) is forbidden.')\n` : '')}${c.requireLower === 1 ? `        if lower_count == 0:
            errors.append('[REJECTED] Missing lowercase letter (a-z).')\n` : (c.requireLower === 0 ? `        if lower_count > 0:
            errors.append('[REJECTED] Lowercase letter (a-z) is forbidden.')\n` : '')}${c.requireDigit === 1 ? `        if digit_count == 0:
            errors.append('[REJECTED] Missing numeric digit (0-9).')\n` : (c.requireDigit === 0 ? `        if digit_count > 0:
            errors.append('[REJECTED] Numeric digit (0-9) is forbidden.')\n` : '')}${c.requireSpecial === 1 ? `        if special_count == 0:
            errors.append('[REJECTED] Missing special character (!@#...).')\n` : (c.requireSpecial === 0 ? `        if special_count > 0:
            errors.append('[REJECTED] Special character (!@#...) is forbidden.')\n` : '')}${c.noSpaces === 1 ? `        if space_count > 0:
            errors.append('[REJECTED] Password contains illegal whitespace characters.')\n` : (c.noSpaces === 0 ? `        if space_count == 0:
            errors.append('[REJECTED] Missing required space character.')\n` : '')}${c.minUpper > 1 ? `        if upper_count < ${c.minUpper}:
            errors.append('[REJECTED] Missing required uppercase count (requires at least ${c.minUpper}).')\n` : ''}${c.minLower > 1 ? `        if lower_count < ${c.minLower}:
            errors.append('[REJECTED] Missing required lowercase count (requires at least ${c.minLower}).')\n` : ''}${c.minDigit > 1 ? `        if digit_count < ${c.minDigit}:
            errors.append('[REJECTED] Missing required numeric count (requires at least ${c.minDigit}).')\n` : ''}${c.minSpecial > 1 ? `        if special_count < ${c.minSpecial}:
            errors.append('[REJECTED] Missing required special character count (requires at least ${c.minSpecial}).')\n` : ''}${c.maxSequence !== -1 ? `        for i in range(${c.maxSequence}, len(self.password)):
            asc = all(ord(self.password[i - k + 1]) == ord(self.password[i - k]) + 1 for k in range(1, ${c.maxSequence} + 1))
            desc = all(ord(self.password[i - k + 1]) == ord(self.password[i - k]) - 1 for k in range(1, ${c.maxSequence} + 1))
            if asc or desc:
                errors.append('[REJECTED] Sequential character run exceeds maximum allowed (${c.maxSequence}).')
                break\n` : ''}${c.maxRepeated !== -1 ? `        rep_run = 1
        for i in range(1, len(self.password)):
            if self.password[i] == self.password[i - 1]:
                rep_run += 1
                if rep_run > ${c.maxRepeated}:
                    errors.append('[REJECTED] Repeated character sequence exceeds maximum allowed (${c.maxRepeated}).')
                    break
            else:
                rep_run = 1\n` : ''}${c.blacklist && c.blacklist.length > 0 ? `        blacklist_terms = ${JSON.stringify(c.blacklist)}
        for term in blacklist_terms:
            if term in self.password:
                errors.append(f"[REJECTED] Contains blacklisted keyword: '{term}'.")
                break\n` : ''}        # -------------------------------------

        strength = 'VERY STRONG' if entropy > 80 else 'STRONG' if entropy > 60 else 'MODERATE' if entropy > 40 else 'WEAK'

        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'entropy_score': round(entropy, 2),
            'strength': strength
        }

if __name__ == '__main__':
    print("========================================")
    print("  Standalone Target Policy Evaluator (Python)")
    print("========================================")
    pwd = input("Enter password to validate: ")
    res = CompiledPolicyValidator(pwd).validate()

    if res['is_valid']:
        print("\\n✅ STATUS: VALID")
    else:
        print("\\n❌ STATUS: INVALID")
        print("\\n-- Error Log --")
        for err in res['errors']:
            print(f" * {err}")

    print(f"\\n-- Metrics --")
    print(f"Calculated Entropy: {res['entropy_score']} bits")
    print(f"Strength: {res['strength']}")
`;
    if (outputPath) {
      try { fs.writeFileSync(outputPath, code, 'utf8'); } catch (_) {}
    }
    return code;
  }

  static generateTypeScript(c, outputPath) {
    const code = `/**
 * AUTO-GENERATED TARGET CODE
 * Generated by the Policy Compiler (Target: TypeScript / Node.js)
 */

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  entropyScore: number;
  strength: 'VERY STRONG' | 'STRONG' | 'MODERATE' | 'WEAK';
}

export class CompiledPolicyValidator {
  constructor(private password: string) {}

  private calculatePoolSize(uppers: number, lowers: number, digits: number, specials: number): number {
    let pool = 0;
    if (uppers > 0) pool += 26;
    if (lowers > 0) pool += 26;
    if (digits > 0) pool += 10;
    if (specials > 0) pool += 32;
    return pool;
  }

  public validate(): ValidationResult {
    const errors: string[] = [];
    let upperCount = 0;
    let lowerCount = 0;
    let digitCount = 0;
    let spaceCount = 0;
    let specialCount = 0;

    for (const ch of this.password) {
      if (/[A-Z]/.test(ch)) upperCount++;
      else if (/[a-z]/.test(ch)) lowerCount++;
      else if (/[0-9]/.test(ch)) digitCount++;
      else if (/\\s/.test(ch)) spaceCount++;
      else specialCount++;
    }

    const pool = this.calculatePoolSize(upperCount, lowerCount, digitCount, specialCount);
    const entropy = pool > 0 ? this.password.length * Math.log2(pool) : 0;

    // --- COMPILED CONSTRAINTS INJECTION ---
${c.minLength !== -1 ? `    if (this.password.length < ${c.minLength}) {
      errors.push('[REJECTED] Password is too short. Minimum length is ${c.minLength}.');
    }\n` : ''}${c.maxLength !== -1 ? `    if (this.password.length > ${c.maxLength}) {
      errors.push('[REJECTED] Password is too long. Maximum length is ${c.maxLength}.');
    }\n` : ''}${c.requireUpper === 1 ? `    if (upperCount === 0) {
      errors.push('[REJECTED] Missing uppercase letter (A-Z).');
    }\n` : (c.requireUpper === 0 ? `    if (upperCount > 0) {
      errors.push('[REJECTED] Uppercase letter (A-Z) is forbidden.');
    }\n` : '')}${c.requireLower === 1 ? `    if (lowerCount === 0) {
      errors.push('[REJECTED] Missing lowercase letter (a-z).');
    }\n` : (c.requireLower === 0 ? `    if (lowerCount > 0) {
      errors.push('[REJECTED] Lowercase letter (a-z) is forbidden.');
    }\n` : '')}${c.requireDigit === 1 ? `    if (digitCount === 0) {
      errors.push('[REJECTED] Missing numeric digit (0-9).');
    }\n` : (c.requireDigit === 0 ? `    if (digitCount > 0) {
      errors.push('[REJECTED] Numeric digit (0-9) is forbidden.');
    }\n` : '')}${c.requireSpecial === 1 ? `    if (specialCount === 0) {
      errors.push('[REJECTED] Missing special character (!@#...).');
    }\n` : (c.requireSpecial === 0 ? `    if (specialCount > 0) {
      errors.push('[REJECTED] Special character (!@#...) is forbidden.');
    }\n` : '')}${c.noSpaces === 1 ? `    if (spaceCount > 0) {
      errors.push('[REJECTED] Password contains illegal whitespace characters.');
    }\n` : (c.noSpaces === 0 ? `    if (spaceCount === 0) {
      errors.push('[REJECTED] Missing required space character.');
    }\n` : '')}${c.minUpper > 1 ? `    if (upperCount < ${c.minUpper}) {
      errors.push('[REJECTED] Missing required uppercase count (requires at least ${c.minUpper}).');
    }\n` : ''}${c.minLower > 1 ? `    if (lowerCount < ${c.minLower}) {
      errors.push('[REJECTED] Missing required lowercase count (requires at least ${c.minLower}).');
    }\n` : ''}${c.minDigit > 1 ? `    if (digitCount < ${c.minDigit}) {
      errors.push('[REJECTED] Missing required numeric count (requires at least ${c.minDigit}).');
    }\n` : ''}${c.minSpecial > 1 ? `    if (specialCount < ${c.minSpecial}) {
      errors.push('[REJECTED] Missing required special character count (requires at least ${c.minSpecial}).');
    }\n` : ''}${c.maxSequence !== -1 ? `    for (let i = ${c.maxSequence}; i < this.password.length; i++) {
      let asc = true, desc = true;
      for (let k = 1; k <= ${c.maxSequence}; k++) {
        if (this.password.charCodeAt(i - k + 1) !== this.password.charCodeAt(i - k) + 1) asc = false;
        if (this.password.charCodeAt(i - k + 1) !== this.password.charCodeAt(i - k) - 1) desc = false;
      }
      if (asc || desc) {
        errors.push('[REJECTED] Sequential character run exceeds maximum allowed (${c.maxSequence}).');
        break;
      }
    }\n` : ''}${c.maxRepeated !== -1 ? `    let repRun = 1;
    for (let i = 1; i < this.password.length; i++) {
      if (this.password[i] === this.password[i - 1]) {
        repRun++;
        if (repRun > ${c.maxRepeated}) {
          errors.push('[REJECTED] Repeated character sequence exceeds maximum allowed (${c.maxRepeated}).');
          break;
        }
      } else {
        repRun = 1;
      }
    }\n` : ''}${c.blacklist && c.blacklist.length > 0 ? `    const blacklistTerms = ${JSON.stringify(c.blacklist)};
    for (const term of blacklistTerms) {
      if (this.password.includes(term)) {
        errors.push("[REJECTED] Contains blacklisted keyword: '" + term + "'.");
        break;
      }
    }\n` : ''}    // -------------------------------------

    const strength: 'VERY STRONG' | 'STRONG' | 'MODERATE' | 'WEAK' =
      entropy > 80 ? 'VERY STRONG' : entropy > 60 ? 'STRONG' : entropy > 40 ? 'MODERATE' : 'WEAK';

    return {
      isValid: errors.length === 0,
      errors,
      entropyScore: Math.round(entropy * 100) / 100,
      strength
    };
  }
}
`;
    if (outputPath) {
      try { fs.writeFileSync(outputPath, code, 'utf8'); } catch (_) {}
    }
    return code;
  }

  static generateRust(c, outputPath) {
    const code = `//! AUTO-GENERATED TARGET CODE
//! Generated by the Policy Compiler (Target: Rust)

#[derive(Debug, Clone)]
pub struct ValidationResult {
    pub is_valid: bool,
    pub errors: Vec<String>,
    pub entropy_score: f64,
    pub strength: String,
}

pub struct CompiledPolicyValidator {
    password: String,
}

impl CompiledPolicyValidator {
    pub fn new(password: &str) -> Self {
        Self { password: password.to_string() }
    }

    fn calculate_pool_size(&self, uppers: usize, lowers: usize, digits: usize, specials: usize) -> usize {
        let mut pool = 0;
        if uppers > 0 { pool += 26; }
        if lowers > 0 { pool += 26; }
        if digits > 0 { pool += 10; }
        if specials > 0 { pool += 32; }
        pool
    }

    pub fn validate(&self) -> ValidationResult {
        let mut errors = Vec::new();
        let mut upper_count = 0;
        let mut lower_count = 0;
        let mut digit_count = 0;
        let mut space_count = 0;
        let mut special_count = 0;

        for ch in self.password.chars() {
            if ch.is_ascii_uppercase() { upper_count += 1; }
            else if ch.is_ascii_lowercase() { lower_count += 1; }
            else if ch.is_ascii_digit() { digit_count += 1; }
            else if ch.is_whitespace() { space_count += 1; }
            else { special_count += 1; }
        }

        let pool = self.calculate_pool_size(upper_count, lower_count, digit_count, special_count);
        let entropy_score = if pool > 0 {
            (self.password.len() as f64) * (pool as f64).log2()
        } else {
            0.0
        };

        // --- COMPILED CONSTRAINTS INJECTION ---
${c.minLength !== -1 ? `        if self.password.len() < ${c.minLength} {
            errors.push(format!("[REJECTED] Password is too short. Minimum length is {}.", ${c.minLength}));
        }\n` : ''}${c.maxLength !== -1 ? `        if self.password.len() > ${c.maxLength} {
            errors.push(format!("[REJECTED] Password is too long. Maximum length is {}.", ${c.maxLength}));
        }\n` : ''}${c.requireUpper === 1 ? `        if upper_count == 0 {
            errors.push("[REJECTED] Missing uppercase letter (A-Z).".to_string());
        }\n` : (c.requireUpper === 0 ? `        if upper_count > 0 {
            errors.push("[REJECTED] Uppercase letter (A-Z) is forbidden.".to_string());
        }\n` : '')}${c.requireLower === 1 ? `        if lower_count == 0 {
            errors.push("[REJECTED] Missing lowercase letter (a-z).".to_string());
        }\n` : (c.requireLower === 0 ? `        if lower_count > 0 {
            errors.push("[REJECTED] Lowercase letter (a-z) is forbidden.".to_string());
        }\n` : '')}${c.requireDigit === 1 ? `        if digit_count == 0 {
            errors.push("[REJECTED] Missing numeric digit (0-9).".to_string());
        }\n` : (c.requireDigit === 0 ? `        if digit_count > 0 {
            errors.push("[REJECTED] Numeric digit (0-9) is forbidden.".to_string());
        }\n` : '')}${c.requireSpecial === 1 ? `        if special_count == 0 {
            errors.push("[REJECTED] Missing special character (!@#...).".to_string());
        }\n` : (c.requireSpecial === 0 ? `        if special_count > 0 {
            errors.push("[REJECTED] Special character (!@#...) is forbidden.".to_string());
        }\n` : '')}${c.noSpaces === 1 ? `        if space_count > 0 {
            errors.push("[REJECTED] Password contains illegal whitespace characters.".to_string());
        }\n` : (c.noSpaces === 0 ? `        if space_count == 0 {
            errors.push("[REJECTED] Missing required space character.".to_string());
        }\n` : '')}${c.minUpper > 1 ? `        if upper_count < ${c.minUpper} {
            errors.push(format!("[REJECTED] Missing required uppercase count (requires at least {}).", ${c.minUpper}));
        }\n` : ''}${c.minLower > 1 ? `        if lower_count < ${c.minLower} {
            errors.push(format!("[REJECTED] Missing required lowercase count (requires at least {}).", ${c.minLower}));
        }\n` : ''}${c.minDigit > 1 ? `        if digit_count < ${c.minDigit} {
            errors.push(format!("[REJECTED] Missing required numeric count (requires at least {}).", ${c.minDigit}));
        }\n` : ''}${c.minSpecial > 1 ? `        if special_count < ${c.minSpecial} {
            errors.push(format!("[REJECTED] Missing required special character count (requires at least {}).", ${c.minSpecial}));
        }\n` : ''}${c.maxSequence !== -1 ? `        let pw_bytes = self.password.as_bytes();
        for i in ${c.maxSequence}..pw_bytes.len() {
            let mut asc = true;
            let mut desc = true;
            for k in 1..=${c.maxSequence} {
                if pw_bytes[i - k + 1] != pw_bytes[i - k] + 1 { asc = false; }
                if pw_bytes[i - k + 1] != pw_bytes[i - k] - 1 { desc = false; }
            }
            if asc || desc {
                errors.push(format!("[REJECTED] Sequential character run exceeds maximum allowed ({}).", ${c.maxSequence}));
                break;
            }
        }\n` : ''}${c.maxRepeated !== -1 ? `        let mut rep_run = 1;
        let chars: Vec<char> = self.password.chars().collect();
        for i in 1..chars.len() {
            if chars[i] == chars[i - 1] {
                rep_run += 1;
                if rep_run > ${c.maxRepeated} {
                    errors.push(format!("[REJECTED] Repeated character sequence exceeds maximum allowed ({}).", ${c.maxRepeated}));
                    break;
                }
            } else {
                rep_run = 1;
            }
        }\n` : ''}${c.blacklist && c.blacklist.length > 0 ? `        let blacklist: &[&str] = &[${c.blacklist.map(w => JSON.stringify(w)).join(', ')}];
        for term in blacklist {
            if self.password.contains(term) {
                errors.push(format!("[REJECTED] Contains blacklisted keyword: '{}'.", term));
                break;
            }
        }\n` : ''}        // -------------------------------------

        let strength = if entropy_score > 80.0 { "VERY STRONG" }
            else if entropy_score > 60.0 { "STRONG" }
            else if entropy_score > 40.0 { "MODERATE" }
            else { "WEAK" };

        ValidationResult {
            is_valid: errors.is_empty(),
            errors,
            entropy_score: (entropy_score * 100.0).round() / 100.0,
            strength: strength.to_string(),
        }
    }
}

fn main() {
    use std::io::{self, Write};
    println!("========================================");
    println!("  Standalone Target Policy Evaluator (Rust)");
    println!("========================================");
    print!("Enter password to validate: ");
    io::stdout().flush().unwrap();

    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    let trimmed = input.trim();

    let validator = CompiledPolicyValidator::new(trimmed);
    let res = validator.validate();

    if res.is_valid {
        println!("\\n✅ STATUS: VALID");
    } else {
        println!("\\n❌ STATUS: INVALID");
        for err in &res.errors {
            println!(" * {}", err);
        }
    }
    println!("\\n-- Metrics --");
    println!("Calculated Entropy: {:.2} bits ({})", res.entropy_score, res.strength);
}
`;
    if (outputPath) {
      try { fs.writeFileSync(outputPath, code, 'utf8'); } catch (_) {}
    }
    return code;
  }

  static generateAll(c, dirPath) {
    const cppFile = path.join(dirPath, 'generated_validator.cpp');
    const pyFile = path.join(dirPath, 'generated_validator.py');
    const tsFile = path.join(dirPath, 'generated_validator.ts');
    const rsFile = path.join(dirPath, 'generated_validator.rs');

    return {
      cpp: this.generateCpp(c, cppFile),
      python: this.generatePython(c, pyFile),
      typescript: this.generateTypeScript(c, tsFile),
      rust: this.generateRust(c, rsFile)
    };
  }

  static generate(c, outputPath) {
    return this.generateCpp(c, outputPath);
  }
}

// 6. NEURO-SYMBOLIC EVALUATOR
class NeuroSymbolicEvaluator {
  static validate(password, c) {
    let upper = 0, lower = 0, digit = 0, special = 0, spaces = 0;
    for (const ch of password) {
      if (/[A-Z]/.test(ch)) upper++;
      else if (/[a-z]/.test(ch)) lower++;
      else if (/[0-9]/.test(ch)) digit++;
      else if (/\s/.test(ch)) spaces++;
      else special++;
    }

    if (c.minLength !== -1 && password.length < c.minLength) return false;
    if (c.maxLength !== -1 && password.length > c.maxLength) return false;

    if (c.requireUpper === 1 && upper === 0) return false;
    if (c.requireUpper === 0 && upper > 0) return false;
    if (c.minUpper > 1 && upper < c.minUpper) return false;

    if (c.requireLower === 1 && lower === 0) return false;
    if (c.requireLower === 0 && lower > 0) return false;
    if (c.minLower > 1 && lower < c.minLower) return false;

    if (c.requireDigit === 1 && digit === 0) return false;
    if (c.requireDigit === 0 && digit > 0) return false;
    if (c.minDigit > 1 && digit < c.minDigit) return false;

    if (c.requireSpecial === 1 && special === 0) return false;
    if (c.requireSpecial === 0 && special > 0) return false;
    if (c.minSpecial > 1 && special < c.minSpecial) return false;

    if (c.noSpaces === 1 && spaces > 0) return false;
    if (c.noSpaces === 0 && spaces === 0) return false;

    if (c.maxSequence !== -1 && c.maxSequence > 0) {
      for (let i = c.maxSequence; i < password.length; i++) {
        let asc = true, desc = true;
        for (let k = 1; k <= c.maxSequence; k++) {
          if (password.charCodeAt(i - k + 1) !== password.charCodeAt(i - k) + 1) asc = false;
          if (password.charCodeAt(i - k + 1) !== password.charCodeAt(i - k) - 1) desc = false;
        }
        if (asc || desc) return false;
      }
    }

    if (c.maxRepeated !== -1 && c.maxRepeated > 0) {
      let repRun = 1;
      for (let i = 1; i < password.length; i++) {
        if (password[i] === password[i - 1]) {
          repRun++;
          if (repRun > c.maxRepeated) return false;
        } else {
          repRun = 1;
        }
      }
    }

    if (c.blacklist && c.blacklist.length > 0) {
      const lowerPw = password.toLowerCase();
      for (const term of c.blacklist) {
        if (lowerPw.includes(term.toLowerCase())) return false;
      }
    }

    return true;
  }

  static getViolations(password, c) {
    const violations = [];
    let upper = 0, lower = 0, digit = 0, special = 0, spaces = 0;
    for (const ch of password) {
      if (/[A-Z]/.test(ch)) upper++;
      else if (/[a-z]/.test(ch)) lower++;
      else if (/[0-9]/.test(ch)) digit++;
      else if (/\s/.test(ch)) spaces++;
      else special++;
    }

    if (c.minLength !== -1 && password.length < c.minLength) {
      violations.push(`Below minimum length: password has ${password.length} characters (requires at least ${c.minLength})`);
    }
    if (c.maxLength !== -1 && password.length > c.maxLength) {
      violations.push(`Exceeds maximum length: password has ${password.length} characters (maximum allowed is ${c.maxLength})`);
    }
    if (c.requireUpper === 1 && upper === 0) {
      violations.push(`Missing required uppercase letter (A-Z)`);
    }
    if (c.minUpper > 1 && upper < c.minUpper) {
      violations.push(`Requires at least ${c.minUpper} uppercase letters (has ${upper})`);
    }
    if (c.requireUpper === 0 && upper > 0) {
      violations.push(`Contains forbidden uppercase letter`);
    }
    if (c.requireLower === 1 && lower === 0) {
      violations.push(`Missing required lowercase letter (a-z)`);
    }
    if (c.minLower > 1 && lower < c.minLower) {
      violations.push(`Requires at least ${c.minLower} lowercase letters (has ${lower})`);
    }
    if (c.requireLower === 0 && lower > 0) {
      violations.push(`Contains forbidden lowercase letter`);
    }
    if (c.requireDigit === 1 && digit === 0) {
      violations.push(`Missing required numeric digit (0-9)`);
    }
    if (c.minDigit > 1 && digit < c.minDigit) {
      violations.push(`Requires at least ${c.minDigit} numeric digits (has ${digit})`);
    }
    if (c.requireDigit === 0 && digit > 0) {
      violations.push(`Contains forbidden digit`);
    }
    if (c.requireSpecial === 1 && special === 0) {
      violations.push(`Missing required special character (!@#$%^&*...)`);
    }
    if (c.minSpecial > 1 && special < c.minSpecial) {
      violations.push(`Requires at least ${c.minSpecial} special characters (has ${special})`);
    }
    if (c.requireSpecial === 0 && special > 0) {
      violations.push(`Contains forbidden special character`);
    }
    if (c.noSpaces === 1 && spaces > 0) {
      violations.push(`Contains forbidden space/whitespace characters`);
    }
    if (c.noSpaces === 0 && spaces === 0) {
      violations.push(`Missing required space character`);
    }

    if (c.maxSequence !== -1 && c.maxSequence > 0) {
      for (let i = c.maxSequence; i < password.length; i++) {
        let asc = true, desc = true;
        for (let k = 1; k <= c.maxSequence; k++) {
          if (password.charCodeAt(i - k + 1) !== password.charCodeAt(i - k) + 1) asc = false;
          if (password.charCodeAt(i - k + 1) !== password.charCodeAt(i - k) - 1) desc = false;
        }
        if (asc || desc) {
          violations.push(`Sequential character run exceeds maximum allowed (${c.maxSequence})`);
          break;
        }
      }
    }

    if (c.maxRepeated !== -1 && c.maxRepeated > 0) {
      let repRun = 1;
      for (let i = 1; i < password.length; i++) {
        if (password[i] === password[i - 1]) {
          repRun++;
          if (repRun > c.maxRepeated) {
            violations.push(`Repeated character sequence exceeds maximum allowed (${c.maxRepeated})`);
            break;
          }
        } else {
          repRun = 1;
        }
      }
    }

    if (c.blacklist && c.blacklist.length > 0) {
      const lowerPw = password.toLowerCase();
      for (const term of c.blacklist) {
        if (lowerPw.includes(term.toLowerCase())) {
          violations.push(`Contains blacklisted term: '${term}'`);
          break;
        }
      }
    }

    return violations;
  }

  static evaluate(password, c) {
    let score = 0;
    const reasons = [];

    let upper = 0, lower = 0, digit = 0, special = 0, spaces = 0;
    for (const ch of password) {
      if (/[A-Z]/.test(ch)) upper++;
      else if (/[a-z]/.test(ch)) lower++;
      else if (/[0-9]/.test(ch)) digit++;
      else if (/\s/.test(ch)) spaces++;
      else special++;
    }

    if (c.minLength !== -1) {
      if (password.length >= c.minLength) score += 2;
      else reasons.push('Below minimum length');
    }

    if (c.maxLength !== -1) {
      if (password.length <= c.maxLength) score += 1;
      else reasons.push('Exceeds maximum length');
    }

    if (c.requireUpper === 1) {
      if (upper >= (c.minUpper > 0 ? c.minUpper : 1)) score += 1;
      else reasons.push('Missing uppercase letter');
    } else if (c.requireUpper === 0) {
      if (upper === 0) score += 1;
      else reasons.push('Contains forbidden uppercase letter');
    }

    if (c.requireLower === 1) {
      if (lower >= (c.minLower > 0 ? c.minLower : 1)) score += 1;
      else reasons.push('Missing lowercase letter');
    } else if (c.requireLower === 0) {
      if (lower === 0) score += 1;
      else reasons.push('Contains forbidden lowercase letter');
    }

    if (c.requireDigit === 1) {
      if (digit >= (c.minDigit > 0 ? c.minDigit : 1)) score += 1;
      else reasons.push('Missing digit');
    } else if (c.requireDigit === 0) {
      if (digit === 0) score += 1;
      else reasons.push('Contains forbidden digit');
    }

    if (c.requireSpecial === 1) {
      if (special >= (c.minSpecial > 0 ? c.minSpecial : 1)) score += 2;
      else reasons.push('Missing special character');
    } else if (c.requireSpecial === 0) {
      if (special === 0) score += 1;
      else reasons.push('Contains forbidden special character');
    }

    if (c.noSpaces === 1) {
      if (spaces === 0) score += 1;
      else reasons.push('Contains spaces');
    } else if (c.noSpaces === 0) {
      if (spaces > 0) score += 1;
      else reasons.push('Missing space character');
    }

    if (password.length >= 12) score += 2;
    else if (password.length >= 8) score += 1;
    else score -= 1;

    if (upper > 0 && lower > 0 && digit > 0 && special > 0) score += 2;

    for (let i = 1; i < password.length; i++) {
      if (password[i] === password[i - 1]) score -= 1;
    }

    for (let i = 2; i < password.length; i++) {
      if (password.charCodeAt(i) === password.charCodeAt(i - 1) + 1 &&
          password.charCodeAt(i - 1) === password.charCodeAt(i - 2) + 1) {
        score -= 2;
        reasons.push('Sequential pattern detected');
        break;
      }
    }

    const common = new Set(['password', '123456', 'admin', 'qwerty', 'welcome', 'letmein']);
    if (common.has(password)) {
      score = 0;
      reasons.push('Common password detected');
    }

    let smartAnalysis = null;
    if (leetspeakBloomEngine) {
      try {
        smartAnalysis = leetspeakBloomEngine.analyzeCandidatePassword(password);
        if (smartAnalysis.status === 'REJECTED') {
          score = Math.max(0, score - 6);
          reasons.push(`[Blocklist/Leetspeak Level ${smartAnalysis.level}] ${smartAnalysis.reason}`);
        }
      } catch (_) {}
    }

    const level = score <= 2 ? 'Very Weak' : score <= 4 ? 'Weak' : score <= 7 ? 'Medium' : 'Strong';
    return { score, level, reasons, smartAnalysis };
  }
}

// 6.5 VISUAL AST & THREE-ADDRESS CODE (TAC) QUADRUPLE IR ENGINE
function buildAstHierarchy(rulesInput) {
  const rules = Array.isArray(rulesInput) ? rulesInput : (rulesInput && Array.isArray(rulesInput.rules) ? rulesInput.rules : []);
  const nodes = [];
  let idCounter = 1;

  rules.forEach((r, idx) => {
    const rawName = r.name || 'constraint';
    const val = r.value !== undefined ? r.value : '';
    const nameLower = rawName.toLowerCase();

    let nodeType = 'OperandNode';
    let category = 'Constraint';
    let icon = '📌';
    let color = '#2563EB';
    let bg = '#EFF6FF';
    let border = '#BFDBFE';
    let formalType = 'std::unique_ptr<ASTNode>';
    let label = `${rawName} = ${val}`;

    if (nameLower.includes('upper') || nameLower.includes('lower') || nameLower.includes('digit') || nameLower.includes('special')) {
      nodeType = 'OperandNode::CHAR_CLASS';
      category = 'CharacterConstraint';
      icon = '🔤';
      color = '#0284C7';
      bg = '#F0F9FF';
      border = '#BAE6FD';
      formalType = 'CharacterConstraintNode';
      let cleanClass = nameLower.replace(/^require_?/, '');
      if (cleanClass.startsWith('upper')) cleanClass = 'uppercase';
      else if (cleanClass.startsWith('lower')) cleanClass = 'lowercase';
      else if (cleanClass.startsWith('digit')) cleanClass = 'digits';
      else if (cleanClass.startsWith('special') || cleanClass.startsWith('symbol')) cleanClass = 'symbols';
      label = `require ${cleanClass} ${val === 'true' || val === '1' ? '>= 1' : val === 'false' || val === '0' ? '= 0' : '>= ' + val}`;
    } else if (nameLower.includes('length')) {
      nodeType = 'OperandNode::LENGTH_BOUND';
      category = 'LengthConstraint';
      icon = '📏';
      color = '#059669';
      bg = '#ECFDF5';
      border = '#A7F3D0';
      formalType = 'LengthConstraintNode';
      label = `${rawName} ${val}`;
    } else if (nameLower.includes('space') || nameLower.includes('sequence') || nameLower.includes('repeat')) {
      nodeType = 'OperatorNode::NOT';
      category = 'PatternConstraint';
      icon = '🚫';
      color = '#DC2626';
      bg = '#FEF2F2';
      border = '#FECACA';
      formalType = 'PatternConstraintNode';
      if (nameLower.includes('space')) {
        label = (val === 'false' || val === '0') ? 'allow spaces' : 'forbid spaces';
      } else if (nameLower.includes('sequence')) {
        label = `max sequence <= ${val}`;
      } else if (nameLower.includes('repeat')) {
        label = `max repeated <= ${val}`;
      } else {
        label = `forbid ${rawName} ${val !== '0' && val !== 'true' ? val : ''}`;
      }
    } else if (nameLower === 'blacklist') {
      nodeType = 'OperatorNode::NOT';
      category = 'DictionaryConstraint';
      icon = '🛡️';
      color = '#7C3AED';
      bg = '#F5F3FF';
      border = '#DDD6FE';
      formalType = 'DictionaryConstraintNode';
      let termCount = 1;
      try {
        if (typeof val === 'string' && val.startsWith('[')) {
          termCount = JSON.parse(val).length;
        }
      } catch (_) {}
      label = `blacklist [${termCount} term${termCount !== 1 ? 's' : ''}]`;
    } else if (nameLower.includes('strength')) {
      nodeType = 'OperandNode::STRENGTH';
      category = 'StrengthConstraint';
      icon = '⚡';
      color = '#D97706';
      bg = '#FFFBEB';
      border = '#FDE68A';
      formalType = 'StrengthConstraintNode';
      const isNum = !isNaN(parseFloat(val));
      label = isNum ? `min strength >= ${val} bits` : `min strength ${val}`;
    }

    nodes.push({
      id: idCounter++,
      originalIndex: idx + 1,
      name: rawName,
      val: val,
      nodeType: nodeType,
      category: category,
      icon: icon,
      color: color,
      bg: bg,
      border: border,
      formalType: formalType,
      label: label
    });
  });

  return nodes;
}

function synthesizeTacInstructions(c) {
  const instrs = [];
  let pc = 0;
  let t = 0;
  const newTemp = () => `t${t++}`;

  if (c.minLength !== -1 || c.maxLength !== -1) {
    const minL = c.minLength === -1 ? 0 : c.minLength;
    const maxL = c.maxLength === -1 ? '∞' : c.maxLength;
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'CHECK_LENGTH',
      arg1: `${minL}`,
      arg2: `${maxL}`,
      comment: `Verify password length bounds [${minL} .. ${maxL}]`,
      category: 'LengthBounds'
    });
  }

  const reqUpper = c.minUpper > 0 ? c.minUpper : (c.requireUpper === 1 ? 1 : 0);
  if (reqUpper > 0) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'MATCH_CLASS',
      arg1: '[A-Z]',
      arg2: `${reqUpper}`,
      comment: `Uppercase threshold >= ${reqUpper}`,
      category: 'CharClass'
    });
  }

  const reqLower = c.minLower > 0 ? c.minLower : (c.requireLower === 1 ? 1 : 0);
  if (reqLower > 0) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'MATCH_CLASS',
      arg1: '[a-z]',
      arg2: `${reqLower}`,
      comment: `Lowercase threshold >= ${reqLower}`,
      category: 'CharClass'
    });
  }

  const reqDigit = c.minDigit > 0 ? c.minDigit : (c.requireDigit === 1 ? 1 : 0);
  if (reqDigit > 0) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'MATCH_CLASS',
      arg1: '[0-9]',
      arg2: `${reqDigit}`,
      comment: `Numeric digit threshold >= ${reqDigit}`,
      category: 'CharClass'
    });
  }

  const reqSpecial = c.minSpecial > 0 ? c.minSpecial : (c.requireSpecial === 1 ? 1 : 0);
  if (reqSpecial > 0) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'MATCH_CLASS',
      arg1: '[!@#$%^&*]',
      arg2: `${reqSpecial}`,
      comment: `Special symbol threshold >= ${reqSpecial}`,
      category: 'CharClass'
    });
  }

  if (c.noSpaces === 1) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'SCAN_WHITESPACE',
      arg1: 'FORBID',
      arg2: '',
      comment: 'Trigger trap state on embedded whitespace',
      category: 'Pattern'
    });
  }

  if (c.maxSequence !== -1 && c.maxSequence !== undefined) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'SCAN_SEQUENCE',
      arg1: 'LIMIT',
      arg2: `${c.maxSequence}`,
      comment: `Monotonic ASCII sequence run <= ${c.maxSequence}`,
      category: 'Pattern'
    });
  }

  if (c.maxRepeated !== -1 && c.maxRepeated !== undefined) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'SCAN_REPEAT',
      arg1: 'LIMIT',
      arg2: `${c.maxRepeated}`,
      comment: `Repeated character run <= ${c.maxRepeated}`,
      category: 'Pattern'
    });
  }

  if (c.blacklist && c.blacklist.length > 0) {
    instrs.push({
      pc: pc++,
      reg: newTemp(),
      op: 'BLOOM_LOOKUP',
      arg1: `${c.blacklist.length}_TERMS`,
      arg2: '',
      comment: 'Static Bloom filter pre-filter + exact match',
      category: 'Security'
    });
  }

  const leafRegs = instrs.map(i => i.reg);
  if (leafRegs.length > 1) {
    let prevReg = leafRegs[0];
    for (let i = 1; i < leafRegs.length; ++i) {
      const nextTemp = newTemp();
      instrs.push({
        pc: pc++,
        reg: nextTemp,
        op: 'AND',
        arg1: prevReg,
        arg2: leafRegs[i],
        comment: `Conjunction step: ${prevReg} ∧ ${leafRegs[i]}`,
        category: 'Conjunction'
      });
      prevReg = nextTemp;
    }
    instrs.push({
      pc: pc++,
      reg: 'RES',
      op: 'RETURN',
      arg1: prevReg,
      arg2: '',
      comment: 'Synthesized Policy Accept/Reject Decision Oracle',
      category: 'Oracle'
    });
  }

  return instrs;
}

// 7. COMPILER ENGINE ENTRY POINT
function compilePolicy(dslText, testPassword = null) {
  const lexer = new Lexer(dslText);
  const tokens = lexer.tokenize();

  if (lexer.errs.length > 0) {
    return {
      success: false,
      stage: 'lexical',
      errors: lexer.errs
    };
  }

  const parser = new Parser(tokens);
  const prog = parser.parse();

  if (parser.errs.length > 0) {
    return {
      success: false,
      stage: 'syntax',
      errors: parser.errs
    };
  }

  const sem = new SemanticAnalyzer();
  sem.analyze(prog);

  if (sem.errs.length > 0) {
    return {
      success: false,
      stage: 'semantic',
      errors: sem.errs
    };
  }

  const constraints = sem.constraints;
  const warnings = IRAnalyzer.analyze(constraints);

  // Generate Polyglot target code files (C++, Python, TypeScript, Rust)
  const polyglotCodes = CodeGenerator.generateAll(constraints, __dirname);

  // Synthesize Automata (NFA -> Subset DFA -> Hopcroft Minimization)
  let automata = null;
  if (AutomataEngine) {
    try {
      const autoRes = AutomataEngine.buildAutomataForPolicy({
        blacklist: constraints.blacklist && constraints.blacklist.length > 0 ? constraints.blacklist : ['password', '123456', 'admin', 'qwerty'],
        maxSequence: constraints.maxSequence > 0 ? constraints.maxSequence : 3,
        maxRepeated: constraints.maxRepeated > 0 ? constraints.maxRepeated : 3
      });

      let sim = null;
      if (testPassword !== null && testPassword !== undefined) {
        sim = autoRes.minDfa.simulate(testPassword);
      }

      automata = {
        metrics: autoRes.metrics,
        transitionTable: autoRes.minDfa.getTransitionTableSample(12),
        simulation: sim,
        cppTableCode: autoRes.minDfa.emitCppTable('MINIMAL_DFA_TABLE')
      };
    } catch (_) {}
  }

  let evaluation = { tested: false, isValid: false, score: 0, level: 'Untested', reasons: [], violations: [], smartAnalysis: null, automataSimulation: null };
  if (testPassword !== null && testPassword !== undefined) {
    let isValid = NeuroSymbolicEvaluator.validate(testPassword, constraints);
    const evalRes = NeuroSymbolicEvaluator.evaluate(testPassword, constraints);
    const violations = NeuroSymbolicEvaluator.getViolations(testPassword, constraints);

    if (evalRes.smartAnalysis && evalRes.smartAnalysis.status === 'REJECTED') {
      violations.push(`[Blocklist/Leetspeak Evasion Alert] ${evalRes.smartAnalysis.reason}`);
      isValid = false;
    }

    if (automata && automata.simulation && automata.simulation.rejected) {
      violations.push(`[Automata DFA Rejection] Pattern matched at step ${automata.simulation.trace.length} on character '${automata.simulation.trace[automata.simulation.trace.length - 1].char}'.`);
      isValid = false;
    }

    evaluation = {
      tested: true,
      isValid,
      score: evalRes.score,
      level: evalRes.level,
      reasons: isValid ? evalRes.reasons : (violations.length > 0 ? violations : evalRes.reasons),
      violations,
      smartAnalysis: evalRes.smartAnalysis,
      automataSimulation: automata ? automata.simulation : null
    };
  }

  return {
    success: true,
    stage: 'complete',
    tokens,
    constraints,
    warnings,
    generated_code_file: 'generated_validator.cpp',
    polyglot_files: {
      cpp: 'generated_validator.cpp',
      python: 'generated_validator.py',
      typescript: 'generated_validator.ts',
      rust: 'generated_validator.rs'
    },
    generated_codes: polyglotCodes,
    evaluation,
    automata,
    ast: {
      rules: prog.rules,
      nodes: buildAstHierarchy(prog.rules),
      nodeCount: prog.rules.length
    },
    ir: {
      constraints,
      instructions: synthesizeTacInstructions(constraints),
      instructionCount: synthesizeTacInstructions(constraints).length
    }
  };
}

module.exports = {
  compilePolicy,
  Lexer,
  Parser,
  SemanticAnalyzer,
  IRAnalyzer,
  CodeGenerator,
  NeuroSymbolicEvaluator,
  buildAstHierarchy,
  synthesizeTacInstructions
};

