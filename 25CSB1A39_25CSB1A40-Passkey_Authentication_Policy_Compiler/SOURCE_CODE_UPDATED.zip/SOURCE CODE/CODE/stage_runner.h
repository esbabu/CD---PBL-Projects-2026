#ifndef STAGE_RUNNER_H
#define STAGE_RUNNER_H

#include <string>
#include "semantic.h"

// Deterministic password validator against compiled policy constraints
bool validatePassword(const std::string& password, const PolicyConstraints& c);

// Runs an isolated stage:
// --stage <lexer|parser|semantic|ir|codegen|test|audit> --in <file> --out <file>
// Reads JSON from inFile, processes stage without shared memory, writes JSON to outFile.
// Returns 0 on success, non-zero on error.
int runStageMode(const std::string& stage, const std::string& inFile, const std::string& outFile);

#endif // STAGE_RUNNER_H
