/**
 * owner_auth_store.js
 * 
 * Manual Owner Authorization Store & Audit Engine for Hardened C++ Code Generation.
 * Provides ACID SQLite persistence, cryptographic token generation, role-based
 * access control, and a tamper-evident audit log.
 * 
 * Security Guarantees:
 * 1. Vaulted Code Storage: Hardened C++ source is stored backend-side and never returned unapproved.
 * 2. Cryptographic Request Tokens: Each requester receives a high-entropy secret bearer token.
 * 3. Authenticated Owner Control: Only the verified project owner can transition status to APPROVED or REJECTED.
 * 4. Isolation: Requester A cannot access Requester B's approved code.
 * 5. Tamper-Evident Audit Chain: Every access, approval, rejection, and unauthorized attempt is cryptographically logged.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Dual SQLite Adapter (matches broker.js pattern)
let Database;
try {
  const BSqlite = require('better-sqlite3');
  const probe = new BSqlite(':memory:');
  probe.close();
  Database = BSqlite;
} catch (e) {
  const { DatabaseSync } = require('node:sqlite');
  Database = DatabaseSync;
}

const DEFAULT_OWNER_SECRET = process.env.OWNER_AUTH_SECRET || 'OwnerSecretKey2026!SecureGate';
const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'owner_auth.db');

function sha256(data) {
  const str = typeof data === 'string' ? data : JSON.stringify(data);
  return crypto.createHash('sha256').update(str).digest('hex');
}

function extractPolicySummary(dslText) {
  if (!dslText || typeof dslText !== 'string') return 'Default Policy';
  const lines = dslText.split('\n')
    .map(l => l.trim())
    .filter(l => l.length > 0 && !l.startsWith('#') && !l.startsWith('//'));
  
  if (lines.length === 0) return 'Empty Policy';
  return lines.slice(0, 4).join(', ') + (lines.length > 4 ? ` (+${lines.length - 4} more rules)` : '');
}

class OwnerAuthStore {
  constructor(dbFilePath = DB_PATH) {
    if (!fs.existsSync(DATA_DIR)) {
      try {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      } catch (_) {}
    }

    this.dbPath = dbFilePath;
    this.db = new Database(dbFilePath);
    this.ownerSessions = new Map(); // sessionToken -> { ownerId, expiresAt }
    this.initTables();
  }

  initTables() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS code_access_requests (
        request_id TEXT PRIMARY KEY,
        requester_id TEXT NOT NULL,
        requester_token TEXT NOT NULL,
        policy_dsl TEXT NOT NULL,
        policy_hash TEXT NOT NULL,
        policy_summary TEXT NOT NULL,
        status TEXT NOT NULL,
        hardened_code TEXT NOT NULL,
        requested_at TEXT NOT NULL,
        reviewed_at TEXT,
        reviewed_by TEXT,
        rejection_reason TEXT,
        access_count INTEGER DEFAULT 0,
        last_accessed_at TEXT
      );
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS access_audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        request_id TEXT,
        ip_address TEXT,
        details TEXT,
        timestamp TEXT NOT NULL,
        prev_hash TEXT,
        record_hash TEXT NOT NULL
      );
    `);
  }

  // --- CRYPTOGRAPHIC AUDIT LOGGING ---
  recordAudit(eventType, actorId, requestId = null, ipAddress = '127.0.0.1', details = {}) {
    const timestamp = new Date().toISOString();
    const detailsStr = typeof details === 'string' ? details : JSON.stringify(details);

    let prevHash = '0000000000000000000000000000000000000000000000000000000000000000';
    try {
      const lastRow = this.db.prepare('SELECT record_hash FROM access_audit_log ORDER BY id DESC LIMIT 1').get();
      if (lastRow && lastRow.record_hash) {
        prevHash = lastRow.record_hash;
      }
    } catch (_) {}

    const recordData = `${prevHash}|${eventType}|${actorId}|${requestId || ''}|${ipAddress}|${detailsStr}|${timestamp}`;
    const recordHash = sha256(recordData);

    const stmt = this.db.prepare(`
      INSERT INTO access_audit_log (event_type, actor_id, request_id, ip_address, details, timestamp, prev_hash, record_hash)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(eventType, actorId, requestId, ipAddress, detailsStr, timestamp, prevHash, recordHash);

    return { recordHash, timestamp };
  }

  getAuditLog(limit = 50) {
    const rows = this.db.prepare('SELECT * FROM access_audit_log ORDER BY id DESC LIMIT ?').all(limit);
    return rows.map(r => ({
      id: r.id,
      eventType: r.event_type,
      actorId: r.actor_id,
      requestId: r.request_id,
      ipAddress: r.ip_address,
      details: (() => { try { return JSON.parse(r.details); } catch (_) { return r.details; } })(),
      timestamp: r.timestamp,
      recordHash: r.record_hash
    }));
  }

  // --- OWNER AUTHENTICATION ---
  validateOwnerSecret(secret) {
    if (!secret || typeof secret !== 'string') return false;
    const expected = process.env.OWNER_AUTH_SECRET || DEFAULT_OWNER_SECRET;
    // Constant-time comparison
    if (secret.length !== expected.length) return false;
    return crypto.timingSafeEqual(Buffer.from(secret, 'utf8'), Buffer.from(expected, 'utf8'));
  }

  createOwnerSession(ownerId = 'Project-Owner') {
    const sessionToken = `owner_sess_${crypto.randomBytes(24).toString('hex')}`;
    const expiresAt = Date.now() + 8 * 60 * 60 * 1000; // 8 hours
    this.ownerSessions.set(sessionToken, { ownerId, expiresAt });
    this.recordAudit('OWNER_SESSION_CREATED', ownerId, null, '127.0.0.1', { sessionTokenPrefix: sessionToken.slice(0, 16) });
    return { sessionToken, expiresAt };
  }

  validateOwnerSession(sessionOrBearerToken) {
    if (!sessionOrBearerToken || typeof sessionOrBearerToken !== 'string') return null;
    const cleanToken = sessionOrBearerToken.replace(/^Bearer\s+/i, '').trim();

    // Check direct secret match (e.g. for API headers or scripts)
    if (this.validateOwnerSecret(cleanToken)) {
      return { ownerId: 'Project-Owner (Secret-Auth)', isDirectSecret: true };
    }

    // Check session token map
    const session = this.ownerSessions.get(cleanToken);
    if (session) {
      if (Date.now() > session.expiresAt) {
        this.ownerSessions.delete(cleanToken);
        return null;
      }
      return { ownerId: session.ownerId, isDirectSecret: false };
    }

    return null;
  }

  // --- ACCESS REQUEST MANAGEMENT ---
  createRequest({ requesterId, policyDsl, hardenedCode, clientIp = '127.0.0.1', reason = '' }) {
    if (!requesterId || typeof requesterId !== 'string') {
      throw new Error('Requester identity is required.');
    }
    if (!hardenedCode || typeof hardenedCode !== 'string') {
      throw new Error('Hardened C++ code payload is required for vaulted storage.');
    }

    const cleanDsl = (policyDsl && typeof policyDsl === 'string') ? policyDsl : '';
    const policyHash = sha256(cleanDsl);
    const policySummary = extractPolicySummary(cleanDsl);
    const requestId = `req_${Date.now()}_${crypto.randomBytes(6).toString('hex')}`;
    const requesterToken = `token_${crypto.randomBytes(32).toString('hex')}`;
    const requestedAt = new Date().toISOString();
    const status = 'PENDING';

    const stmt = this.db.prepare(`
      INSERT INTO code_access_requests (
        request_id, requester_id, requester_token, policy_dsl, policy_hash,
        policy_summary, status, hardened_code, requested_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      requestId,
      requesterId.trim(),
      requesterToken,
      cleanDsl,
      policyHash,
      policySummary,
      status,
      hardenedCode,
      requestedAt
    );

    this.recordAudit('ACCESS_REQUESTED', requesterId, requestId, clientIp, {
      policySummary,
      policyHash: policyHash.substring(0, 12),
      reason: reason || 'Access to hardened C++ code requested'
    });

    return {
      requestId,
      requesterToken,
      requesterId: requesterId.trim(),
      status,
      requestedAt,
      policySummary,
      policyHash
    };
  }

  getRequest(requestId) {
    return this.db.prepare('SELECT * FROM code_access_requests WHERE request_id = ?').get(requestId);
  }

  getRequestStatus(requestId, requesterToken = null) {
    const row = this.getRequest(requestId);
    if (!row) return null;

    // If requester token is provided, verify it matches
    const tokenMatches = requesterToken ? row.requester_token === requesterToken : null;

    return {
      requestId: row.request_id,
      requesterId: row.requester_id,
      status: row.status,
      requestedAt: row.requested_at,
      policySummary: row.policy_summary,
      policyHash: row.policy_hash,
      reviewedAt: row.reviewed_at,
      reviewedBy: row.reviewed_by,
      rejectionReason: row.rejection_reason,
      tokenMatches
    };
  }

  approveRequest(requestId, ownerId = 'Project-Owner', clientIp = '127.0.0.1') {
    const row = this.getRequest(requestId);
    if (!row) {
      throw new Error(`Request not found: ${requestId}`);
    }

    const reviewedAt = new Date().toISOString();
    const stmt = this.db.prepare(`
      UPDATE code_access_requests
      SET status = 'APPROVED', reviewed_at = ?, reviewed_by = ?, rejection_reason = NULL
      WHERE request_id = ?
    `);
    stmt.run(reviewedAt, ownerId, requestId);

    this.recordAudit('REQUEST_APPROVED', ownerId, requestId, clientIp, {
      requesterId: row.requester_id,
      policyHash: row.policy_hash.substring(0, 12)
    });

    return {
      requestId,
      status: 'APPROVED',
      reviewedAt,
      reviewedBy: ownerId
    };
  }

  rejectRequest(requestId, ownerId = 'Project-Owner', rejectionReason = 'Access request rejected by project owner.', clientIp = '127.0.0.1') {
    const row = this.getRequest(requestId);
    if (!row) {
      throw new Error(`Request not found: ${requestId}`);
    }

    const reviewedAt = new Date().toISOString();
    const stmt = this.db.prepare(`
      UPDATE code_access_requests
      SET status = 'REJECTED', reviewed_at = ?, reviewed_by = ?, rejection_reason = ?
      WHERE request_id = ?
    `);
    stmt.run(reviewedAt, ownerId, rejectionReason, requestId);

    this.recordAudit('REQUEST_REJECTED', ownerId, requestId, clientIp, {
      requesterId: row.requester_id,
      rejectionReason
    });

    return {
      requestId,
      status: 'REJECTED',
      reviewedAt,
      reviewedBy: ownerId,
      rejectionReason
    };
  }

  verifyRequesterAccess(requestId, requesterToken, clientIp = '127.0.0.1') {
    const row = this.getRequest(requestId);
    if (!row) {
      this.recordAudit('UNAUTHORIZED_ACCESS_ATTEMPT', 'UNKNOWN_REQUEST', requestId, clientIp, {
        reason: 'Request ID does not exist'
      });
      return { ok: false, error: 'Request not found.', code: 'NOT_FOUND', status: 404, statusCode: 404 };
    }

    // Check token match
    if (!requesterToken || row.requester_token !== requesterToken) {
      this.recordAudit('UNAUTHORIZED_ACCESS_ATTEMPT', row.requester_id, requestId, clientIp, {
        reason: 'Invalid or missing requester token'
      });
      return { ok: false, error: 'Unauthorized: Invalid requester token for this code release.', code: 'UNAUTHORIZED_TOKEN', status: 401, statusCode: 401 };
    }

    // Check status
    if (row.status === 'PENDING') {
      this.recordAudit('ACCESS_DENIED_PENDING', row.requester_id, requestId, clientIp, {
        status: 'PENDING'
      });
      return {
        ok: false,
        error: 'Your request for hardened C++ code has been sent to the project owner. Access will be granted only after manual approval.',
        status: 'PENDING',
        statusCode: 403
      };
    }

    if (row.status === 'REJECTED') {
      this.recordAudit('ACCESS_DENIED_REJECTED', row.requester_id, requestId, clientIp, {
        status: 'REJECTED',
        rejectionReason: row.rejection_reason
      });
      return {
        ok: false,
        error: `Access Denied: Your request for hardened C++ code was rejected by the project owner.${row.rejection_reason ? ' Reason: ' + row.rejection_reason : ''}`,
        status: 'REJECTED',
        rejectionReason: row.rejection_reason,
        statusCode: 403
      };
    }

    if (row.status === 'APPROVED') {
      // Access granted: update access count
      const now = new Date().toISOString();
      this.db.prepare(`
        UPDATE code_access_requests 
        SET access_count = access_count + 1, last_accessed_at = ?
        WHERE request_id = ?
      `).run(now, requestId);

      this.recordAudit('CODE_ACCESSED', row.requester_id, requestId, clientIp, {
        accessCount: (row.access_count || 0) + 1,
        codeLength: row.hardened_code.length
      });

      return {
        ok: true,
        status: 'APPROVED',
        code: row.hardened_code,
        requesterId: row.requester_id,
        policySummary: row.policy_summary,
        policyHash: row.policy_hash,
        reviewedBy: row.reviewed_by,
        reviewedAt: row.reviewed_at
      };
    }

    return { ok: false, error: 'Unknown request status.', statusCode: 400 };
  }

  getAllRequestsGrouped() {
    const rows = this.db.prepare(`
      SELECT request_id, requester_id, policy_summary, policy_hash, status, requested_at, reviewed_at, reviewed_by, rejection_reason, access_count, last_accessed_at
      FROM code_access_requests
      ORDER BY requested_at DESC
    `).all();

    const grouped = {
      pending: [],
      approved: [],
      rejected: []
    };

    for (const r of rows) {
      const item = {
        requestId: r.request_id,
        requesterId: r.requester_id,
        policySummary: r.policy_summary,
        policyHash: r.policy_hash,
        status: r.status,
        requestedAt: r.requested_at,
        reviewedAt: r.reviewed_at,
        reviewedBy: r.reviewed_by,
        rejectionReason: r.rejection_reason,
        accessCount: r.access_count,
        lastAccessedAt: r.last_accessed_at
      };

      if (r.status === 'PENDING') grouped.pending.push(item);
      else if (r.status === 'APPROVED') grouped.approved.push(item);
      else if (r.status === 'REJECTED') grouped.rejected.push(item);
    }

    return grouped;
  }
}

const defaultStore = new OwnerAuthStore();

module.exports = {
  OwnerAuthStore,
  defaultStore,
  DEFAULT_OWNER_SECRET
};
