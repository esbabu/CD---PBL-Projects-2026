#!/usr/bin/env node
/**
 * policy_compiler.js
 * 
 * Unified CLI entrypoint for Policy Compiler.
 * Supports:
 *   1. Stage Mode:
 *      policy_compiler --stage <lexer|parser|semantic|ir|codegen|test|audit> --in <file> --out <file>
 *   2. Legacy Mode:
 *      policy_compiler <policyfile> [--password <pwd>] [--check] [--json]
 */

const fs = require('fs');
const path = require('path');
const { executeStage } = require('./stage_runner');
const { compilePolicy } = require('./compiler_engine');

function printUsage() {
  console.log('Usage:');
  console.log('  Stage Mode:  policy_compiler --stage <lexer|parser|semantic|ir|codegen|test|audit> --in <file> --out <file>');
  console.log('  Legacy Mode: policy_compiler <policyfile> [--password <pwd>] [--check] [--json]');
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    printUsage();
    process.exit(0);
  }

  // Check for Benchmark Simulation
  if (args.includes('--simulate-attacks')) {
    const { runAllBenchmarkScenarios } = require('./agent_telemetry_engine');
    const res = runAllBenchmarkScenarios();
    console.log('================================================================================');
    console.log('🛡️  55-SCENARIO ADVERSARIAL ATTACK BENCHMARK & EVALUATION REPORT');
    console.log('================================================================================');
    console.log(`Total Attacks Evaluated : ${res.totalScenarios}`);
    console.log(`True Positives (Blocked): ${res.confusionMatrix.truePositives}`);
    console.log(`False Positives         : ${res.confusionMatrix.falsePositives}`);
    console.log(`True Negatives (Benign) : ${res.confusionMatrix.trueNegatives}`);
    console.log(`False Negatives         : ${res.confusionMatrix.falseNegatives}`);
    console.log(`Model Accuracy          : ${res.accuracy}`);
    console.log(`Mean Evaluation Latency : ${res.meanLatencyMs} ms`);
    console.log('================================================================================');
    process.exit(0);
  }

  // Check for Stage Mode
  let stage = null;
  let inFile = null;
  let outFile = null;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--stage' && i + 1 < args.length) {
      stage = args[++i];
    } else if (args[i] === '--in' && i + 1 < args.length) {
      inFile = args[++i];
    } else if (args[i] === '--out' && i + 1 < args.length) {
      outFile = args[++i];
    }
  }

  if (stage) {
    if (!inFile || !outFile) {
      console.error('Error: Stage mode requires --stage <stage> --in <file> --out <file>');
      process.exit(1);
    }
    const exitCode = executeStage(stage, inFile, outFile);
    process.exit(exitCode);
  }

  // Legacy Mode
  const policyFile = args[0];
  const jsonOutput = args.includes('--json');
  let cliPassword = null;
  const pwdIdx = args.indexOf('--password');
  if (pwdIdx !== -1 && pwdIdx + 1 < args.length) {
    cliPassword = args[pwdIdx + 1];
  }

  if (!fs.existsSync(policyFile)) {
    if (jsonOutput) {
      console.log(JSON.stringify({
        success: false,
        stage: 'io',
        errors: [{ message: `Cannot open file: ${policyFile}`, line: 0, col: 0 }]
      }, null, 2));
    } else {
      console.error(`Error: cannot open file: ${policyFile}`);
    }
    process.exit(1);
  }

  const dslText = fs.readFileSync(policyFile, 'utf8');
  const res = compilePolicy(dslText, cliPassword);

  if (jsonOutput) {
    console.log(JSON.stringify(res, null, 2));
  } else {
    if (res.success) {
      console.log('Policy Compiled Successfully!');
      console.log('Final Policy Constraints:', res.constraints);
    } else {
      console.error('Compilation failed with errors:', res.errors);
    }
  }
  process.exit(res.success ? 0 : 1);
}

if (require.main === module) {
  main();
}
