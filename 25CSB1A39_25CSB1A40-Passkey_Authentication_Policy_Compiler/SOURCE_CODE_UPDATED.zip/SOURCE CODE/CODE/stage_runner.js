/**
 * stage_runner.js
 * 
 * Standalone Stage Runner for Policy Compiler.
 * Executes any of the 7 decoupled stages:
 *   lexer | parser | semantic | ir | codegen | test | audit
 * 
 * Zero shared memory between stages. Reads JSON from inFile, writes JSON to outFile, exits.
 */

const fs = require('fs');
const path = require('path');
const {
  Lexer,
  Parser,
  SemanticAnalyzer,
  IRAnalyzer,
  CodeGenerator,
  NeuroSymbolicEvaluator
} = require('./compiler_engine');

function readJsonFile(filePath) {
  try {
    let raw = fs.readFileSync(filePath, 'utf8');
    if (raw.charCodeAt(0) === 0xFEFF) {
      raw = raw.slice(1);
    }
    return { ok: true, data: JSON.parse(raw) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

function writeJsonFile(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    return false;
  }
}

function extractDslInput(data) {
  return data.input || data.source || data.policy || data.code || '';
}

// ---------------------------------------------------------------------------
// STAGE 1: LEXER
// ---------------------------------------------------------------------------
function runLexer(inJson) {
  const dsl = extractDslInput(inJson);
  if (!dsl && !inJson.input && !inJson.source && !inJson.policy) {
    return {
      exitCode: 1,
      output: {
        success: false,
        stage: 'lexer',
        tokenCount: 0,
        tokens: [],
        errors: [{ message: "Missing 'input' field in JSON payload for lexer stage", line: 0, col: 0 }]
      }
    };
  }

  const lexer = new Lexer(dsl);
  const tokens = lexer.tokenize();

  if (lexer.errs && lexer.errs.length > 0) {
    return {
      exitCode: 1,
      output: {
        success: false,
        stage: 'lexer',
        tokenCount: 0,
        tokens: [],
        errors: lexer.errs.map(e => ({ message: e.message, line: e.line || 0, col: e.col || 0 }))
      }
    };
  }

  return {
    exitCode: 0,
    output: {
      success: true,
      stage: 'lexer',
      tokenCount: tokens.length,
      tokens: tokens.map(t => ({
        type: t.type,
        lexeme: t.lexeme,
        line: t.line,
        col: t.col
      })),
      errors: []
    }
  };
}

// ---------------------------------------------------------------------------
// STAGE 2: PARSER
// ---------------------------------------------------------------------------
function runParser(inJson) {
  let tokens = [];

  if (Array.isArray(inJson.tokens)) {
    tokens = inJson.tokens.map(t => ({
      type: t.type,
      lexeme: t.lexeme,
      line: t.line || 1,
      col: t.col || 1
    }));
    if (tokens.length === 0 || tokens[tokens.length - 1].type !== 'End') {
      tokens.push({ type: 'End', lexeme: 'EOF', line: 1, col: 1 });
    }
  } else {
    const dsl = extractDslInput(inJson);
    if (!dsl && !inJson.input) {
      return {
        exitCode: 1,
        output: {
          success: false,
          stage: 'parser',
          ruleCount: 0,
          ast: { rules: [] },
          errors: [{ message: "Missing 'tokens' or 'input' in JSON payload for parser stage", line: 0, col: 0 }]
        }
      };
    }
    const lexer = new Lexer(dsl);
    tokens = lexer.tokenize();
    if (lexer.errs && lexer.errs.length > 0) {
      return {
        exitCode: 1,
        output: {
          success: false,
          stage: 'parser',
          ruleCount: 0,
          ast: { rules: [] },
          errors: lexer.errs.map(e => ({ message: e.message, line: e.line || 0, col: e.col || 0 }))
        }
      };
    }
  }

  const parser = new Parser(tokens);
  const prog = parser.parse();

  if (parser.errs && parser.errs.length > 0) {
    return {
      exitCode: 1,
      output: {
        success: false,
        stage: 'parser',
        ruleCount: 0,
        ast: { rules: [] },
        errors: parser.errs.map(e => ({ message: e.message, line: e.line || 0, col: e.col || 0 }))
      }
    };
  }

  const rules = (prog && prog.rules) ? prog.rules : [];
  return {
    exitCode: 0,
    output: {
      success: true,
      stage: 'parser',
      ruleCount: rules.length,
      ast: {
        rules: rules.map(r => ({
          name: r.name,
          value: String(r.value),
          line: r.pos ? r.pos.line : (r.line || 1),
          col: r.pos ? r.pos.col : (r.col || 1)
        }))
      },
      errors: []
    }
  };
}

// ---------------------------------------------------------------------------
// STAGE 3: SEMANTIC
// ---------------------------------------------------------------------------
function runSemantic(inJson) {
  let prog = { rules: [] };

  if (inJson.ast && Array.isArray(inJson.ast.rules)) {
    prog.rules = inJson.ast.rules.map(r => ({
      name: r.name,
      value: r.value,
      pos: { line: r.line || 1, col: r.col || 1 }
    }));
  } else if (Array.isArray(inJson.rules)) {
    prog.rules = inJson.rules.map(r => ({
      name: r.name,
      value: r.value,
      pos: { line: r.line || 1, col: r.col || 1 }
    }));
  } else {
    // Fallback through parser
    const parseRes = runParser(inJson);
    if (parseRes.exitCode !== 0 || !parseRes.output.success) {
      parseRes.output.stage = 'semantic';
      return parseRes;
    }
    prog.rules = parseRes.output.ast.rules.map(r => ({
      name: r.name,
      value: r.value,
      pos: { line: r.line || 1, col: r.col || 1 }
    }));
  }

  const sem = new SemanticAnalyzer();
  sem.analyze(prog);

  if (sem.errs && sem.errs.length > 0) {
    return {
      exitCode: 1,
      output: {
        success: false,
        stage: 'semantic',
        constraints: {},
        errors: sem.errs.map(e => ({ message: e.message, line: e.line || 0, col: e.col || 0 }))
      }
    };
  }

  const c = sem.constraints || {};
  return {
    exitCode: 0,
    output: {
      success: true,
      stage: 'semantic',
      constraints: {
        minLength: c.minLength !== undefined ? c.minLength : -1,
        maxLength: c.maxLength !== undefined ? c.maxLength : -1,
        requireUpper: c.requireUpper !== undefined ? c.requireUpper : -1,
        requireLower: c.requireLower !== undefined ? c.requireLower : -1,
        requireDigit: c.requireDigit !== undefined ? c.requireDigit : -1,
        requireSpecial: c.requireSpecial !== undefined ? c.requireSpecial : -1,
        noSpaces: c.noSpaces !== undefined ? c.noSpaces : -1
      },
      errors: []
    }
  };
}

// ---------------------------------------------------------------------------
// Helper: Resolve PolicyConstraints
// ---------------------------------------------------------------------------
function resolveConstraints(inJson) {
  if (inJson.constraints && typeof inJson.constraints === 'object') {
    const c = inJson.constraints;
    return {
      ok: true,
      constraints: {
        minLength: c.minLength !== undefined ? c.minLength : -1,
        maxLength: c.maxLength !== undefined ? c.maxLength : -1,
        requireUpper: c.requireUpper !== undefined ? c.requireUpper : -1,
        requireLower: c.requireLower !== undefined ? c.requireLower : -1,
        requireDigit: c.requireDigit !== undefined ? c.requireDigit : -1,
        requireSpecial: c.requireSpecial !== undefined ? c.requireSpecial : -1,
        noSpaces: c.noSpaces !== undefined ? c.noSpaces : -1
      }
    };
  }

  const semRes = runSemantic(inJson);
  if (semRes.exitCode !== 0 || !semRes.output.success) {
    return { ok: false, errorRes: semRes };
  }
  return { ok: true, constraints: semRes.output.constraints };
}

// ---------------------------------------------------------------------------
// STAGE 4: IR
// ---------------------------------------------------------------------------
function runIR(inJson) {
  const resolved = resolveConstraints(inJson);
  if (!resolved.ok) {
    resolved.errorRes.output.stage = 'ir';
    return resolved.errorRes;
  }
  const c = resolved.constraints;
  const warnings = IRAnalyzer.analyze(c);

  const ir = {
    minLength: c.minLength,
    maxLength: c.maxLength,
    requireUpper: c.requireUpper === 1,
    requireLower: c.requireLower === 1,
    requireDigit: c.requireDigit === 1,
    requireSpecial: c.requireSpecial === 1,
    noSpaces: c.noSpaces === 1
  };

  return {
    exitCode: 0,
    output: {
      success: true,
      stage: 'ir',
      constraints: c,
      ir: ir,
      warnings: warnings,
      errors: []
    }
  };
}

// ---------------------------------------------------------------------------
// STAGE 5: CODEGEN
// ---------------------------------------------------------------------------
function runCodegen(inJson) {
  const resolved = resolveConstraints(inJson);
  if (!resolved.ok) {
    resolved.errorRes.output.stage = 'codegen';
    return resolved.errorRes;
  }
  const c = resolved.constraints;
  const target = inJson.target || 'cpp';
  const outFile = inJson.outputFile || (target === 'python' ? 'generated_validator.py' :
                                      target === 'typescript' ? 'generated_validator.ts' :
                                      target === 'rust' ? 'generated_validator.rs' : 'generated_validator.cpp');

  let code = '';
  if (target === 'python') {
    code = CodeGenerator.generatePython(c, outFile);
  } else if (target === 'typescript') {
    code = CodeGenerator.generateTypeScript(c, outFile);
  } else if (target === 'rust') {
    code = CodeGenerator.generateRust(c, outFile);
  } else {
    code = CodeGenerator.generateCpp(c, outFile);
  }

  return {
    exitCode: 0,
    output: {
      success: true,
      stage: 'codegen',
      target: target,
      outputFile: outFile,
      codeLength: code.length,
      code: code,
      constraints: c,
      errors: []
    }
  };
}

// ---------------------------------------------------------------------------
// STAGE 6: TEST
// ---------------------------------------------------------------------------
function runTest(inJson) {
  const resolved = resolveConstraints(inJson);
  if (!resolved.ok) {
    resolved.errorRes.output.stage = 'test';
    return resolved.errorRes;
  }
  const c = resolved.constraints;

  let testPasswords = [];
  if (typeof inJson.password === 'string') {
    testPasswords.push(inJson.password);
  } else if (Array.isArray(inJson.passwords)) {
    testPasswords = inJson.passwords.map(String);
  } else if (Array.isArray(inJson.testVectors)) {
    testPasswords = inJson.testVectors.map(v => typeof v === 'string' ? v : v.password);
  }

  if (testPasswords.length === 0) {
    testPasswords = [
      'CorrectHorseBatteryStaple99!',
      'short1!',
      'alllowercaseletters123!',
      'NOLOWERCASEHERE1234!',
      'NoDigitsAllowedHere!!',
      'Password With Spaces 123!'
    ];
  }

  const results = [];
  let validCount = 0;

  for (const pwd of testPasswords) {
    const isValid = NeuroSymbolicEvaluator.validate(pwd, c);
    const ns = NeuroSymbolicEvaluator.evaluate(pwd, c);

    if (isValid) validCount++;

    results.push({
      password: pwd,
      isValid: isValid,
      score: ns.score,
      level: ns.level,
      reasons: ns.reasons || []
    });
  }

  return {
    exitCode: 0,
    output: {
      success: true,
      stage: 'test',
      constraints: c,
      totalTested: testPasswords.length,
      validCount: validCount,
      allPassed: validCount > 0,
      results: results,
      errors: []
    }
  };
}

// ---------------------------------------------------------------------------
// STAGE 7: AUDIT
// ---------------------------------------------------------------------------
function runAudit(inJson) {
  const resolved = resolveConstraints(inJson);
  if (!resolved.ok) {
    resolved.errorRes.output.stage = 'audit';
    return resolved.errorRes;
  }
  const c = resolved.constraints;

  // Contradiction Check
  if (c.minLength !== -1 && c.maxLength !== -1 && c.minLength > c.maxLength) {
    return {
      exitCode: 1,
      output: {
        success: false,
        stage: 'audit',
        nistCompliant: false,
        score: 0,
        riskLevel: 'CRITICAL',
        errors: [{
          message: `Contradictory policy constraints: minLength (${c.minLength}) exceeds maxLength (${c.maxLength})`,
          line: 0,
          col: 0
        }]
      }
    };
  }

  let score = 100;
  let nistCompliant = true;
  const findings = [];
  const recommendations = [];

  // Min length
  if (c.minLength === -1) {
    score -= 40;
    nistCompliant = false;
    findings.push('CRITICAL: No minimum length specified. NIST SP 800-63B requires at least 8 characters.');
    recommendations.push('Enforce a minimum length of at least 8 characters (15+ recommended).');
  } else if (c.minLength < 8) {
    score -= 40;
    nistCompliant = false;
    findings.push(`CRITICAL: Minimum length (${c.minLength}) is under the 8-character floor required by NIST SP 800-63B Section 5.1.1.2.`);
    recommendations.push('Increase minimum length to >= 8 characters.');
  } else if (c.minLength < 15) {
    score -= 5;
    findings.push(`PASS: Minimum length (${c.minLength}) satisfies NIST baseline.`);
    recommendations.push('Consider increasing to 15+ characters to facilitate long passphrase defense.');
  } else {
    findings.push(`EXCELLENT: Minimum length (${c.minLength}) satisfies NIST passphrase recommendations.`);
  }

  // Max length
  if (c.maxLength !== -1 && c.maxLength < 64) {
    score -= 15;
    findings.push(`WARN: Maximum length (${c.maxLength}) is below NIST SP 800-63B recommendation of at least 64 characters.`);
    recommendations.push('Allow passwords of at least 64 characters to avoid truncating passphrases.');
  } else {
    findings.push('PASS: Maximum length permits resilient multi-word passphrases.');
  }

  // Composition rules
  let compositionCount = 0;
  if (c.requireUpper === 1) compositionCount++;
  if (c.requireLower === 1) compositionCount++;
  if (c.requireDigit === 1) compositionCount++;
  if (c.requireSpecial === 1) compositionCount++;

  if (compositionCount >= 3) {
    findings.push(`INFO: Multiple mandatory composition rules enforced (${compositionCount} rules). NIST SP 800-63B notes that strict composition rules lead to predictable human substitutions rather than genuine entropy.`);
    recommendations.push('Emphasize length and breach blocklisting over rigid composition requirements.');
  }

  if (c.noSpaces === 1) {
    score -= 5;
    findings.push('WARN: Space characters are prohibited. NIST recommends allowing space characters.');
    recommendations.push('Allow spaces to encourage natural multi-word passphrases.');
  }

  // Entropy lower bound
  let poolSize = 26;
  if (c.requireUpper !== 0) poolSize += 26;
  if (c.requireDigit !== 0) poolSize += 10;
  if (c.requireSpecial !== 0) poolSize += 32;
  if (c.noSpaces === 0) poolSize += 1;

  const effMin = c.minLength > 0 ? c.minLength : 8;
  const entropyLowerBound = Math.round(effMin * (Math.log2(poolSize)) * 10) / 10;

  let riskLevel = 'LOW';
  if (score < 50) riskLevel = 'CRITICAL';
  else if (score < 70) riskLevel = 'HIGH';
  else if (score < 85) riskLevel = 'MEDIUM';

  const output = {
    success: true,
    stage: 'audit',
    nistCompliant: nistCompliant,
    score: score,
    riskLevel: riskLevel,
    entropyLowerBound: entropyLowerBound,
    findings: findings,
    recommendations: recommendations,
    errors: []
  };

  if (inJson.password) {
    const isValid = NeuroSymbolicEvaluator.validate(inJson.password, c);
    const ns = NeuroSymbolicEvaluator.evaluate(inJson.password, c);
    output.passwordAudit = {
      candidatePassword: inJson.password,
      meetsPolicy: isValid,
      strengthScore: ns.score,
      tier: ns.level
    };
  }

  return { exitCode: 0, output: output };
}

// ---------------------------------------------------------------------------
// MAIN EXECUTE STAGE FUNCTION
// ---------------------------------------------------------------------------
function executeStage(stage, inFile, outFile) {
  const readRes = readJsonFile(inFile);
  if (!readRes.ok) {
    const errPayload = {
      success: false,
      stage: stage,
      errors: [{ message: `Cannot read or parse JSON from '${inFile}': ${readRes.error}`, line: 0, col: 0 }]
    };
    writeJsonFile(outFile, errPayload);
    return 1;
  }

  const inJson = readRes.data;
  let stageRes;

  switch (stage.toLowerCase()) {
    case 'lexer':
      stageRes = runLexer(inJson);
      break;
    case 'parser':
      stageRes = runParser(inJson);
      break;
    case 'semantic':
      stageRes = runSemantic(inJson);
      break;
    case 'ir':
      stageRes = runIR(inJson);
      break;
    case 'codegen':
      stageRes = runCodegen(inJson);
      break;
    case 'test':
      stageRes = runTest(inJson);
      break;
    case 'audit':
      stageRes = runAudit(inJson);
      break;
    default:
      stageRes = {
        exitCode: 1,
        output: {
          success: false,
          stage: stage,
          errors: [{ message: `Unknown compilation stage: '${stage}'. Allowed: lexer, parser, semantic, ir, codegen, test, audit`, line: 0, col: 0 }]
        }
      };
      break;
  }

  writeJsonFile(outFile, stageRes.output);
  return stageRes.exitCode;
}

module.exports = {
  executeStage,
  runLexer,
  runParser,
  runSemantic,
  runIR,
  runCodegen,
  runTest,
  runAudit
};
