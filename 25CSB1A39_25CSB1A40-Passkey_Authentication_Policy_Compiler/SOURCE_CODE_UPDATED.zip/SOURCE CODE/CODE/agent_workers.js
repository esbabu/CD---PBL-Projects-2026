/**
 * agent_workers.js
 * 
 * Cryptographically Isolated Agent Workers.
 * Each worker possesses its own Ed25519 keypair and single assigned permission:
 * - lexer:    emit tokens only (EMIT_TOKENS)
 * - parser:   emit AST only (EMIT_AST)
 * - semantic: verify semantics only (VERIFY_SEMANTICS)
 * - ir:       optimize IR only (OPTIMIZE_IR)
 * - codegen:  emit validator only (EMIT_VALIDATOR)
 * - test:     run tests only (RUN_TESTS)
 * - audit:    approve or reject only (SECURITY_AUDIT)
 * 
 * Agents hold private keys locally; only public keys are shared with the broker.
 */

const {
  generateKeypair,
  createEnvelope,
  verifyEnvelope,
  sha256,
  PERMITTED_ACTIONS
} = require('./crypto_utils');

const {
  runLexer,
  runParser,
  runSemantic,
  runIR,
  runCodegen,
  runTest,
  runAudit
} = require('./stage_runner');

class AgentWorker {
  constructor(stage, agentId, brokerPublicKey) {
    this.stage = stage;
    this.agentId = agentId || `agent_${stage}`;
    this.permittedAction = PERMITTED_ACTIONS[stage];
    if (!this.permittedAction) {
      throw new Error(`Unknown stage '${stage}': no permitted action defined`);
    }

    // Agent's private keypair (held securely inside agent memory)
    this.keypair = generateKeypair();
    this.publicKey = this.keypair.publicKey;
    this._privateKey = this.keypair.privateKey;

    this.brokerPublicKey = brokerPublicKey;
    this.seenNonces = new Set();
    this.currentFencingToken = null;
    this.heartbeatTimer = null;
    this.isAlive = true;
    this.mutator = null;
  }

  getPublicKey() {
    return this.publicKey;
  }

  /**
   * Sets a mutator hook to alter output payloads (used for fault injection & divergence testing).
   */
  setMutator(fn) {
    this.mutator = fn;
  }

  /**
   * Clears any active mutator hook.
   */
  clearMutator() {
    this.mutator = null;
  }

  /**
   * Acquires a lease from the broker for this agent.
   */
  acquireLease(broker, jobId, ttlMs = 5000) {
    const lease = broker.acquireLease(jobId, this.stage, this.agentId, ttlMs);
    this.currentFencingToken = lease.token;
    return lease;
  }

  /**
   * Starts sending periodic heartbeats to maintain the lease.
   */
  startHeartbeat(broker, jobId, intervalMs = 1000, extensionMs = 3000) {
    this.stopHeartbeat();
    if (!this.isAlive) {
      throw new Error(`Worker '${this.agentId}' is inactive/crashed; cannot start heartbeats`);
    }
    this.heartbeatTimer = setInterval(() => {
      if (!this.isAlive) {
        this.stopHeartbeat();
        return;
      }
      try {
        broker.heartbeat(jobId, this.stage, this.agentId, this.currentFencingToken, extensionMs);
      } catch (_) {
        this.stopHeartbeat();
      }
    }, intervalMs);
    if (this.heartbeatTimer && typeof this.heartbeatTimer.unref === 'function') {
      this.heartbeatTimer.unref();
    }
  }

  /**
   * Stops sending heartbeats (simulating a freeze or failure).
   */
  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  /**
   * Simulates worker crash/freeze.
   */
  simulateCrash() {
    this.isAlive = false;
    this.stopHeartbeat();
  }

  /**
   * Simulates worker recovery/wakeup (e.g., zombie worker awakening).
   */
  simulateWakeup() {
    this.isAlive = true;
  }

  /**
   * Processes a task envelope received from the broker.
   * Performs full zero-trust validation before executing stage work.
   */
  processTaskEnvelope(taskEnvelope) {
    // 1. Signature Verification
    if (this.brokerPublicKey) {
      const sigRes = verifyEnvelope(taskEnvelope, this.brokerPublicKey);
      if (!sigRes.valid) {
        throw new Error(`[${this.agentId}] Broker signature verification failed: ${sigRes.reason}`);
      }
    }

    // 2. Deadline Check
    if (Date.now() > taskEnvelope.deadline) {
      throw new Error(`[${this.agentId}] Task rejected: deadline expired at ${new Date(taskEnvelope.deadline).toISOString()}`);
    }

    // 3. Nonce Check (Replay Prevention)
    if (this.seenNonces.has(taskEnvelope.nonce)) {
      throw new Error(`[${this.agentId}] Task rejected: reused nonce '${taskEnvelope.nonce}'`);
    }
    this.seenNonces.add(taskEnvelope.nonce);

    // 4. Input Hash Verification
    if (taskEnvelope.payload) {
      const computedHash = sha256(taskEnvelope.payload);
      if (computedHash !== taskEnvelope.inputHash) {
        throw new Error(`[${this.agentId}] Task rejected: input hash mismatch (computed '${computedHash}' != header '${taskEnvelope.inputHash}')`);
      }
    }

    // 5. Permission Enforcement
    if (taskEnvelope.permittedAction !== this.permittedAction) {
      throw new Error(`[${this.agentId}] Permission Denied: attempted action '${taskEnvelope.permittedAction}' is outside permitted capability '${this.permittedAction}'`);
    }

    // 6. Track Fencing Token
    if (taskEnvelope.fencingToken !== undefined && taskEnvelope.fencingToken !== null) {
      this.currentFencingToken = taskEnvelope.fencingToken;
    }

    // Demo Pace Delay Hook: sleep before running stage if DEMO_STAGE_DELAY_MS is set
    const demoDelay = parseInt(process.env.DEMO_STAGE_DELAY_MS || '0', 10);
    if (demoDelay > 0) {
      const end = Date.now() + demoDelay;
      while (Date.now() < end) {}
    }

    // 7. Stage-Specific Execution
    const inputPayload = taskEnvelope.payload;
    let stageResult;

    switch (this.stage) {
      case 'lexer':
        stageResult = runLexer(inputPayload);
        break;
      case 'parser':
        stageResult = runParser(inputPayload);
        break;
      case 'semantic':
        stageResult = runSemantic(inputPayload);
        break;
      case 'ir':
        stageResult = runIR(inputPayload);
        break;
      case 'codegen':
        stageResult = runCodegen(inputPayload);
        break;
      case 'test':
        stageResult = runTest(inputPayload);
        break;
      case 'audit':
        stageResult = runAudit(inputPayload);
        break;
      default:
        throw new Error(`Unsupported agent stage '${this.stage}'`);
    }

    // 8. Emit Signed Response Envelope
    let outputPayload = stageResult.output;
    if (typeof this.mutator === 'function') {
      outputPayload = this.mutator(outputPayload);
    }
    const outputHash = sha256(outputPayload);

    const responseEnvelope = createEnvelope({
      jobId: taskEnvelope.jobId,
      stage: this.stage,
      inputHash: taskEnvelope.inputHash,
      deadline: Date.now() + 30000,
      permittedAction: this.permittedAction,
      payload: outputPayload,
      privateKey: this._privateKey,
      senderId: this.agentId,
      fencingToken: this.currentFencingToken
    });

    responseEnvelope.outputHash = outputHash;
    responseEnvelope.exitCode = stageResult.exitCode;
    return responseEnvelope;
  }
}

/**
 * Factory creating all 7 standard pipeline agents.
 */
function createPipelineAgents(brokerPublicKey) {
  return {
    lexer: new AgentWorker('lexer', 'agent-01-lexer', brokerPublicKey),
    parser: new AgentWorker('parser', 'agent-02-parser', brokerPublicKey),
    semantic: new AgentWorker('semantic', 'agent-03-semantic', brokerPublicKey),
    ir: new AgentWorker('ir', 'agent-04-ir', brokerPublicKey),
    codegen: new AgentWorker('codegen', 'agent-05-codegen', brokerPublicKey),
    test: new AgentWorker('test', 'agent-06-test', brokerPublicKey),
    audit: new AgentWorker('audit', 'agent-07-audit', brokerPublicKey)
  };
}

/**
 * Factory creating a standby worker for a specific stage.
 */
function createStandbyWorker(stage, brokerPublicKey, workerSuffix = 'standby') {
  return new AgentWorker(stage, `agent-${stage}-${workerSuffix}`, brokerPublicKey);
}

/**
 * Factory creating two redundant codegen workers for dual-codegen verification.
 */
function createDualCodegenAgents(brokerPublicKey) {
  return {
    codegenA: new AgentWorker('codegen', 'agent-05-codegen-primary', brokerPublicKey),
    codegenB: new AgentWorker('codegen', 'agent-05-codegen-secondary', brokerPublicKey)
  };
}

module.exports = {
  AgentWorker,
  createPipelineAgents,
  createStandbyWorker,
  createDualCodegenAgents
};
