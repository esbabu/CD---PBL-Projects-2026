/**
 * quorum_engine.js
 * 
 * PHASE 6: 2-of-3 Quorum Gate Architecture
 * 
 * Voters:
 * - Agent 0A: Pattern Detector (prompt injection, secret leaks, payload limits)
 * - Agent 0B: Strict Allowlist Grammar Check (accepts only input the grammar can fully parse)
 * - Deterministic Parser: Dragon-Book AST parser
 * 
 * Quorum Rule: Needs 2 of 3 votes to admit a proposed policy.
 * LLM Policy Proposal: LLM can propose policies but has zero (0) votes.
 * Degraded Mode: If Agent 0 is flagged as compromised, Agent 0's vote is dropped,
 * requiring strict dual deterministic grammar acceptance (Agent 0B + Deterministic Parser).
 */

const SafetyChecker = require('./safety_checker');
const { compilePolicy } = require('./compiler_engine');

const STRICT_ALLOWLIST_DIRECTIVES = new Set([
  'minlength',
  'maxlength',
  'requireupper',
  'require_upper',
  'require_uppercase',
  'requirelower',
  'require_lower',
  'require_lowercase',
  'requiredigit',
  'require_digit',
  'require_digits',
  'requirespecial',
  'require_special',
  'require_specials',
  'nospaces',
  'forbid_spaces',
  'forbid_whitespace',
  'require',
  'max_sequence',
  'maxsequence',
  'forbid_sequence',
  'forbid_sequences',
  'max_repeated',
  'maxrepeated',
  'forbid_repeated',
  'forbid_consecutive',
  'blacklist'
]);

/**
 * Agent 0A: Pattern & Injection Detector
 */
function voteAgent0A(dsl) {
  const sizeCheck = SafetyChecker.checkInputSize(dsl, 5000);
  if (!sizeCheck.ok) {
    return { voter: 'Agent 0A (Pattern Detector)', vote: 'REJECT', reason: sizeCheck.error };
  }

  const secretCheck = SafetyChecker.detectSensitiveData(dsl);
  if (!secretCheck.ok) {
    return { voter: 'Agent 0A (Pattern Detector)', vote: 'REJECT', reason: secretCheck.error };
  }

  const injectionCheck = SafetyChecker.detectPromptInjection(dsl);
  if (!injectionCheck.ok) {
    return { voter: 'Agent 0A (Pattern Detector)', vote: 'REJECT', reason: injectionCheck.error };
  }

  return { voter: 'Agent 0A (Pattern Detector)', vote: 'ACCEPT', reason: 'No injection, secret leakage, or size overflow detected' };
}

/**
 * Agent 0B: Strict Allowlist Check
 * Accepts only input that the strict grammar allowlist can fully parse.
 */
function voteAgent0B(dsl) {
  if (!dsl || typeof dsl !== 'string' || dsl.trim().length === 0) {
    return { voter: 'Agent 0B (Strict Allowlist)', vote: 'REJECT', reason: 'Empty policy input' };
  }

  const lines = dsl.split(/\r?\n/);
  for (let idx = 0; idx < lines.length; idx++) {
    const rawLine = lines[idx];
    const stripped = rawLine.replace(/#.*$/, '').replace(/\/\/.*$/, '').trim();
    if (!stripped) continue; // blank or comment line

    const tokens = stripped.split(/\s+/);
    const directive = tokens[0].toLowerCase();

    if (!STRICT_ALLOWLIST_DIRECTIVES.has(directive)) {
      return {
        voter: 'Agent 0B (Strict Allowlist)',
        vote: 'REJECT',
        reason: `Non-allowlisted directive '${tokens[0]}' at line ${idx + 1}. Strict allowlist violation.`
      };
    }

    // Additional argument validation
    if (tokens.length < 2 && directive !== 'blacklist') {
      return {
        voter: 'Agent 0B (Strict Allowlist)',
        vote: 'REJECT',
        reason: `Directive '${tokens[0]}' missing argument at line ${idx + 1}`
      };
    }
  }

  return { voter: 'Agent 0B (Strict Allowlist)', vote: 'ACCEPT', reason: 'All directives strictly conform to grammar allowlist' };
}

/**
 * Deterministic Parser Voter: AST Compiler
 */
function voteDeterministicParser(dsl) {
  try {
    const comp = compilePolicy(dsl);
    if (!comp.success || (comp.errors && comp.errors.length > 0)) {
      const errMsgs = (comp.errors || []).map(e => e.message || 'Syntax error').join('; ');
      return {
        voter: 'Deterministic Parser',
        vote: 'REJECT',
        reason: `Parser rejected syntax: ${errMsgs}`
      };
    }
    const ruleCount = comp.ast && comp.ast.rules ? comp.ast.rules.length : 0;
    if (ruleCount === 0) {
      return {
        voter: 'Deterministic Parser',
        vote: 'REJECT',
        reason: 'Parser produced 0 valid AST rules'
      };
    }
    return {
      voter: 'Deterministic Parser',
      vote: 'ACCEPT',
      reason: `Successfully parsed ${ruleCount} AST rules without errors`
    };
  } catch (err) {
    return {
      voter: 'Deterministic Parser',
      vote: 'REJECT',
      reason: `Parser exception: ${err.message}`
    };
  }
}

/**
 * Evaluates the 2-of-3 Quorum on a proposed policy.
 * 
 * @param {string} dsl - Proposed password policy DSL string
 * @param {object} options - { degradedMode, agent0Compromised, llmProposal }
 * @returns {object} Quorum decision report
 */
function evaluateQuorum(dsl, options = {}) {
  const degradedMode = Boolean(options.degradedMode || options.agent0Compromised);

  const vote0A = voteAgent0A(dsl);
  const vote0B = voteAgent0B(dsl);
  const voteParser = voteDeterministicParser(dsl);

  const votes = [vote0A, vote0B, voteParser];

  // The LLM has zero votes
  const llmVote = { voter: 'LLM Proposal', vote: 'NO_VOTE', reason: 'LLM can propose policies but has zero (0) voting rights' };

  if (degradedMode) {
    // In degraded mode: Agent 0 is compromised. Ignore Agent 0A.
    // Policy MUST pass both strict deterministic grammar checks (0B and Parser).
    const admitted = vote0B.vote === 'ACCEPT' && voteParser.vote === 'ACCEPT';
    return {
      admitted,
      quorumMet: admitted,
      degradedMode: true,
      rule: 'DEGRADED_MODE (Dual Deterministic Approval Required: Agent 0B + Deterministic Parser)',
      totalVotes: 2,
      acceptCount: (vote0B.vote === 'ACCEPT' ? 1 : 0) + (voteParser.vote === 'ACCEPT' ? 1 : 0),
      requiredVotes: 2,
      votes: [
        { ...vote0A, disregarded: true, note: 'Disregarded: Agent 0 flagged compromised' },
        vote0B,
        voteParser,
        llmVote
      ],
      timestamp: new Date().toISOString()
    };
  }

  // Standard Quorum: 2 of 3 votes required
  const acceptCount = votes.filter(v => v.vote === 'ACCEPT').length;
  const admitted = acceptCount >= 2;

  return {
    admitted,
    quorumMet: admitted,
    degradedMode: false,
    rule: '2_OF_3_QUORUM',
    totalVotes: 3,
    acceptCount,
    requiredVotes: 2,
    votes: [...votes, llmVote],
    timestamp: new Date().toISOString()
  };
}

module.exports = {
  voteAgent0A,
  voteAgent0B,
  voteDeterministicParser,
  evaluateQuorum
};
