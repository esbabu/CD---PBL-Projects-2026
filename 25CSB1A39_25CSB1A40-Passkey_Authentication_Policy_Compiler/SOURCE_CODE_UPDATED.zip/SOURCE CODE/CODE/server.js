/**
 * server.js
 * 
 * Secure Backend Server for Password Policy Compiler & Agentic AI.
 * Integrates:
 * - Deterministic C++ Compiler Pipeline (Lexer, Parser, Semantic, IR, NS Evaluator, CodeGen)
 * - Agentic AI (Plain Language to Policy, Security Review, Synthetic Test Cases, Error Explainer)
 * - Strict Input and Output Safety Layers
 * - User Approval Flow
 * - Static UI Serving
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');

const SafetyChecker = require('./safety_checker');
const AiService = require('./ai_service');
const leetspeakBloomEngine = require('./leetspeak_bloom_engine');
const { AutomataEngine } = require('./automata_engine');
const agentTelemetryEngine = require('./agent_telemetry_engine');
const { defaultStore: ownerAuthStore, DEFAULT_OWNER_SECRET } = require('./owner_auth_store');

const app = express();
const PORT = process.env.PORT || 3000;
const COMPILER_EXE = path.join(__dirname, 'policy_compiler.exe');

// Initialize AI Service
const aiService = new AiService(COMPILER_EXE);

// Middlewares
// Whitelist only own local server origins (Zero-Trust origin restriction)
const allowedOrigins = new Set([
  `http://localhost:${PORT}`,
  `http://127.0.0.1:${PORT}`
]);

app.use(cors({
  origin: function (origin, callback) {
    // Allow non-browser requests (e.g. same-origin without origin header, curl, internal tests)
    if (!origin || allowedOrigins.has(origin)) {
      return callback(null, true);
    }
    return callback(new Error(`CORS blocked: Origin '${origin}' is not authorized.`));
  },
  credentials: true
}));
app.use(express.json({ limit: '50kb' })); // Payload size safety check

// 1. Defensive HTTP Security Headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

// 2. Sensitive File & Source Code Exposure Blocker
// Strictly denies direct HTTP requests for source code, configs, dotfiles, or build artifacts
app.use((req, res, next) => {
  // Allow safe frontend scripts required by the IDE UI
  if (req.path === '/benchmark_scenarios.js') {
    return next();
  }

  const blockedExtensions = /\.(env|js|json|cpp|h|exe|o|log|git|md|yml|yaml|ps1|bat|sh)$/i;
  const blockedPaths = /(\/\.|\/node_modules|\/scratch)/i;

  if (blockedExtensions.test(req.path) || blockedPaths.test(req.path)) {
    return res.status(403).json({
      ok: false,
      error: '[Security Guard Triggered] Access Forbidden: Direct access to server source code and configuration files is blocked.'
    });
  }
  next();
});

// 3. Sliding-Window Rate Limiting Engine
const rateLimitStore = new Map();
function createRateLimiter(options = {}) {
  const windowMs = options.windowMs || 60 * 1000;
  const max = options.max || 100;
  const message = options.message || 'Too many requests. Please slow down.';

  return (req, res, next) => {
    const ip = req.ip || req.connection?.remoteAddress || '127.0.0.1';
    const now = Date.now();

    let clientRecord = rateLimitStore.get(ip);
    if (!clientRecord) {
      clientRecord = { requests: [] };
      rateLimitStore.set(ip, clientRecord);
    }

    clientRecord.requests = clientRecord.requests.filter(t => now - t < windowMs);

    if (clientRecord.requests.length >= max) {
      res.setHeader('Retry-After', Math.ceil(windowMs / 1000));
      return res.status(429).json({
        ok: false,
        error: `[Security Guard Triggered] Rate limit exceeded (${max} req/min). ${message}`
      });
    }

    clientRecord.requests.push(now);
    next();
  };
}

// Stale rate-limit record cleanup
setInterval(() => {
  const now = Date.now();
  for (const [ip, record] of rateLimitStore.entries()) {
    record.requests = record.requests.filter(t => now - t < 60000);
    if (record.requests.length === 0) rateLimitStore.delete(ip);
  }
}, 5 * 60 * 1000);

// Route-Specific Rate Limiters
app.use('/api', createRateLimiter({ max: 120, windowMs: 60000 }));
app.use('/api/ai', createRateLimiter({ max: 35, windowMs: 60000, message: 'AI generation quota reached.' }));
app.use('/api/check-breach', createRateLimiter({ max: 45, windowMs: 60000, message: 'Breach verification quota reached.' }));

app.use(express.static(__dirname));

// Serve IDE at root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'policy_compiler.html'));
});

/**
 * Health & Capabilities Endpoint
 */
app.get('/api/status', (req, res) => {
  const compilerExists = fs.existsSync(COMPILER_EXE);
  res.json({
    status: 'online',
    compilerAvailable: compilerExists,
    aiProvider: aiService.getLlmProviderName(),
    hasSecretApiKey: aiService.hasLlmConfigured(),
    blocklistCount: leetspeakBloomEngine.getBlocklistCount(),
    bloomParameters: leetspeakBloomEngine.getBloomParameters(),
    datasetManifest: leetspeakBloomEngine.getDatasetManifest(),
    features: [
      'Plain Language to Policy DSL',
      'Security Policy Review & NIST Audit',
      'Synthetic Test-Case Generation (Fake Passwords Only)',
      'Compiler Error & Warning Explainer',
      'Input/Output Safety & Leakage Detection',
      'User Approval Gate',
      'Full C++ Compiler Execution',
      '3,000 Curated Weak Password Datasets',
      'Kirsch-Mitzenmacher Double-Hashed Bloom Filter (0.1% FPR)',
      '5-Level Leetspeak & Evasion Detection',
      'Automata Theory Engine (NFA -> Subset DFA -> Hopcroft Minimization)',
      'DSL 2.0 Extended Syntax & Polyglot Generators (C++/Py/TS/Rust)',
      '8-Agent O-A-D-A-V Telemetry Trail',
      '55-Scenario Adversarial Benchmark Suite with Confusion Matrix'
    ]
  });
});

/**
 * FEATURE: 5-Level Leetspeak & Bloom Filter Smart Evaluation
 * Analyzes candidate password across:
 * - Level 1: Exact Case-Sensitive Match
 * - Level 2: Case-Normalized Match
 * - Level 3: Leetspeak Evasion Match (@ -> a, $ -> s, 0 -> o, 3 -> e, etc.)
 * - Level 4: Weak Structural & Keyboard Walk Patterns (admin123, qwerty)
 * - Level 5: Damerau-Levenshtein Distance-1 Typo Tolerance
 */
app.post('/api/smart-eval', (req, res) => {
  const { password } = req.body;
  if (!password || typeof password !== 'string') {
    return res.status(400).json({ ok: false, error: 'Password string required.' });
  }

  if (password.length > 256) {
    return res.status(400).json({ ok: false, error: 'Password exceeds evaluation limit (256 characters).' });
  }

  try {
    const analysis = leetspeakBloomEngine.analyzeCandidatePassword(password);
    res.json({
      ok: true,
      ...analysis
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * CORE COMPILER ENDPOINT:
 * Runs the existing C++ Policy Compiler on an approved policy
 */
app.post('/api/compile', async (req, res) => {
  const { policyDsl, password } = req.body;

  if (!policyDsl || typeof policyDsl !== 'string') {
    return res.status(400).json({ success: false, message: 'Missing policyDsl payload' });
  }

  // Input check
  const sizeCheck = SafetyChecker.checkInputSize(policyDsl, 2000);
  if (!sizeCheck.ok) {
    return res.status(400).json({ success: false, message: sizeCheck.error });
  }

  try {
    delete require.cache[require.resolve('./compiler_engine')];
    const { compilePolicy } = require('./compiler_engine');
    const result = compilePolicy(policyDsl, (password && typeof password === 'string') ? password : null);

    // Security Vaulting: Do not expose raw hardened C++ code in compile response to unapproved clients
    if (result.generated_codes && result.generated_codes.cpp) {
      result.hardened_cpp_vaulted = true;
      result.generated_codes.cpp = `// [SECURITY GUARD: HARDENED C++ CODE VAULTED]\n// Access to compiled hardened C++ validator requires manual authorization by the project owner.\n// Submit an authorization request through the Owner Approval Gate or POST /api/code/request-access.`;
    }

    res.json(result);
  } catch (err) {
    res.status(500).json({
      success: false,
      stage: 'compiler_engine',
      errors: [{ message: err.message }]
    });
  }
});

/**
 * AUTOMATA ENGINE ENDPOINT:
 * Generates NFA, Subset-Constructed DFA, and Hopcroft Minimized DFA with State Transition Matrix
 */
app.post('/api/automata', (req, res) => {
  const { policyDsl, password } = req.body;
  try {
    delete require.cache[require.resolve('./compiler_engine')];
    const { compilePolicy } = require('./compiler_engine');
    const comp = compilePolicy(policyDsl || 'minLength 8\nrequireUpper true');
    const autoRes = AutomataEngine.buildAutomataForPolicy({
      blacklist: (comp.constraints.blacklist && comp.constraints.blacklist.length > 0) ? comp.constraints.blacklist : ['password', '123456', 'admin', 'qwerty'],
      maxSequence: comp.constraints.maxSequence > 0 ? comp.constraints.maxSequence : 3,
      maxRepeated: comp.constraints.maxRepeated > 0 ? comp.constraints.maxRepeated : 3
    });

    const testPw = (typeof password === 'string' && password.length > 0) ? password : 'TestPassword123!';
    const sim = autoRes.minDfa.simulate(testPw);
    const tableSample = autoRes.minDfa.getTransitionTableSample(15);
    const cppTableCode = autoRes.minDfa.emitCppTable('MINIMAL_DFA_TRANSITION_TABLE');

    res.json({
      ok: true,
      metrics: autoRes.metrics,
      simulation: sim,
      transitionTable: tableSample,
      cppTableCode
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * 8-AGENT O-A-D-A-V TELEMETRY ENDPOINT:
 * Generates live Observation, Analysis, Decision, Action, Verification audit trail
 */
app.post('/api/agents/telemetry', (req, res) => {
  const { policyDsl, password } = req.body;
  try {
    delete require.cache[require.resolve('./compiler_engine')];
    const { compilePolicy } = require('./compiler_engine');
    const comp = compilePolicy(policyDsl || 'minLength 8\nrequireUpper true', (password && typeof password === 'string') ? password : null);
    const telemetry = agentTelemetryEngine.generatePipelineTelemetry(policyDsl || 'minLength 8\nrequireUpper true', password, comp);
    res.json({
      ok: true,
      agentsCount: telemetry.length,
      telemetry,
      compilationSuccess: comp.success,
      constraints: comp.constraints
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * 55-SCENARIO BENCHMARK RUNNER ENDPOINT:
 * Runs all 55 adversarial scenarios and computes Confusion Matrix & KPIs
 */
app.post('/api/benchmark/run', (req, res) => {
  try {
    const results = agentTelemetryEngine.runAllBenchmarkScenarios();
    res.json({
      ok: true,
      ...results
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * 100 PRODUCTION TEST CASES ENDPOINTS:
 * Loads NIST / OWASP 100 test case suite and executes batch QA run
 */
const testCasesEngine = require('./test_cases_engine');

app.get('/api/test-cases', (req, res) => {
  try {
    const list = testCasesEngine.loadTestCases();
    const metrics = testCasesEngine.getTestMetrics(list);
    res.json({
      ok: true,
      testCases: list,
      metrics
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/test-cases/run', (req, res) => {
  try {
    const result = testCasesEngine.runBatchTestSuite();
    res.json(result);
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * AI FEATURE 1: Plain Language to Policy DSL
 * Generates compiler-verified proposal with safety checks, awaiting USER APPROVAL
 */
app.post('/api/ai/nl-to-policy', async (req, res) => {
  const { prompt } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ ok: false, error: 'Please enter a description of your policy rules.' });
  }

  const result = await aiService.plainLanguageToPolicy(prompt);
  if (!result.ok) {
    return res.status(400).json(result);
  }

  res.json(result);
});

/**
 * AI FEATURE 2: Security Review & NIST SP 800-63B Audit
 */
app.post('/api/ai/review', async (req, res) => {
  const { policyDsl } = req.body;

  if (!policyDsl) {
    return res.status(400).json({ ok: false, error: 'Policy DSL is empty.' });
  }

  const result = await aiService.reviewPolicySecurity(policyDsl);
  res.json(result);
});

/**
 * AI FEATURE 3: Synthetic Test Cases (Fake Passwords Only)
 */
app.post('/api/ai/synthetic-tests', async (req, res) => {
  const { policyDsl } = req.body;

  if (!policyDsl) {
    return res.status(400).json({ ok: false, error: 'Policy DSL is empty.' });
  }

  const result = await aiService.generateSyntheticTestCases(policyDsl);
  res.json(result);
});

/**
 * AI FEATURE 4: Explain Compiler Errors
 */
app.post('/api/ai/explain-error', async (req, res) => {
  const { errorData, policyDsl, passwordFailure } = req.body;

  if (passwordFailure) {
    const result = await aiService.explainPasswordFailure(passwordFailure, policyDsl || '');
    return res.json(result);
  }

  if (!errorData) {
    return res.status(400).json({ ok: false, error: 'No error data provided.' });
  }

  const result = await aiService.explainCompilerErrors(errorData, policyDsl || '');
  res.json(result);
});

/**
 * ATTACK SIMULATOR ENDPOINTS:
 * Simulates real-world attacks against Agentic AI and multi-agent compiler pipeline.
 */
app.get('/api/attacks/predefined', (req, res) => {
  try {
    delete require.cache[require.resolve('./agent_telemetry_engine')];
    const telemetryEng = require('./agent_telemetry_engine');
    res.json({ ok: true, attacks: telemetryEng.PREDEFINED_ATTACKS || {} });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post('/api/simulate-attack', (req, res) => {
  const { attackId, customPayload, attackType } = req.body;
  try {
    delete require.cache[require.resolve('./agent_telemetry_engine')];
    const telemetryEng = require('./agent_telemetry_engine');
    const result = telemetryEng.simulateAttackScenario({ attackId, customPayload, attackType });
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * OWNER AUTHORIZATION & CODE ACCESS CONTROL
 */

function requireOwnerAuth(req, res, next) {
  const token = req.headers['x-owner-token'] || req.headers.authorization;
  const owner = ownerAuthStore.validateOwnerSession(token);
  if (!owner) {
    ownerAuthStore.recordAudit('UNAUTHORIZED_OWNER_ATTEMPT', 'UNAUTHORIZED_CALLER', null, req.ip || '127.0.0.1', { path: req.path });
    return res.status(401).json({
      ok: false,
      error: '[Security Guard] Unauthorized: Valid project owner credentials or session token required.'
    });
  }
  req.owner = owner;
  next();
}

/**
 * 1. Request Owner Authorization for Hardened C++ Code
 * Creates a pending access request and vaults the hardened C++ validator.
 */
app.post('/api/code/request-access', async (req, res) => {
  const { requesterId, policyDsl, reason } = req.body;
  const clientIp = req.ip || req.connection?.remoteAddress || '127.0.0.1';

  if (!requesterId || typeof requesterId !== 'string' || requesterId.trim().length === 0) {
    return res.status(400).json({ ok: false, error: 'Requester identity (e.g. email or username) is required.' });
  }

  try {
    let cppCode = '';
    const cppPath = path.join(__dirname, 'generated_validator.cpp');
    if (policyDsl && typeof policyDsl === 'string') {
      delete require.cache[require.resolve('./compiler_engine')];
      const { compilePolicy } = require('./compiler_engine');
      const comp = compilePolicy(policyDsl);
      if (comp.generated_codes && comp.generated_codes.cpp) {
        cppCode = comp.generated_codes.cpp;
      }
    }
    if (!cppCode && fs.existsSync(cppPath)) {
      cppCode = await fs.promises.readFile(cppPath, 'utf8');
    }
    if (!cppCode) {
      return res.status(400).json({ ok: false, error: 'No compiled C++ code available. Compile a policy first.' });
    }

    const requestRecord = ownerAuthStore.createRequest({
      requesterId: requesterId.trim(),
      policyDsl: policyDsl || '',
      hardenedCode: cppCode,
      clientIp,
      reason: reason || ''
    });

    res.json({
      ok: true,
      requestId: requestRecord.requestId,
      requesterToken: requestRecord.requesterToken,
      status: 'PENDING',
      message: 'Your request for hardened C++ code has been sent to the project owner. Access will be granted only after manual approval.',
      requestedAt: requestRecord.requestedAt,
      policySummary: requestRecord.policySummary,
      policyHash: requestRecord.policyHash
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * 2. Check Request Approval Status
 * Returns status without exposing the hardened C++ code.
 */
app.get('/api/code/status/:requestId', (req, res) => {
  const { requestId } = req.params;
  const token = req.query.token || req.headers['x-requester-token'];
  const statusInfo = ownerAuthStore.getRequestStatus(requestId, token);
  if (!statusInfo) {
    return res.status(404).json({ ok: false, error: 'Request not found.' });
  }
  res.json({ ok: true, ...statusInfo });
});

/**
 * 3. Access / Download Approved Hardened C++ Code
 * Strictly requires owner approval and matching requester token.
 */
app.get('/api/code/access/:requestId', (req, res) => {
  const { requestId } = req.params;
  const token = req.query.token || req.headers['x-requester-token'] || (req.headers.authorization ? req.headers.authorization.replace(/^Bearer\s+/i, '').trim() : null);
  const clientIp = req.ip || req.connection?.remoteAddress || '127.0.0.1';

  const access = ownerAuthStore.verifyRequesterAccess(requestId, token, clientIp);
  if (!access.ok) {
    return res.status(access.statusCode || 403).json(access);
  }

  res.json({
    ok: true,
    status: 'APPROVED',
    code: access.code,
    filename: 'generated_validator.cpp',
    requesterId: access.requesterId,
    policySummary: access.policySummary,
    policyHash: access.policyHash,
    reviewedBy: access.reviewedBy,
    reviewedAt: access.reviewedAt
  });
});

/**
 * 4. Owner Authentication / Login
 */
app.post('/api/owner/login', (req, res) => {
  const { secret } = req.body;
  if (!secret) {
    return res.status(400).json({ ok: false, error: 'Secret is required.' });
  }
  if (!ownerAuthStore.validateOwnerSecret(secret)) {
    ownerAuthStore.recordAudit('AUTH_FAILURE', 'UNAUTHENTICATED', null, req.ip || '127.0.0.1', { reason: 'Incorrect owner secret' });
    return res.status(401).json({ ok: false, error: 'Invalid owner secret.' });
  }
  const session = ownerAuthStore.createOwnerSession('Project-Owner');
  res.json({ ok: true, sessionToken: session.sessionToken, expiresAt: session.expiresAt });
});

/**
 * 5. Owner Dashboard: List All Requests Grouped (Pending, Approved, Rejected)
 */
app.get('/api/owner/requests', requireOwnerAuth, (req, res) => {
  try {
    const grouped = ownerAuthStore.getAllRequestsGrouped();
    res.json({ ok: true, requests: grouped });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * 6. Owner Action: Approve or Reject Request
 */
app.post('/api/owner/action', requireOwnerAuth, (req, res) => {
  const { requestId, action, rejectionReason } = req.body;
  const clientIp = req.ip || req.connection?.remoteAddress || '127.0.0.1';

  if (!requestId || !action) {
    return res.status(400).json({ ok: false, error: 'requestId and action (APPROVE or REJECT) are required.' });
  }

  try {
    const act = action.toUpperCase();
    if (act === 'APPROVE') {
      const result = ownerAuthStore.approveRequest(requestId, req.owner.ownerId, clientIp);
      return res.json({ ok: true, ...result });
    } else if (act === 'REJECT') {
      const result = ownerAuthStore.rejectRequest(requestId, req.owner.ownerId, rejectionReason || 'Access request rejected by project owner.', clientIp);
      return res.json({ ok: true, ...result });
    } else {
      return res.status(400).json({ ok: false, error: `Invalid action '${action}'. Expected APPROVE or REJECT.` });
    }
  } catch (err) {
    return res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * 7. Owner Audit Log
 */
app.get('/api/owner/audit-log', requireOwnerAuth, (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 50;
  const logs = ownerAuthStore.getAuditLog(limit);
  res.json({ ok: true, logs });
});

/**
 * Read Generated Target Polyglot Code (C++, Python, TypeScript, Rust)
 * Hardened C++ code requires valid owner authorization or approved request token.
 */
app.get('/api/generated-code', async (req, res) => {
  const lang = (req.query.lang || 'cpp').toLowerCase();
  const clientIp = req.ip || req.connection?.remoteAddress || '127.0.0.1';
  const targets = {
    cpp: { file: 'generated_validator.cpp', name: 'C++ (C++17)' },
    python: { file: 'generated_validator.py', name: 'Python 3' },
    typescript: { file: 'generated_validator.ts', name: 'TypeScript' },
    rust: { file: 'generated_validator.rs', name: 'Rust' }
  };

  try {
    const codes = {};
    for (const [k, v] of Object.entries(targets)) {
      const p = path.join(__dirname, v.file);
      codes[k] = fs.existsSync(p) ? await fs.promises.readFile(p, 'utf8') : '';
    }

    // GATING: Hardened C++ is strictly protected by manual owner authorization
    if (lang === 'cpp') {
      // Check 1: Is caller authenticated as Project Owner?
      const ownerToken = req.headers['x-owner-token'] || req.headers.authorization;
      const isOwner = ownerAuthStore.validateOwnerSession(ownerToken);

      if (!isOwner) {
        // Check 2: Did caller provide an approved requestId + requesterToken?
        const requestId = req.query.requestId || req.headers['x-request-id'];
        const token = req.query.token || req.headers['x-requester-token'];

        if (!requestId || !token) {
          ownerAuthStore.recordAudit('UNAUTHORIZED_ACCESS_ATTEMPT', 'ANONYMOUS_CLIENT', null, clientIp, {
            reason: 'Direct unauthenticated attempt to access hardened C++ code'
          });
          return res.status(403).json({
            ok: false,
            authorizationRequired: true,
            status: 'AUTH_REQUIRED',
            message: 'Manual Owner Authorization is required to access hardened C++ code. Submit an access request via /api/code/request-access.'
          });
        }

        const access = ownerAuthStore.verifyRequesterAccess(requestId, token, clientIp);
        if (!access.ok) {
          return res.status(access.statusCode || 403).json(access);
        }

        // Return approved C++ code for this requester
        codes.cpp = access.code;
      }
    }

    const selectedCode = codes[lang] || codes.cpp || '';
    if (!selectedCode) {
      return res.json({ ok: false, message: 'No target code generated yet. Compile a policy first.' });
    }

    res.json({
      ok: true,
      lang,
      code: selectedCode,
      polyglot: codes,
      codes,
      targets
    });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

/**
 * FEATURE: k-Anonymity Breach Checker (HaveIBeenPwned Protocol)
 * Hashes password using SHA-1 and queries HIBP range API using only 5-character prefix.
 * Complete password NEVER leaves the system.
 */
app.post('/api/check-breach', async (req, res) => {
  const { password } = req.body;
  if (!password || typeof password !== 'string') {
    return res.status(400).json({ ok: false, error: 'Password string required.' });
  }

  // Input length boundary check to prevent ReDoS / CPU starvation
  if (password.length > 256) {
    return res.status(400).json({ ok: false, error: 'Password length exceeds evaluation limit (256 characters).' });
  }

  try {
    const crypto = require('crypto');
    const sha1 = crypto.createHash('sha1').update(password).digest('hex').toUpperCase();
    const prefix = sha1.substring(0, 5);
    const suffix = sha1.substring(5);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const hibpUrl = `https://api.pwnedpasswords.com/range/${prefix}`;
    const hibpRes = await fetch(hibpUrl, {
      signal: controller.signal,
      headers: { 'User-Agent': 'PasswordPolicyCompiler-ZeroTrust/2.0' }
    });
    clearTimeout(timeoutId);

    if (!hibpRes.ok) {
      throw new Error(`HIBP responded with status ${hibpRes.status}`);
    }

    const text = await hibpRes.text();
    const entries = text.split('\r\n');
    let breachCount = 0;

    for (const entry of entries) {
      const [hSuffix, countStr] = entry.split(':');
      if (hSuffix && hSuffix.trim().toUpperCase() === suffix) {
        breachCount = parseInt(countStr.trim(), 10) || 0;
        break;
      }
    }

    res.json({
      ok: true,
      breached: breachCount > 0,
      isBreached: breachCount > 0,
      count: breachCount,
      breachCount,
      source: 'HIBP Live API',
      prefix,
      sha1FullLength: 40,
      kAnonymityGuarantee: `k-Anonymity Verified: Only 5-character prefix '${prefix}***' was queried. Your actual password was never transmitted over the network.`
    });

  } catch (err) {
    // Offline / sandbox fallback: Check common known breached passwords dictionary
    const commonBreached = {
      'password': 9823521,
      '123456': 23984122,
      '123456789': 8762310,
      'admin': 1523490,
      'qwerty': 4512390,
      'welcome': 892340,
      'letmein': 782390,
      'password123': 1230490,
      'secret': 672340,
      'pass123': 412390
    };

    const lower = password.toLowerCase();
    const isCommon = Boolean(commonBreached[lower]);
    const crypto = require('crypto');
    const sha1 = crypto.createHash('sha1').update(password).digest('hex').toUpperCase();

    res.json({
      ok: true,
      breached: isCommon,
      isBreached: isCommon,
      count: isCommon ? commonBreached[lower] : 0,
      breachCount: isCommon ? commonBreached[lower] : 0,
      source: 'Local Leaked Dictionary (Fallback)',
      offlineFallback: true,
      prefix: sha1.substring(0, 5),
      kAnonymityGuarantee: `Evaluated via local breach hash dictionary (Offline / Sandbox Mode). Full password never transmitted.`
    });
  }
});
app.use('/api/auth-policy', require('./auth_policy/routes'));

// Start Server if run directly
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`🚀 Password Policy Compiler & Agentic AI Server Running`);
    console.log(`🌐 URL: http://localhost:${PORT}`);
    console.log(`🔒 AI Provider: ${aiService.getLlmProviderName()}`);
    console.log(`🛡️  Zero-Trust Safety & Compiler Verification: ACTIVE`);
    console.log(`=======================================================`);
  });
}

module.exports = app;
