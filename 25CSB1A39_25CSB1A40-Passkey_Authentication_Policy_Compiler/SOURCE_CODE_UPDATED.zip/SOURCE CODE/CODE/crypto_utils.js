/**
 * crypto_utils.js
 * 
 * Cryptographic Utilities for Zero-Trust Signed Envelopes.
 * Uses native Ed25519 signatures and SHA-256 digests.
 */

const crypto = require('crypto');

const PERMITTED_ACTIONS = {
  lexer: 'EMIT_TOKENS',
  parser: 'EMIT_AST',
  semantic: 'VERIFY_SEMANTICS',
  ir: 'OPTIMIZE_IR',
  codegen: 'EMIT_VALIDATOR',
  test: 'RUN_TESTS',
  audit: 'SECURITY_AUDIT'
};

function sha256(data) {
  const str = typeof data === 'string' ? data : JSON.stringify(data);
  return crypto.createHash('sha256').update(str).digest('hex');
}

/**
 * Generates an Ed25519 keypair.
 * Returns public and private keys in PEM format.
 */
function generateKeypair() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  return {
    publicKey: publicKey.export({ type: 'spki', format: 'pem' }),
    privateKey: privateKey.export({ type: 'pkcs8', format: 'pem' })
  };
}

/**
 * Builds canonical string representation of an envelope for signing.
 */
function buildSignableString(fields) {
  const {
    jobId,
    stage,
    inputHash,
    deadline,
    nonce,
    permittedAction,
    payloadHash,
    fencingToken
  } = fields;

  const parts = [
    jobId,
    stage,
    inputHash,
    String(deadline),
    nonce,
    permittedAction,
    payloadHash || ''
  ];
  if (fencingToken !== undefined && fencingToken !== null && fencingToken !== '') {
    parts.push(String(fencingToken));
  }
  return parts.join('|');
}

/**
 * Creates and signs an envelope.
 */
function createEnvelope({
  jobId,
  stage,
  inputHash,
  deadline,
  nonce,
  permittedAction,
  payload,
  privateKey,
  senderId,
  fencingToken
}) {
  const generatedNonce = nonce || `nonce_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
  const generatedDeadline = deadline || (Date.now() + 30000); // 30s default
  const payloadHash = payload ? sha256(payload) : '';

  const signable = buildSignableString({
    jobId,
    stage,
    inputHash,
    deadline: generatedDeadline,
    nonce: generatedNonce,
    permittedAction,
    payloadHash,
    fencingToken
  });

  const privKeyObj = typeof privateKey === 'string'
    ? crypto.createPrivateKey(privateKey)
    : privateKey;

  const signature = crypto.sign(null, Buffer.from(signable, 'utf8'), privKeyObj).toString('hex');

  return {
    jobId,
    stage,
    inputHash,
    deadline: generatedDeadline,
    nonce: generatedNonce,
    permittedAction,
    senderId: senderId || 'anonymous',
    payload: payload || null,
    payloadHash,
    fencingToken: (fencingToken !== undefined && fencingToken !== null) ? fencingToken : null,
    signature
  };
}

/**
 * Verifies envelope signature and integrity.
 */
function verifyEnvelope(envelope, publicKey) {
  if (!envelope || !envelope.signature) {
    return { valid: false, reason: 'Missing envelope or signature' };
  }

  const {
    jobId,
    stage,
    inputHash,
    deadline,
    nonce,
    permittedAction,
    payload,
    payloadHash,
    fencingToken,
    signature
  } = envelope;

  // 1. Verify payload hash if payload is provided
  if (payload !== undefined && payload !== null) {
    const computedHash = sha256(payload);
    if (payloadHash && computedHash !== payloadHash) {
      return {
        valid: false,
        reason: `Payload hash mismatch: computed '${computedHash}' != header '${payloadHash}'`
      };
    }
  }

  // 2. Build signable string
  const signable = buildSignableString({
    jobId,
    stage,
    inputHash,
    deadline,
    nonce,
    permittedAction,
    payloadHash,
    fencingToken
  });

  // 3. Verify Ed25519 signature
  try {
    const pubKeyObj = typeof publicKey === 'string'
      ? crypto.createPublicKey(publicKey)
      : publicKey;

    const isVerified = crypto.verify(
      null,
      Buffer.from(signable, 'utf8'),
      pubKeyObj,
      Buffer.from(signature, 'hex')
    );

    if (!isVerified) {
      return { valid: false, reason: 'Invalid Ed25519 signature' };
    }
  } catch (err) {
    return { valid: false, reason: `Signature verification error: ${err.message}` };
  }

  return { valid: true };
}

module.exports = {
  PERMITTED_ACTIONS,
  sha256,
  generateKeypair,
  createEnvelope,
  verifyEnvelope,
  buildSignableString
};
