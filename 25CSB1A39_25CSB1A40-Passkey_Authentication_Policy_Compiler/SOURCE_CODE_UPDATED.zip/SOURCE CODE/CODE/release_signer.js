/**
 * release_signer.js
 * 
 * PHASE 6: Standalone Release Signer Program
 * 
 * Signs the final validator only when:
 * 1. Both Gate 1 (Semantic Verification) and Gate 2 (Security & Differential Testing) approve.
 * 2. Quorum policy admission is verified.
 * 3. The artifact's SHA-256 hash strictly matches the approved expected hash.
 * 
 * Also writes an immutable cryptographic audit report.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { generateKeypair, sha256 } = require('./crypto_utils');

class ReleaseSigner {
  /**
   * Initializes the Release Authority with a dedicated Ed25519 keypair.
   * Completely decoupled from the broker and individual pipeline agents.
   */
  constructor() {
    this.keypair = generateKeypair();
    this.publicKey = this.keypair.publicKey;
    this._privateKey = this.keypair.privateKey;
    this.signerId = 'ReleaseAuthority-Root-Ed25519';
  }

  getPublicKey() {
    return this.publicKey;
  }

  /**
   * Evaluates release criteria and signs the artifact release certificate.
   * 
   * @param {object} params
   * @param {string} params.jobId
   * @param {string|object} params.artifact - Final validator source or payload
   * @param {string} params.expectedHash - Expected SHA-256 hash approved by gates
   * @param {object} params.gate1Receipt - Gate 1 semantic approval receipt
   * @param {object} params.gate2Receipt - Gate 2 differential & security approval receipt
   * @param {object} params.quorumReceipt - Policy quorum admission receipt
   * @param {string} [params.auditDir] - Destination directory for audit report
   * @returns {object} Signed release bundle
   */
  signRelease({
    jobId,
    artifact,
    expectedHash,
    gate1Receipt,
    gate2Receipt,
    quorumReceipt,
    auditDir = null
  }) {
    if (!jobId) throw new Error('[Release Authority Rejection] Missing jobId');
    if (!artifact) throw new Error('[Release Authority Rejection] Missing artifact');

    // 1. Quorum Check
    if (!quorumReceipt || !quorumReceipt.admitted) {
      throw new Error('[Release Authority Rejection] Policy failed 2-of-3 quorum admission. Release refused.');
    }

    // 2. Gate 1 Semantic Verification Check
    if (!gate1Receipt || !gate1Receipt.approved) {
      const errs = (gate1Receipt && gate1Receipt.errors) ? gate1Receipt.errors.join('; ') : 'Rejected';
      throw new Error(`[Release Authority Rejection] Gate 1 (Semantic Verification) did not approve: ${errs}`);
    }

    // 3. Gate 2 Security & Differential Test Check
    if (!gate2Receipt || !gate2Receipt.approved) {
      const reason = (gate2Receipt && gate2Receipt.reason) ? gate2Receipt.reason : 'Differential disagreement or security alert';
      throw new Error(`[Release Authority Rejection] Gate 2 (Security & Differential Test) did not approve: ${reason}`);
    }

    // 4. Artifact Hash Integrity Check
    const artifactStr = typeof artifact === 'string' ? artifact : JSON.stringify(artifact);
    const actualHash = sha256(artifactStr);

    if (actualHash !== expectedHash) {
      throw new Error(`[Release Authority Rejection] Artifact SHA-256 hash mismatch! Expected approved hash '${expectedHash}', but actual artifact produced '${actualHash}' (possible tampered byte). Release refused.`);
    }

    // 5. Build Canonical Release Certificate Payload
    const signedAt = new Date().toISOString();
    const certPayload = [
      jobId,
      actualHash,
      gate1Receipt.receiptHash || sha256(gate1Receipt),
      gate2Receipt.receiptHash || sha256(gate2Receipt),
      quorumReceipt.rule || 'QUORUM_VERIFIED',
      signedAt,
      this.signerId
    ].join('|');

    const privKeyObj = crypto.createPrivateKey(this._privateKey);
    const signature = crypto.sign(null, Buffer.from(certPayload, 'utf8'), privKeyObj).toString('hex');

    // 6. Build Comprehensive Audit Report
    const auditReport = {
      jobId,
      signerId: this.signerId,
      signedAt,
      artifactHash: actualHash,
      artifactLengthBytes: Buffer.byteLength(artifactStr, 'utf8'),
      quorum: {
        admitted: quorumReceipt.admitted,
        rule: quorumReceipt.rule,
        degradedMode: Boolean(quorumReceipt.degradedMode),
        acceptCount: quorumReceipt.acceptCount,
        totalVotes: quorumReceipt.totalVotes
      },
      gate1: {
        approved: gate1Receipt.approved,
        receiptHash: gate1Receipt.receiptHash,
        constraintSummary: gate1Receipt.constraintSummary
      },
      gate2: {
        approved: gate2Receipt.approved,
        receiptHash: gate2Receipt.receiptHash,
        languagesVerified: gate2Receipt.languagesVerified,
        testVectorCount: gate2Receipt.testVectorCount,
        agreementRate: gate2Receipt.agreementRate
      },
      releaseCertificate: {
        payload: certPayload,
        signature,
        publicKeyPem: this.publicKey
      }
    };

    // 7. Write Audit Report to disk
    const destDir = auditDir || path.join(__dirname, 'data', 'audits');
    try {
      if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
      const auditPath = path.join(destDir, `release_audit_${jobId}.json`);
      fs.writeFileSync(auditPath, JSON.stringify(auditReport, null, 2), 'utf8');
      auditReport.auditFilePath = auditPath;
    } catch (_) {}

    return {
      ok: true,
      signed: true,
      jobId,
      artifactHash: actualHash,
      signature,
      signerId: this.signerId,
      auditReport
    };
  }

  /**
   * Verifies a release certificate signature against the Release Authority public key.
   */
  verifyReleaseCertificate(certPayload, signature) {
    try {
      const pubKeyObj = crypto.createPublicKey(this.publicKey);
      return crypto.verify(null, Buffer.from(certPayload, 'utf8'), pubKeyObj, Buffer.from(signature, 'hex'));
    } catch (_) {
      return false;
    }
  }
}

module.exports = {
  ReleaseSigner
};
