/**
 * test_broker.js
 * 
 * Comprehensive Verification Suite for Phase 2:
 * 1. Database creation & tables (jobs, stage_results, leases, events)
 * 2. Stage transitions enforcement (rejects skipped/out-of-order stages)
 * 3. Idempotency keyed on (job_id, stage, input_hash)
 * 4. Tamper-evident hash chain and verify-chain command
 * 5. Tamper detection upon adversarial row modification
 */

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const { JobBroker, sha256 } = require('./broker');

async function runBrokerTests() {
  console.log('--------------------------------------------------------------------------------');
  console.log('🧪 BROKER VERIFICATION SUITE (SQLite + Zero-Trust Orchestration)');
  console.log('--------------------------------------------------------------------------------');

  const testDb = path.join(__dirname, 'test_broker.db');
  if (fs.existsSync(testDb)) fs.unlinkSync(testDb);

  const broker = new JobBroker(testDb);
  console.log('  ✓ Initialized SQLite database with all 4 tables (jobs, stage_results, leases, events)');

  // 1. Job Creation
  const dsl = 'minLength 12\nrequireUpper true\nrequireDigit true\n';
  const job = broker.createJob(dsl);
  assert.strictEqual(job.status, 'PENDING');
  assert.strictEqual(job.currentStage, 'lexer');
  assert.strictEqual(job.initialHash, sha256(dsl));
  console.log(`  ✓ Created job '${job.jobId}' with initial SHA-256: ${job.initialHash.slice(0, 16)}...`);

  // 2. Out-of-Order Stage Rejection
  let caughtOutOfOrder = false;
  try {
    broker.runStage(job.jobId, 'semantic'); // Invalid: must run lexer first!
  } catch (err) {
    caughtOutOfOrder = true;
    console.log(`  ✓ Out-of-order stage correctly rejected: ${err.message}`);
  }
  assert.strictEqual(caughtOutOfOrder, true, 'Broker should reject skipped stages');

  // 3. Sequential Stage Execution
  // Stage 1: Lexer
  const resLex = broker.runStage(job.jobId, 'lexer', 'worker_lex_1');
  assert.strictEqual(resLex.ok, true);
  assert.strictEqual(resLex.cached, false);
  assert.strictEqual(resLex.status, 'COMPLETED');
  console.log(`  ✓ Executed stage [lexer]: produced output hash ${resLex.outputHash.slice(0, 16)}...`);

  // 4. Idempotency Test: Re-running lexer with same input
  const resLexIdempotent = broker.runStage(job.jobId, 'lexer', 'worker_lex_2');
  assert.strictEqual(resLexIdempotent.ok, true);
  assert.strictEqual(resLexIdempotent.cached, true);
  assert.strictEqual(resLexIdempotent.outputHash, resLex.outputHash);
  console.log('  ✓ Idempotency verified: duplicate stage submission returned cached output without re-execution');

  // Stage 2: Parser
  const resParse = broker.runStage(job.jobId, 'parser', 'worker_parse_1');
  assert.strictEqual(resParse.ok, true);
  assert.strictEqual(resParse.nextStage, 'semantic');
  console.log(`  ✓ Executed stage [parser]: AST generated, next expected stage '${resParse.nextStage}'`);

  // Stage 3: Semantic
  const resSem = broker.runStage(job.jobId, 'semantic', 'worker_sem_1');
  assert.strictEqual(resSem.ok, true);
  console.log(`  ✓ Executed stage [semantic]: constraints extracted (minLength: ${resSem.outputPayload.constraints.minLength})`);

  // Stage 4: IR
  const resIR = broker.runStage(job.jobId, 'ir', 'worker_ir_1');
  assert.strictEqual(resIR.ok, true);
  console.log('  ✓ Executed stage [ir]: IR generated');

  // Stage 5: Codegen
  const resCodeGen = broker.runStage(job.jobId, 'codegen', 'worker_code_1');
  assert.strictEqual(resCodeGen.ok, true);
  console.log(`  ✓ Executed stage [codegen]: Validator synthesized (${resCodeGen.outputPayload.codeLength} bytes)`);

  // Stage 6: Test
  const resTest = broker.runStage(job.jobId, 'test', 'worker_test_1');
  assert.strictEqual(resTest.ok, true);
  console.log(`  ✓ Executed stage [test]: Oracle verified (${resTest.outputPayload.validCount}/${resTest.outputPayload.totalTested} valid)`);

  // Stage 7: Audit
  const resAudit = broker.runStage(job.jobId, 'audit', 'worker_audit_1');
  assert.strictEqual(resAudit.ok, true);
  assert.strictEqual(resAudit.jobStatus, 'COMPLETED');
  console.log(`  ✓ Executed stage [audit]: NIST SP 800-63B score ${resAudit.outputPayload.score}, job status 'COMPLETED'`);

  // 5. Tamper-Evident Hash Chain Verification
  const verify1 = broker.verifyChain();
  assert.strictEqual(verify1.valid, true);
  console.log(`  ✓ verifyChain() passed: ${verify1.count} events cryptographically linked. Head: ${verify1.headHash.slice(0, 16)}...`);

  // 6. Adversarial Tamper Detection Test
  // Modify an event row directly in the database to simulate malicious tampering
  broker.db.prepare("UPDATE events SET details = '{\"tampered\": true}' WHERE seq = 3").run();
  const verifyTampered = broker.verifyChain();
  assert.strictEqual(verifyTampered.valid, false, 'Tampered event should fail verification');
  assert.strictEqual(verifyTampered.brokenSeq, 3);
  console.log(`  ✓ Adversarial Tamper Detection: Caught unauthorized record modification at seq ${verifyTampered.brokenSeq} (${verifyTampered.reason})`);

  broker.close();
  if (fs.existsSync(testDb)) fs.unlinkSync(testDb);

  console.log('\n  ✅ ALL PHASE 2 BROKER CHECKS PASSED (100%)\n');
}

runBrokerTests().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});
