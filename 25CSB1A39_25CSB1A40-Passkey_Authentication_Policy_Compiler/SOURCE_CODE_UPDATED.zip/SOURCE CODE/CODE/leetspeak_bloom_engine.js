/**
 * leetspeak_bloom_engine.js
 * 
 * High-performance Bloom Filter & 5-Level Leetspeak Evasion Detector.
 * Implements:
 * 1. Kirsch-Mitzenmacher Double Hashing (FNV-1a 64-bit + MurmurMix 64-bit)
 * 2. Static Bloom Filter with m=43,133 bits, k=10 hashes for 3,000 weak passwords (0.1% FPR)
 * 3. 5-Level Smart Finder (Exact, Case-normalized, Leetspeak-variant, Structural Affix, Damerau-Levenshtein)
 */

const fs = require('fs');
const path = require('path');

// Load 3,000 weak password dataset
let blocklistEntries = [];
let blocklistSet = new Set();
let datasetManifest = null;

try {
  // Load from dataset_bundle.js or data directory
  const bundlePath = path.join(__dirname, 'dataset_bundle.js');
  if (fs.existsSync(bundlePath)) {
    const code = fs.readFileSync(bundlePath, 'utf8');
    // Evaluate bundle variables safely
    const fn = new Function(code + '; return { EMBEDDED_DATASET_MANIFEST, EMBEDDED_3000_BLOCKLIST };');
    const res = fn();
    blocklistEntries = res.EMBEDDED_3000_BLOCKLIST || [];
    datasetManifest = res.EMBEDDED_DATASET_MANIFEST || null;
    blocklistSet = new Set(blocklistEntries.map(s => s.toLowerCase().trim()));
  }
} catch (e) {
  console.warn('[BloomEngine] Error loading dataset bundle:', e.message);
}

// Fallback if bundle load failed
if (blocklistEntries.length === 0) {
  const common = ['password', '123456', 'admin', 'qwerty', 'welcome', 'root', 'secret', 'testing', 'letmein'];
  blocklistEntries = common;
  blocklistSet = new Set(common);
}

const BLOOM_N = blocklistEntries.length;
const BLOOM_TARGET_FPR = 0.001; // 0.1%
const LN2 = 0.6931471805599453;
const LN2_SQ = LN2 * LN2;

// m = ceil(-n * ln(p) / (ln(2))^2)
const BLOOM_M_BITS = Math.max(8, Math.ceil((-BLOOM_N * Math.log(BLOOM_TARGET_FPR)) / LN2_SQ));
const BLOOM_M_BYTES = Math.ceil(BLOOM_M_BITS / 8);
// k = round((m / n) * ln(2))
const BLOOM_K_HASHES = Math.min(30, Math.max(1, Math.round((BLOOM_M_BITS / BLOOM_N) * LN2)));

// Bit array storage
const bloomBitArray = new Uint8Array(BLOOM_M_BYTES);

// Hash 1: FNV-1a 64-bit
function hashFnv1a64(str) {
  let h = 0xcbf29ce484222325n;
  const prime = 0x100000001b3n;
  const bytes = Buffer.from(str, 'utf8');
  for (let i = 0; i < bytes.length; i++) {
    h = BigInt.asUintN(64, (h ^ BigInt(bytes[i])) * prime);
  }
  return h;
}

// Hash 2: MurmurMix 64-bit
function hashMurmurMix64(str) {
  const bytes = Buffer.from(str, 'utf8');
  const len = BigInt(bytes.length);
  const m = 0xc6a4a7935bd1e995n;
  const r = 47;
  let h = BigInt.asUintN(64, 0x8445d61a4e31n ^ (len * m));

  const nblocks = Math.floor(bytes.length / 8);
  for (let i = 0; i < nblocks; i++) {
    const offset = i * 8;
    let k = 0n;
    for (let b = 0; b < 8; b++) {
      k |= BigInt(bytes[offset + b]) << BigInt(b * 8);
    }
    k = BigInt.asUintN(64, k * m);
    k = BigInt.asUintN(64, k ^ (k >> BigInt(r)));
    k = BigInt.asUintN(64, k * m);
    h = BigInt.asUintN(64, h ^ k);
    h = BigInt.asUintN(64, h * m);
  }

  const tailOffset = nblocks * 8;
  const tailLen = bytes.length & 7;
  if (tailLen >= 7) h = BigInt.asUintN(64, h ^ (BigInt(bytes[tailOffset + 6]) << 48n));
  if (tailLen >= 6) h = BigInt.asUintN(64, h ^ (BigInt(bytes[tailOffset + 5]) << 40n));
  if (tailLen >= 5) h = BigInt.asUintN(64, h ^ (BigInt(bytes[tailOffset + 4]) << 32n));
  if (tailLen >= 4) h = BigInt.asUintN(64, h ^ (BigInt(bytes[tailOffset + 3]) << 24n));
  if (tailLen >= 3) h = BigInt.asUintN(64, h ^ (BigInt(bytes[tailOffset + 2]) << 16n));
  if (tailLen >= 2) h = BigInt.asUintN(64, h ^ (BigInt(bytes[tailOffset + 1]) << 8n));
  if (tailLen >= 1) {
    h = BigInt.asUintN(64, h ^ BigInt(bytes[tailOffset]));
    h = BigInt.asUintN(64, h * m);
  }

  h = BigInt.asUintN(64, h ^ (h >> BigInt(r)));
  h = BigInt.asUintN(64, h * m);
  h = BigInt.asUintN(64, h ^ (h >> BigInt(r)));
  return h;
}

// Populate Bloom filter with all blocklist entries
function initBloomFilter() {
  bloomBitArray.fill(0);
  const mBig = BigInt(BLOOM_M_BITS);
  for (let i = 0; i < blocklistEntries.length; i++) {
    const key = blocklistEntries[i].toLowerCase().trim();
    const h1 = hashFnv1a64(key);
    const h2 = hashMurmurMix64(key);
    for (let k = 0; k < BLOOM_K_HASHES; k++) {
      const probe = Number(BigInt.asUintN(64, h1 + BigInt(k) * h2) % mBig);
      const byteIdx = Math.floor(probe / 8);
      const bitMask = 1 << (probe % 8);
      bloomBitArray[byteIdx] |= bitMask;
    }
  }
}

// Query Bloom Filter
function queryBloom(candidate) {
  const key = candidate.toLowerCase().trim();
  const h1 = hashFnv1a64(key);
  const h2 = hashMurmurMix64(key);
  const mBig = BigInt(BLOOM_M_BITS);

  let allSet = true;
  let setBits = 0;
  for (let k = 0; k < BLOOM_K_HASHES; k++) {
    const probe = Number(BigInt.asUintN(64, h1 + BigInt(k) * h2) % mBig);
    const byteIdx = Math.floor(probe / 8);
    const bitMask = 1 << (probe % 8);
    const isSet = (bloomBitArray[byteIdx] & bitMask) !== 0;
    if (isSet) setBits++;
    else allSet = false;
  }

  const inExactTable = blocklistSet.has(key);
  let status = 'DEFINITELY_NOT_PRESENT';
  if (allSet) {
    status = inExactTable ? 'EXACT_MATCH_CONFIRMED' : 'BLOOM_FALSE_POSITIVE';
  }

  return {
    inBloom: allSet,
    inExactTable,
    status,
    probesTested: BLOOM_K_HASHES,
    setBits,
    h1Hex: '0x' + h1.toString(16),
    h2Hex: '0x' + h2.toString(16),
    bloomParameters: {
      n: BLOOM_N,
      mBits: BLOOM_M_BITS,
      mBytes: BLOOM_M_BYTES,
      kHashes: BLOOM_K_HASHES,
      targetFpr: BLOOM_TARGET_FPR
    }
  };
}

// Leetspeak Normalization Mapping Tables
const LEET_TABLE_1 = { '@': 'a', '4': 'a', '0': 'o', '$': 's', '5': 's', '3': 'e', '7': 't', '8': 'b', '!': 'i', '2': 'z', '1': 'i' };
const LEET_TABLE_2 = { '@': 'a', '4': 'a', '0': 'o', '$': 's', '5': 's', '3': 'e', '7': 't', '8': 'b', '!': 'i', '2': 'z', '1': 'l' };

function normalizeLeetspeak(str, map = LEET_TABLE_1) {
  const substitutions = [];
  let normalized = '';
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (map[ch]) {
      substitutions.push({ position: i, from: ch, to: map[ch] });
      normalized += map[ch];
    } else {
      normalized += ch.toLowerCase();
    }
  }
  return { normalized, substitutions, hasSubstitutions: substitutions.length > 0 };
}

// Damerau-Levenshtein Distance (transposition + insertion/deletion/substitution)
function damerauLevenshtein(s1, s2) {
  const l1 = s1.length;
  const l2 = s2.length;
  if (Math.abs(l1 - l2) > 1) return 2;
  const d = [];
  for (let i = 0; i <= l1; i++) d[i] = [i];
  for (let j = 0; j <= l2; j++) d[0][j] = j;

  for (let i = 1; i <= l1; i++) {
    for (let j = 1; j <= l2; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      d[i][j] = Math.min(
        d[i - 1][j] + 1,
        d[i][j - 1] + 1,
        d[i - 1][j - 1] + cost
      );
      if (i > 1 && j > 1 && s1[i - 1] === s2[j - 2] && s1[i - 2] === s2[j - 1]) {
        d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      }
    }
  }
  return d[l1][l2];
}

// 5-Level Smart Blocklist & Leetspeak Analysis
function analyzeCandidatePassword(rawPassword) {
  if (!rawPassword || typeof rawPassword !== 'string' || rawPassword.trim().length === 0) {
    return {
      status: 'AWAITING_INPUT',
      verdict: 'AWAITING_INPUT',
      level: 0,
      matchedWord: null,
      substitutions: [],
      reason: 'Awaiting password input for evaluation.'
    };
  }

  const raw = rawPassword.trim();
  const lower = raw.toLowerCase();
  const bloomRes = queryBloom(raw);

  // LEVEL 1: Exact Case-Sensitive Match
  if (blocklistSet.has(raw)) {
    return {
      status: 'REJECTED',
      verdict: 'EXACT_MATCH',
      level: 1,
      category: 'Exact Common Weak Password Match',
      matchedWord: raw,
      normalizedCandidate: raw,
      substitutions: [],
      bloom: bloomRes,
      reason: `Matches a known compromised weak password '${raw}' verbatim.`,
      recommendation: 'Choose a passphrase not present in any public dictionary or breach corpus.'
    };
  }

  // LEVEL 2: Case-Normalized Match
  if (blocklistSet.has(lower)) {
    return {
      status: 'REJECTED',
      verdict: 'CASE_NORMALIZED_MATCH',
      level: 2,
      category: 'Case-Insensitive Blocklist Match',
      matchedWord: lower,
      normalizedCandidate: lower,
      substitutions: [],
      bloom: bloomRes,
      reason: `Simple casing variation of commonly used weak password '${lower}'.`,
      recommendation: 'Capitalizing letters alone does not prevent dictionary or credential-stuffing attacks.'
    };
  }

  // Controlled Candidate Expansion for Levels 3 & 4
  const norm1 = normalizeLeetspeak(raw, LEET_TABLE_1);
  const norm2 = normalizeLeetspeak(raw, LEET_TABLE_2);

  const candidates = [
    { text: norm1.normalized, desc: 'Leetspeak substitution (1->i)', subs: norm1.substitutions },
    { text: norm2.normalized, desc: 'Leetspeak substitution (1->l)', subs: norm2.substitutions }
  ];

  const trailMatch = raw.match(/^(.*?)(\d+)$/);
  const wordPart = trailMatch ? trailMatch[1] : raw;
  const numPart = trailMatch ? trailMatch[2] : '';

  if (numPart) {
    const wn1 = normalizeLeetspeak(wordPart, LEET_TABLE_1);
    candidates.push({ text: wn1.normalized + numPart, desc: 'Leetspeak root with trailing numbers', subs: wn1.substitutions });
    candidates.push({ text: wn1.normalized, desc: 'Leetspeak root alone', subs: wn1.substitutions });
    candidates.push({ text: wordPart.toLowerCase(), desc: 'Word root alone', subs: [] });
  }

  // LEVEL 3: Leetspeak-normalized match
  for (const cand of candidates) {
    if (cand.text && blocklistSet.has(cand.text)) {
      return {
        status: 'REJECTED',
        verdict: 'LEETSPEAK_VARIANT_MATCH',
        level: 3,
        category: 'Leetspeak-based Blocklist Match',
        matchedWord: cand.text,
        normalizedCandidate: cand.text,
        substitutions: cand.subs,
        bloom: bloomRes,
        reason: `Character-substituted (leetspeak) variation of weak password '${cand.text}'.`,
        recommendation: 'Replacing letters with symbols (@ for a, $ for s) is trivially cracked by modern tools.'
      };
    }
  }

  // LEVEL 4: Predictable Word + Affixes & Keyboard Walks
  if (numPart && numPart.length >= 1 && numPart.length <= 4) {
    const cleanWord = wordPart.toLowerCase().replace(/[^a-z]/g, '');
    if (cleanWord.length >= 3 && blocklistSet.has(cleanWord)) {
      return {
        status: 'REJECTED',
        verdict: 'WEAK_PATTERN_MATCH',
        level: 4,
        category: 'Predictable Word + Numeric Pattern',
        matchedWord: cleanWord,
        normalizedCandidate: cleanWord + numPart,
        substitutions: norm1.substitutions,
        bloom: bloomRes,
        reason: `Combines dictionary word '${cleanWord}' with predictable numeric sequence '${numPart}'.`,
        recommendation: 'Avoid appending numbers or years to common words.'
      };
    }
  }

  const keyboardWalks = ['qwerty', 'asdfgh', 'zxcvbn', '123456', '654321', '098765'];
  for (const walk of keyboardWalks) {
    if (lower.includes(walk)) {
      return {
        status: 'REJECTED',
        verdict: 'KEYBOARD_PATTERN_MATCH',
        level: 4,
        category: 'Spatial Keyboard Walk Pattern',
        matchedWord: walk,
        normalizedCandidate: lower,
        substitutions: [],
        bloom: bloomRes,
        reason: `Contains easily guessed spatial keyboard sequence '${walk}'.`,
        recommendation: 'Avoid sequential patterns across keyboard rows.'
      };
    }
  }

  // LEVEL 5: Calibrated Damerau-Levenshtein Typo Match (distance-1 on length >= 7)
  if (lower.length >= 7) {
    for (const entry of blocklistEntries) {
      if (entry.length >= 7 && Math.abs(entry.length - lower.length) <= 1) {
        if (damerauLevenshtein(lower, entry) === 1) {
          return {
            status: 'REJECTED',
            verdict: 'SIMILARITY_MATCH',
            level: 5,
            category: 'High-Similarity Near-Match (Distance-1)',
            matchedWord: entry,
            normalizedCandidate: lower,
            substitutions: [],
            bloom: bloomRes,
            reason: `Only 1 edit away from compromised blocklist entry '${entry}'.`,
            recommendation: 'Changing a single character of a known weak password does not provide security.'
          };
        }
      }
    }
  }

  // All 5 levels cleared!
  return {
    status: 'PASSED',
    verdict: 'CLEAN_PASSWORD',
    level: 0,
    category: 'Unique Password (Cleared Blocklist)',
    matchedWord: null,
    normalizedCandidate: lower,
    substitutions: norm1.substitutions,
    bloom: bloomRes,
    reason: `Cleared all 5 levels of blocklist screening (${BLOOM_N.toLocaleString()} entries).`,
    recommendation: 'Password cleared blocklist screening. Ensure it also satisfies entropy and length policies.'
  };
}

// Initialize on load
initBloomFilter();

module.exports = {
  initBloomFilter,
  queryBloom,
  normalizeLeetspeak,
  analyzeCandidatePassword,
  damerauLevenshtein,
  getBlocklistCount: () => BLOOM_N,
  getDatasetManifest: () => datasetManifest,
  getBloomParameters: () => ({
    n: BLOOM_N,
    mBits: BLOOM_M_BITS,
    mBytes: BLOOM_M_BYTES,
    kHashes: BLOOM_K_HASHES,
    targetFpr: BLOOM_TARGET_FPR
  })
};
