/**
 * automata_engine.js
 * 
 * Formal Language & Automata Theory Engine for Password Policy Verification:
 * 1. Thompson-style Non-deterministic Finite Automaton (NFA) construction
 *    - Literal Blacklist pattern matching
 *    - Repeated character detection (e.g. 'aaa')
 *    - Ascending sequential patterns (e.g. 'abc', '123')
 *    - Descending sequential patterns (e.g. 'cba', '321')
 *    - NFA Union with epsilon transitions
 * 2. Deterministic Finite Automaton (DFA) Subset Construction
 *    - Epsilon-closure computation
 *    - Powerset construction to deterministic state machine
 * 3. Hopcroft's DFA State Minimization Algorithm
 *    - O(k * |S| log |S|) partition refinement
 *    - Canonical state reduction with compression metric calculation
 * 4. O(N) Execution Engine & Trace Simulator
 *    - Step-by-step state transition recorder for visual inspection
 */

class NFAState {
  constructor(id, isMatch = false) {
    this.id = id;
    this.isMatch = isMatch;
    this.transitions = new Map(); // char -> Array<int>
    this.eps = []; // Array<int>
  }
}

class NFA {
  constructor() {
    this.startState = 0;
    this.states = [];
  }

  static computeEpsilonClosure(nfa, stateSet) {
    const closure = new Set(stateSet);
    const stack = Array.from(stateSet);

    while (stack.length > 0) {
      const u = stack.pop();
      if (u >= 0 && u < nfa.states.length) {
        for (const v of nfa.states[u].eps) {
          if (!closure.has(v)) {
            closure.add(v);
            stack.push(v);
          }
        }
      }
    }
    return closure;
  }

  static buildLiteral(str) {
    const nfa = new NFA();
    if (!str || str.length === 0) {
      nfa.states.push(new NFAState(0, true));
      nfa.startState = 0;
      return nfa;
    }

    const len = str.length;
    for (let i = 0; i <= len; i++) {
      nfa.states.push(new NFAState(i, false));
    }

    for (let i = 0; i < len; i++) {
      const ch = str[i];
      const lower = ch.toLowerCase();
      const upper = ch.toUpperCase();

      if (!nfa.states[i].transitions.has(lower)) {
        nfa.states[i].transitions.set(lower, []);
      }
      nfa.states[i].transitions.get(lower).push(i + 1);

      if (lower !== upper) {
        if (!nfa.states[i].transitions.has(upper)) {
          nfa.states[i].transitions.set(upper, []);
        }
        nfa.states[i].transitions.get(upper).push(i + 1);
      }
    }

    nfa.states[len].isMatch = true;
    // Self-loop on final match state for printable ASCII
    for (let c = 32; c <= 126; c++) {
      const charCode = String.fromCharCode(c);
      if (!nfa.states[len].transitions.has(charCode)) {
        nfa.states[len].transitions.set(charCode, []);
      }
      nfa.states[len].transitions.get(charCode).push(len);
    }

    nfa.startState = 0;
    return nfa;
  }

  static buildRepeatedChar(threshold) {
    const nfa = new NFA();
    if (threshold <= 1) {
      const s0 = new NFAState(0, false);
      const s1 = new NFAState(1, true);
      for (let c = 32; c <= 126; c++) {
        const ch = String.fromCharCode(c);
        s0.transitions.set(ch, [1]);
        s1.transitions.set(ch, [1]);
      }
      nfa.states = [s0, s1];
      nfa.startState = 0;
      return nfa;
    }

    const s0 = new NFAState(0, false);
    const s1 = new NFAState(1, true);
    for (let c = 32; c <= 126; c++) {
      s1.transitions.set(String.fromCharCode(c), [1]);
    }
    nfa.states.push(s0, s1);

    let nextId = 2;
    for (let c = 32; c <= 126; c++) {
      const ch = String.fromCharCode(c);
      let prev = 0;
      for (let step = 1; step < threshold; step++) {
        const curr = nextId++;
        const st = new NFAState(curr, false);
        nfa.states.push(st);
        if (!nfa.states[prev].transitions.has(ch)) {
          nfa.states[prev].transitions.set(ch, []);
        }
        nfa.states[prev].transitions.get(ch).push(curr);
        prev = curr;
      }
      if (!nfa.states[prev].transitions.has(ch)) {
        nfa.states[prev].transitions.set(ch, []);
      }
      nfa.states[prev].transitions.get(ch).push(1);
    }

    nfa.startState = 0;
    return nfa;
  }

  static buildAscendingSequence(threshold) {
    const nfa = new NFA();
    if (threshold <= 1) return this.buildRepeatedChar(threshold);

    const s0 = new NFAState(0, false);
    const s1 = new NFAState(1, true);
    for (let c = 32; c <= 126; c++) {
      s1.transitions.set(String.fromCharCode(c), [1]);
    }
    nfa.states.push(s0, s1);

    let nextId = 2;
    for (let c = 32; c <= 126 - (threshold - 1); c++) {
      let prev = 0;
      for (let step = 0; step < threshold - 1; step++) {
        const ch = String.fromCharCode(c + step);
        const curr = nextId++;
        const st = new NFAState(curr, false);
        nfa.states.push(st);
        if (!nfa.states[prev].transitions.has(ch)) {
          nfa.states[prev].transitions.set(ch, []);
        }
        nfa.states[prev].transitions.get(ch).push(curr);
        prev = curr;
      }
      const lastCh = String.fromCharCode(c + threshold - 1);
      if (!nfa.states[prev].transitions.has(lastCh)) {
        nfa.states[prev].transitions.set(lastCh, []);
      }
      nfa.states[prev].transitions.get(lastCh).push(1);
    }

    nfa.startState = 0;
    return nfa;
  }

  static buildDescendingSequence(threshold) {
    const nfa = new NFA();
    if (threshold <= 1) return this.buildRepeatedChar(threshold);

    const s0 = new NFAState(0, false);
    const s1 = new NFAState(1, true);
    for (let c = 32; c <= 126; c++) {
      s1.transitions.set(String.fromCharCode(c), [1]);
    }
    nfa.states.push(s0, s1);

    let nextId = 2;
    for (let c = 32 + (threshold - 1); c <= 126; c++) {
      let prev = 0;
      for (let step = 0; step < threshold - 1; step++) {
        const ch = String.fromCharCode(c - step);
        const curr = nextId++;
        const st = new NFAState(curr, false);
        nfa.states.push(st);
        if (!nfa.states[prev].transitions.has(ch)) {
          nfa.states[prev].transitions.set(ch, []);
        }
        nfa.states[prev].transitions.get(ch).push(curr);
        prev = curr;
      }
      const lastCh = String.fromCharCode(c - (threshold - 1));
      if (!nfa.states[prev].transitions.has(lastCh)) {
        nfa.states[prev].transitions.set(lastCh, []);
      }
      nfa.states[prev].transitions.get(lastCh).push(1);
    }

    nfa.startState = 0;
    return nfa;
  }

  static unionAll(nfas) {
    const combined = new NFA();
    const start = new NFAState(0, false);

    // Self-loop on start state for search anywhere in text
    for (let c = 32; c <= 126; c++) {
      start.transitions.set(String.fromCharCode(c), [0]);
    }
    combined.states.push(start);
    combined.startState = 0;

    for (const sub of nfas) {
      if (!sub || sub.states.length === 0) continue;
      const offset = combined.states.length;

      for (const st of sub.states) {
        const newSt = new NFAState(st.id + offset, st.isMatch);
        for (const [ch, targets] of st.transitions.entries()) {
          newSt.transitions.set(ch, targets.map(t => t + offset));
        }
        newSt.eps = st.eps.map(ep => ep + offset);
        combined.states.push(newSt);
      }

      // Epsilon transition from root
      combined.states[0].eps.push(sub.startState + offset);
    }

    return combined;
  }
}

class DFAState {
  constructor(id, isRejectState = false) {
    this.id = id;
    this.isRejectState = isRejectState;
    this.transitions = new Int32Array(128);
    this.transitions.fill(0);
  }
}

class DFA {
  constructor() {
    this.startState = 0;
    this.states = [];
    this.rawDfaStateCount = 0;
  }

  static fromNFA(nfa) {
    const dfa = new DFA();
    if (!nfa || nfa.states.length === 0) return dfa;

    const initialSet = NFA.computeEpsilonClosure(nfa, [nfa.startState]);
    const setKey = (s) => Array.from(s).sort((a, b) => a - b).join(',');

    const subsetToId = new Map();
    const worklist = [];

    dfa.startState = 0;
    subsetToId.set(setKey(initialSet), 0);
    worklist.push(initialSet);

    let canonicalRejectId = -1;

    let s0IsReject = false;
    for (const s of initialSet) {
      if (s >= 0 && s < nfa.states.length && nfa.states[s].isMatch) {
        s0IsReject = true;
        canonicalRejectId = 0;
        break;
      }
    }

    dfa.states.push(new DFAState(0, s0IsReject));

    let worklistIdx = 0;
    while (worklistIdx < worklist.length) {
      const U = worklist[worklistIdx++];
      const uId = subsetToId.get(setKey(U));

      if (dfa.states[uId].isRejectState) {
        for (let c = 0; c < 128; c++) {
          dfa.states[uId].transitions[c] = uId;
        }
        continue;
      }

      for (let c = 32; c <= 126; c++) {
        const ch = String.fromCharCode(c);
        const moveSet = new Set();

        for (const s of U) {
          if (s >= 0 && s < nfa.states.length) {
            const targets = nfa.states[s].transitions.get(ch);
            if (targets) {
              for (const nextS of targets) moveSet.add(nextS);
            }
          }
        }

        const closure = NFA.computeEpsilonClosure(nfa, moveSet);
        if (closure.size === 0) {
          dfa.states[uId].transitions[c] = 0;
        } else {
          let isMatchClosure = false;
          for (const s of closure) {
            if (s >= 0 && s < nfa.states.length && nfa.states[s].isMatch) {
              isMatchClosure = true;
              break;
            }
          }

          if (isMatchClosure) {
            if (canonicalRejectId === -1) {
              canonicalRejectId = dfa.states.length;
              const rejectState = new DFAState(canonicalRejectId, true);
              for (let i = 0; i < 128; i++) rejectState.transitions[i] = canonicalRejectId;
              dfa.states.push(rejectState);
            }
            dfa.states[uId].transitions[c] = canonicalRejectId;
          } else {
            const k = setKey(closure);
            if (!subsetToId.has(k)) {
              const nextId = dfa.states.length;
              subsetToId.set(k, nextId);
              dfa.states.push(new DFAState(nextId, false));
              worklist.push(closure);
              dfa.states[uId].transitions[c] = nextId;
            } else {
              dfa.states[uId].transitions[c] = subsetToId.get(k);
            }
          }
        }
      }

      for (let c = 0; c < 128; c++) {
        if (c < 32 || c > 126) dfa.states[uId].transitions[c] = 0;
      }
    }

    dfa.rawDfaStateCount = dfa.states.length;
    return dfa;
  }

  minimizeHopcroft() {
    const n = this.states.length;
    if (n <= 1) {
      const copy = new DFA();
      copy.startState = this.startState;
      copy.states = this.states.map(s => {
        const ns = new DFAState(s.id, s.isRejectState);
        ns.transitions.set(s.transitions);
        return ns;
      });
      copy.rawDfaStateCount = n;
      return copy;
    }

    const F = new Set();
    const nonF = new Set();
    for (let i = 0; i < n; i++) {
      if (this.states[i].isRejectState) F.add(i);
      else nonF.add(i);
    }

    if (F.size === 0 || nonF.size === 0) {
      const minDfa = new DFA();
      minDfa.startState = 0;
      minDfa.rawDfaStateCount = n;
      const s0 = new DFAState(0, F.size > 0);
      minDfa.states.push(s0);
      return minDfa;
    }

    let P = [new Set(F), new Set(nonF)];
    const W = [new Set(F)];

    while (W.length > 0) {
      const A = W.pop();

      for (let c = 32; c <= 126; c++) {
        const X = new Set();
        for (let s = 0; s < n; s++) {
          const dest = this.states[s].transitions[c];
          if (A.has(dest)) X.add(s);
        }

        if (X.size === 0) continue;

        const nextP = [];
        for (const Y of P) {
          const Y1 = new Set();
          const Y2 = new Set();

          for (const s of Y) {
            if (X.has(s)) Y1.add(s);
            else Y2.add(s);
          }

          if (Y1.size > 0 && Y2.size > 0) {
            nextP.push(Y1, Y2);
            const wIdx = W.findIndex(w => w.size === Y.size && Array.from(w).every(val => Y.has(val)));
            if (wIdx !== -1) {
              W.splice(wIdx, 1);
              W.push(Y1, Y2);
            } else {
              W.push(Y1.size <= Y2.size ? Y1 : Y2);
            }
          } else {
            nextP.push(Y);
          }
        }
        P = nextP;
      }
    }

    const k = P.length;
    let startBlock = 0;
    for (let i = 0; i < k; i++) {
      if (P[i].has(this.startState)) {
        startBlock = i;
        break;
      }
    }
    if (startBlock !== 0) {
      const temp = P[0];
      P[0] = P[startBlock];
      P[startBlock] = temp;
    }

    const stateToBlock = new Int32Array(n);
    for (let i = 0; i < k; i++) {
      for (const s of P[i]) {
        stateToBlock[s] = i;
      }
    }

    const minDfa = new DFA();
    minDfa.startState = 0;
    minDfa.rawDfaStateCount = this.rawDfaStateCount > 0 ? this.rawDfaStateCount : n;
    minDfa.states = [];

    for (let i = 0; i < k; i++) {
      const rep = Array.from(P[i])[0];
      const s = new DFAState(i, this.states[rep].isRejectState);
      for (let c = 0; c < 128; c++) {
        const origTarget = this.states[rep].transitions[c];
        if (origTarget >= 0 && origTarget < n) {
          s.transitions[c] = stateToBlock[origTarget];
        } else {
          s.transitions[c] = 0;
        }
      }
      minDfa.states.push(s);
    }

    return minDfa;
  }

  simulate(input) {
    if (!this.states || this.states.length === 0) {
      return { accepted: false, rejected: false, finalState: 0, trace: [] };
    }

    let curr = this.startState;
    const trace = [];
    const isRejectAtStart = curr < this.states.length && this.states[curr].isRejectState;

    if (isRejectAtStart) {
      return {
        accepted: false,
        rejected: true,
        finalState: curr,
        trace: [{ step: 0, char: 'START', fromState: curr, toState: curr, isReject: true }]
      };
    }

    for (let i = 0; i < input.length; i++) {
      const ch = input[i];
      const code = ch.charCodeAt(0);
      const from = curr;
      if (code < 128) {
        curr = this.states[curr].transitions[code];
      } else {
        curr = 0;
      }
      const isReject = curr < this.states.length && this.states[curr].isRejectState;
      trace.push({
        step: i + 1,
        char: ch,
        fromState: from,
        toState: curr,
        isReject
      });

      if (isReject) {
        return { accepted: false, rejected: true, finalState: curr, trace };
      }
    }

    const finalReject = curr < this.states.length && this.states[curr].isRejectState;
    return {
      accepted: !finalReject,
      rejected: finalReject,
      finalState: curr,
      trace
    };
  }

  getTransitionTableSample(maxStates = 15) {
    const displayStates = this.states.slice(0, maxStates);
    const chars = ['a', 'b', 'c', '1', '2', '3', '@', '#', ' '];
    const table = [];

    for (const s of displayStates) {
      const row = {
        state: s.id,
        isReject: s.isRejectState,
        transitions: {}
      };
      for (const ch of chars) {
        row.transitions[ch] = s.transitions[ch.charCodeAt(0)];
      }
      table.push(row);
    }
    return table;
  }

  emitCppTable(tableName = "DFA_TRANSITION_TABLE") {
    const minStates = this.states.length;
    const rawStates = this.rawDfaStateCount > 0 ? this.rawDfaStateCount : minStates;
    const ratio = rawStates > 0 ? (((rawStates - minStates) / rawStates) * 100).toFixed(1) : "0.0";

    let out = `// AUTO-GENERATED MINIMAL DFA TRANSITION TABLE (Hopcroft Minimization)\n`;
    out += `// Raw DFA States: ${rawStates}, Minimized States: ${minStates}, Compression: ${ratio}%\n\n`;
    out += `static constexpr int ${tableName}_SIZE = ${minStates};\n`;
    out += `static constexpr int ${tableName}[${minStates}][128] = {\n`;

    for (let i = 0; i < minStates; i++) {
      out += `  /* State ${i}${this.states[i].isRejectState ? ' [REJECT]' : ''} */ { `;
      for (let c = 0; c < 128; c++) {
        out += `${this.states[i].transitions[c]}${c < 127 ? ',' : ''}`;
      }
      out += ` }${i < minStates - 1 ? ',' : ''}\n`;
    }
    out += `};\n\n`;

    out += `static constexpr bool ${tableName}_REJECT[${minStates}] = {\n  `;
    for (let i = 0; i < minStates; i++) {
      out += `${this.states[i].isRejectState ? 'true' : 'false'}${i < minStates - 1 ? ', ' : ''}`;
    }
    out += `\n};\n`;
    return out;
  }
}

/**
 * Automata Builder Helper for Compiled Policies
 */
class AutomataEngine {
  static buildAutomataForPolicy(options = {}) {
    const subNfas = [];

    // 1. Blacklist terms
    const blacklist = options.blacklist || ['password', '123456', 'admin', 'qwerty'];
    for (const term of blacklist) {
      if (term && term.length > 0) {
        subNfas.push(NFA.buildLiteral(term));
      }
    }

    // 2. Sequential patterns
    const maxSeq = options.maxSequence || 3;
    subNfas.push(NFA.buildAscendingSequence(maxSeq + 1));
    subNfas.push(NFA.buildDescendingSequence(maxSeq + 1));

    // 3. Repeated characters
    const maxRep = options.maxRepeated || 3;
    subNfas.push(NFA.buildRepeatedChar(maxRep + 1));

    // Union all into Master NFA
    const masterNfa = NFA.unionAll(subNfas);
    const nfaStateCount = masterNfa.states.length;

    // Subset Construction to DFA
    const rawDfa = DFA.fromNFA(masterNfa);
    const rawDfaStateCount = rawDfa.states.length;

    // Hopcroft Minimization
    const minDfa = rawDfa.minimizeHopcroft();
    const minDfaStateCount = minDfa.states.length;

    const compressionRatio = rawDfaStateCount > 0
      ? (((rawDfaStateCount - minDfaStateCount) / rawDfaStateCount) * 100)
      : 0.0;

    return {
      nfa: masterNfa,
      rawDfa,
      minDfa,
      metrics: {
        nfaStateCount,
        rawDfaStateCount,
        minDfaStateCount,
        compressionRatio: parseFloat(compressionRatio.toFixed(2))
      }
    };
  }
}

module.exports = {
  NFAState,
  NFA,
  DFAState,
  DFA,
  AutomataEngine
};
