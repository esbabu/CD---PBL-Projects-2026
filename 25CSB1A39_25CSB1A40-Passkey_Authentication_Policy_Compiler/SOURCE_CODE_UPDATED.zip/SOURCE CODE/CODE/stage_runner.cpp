#include "stage_runner.h"
#include "json_helper.h"
#include "lexer.h"
#include "parser.h"
#include "semantic.h"
#include "ir.h"
#include "ir_analyzer.h"
#include "codegen.h"
#include "neurosymbolic.h"

#include <fstream>
#include <sstream>
#include <iostream>
#include <cmath>
#include <algorithm>

static std::string readEntireFile(const std::string& path) {
    std::ifstream f(path, std::ios::in | std::ios::binary);
    if (!f.is_open()) return "";
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

static bool writeEntireFile(const std::string& path, const std::string& content) {
    std::ofstream f(path, std::ios::out | std::ios::binary | std::ios::trunc);
    if (!f.is_open()) return false;
    f << content;
    return f.good();
}

bool validatePassword(const std::string& password, const PolicyConstraints& c) {
    int upper = 0, lower = 0, digit = 0, special = 0, spaces = 0;

    for (char ch : password) {
        if (isupper((unsigned char)ch)) upper++;
        else if (islower((unsigned char)ch)) lower++;
        else if (isdigit((unsigned char)ch)) digit++;
        else if (isspace((unsigned char)ch)) spaces++;
        else special++;
    }

    if (c.minLength != -1 && (int)password.size() < c.minLength) return false;
    if (c.maxLength != -1 && (int)password.size() > c.maxLength) return false;

    if (c.requireUpper == 1 && upper == 0) return false;
    if (c.requireUpper == 0 && upper > 0) return false;

    if (c.requireLower == 1 && lower == 0) return false;
    if (c.requireLower == 0 && lower > 0) return false;

    if (c.requireDigit == 1 && digit == 0) return false;
    if (c.requireDigit == 0 && digit > 0) return false;

    if (c.requireSpecial == 1 && special == 0) return false;
    if (c.requireSpecial == 0 && special > 0) return false;

    if (c.noSpaces == 1 && spaces > 0) return false;
    if (c.noSpaces == 0 && spaces == 0) return false;

    return true;
}

static TokenType stringToTokenType(const std::string& s) {
    if (s == "Identifier") return TokenType::Identifier;
    if (s == "Number") return TokenType::Number;
    if (s == "Boolean") return TokenType::Boolean;
    if (s == "Newline") return TokenType::Newline;
    if (s == "End") return TokenType::End;
    return TokenType::Unknown;
}

static JsonValue serializeError(const std::string& msg, int line = 0, int col = 0) {
    JsonValue err = JsonValue::makeObject();
    err.set("message", msg);
    err.set("line", line);
    err.set("col", col);
    return err;
}

static std::string extractDslInput(const JsonValue& root) {
    if (root.has("input")) return root.get("input").asString();
    if (root.has("source")) return root.get("source").asString();
    if (root.has("policy")) return root.get("policy").asString();
    if (root.has("code")) return root.get("code").asString();
    return "";
}

// ---------------------------------------------------------------------------
// STAGE 1: LEXER
// ---------------------------------------------------------------------------
static int runLexerStage(const JsonValue& inJson, JsonValue& outJson) {
    std::string dsl = extractDslInput(inJson);
    if (dsl.empty() && !inJson.has("input") && !inJson.has("source") && !inJson.has("policy")) {
        outJson.set("success", false);
        outJson.set("stage", "lexer");
        outJson.set("tokenCount", 0);
        outJson.set("tokens", JsonValue::makeArray());
        JsonValue errs = JsonValue::makeArray();
        errs.push(serializeError("Missing 'input' field in JSON payload for lexer stage", 0, 0));
        outJson.set("errors", std::move(errs));
        return 1;
    }

    Lexer lexer(dsl);
    std::vector<Token> tokens = lexer.tokenize();

    if (!lexer.errors().empty()) {
        outJson.set("success", false);
        outJson.set("stage", "lexer");
        outJson.set("tokenCount", 0);
        outJson.set("tokens", JsonValue::makeArray());
        JsonValue errs = JsonValue::makeArray();
        for (const auto& e : lexer.errors()) {
            errs.push(serializeError(e.message, e.pos.line, e.pos.col));
        }
        outJson.set("errors", std::move(errs));
        return 1;
    }

    outJson.set("success", true);
    outJson.set("stage", "lexer");
    outJson.set("tokenCount", static_cast<int>(tokens.size()));

    JsonValue tokenArray = JsonValue::makeArray();
    for (const auto& tok : tokens) {
        JsonValue tObj = JsonValue::makeObject();
        tObj.set("type", tokenTypeName(tok.type));
        tObj.set("lexeme", tok.lexeme);
        tObj.set("line", tok.pos.line);
        tObj.set("col", tok.pos.col);
        tokenArray.push(std::move(tObj));
    }
    outJson.set("tokens", std::move(tokenArray));
    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// STAGE 2: PARSER
// ---------------------------------------------------------------------------
static int runParserStage(const JsonValue& inJson, JsonValue& outJson) {
    std::vector<Token> tokens;

    if (inJson.has("tokens") && inJson.get("tokens").isArray()) {
        const auto& arr = inJson.get("tokens").asArray();
        for (const auto& item : arr) {
            Token t;
            t.type = stringToTokenType(item.get("type").asString());
            t.lexeme = item.get("lexeme").asString();
            t.pos.line = item.get("line").asInt(1);
            t.pos.col = item.get("col").asInt(1);
            tokens.push_back(t);
        }
        if (tokens.empty() || tokens.back().type != TokenType::End) {
            Token endTok;
            endTok.type = TokenType::End;
            endTok.lexeme = "EOF";
            endTok.pos = tokens.empty() ? SourcePos{1, 1} : tokens.back().pos;
            tokens.push_back(endTok);
        }
    } else {
        std::string dsl = extractDslInput(inJson);
        if (dsl.empty() && !inJson.has("input")) {
            outJson.set("success", false);
            outJson.set("stage", "parser");
            outJson.set("ruleCount", 0);
            outJson.set("ast", JsonValue::makeObject());
            JsonValue errs = JsonValue::makeArray();
            errs.push(serializeError("Missing 'tokens' or 'input' in JSON payload for parser stage", 0, 0));
            outJson.set("errors", std::move(errs));
            return 1;
        }
        Lexer lexer(dsl);
        tokens = lexer.tokenize();
        if (!lexer.errors().empty()) {
            outJson.set("success", false);
            outJson.set("stage", "parser");
            outJson.set("ruleCount", 0);
            outJson.set("ast", JsonValue::makeObject());
            JsonValue errs = JsonValue::makeArray();
            for (const auto& e : lexer.errors()) {
                errs.push(serializeError(e.message, e.pos.line, e.pos.col));
            }
            outJson.set("errors", std::move(errs));
            return 1;
        }
    }

    Parser parser(tokens);
    ProgramNode prog = parser.parse();

    if (!parser.errors().empty()) {
        outJson.set("success", false);
        outJson.set("stage", "parser");
        outJson.set("ruleCount", 0);
        JsonValue astObj = JsonValue::makeObject();
        astObj.set("rules", JsonValue::makeArray());
        outJson.set("ast", std::move(astObj));

        JsonValue errs = JsonValue::makeArray();
        for (const auto& e : parser.errors()) {
            errs.push(serializeError(e.message, e.pos.line, e.pos.col));
        }
        outJson.set("errors", std::move(errs));
        return 1;
    }

    outJson.set("success", true);
    outJson.set("stage", "parser");
    outJson.set("ruleCount", static_cast<int>(prog.rules.size()));

    JsonValue astObj = JsonValue::makeObject();
    JsonValue rulesArr = JsonValue::makeArray();
    for (const auto& r : prog.rules) {
        JsonValue rObj = JsonValue::makeObject();
        rObj.set("name", r.name);
        rObj.set("value", r.value);
        rObj.set("line", r.pos.line);
        rObj.set("col", r.pos.col);
        rulesArr.push(std::move(rObj));
    }
    astObj.set("rules", std::move(rulesArr));
    outJson.set("ast", std::move(astObj));
    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// STAGE 3: SEMANTIC
// ---------------------------------------------------------------------------
static int runSemanticStage(const JsonValue& inJson, JsonValue& outJson) {
    ProgramNode prog;

    if (inJson.has("ast") && inJson.get("ast").has("rules")) {
        const auto& rules = inJson.get("ast").get("rules").asArray();
        for (const auto& r : rules) {
            RuleNode rn;
            rn.name = r.get("name").asString();
            rn.value = r.get("value").asString();
            rn.pos.line = r.get("line").asInt(1);
            rn.pos.col = r.get("col").asInt(1);
            prog.rules.push_back(rn);
        }
    } else if (inJson.has("rules") && inJson.get("rules").isArray()) {
        const auto& rules = inJson.get("rules").asArray();
        for (const auto& r : rules) {
            RuleNode rn;
            rn.name = r.get("name").asString();
            rn.value = r.get("value").asString();
            rn.pos.line = r.get("line").asInt(1);
            rn.pos.col = r.get("col").asInt(1);
            prog.rules.push_back(rn);
        }
    } else {
        // Fallback: parse from input or tokens
        JsonValue parseOut;
        int parseRes = runParserStage(inJson, parseOut);
        if (parseRes != 0 || !parseOut.get("success").asBool()) {
            outJson = parseOut;
            outJson.set("stage", "semantic");
            return 1;
        }
        const auto& rules = parseOut.get("ast").get("rules").asArray();
        for (const auto& r : rules) {
            RuleNode rn;
            rn.name = r.get("name").asString();
            rn.value = r.get("value").asString();
            rn.pos.line = r.get("line").asInt(1);
            rn.pos.col = r.get("col").asInt(1);
            prog.rules.push_back(rn);
        }
    }

    SemanticAnalyzer sem;
    sem.analyze(prog);

    if (!sem.errors().empty()) {
        outJson.set("success", false);
        outJson.set("stage", "semantic");
        outJson.set("constraints", JsonValue::makeObject());
        JsonValue errs = JsonValue::makeArray();
        for (const auto& e : sem.errors()) {
            errs.push(serializeError(e.message, e.pos.line, e.pos.col));
        }
        outJson.set("errors", std::move(errs));
        return 1;
    }

    const auto& c = sem.getConstraints();
    outJson.set("success", true);
    outJson.set("stage", "semantic");

    JsonValue cObj = JsonValue::makeObject();
    cObj.set("minLength", c.minLength);
    cObj.set("maxLength", c.maxLength);
    cObj.set("requireUpper", c.requireUpper);
    cObj.set("requireLower", c.requireLower);
    cObj.set("requireDigit", c.requireDigit);
    cObj.set("requireSpecial", c.requireSpecial);
    cObj.set("noSpaces", c.noSpaces);
    outJson.set("constraints", std::move(cObj));

    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// Helper: Extract PolicyConstraints from JSON
// ---------------------------------------------------------------------------
static bool extractConstraints(const JsonValue& inJson, PolicyConstraints& c, JsonValue& errOut) {
    if (inJson.has("constraints") && inJson.get("constraints").isObject()) {
        const auto& obj = inJson.get("constraints");
        c.minLength = obj.get("minLength").asInt(-1);
        c.maxLength = obj.get("maxLength").asInt(-1);
        c.requireUpper = obj.get("requireUpper").asInt(-1);
        c.requireLower = obj.get("requireLower").asInt(-1);
        c.requireDigit = obj.get("requireDigit").asInt(-1);
        c.requireSpecial = obj.get("requireSpecial").asInt(-1);
        c.noSpaces = obj.get("noSpaces").asInt(-1);
        return true;
    }

    // Run semantic stage to obtain constraints
    JsonValue semOut;
    int res = runSemanticStage(inJson, semOut);
    if (res != 0 || !semOut.get("success").asBool()) {
        errOut = semOut;
        return false;
    }
    const auto& obj = semOut.get("constraints");
    c.minLength = obj.get("minLength").asInt(-1);
    c.maxLength = obj.get("maxLength").asInt(-1);
    c.requireUpper = obj.get("requireUpper").asInt(-1);
    c.requireLower = obj.get("requireLower").asInt(-1);
    c.requireDigit = obj.get("requireDigit").asInt(-1);
    c.requireSpecial = obj.get("requireSpecial").asInt(-1);
    c.noSpaces = obj.get("noSpaces").asInt(-1);
    return true;
}

// ---------------------------------------------------------------------------
// STAGE 4: IR
// ---------------------------------------------------------------------------
static int runIRStage(const JsonValue& inJson, JsonValue& outJson) {
    PolicyConstraints c;
    JsonValue errOut;
    if (!extractConstraints(inJson, c, errOut)) {
        outJson = errOut;
        outJson.set("stage", "ir");
        return 1;
    }

    PolicyIR ir = buildIR(c);
    auto warnings = IRAnalyzer::analyze(ir);

    outJson.set("success", true);
    outJson.set("stage", "ir");

    JsonValue cObj = JsonValue::makeObject();
    cObj.set("minLength", c.minLength);
    cObj.set("maxLength", c.maxLength);
    cObj.set("requireUpper", c.requireUpper);
    cObj.set("requireLower", c.requireLower);
    cObj.set("requireDigit", c.requireDigit);
    cObj.set("requireSpecial", c.requireSpecial);
    cObj.set("noSpaces", c.noSpaces);
    outJson.set("constraints", std::move(cObj));

    JsonValue irObj = JsonValue::makeObject();
    irObj.set("minLength", ir.minLength);
    irObj.set("maxLength", ir.maxLength);
    irObj.set("requireUpper", ir.requireUpper);
    irObj.set("requireLower", ir.requireLower);
    irObj.set("requireDigit", ir.requireDigit);
    irObj.set("requireSpecial", ir.requireSpecial);
    irObj.set("noSpaces", ir.noSpaces);
    outJson.set("ir", std::move(irObj));

    JsonValue warnArr = JsonValue::makeArray();
    for (const auto& w : warnings) {
        warnArr.push(JsonValue(w.message));
    }
    outJson.set("warnings", std::move(warnArr));
    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// STAGE 5: CODEGEN
// ---------------------------------------------------------------------------
static int runCodegenStage(const JsonValue& inJson, JsonValue& outJson) {
    PolicyConstraints c;
    JsonValue errOut;
    if (!extractConstraints(inJson, c, errOut)) {
        outJson = errOut;
        outJson.set("stage", "codegen");
        return 1;
    }

    std::string target = inJson.has("target") ? inJson.get("target").asString("cpp") : "cpp";
    std::string outFile = inJson.has("outputFile") ? inJson.get("outputFile").asString("generated_validator.cpp") : "generated_validator.cpp";

    try {
        CodeGenerator::generate(c, outFile);
    } catch (const std::exception& ex) {
        outJson.set("success", false);
        outJson.set("stage", "codegen");
        JsonValue errs = JsonValue::makeArray();
        errs.push(serializeError(std::string("Code generator exception: ") + ex.what(), 0, 0));
        outJson.set("errors", std::move(errs));
        return 1;
    }

    std::string generatedCode = readEntireFile(outFile);

    outJson.set("success", true);
    outJson.set("stage", "codegen");
    outJson.set("target", target);
    outJson.set("outputFile", outFile);
    outJson.set("codeLength", static_cast<int>(generatedCode.size()));
    outJson.set("code", generatedCode);

    JsonValue cObj = JsonValue::makeObject();
    cObj.set("minLength", c.minLength);
    cObj.set("maxLength", c.maxLength);
    cObj.set("requireUpper", c.requireUpper);
    cObj.set("requireLower", c.requireLower);
    cObj.set("requireDigit", c.requireDigit);
    cObj.set("requireSpecial", c.requireSpecial);
    cObj.set("noSpaces", c.noSpaces);
    outJson.set("constraints", std::move(cObj));

    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// STAGE 6: TEST
// ---------------------------------------------------------------------------
static int runTestStage(const JsonValue& inJson, JsonValue& outJson) {
    PolicyConstraints c;
    JsonValue errOut;
    if (!extractConstraints(inJson, c, errOut)) {
        outJson = errOut;
        outJson.set("stage", "test");
        return 1;
    }

    std::vector<std::string> testPasswords;

    if (inJson.has("password") && inJson.get("password").isString()) {
        testPasswords.push_back(inJson.get("password").asString());
    } else if (inJson.has("passwords") && inJson.get("passwords").isArray()) {
        for (const auto& item : inJson.get("passwords").asArray()) {
            testPasswords.push_back(item.asString());
        }
    } else if (inJson.has("testVectors") && inJson.get("testVectors").isArray()) {
        for (const auto& item : inJson.get("testVectors").asArray()) {
            if (item.isString()) {
                testPasswords.push_back(item.asString());
            } else if (item.isObject() && item.has("password")) {
                testPasswords.push_back(item.get("password").asString());
            }
        }
    }

    // Default canonical test suite if none supplied
    if (testPasswords.empty()) {
        testPasswords.push_back("CorrectHorseBatteryStaple99!"); // strong
        testPasswords.push_back("short1!");                     // too short
        testPasswords.push_back("alllowercaseletters123!");      // might miss upper
        testPasswords.push_back("NOLOWERCASEHERE1234!");        // might miss lower
        testPasswords.push_back("NoDigitsAllowedHere!!");        // might miss digit
        testPasswords.push_back("Password With Spaces 123!");   // tests space constraint
    }

    JsonValue resultsArr = JsonValue::makeArray();
    int passedCount = 0;

    for (const auto& pwd : testPasswords) {
        bool isValid = validatePassword(pwd, c);
        NSResult ns = NeuroSymbolicEvaluator::evaluate(pwd, c);

        if (isValid) passedCount++;

        JsonValue resObj = JsonValue::makeObject();
        resObj.set("password", pwd);
        resObj.set("isValid", isValid);
        resObj.set("score", ns.score);
        resObj.set("level", ns.level);

        JsonValue reasonsArr = JsonValue::makeArray();
        for (const auto& r : ns.reasons) {
            reasonsArr.push(JsonValue(r));
        }
        resObj.set("reasons", std::move(reasonsArr));
        resultsArr.push(std::move(resObj));
    }

    outJson.set("success", true);
    outJson.set("stage", "test");
    outJson.set("totalTested", static_cast<int>(testPasswords.size()));
    outJson.set("validCount", passedCount);
    outJson.set("allPassed", passedCount > 0);
    outJson.set("results", std::move(resultsArr));
    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// STAGE 7: AUDIT
// ---------------------------------------------------------------------------
static int runAuditStage(const JsonValue& inJson, JsonValue& outJson) {
    PolicyConstraints c;
    JsonValue errOut;
    if (!extractConstraints(inJson, c, errOut)) {
        outJson = errOut;
        outJson.set("stage", "audit");
        return 1;
    }

    // Contradiction Check
    if (c.minLength != -1 && c.maxLength != -1 && c.minLength > c.maxLength) {
        outJson.set("success", false);
        outJson.set("stage", "audit");
        outJson.set("nistCompliant", false);
        outJson.set("score", 0);
        outJson.set("riskLevel", "CRITICAL");
        JsonValue errs = JsonValue::makeArray();
        errs.push(serializeError("Contradictory policy constraints: minLength (" +
                                 std::to_string(c.minLength) + ") exceeds maxLength (" +
                                 std::to_string(c.maxLength) + ")", 0, 0));
        outJson.set("errors", std::move(errs));
        return 1;
    }

    int score = 100;
    bool nistCompliant = true;
    JsonValue findings = JsonValue::makeArray();
    JsonValue recommendations = JsonValue::makeArray();

    // 1. Min Length check
    if (c.minLength == -1) {
        score -= 40;
        nistCompliant = false;
        findings.push("CRITICAL: No minimum length specified. NIST SP 800-63B requires at least 8 characters.");
        recommendations.push("Enforce a minimum length of at least 8 characters (15+ recommended).");
    } else if (c.minLength < 8) {
        score -= 40;
        nistCompliant = false;
        findings.push("CRITICAL: Minimum length (" + std::to_string(c.minLength) +
                      ") is under the 8-character floor required by NIST SP 800-63B Section 5.1.1.2.");
        recommendations.push("Increase minimum length to >= 8 characters.");
    } else if (c.minLength < 15) {
        score -= 5;
        findings.push("PASS: Minimum length (" + std::to_string(c.minLength) + ") satisfies NIST baseline.");
        recommendations.push("Consider increasing to 15+ characters to facilitate long passphrase defense.");
    } else {
        findings.push("EXCELLENT: Minimum length (" + std::to_string(c.minLength) +
                      ") satisfies NIST passphrase recommendations.");
    }

    // 2. Max Length check
    if (c.maxLength != -1 && c.maxLength < 64) {
        score -= 15;
        findings.push("WARN: Maximum length (" + std::to_string(c.maxLength) +
                      ") is below NIST SP 800-63B recommendation of at least 64 characters.");
        recommendations.push("Allow passwords of at least 64 characters to avoid truncating passphrases.");
    } else {
        findings.push("PASS: Maximum length permits resilient multi-word passphrases.");
    }

    // 3. Composition Rules Evaluation
    int compositionCount = 0;
    if (c.requireUpper == 1) compositionCount++;
    if (c.requireLower == 1) compositionCount++;
    if (c.requireDigit == 1) compositionCount++;
    if (c.requireSpecial == 1) compositionCount++;

    if (compositionCount >= 3) {
        findings.push("INFO: Multiple mandatory composition rules enforced (" +
                      std::to_string(compositionCount) + " rules). NIST SP 800-63B notes that strict composition "
                      "rules lead to predictable human substitutions rather than genuine entropy.");
        recommendations.push("Emphasize length and breach blocklisting over rigid composition requirements.");
    }

    if (c.noSpaces == 1) {
        score -= 5;
        findings.push("WARN: Space characters are prohibited. NIST recommends allowing space characters.");
        recommendations.push("Allow spaces to encourage natural multi-word passphrases.");
    }

    // 4. Theoretical Entropy Lower Bound
    int poolSize = 26; // lowercase
    if (c.requireUpper != 0) poolSize += 26;
    if (c.requireDigit != 0) poolSize += 10;
    if (c.requireSpecial != 0) poolSize += 32;
    if (c.noSpaces == 0) poolSize += 1;

    int effMin = (c.minLength > 0) ? c.minLength : 8;
    double entropyLowerBound = effMin * (std::log(static_cast<double>(poolSize)) / std::log(2.0));

    std::string riskLevel;
    if (score >= 85) riskLevel = "LOW";
    else if (score >= 70) riskLevel = "MEDIUM";
    else if (score >= 50) riskLevel = "HIGH";
    else riskLevel = "CRITICAL";

    outJson.set("success", true);
    outJson.set("stage", "audit");
    outJson.set("nistCompliant", nistCompliant);
    outJson.set("score", score);
    outJson.set("riskLevel", riskLevel);
    outJson.set("entropyLowerBound", std::round(entropyLowerBound * 10.0) / 10.0);
    outJson.set("findings", std::move(findings));
    outJson.set("recommendations", std::move(recommendations));

    // Optional password candidate evaluation if provided
    if (inJson.has("password") && inJson.get("password").isString()) {
        std::string pwd = inJson.get("password").asString();
        bool valid = validatePassword(pwd, c);
        NSResult ns = NeuroSymbolicEvaluator::evaluate(pwd, c);

        JsonValue pwdAudit = JsonValue::makeObject();
        pwdAudit.set("candidatePassword", pwd);
        pwdAudit.set("meetsPolicy", valid);
        pwdAudit.set("strengthScore", ns.score);
        pwdAudit.set("tier", ns.level);
        outJson.set("passwordAudit", std::move(pwdAudit));
    }

    outJson.set("errors", JsonValue::makeArray());
    return 0;
}

// ---------------------------------------------------------------------------
// MAIN STAGE RUNNER ENTRYPOINT
// ---------------------------------------------------------------------------
int runStageMode(const std::string& stage, const std::string& inFile, const std::string& outFile) {
    std::string inContent = readEntireFile(inFile);
    if (inContent.empty()) {
        std::ifstream chk(inFile);
        if (!chk.is_open()) {
            JsonValue errJson = JsonValue::makeObject();
            errJson.set("success", false);
            errJson.set("stage", stage);
            JsonValue errs = JsonValue::makeArray();
            errs.push(serializeError("Cannot open input file: " + inFile, 0, 0));
            errJson.set("errors", std::move(errs));
            writeEntireFile(outFile, errJson.serialize(0, 2));
            std::cerr << "Stage [" << stage << "] Error: Cannot open input file: " << inFile << "\n";
            return 1;
        }
    }

    std::string parseErr;
    JsonValue inJson = JsonValue::parse(inContent, parseErr);
    if (!parseErr.empty()) {
        JsonValue errJson = JsonValue::makeObject();
        errJson.set("success", false);
        errJson.set("stage", stage);
        JsonValue errs = JsonValue::makeArray();
        errs.push(serializeError("JSON parsing error in input file: " + parseErr, 0, 0));
        errJson.set("errors", std::move(errs));
        writeEntireFile(outFile, errJson.serialize(0, 2));
        std::cerr << "Stage [" << stage << "] Error: Invalid JSON input: " << parseErr << "\n";
        return 1;
    }

    JsonValue outJson = JsonValue::makeObject();
    int exitCode = 0;

    if (stage == "lexer") {
        exitCode = runLexerStage(inJson, outJson);
    } else if (stage == "parser") {
        exitCode = runParserStage(inJson, outJson);
    } else if (stage == "semantic") {
        exitCode = runSemanticStage(inJson, outJson);
    } else if (stage == "ir") {
        exitCode = runIRStage(inJson, outJson);
    } else if (stage == "codegen") {
        exitCode = runCodegenStage(inJson, outJson);
    } else if (stage == "test") {
        exitCode = runTestStage(inJson, outJson);
    } else if (stage == "audit") {
        exitCode = runAuditStage(inJson, outJson);
    } else {
        outJson.set("success", false);
        outJson.set("stage", stage);
        JsonValue errs = JsonValue::makeArray();
        errs.push(serializeError("Unknown compilation stage: '" + stage + "'. Allowed: lexer, parser, semantic, ir, codegen, test, audit", 0, 0));
        outJson.set("errors", std::move(errs));
        exitCode = 1;
    }

    std::string serialized = outJson.serialize(0, 2);
    if (!writeEntireFile(outFile, serialized)) {
        std::cerr << "Stage [" << stage << "] Error: Failed to write output JSON to " << outFile << "\n";
        return 1;
    }

    return exitCode;
}
