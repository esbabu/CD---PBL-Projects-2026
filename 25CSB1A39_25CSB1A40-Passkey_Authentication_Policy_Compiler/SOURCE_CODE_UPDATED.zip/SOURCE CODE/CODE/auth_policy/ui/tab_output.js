/**
 * ui/tab_output.js
 * 
 * Tab 2: Compilation Output, Agent Pipeline Table, NIST Assurance, and Security Score.
 * Belongs to the User Interface subsystem.
 * Inputs: Compilation results bundle. Outputs: Rendered output panel.
 */

'use strict';

// Determines qualitative label and accent color for security audit score
function getScoreRating(score) {
  if (score >= 90) return { label: 'Strong', color: '#059669' };
  if (score >= 75) return { label: 'Good', color: '#4f46e5' };
  if (score >= 50) return { label: 'Needs work', color: '#b45309' };
  return { label: 'Weak', color: '#dc2626' };
}

// Renders the initial layout for Compile Output tab
function pkRenderOutputTab() {
  return `
    <div class="pk-card" style="padding:10px 12px;">
      <div class="pk-card-title" style="margin-bottom:2px; font-size:12.5px;">
        <span>Agent Pipeline</span>
      </div>
      <div style="font-size:10.5px; color:#64748b; margin-bottom:8px;">7 stages, each signed with Ed25519</div>
      <div id="pk-pipeline-strip">
        <div style="font-size:11.5px; color:#64748b;">No policy compiled yet. Go to Tab 1 and click 'Compile Policy'.</div>
      </div>
    </div>

    <div class="pk-grid-2" style="gap:10px; align-items:stretch;">
      <div class="pk-card" style="padding:10px 12px; display:flex; flex-direction:column;">
        <div class="pk-card-title" style="margin-bottom:8px; font-size:12.5px;">
          <span>NIST SP 800-63B-4 Assurance</span>
        </div>
        <div id="pk-nist-card-body" style="font-size:11.5px; color:#64748b; flex:1;">
          Awaiting compilation...
        </div>
      </div>

      <div class="pk-card" style="padding:10px 12px; display:flex; flex-direction:column;">
        <div class="pk-card-title" style="margin-bottom:8px; font-size:12.5px;">
          <span>Security Audit Score &amp; Checklist</span>
        </div>
        <div id="pk-audit-card-body" style="font-size:11.5px; color:#64748b; flex:1;">
          Awaiting compilation...
        </div>
      </div>
    </div>
  `;
}

// Updates output tab with live compiled policy data
function pkUpdateOutputTab(data) {
  const strip = document.getElementById('pk-pipeline-strip');
  const nistBody = document.getElementById('pk-nist-card-body');
  const auditBody = document.getElementById('pk-audit-card-body');

  if (!strip || !data) return;

  // 1. Pipeline table (compact, no emojis, plain badges)
  if (Array.isArray(data.stages)) {
    let rowsHtml = '';
    data.stages.forEach(stg => {
      const isOk = stg.ok;
      const sigOk = stg.signatureValid;
      const statusBadge = `<span class="pk-badge ${isOk ? 'pk-badge-pass' : 'pk-badge-fail'}" style="padding:1px 6px; font-size:10px;">${isOk ? 'PASS' : 'FAIL'}</span>`;
      const sigText = sigOk
        ? '<span style="color:#059669; font-weight:600;">Valid</span>'
        : '<span style="color:#dc2626; font-weight:600;">Invalid</span>';
      rowsHtml += `
        <tr>
          <td style="padding:3px 8px; font-family:'JetBrains Mono',monospace; font-weight:600; color:#334155;">${stg.agentId}</td>
          <td style="padding:3px 8px; color:#0f172a;">${stg.name}</td>
          <td style="padding:3px 8px;">${statusBadge}</td>
          <td style="padding:3px 8px; font-family:'JetBrains Mono',monospace; color:#64748b;">${stg.latencyMs} ms</td>
          <td style="padding:3px 8px;">${sigText}</td>
        </tr>
      `;
    });
    strip.innerHTML = `
      <table class="pk-table" style="font-size:11.5px;">
        <thead>
          <tr>
            <th style="padding:4px 8px;">Agent</th>
            <th style="padding:4px 8px;">Stage</th>
            <th style="padding:4px 8px;">Status</th>
            <th style="padding:4px 8px;">Time</th>
            <th style="padding:4px 8px;">Signature</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    `;
  }

  // 2. NIST assurance box (compact, smaller padding, no emojis)
  if (data.assurance && nistBody) {
    const ass = data.assurance;
    const isPr = Boolean(ass.phishingResistant);
    nistBody.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px;">
        <span class="pk-badge pk-badge-info" style="font-size:10.5px; padding:2px 8px;">${ass.nistLevel}</span>
        <span style="font-size:11.5px; font-weight:600; color:${isPr ? '#059669' : '#b45309'};">
          Phishing-resistant: ${isPr ? 'Yes' : 'No'}
        </span>
      </div>
      <div style="font-size:11px; color:#334155; line-height:1.4;">${ass.description || ''}</div>
      <div style="margin-top:6px; font-size:9.5px; color:#94a3b8; font-style:italic;">Note: ${ass.disclaimer}</div>
    `;
  }

  // 3. Security score & compact checklist (progress bar, rating label, no emojis/bullets)
  if (data.auditReport && auditBody) {
    const rep = data.auditReport;
    const rating = getScoreRating(rep.score);
    const checklistHtml = (rep.checklist || []).map(c => {
      const isPass = c.status === 'PASS';
      const isWarn = c.status === 'WARN';
      const statusColor = isPass ? '#059669' : (isWarn ? '#b45309' : '#dc2626');
      return `
        <div style="border-bottom:1px solid #f1f5f9; padding-bottom:4px; margin-bottom:4px;">
          <div style="display:flex; justify-content:space-between; align-items:center; font-size:11px;">
            <span style="font-weight:600; color:#1e293b;">${c.category}</span>
            <span style="font-weight:700; font-family:'JetBrains Mono',monospace; font-size:10px; color:${statusColor};">${c.status}</span>
          </div>
          <div style="font-size:10.5px; color:#64748b; margin-top:1px; line-height:1.3;">${c.details}</div>
        </div>
      `;
    }).join('');

    auditBody.innerHTML = `
      <div style="display:flex; align-items:baseline; justify-content:space-between;">
        <div>
          <span style="font-size:22px; font-weight:800; color:#0f172a; font-family:'JetBrains Mono',monospace;">${rep.score}</span>
          <span style="font-size:11px; color:#94a3b8; font-weight:500;">/ 100</span>
        </div>
        <span style="font-size:11.5px; font-weight:700; color:${rating.color};">${rating.label}</span>
      </div>
      <div style="width:100%; height:4px; background:#e2e8f0; border-radius:2px; overflow:hidden; margin:6px 0 10px 0;">
        <div style="width:${Math.max(0, Math.min(100, rep.score))}%; height:100%; background:${rating.color}; border-radius:2px;"></div>
      </div>
      <div style="max-height:220px; overflow-y:auto; padding-right:4px;">${checklistHtml}</div>
    `;
  }
}

window.pkTabOutput = {
  render: pkRenderOutputTab,
  update: pkUpdateOutputTab
};
