/**
 * ui/tab_agents.js
 * 
 * Tab 6: Per-Agent Cryptographic Output Envelopes, Hash-Chained Audit Trail, and Report Exporters.
 * Belongs to the User Interface subsystem.
 * Inputs: Pipeline data and audit events. Outputs: Trail viewer and downloadable reports.
 */

'use strict';

let pkCurrentReport = null;

// Renders the Agents & Audit tab layout
function pkRenderAgentsTab() {
  return `
    <div class="pk-card">
      <div class="pk-card-title">
        <span>⑥ Cryptographic Audit Trail &amp; Compliance Reporting</span>
        <div style="display:flex; gap:8px;">
          <button class="pk-btn pk-btn-sec" onclick="window.pkTabAgents.downloadMarkdown()">
            📥 Download Report (.md)
          </button>
          <button class="pk-btn pk-btn-sec" onclick="window.pkTabAgents.downloadJson()">
            📥 Download Report (.json)
          </button>
          <button class="pk-btn pk-btn-primary" onclick="window.pkTabAgents.refreshAudit()">
            🔄 Refresh Audit Trail
          </button>
        </div>
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span style="font-size:12px; color:#64748b;">Append-Only Hash-Chained Log (SHA-256):</span>
        <span id="pk-audit-chain-badge" class="pk-badge pk-badge-pass">Chain Status: VERIFIED</span>
      </div>
      <div id="pk-audit-trail-container" style="max-height:280px; overflow-y:auto; border:1px solid #e2e8f0; border-radius:6px;">
        <div style="padding:16px; font-size:12px; color:#64748b; text-align:center;">Loading audit trail...</div>
      </div>
    </div>

    <div class="pk-card">
      <div class="pk-card-title">
        <span>Per-Agent Cryptographic Output Envelopes (Ed25519)</span>
      </div>
      <div id="pk-agent-envelopes-container">
        <div style="font-size:12px; color:#64748b;">Compile a policy in Tab 1 to inspect per-agent signed envelopes.</div>
      </div>
    </div>
  `;
}

// Refreshes the hash-chained audit trail from GET /api/auth-policy/audit
async function pkRefreshAudit() {
  const container = document.getElementById('pk-audit-trail-container');
  const badge = document.getElementById('pk-audit-chain-badge');
  if (!container) return;

  try {
    const res = await fetch('/api/auth-policy/audit');
    const data = await res.json();
    if (!data.ok) throw new Error(data.error);

    badge.className = data.chainValid ? 'pk-badge pk-badge-pass' : 'pk-badge pk-badge-fail';
    badge.innerText = data.chainValid ? 'Chain Status: 100% CRYPTOGRAPHICALLY INTACT' : 'Chain Status: TAMPER DETECTED';

    let html = `
      <table class="pk-table">
        <thead>
          <tr>
            <th>Seq #</th>
            <th>Timestamp</th>
            <th>Event Action</th>
            <th>User</th>
            <th>Record SHA-256</th>
            <th>Previous Hash Link</th>
          </tr>
        </thead>
        <tbody>
    `;

    data.auditLog.forEach(entry => {
      const ts = new Date(entry.timestamp).toLocaleTimeString();
      html += `
        <tr>
          <td><b style="color:#4f46e5;">#${entry.id}</b></td>
          <td style="font-family:'JetBrains Mono',monospace; font-size:11px;">${ts}</td>
          <td><span class="pk-badge pk-badge-info">${entry.action}</span></td>
          <td><b>${entry.username}</b></td>
          <td style="font-family:'JetBrains Mono',monospace; font-size:10.5px; color:#059669;" title="${entry.hash}">${entry.hash.substring(0, 16)}...</td>
          <td style="font-family:'JetBrains Mono',monospace; font-size:10.5px; color:#64748b;" title="${entry.prevHash}">${entry.prevHash.substring(0, 16)}...</td>
        </tr>
      `;
    });

    html += `</tbody></table>`;
    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div style="padding:16px; color:#dc2626; font-size:12px;">Failed to load audit trail: ${err.message}</div>`;
  }
}

// Updates envelopes view and stores report reference
function pkUpdateAgentsTab(data) {
  pkCurrentReport = data.auditReport;
  const container = document.getElementById('pk-agent-envelopes-container');
  if (!container || !data.stages) return;

  let html = '';
  data.stages.forEach(stg => {
    html += `
      <div style="margin-bottom:10px; border:1px solid #e2e8f0; border-radius:6px; padding:10px; background:#f8fafc;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <b style="font-size:12px; color:#0f172a;">${stg.agentId} ${stg.name}</b>
          <span class="pk-badge ${stg.signatureValid ? 'pk-badge-pass' : 'pk-badge-fail'}">
            ${stg.signatureValid ? 'Ed25519 Verified' : 'Sig Failed'}
          </span>
        </div>
        <pre class="pk-codebox" style="margin-top:8px; max-height:100px;">${JSON.stringify(stg.envelope, null, 2)}</pre>
      </div>
    `;
  });
  container.innerHTML = html;
  pkRefreshAudit();
}

// Helper to trigger browser file download
function pkTriggerDownload(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function pkDownloadMarkdown() {
  if (!pkCurrentReport || !pkCurrentReport.markdown) {
    const badge = document.getElementById('pk-audit-chain-badge');
    if (badge) {
      badge.className = 'pk-badge pk-badge-warn';
      badge.innerText = 'Please compile a policy first in Tab 1';
    }
    return;
  }
  pkTriggerDownload('auth_policy_security_audit.md', pkCurrentReport.markdown, 'text/markdown');
}

function pkDownloadJson() {
  if (!pkCurrentReport) {
    const badge = document.getElementById('pk-audit-chain-badge');
    if (badge) {
      badge.className = 'pk-badge pk-badge-warn';
      badge.innerText = 'Please compile a policy first in Tab 1';
    }
    return;
  }
  pkTriggerDownload('auth_policy_security_audit.json', JSON.stringify(pkCurrentReport, null, 2), 'application/json');
}

window.pkTabAgents = {
  render: pkRenderAgentsTab,
  update: pkUpdateAgentsTab,
  refreshAudit: pkRefreshAudit,
  downloadMarkdown: pkDownloadMarkdown,
  downloadJson: pkDownloadJson
};
