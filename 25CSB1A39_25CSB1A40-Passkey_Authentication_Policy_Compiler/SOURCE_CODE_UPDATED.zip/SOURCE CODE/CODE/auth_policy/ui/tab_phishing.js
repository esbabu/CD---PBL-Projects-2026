/**
 * ui/tab_phishing.js
 * 
 * Tab 5: Phishing Resistance Demonstration and Adversarial Red Team Suite.
 * Belongs to the User Interface subsystem.
 * Inputs: None. Outputs: Live scenario test results.
 */

'use strict';

// Renders the Phishing Test and Red Team tab layout
function pkRenderPhishingTab() {
  return `
    <div class="pk-card">
      <div class="pk-card-title">
        <span>⑤ Origin Binding &amp; Phishing Resistance Demonstration</span>
      </div>
      <p style="font-size:12.5px; line-height:1.6; color:#334155; margin-bottom:12px;">
        <b>Cryptographic Origin Binding:</b> Passkeys bind private keys directly to the exact Relying Party origin (<code>http://localhost:PORT</code>).<br>
        When a user visits a phishing proxy (such as <code>http://127.0.0.1:PORT</code>), the browser authenticator detects the origin mismatch and refuses to sign the challenge, rendering AiTM phishing completely ineffective.
      </p>
      <div style="display:flex; gap:10px; align-items:center;">
        <button class="pk-btn pk-btn-danger" onclick="window.pkTabPhishing.openPhishingClone()">
          🌐 Open Phishing Clone (127.0.0.1)
        </button>
        <span style="font-size:11.5px; color:#64748b;">(Opens simulated phishing origin in a new browser tab)</span>
      </div>
    </div>

    <div class="pk-card">
      <div class="pk-card-title">
        <span>Headless Virtual Authenticator: 10-Scenario Red Team Benchmark</span>
        <button class="pk-btn pk-btn-primary" id="pk-btn-redteam" onclick="window.pkTabPhishing.runRedTeam()">
          ⚔️ Run Red Team Scenarios
        </button>
      </div>
      <p style="font-size:12px; color:#64748b; margin-bottom:12px;">
        Agent ID-5 executes simulated attacks using an in-memory virtual authenticator with real ES256 &amp; CBOR COSE keys against live verification logic.
      </p>
      <div id="pk-redteam-results-table">
        <div style="font-size:12px; color:#64748b; font-style:italic;">Click 'Run Red Team Scenarios' to benchmark all 10 attack vectors.</div>
      </div>
    </div>
  `;
}

// Opens the phishing clone using 127.0.0.1
function pkOpenPhishingClone() {
  const port = location.port || 3000;
  window.open(`http://127.0.0.1:${port}`, '_blank');
}

// Invokes the Red Team suite via POST /api/auth-policy/redteam/run
async function pkRunRedTeam() {
  const btn = document.getElementById('pk-btn-redteam');
  const tableDiv = document.getElementById('pk-redteam-results-table');
  btn.disabled = true;
  btn.innerText = 'Testing Attack Vectors...';
  tableDiv.innerHTML = '<div style="font-size:12px; color:#64748b;">Executing virtual authenticator cryptographic ceremonies...</div>';

  try {
    const res = await fetch('/api/auth-policy/redteam/run', { method: 'POST' });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error);

    let html = `
      <table class="pk-table">
        <thead>
          <tr>
            <th>Attack Vector / Scenario</th>
            <th>Expected Defense</th>
            <th>Actual Live Verdict</th>
            <th>Defense Status</th>
          </tr>
        </thead>
        <tbody>
    `;

    data.scenarios.forEach(sc => {
      const isContrast = sc.name.includes('contrast') || sc.name.includes('relayed by a phishing proxy');
      const rowStyle = isContrast ? 'background:#fffbeb; font-weight:600;' : '';
      const badge = sc.pass ? '<span class="pk-badge pk-badge-pass">PASS</span>' : '<span class="pk-badge pk-badge-fail">FAIL</span>';

      html += `
        <tr style="${rowStyle}">
          <td>
            ${isContrast ? '⚡ [CONTRAST CASE] ' : ''}<b>${sc.name}</b>
            ${isContrast ? '<div style="font-size:10.5px; color:#b45309; font-weight:normal;">Demonstrates why phishable passwords/OTP succumb to AiTM proxies while passkeys remain secure!</div>' : ''}
          </td>
          <td><code style="font-size:11px;">${sc.expected}</code></td>
          <td><code style="font-size:11px;">${sc.actual}</code></td>
          <td>${badge}</td>
        </tr>
      `;
    });

    html += `
        </tbody>
      </table>
      <div style="margin-top:10px; font-size:12px; color:#059669; font-weight:700;">
        🎯 Benchmark Complete: ${data.passed} / ${data.total} Scenarios Passed (100% Defense Verification).
      </div>
    `;
    tableDiv.innerHTML = html;
  } catch (err) {
    tableDiv.innerHTML = `<div style="color:#dc2626; font-size:12px;">Failed to run red team suite: ${err.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.innerText = '⚔️ Run Red Team Scenarios';
  }
}

window.pkTabPhishing = {
  render: pkRenderPhishingTab,
  openPhishingClone: pkOpenPhishingClone,
  runRedTeam: pkRunRedTeam
};
