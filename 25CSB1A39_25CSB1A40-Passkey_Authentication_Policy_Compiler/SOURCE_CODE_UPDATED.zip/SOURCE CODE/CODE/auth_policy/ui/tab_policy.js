/**
 * ui/tab_policy.js
 * 
 * Tab 1: Auth Policy DSL Editor, Preset Selector, Deterministic Auto-Fix, and Compiler Runner.
 * Belongs to the User Interface subsystem.
 * Inputs: User DSL text or selected preset. Outputs: Rendered HTML and compilation triggering.
 */

'use strict';

let pkCurrentFixes = [];
let pkEditorUndoHistory = null;
let pkAutoFixTableVisible = false;

// Returns initial default preset text from presets repository or fallback
function pkGetInitialPreset() {
  const p = (typeof window !== 'undefined' && window.pkPresets) ? window.pkPresets.find(x => x.id === 'employee_portal') : null;
  return p ? p.dslText : 'policy "Employee Portal"\nprimaryAuth passkey\npasswordFallback requireMfa\nadminAuth passkeyOnly\nrecovery requireTwoFactors\nrequireUserVerification true\nresidentKey required';
}

// Renders the Policy tab layout with preset dropdown, description, and compiler button
function pkRenderPolicyTab() {
  const defaultDesc = 'Enterprise passkey with MFA fallback & nested password rules (AAL3, Score: 100, Phishing-resistant)';
  const pOpts = [['employee_portal', 'Employee Portal'], ['banking_fintech', 'Banking and Fintech'], ['healthcare_staff', 'Healthcare Staff'], ['university_portal', 'University Portal'], ['gov_citizen', 'Government Citizen Portal'], ['ecommerce_customer', 'E-commerce Customer'], ['saas_admin', 'SaaS Admin Console']]
    .map(([v, n]) => `<option value="${v}" ${v === 'employee_portal' ? 'selected' : ''}>${n}</option>`).join('');
  const dOpts = [['weak_legacy', 'Weak Legacy Portal'], ['typos_demo', 'Typos for Auto-Fix'], ['downgrade_demo', 'Downgrade Attack'], ['contradiction_demo', 'Contradiction']]
    .map(([v, n]) => `<option value="${v}">${n}</option>`).join('');

  return `
    <div class="pk-card">
      <div class="pk-card-title" style="flex-wrap:wrap; gap:8px;">
        <span>① Auth Policy DSL Editor</span>
        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
          <select id="pk-preset-select" class="pk-select" style="width:auto; min-width:220px; font-size:12px; padding:5px 8px;" onchange="window.pkTabPolicy.onPresetChange()">
            <optgroup label="Portals">${pOpts}</optgroup><optgroup label="Demo Cases">${dOpts}</optgroup>
          </select>
          <button class="pk-btn pk-btn-sec" id="pk-preset-btn" onclick="window.pkTabPolicy.loadPreset()" title="Load selected preset into editor">Load</button>
          <button class="pk-btn pk-btn-primary" id="pk-btn-compile" onclick="window.pkTabPolicy.compile()">▶ Compile Policy</button>
        </div>
      </div>
      <div id="pk-preset-desc" style="font-size:11.5px; color:#64748b; margin:-4px 0 10px 0; line-height:1.4;">${defaultDesc}</div>
      <textarea id="pk-dsl-editor" class="pk-textarea" spellcheck="false" placeholder="# Enter your passkey-first policy...">${pkGetInitialPreset()}</textarea>
    </div>
    <div class="pk-card" id="pk-policy-status-card" style="display:none;">
      <div class="pk-card-title"><span>Compilation Diagnostics &amp; Guardrails</span><span id="pk-policy-status-badge"></span></div>
      <div id="pk-policy-errors"></div>
      <div id="pk-autofix-panel" style="margin-top:12px; display:none;"></div>
    </div>`;
}

// Updates the description line when dropdown selection changes
function pkOnPresetChange() {
  const select = document.getElementById('pk-preset-select');
  const descEl = document.getElementById('pk-preset-desc');
  if (!select || !descEl) return;
  const presets = (typeof window !== 'undefined' && window.pkPresets) ? window.pkPresets : [];
  const found = presets.find(p => p.id === select.value);
  if (found) descEl.innerText = found.description;
}

// Loads selected preset into the DSL textarea and updates the description
function pkLoadPreset(presetId) {
  const select = document.getElementById('pk-preset-select');
  const editor = document.getElementById('pk-dsl-editor');
  const descEl = document.getElementById('pk-preset-desc');
  if (!editor) return;

  const targetId = presetId || (select ? select.value : 'employee_portal');
  const presets = (typeof window !== 'undefined' && window.pkPresets) ? window.pkPresets : [];
  const found = presets.find(p => p.id === targetId);

  if (found) {
    editor.value = found.dslText;
    if (select && select.value !== targetId) select.value = targetId;
    if (descEl) descEl.innerText = found.description;
  } else if (targetId === 'employee_portal' || !presetId) {
    editor.value = pkGetInitialPreset();
  }
}

// Replaces target string on specified line in DSL text
function pkApplyFixToText(text, fix) {
  if (!fix || fix.after === null || fix.after === undefined) return text;
  if (fix.before === '' && fix.after === '}') return text.endsWith('}') ? text : text + '\n}';
  const lines = text.split('\n');
  const idx = fix.line - 1;
  if (idx >= 0 && idx < lines.length && lines[idx].includes(fix.before)) {
    lines[idx] = lines[idx].replace(fix.before, fix.after);
    return lines.join('\n');
  }
  return text;
}

// Renders the auto-fix table and actions inside the diagnostics card
function pkRenderAutoFixUi(fixes) {
  const panel = document.getElementById('pk-autofix-panel');
  if (!panel) return;
  pkCurrentFixes = fixes || [];
  if (pkCurrentFixes.length === 0) { panel.style.display = 'none'; return; }

  const safeCount = pkCurrentFixes.filter(f => f.kind === 'auto' && f.after !== null).length;
  panel.style.display = 'block';

  const rows = pkCurrentFixes.map((f, idx) => {
    const act = (f.kind === 'suggested' && f.after)
      ? `<button class="pk-btn pk-btn-sec" style="padding:2px 8px; font-size:10.5px;" onclick="window.pkTabPolicy.applySingleFix(${idx})">Fix</button>`
      : (f.kind === 'auto' ? `<span style="font-size:10.5px; color:#059669; font-weight:600;">Auto</span>` : `<span style="font-size:10.5px; color:#64748b;">Manual</span>`);
    return `<tr>
      <td style="padding:5px 8px; font-family:'JetBrains Mono',monospace; font-weight:600;">Line ${f.line}</td>
      <td style="padding:5px 8px; font-family:'JetBrains Mono',monospace; color:#dc2626;">${f.before || '(empty)'}</td>
      <td style="padding:5px 8px; font-family:'JetBrains Mono',monospace; color:#059669;">${f.after || '—'}</td>
      <td style="padding:5px 8px; font-size:11px; color:#475569;">${f.reason}</td>
      <td style="padding:5px 8px; text-align:center;">${act}</td>
    </tr>`;
  }).join('');

  panel.innerHTML = `
    <div style="border-top:1px solid #e2e8f0; padding-top:10px; margin-top:8px;">
      <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px;">
        <div style="display:flex; align-items:center; gap:8px;">
          <button class="pk-btn pk-btn-sec" id="pk-btn-autofix" onclick="window.pkTabPolicy.toggleAutoFixPanel()" style="font-size:11px; padding:4px 10px;">Auto-Fix (${pkCurrentFixes.length})</button>
          ${safeCount > 0 ? `<button class="pk-btn pk-btn-primary" id="pk-btn-apply-safe" onclick="window.pkTabPolicy.applySafeFixes()" style="font-size:11px; padding:4px 10px;">Apply Safe Fixes (${safeCount})</button>` : ''}
          <button class="pk-btn pk-btn-sec" id="pk-btn-undo" onclick="window.pkTabPolicy.undoFix()" style="font-size:11px; padding:4px 10px; display:${pkEditorUndoHistory ? 'inline-flex' : 'none'};">Undo</button>
        </div>
        <div id="pk-autofix-status" style="font-size:11.5px; color:#475569; font-weight:600;"></div>
      </div>
      <div id="pk-autofix-table-wrap" style="margin-top:8px; display:${pkAutoFixTableVisible ? 'block' : 'none'}; overflow-x:auto;">
        <table class="pk-table" style="font-size:11.5px;">
          <thead><tr><th style="padding:5px 8px;">Line</th><th style="padding:5px 8px;">Before</th><th style="padding:5px 8px;">After</th><th style="padding:5px 8px;">Reason</th><th style="padding:5px 8px; text-align:center;">Action</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// Toggles visibility of the auto-fix suggestions table
function pkToggleAutoFixPanel() {
  pkAutoFixTableVisible = !pkAutoFixTableVisible;
  const wrap = document.getElementById('pk-autofix-table-wrap');
  if (wrap) wrap.style.display = pkAutoFixTableVisible ? 'block' : 'none';
}

// Applies updates to editor while saving history and updating status
function pkUpdateEditorWithFix(updater, statusMsg) {
  const editor = document.getElementById('pk-dsl-editor');
  const statusEl = document.getElementById('pk-autofix-status');
  if (!editor) return;
  pkEditorUndoHistory = editor.value;
  editor.value = updater(editor.value);
  if (statusEl) statusEl.innerText = statusMsg;
  const undoBtn = document.getElementById('pk-btn-undo');
  if (undoBtn) undoBtn.style.display = 'inline-flex';
}

// Applies all safe automatic fixes to the DSL editor
function pkApplySafeFixes() {
  const safeFixes = pkCurrentFixes.filter(f => f.kind === 'auto' && f.after !== null);
  if (safeFixes.length > 0) {
    pkUpdateEditorWithFix(text => safeFixes.reduce((t, fix) => pkApplyFixToText(t, fix), text), `${safeFixes.length} fixes applied, recompile to verify`);
  }
}

// Applies a single suggested fix to the DSL editor
function pkApplySingleFix(index) {
  const fix = pkCurrentFixes[index];
  if (fix) pkUpdateEditorWithFix(text => pkApplyFixToText(text, fix), '1 fix applied, recompile to verify');
}

// Restores editor text to pre-fix state
function pkUndoFix() {
  const editor = document.getElementById('pk-dsl-editor');
  const statusEl = document.getElementById('pk-autofix-status');
  if (!editor || pkEditorUndoHistory === null) return;
  editor.value = pkEditorUndoHistory;
  pkEditorUndoHistory = null;
  if (statusEl) statusEl.innerText = 'Undone to previous text';
  const undoBtn = document.getElementById('pk-btn-undo');
  if (undoBtn) undoBtn.style.display = 'none';
}

// Compiles the DSL via POST /api/auth-policy/compile
async function pkCompilePolicy() {
  const editor = document.getElementById('pk-dsl-editor');
  const statusCard = document.getElementById('pk-policy-status-card');
  const badge = document.getElementById('pk-policy-status-badge');
  const errorsDiv = document.getElementById('pk-policy-errors');
  const btn = document.getElementById('pk-btn-compile');
  const autofixPanel = document.getElementById('pk-autofix-panel');
  if (!editor || !statusCard) return;

  btn.disabled = true;
  btn.innerText = 'Compiling...';
  if (autofixPanel) autofixPanel.style.display = 'none';

  try {
    const res = await fetch('/api/auth-policy/compile', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dslText: editor.value })
    });
    const data = await res.json();
    statusCard.style.display = 'block';

    if (data.ok) {
      badge.className = 'pk-badge pk-badge-pass';
      badge.innerText = `COMPILED (${data.latencyMs}ms)`;
      errorsDiv.innerHTML = `<div style="color:#059669; font-size:12px; font-weight:600;">Zero-Trust Compiler: All 7 agent stages verified with valid Ed25519 signatures. Policy active!</div>`;
      if (window.pkTabOutput && window.pkTabOutput.update) window.pkTabOutput.update(data);
      if (window.pkTabAgents && window.pkTabAgents.update) window.pkTabAgents.update(data);
    } else {
      badge.className = 'pk-badge pk-badge-fail';
      badge.innerText = `BLOCKED AT ${data.stoppedAt || 'SYNTAX'}`;
      let html = '<ul style="margin-left:16px; font-size:12px; color:#dc2626;">';
      (data.findings || []).forEach(f => {
        const loc = (f.line !== undefined) ? `[Line ${f.line}, Col ${f.col || 1}] ` : '';
        html += `<li style="margin-top:4px;"><b>${loc}${f.severity || 'ERROR'}:</b> ${f.message}</li>`;
      });
      html += '</ul>';
      errorsDiv.innerHTML = html;

      try {
        const fixRes = await fetch('/api/auth-policy/autofix', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ dslText: editor.value })
        });
        const fixData = await fixRes.json();
        if (fixData.ok && fixData.fixes) pkRenderAutoFixUi(fixData.fixes);
      } catch (err) {}
    }
  } catch (err) {
    statusCard.style.display = 'block';
    badge.className = 'pk-badge pk-badge-fail';
    badge.innerText = 'ERROR';
    errorsDiv.innerHTML = `<div style="color:#dc2626; font-size:12px;">Network error: ${err.message}</div>`;
  } finally {
    btn.disabled = false;
    btn.innerText = '▶ Compile Policy';
  }
}

window.pkTabPolicy = {
  render: pkRenderPolicyTab,
  loadPreset: pkLoadPreset,
  onPresetChange: pkOnPresetChange,
  compile: pkCompilePolicy,
  toggleAutoFixPanel: pkToggleAutoFixPanel,
  applySafeFixes: pkApplySafeFixes,
  applySingleFix: pkApplySingleFix,
  undoFix: pkUndoFix
};
