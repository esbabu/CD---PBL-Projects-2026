/**
 * ui/tab_passkey_demo.js
 * 
 * Tab 4: Live Passkey Ceremonies, Password+TOTP Fallback, and Two-Factor Recovery.
 * Uses native navigator.credentials with base64url encoding and human-friendly diagnostics.
 * Belongs to the User Interface subsystem.
 */

'use strict';

function pkBufToBase64Url(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function pkBase64UrlToBuf(base64url) {
  const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
  const pad = base64.length % 4 ? '='.repeat(4 - (base64.length % 4)) : '';
  const binary = atob(base64 + pad);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function pkSetFb(elementId, badgeClass, message) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.style.display = 'block';
  el.className = `pk-badge ${badgeClass}`;
  el.innerText = message;
}

async function pkPostApi(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return res.json();
}

function pkRenderPasskeyTab() {
  const hasWebAuthn = Boolean(window.PublicKeyCredential);
  return `
    ${!hasWebAuthn ? '<div class="pk-badge pk-badge-fail" style="width:100%; padding:10px; margin-bottom:12px;">⚠️ WebAuthn is not supported by your current browser environment.</div>' : ''}
    <div class="pk-grid-2">
      <div class="pk-card">
        <div class="pk-card-title"><span>🔐 FIDO2 Passkey Ceremonies</span></div>
        <div style="margin-bottom:12px;">
          <label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Username</label>
          <input type="text" id="pk-demo-user" class="pk-input" value="alice" placeholder="alice or admin"/>
        </div>
        <div style="display:flex; gap:10px; margin-bottom:14px;">
          <button class="pk-btn pk-btn-accent" onclick="window.pkTabPasskeyDemo.register()">🔑 Register Passkey</button>
          <button class="pk-btn pk-btn-primary" onclick="window.pkTabPasskeyDemo.login()">🔓 Login with Passkey</button>
        </div>
        <div id="pk-passkey-feedback" style="display:none; padding:10px; border-radius:6px; font-size:11.5px;"></div>
      </div>
      <div class="pk-card">
        <div class="pk-card-title"><span>🔑 Password &amp; Live TOTP Simulator</span></div>
        <div style="margin-bottom:8px;">
          <input type="password" id="pk-demo-password" class="pk-input" value="AlicePassword123!" placeholder="Password"/>
        </div>
        <div style="display:flex; gap:8px; margin-bottom:12px;">
          <button class="pk-btn pk-btn-sec" onclick="window.pkTabPasskeyDemo.loginPassword()">Login with Password</button>
          <button class="pk-btn pk-btn-sec" onclick="window.pkTabPasskeyDemo.enrollTotp()">📟 Simulator Code</button>
        </div>
        <div id="pk-totp-sim-box" style="display:none; background:#0f172a; color:#38bdf8; padding:12px; border-radius:8px; font-family:'JetBrains Mono',monospace; margin-bottom:10px;">
          <div style="font-size:10px; color:#94a3b8; margin-bottom:4px;">LIVE SIMULATOR CODE (RFC 6238):</div>
          <div id="pk-totp-code-display" style="font-size:24px; font-weight:700; letter-spacing:4px; color:#a7f3d0;">------</div>
        </div>
        <div style="display:flex; gap:8px;">
          <input type="text" id="pk-totp-input" class="pk-input" placeholder="6-digit code"/>
          <button class="pk-btn pk-btn-primary" onclick="window.pkTabPasskeyDemo.verifyTotp()">Verify</button>
        </div>
        <div id="pk-password-feedback" style="display:none; padding:10px; border-radius:6px; font-size:11.5px; margin-top:10px;"></div>
      </div>
    </div>
    <div class="pk-card">
      <div class="pk-card-title"><span>🛡️ Zero-Trust Account Recovery (Two Distinct Factors)</span></div>
      <p style="font-size:11.5px; color:#64748b; margin-bottom:10px;">Recovery strictly requires at least two verified factors to prevent account takeover.</p>
      <div class="pk-grid-3" style="margin-bottom:12px;">
        <div><label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Factor 1: Recovery Code</label>
             <input type="text" id="pk-rec-code" class="pk-input" value="RC-ALICE-01"/></div>
        <div><label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Factor 2: TOTP Code</label>
             <input type="text" id="pk-rec-totp" class="pk-input" placeholder="Current TOTP"/></div>
        <div><label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Factor 3: Email OTP</label>
             <input type="text" id="pk-rec-email" class="pk-input" value="123456"/></div>
      </div>
      <button class="pk-btn pk-btn-primary" onclick="window.pkTabPasskeyDemo.recoverAccount()">Execute Recovery</button>
      <div id="pk-recovery-feedback" style="display:none; padding:10px; border-radius:6px; font-size:11.5px; margin-top:10px;"></div>
    </div>
  `;
}

function pkHumanError(err) {
  if (err.name === 'NotAllowedError') return 'Ceremony cancelled by user, timed out, or permission denied.';
  if (err.name === 'NotSupportedError') return 'Passkeys not supported or enabled on this platform.';
  if (err.name === 'SecurityError') return 'Origin mismatch: passkeys are cryptographically restricted to localhost.';
  return err.message || 'Unknown WebAuthn error occurred.';
}

async function pkRegisterPasskey() {
  const username = document.getElementById('pk-demo-user').value.trim();
  pkSetFb('pk-passkey-feedback', 'pk-badge-info', 'Requesting registration challenge...');
  try {
    const { ok, options, error } = await pkPostApi('/api/auth-policy/passkey/register/options', { username });
    if (!ok) throw new Error(error || 'Failed to get options');

    options.challenge = pkBase64UrlToBuf(options.challenge);
    options.user.id = pkBase64UrlToBuf(options.user.id);

    pkSetFb('pk-passkey-feedback', 'pk-badge-info', 'Please complete biometric / security key prompt...');
    const cred = await navigator.credentials.create({ publicKey: options });

    const credResponse = {
      id: cred.id, rawId: pkBufToBase64Url(cred.rawId), type: cred.type, challenge: pkBufToBase64Url(options.challenge),
      response: {
        clientDataJSON: pkBufToBase64Url(cred.response.clientDataJSON),
        attestationObject: pkBufToBase64Url(cred.response.attestationObject),
        transports: cred.response.getTransports ? cred.response.getTransports() : []
      }
    };

    const verifyData = await pkPostApi('/api/auth-policy/passkey/register/verify', { username, response: credResponse });
    if (!verifyData.ok) throw new Error(verifyData.error);
    pkSetFb('pk-passkey-feedback', 'pk-badge-pass', `✅ Passkey registered for '${username}'! Ready for passwordless login.`);
  } catch (err) {
    pkSetFb('pk-passkey-feedback', 'pk-badge-fail', `❌ Registration Failed: ${pkHumanError(err)}`);
  }
}

async function pkLoginPasskey() {
  const username = document.getElementById('pk-demo-user').value.trim();
  pkSetFb('pk-passkey-feedback', 'pk-badge-info', 'Requesting authentication challenge...');
  try {
    const { ok, options, error } = await pkPostApi('/api/auth-policy/passkey/login/options', { username });
    if (!ok) throw new Error(error || 'Failed to get options');

    options.challenge = pkBase64UrlToBuf(options.challenge);
    if (Array.isArray(options.allowCredentials)) {
      options.allowCredentials.forEach(c => { c.id = pkBase64UrlToBuf(c.id); });
    }

    pkSetFb('pk-passkey-feedback', 'pk-badge-info', 'Verify biometric / security key...');
    const cred = await navigator.credentials.get({ publicKey: options });

    const credResponse = {
      id: cred.id, rawId: pkBufToBase64Url(cred.rawId), type: cred.type, challenge: pkBufToBase64Url(options.challenge),
      response: {
        clientDataJSON: pkBufToBase64Url(cred.response.clientDataJSON),
        authenticatorData: pkBufToBase64Url(cred.response.authenticatorData),
        signature: pkBufToBase64Url(cred.response.signature)
      }
    };

    const verifyData = await pkPostApi('/api/auth-policy/passkey/login/verify', { username, response: credResponse });
    if (!verifyData.ok) throw new Error(verifyData.error);
    pkSetFb('pk-passkey-feedback', 'pk-badge-pass', `✅ Authenticated as '${username}'! Assertion verified.`);
  } catch (err) {
    pkSetFb('pk-passkey-feedback', 'pk-badge-fail', `❌ Login Failed: ${pkHumanError(err)}`);
  }
}

async function pkLoginPassword() {
  const username = document.getElementById('pk-demo-user').value.trim();
  const password = document.getElementById('pk-demo-password').value;
  try {
    const data = await pkPostApi('/api/auth-policy/password/login', { username, password });
    if (!data.ok) return pkSetFb('pk-password-feedback', 'pk-badge-fail', `❌ ${data.error}`);
    if (data.requiresMfa) {
      pkSetFb('pk-password-feedback', 'pk-badge-warn', `⚠️ ${data.message}`);
      pkEnrollTotp();
    } else {
      pkSetFb('pk-password-feedback', 'pk-badge-pass', `✅ Authenticated as '${username}' with password.`);
    }
  } catch (err) {
    pkSetFb('pk-password-feedback', 'pk-badge-fail', `❌ ${err.message}`);
  }
}

async function pkEnrollTotp() {
  const username = document.getElementById('pk-demo-user').value.trim();
  document.getElementById('pk-totp-sim-box').style.display = 'block';
  try {
    const data = await pkPostApi('/api/auth-policy/totp/enroll', { username });
    if (data.ok) {
      document.getElementById('pk-totp-code-display').innerText = data.currentCode;
      document.getElementById('pk-totp-input').value = data.currentCode;
    }
  } catch (e) {}
}

async function pkVerifyTotp() {
  const username = document.getElementById('pk-demo-user').value.trim();
  const token = document.getElementById('pk-totp-input').value.trim();
  try {
    const data = await pkPostApi('/api/auth-policy/totp/verify', { username, token });
    pkSetFb('pk-password-feedback', data.ok ? 'pk-badge-pass' : 'pk-badge-fail',
      data.ok ? '✅ TOTP Code Verified! Secondary factor authenticated.' : `❌ ${data.error}`);
  } catch (err) {
    pkSetFb('pk-password-feedback', 'pk-badge-fail', `❌ ${err.message}`);
  }
}

async function pkRecoverAccount() {
  const username = document.getElementById('pk-demo-user').value.trim();
  const recoveryCode = document.getElementById('pk-rec-code').value.trim();
  const totp = document.getElementById('pk-rec-totp').value.trim();
  const emailOtp = document.getElementById('pk-rec-email').value.trim();
  try {
    const data = await pkPostApi('/api/auth-policy/recovery', { username, recoveryCode, totp, emailOtp });
    pkSetFb('pk-recovery-feedback', data.ok ? 'pk-badge-pass' : 'pk-badge-fail',
      data.ok ? `✅ ${data.message} Verified: [${data.factorsUsed.join(', ')}]` : `❌ Recovery Blocked: ${data.error}`);
  } catch (err) {
    pkSetFb('pk-recovery-feedback', 'pk-badge-fail', `❌ Error: ${err.message}`);
  }
}

window.pkTabPasskeyDemo = {
  render: pkRenderPasskeyTab,
  register: pkRegisterPasskey,
  login: pkLoginPasskey,
  loginPassword: pkLoginPassword,
  enrollTotp: pkEnrollTotp,
  verifyTotp: pkVerifyTotp,
  recoverAccount: pkRecoverAccount
};
