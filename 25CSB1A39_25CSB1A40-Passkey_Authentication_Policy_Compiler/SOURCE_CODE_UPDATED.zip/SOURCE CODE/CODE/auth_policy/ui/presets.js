/**
 * ui/presets.js
 * 
 * Presets repository for Passkey-First Authentication Policy Compiler.
 * Contains production portal configurations and diagnostic demo cases with verified metadata.
 * Belongs to the User Interface subsystem.
 * Inputs: None. Outputs: Array of preset objects with DSL text and expected evaluation results.
 */

'use strict';

const PK_PRESETS = [
  // --- Portals Group ---
  {
    id: 'employee_portal',
    group: 'Portals',
    name: 'Employee Portal',
    description: 'Enterprise passkey with MFA fallback & nested password rules (AAL3, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL3', score: 100, phishingResistant: true },
    dslText: [
      '# Passkey-First Enterprise Authentication Policy',
      'policy "Employee Portal"',
      'primaryAuth passkey',
      'passwordFallback requireMfa',
      'adminAuth passkeyOnly',
      'stepUpOn newDevice',
      'stepUpOn highRisk',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey required',
      'passkeyType deviceBound',
      '',
      '# Nested NIST Password Baseline for Fallback',
      'passwordPolicy {',
      '  minLength 14',
      '  requireUpper true',
      '  requireDigit true',
      '  requireSpecial true',
      '}'
    ].join('\n')
  },
  {
    id: 'banking_fintech',
    group: 'Portals',
    name: 'Banking and Fintech',
    description: 'Hardware passkey-only with step-up on sensitive actions (AAL3, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL3', score: 100, phishingResistant: true },
    dslText: [
      'policy "Banking and Fintech"',
      'primaryAuth passkeyOnly',
      'passwordFallback none',
      'adminAuth passkeyOnly',
      'stepUpOn sensitiveAction',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey required',
      'passkeyType deviceBound'
    ].join('\n')
  },
  {
    id: 'healthcare_staff',
    group: 'Portals',
    name: 'Healthcare Staff',
    description: 'Clinical passkey with admin passkey+MFA and password baseline (AAL2, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL2', score: 100, phishingResistant: true },
    dslText: [
      'policy "Healthcare Staff"',
      'primaryAuth passkey',
      'passwordFallback requireMfa',
      'adminAuth passkeyPlusMfa',
      'stepUpOn newDevice',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey preferred',
      'passkeyType synced',
      '',
      'passwordPolicy {',
      '  minLength 12',
      '  requireUpper true',
      '  requireDigit true',
      '  requireSpecial true',
      '}'
    ].join('\n')
  },
  {
    id: 'university_portal',
    group: 'Portals',
    name: 'University Portal',
    description: 'Campus synced passkeys with MFA fallback for students (AAL2, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL2', score: 100, phishingResistant: true },
    dslText: [
      'policy "University Portal"',
      'primaryAuth passkey',
      'passwordFallback requireMfa',
      'adminAuth passkeyOnly',
      'stepUpOn newDevice',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey preferred',
      'passkeyType synced'
    ].join('\n')
  },
  {
    id: 'gov_citizen',
    group: 'Portals',
    name: 'Government Citizen Portal',
    description: 'Citizen portal with strict passkey-only and 2-factor recovery (AAL3, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL3', score: 100, phishingResistant: true },
    dslText: [
      'policy "Government Citizen Portal"',
      'primaryAuth passkeyOnly',
      'passwordFallback none',
      'adminAuth passkeyOnly',
      'stepUpOn highRisk',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey required',
      'passkeyType deviceBound'
    ].join('\n')
  },
  {
    id: 'ecommerce_customer',
    group: 'Portals',
    name: 'E-commerce Customer',
    description: 'Consumer multi-device synced passkey with high-risk step-up (AAL2, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL2', score: 100, phishingResistant: true },
    dslText: [
      'policy "E-commerce Customer"',
      'primaryAuth passkey',
      'passwordFallback requireMfa',
      'adminAuth passkeyOnly',
      'stepUpOn highRisk',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey preferred',
      'passkeyType synced'
    ].join('\n')
  },
  {
    id: 'saas_admin',
    group: 'Portals',
    name: 'SaaS Admin Console',
    description: 'Cloud admin console with mandatory step-up on high risk and sensitive actions (AAL3, Score: 100, Phishing-resistant)',
    expected: { ok: true, aal: 'AAL3', score: 100, phishingResistant: true },
    dslText: [
      'policy "SaaS Admin Console"',
      'primaryAuth passkeyOnly',
      'passwordFallback none',
      'adminAuth passkeyOnly',
      'stepUpOn highRisk',
      'stepUpOn sensitiveAction',
      'recovery requireTwoFactors',
      'requireUserVerification true',
      'residentKey required',
      'passkeyType deviceBound'
    ].join('\n')
  },

  // --- Demo Cases Group ---
  {
    id: 'weak_legacy',
    group: 'Demo Cases',
    name: 'Weak Legacy Portal',
    description: 'Legacy password-only authentication (AAL1, Score: 50, Phishable: Yes)',
    expected: { ok: true, aal: 'AAL1', score: 50, phishingResistant: false },
    dslText: [
      'policy "Weak Legacy Portal"',
      'primaryAuth password',
      'recovery requireTwoFactors',
      'requireUserVerification true'
    ].join('\n')
  },
  {
    id: 'typos_demo',
    group: 'Demo Cases',
    name: 'Typos for Auto-Fix',
    description: 'Malformed keyword and value typos (Blocked at ID-1 Parser)',
    expected: { ok: false, stoppedAt: 'ID-1', errorContains: 'requireUrVerification' },
    dslText: [
      'policy "Typos Demo"',
      'primaryAuth passkey',
      'requireUrVerification true',
      'passkeyType deviceBou'
    ].join('\n')
  },
  {
    id: 'downgrade_demo',
    group: 'Demo Cases',
    name: 'Downgrade Attack',
    description: 'Insecure adminAuth passwordOnly (Blocked at ID-0 Guard: DOWNGRADE_BLOCKED)',
    expected: { ok: false, stoppedAt: 'ID-0', errorContains: 'DOWNGRADE_BLOCKED' },
    dslText: [
      'policy "Downgrade Attack Demo"',
      'primaryAuth passkey',
      'adminAuth passwordOnly',
      'recovery requireTwoFactors',
      'requireUserVerification true'
    ].join('\n')
  },
  {
    id: 'contradiction_demo',
    group: 'Demo Cases',
    name: 'Contradiction',
    description: 'Conflicting passkeyOnly and password fallback (Blocked at ID-2 Consistency)',
    expected: { ok: false, stoppedAt: 'ID-2', errorContains: 'Contradiction' },
    dslText: [
      'policy "Contradiction Demo"',
      'primaryAuth passkeyOnly',
      'passwordFallback requireMfa',
      'adminAuth passkeyOnly',
      'recovery requireTwoFactors',
      'requireUserVerification true'
    ].join('\n')
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PK_PRESETS };
}
if (typeof window !== 'undefined') {
  window.pkPresets = PK_PRESETS;
}
