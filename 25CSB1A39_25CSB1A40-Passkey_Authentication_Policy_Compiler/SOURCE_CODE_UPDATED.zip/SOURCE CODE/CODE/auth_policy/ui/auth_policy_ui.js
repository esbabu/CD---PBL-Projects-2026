/**
 * ui/auth_policy_ui.js
 * 
 * Main UI Controller for Passkey-First Authentication Policy Compiler.
 * Mounts full-screen modal panel into #pk-root and coordinates the 6 inner tabs.
 * Belongs to the User Interface subsystem.
 */

'use strict';

let pkActiveTab = 'policy';

// Constructs and mounts the modal markup into #pk-root
function pkMountUI() {
  const root = document.getElementById('pk-root');
  if (!root) return;

  const port = location.port || 3000;
  const isLocalhost = location.hostname === 'localhost';

  root.innerHTML = `
    <div class="pk-overlay" id="pk-modal-overlay">
      <div class="pk-panel">
        <!-- Header -->
        <div class="pk-header">
          <div class="pk-header-title">
            <div class="pk-header-icon">🔐</div>
            <div>
              <h2>Passkey-First Authentication Policy Compiler</h2>
              <p>Zero-Trust WebAuthn Pipeline · NIST SP 800-63B-4 Assurance · Ed25519 Verified Agents</p>
            </div>
          </div>
          <div class="pk-header-actions">
            <button class="pk-close-btn" onclick="pkCloseModal()" title="Close panel">✕</button>
          </div>
        </div>

        <!-- Hostname Origin Advisory Banner -->
        <div id="pk-origin-banner" class="pk-banner-warning" style="${isLocalhost ? 'display:none;' : ''}">
          <span>⚠️ <b>Origin Warning:</b> You are accessing via <code>${location.hostname}</code>. Passkeys require <code>localhost</code> origin for cryptographic binding.</span>
          <a href="http://localhost:${port}" target="_blank">Open http://localhost:${port} ↗</a>
        </div>

        <!-- Tabs Bar -->
        <div class="pk-tabs-bar">
          <button class="pk-tab-btn pk-active" id="pk-tab-btn-policy" onclick="pkSwitchTab('policy')">
            <span>📝</span> 1. Policy Editor
          </button>
          <button class="pk-tab-btn" id="pk-tab-btn-output" onclick="pkSwitchTab('output')">
            <span>⚡</span> 2. Compile Output
          </button>
          <button class="pk-tab-btn" id="pk-tab-btn-flow" onclick="pkSwitchTab('flow')">
            <span>🔄</span> 3. Flow &amp; State Machine
          </button>
          <button class="pk-tab-btn" id="pk-tab-btn-passkey_demo" onclick="pkSwitchTab('passkey_demo')">
            <span>🔑</span> 4. Live Passkey Demo
          </button>
          <button class="pk-tab-btn" id="pk-tab-btn-phishing" onclick="pkSwitchTab('phishing')">
            <span>🎯</span> 5. Phishing Test
          </button>
          <button class="pk-tab-btn" id="pk-tab-btn-agents" onclick="pkSwitchTab('agents')">
            <span>🛡️</span> 6. Agents &amp; Audit
          </button>
        </div>

        <!-- Body / Tab Content -->
        <div class="pk-body">
          <div class="pk-tab-pane pk-active" id="pk-tab-pane-policy">
            ${window.pkTabPolicy ? window.pkTabPolicy.render() : ''}
          </div>
          <div class="pk-tab-pane" id="pk-tab-pane-output">
            ${window.pkTabOutput ? window.pkTabOutput.render() : ''}
          </div>
          <div class="pk-tab-pane" id="pk-tab-pane-flow">
            ${window.pkTabFlow ? window.pkTabFlow.render() : ''}
          </div>
          <div class="pk-tab-pane" id="pk-tab-pane-passkey_demo">
            ${window.pkTabPasskeyDemo ? window.pkTabPasskeyDemo.render() : ''}
          </div>
          <div class="pk-tab-pane" id="pk-tab-pane-phishing">
            ${window.pkTabPhishing ? window.pkTabPhishing.render() : ''}
          </div>
          <div class="pk-tab-pane" id="pk-tab-pane-agents">
            ${window.pkTabAgents ? window.pkTabAgents.render() : ''}
          </div>
        </div>
      </div>
    </div>
  `;

  // Attach overlay click to close
  const overlay = document.getElementById('pk-modal-overlay');
  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) pkCloseModal();
    });
  }
}

// Switches visible tab pane and updates tab button styling
function pkSwitchTab(tabName) {
  pkActiveTab = tabName;
  const tabs = ['policy', 'output', 'flow', 'passkey_demo', 'phishing', 'agents'];

  tabs.forEach(t => {
    const btn = document.getElementById(`pk-tab-btn-${t}`);
    const pane = document.getElementById(`pk-tab-pane-${t}`);
    if (btn) btn.classList.toggle('pk-active', t === tabName);
    if (pane) pane.classList.toggle('pk-active', t === tabName);
  });

  // Hide origin warning banner when viewing the phishing test tab
  const banner = document.getElementById('pk-origin-banner');
  if (banner && location.hostname !== 'localhost') {
    banner.style.display = (tabName === 'phishing') ? 'none' : 'flex';
  }

  // Trigger lazy tab refresh
  if (tabName === 'agents' && window.pkTabAgents) {
    window.pkTabAgents.refreshAudit();
  }
}

// Opens the Passkey Auth full-screen modal
function pkOpenModal() {
  const overlay = document.getElementById('pk-modal-overlay');
  if (!overlay) {
    pkMountUI();
  }
  const el = document.getElementById('pk-modal-overlay');
  if (el) el.classList.add('pk-open');
}

// Closes the Passkey Auth modal
function pkCloseModal() {
  const el = document.getElementById('pk-modal-overlay');
  if (el) el.classList.remove('pk-open');
}

// Expose globals
window.pkOpenModal = pkOpenModal;
window.pkCloseModal = pkCloseModal;
window.pkSwitchTab = pkSwitchTab;

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', pkMountUI);
} else {
  pkMountUI();
}
