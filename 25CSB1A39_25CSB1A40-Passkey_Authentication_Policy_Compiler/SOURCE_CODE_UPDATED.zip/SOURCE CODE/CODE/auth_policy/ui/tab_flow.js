/**
 * ui/tab_flow.js
 * 
 * Tab 3: Authentication Flow State Machine SVG and 'What would happen?' Decision Simulator.
 * Belongs to the User Interface subsystem.
 * Inputs: Simulation context. Outputs: Rendered SVG graph and policy decision.
 */

'use strict';

// Renders the state machine SVG and simulator controls
function pkRenderFlowTab() {
  return `
    <div class="pk-card">
      <div class="pk-card-title">
        <span>③ Authentication State Machine (Deterministic FSM)</span>
      </div>
      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px; overflow-x:auto;">
        <svg viewBox="0 0 960 210" style="width:100%; min-width:760px; height:180px; font-family:'Inter',sans-serif;">
          <defs>
            <marker id="pk-arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 1 L 8 5 L 0 9 z" fill="#64748b" />
            </marker>
          </defs>

          <!-- States -->
          <!-- 1. Start: IDLE -->
          <circle cx="50" cy="100" r="24" fill="#e2e8f0" stroke="#94a3b8" stroke-width="2"/>
          <text x="50" y="104" text-anchor="middle" font-size="11" font-weight="700" fill="#334155">IDLE</text>

          <!-- Arrow IDLE -> IDENTIFY -->
          <line x1="74" y1="100" x2="136" y2="100" stroke="#64748b" stroke-width="2" marker-end="url(#pk-arrow)"/>
          <text x="105" y="92" text-anchor="middle" font-size="9" fill="#64748b">Identify</text>

          <!-- 2. IDENTIFY -->
          <rect x="140" y="78" width="90" height="44" rx="8" fill="#e0e7ff" stroke="#6366f1" stroke-width="2"/>
          <text x="185" y="104" text-anchor="middle" font-size="11" font-weight="700" fill="#4338ca">IDENTIFY</text>

          <!-- Split paths -->
          <!-- Upper: Passkey Branch -->
          <path d="M 230 92 Q 280 50 340 50" fill="none" stroke="#64748b" stroke-width="2" marker-end="url(#pk-arrow)"/>
          <text x="275" y="52" font-size="9" fill="#059669">Has Passkey</text>

          <!-- Lower: Password Fallback Branch -->
          <path d="M 230 108 Q 280 150 340 150" fill="none" stroke="#64748b" stroke-width="2" marker-end="url(#pk-arrow)"/>
          <text x="270" y="145" font-size="9" fill="#d97706">Fallback</text>

          <!-- 3. WEBAUTHN ASSERTION (Upper) -->
          <rect x="345" y="28" width="160" height="44" rx="8" fill="#ecfdf5" stroke="#10b981" stroke-width="2"/>
          <text x="425" y="54" text-anchor="middle" font-size="11" font-weight="700" fill="#065f46">WEBAUTHN ASSERT</text>

          <!-- 4. PASSWORD & MFA (Lower) -->
          <rect x="345" y="128" width="160" height="44" rx="8" fill="#fffbeb" stroke="#f59e0b" stroke-width="2"/>
          <text x="425" y="154" text-anchor="middle" font-size="11" font-weight="700" fill="#92400e">PASSWORD VERIFY</text>

          <!-- Upper Success -> AUTHENTICATED -->
          <line x1="505" y1="50" x2="685" y2="85" stroke="#059669" stroke-width="2" marker-end="url(#pk-arrow)"/>
          <text x="590" y="60" font-size="9" fill="#059669">Assertion OK</text>

          <!-- Lower MFA Step-Up -->
          <line x1="505" y1="150" x2="575" y2="150" stroke="#64748b" stroke-width="2" marker-end="url(#pk-arrow)"/>
          <text x="540" y="142" text-anchor="middle" font-size="9" fill="#64748b">MFA</text>

          <!-- MFA Node -->
          <rect x="580" y="128" width="90" height="44" rx="8" fill="#fdf4ff" stroke="#c026d3" stroke-width="2"/>
          <text x="625" y="154" text-anchor="middle" font-size="11" font-weight="700" fill="#86198f">TOTP MFA</text>

          <line x1="670" y1="140" x2="695" y2="115" stroke="#059669" stroke-width="2" marker-end="url(#pk-arrow)"/>

          <!-- 5. Accepting State: AUTHENTICATED -->
          <circle cx="735" cy="100" r="28" fill="#dcfce7" stroke="#16a34a" stroke-width="3"/>
          <circle cx="735" cy="100" r="23" fill="none" stroke="#16a34a" stroke-width="1.5"/>
          <text x="735" y="104" text-anchor="middle" font-size="9.5" font-weight="700" fill="#14532d">ACCEPTED</text>

          <!-- 6. Trap State: REJECTED -->
          <rect x="830" y="78" width="95" height="44" rx="8" fill="#fee2e2" stroke="#ef4444" stroke-width="2"/>
          <text x="877" y="104" text-anchor="middle" font-size="11" font-weight="700" fill="#991b1b">REJECTED</text>
        </svg>
      </div>
    </div>

    <div class="pk-card">
      <div class="pk-card-title">
        <span>'What would happen?' Policy Decision Simulator</span>
      </div>
      <div class="pk-grid-3" style="margin-bottom:14px;">
        <div>
          <label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">User Role</label>
          <select id="pk-sim-role" class="pk-select">
            <option value="employee">Employee (Standard)</option>
            <option value="admin">Administrator (Privileged)</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Device Recognition</label>
          <select id="pk-sim-device" class="pk-select">
            <option value="true">Known / Enrolled Device</option>
            <option value="false">New / Unrecognized Device</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Session Risk Score</label>
          <select id="pk-sim-risk" class="pk-select">
            <option value="low">Low Risk (Standard Network)</option>
            <option value="high">High Risk (Anomalous IP / Geolocation)</option>
          </select>
        </div>
      </div>

      <div class="pk-grid-2" style="margin-bottom:16px;">
        <div>
          <label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Has Registered Passkey?</label>
          <select id="pk-sim-has-pk" class="pk-select">
            <option value="true">Yes (Passkey Available)</option>
            <option value="false">No (No Passkey on Device)</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px; font-weight:600; color:#475569; display:block; margin-bottom:4px;">Requested Method</label>
          <select id="pk-sim-method" class="pk-select">
            <option value="passkey">Passkey (WebAuthn)</option>
            <option value="password">Password</option>
          </select>
        </div>
      </div>

      <button class="pk-btn pk-btn-primary" onclick="window.pkTabFlow.simulate()">
        ⚡ Run Policy Decision Simulation
      </button>

      <div id="pk-sim-result-box" style="display:none; margin-top:16px; padding:14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;"></div>
    </div>
  `;
}

// Executes flow simulation via POST /api/auth-policy/simulate
async function pkSimulateFlow() {
  const role = document.getElementById('pk-sim-role').value;
  const deviceKnown = document.getElementById('pk-sim-device').value === 'true';
  const risk = document.getElementById('pk-sim-risk').value;
  const hasPasskey = document.getElementById('pk-sim-has-pk').value === 'true';
  const requestedMethod = document.getElementById('pk-sim-method').value;
  const box = document.getElementById('pk-sim-result-box');

  box.style.display = 'block';
  box.innerHTML = '<span style="font-size:12px; color:#64748b;">Evaluating policy matrix...</span>';

  try {
    const res = await fetch('/api/auth-policy/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        context: { role, deviceKnown, risk, hasPasskey, requestedMethod }
      })
    });
    const data = await res.json();

    if (!data.ok) {
      box.innerHTML = `<div style="color:#dc2626; font-size:12px; font-weight:600;">Simulation Error: ${data.error}</div>`;
      return;
    }

    const d = data.decision;
    const allowed = d.allowed;
    const steps = (d.requiredSteps || []).map(s => `<span class="pk-badge pk-badge-info">${s}</span>`).join(' + ');

    box.innerHTML = `
      <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
        <span class="pk-badge ${allowed ? 'pk-badge-pass' : 'pk-badge-fail'}" style="font-size:12px; padding:4px 10px;">
          ${allowed ? 'ACCESS PERMITTED' : 'ACCESS DENIED'}
        </span>
        <span style="font-size:12px; color:#475569;">Required Factors: ${steps || 'None'}</span>
      </div>
      <div style="font-size:12px; color:#1e293b; margin-top:6px;">
        <b>Reason:</b> ${d.reason}
      </div>
    `;
  } catch (err) {
    box.innerHTML = `<div style="color:#dc2626; font-size:12px;">Error: ${err.message}</div>`;
  }
}

window.pkTabFlow = {
  render: pkRenderFlowTab,
  simulate: pkSimulateFlow
};
