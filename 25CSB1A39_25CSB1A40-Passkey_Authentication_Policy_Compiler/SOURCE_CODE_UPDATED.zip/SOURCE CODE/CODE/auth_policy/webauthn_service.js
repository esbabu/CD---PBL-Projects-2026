/**
 * webauthn_service.js
 * 
 * Re-export wrapper for WebAuthn passkey ceremony service.
 */
'use strict';
module.exports = require('./services/webauthn_service');
