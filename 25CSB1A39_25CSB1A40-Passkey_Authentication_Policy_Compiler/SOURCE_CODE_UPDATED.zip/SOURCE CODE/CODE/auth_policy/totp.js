/**
 * totp.js
 * 
 * Re-export wrapper for TOTP service.
 */
'use strict';
module.exports = require('./services/totp');
