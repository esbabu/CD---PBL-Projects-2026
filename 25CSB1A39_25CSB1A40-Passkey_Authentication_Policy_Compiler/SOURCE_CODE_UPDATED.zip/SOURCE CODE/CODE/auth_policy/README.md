# Passkey-First Authentication Policy Compiler

A Zero-Trust authentication policy compiler and multi-agent verification system designed for WebAuthn/FIDO2 passkey-first identity architectures, NIST SP 800-63B-4 assurance classification, and cryptographic auditability.

---

## 🌟 Feature Overview

1. **Passkey-First Authentication DSL**:
   - Express declarative security postures favoring phishing-resistant WebAuthn credentials.
   - Enforce strict downgrade protection (blocking passwords for privileged roles, forbidding insecure fallbacks).
   - Dynamic step-up authentication triggers (`newDevice`, `highRisk`, `sensitiveAction`).
   - Strong multi-factor recovery guarantees requiring at least two distinct out-of-band factors.
   - Seamlessly embed existing password policy DSL blocks for hybrid deployments.

2. **7-Agent Cryptographic Verification Pipeline**:
   - Every policy undergoes 7 sequential AI/static verification agents (`ID-0` through `ID-6`).
   - Every agent envelope is cryptographically signed using Ed25519 (`node:crypto`).
   - Pipeline immediately halts if tampering or security downgrade attacks are detected.

3. **External Persistent Store & Tamper-Evident Audit Chain**:
   - Persists credentials, TOTP secrets, challenges, and audit logs outside the web-served root (`os.tmpdir()/policy_compiler_auth_store.json`).
   - Hash-chained audit trail where each entry contains `SHA-256(previousHash + eventData)`.

4. **FIDO2 / WebAuthn & RFC 6238 TOTP Engine**:
   - Production `@simplewebauthn/server` integration with origin and RP verification.
   - Hardware authenticator sign-counter rollback protection (cloned token detection).
   - Time-based One-Time Password (TOTP) engine with constant-time verification (`crypto.timingSafeEqual`).

5. **Integrated 6-Tab Full-Screen UI Panel**:
   - Accessible via the `🔐 Passkey Auth` header button.
   - Visualizes compilation diagnostics, pipeline latency, NIST badges, interactive SVG state machines, live passkey ceremonies, phishing resistance proof, and the cryptographic audit trail.

---

## 📖 DSL Reference

Authentication policies are written in a line-oriented DSL. Comments begin with `#`. Blank lines are ignored.

```dsl
# Employee Portal Passkey Policy
policy "Employee Portal"
primaryAuth passkey
passwordFallback requireMfa
adminAuth passkeyOnly
stepUpOn newDevice
stepUpOn highRisk
recovery requireTwoFactors
requireUserVerification true
residentKey preferred
passkeyType synced

passwordPolicy {
  minLength 12
  requireUppercase true
  requireSpecial true
  maxAgeDays 90
}
```

### Keywords and Grammar

| Keyword | Allowed Values | Repeatable? | Description |
| :--- | :--- | :---: | :--- |
| `policy` | `"Quoted String"` | No | Human-readable name of the authentication policy. |
| `primaryAuth` | `passkey` \| `passkeyOnly` \| `password` | No | Default primary authentication factor. |
| `passwordFallback` | `none` \| `requireMfa` \| `allow` | No | Fallback behavior when passkey is unavailable. |
| `adminAuth` | `passkeyOnly` \| `passkeyPlusMfa` \| `passwordOnly` | No | Strict requirement for administrative/privileged roles. |
| `stepUpOn` | `newDevice` \| `highRisk` \| `sensitiveAction` | **Yes** | Circumstances demanding an additional authentication step. |
| `recovery` | `requireTwoFactors` \| `requireOneFactor` | No | Minimum distinct factors required for account recovery. |
| `requireUserVerification` | `true` \| `false` | No | Whether biometric or PIN verification is required by WebAuthn. |
| `residentKey` | `required` \| `preferred` | No | Discoverable credential (passkey username-less) preference. |
| `passkeyType` | `synced` \| `deviceBound` | No (Optional) | Multi-device cloud sync vs. hardware FIDO2 security key. |
| `passwordPolicy { ... }` | Existing Password DSL block | No (Optional) | Sub-policy compiled by the existing C++ password engine. |

### Downstream Downgrade Guards
Agent ID-0 proactively blocks insecure configurations with a `DOWNGRADE_BLOCKED` rejection:
- `adminAuth passwordOnly` (privilege downgrade)
- `passwordFallback allow` (unauthenticated or single-factor password bypass)
- `recovery requireOneFactor` (weak account takeover vector)
- `requireUserVerification false` (allowing unverified possession-only tokens)

---

## 🤖 Agent Verification Pipeline

| Agent ID | Name | Role | Inputs | Outputs | Failure Mode |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **ID-0** | **Guard** | Input sanitizer & downgrade blocker | Raw DSL string | Filtered DSL, AST stub | `DOWNGRADE_BLOCKED` or Size > 2000 |
| **ID-1** | **Parser** | Lexer, parser & AST generator | Guarded DSL | Normalized AST JSON | Line/Col syntax or duplicate key error |
| **ID-2** | **Consistency** | Semantic contradiction checker | AST JSON | Validated AST | Contradiction error or lockout warning |
| **ID-3** | **Assurance** | NIST SP 800-63B-4 evaluator | Validated AST | AAL level, Phishing badge | Non-compliant assurance mapping |
| **ID-4** | **Flow Generator** | WebAuthn config & state machine | Validated AST | WebAuthn JSON, FSM, `decide()` | Password compiler compile failure |
| **ID-5** | **Red Team** | Headless virtual authenticator | Flow & WebAuthn cfg | 10 Adversarial results | Attack scenario bypasses verification |
| **ID-6** | **Auditor** | Security score & compliance checklist | All agent findings | Checklist, 0–100 Score, MD report | Score < 70 or critical checklist item |
| **Core** | **Orchestrator** | Cryptographic envelope pipeline | Raw DSL | Signed envelope bundle | Ed25519 signature tamper or invalid hash |

---

## 🚀 How to Demo

### Prerequisites & Starting Server
1. Open PowerShell / Terminal in `CODE`:
   ```bash
   cd "c:\Users\chakr\Password_Policy_Compiler\MY PROJECT\CODE"
   npm start
   ```
2. Open your browser to:
   ```text
   http://localhost:3000
   ```
   > **Note on Origin**: WebAuthn requires a secure context or `localhost`. Do not open `127.0.0.1` unless running the phishing demonstration.

---

## ⏱️ 5-Minute Demo Script

### Step 1: Launch Passkey Auth Compiler (0:00 - 0:45)
1. In the header bar, click the purple **`🔐 Passkey Auth`** button.
2. The full-screen modal opens to **Tab 1: Policy DSL**.
3. Click **"Load Employee Portal Preset"** to populate a Zero-Trust passkey configuration.
4. Click **"🚀 Compile & Enforce Policy"**.
5. Observe the live compilation diagnostics indicating zero syntax errors.

### Step 2: Inspect Agent Pipeline & NIST Assurance (0:45 - 1:45)
1. Switch to **Tab 2: Compile Output**.
2. Notice the horizontal pipeline strip showing `ID-0` through `ID-6`:
   - Each agent displays green execution status, latency in milliseconds, and `Ed25519: VALID`.
3. Review the **NIST SP 800-63B-4** badge:
   - Level: `AAL2`
   - Phishing Resistance: `✅ Phishing-Resistant (WebAuthn FIDO2 / P-256)`
4. View the generated WebAuthn Relying Party Configuration and embedded password constraints.

### Step 3: Interactive Flow & State Machine (1:45 - 2:45)
1. Switch to **Tab 3: Authentication Flow**.
2. Review the inline SVG state machine diagram illustrating the decision pathways.
3. Test the **"What Would Happen?"** simulator:
   - Select Role: `admin`, Has Passkey: `false` $\rightarrow$ Result: **DENIED (Admin requires passkeyOnly)**.
   - Select Role: `employee`, Has Passkey: `false`, Device: `new` $\rightarrow$ Result: **PASSWORD_MFA_STEPUP**.
   - Select Role: `employee`, Has Passkey: `true`, Device: `known` $\rightarrow$ Result: **PASSKEY_UV_DIRECT**.

### Step 4: Live Passkey Demo & Phishing Defense (2:45 - 4:00)
1. Switch to **Tab 4: Live Passkey Demo**:
   - Register or authenticate with a WebAuthn passkey (Windows Hello, Touch ID, or security key).
   - Test password fallback with user `alice` (`Password123!`).
   - Use the live RFC 6238 TOTP simulator box to verify a 6-digit code.
   - Test the two-factor account recovery using backup recovery code + TOTP.
2. Switch to **Tab 5: Phishing Test**:
   - Click **"Open Phishing Clone (127.0.0.1:3000)"**.
   - Explain why WebAuthn cryptographically binds to `localhost` and causes the browser to reject credentials on `127.0.0.1`.
   - Click **"Run Red Team Suite"** to watch the virtual authenticator execute 10 attack scenarios (all PASS).

### Step 5: Cryptographic Audit Trail & Report (4:00 - 5:00)
1. Switch to **Tab 6: Agents & Audit**.
2. Expand an agent's signed envelope to inspect the cryptographic hash and Ed25519 signature.
3. Scroll through the SHA-256 hash-chained audit log; observe `Chain Integrity: VALID`.
4. Click **"Download Markdown"** or **"Download JSON"** to export the signed audit certificate.

---

## 🧪 Verification Commands

```bash
# Verify the 50 passkey auth agent and service unit/integration tests
npm run test:auth

# Verify the 13 Pillars of the core deterministic compiler & neuro-symbolic engine
npm test
```
