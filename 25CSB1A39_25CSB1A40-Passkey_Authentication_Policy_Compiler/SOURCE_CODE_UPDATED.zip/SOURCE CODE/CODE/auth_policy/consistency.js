/**
 * consistency.js
 * 
 * Re-export wrapper for Agent ID-2 Consistency.
 */
'use strict';
module.exports = require('./agents/id2_consistency');
