/**
 * config/nist_mapping.js
 * 
 * Defines NIST SP 800-63B-4 Authenticator Assurance Level (AAL) criteria and mappings.
 * Belongs to the Configuration subsystem (data-only rule repository).
 * Inputs: Policy attributes. Outputs: Assurance levels, phishing resistance flags, and disclaimers.
 */

'use strict';

const NIST_DISCLAIMER = 'educational approximation – verify against SP 800-63B-4';

const ASSURANCE_TIERS = Object.freeze({
  AAL1: Object.freeze({
    level: 'AAL1',
    description: 'Single-factor password authentication or shared secrets.',
    phishingResistant: false
  }),
  AAL2_PHISHABLE: Object.freeze({
    level: 'AAL2',
    description: 'Multi-factor authentication via passwords plus TOTP / out-of-band codes (phishable MFA).',
    phishingResistant: false
  }),
  AAL2_PASSKEY: Object.freeze({
    level: 'AAL2',
    description: 'Multi-factor cryptographic passkey (synced or device-bound) with User Verification.',
    phishingResistant: true
  }),
  AAL3: Object.freeze({
    level: 'AAL3',
    description: 'Hardware-bound cryptographic authenticator (deviceBound passkey) with User Verification.',
    phishingResistant: true
  })
});

// Resolves NIST AAL profile based on parsed policy fields
function resolveNistTier(ast) {
  const primary = ast.primaryAuth || 'password';
  const passkeyType = ast.passkeyType || 'synced';
  const uv = Boolean(ast.requireUserVerification);

  if (primary === 'password') {
    if (ast.passwordFallback === 'requireMfa') {
      return ASSURANCE_TIERS.AAL2_PHISHABLE;
    }
    return ASSURANCE_TIERS.AAL1;
  }

  if (primary === 'passkey' || primary === 'passkeyOnly') {
    if (passkeyType === 'deviceBound' && uv) {
      return ASSURANCE_TIERS.AAL3;
    }
    if (uv) {
      return ASSURANCE_TIERS.AAL2_PASSKEY;
    }
    return ASSURANCE_TIERS.AAL1;
  }

  return ASSURANCE_TIERS.AAL1;
}

module.exports = {
  NIST_DISCLAIMER,
  ASSURANCE_TIERS,
  resolveNistTier
};
