/**
 * config/dsl_keywords.js
 * 
 * Defines valid DSL keywords, allowed enum values, and structural grammar rules.
 * Belongs to the Configuration subsystem (data-only rule repository).
 * Inputs: None. Outputs: Keyword dictionaries and validator helper functions.
 */

'use strict';

const ALLOWED_VALUES = Object.freeze({
  primaryAuth: Object.freeze(['passkey', 'passkeyOnly', 'password']),
  passwordFallback: Object.freeze(['none', 'requireMfa', 'allow']),
  adminAuth: Object.freeze(['passkeyOnly', 'passkeyPlusMfa', 'passwordOnly']),
  stepUpOn: Object.freeze(['newDevice', 'highRisk', 'sensitiveAction']),
  recovery: Object.freeze(['requireTwoFactors', 'requireOneFactor']),
  requireUserVerification: Object.freeze(['true', 'false']),
  residentKey: Object.freeze(['required', 'preferred']),
  passkeyType: Object.freeze(['synced', 'deviceBound'])
});

const REPEATABLE_KEYWORDS = Object.freeze(new Set(['stepUpOn']));
const BLOCK_KEYWORDS = Object.freeze(new Set(['passwordPolicy']));
const ALL_KEYWORDS = Object.freeze(new Set([
  'policy',
  'primaryAuth',
  'passwordFallback',
  'adminAuth',
  'stepUpOn',
  'recovery',
  'requireUserVerification',
  'residentKey',
  'passkeyType',
  'passwordPolicy'
]));

// Returns list of permitted values for a given DSL keyword
function getAllowedValues(keyword) {
  return ALLOWED_VALUES[keyword] || null;
}

// Checks if a DSL keyword can appear multiple times
function isRepeatableKeyword(keyword) {
  return REPEATABLE_KEYWORDS.has(keyword);
}

// Checks if a keyword introduces a multiline nested block
function isBlockKeyword(keyword) {
  return BLOCK_KEYWORDS.has(keyword);
}

// Validates whether an identifier is a recognized DSL keyword
function isValidKeyword(keyword) {
  return ALL_KEYWORDS.has(keyword);
}

module.exports = {
  ALLOWED_VALUES,
  REPEATABLE_KEYWORDS,
  BLOCK_KEYWORDS,
  ALL_KEYWORDS,
  getAllowedValues,
  isRepeatableKeyword,
  isBlockKeyword,
  isValidKeyword
};
