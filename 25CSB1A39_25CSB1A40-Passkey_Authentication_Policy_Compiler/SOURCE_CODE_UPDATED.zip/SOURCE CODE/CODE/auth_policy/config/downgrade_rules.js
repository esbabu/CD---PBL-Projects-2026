/**
 * config/downgrade_rules.js
 * 
 * Defines dangerous downgrade patterns prohibited by Zero-Trust policy rules.
 * Belongs to the Configuration subsystem (data-only rule repository).
 * Inputs: Key/value pairs. Outputs: Downgrade rule definitions and matchers.
 */

'use strict';

const DOWNGRADE_RULES = Object.freeze([
  {
    field: 'adminAuth',
    forbiddenValue: 'passwordOnly',
    severity: 'DOWNGRADE_BLOCKED',
    message: 'Admin authentication cannot be degraded to passwordOnly (passkeys required for privileged roles).'
  },
  {
    field: 'passwordFallback',
    forbiddenValue: 'allow',
    severity: 'DOWNGRADE_BLOCKED',
    message: 'Password fallback cannot allow plain unverified password access (MFA required if password allowed).'
  },
  {
    field: 'recovery',
    forbiddenValue: 'requireOneFactor',
    severity: 'DOWNGRADE_BLOCKED',
    message: 'Account recovery cannot rely on single factor (requireTwoFactors mandatory).'
  },
  {
    field: 'requireUserVerification',
    forbiddenValue: 'false',
    severity: 'DOWNGRADE_BLOCKED',
    message: 'Passkey user verification cannot be disabled (requireUserVerification must be true).'
  }
]);

// Returns all configured downgrade rules
function getDowngradeRules() {
  return DOWNGRADE_RULES;
}

// Checks if a specific key-value pair violates downgrade defenses
function checkDowngradeViolation(field, value) {
  const normalizedVal = String(value).trim();
  return DOWNGRADE_RULES.find(rule => 
    rule.field === field && rule.forbiddenValue === normalizedVal
  ) || null;
}

module.exports = {
  DOWNGRADE_RULES,
  getDowngradeRules,
  checkDowngradeViolation
};
