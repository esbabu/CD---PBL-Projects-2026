/**
 * guard.js
 * 
 * Re-export wrapper for Agent ID-0 Guard.
 */
'use strict';
module.exports = require('./agents/id0_guard');
