/**
 * audit_log.js
 * 
 * Re-export wrapper for Audit Log service.
 */
'use strict';
module.exports = require('./services/audit_log');
