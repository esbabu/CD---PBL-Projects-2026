/**
 * audit_report.js
 * 
 * Re-export wrapper for Agent ID-6 Auditor.
 */
'use strict';
module.exports = require('./agents/id6_auditor');
