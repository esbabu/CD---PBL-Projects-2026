/**
 * flow_generator.js
 * 
 * Re-export wrapper for Agent ID-4 Flow Generator.
 */
'use strict';
module.exports = require('./agents/id4_flow_generator');
