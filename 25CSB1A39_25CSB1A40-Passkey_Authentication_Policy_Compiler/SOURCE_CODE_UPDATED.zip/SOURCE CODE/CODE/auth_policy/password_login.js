/**
 * password_login.js
 * 
 * Re-export wrapper for Password login service.
 */
'use strict';
module.exports = require('./services/password_login');
