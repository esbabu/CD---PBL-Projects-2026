/**
 * services/store.js
 * 
 * Persistent JSON store outside the served directory with hash-chained audit log.
 * Belongs to the Data Storage subsystem.
 * Inputs: Users, credentials, challenges, audit events. Outputs: Stored records and verification.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const totpService = require('./totp');

const STORE_PATH = path.join(os.tmpdir(), 'policy_compiler_auth_store.json');
const GENESIS_HASH = '0'.repeat(64);

// Hashes passwords using scrypt with random salt
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return { salt, hash: derivedKey.toString('hex') };
}

// Verifies a plaintext password against stored salt and scrypt hash
function verifyPassword(password, salt, storedHash) {
  const derivedKey = crypto.scryptSync(password, salt, 64);
  const derivedBuf = Buffer.from(derivedKey.toString('hex'), 'hex');
  const storedBuf = Buffer.from(storedHash, 'hex');
  return crypto.timingSafeEqual(derivedBuf, storedBuf);
}

// Calculates SHA-256 hash for audit chain entry
function computeAuditHash(prevHash, timestamp, action, username, detailsStr) {
  return crypto.createHash('sha256')
    .update(`${prevHash}|${timestamp}|${action}|${username}|${detailsStr}`)
    .digest('hex');
}

class AuthStore {
  constructor(filePath = STORE_PATH) {
    this.filePath = filePath;
    this.data = {
      users: {},
      challenges: {},
      auditLog: [],
      activePolicy: null
    };
    this.init();
  }

  // Initializes store from disk or creates default seeded structure
  init() {
    if (fs.existsSync(this.filePath)) {
      try {
        const raw = fs.readFileSync(this.filePath, 'utf8');
        this.data = JSON.parse(raw);
        return;
      } catch (err) {
        // Fallback to seed if file is corrupted
      }
    }
    this.seedDefaultData();
    this.persist();
  }

  // Seeds default users (alice and admin) and genesis audit entry
  seedDefaultData() {
    const alicePass = hashPassword('AlicePassword123!');
    const adminPass = hashPassword('AdminPassword123!');

    this.data.users = {
      alice: {
        username: 'alice',
        role: 'employee',
        salt: alicePass.salt,
        passwordHash: alicePass.hash,
        passkeys: [],
        totpSecret: totpService.generateSecret(),
        recoveryCodes: ['RC-ALICE-01', 'RC-ALICE-02', 'RC-ALICE-03']
      },
      admin: {
        username: 'admin',
        role: 'admin',
        salt: adminPass.salt,
        passwordHash: adminPass.hash,
        passkeys: [],
        totpSecret: totpService.generateSecret(),
        recoveryCodes: ['RC-ADMIN-01', 'RC-ADMIN-02', 'RC-ADMIN-03']
      }
    };

    const genesisTs = Date.now();
    const genesisHash = computeAuditHash(GENESIS_HASH, genesisTs, 'GENESIS', 'system', '{}');
    this.data.auditLog = [{
      id: 1,
      timestamp: genesisTs,
      action: 'GENESIS',
      username: 'system',
      details: {},
      prevHash: GENESIS_HASH,
      hash: genesisHash
    }];

    this.data.challenges = {};
    this.data.activePolicy = null;
  }

  // Persists current in-memory store safely to disk
  persist() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf8');
    } catch (err) {
      // Ignored for concurrent file locks during testing
    }
  }

  // Appends a hash-chained event to the audit log
  appendAudit(action, username, details = {}) {
    const lastEntry = this.data.auditLog[this.data.auditLog.length - 1];
    const prevHash = lastEntry ? lastEntry.hash : GENESIS_HASH;
    const timestamp = Date.now();
    const detailsStr = JSON.stringify(details);
    const hash = computeAuditHash(prevHash, timestamp, action, username, detailsStr);

    const entry = {
      id: this.data.auditLog.length + 1,
      timestamp,
      action,
      username,
      details,
      prevHash,
      hash
    };

    this.data.auditLog.push(entry);
    this.persist();
    return entry;
  }

  // Validates the cryptographic integrity of the entire audit chain
  verifyAuditChain() {
    for (let i = 0; i < this.data.auditLog.length; i++) {
      const entry = this.data.auditLog[i];
      const prevHash = i === 0 ? GENESIS_HASH : this.data.auditLog[i - 1].hash;
      if (entry.prevHash !== prevHash) return false;
      const computed = computeAuditHash(prevHash, entry.timestamp, entry.action, entry.username, JSON.stringify(entry.details));
      if (entry.hash !== computed) return false;
    }
    return true;
  }

  // Saves a single-use WebAuthn challenge with a 5-minute expiration
  saveChallenge(challenge, username, type) {
    this.data.challenges[challenge] = {
      challenge,
      username,
      type,
      expiresAt: Date.now() + 5 * 60 * 1000,
      used: false
    };
    this.persist();
  }

  // Consumes a challenge ensuring single-use and expiration checks
  consumeChallenge(challenge, type) {
    const record = this.data.challenges[challenge];
    if (!record) return null;
    if (record.used) return null;
    if (Date.now() > record.expiresAt) return null;
    if (type && record.type !== type) return null;

    record.used = true;
    delete this.data.challenges[challenge];
    this.persist();
    return record;
  }

  getUser(username) {
    return this.data.users[username] || null;
  }

  saveUser(user) {
    this.data.users[user.username] = user;
    this.persist();
  }

  setActivePolicy(policy) {
    this.data.activePolicy = policy;
    this.persist();
  }

  getActivePolicy() {
    return this.data.activePolicy;
  }

  getAuditLog() {
    return [...this.data.auditLog];
  }
}

const defaultStore = new AuthStore();

module.exports = {
  AuthStore,
  defaultStore,
  hashPassword,
  verifyPassword,
  computeAuditHash,
  STORE_PATH
};
