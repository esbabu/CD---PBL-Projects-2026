/**
 * services/autofix.js
 * 
 * Deterministic Auto-Error Fix service for Auth Policy DSL.
 * Analyzes syntax, downgrade, and consistency errors and produces safe automatic
 * replacements or user-selectable suggestions without AI/LLM calls.
 * Belongs to the Authentication Services subsystem.
 * Inputs: dslText string. Outputs: Array of fix objects { line, col, before, after, reason, kind }.
 */

'use strict';

const {
  isValidKeyword,
  isRepeatableKeyword,
  isBlockKeyword,
  getAllowedValues,
  ALL_KEYWORDS
} = require('../config/dsl_keywords');

const { getDowngradeRules } = require('../config/downgrade_rules');
const { levenshteinDistance, findClosestCandidate } = require('../utils');
const id1 = require('../agents/id1_parser');
const id2 = require('../agents/id2_consistency');

const STRONGER_VALUES = Object.freeze({
  adminAuth: 'passkeyOnly',
  passwordFallback: 'requireMfa',
  recovery: 'requireTwoFactors',
  requireUserVerification: 'true'
});

// Replaces target string on specified line in DSL text
function applyFix(dslText, fix) {
  if (!fix || fix.after === null || fix.after === undefined) return dslText;
  const lines = dslText.split('\n');
  const lineIdx = fix.line - 1;

  if (lineIdx < 0 || lineIdx >= lines.length) {
    if (fix.before === '' && fix.after === '}') {
      lines.push('}');
      return lines.join('\n');
    }
    return dslText;
  }

  const rawLine = lines[lineIdx];
  if (fix.before === '' && fix.after === '}') {
    lines.push('}');
    return lines.join('\n');
  }

  if (rawLine.includes(fix.before)) {
    lines[lineIdx] = rawLine.replace(fix.before, fix.after);
  }
  return lines.join('\n');
}

// Applies all safe automatic fixes to DSL text
function applySafeFixes(dslText, fixes) {
  let result = dslText;
  const safeFixes = (fixes || []).filter(f => f.kind === 'auto' && f.after !== null);
  for (const fix of safeFixes) {
    result = applyFix(result, fix);
  }
  return result;
}

// Inspects a single pass of DSL text for syntax, downgrade, and consistency errors
function collectPassFixes(text) {
  const fixes = [];
  const lines = text.split('\n');
  const addFix = (line, col, before, after, reason, kind) => {
    fixes.push({ line, col, before, after, reason, kind });
  };

  // 1. Agent ID-0 Downgrade Defense screening
  let inPasswordPolicy = false;
  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();

    if (inPasswordPolicy) {
      if (trimmed === '}' || trimmed.startsWith('}')) inPasswordPolicy = false;
      continue;
    }
    if (trimmed.startsWith('#') || !trimmed) continue;
    if (trimmed.startsWith('passwordPolicy')) {
      inPasswordPolicy = true;
      continue;
    }

    for (const rule of getDowngradeRules()) {
      const pattern = new RegExp(`^${rule.field}\\s+${rule.forbiddenValue}\\b`);
      if (pattern.test(trimmed)) {
        const stronger = STRONGER_VALUES[rule.field] || 'passkeyOnly';
        addFix(i + 1, rawLine.indexOf(rule.field) + 1, `${rule.field} ${rule.forbiddenValue}`, `${rule.field} ${stronger}`,
          `Downgrade defense: replace ${rule.forbiddenValue} with ${stronger} for ${rule.field}`, 'suggested');
      }
    }
  }

  // 2. Agent ID-1 Parser & Lexer screening
  inPasswordPolicy = false;
  const seenKeys = new Set();

  for (let i = 0; i < lines.length; i++) {
    const lineNum = i + 1;
    const rawLine = lines[i];

    if (inPasswordPolicy) {
      const trimmed = rawLine.trim();
      if (trimmed === '}' || trimmed.startsWith('}')) inPasswordPolicy = false;
      continue;
    }

    const commentIdx = rawLine.indexOf('#');
    const lineWithoutComment = (commentIdx >= 0 ? rawLine.slice(0, commentIdx) : rawLine).trim();
    if (!lineWithoutComment) continue;

    const tokens = lineWithoutComment.split(/\s+/);
    const keyword = tokens[0];
    const col = rawLine.indexOf(keyword) + 1;

    // Block keyword check (passwordPolicy)
    if (isBlockKeyword(keyword)) {
      if (seenKeys.has(keyword)) {
        addFix(lineNum, col, keyword, null, `Duplicate keyword '${keyword}' (manual review required)`, 'suggested');
        continue;
      }
      seenKeys.add(keyword);
      if (!lineWithoutComment.includes('{')) {
        addFix(lineNum, col, lineWithoutComment, `${lineWithoutComment} {`, `Add missing '{' to start '${keyword}' block`, 'auto');
      }
      inPasswordPolicy = true;
      continue;
    }

    // Unknown keyword check
    if (!isValidKeyword(keyword)) {
      const match = findClosestCandidate(keyword, Array.from(ALL_KEYWORDS), 2);
      if (match.winner) {
        addFix(lineNum, col, keyword, match.winner, `Unknown keyword: replace with '${match.winner}'`, 'auto');
      } else if (match.tie) {
        addFix(lineNum, col, keyword, null, `Ambiguous keyword '${keyword}': equally close to ${match.matches.map(m => `'${m}'`).join(' and ')}`, 'suggested');
      } else {
        addFix(lineNum, col, keyword, null, `Unknown keyword '${keyword}' (no close match)`, 'suggested');
      }
      continue;
    }

    // Duplicate non-repeatable keyword check
    if (seenKeys.has(keyword) && !isRepeatableKeyword(keyword)) {
      addFix(lineNum, col, keyword, null, `Duplicate keyword '${keyword}' (manual review required)`, 'suggested');
      continue;
    }
    seenKeys.add(keyword);

    // Missing value check
    if (tokens.length < 2) {
      addFix(lineNum, col, keyword, null, `Missing value for keyword '${keyword}'`, 'suggested');
      continue;
    }

    // Policy unquoted name check
    if (keyword === 'policy') {
      if (!lineWithoutComment.match(/^policy\s+"([^"]*)"$/)) {
        const m = lineWithoutComment.match(/^policy\s+(.+)$/);
        const name = m ? m[1].trim().replace(/^"+|"+$/g, '') : 'Default Policy';
        addFix(lineNum, col, lineWithoutComment, `policy "${name}"`, 'Enclose policy name in double quotes', 'auto');
      }
      continue;
    }

    // Invalid enum value check
    const value = tokens[1];
    const allowed = getAllowedValues(keyword);
    if (allowed && !allowed.includes(value)) {
      const match = findClosestCandidate(value, allowed, 2);
      if (match.winner) {
        addFix(lineNum, rawLine.indexOf(value) + 1, value, match.winner, `Invalid value: replace '${value}' with '${match.winner}'`, 'auto');
      } else if (match.tie) {
        addFix(lineNum, rawLine.indexOf(value) + 1, value, null, `Ambiguous value '${value}': equally close to ${match.matches.map(m => `'${m}'`).join(' and ')}`, 'suggested');
      } else {
        addFix(lineNum, rawLine.indexOf(value) + 1, value, null, `Invalid value '${value}' for '${keyword}' (expected: ${allowed.join(', ')})`, 'suggested');
      }
    }
  }

  // Unterminated block check
  if (inPasswordPolicy) {
    addFix(lines.length, 1, '', '}', `Add missing '}' to close unterminated block`, 'auto');
  }

  // 3. Agent ID-2 Consistency check
  const parseRes = id1.run(text);
  if (parseRes.ok && parseRes.output) {
    const consistencyRes = id2.run(parseRes.output);
    for (const f of consistencyRes.findings) {
      if (f.type === 'CONTRADICTION' && f.field === 'passwordFallback') {
        const idx = lines.findIndex(l => l.trim().startsWith('passwordFallback'));
        if (idx >= 0) addFix(idx + 1, lines[idx].indexOf('passwordFallback') + 1, lines[idx].trim(), 'passwordFallback none',
          'Contradiction: primaryAuth is passkeyOnly, passwordFallback must be none', 'suggested');
      }
      if (f.type === 'LOCKOUT_RISK' && f.field === 'recovery') {
        const idx = lines.findIndex(l => l.trim().startsWith('recovery'));
        if (idx >= 0) addFix(idx + 1, lines[idx].indexOf('recovery') + 1, lines[idx].trim(), 'recovery requireTwoFactors',
          'Lockout risk: adminAuth passkeyOnly requires two-factor recovery', 'suggested');
      }
    }
  }

  return fixes;
}

// Multi-pass auto-fix runner executing up to 3 passes
function suggestFixes(dslText) {
  let currentText = dslText || '';
  const allFixes = [];
  const seenFixKeys = new Set();

  for (let pass = 1; pass <= 3; pass++) {
    const passFixes = collectPassFixes(currentText);
    for (const fix of passFixes) {
      const key = `${fix.line}:${fix.before}:${fix.after}:${fix.kind}`;
      if (!seenFixKeys.has(key)) {
        seenFixKeys.add(key);
        allFixes.push(fix);
      }
    }
    const safeFixes = passFixes.filter(f => f.kind === 'auto' && f.after !== null);
    if (safeFixes.length === 0) break;
    currentText = applySafeFixes(currentText, safeFixes);
  }

  return allFixes;
}

module.exports = {
  suggestFixes,
  applyFix,
  applySafeFixes,
  levenshteinDistance,
  findClosestCandidate
};
