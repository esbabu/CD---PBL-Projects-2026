/**
 * services/audit_log.js
 * 
 * Cryptographic hash-chained audit logging service.
 * Belongs to the Authentication Services subsystem.
 * Inputs: Actions, usernames, metadata. Outputs: Linked audit records and integrity verification.
 */

'use strict';

const { defaultStore } = require('./store');

// Records an audit event into the hash chain
function logEvent(action, username, details = {}, store = defaultStore) {
  return store.appendAudit(action, username, details);
}

// Retrieves all recorded audit entries
function getAuditTrail(store = defaultStore) {
  return store.getAuditLog();
}

// Validates cryptographic linkage of all audit entries
function verifyIntegrity(store = defaultStore) {
  return store.verifyAuditChain();
}

module.exports = {
  logEvent,
  getAuditTrail,
  verifyIntegrity
};
