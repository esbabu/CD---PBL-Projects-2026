/**
 * services/password_login.js
 * 
 * Verifies password authentication against scrypt hashes and policy requirements.
 * Belongs to the Authentication Services subsystem.
 * Inputs: username, password, context. Outputs: Authentication status and MFA requirements.
 */

'use strict';

const { defaultStore, verifyPassword } = require('./store');

// Validates password login against active policy rules and user credentials
function authenticatePassword(username, password, context = {}, store = defaultStore) {
  const user = store.getUser(username);
  if (!user) {
    return { ok: false, error: 'Invalid username or password.' };
  }

  const valid = verifyPassword(password, user.salt, user.passwordHash);
  if (!valid) {
    store.appendAudit('PASSWORD_LOGIN_FAILED', username, { reason: 'Bad credentials' });
    return { ok: false, error: 'Invalid username or password.' };
  }

  const activePolicy = store.getActivePolicy();
  const decide = activePolicy?.flow?.decide || (() => ({ allowed: true, requiredSteps: ['password'] }));

  const decisionContext = {
    role: user.role,
    deviceKnown: context.deviceKnown !== undefined ? context.deviceKnown : true,
    risk: context.risk || 'low',
    hasPasskey: user.passkeys && user.passkeys.length > 0,
    requestedMethod: 'password'
  };

  const decision = decide(decisionContext);

  if (user.role === 'admin' && activePolicy?.ast?.adminAuth === 'passkeyOnly') {
    store.appendAudit('ADMIN_PASSWORD_DENIED', username, { reason: 'Admin requires passkeyOnly' });
    return {
      ok: false,
      error: 'Access Denied: Administrator role strictly requires passkeyOnly authentication.'
    };
  }

  if (!decision.allowed) {
    store.appendAudit('PASSWORD_LOGIN_POLICY_BLOCKED', username, { reason: decision.reason });
    return {
      ok: false,
      error: `Access Denied by Policy: ${decision.reason}`
    };
  }

  if (decision.requiredSteps.includes('mfa')) {
    store.appendAudit('PASSWORD_STEP_UP_MFA_REQUIRED', username, { steps: decision.requiredSteps });
    return {
      ok: true,
      requiresMfa: true,
      mfaType: 'totp',
      message: 'Password verified. Multi-factor authentication code (TOTP) is required.'
    };
  }

  store.appendAudit('PASSWORD_LOGIN_SUCCESS', username, { role: user.role });
  return {
    ok: true,
    requiresMfa: false,
    authenticated: true,
    user: { username: user.username, role: user.role }
  };
}

module.exports = { authenticatePassword };
