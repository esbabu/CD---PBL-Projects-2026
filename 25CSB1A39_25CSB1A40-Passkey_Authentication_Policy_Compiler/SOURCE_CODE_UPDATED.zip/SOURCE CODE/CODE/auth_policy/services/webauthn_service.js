/**
 * services/webauthn_service.js
 * 
 * FIDO2 / WebAuthn passkey ceremony engine using @simplewebauthn/server.
 * Enforces single-use challenges, origin & rpID binding, user verification, and counter validation.
 * Belongs to the Authentication Services subsystem.
 * Inputs: Registration/Login ceremony payloads. Outputs: Challenge options and verification results.
 */

'use strict';

const { defaultStore } = require('./store');

let simpleWebAuthnMod = null;

// Dynamically loads ESM @simplewebauthn/server in CommonJS environment
async function getSimpleWebAuthn() {
  if (!simpleWebAuthnMod) {
    simpleWebAuthnMod = await import('@simplewebauthn/server');
  }
  return simpleWebAuthnMod;
}

function getRpId() {
  return 'localhost';
}

function getExpectedOrigin() {
  const port = process.env.PORT || 3000;
  return `http://localhost:${port}`;
}

// Generates WebAuthn registration options for a given username
async function generateRegisterOptions(username, policy = null, store = defaultStore) {
  const swa = await getSimpleWebAuthn();
  const user = store.getUser(username);
  if (!user) throw new Error(`User '${username}' not found.`);

  const activePolicy = policy || store.getActivePolicy()?.ast || {};
  const uvRequired = Boolean(activePolicy.requireUserVerification);

  const options = await swa.generateRegistrationOptions({
    rpName: activePolicy.policy || 'Passkey Policy Compiler RP',
    rpID: getRpId(),
    userName: username,
    userID: new TextEncoder().encode(username),
    userDisplayName: username === 'admin' ? 'System Administrator' : 'Standard Employee',
    authenticatorSelection: {
      userVerification: uvRequired ? 'required' : 'preferred',
      residentKey: activePolicy.residentKey || 'preferred'
    },
    timeout: 60000,
    attestationType: 'none'
  });

  store.saveChallenge(options.challenge, username, 'register');
  return options;
}

// Verifies a WebAuthn registration assertion and stores the credential
async function verifyRegisterResponse(username, body, policy = null, store = defaultStore) {
  const swa = await getSimpleWebAuthn();
  const user = store.getUser(username);
  if (!user) throw new Error(`User '${username}' not found.`);

  const challenge = body.challenge || body.rawChallenge;
  const challengeRecord = store.consumeChallenge(challenge, 'register');
  if (!challengeRecord || challengeRecord.username !== username) {
    throw new Error('Invalid, expired, or replayed registration challenge.');
  }

  const activePolicy = policy || store.getActivePolicy()?.ast || {};
  const requireUserVerification = Boolean(activePolicy.requireUserVerification);

  const verification = await swa.verifyRegistrationResponse({
    response: body,
    expectedChallenge: challengeRecord.challenge,
    expectedOrigin: getExpectedOrigin(),
    expectedRPID: getRpId(),
    requireUserVerification
  });

  if (!verification.verified || !verification.registrationInfo) {
    throw new Error('WebAuthn registration verification failed.');
  }

  const { credential } = verification.registrationInfo;
  const newPasskey = {
    id: credential.id,
    publicKey: Buffer.from(credential.publicKey).toString('base64'),
    counter: credential.counter,
    transports: body.response?.transports || [],
    createdAt: Date.now()
  };

  user.passkeys.push(newPasskey);
  store.saveUser(user);
  store.appendAudit('PASSKEY_REGISTER_SUCCESS', username, { credentialId: credential.id });

  return { verified: true, credentialId: credential.id };
}

// Generates WebAuthn authentication options for user login
async function generateLoginOptions(username, policy = null, store = defaultStore) {
  const swa = await getSimpleWebAuthn();
  const user = store.getUser(username);
  if (!user) throw new Error(`User '${username}' not found.`);

  const activePolicy = policy || store.getActivePolicy()?.ast || {};
  const uvRequired = Boolean(activePolicy.requireUserVerification);

  const allowCredentials = user.passkeys.map(pk => ({
    id: pk.id,
    transports: pk.transports
  }));

  const options = await swa.generateAuthenticationOptions({
    rpID: getRpId(),
    allowCredentials,
    userVerification: uvRequired ? 'required' : 'preferred',
    timeout: 60000
  });

  store.saveChallenge(options.challenge, username, 'login');
  return options;
}

// Verifies a WebAuthn authentication assertion and inspects sign-counters
async function verifyLoginResponse(username, body, policy = null, store = defaultStore) {
  const swa = await getSimpleWebAuthn();
  const user = store.getUser(username);
  if (!user) throw new Error(`User '${username}' not found.`);

  const challengeRecord = store.consumeChallenge(body.challenge, 'login');
  if (!challengeRecord || challengeRecord.username !== username) {
    throw new Error('Invalid, expired, or replayed login challenge.');
  }

  const passkey = user.passkeys.find(pk => pk.id === body.id);
  if (!passkey) throw new Error('Unrecognized credential ID for user.');

  const activePolicy = policy || store.getActivePolicy()?.ast || {};
  const requireUserVerification = Boolean(activePolicy.requireUserVerification);

  let verification;
  try {
    verification = await swa.verifyAuthenticationResponse({
      response: body,
      expectedChallenge: challengeRecord.challenge,
      expectedOrigin: getExpectedOrigin(),
      expectedRPID: getRpId(),
      credential: {
        id: passkey.id,
        publicKey: Buffer.from(passkey.publicKey, 'base64'),
        counter: passkey.counter
      },
      requireUserVerification
    });
  } catch (err) {
    if (err.message && (err.message.includes('lower than expected') || err.message.includes('counter'))) {
      store.appendAudit('PASSKEY_COUNTER_ROLLBACK_BLOCKED', username, { storedCounter: passkey.counter });
      throw new Error(`Sign-count rollback detected: ${err.message}`);
    }
    throw err;
  }

  if (!verification.verified || !verification.authenticationInfo) {
    throw new Error('WebAuthn authentication assertion verification failed.');
  }

  const { newCounter } = verification.authenticationInfo;

  // Reject sign-count rollback only when both counters are non-zero (synced passkeys report 0)
  if (passkey.counter > 0 && newCounter > 0 && newCounter <= passkey.counter) {
    store.appendAudit('PASSKEY_COUNTER_ROLLBACK_BLOCKED', username, {
      storedCounter: passkey.counter,
      presentedCounter: newCounter
    });
    throw new Error(`Sign-count rollback detected (${newCounter} <= ${passkey.counter}). Possible cloned credential.`);
  }

  passkey.counter = newCounter;
  store.saveUser(user);
  store.appendAudit('PASSKEY_LOGIN_SUCCESS', username, { credentialId: passkey.id, newCounter });

  return { verified: true, counter: newCounter };
}

module.exports = {
  getRpId,
  getExpectedOrigin,
  generateRegisterOptions,
  verifyRegisterResponse,
  generateLoginOptions,
  verifyLoginResponse
};
