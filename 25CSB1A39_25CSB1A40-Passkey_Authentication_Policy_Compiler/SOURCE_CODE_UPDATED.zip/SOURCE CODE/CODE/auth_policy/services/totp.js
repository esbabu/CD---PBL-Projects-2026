/**
 * services/totp.js
 * 
 * Implements RFC 6238 Time-Based One-Time Password (TOTP) algorithm using node:crypto.
 * Belongs to the Authentication Services subsystem.
 * Inputs: Base32 secret, 6-digit token, time step. Outputs: Generated codes, verification booleans.
 */

'use strict';

const crypto = require('crypto');

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

// Decodes a standard Base32 encoded string into a Buffer
function base32ToBuffer(base32Str) {
  const clean = base32Str.toUpperCase().replace(/[\s=-]/g, '');
  let bits = 0;
  let value = 0;
  const bytes = [];

  for (let i = 0; i < clean.length; i++) {
    const idx = BASE32_ALPHABET.indexOf(clean[i]);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }

  return Buffer.from(bytes);
}

// Generates a random Base32 encoded secret key
function generateSecret(numBytes = 20) {
  const buffer = crypto.randomBytes(numBytes);
  let bits = 0;
  let value = 0;
  let output = '';

  for (let i = 0; i < buffer.length; i++) {
    value = (value << 8) | buffer[i];
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }

  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }

  return output;
}

// Calculates RFC 4226 HOTP code for a given counter
function generateHotp(secretBuffer, counter) {
  const counterBuffer = Buffer.alloc(8);
  counterBuffer.writeBigUInt64BE(BigInt(counter));

  const hmac = crypto.createHmac('sha1', secretBuffer).update(counterBuffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = (
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff)
  ) % 1000000;

  return String(code).padStart(6, '0');
}

// Returns the current 6-digit TOTP code for the authenticator simulator
function currentCode(secret, timeMs = Date.now(), stepSeconds = 30) {
  const secretBuf = typeof secret === 'string' ? base32ToBuffer(secret) : secret;
  const step = Math.floor(timeMs / (stepSeconds * 1000));
  return generateHotp(secretBuf, step);
}

// Verifies a 6-digit token using constant-time comparison within a +/-1 window
function verifyCode(secret, token, window = 1, timeMs = Date.now(), stepSeconds = 30) {
  if (!token || typeof token !== 'string') return false;
  const normalizedToken = token.trim();
  if (normalizedToken.length !== 6 || !/^\d{6}$/.test(normalizedToken)) return false;

  const secretBuf = typeof secret === 'string' ? base32ToBuffer(secret) : secret;
  const currentStep = Math.floor(timeMs / (stepSeconds * 1000));
  const tokenBuf = Buffer.from(normalizedToken, 'utf8');

  for (let w = -window; w <= window; w++) {
    const candidate = generateHotp(secretBuf, currentStep + w);
    const candidateBuf = Buffer.from(candidate, 'utf8');
    if (crypto.timingSafeEqual(candidateBuf, tokenBuf)) {
      return true;
    }
  }

  return false;
}

module.exports = {
  generateSecret,
  currentCode,
  verifyCode,
  base32ToBuffer
};
