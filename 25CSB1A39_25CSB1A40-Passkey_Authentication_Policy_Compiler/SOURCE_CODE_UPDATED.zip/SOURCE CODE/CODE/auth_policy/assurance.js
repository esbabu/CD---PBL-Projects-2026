/**
 * assurance.js
 * 
 * Re-export wrapper for Agent ID-3 Assurance.
 */
'use strict';
module.exports = require('./agents/id3_assurance');
