/**
 * agents.js
 * 
 * Re-export wrapper for Orchestrator running Agent ID-0 through ID-6.
 */
'use strict';
module.exports = require('./agents/orchestrator');
