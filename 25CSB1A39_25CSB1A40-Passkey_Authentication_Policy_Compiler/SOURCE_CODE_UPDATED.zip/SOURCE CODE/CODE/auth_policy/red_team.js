/**
 * red_team.js
 * 
 * Re-export wrapper for Red Team agent and headless virtual authenticator.
 */
'use strict';
module.exports = require('./agents/id5_red_team');
