/**
 * agents/id2_consistency.js
 * 
 * Agent ID-2: Policy Semantic & Consistency Verifier.
 * Detects contradictions between primary auth, fallbacks, admin policies, and recovery.
 * Belongs to the Agent Pipeline subsystem.
 * Inputs: AST object. Outputs: { ok, output: ast, findings[] }.
 */

'use strict';

// Verifies semantic consistency and catches contradictions across policy rules
function run(input) {
  const ast = (input && input.output) || input || {};
  const findings = [];

  if (ast.primaryAuth === 'passkeyOnly' && ast.passwordFallback && ast.passwordFallback !== 'none') {
    findings.push({
      severity: 'ERROR',
      type: 'CONTRADICTION',
      field: 'passwordFallback',
      message: `Contradiction: primaryAuth is 'passkeyOnly', but passwordFallback is '${ast.passwordFallback}'. Fallback must be 'none'.`
    });
  }

  const hasStrongMethod = ast.primaryAuth === 'passkey' || 
                          ast.primaryAuth === 'passkeyOnly' || 
                          ast.adminAuth === 'passkeyOnly' || 
                          ast.adminAuth === 'passkeyPlusMfa' || 
                          ast.passwordFallback === 'requireMfa';

  if (Array.isArray(ast.stepUpOn) && ast.stepUpOn.length > 0 && !hasStrongMethod) {
    findings.push({
      severity: 'ERROR',
      type: 'CONTRADICTION',
      field: 'stepUpOn',
      message: `Contradiction: stepUpOn is specified (${ast.stepUpOn.join(', ')}), but no strong authentication method (passkey or MFA) is available.`
    });
  }

  if (ast.adminAuth === 'passkeyOnly' && (!ast.recovery || ast.recovery !== 'requireTwoFactors')) {
    findings.push({
      severity: 'WARNING',
      type: 'LOCKOUT_RISK',
      field: 'recovery',
      message: `Lockout Risk Warning: adminAuth is 'passkeyOnly' without two-factor recovery. Administrators face permanent lockout if passkey is lost.`
    });
  }

  if (ast.primaryAuth === 'passkeyOnly' && ast.residentKey === 'preferred') {
    findings.push({
      severity: 'WARNING',
      type: 'CONFIG_ADVISORY',
      field: 'residentKey',
      message: `Advisory: residentKey is 'preferred' under 'passkeyOnly'. Consider 'required' for seamless discoverable credentials.`
    });
  }

  const hasErrors = findings.some(f => f.severity === 'ERROR');
  return {
    ok: !hasErrors,
    output: hasErrors ? null : ast,
    findings
  };
}

module.exports = { run };
