/**
 * agents/id3_assurance.js
 * 
 * Agent ID-3: NIST SP 800-63B-4 Assurance Level Classifier.
 * Maps policy rules to Authenticator Assurance Levels (AAL1/AAL2/AAL3) and phishing resistance.
 * Belongs to the Agent Pipeline subsystem.
 * Inputs: AST object. Outputs: { ok, output: { nistLevel, phishingResistant, disclaimer }, findings[] }.
 */

'use strict';

const { resolveNistTier, NIST_DISCLAIMER } = require('../config/nist_mapping');

// Evaluates NIST SP 800-63B-4 authenticator assurance level
function run(input) {
  const ast = (input && input.output) || input || {};
  const findings = [];
  const tier = resolveNistTier(ast);

  findings.push({
    severity: 'INFO',
    level: tier.level,
    phishingResistant: tier.phishingResistant,
    message: `NIST SP 800-63B-4 Evaluated: ${tier.level} (${tier.description})`
  });

  const output = {
    nistLevel: tier.level,
    phishingResistant: tier.phishingResistant,
    description: tier.description,
    disclaimer: NIST_DISCLAIMER
  };

  return {
    ok: true,
    output,
    findings
  };
}

module.exports = { run };
