/**
 * agents/orchestrator.js
 * 
 * Multi-Agent Pipeline Orchestrator.
 * Sequentially invokes Agent ID-0 through ID-6, cryptographically signs each agent's
 * output using Ed25519 keys, verifies signatures, and tracks execution latency.
 * Belongs to the Agent Pipeline subsystem.
 * Inputs: dslText string or object. Outputs: { ok, results, auditReport, signaturesValid, latencyMs }.
 */

'use strict';

const id0 = require('./id0_guard');
const id1 = require('./id1_parser');
const id2 = require('./id2_consistency');
const id3 = require('./id3_assurance');
const id4 = require('./id4_flow_generator');
const id5 = require('./id5_red_team');
const id6 = require('./id6_auditor');

const {
  generateAgentKeyPair,
  signPayload,
  verifySignature,
  createTamperedCopy
} = require('../utils');

const AGENT_KEYS = {
  'ID-0': generateAgentKeyPair(),
  'ID-1': generateAgentKeyPair(),
  'ID-2': generateAgentKeyPair(),
  'ID-3': generateAgentKeyPair(),
  'ID-4': generateAgentKeyPair(),
  'ID-5': generateAgentKeyPair(),
  'ID-6': generateAgentKeyPair()
};

// Signs an agent execution result using its dedicated Ed25519 key
function createSignedEnvelope(agentId, name, result, latencyMs) {
  const keys = AGENT_KEYS[agentId];
  const payload = {
    agentId,
    name,
    ok: result.ok,
    output: result.output,
    findings: result.findings,
    latencyMs
  };
  const signature = signPayload(keys.privateKey, payload);
  return {
    agentId,
    name,
    publicKey: keys.publicKey,
    signature,
    payload
  };
}

// Verifies the cryptographic integrity of an agent output envelope
function verifyEnvelope(envelope) {
  if (!envelope || !envelope.publicKey || !envelope.signature || !envelope.payload) {
    return false;
  }
  return verifySignature(envelope.publicKey, envelope.payload, envelope.signature);
}

// Tamper helper exposed for unit testing cryptographic rejection
function tamper(envelope, field = 'output', value = 'TAMPERED') {
  return createTamperedCopy(envelope, field, value);
}

// Executes the entire 7-agent pipeline with cryptographic verification
async function run(input) {
  const dslText = typeof input === 'string' ? input : (input && input.dslText) || '';
  const startTime = Date.now();
  const stages = [];
  const allFindings = [];
  let allSignaturesValid = true;

  // Helper to run, sign, and verify a single agent
  function executeAgent(agentId, name, agentModule, agentInput) {
    const t0 = Date.now();
    const res = agentModule.run(agentInput);
    const lat = Date.now() - t0;
    const envelope = createSignedEnvelope(agentId, name, res, lat);
    const valid = verifyEnvelope(envelope);
    if (!valid) allSignaturesValid = false;

    if (res.findings && res.findings.length > 0) {
      allFindings.push(...res.findings);
    }

    stages.push({
      agentId,
      name,
      ok: res.ok,
      latencyMs: lat,
      signatureValid: valid,
      envelope,
      result: res
    });

    return res;
  }

  // ID-0: Guard
  const res0 = executeAgent('ID-0', 'Guard', id0, dslText);
  if (!res0.ok) {
    return {
      ok: false,
      stoppedAt: 'ID-0',
      stages,
      findings: allFindings,
      signaturesValid: allSignaturesValid,
      latencyMs: Date.now() - startTime
    };
  }

  // ID-1: Parser
  const res1 = executeAgent('ID-1', 'Parser', id1, res0.output);
  if (!res1.ok) {
    return {
      ok: false,
      stoppedAt: 'ID-1',
      stages,
      findings: allFindings,
      signaturesValid: allSignaturesValid,
      latencyMs: Date.now() - startTime
    };
  }

  const ast = res1.output;

  // ID-2: Consistency
  const res2 = executeAgent('ID-2', 'Consistency', id2, ast);
  if (!res2.ok) {
    return {
      ok: false,
      stoppedAt: 'ID-2',
      stages,
      findings: allFindings,
      signaturesValid: allSignaturesValid,
      latencyMs: Date.now() - startTime
    };
  }

  // ID-3: Assurance
  const res3 = executeAgent('ID-3', 'Assurance', id3, ast);

  // ID-4: Flow Generator
  const res4 = executeAgent('ID-4', 'FlowGenerator', id4, ast);

  // ID-5: Red Team
  const res5 = executeAgent('ID-5', 'RedTeam', id5, { ast, flow: res4.output });

  // ID-6: Auditor
  const res6 = executeAgent('ID-6', 'Auditor', id6, {
    ast,
    assurance: res3.output,
    flow: res4.output,
    redTeam: res5.output,
    allFindings
  });

  return {
    ok: true,
    ast,
    stages,
    assurance: res3.output,
    flow: res4.output,
    redTeam: res5.output,
    auditReport: res6.output,
    findings: allFindings,
    signaturesValid: allSignaturesValid,
    latencyMs: Date.now() - startTime
  };
}

module.exports = {
  run,
  runPipeline: run,
  createSignedEnvelope,
  verifyEnvelope,
  tamper,
  AGENT_KEYS
};
