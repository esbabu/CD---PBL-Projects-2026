/**
 * agents/id4_flow_generator.js
 * 
 * Agent ID-4: Authentication Flow & State Machine Generator.
 * Emits WebAuthn RP options, login state machine, and evaluates decide(context).
 * Integrates read-only password policy compilation from compiler_engine.
 * Belongs to the Agent Pipeline subsystem.
 * Inputs: AST object. Outputs: { ok, output: { webauthnConfig, stateMachine, decide, passwordRules }, findings[] }.
 */

'use strict';

const { compilePolicy } = require('../../compiler_engine');

// Constructs a decision function based on compiled policy AST
function buildDecideFunction(ast) {
  return function decide(context = {}) {
    const role = context.role || 'employee';
    const deviceKnown = context.deviceKnown !== undefined ? context.deviceKnown : true;
    const risk = context.risk || 'low';
    const hasPasskey = Boolean(context.hasPasskey);
    const requestedMethod = context.requestedMethod || (hasPasskey ? 'passkey' : 'password');

    // 1. Privileged Admin Evaluation
    if (role === 'admin') {
      if (ast.adminAuth === 'passkeyOnly') {
        const ok = hasPasskey && requestedMethod !== 'password';
        return {
          allowed: ok,
          requiredSteps: ['passkey'],
          reason: ok ? 'Admin passkey authenticated successfully.' : 'Admin role strictly requires passkeyOnly authentication.'
        };
      }
      if (ast.adminAuth === 'passkeyPlusMfa') {
        return {
          allowed: hasPasskey,
          requiredSteps: ['passkey', 'mfa'],
          reason: hasPasskey ? 'Admin passkey plus MFA authenticated successfully.' : 'Admin role requires passkey plus secondary MFA.'
        };
      }
    }

    // 2. Step-Up Verification Triggers
    const stepUpRules = Array.isArray(ast.stepUpOn) ? ast.stepUpOn : [];
    if (stepUpRules.includes('newDevice') && !deviceKnown) {
      if (hasPasskey) {
        return { allowed: true, requiredSteps: ['passkey', 'device_verification'], reason: 'New device detected: step-up passkey verification required.' };
      }
      if (ast.passwordFallback === 'requireMfa') {
        return { allowed: true, requiredSteps: ['password', 'mfa'], reason: 'New device detected: password with step-up MFA required.' };
      }
      return { allowed: false, requiredSteps: ['passkey', 'mfa'], reason: 'New device detected: no strong factor available for step-up.' };
    }

    if (stepUpRules.includes('highRisk') && risk === 'high') {
      if (hasPasskey) {
        return { allowed: true, requiredSteps: ['passkey', 'step_up_challenge'], reason: 'High risk session: step-up passkey challenge required.' };
      }
      if (ast.passwordFallback === 'requireMfa') {
        return { allowed: true, requiredSteps: ['password', 'mfa'], reason: 'High risk session: password with step-up MFA required.' };
      }
      return { allowed: false, requiredSteps: ['mfa'], reason: 'High risk session: authentication blocked due to lack of step-up MFA.' };
    }

    // 3. Primary Authentication & Fallback Evaluation
    if (ast.primaryAuth === 'passkeyOnly') {
      const ok = hasPasskey && requestedMethod !== 'password';
      return {
        allowed: ok,
        requiredSteps: ['passkey'],
        reason: ok ? 'Passkey authentication allowed.' : 'Policy enforces passkeyOnly. Password login is completely disabled.'
      };
    }

    if (ast.primaryAuth === 'passkey') {
      if (hasPasskey && requestedMethod === 'passkey') {
        return { allowed: true, requiredSteps: ['passkey'], reason: 'Passkey authentication allowed.' };
      }
      if (ast.passwordFallback === 'none') {
        return { allowed: false, requiredSteps: ['passkey'], reason: 'User lacks passkey and passwordFallback is none.' };
      }
      if (ast.passwordFallback === 'requireMfa') {
        return { allowed: true, requiredSteps: ['password', 'mfa'], reason: 'Password fallback permitted with secondary MFA.' };
      }
      return { allowed: true, requiredSteps: ['password'], reason: 'Password fallback permitted.' };
    }

    if (ast.passwordFallback === 'requireMfa') {
      return { allowed: true, requiredSteps: ['password', 'mfa'], reason: 'Password login requires secondary MFA.' };
    }

    return { allowed: true, requiredSteps: ['password'], reason: 'Password login permitted.' };
  };
}

// Generates WebAuthn options, state machine, and decision engine
function run(input) {
  const ast = (input && input.output) || input || {};
  const findings = [];

  const webauthnConfig = {
    rp: { name: ast.policy || 'Passkey Auth Policy', id: 'localhost' },
    authenticatorSelection: {
      userVerification: ast.requireUserVerification ? 'required' : 'preferred',
      residentKey: ast.residentKey || 'preferred',
      authenticatorAttachment: ast.passkeyType === 'deviceBound' ? 'cross-platform' : undefined
    },
    pubKeyCredParams: [{ alg: -7, type: 'public-key' }, { alg: -257, type: 'public-key' }],
    timeout: 60000,
    attestation: 'none'
  };

  const stateMachine = {
    states: ['IDLE', 'IDENTIFY', 'WEBAUTHN_ASSERTION', 'PASSWORD_VERIFICATION', 'MFA_VERIFICATION', 'AUTHENTICATED', 'REJECTED'],
    start: 'IDLE',
    accepting: ['AUTHENTICATED'],
    transitions: [
      { from: 'IDLE', on: 'IDENTIFY_USER', to: 'IDENTIFY' },
      { from: 'IDENTIFY', on: 'PASSKEY_AVAILABLE', to: 'WEBAUTHN_ASSERTION' },
      { from: 'IDENTIFY', on: 'PASSWORD_FALLBACK', to: 'PASSWORD_VERIFICATION' },
      { from: 'WEBAUTHN_ASSERTION', on: 'PASSKEY_SUCCESS', to: 'AUTHENTICATED' },
      { from: 'WEBAUTHN_ASSERTION', on: 'PASSKEY_FAIL', to: 'REJECTED' },
      { from: 'PASSWORD_VERIFICATION', on: 'REQUIRES_MFA', to: 'MFA_VERIFICATION' },
      { from: 'PASSWORD_VERIFICATION', on: 'DIRECT_SUCCESS', to: 'AUTHENTICATED' },
      { from: 'MFA_VERIFICATION', on: 'MFA_SUCCESS', to: 'AUTHENTICATED' },
      { from: 'MFA_VERIFICATION', on: 'MFA_FAIL', to: 'REJECTED' }
    ]
  };

  const decide = buildDecideFunction(ast);
  let passwordRules = null;

  if (ast.passwordPolicyRaw) {
    try {
      passwordRules = compilePolicy(ast.passwordPolicyRaw);
      findings.push({ severity: 'INFO', message: 'Nested passwordPolicy DSL successfully compiled via read-only compiler_engine.' });
    } catch (err) {
      findings.push({ severity: 'WARNING', message: `Failed to compile nested passwordPolicy: ${err.message}` });
    }
  }

  return {
    ok: true,
    output: { webauthnConfig, stateMachine, decide, passwordRules },
    findings
  };
}

module.exports = {
  run,
  buildDecideFunction
};
