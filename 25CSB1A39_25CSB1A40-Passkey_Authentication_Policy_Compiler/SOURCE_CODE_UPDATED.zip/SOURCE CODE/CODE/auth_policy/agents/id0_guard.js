/**
 * agents/id0_guard.js
 * 
 * Agent ID-0: Input Safety & Zero-Trust Downgrade Guard.
 * Screens payload size, sensitive secrets, and prompt injections via SafetyChecker,
 * and actively blocks security downgrade attempts.
 * Belongs to the Agent Pipeline subsystem.
 * Inputs: dslText string or object. Outputs: { ok, output, findings[] }.
 */

'use strict';

const SafetyChecker = require('../../safety_checker');
const { getDowngradeRules } = require('../config/downgrade_rules');

// Executes Agent 0 safety screening and downgrade protection
function run(input) {
  const dslText = typeof input === 'string' ? input : (input && input.dslText) || '';
  const findings = [];

  const sizeCheck = SafetyChecker.checkInputSize(dslText, 2000);
  if (!sizeCheck.ok) {
    findings.push({ severity: 'ERROR', message: sizeCheck.error });
    return { ok: false, output: null, findings };
  }

  const sensitiveCheck = SafetyChecker.detectSensitiveData(dslText);
  if (!sensitiveCheck.ok) {
    findings.push({ severity: 'ERROR', message: sensitiveCheck.error });
    return { ok: false, output: null, findings };
  }

  const injectionCheck = SafetyChecker.detectPromptInjection(dslText);
  if (!injectionCheck.ok) {
    findings.push({ severity: 'ERROR', message: injectionCheck.error });
    return { ok: false, output: null, findings };
  }

  const rules = getDowngradeRules();
  const lines = dslText.split('\n');

  lines.forEach((rawLine, idx) => {
    const line = rawLine.replace(/#.*$/, '').trim();
    if (!line) return;

    for (const rule of rules) {
      const pattern = new RegExp(`^${rule.field}\\s+${rule.forbiddenValue}\\b`);
      if (pattern.test(line)) {
        findings.push({
          line: idx + 1,
          field: rule.field,
          forbiddenValue: rule.forbiddenValue,
          severity: rule.severity,
          message: `[Downgrade Defense Blocked] ${rule.message}`
        });
      }
    }
  });

  const ok = findings.length === 0;
  return {
    ok,
    output: ok ? { screenedText: dslText } : null,
    findings
  };
}

module.exports = { run };
