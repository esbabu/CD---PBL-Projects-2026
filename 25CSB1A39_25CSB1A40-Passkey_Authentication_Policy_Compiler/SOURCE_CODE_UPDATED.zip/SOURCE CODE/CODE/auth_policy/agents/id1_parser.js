/**
 * agents/id1_parser.js
 * 
 * Agent ID-1: Auth Policy DSL Lexer and Parser.
 * Converts raw DSL text into a structured AST and catches syntax/keyword errors.
 * Belongs to the Agent Pipeline subsystem.
 * Inputs: dslText string or object. Outputs: { ok, output: ast, findings[] }.
 */

'use strict';

const {
  isValidKeyword,
  isRepeatableKeyword,
  isBlockKeyword,
  getAllowedValues
} = require('../config/dsl_keywords');

// Parses auth policy DSL text into an AST structure
function run(input) {
  const dslText = typeof input === 'string' ? input : (input && input.screenedText) || (input && input.dslText) || '';
  const findings = [];
  const ast = {
    policy: 'Default Authentication Policy',
    primaryAuth: null,
    passwordFallback: null,
    adminAuth: null,
    stepUpOn: [],
    recovery: null,
    requireUserVerification: null,
    residentKey: null,
    passkeyType: null,
    passwordPolicyRaw: null
  };

  const lines = dslText.split('\n');
  const seenKeys = new Set();
  let insideBlock = false;
  let blockKeyword = null;
  let blockLines = [];
  let blockStartLine = 1;

  for (let i = 0; i < lines.length; i++) {
    const lineNum = i + 1;
    const rawLine = lines[i];

    if (insideBlock) {
      const trimmed = rawLine.trim();
      if (trimmed === '}' || trimmed.startsWith('}')) {
        insideBlock = false;
        if (blockKeyword === 'passwordPolicy') {
          ast.passwordPolicyRaw = blockLines.join('\n');
        }
        blockKeyword = null;
        blockLines = [];
      } else {
        blockLines.push(rawLine);
      }
      continue;
    }

    const commentIdx = rawLine.indexOf('#');
    const lineWithoutComment = (commentIdx >= 0 ? rawLine.slice(0, commentIdx) : rawLine).trim();
    if (!lineWithoutComment) continue;

    const col = rawLine.indexOf(lineWithoutComment.split(/\s+/)[0]) + 1;
    const tokens = lineWithoutComment.split(/\s+/);
    const keyword = tokens[0];

    if (!isValidKeyword(keyword)) {
      findings.push({ line: lineNum, col, message: `Unknown keyword '${keyword}'` });
      continue;
    }

    if (isBlockKeyword(keyword)) {
      if (seenKeys.has(keyword)) {
        findings.push({ line: lineNum, col, message: `Duplicate keyword '${keyword}'` });
        continue;
      }
      seenKeys.add(keyword);
      if (!lineWithoutComment.includes('{')) {
        findings.push({ line: lineNum, col, message: `Expected '{' to start '${keyword}' block` });
        continue;
      }
      insideBlock = true;
      blockKeyword = keyword;
      blockStartLine = lineNum;
      blockLines = [];
      continue;
    }

    if (seenKeys.has(keyword) && !isRepeatableKeyword(keyword)) {
      findings.push({ line: lineNum, col, message: `Duplicate keyword '${keyword}'` });
      continue;
    }
    seenKeys.add(keyword);

    if (tokens.length < 2) {
      findings.push({ line: lineNum, col, message: `Missing value for keyword '${keyword}'` });
      continue;
    }

    if (keyword === 'policy') {
      const match = lineWithoutComment.match(/^policy\s+"([^"]*)"$/);
      if (!match) {
        findings.push({ line: lineNum, col, message: `policy value must be enclosed in double quotes` });
        continue;
      }
      ast.policy = match[1];
      continue;
    }

    const value = tokens[1];
    const allowed = getAllowedValues(keyword);
    if (allowed && !allowed.includes(value)) {
      findings.push({
        line: lineNum,
        col,
        message: `Invalid value '${value}' for '${keyword}'. Expected one of: ${allowed.join(', ')}`
      });
      continue;
    }

    if (keyword === 'requireUserVerification') {
      ast.requireUserVerification = value === 'true';
    } else if (isRepeatableKeyword(keyword)) {
      if (!ast[keyword].includes(value)) {
        ast[keyword].push(value);
      }
    } else {
      ast[keyword] = value;
    }
  }

  if (insideBlock) {
    findings.push({
      line: blockStartLine,
      col: 1,
      message: `Unterminated '${blockKeyword}' block (missing '}')`
    });
  }

  const ok = findings.length === 0;
  return {
    ok,
    output: ok ? ast : null,
    findings
  };
}

module.exports = { run };
