/**
 * store.js
 * 
 * Re-export wrapper for AuthStore and default store instance.
 */
'use strict';
module.exports = require('./services/store');
