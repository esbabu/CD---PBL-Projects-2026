/**
 * routes.js
 * 
 * Express Router mounting passkey-first authentication endpoints under /api/auth-policy.
 * Thin controller wiring endpoints to dedicated services, input validation, and audit logging.
 * Inputs: HTTP Requests. Outputs: JSON responses.
 */

'use strict';

const express = require('express');
const path = require('path');
const fs = require('fs');
const router = express.Router();

const orchestrator = require('./agents/orchestrator');
const { defaultStore: store } = require('./services/store');
const webauthnService = require('./services/webauthn_service');
const totpService = require('./services/totp');
const { authenticatePassword } = require('./services/password_login');
const redTeam = require('./agents/id5_red_team');
const { suggestFixes } = require('./services/autofix');

// Higher-order helper for clean async error propagation
const handle = fn => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(err => {
    res.status(err.status || 500).json({ ok: false, error: err.message });
  });
};

// Compiles DSL policy and stores it as the active enforcement policy
router.post('/compile', handle(async (req, res) => {
  const { dslText } = req.body || {};
  if (!dslText || typeof dslText !== 'string') {
    return res.status(400).json({ ok: false, error: 'Invalid payload: dslText string required.' });
  }
  const result = await orchestrator.run(dslText);
  if (result.ok) {
    store.setActivePolicy(result);
    store.appendAudit('POLICY_COMPILED', 'system', { policy: result.ast.policy });
  }
  res.json(result);
}));

// Analyzes DSL text and generates deterministic auto and suggested fixes
router.post('/autofix', handle((req, res) => {
  const { dslText } = req.body || {};
  if (!dslText || typeof dslText !== 'string') {
    return res.status(400).json({ ok: false, error: 'Invalid payload: dslText string required.' });
  }
  const fixes = suggestFixes(dslText);
  res.json({
    ok: true,
    fixes,
    safeCount: fixes.filter(f => f.kind === 'auto' && f.after !== null).length,
    suggestedCount: fixes.filter(f => f.kind === 'suggested').length
  });
}));

// Returns the currently active compiled authentication policy
router.get('/active', handle((req, res) => {
  res.json({ ok: true, activePolicy: store.getActivePolicy() || null });
}));

// Simulates authentication flow decisions using the active policy
router.post('/simulate', handle((req, res) => {
  const active = store.getActivePolicy();
  if (!active || !active.flow || !active.flow.decide) {
    return res.status(400).json({ ok: false, error: 'No compiled policy active. Compile a policy first.' });
  }
  const decision = active.flow.decide(req.body?.context || {});
  res.json({ ok: true, decision });
}));

// Generates passkey registration challenge and options
router.post('/passkey/register/options', handle(async (req, res) => {
  const { username } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, error: 'username is required.' });
  const options = await webauthnService.generateRegisterOptions(username);
  res.json({ ok: true, options });
}));

// Verifies WebAuthn registration assertion
router.post('/passkey/register/verify', handle(async (req, res) => {
  const { username, response } = req.body || {};
  if (!username || !response) {
    return res.status(400).json({ ok: false, error: 'username and response payload required.' });
  }
  const result = await webauthnService.verifyRegisterResponse(username, response);
  res.json({ ok: true, result });
}));

// Generates passkey authentication challenge and options
router.post('/passkey/login/options', handle(async (req, res) => {
  const { username } = req.body || {};
  if (!username) return res.status(400).json({ ok: false, error: 'username is required.' });
  const options = await webauthnService.generateLoginOptions(username);
  res.json({ ok: true, options });
}));

// Verifies WebAuthn authentication assertion
router.post('/passkey/login/verify', handle(async (req, res) => {
  const { username, response } = req.body || {};
  if (!username || !response) {
    return res.status(400).json({ ok: false, error: 'username and response payload required.' });
  }
  const result = await webauthnService.verifyLoginResponse(username, response);
  res.json({ ok: true, result });
}));

// Evaluates password authentication with policy and MFA checks
router.post('/password/login', handle((req, res) => {
  const { username, password, context } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ ok: false, error: 'username and password are required.' });
  }
  const result = authenticatePassword(username, password, context || {});
  if (!result.ok) return res.status(401).json(result);
  res.json(result);
}));

// Enrolls user into TOTP authenticator and returns current code
router.post('/totp/enroll', handle((req, res) => {
  const user = store.getUser(req.body?.username);
  if (!user) return res.status(404).json({ ok: false, error: 'User not found.' });
  const code = totpService.currentCode(user.totpSecret);
  res.json({ ok: true, secret: user.totpSecret, currentCode: code });
}));

// Verifies 6-digit TOTP token
router.post('/totp/verify', handle((req, res) => {
  const { username, token } = req.body || {};
  const user = store.getUser(username);
  if (!user) return res.status(404).json({ ok: false, error: 'User not found.' });
  const verified = totpService.verifyCode(user.totpSecret, token);
  if (!verified) {
    store.appendAudit('TOTP_VERIFY_FAIL', username, { token });
    return res.status(400).json({ ok: false, error: 'Invalid or expired TOTP code.' });
  }
  store.appendAudit('TOTP_VERIFY_SUCCESS', username);
  res.json({ ok: true, verified: true });
}));

// Performs account recovery requiring two distinct factors
router.post('/recovery', handle((req, res) => {
  const { username, recoveryCode, totp, emailOtp } = req.body || {};
  const user = store.getUser(username);
  if (!user) return res.status(404).json({ ok: false, error: 'User not found.' });

  const validFactors = [];
  if (recoveryCode && user.recoveryCodes?.includes(recoveryCode)) validFactors.push('recovery_code');
  if (totp && totpService.verifyCode(user.totpSecret, totp)) validFactors.push('totp');
  if (emailOtp === '123456') validFactors.push('email_otp');

  if (validFactors.length < 2) {
    store.appendAudit('ACCOUNT_RECOVERY_FAILED', username, { verifiedFactors: validFactors });
    return res.status(400).json({
      ok: false,
      error: 'Recovery requires at least two distinct valid factors (recoveryCode, totp, emailOtp).'
    });
  }

  store.appendAudit('ACCOUNT_RECOVERY_SUCCESS', username, { factors: validFactors });
  res.json({
    ok: true,
    recovered: true,
    message: 'Account successfully recovered with two verified distinct factors.',
    factorsUsed: validFactors
  });
}));

// Returns the hash-chained audit log and validates its integrity
router.get('/audit', handle((req, res) => {
  const auditLog = store.getAuditLog();
  const chainValid = store.verifyAuditChain();
  res.json({ ok: true, chainValid, count: auditLog.length, auditLog });
}));

// Executes the red team headless virtual authenticator adversarial suite
router.post('/redteam/run', handle(async (req, res) => {
  const scenarios = await redTeam.runScenarios();
  const passed = scenarios.filter(s => s.pass).length;
  res.json({ ok: true, passed, total: scenarios.length, scenarios });
}));

// Returns the security audit report for the active policy
router.get('/report', handle((req, res) => {
  const active = store.getActivePolicy();
  if (!active?.auditReport) {
    return res.status(404).json({ ok: false, error: 'No active audit report available. Compile a policy first.' });
  }
  res.json({
    ok: true,
    score: active.auditReport.score,
    checklist: active.auditReport.checklist,
    markdown: active.auditReport.markdown
  });
}));

// Serves UI assets with appropriate content-type headers
router.get('/ui/:file', (req, res) => {
  let filename = req.params.file;
  if (!filename.endsWith('.js') && !filename.endsWith('.css')) filename += '.js';
  const safePath = path.join(__dirname, 'ui', path.basename(filename));
  if (!fs.existsSync(safePath)) return res.status(404).send('UI asset not found.');
  res.type(filename.endsWith('.css') ? 'text/css' : 'application/javascript');
  res.sendFile(safePath);
});

module.exports = router;
