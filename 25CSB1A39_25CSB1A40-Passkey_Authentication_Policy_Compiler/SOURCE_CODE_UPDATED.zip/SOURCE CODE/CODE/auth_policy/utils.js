/**
 * utils.js
 * 
 * Shared cryptographic, formatting, and string distance utilities for auth policy agents.
 * Belongs to the Shared Infrastructure subsystem.
 * Inputs: Objects, keys, signatures, strings. Outputs: Keypairs, signed envelopes, verified booleans, string matches.
 */

'use strict';

const crypto = require('crypto');

// Generates an Ed25519 keypair for cryptographic agent envelopes
function generateAgentKeyPair() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519', {
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
  });
  return { publicKey, privateKey };
}

// Deterministically serializes objects by recursively sorting dictionary keys
function canonicalJson(obj) {
  if (obj === null || typeof obj !== 'object') {
    return JSON.stringify(obj);
  }
  if (Array.isArray(obj)) {
    return '[' + obj.map(item => canonicalJson(item)).join(',') + ']';
  }
  const keys = Object.keys(obj).sort();
  return '{' + keys.map(k => JSON.stringify(k) + ':' + canonicalJson(obj[k])).join(',') + '}';
}

// Signs an arbitrary payload using an Ed25519 private key
function signPayload(privateKey, payload) {
  const data = Buffer.from(canonicalJson(payload), 'utf8');
  const signature = crypto.sign(null, data, privateKey);
  return signature.toString('hex');
}

// Verifies an Ed25519 signature over a payload
function verifySignature(publicKey, payload, signatureHex) {
  try {
    const data = Buffer.from(canonicalJson(payload), 'utf8');
    const signature = Buffer.from(signatureHex, 'hex');
    return crypto.verify(null, data, publicKey, signature);
  } catch (err) {
    return false;
  }
}

// Tampering helper: returns a copy with one byte flipped for adversarial testing
function createTamperedCopy(obj) {
  const clone = JSON.parse(JSON.stringify(obj));
  if (clone.payload) {
    clone.payload._tampered = true;
  } else {
    clone._tampered = true;
  }
  return clone;
}

// Calculates Levenshtein edit distance between two strings
function levenshteinDistance(a, b) {
  const s1 = a.toLowerCase();
  const s2 = b.toLowerCase();
  if (s1 === s2) return 0;
  const m = s1.length;
  const n = s2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost
      );
    }
  }
  return dp[m][n];
}

// Searches candidate list for closest match within maximum edit distance threshold
function findClosestCandidate(word, candidateList, maxDistance = 2) {
  const exactCaseInsensitive = candidateList.find(c => c.toLowerCase() === word.toLowerCase());
  if (exactCaseInsensitive) {
    return { winner: exactCaseInsensitive, distance: 0, tie: false, matches: [exactCaseInsensitive] };
  }

  let minDistance = Infinity;
  let matches = [];
  for (const cand of candidateList) {
    const dist = levenshteinDistance(word, cand);
    if (dist < minDistance) {
      minDistance = dist;
      matches = [cand];
    } else if (dist === minDistance) {
      matches.push(cand);
    }
  }

  if (minDistance <= maxDistance) {
    if (matches.length === 1) {
      return { winner: matches[0], distance: minDistance, tie: false, matches };
    }
    return { winner: null, distance: minDistance, tie: true, matches };
  }

  return { winner: null, distance: minDistance, tie: false, matches: [] };
}

module.exports = {
  generateAgentKeyPair,
  canonicalJson,
  signPayload,
  verifySignature,
  createTamperedCopy,
  levenshteinDistance,
  findClosestCandidate
};
