/**
 * tests/id1_parser.test.js
 * 
 * Unit tests for Agent ID-1 Parser: syntax, tokens, duplicate keys, and AST output.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const parser = require('../agents/id1_parser');

test('Agent ID-1: correctly parses complete auth policy DSL with nested passwordPolicy', () => {
  const dsl = `
# Employee Portal Policy
policy "Corporate Standard"
primaryAuth passkey
passwordFallback requireMfa
adminAuth passkeyPlusMfa
stepUpOn newDevice
stepUpOn highRisk
recovery requireTwoFactors
requireUserVerification true
residentKey required
passkeyType deviceBound
passwordPolicy {
  minLength 14
  requireUpper true
  requireDigit true
  requireSpecial true
}
`;
  const res = parser.run(dsl);
  assert.equal(res.ok, true);
  assert.equal(res.findings.length, 0);
  assert.equal(res.output.policy, 'Corporate Standard');
  assert.equal(res.output.primaryAuth, 'passkey');
  assert.equal(res.output.passwordFallback, 'requireMfa');
  assert.equal(res.output.adminAuth, 'passkeyPlusMfa');
  assert.deepEqual(res.output.stepUpOn, ['newDevice', 'highRisk']);
  assert.equal(res.output.recovery, 'requireTwoFactors');
  assert.equal(res.output.requireUserVerification, true);
  assert.equal(res.output.residentKey, 'required');
  assert.equal(res.output.passkeyType, 'deviceBound');
  assert.ok(res.output.passwordPolicyRaw.includes('minLength 14'));
});

test('Agent ID-1: rejects unknown keyword with line and col info', () => {
  const dsl = `
policy "Demo"
primaryAuth passkey
magicKeyword true
`;
  const res = parser.run(dsl);
  assert.equal(res.ok, false);
  const err = res.findings.find(f => f.message.includes("Unknown keyword 'magicKeyword'"));
  assert.ok(err);
  assert.equal(err.line, 4);
  assert.ok(err.col > 0);
});

test('Agent ID-1: rejects duplicate non-repeatable keyword', () => {
  const dsl = `
policy "Demo"
primaryAuth passkey
primaryAuth password
`;
  const res = parser.run(dsl);
  assert.equal(res.ok, false);
  const err = res.findings.find(f => f.message.includes("Duplicate keyword 'primaryAuth'"));
  assert.ok(err);
  assert.equal(err.line, 4);
});

test('Agent ID-1: allows repeatable stepUpOn keyword', () => {
  const dsl = `
policy "Demo"
primaryAuth passkey
stepUpOn newDevice
stepUpOn highRisk
stepUpOn sensitiveAction
`;
  const res = parser.run(dsl);
  assert.equal(res.ok, true);
  assert.deepEqual(res.output.stepUpOn, ['newDevice', 'highRisk', 'sensitiveAction']);
});

test('Agent ID-1: rejects invalid enum value', () => {
  const dsl = `
policy "Demo"
primaryAuth sms
`;
  const res = parser.run(dsl);
  assert.equal(res.ok, false);
  const err = res.findings.find(f => f.message.includes("Invalid value 'sms' for 'primaryAuth'"));
  assert.ok(err);
});

test('Agent ID-1: rejects unterminated block', () => {
  const dsl = `
policy "Demo"
primaryAuth passkey
passwordPolicy {
  minLength 12
`;
  const res = parser.run(dsl);
  assert.equal(res.ok, false);
  const err = res.findings.find(f => f.message.includes("Unterminated 'passwordPolicy' block"));
  assert.ok(err);
});
