/**
 * tests/store.test.js
 * 
 * Unit tests for AuthStore: seed users, scrypt hashing, single-use challenges, and hash-chained audit log.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const os = require('os');

const { AuthStore, hashPassword, verifyPassword } = require('../services/store');

test('AuthStore: seeds alice and admin with scrypt hashes outside served root', () => {
  const tmpPath = path.join(os.tmpdir(), `test_store_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  const store = new AuthStore(tmpPath);

  assert.ok(fs.existsSync(tmpPath));

  const alice = store.getUser('alice');
  assert.ok(alice);
  assert.equal(alice.role, 'employee');
  assert.ok(verifyPassword('AlicePassword123!', alice.salt, alice.passwordHash));
  assert.equal(verifyPassword('WrongPassword', alice.salt, alice.passwordHash), false);

  const admin = store.getUser('admin');
  assert.ok(admin);
  assert.equal(admin.role, 'admin');
  assert.ok(verifyPassword('AdminPassword123!', admin.salt, admin.passwordHash));

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});

test('AuthStore: maintains unbroken hash-chained audit log', () => {
  const tmpPath = path.join(os.tmpdir(), `test_store_audit_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);

  store.appendAudit('LOGIN_ATTEMPT', 'alice', { ip: '127.0.0.1' });
  store.appendAudit('PASSKEY_REGISTER', 'alice', { credId: 'cred_1' });
  store.appendAudit('ADMIN_ACTION', 'admin', { op: 'lock' });

  assert.equal(store.verifyAuditChain(), true);
  const log = store.getAuditLog();
  assert.equal(log.length, 4); // Genesis + 3 events

  // Verify linkage
  for (let i = 1; i < log.length; i++) {
    assert.equal(log[i].prevHash, log[i - 1].hash);
  }

  // Tamper detection
  log[1].details = { ip: '10.0.0.99_TAMPERED' };
  store.data.auditLog = log;
  assert.equal(store.verifyAuditChain(), false);

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});

test('AuthStore: enforces single-use and expiration on challenges', () => {
  const tmpPath = path.join(os.tmpdir(), `test_store_c_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);

  store.saveChallenge('chal_123', 'alice', 'login');
  
  // First consumption succeeds
  const record = store.consumeChallenge('chal_123', 'login');
  assert.ok(record);
  assert.equal(record.challenge, 'chal_123');

  // Replay attempt fails (single-use)
  const replay = store.consumeChallenge('chal_123', 'login');
  assert.equal(replay, null);

  // Expired challenge fails
  store.saveChallenge('chal_expired', 'alice', 'login');
  store.data.challenges['chal_expired'].expiresAt = Date.now() - 1000;
  const expired = store.consumeChallenge('chal_expired', 'login');
  assert.equal(expired, null);

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});
