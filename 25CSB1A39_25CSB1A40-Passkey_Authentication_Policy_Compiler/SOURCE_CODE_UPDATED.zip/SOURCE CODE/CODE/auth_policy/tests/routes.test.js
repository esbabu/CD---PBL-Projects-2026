/**
 * tests/routes.test.js
 * 
 * Unit and integration tests for auth policy Express routes.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const router = require('../routes');

function createTestApp() {
  const app = express();
  app.use(express.json());
  app.use('/api/auth-policy', router);
  return app;
}

test('Routes: POST /api/auth-policy/compile and GET /active', async () => {
  const app = createTestApp();
  const server = app.listen(0);
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}/api/auth-policy`;

  try {
    const compileRes = await fetch(`${baseUrl}/compile`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dslText: 'policy "Test API"\nprimaryAuth passkey\npasswordFallback requireMfa\nadminAuth passkeyOnly\nrecovery requireTwoFactors\nrequireUserVerification true\n'
      })
    });
    const compileData = await compileRes.json();
    assert.equal(compileRes.status, 200);
    assert.equal(compileData.ok, true);

    const activeRes = await fetch(`${baseUrl}/active`);
    const activeData = await activeRes.json();
    assert.equal(activeRes.status, 200);
    assert.equal(activeData.ok, true);
    assert.equal(activeData.activePolicy.ast.policy, 'Test API');

    const auditRes = await fetch(`${baseUrl}/audit`);
    const auditData = await auditRes.json();
    assert.equal(auditRes.status, 200);
    assert.equal(auditData.ok, true);
    assert.equal(auditData.chainValid, true);

    const redteamRes = await fetch(`${baseUrl}/redteam/run`, { method: 'POST' });
    const redteamData = await redteamRes.json();
    assert.equal(redteamRes.status, 200);
    assert.equal(redteamData.ok, true);
    assert.equal(redteamData.total, 10);
    assert.equal(redteamData.passed, 10);
  } finally {
    server.close();
  }
});
