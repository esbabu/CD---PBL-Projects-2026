/**
 * tests/orchestrator.test.js
 * 
 * Unit tests for Multi-Agent Orchestrator: end-to-end pipeline, Ed25519 signing,
 * per-agent status, timing, and cryptographic tamper rejection.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const orchestrator = require('../agents/orchestrator');

const VALID_POLICY = `
policy "Enterprise Zero Trust"
primaryAuth passkey
passwordFallback requireMfa
adminAuth passkeyOnly
stepUpOn newDevice
recovery requireTwoFactors
requireUserVerification true
residentKey required
passkeyType deviceBound
`;

test('Orchestrator: executes ID-0 -> ID-6 pipeline with valid signatures and timing', async () => {
  const result = await orchestrator.run(VALID_POLICY);

  assert.equal(result.ok, true);
  assert.equal(result.signaturesValid, true);
  assert.equal(result.stages.length, 7);
  assert.ok(result.latencyMs >= 0);

  // Verify all 7 agents executed in strict order
  const expectedAgents = ['ID-0', 'ID-1', 'ID-2', 'ID-3', 'ID-4', 'ID-5', 'ID-6'];
  const actualAgents = result.stages.map(s => s.agentId);
  assert.deepEqual(actualAgents, expectedAgents);

  // Verify each stage has valid signature
  result.stages.forEach(stage => {
    assert.equal(stage.signatureValid, true);
    assert.ok(stage.envelope.signature);
    assert.ok(stage.envelope.publicKey);
  });

  // Verify audit report is generated
  assert.ok(result.auditReport);
  assert.ok(result.auditReport.score >= 80);
});

test('Orchestrator: rejects cryptographically tampered agent envelope', () => {
  const mockResult = { ok: true, output: { nistLevel: 'AAL2' }, findings: [] };
  const envelope = orchestrator.createSignedEnvelope('ID-3', 'Assurance', mockResult, 5);

  // Authentic envelope verifies successfully
  assert.equal(orchestrator.verifyEnvelope(envelope), true);

  // Tampering with the payload causes signature verification to fail
  const tamperedEnvelope = orchestrator.tamper(envelope, 'output', { nistLevel: 'AAL3_FAKED' });
  assert.equal(orchestrator.verifyEnvelope(tamperedEnvelope), false);
});

test('Orchestrator: stops pipeline early if ID-0 detects downgrade', async () => {
  const badPolicy = `
policy "Insecure"
primaryAuth passkey
adminAuth passwordOnly
`;
  const result = await orchestrator.run(badPolicy);
  assert.equal(result.ok, false);
  assert.equal(result.stoppedAt, 'ID-0');
  assert.equal(result.stages.length, 1);
});
