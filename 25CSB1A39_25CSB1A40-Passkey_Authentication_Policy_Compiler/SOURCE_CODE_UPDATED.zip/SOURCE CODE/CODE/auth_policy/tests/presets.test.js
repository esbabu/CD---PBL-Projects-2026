/**
 * tests/presets.test.js
 * 
 * Automated test suite for auth policy presets repository.
 * Verifies that all portal presets compile cleanly through all 7 agents and demo cases
 * trigger their expected diagnostic stops (AAL1, ID-1 typos, ID-0 downgrade, ID-2 contradiction).
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { PK_PRESETS } = require('../ui/presets');
const orchestrator = require('../agents/orchestrator');

test('Presets: repository contains all 11 presets partitioned into Portals and Demo Cases', () => {
  assert.equal(PK_PRESETS.length, 11);
  const portals = PK_PRESETS.filter(p => p.group === 'Portals');
  const demoCases = PK_PRESETS.filter(p => p.group === 'Demo Cases');

  assert.equal(portals.length, 7);
  assert.equal(demoCases.length, 4);

  const portalIds = portals.map(p => p.id);
  assert.ok(portalIds.includes('employee_portal'));
  assert.ok(portalIds.includes('banking_fintech'));
  assert.ok(portalIds.includes('healthcare_staff'));
  assert.ok(portalIds.includes('university_portal'));
  assert.ok(portalIds.includes('gov_citizen'));
  assert.ok(portalIds.includes('ecommerce_customer'));
  assert.ok(portalIds.includes('saas_admin'));

  const demoIds = demoCases.map(p => p.id);
  assert.ok(demoIds.includes('weak_legacy'));
  assert.ok(demoIds.includes('typos_demo'));
  assert.ok(demoIds.includes('downgrade_demo'));
  assert.ok(demoIds.includes('contradiction_demo'));
});

// Run each preset and assert expected outcome
for (const preset of PK_PRESETS) {
  test(`Preset [${preset.group}] "${preset.name}" compiles to expected outcome`, async () => {
    assert.ok(preset.dslText && preset.dslText.length > 0, `DSL text required for ${preset.name}`);
    const res = await orchestrator.run(preset.dslText);

    if (preset.expected.ok) {
      assert.equal(res.ok, true, `Expected ${preset.name} to compile cleanly. Stopped at: ${res.stoppedAt}`);
      assert.equal(res.stages.length, 7, 'Expected all 7 stages to complete');
      assert.equal(res.assurance.nistLevel, preset.expected.aal, `Expected AAL ${preset.expected.aal}`);
      assert.equal(res.auditReport.score, preset.expected.score, `Expected score ${preset.expected.score}`);
      assert.equal(
        res.assurance.phishingResistant,
        preset.expected.phishingResistant,
        `Expected phishingResistant=${preset.expected.phishingResistant}`
      );
    } else {
      assert.equal(res.ok, false, `Expected ${preset.name} to fail compilation`);
      assert.equal(res.stoppedAt, preset.expected.stoppedAt, `Expected stoppedAt=${preset.expected.stoppedAt}`);

      const matched = (res.findings || []).some(f => 
        (f.message && f.message.includes(preset.expected.errorContains)) ||
        f.severity === preset.expected.errorContains
      );
      assert.ok(
        matched,
        `Expected error or severity containing "${preset.expected.errorContains}", got: ${JSON.stringify(res.findings)}`
      );
    }
  });
}
