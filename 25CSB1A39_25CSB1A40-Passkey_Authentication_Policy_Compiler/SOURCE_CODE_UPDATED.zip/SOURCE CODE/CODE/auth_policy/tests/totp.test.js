/**
 * tests/totp.test.js
 * 
 * Unit tests for RFC 6238 TOTP engine: code generation, simulator code, and window verification.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const totp = require('../services/totp');

test('TOTP: generates valid Base32 secrets', () => {
  const secret = totp.generateSecret();
  assert.ok(typeof secret === 'string');
  assert.ok(secret.length >= 16);
  assert.match(secret, /^[A-Z2-7]+$/);
});

test('TOTP: produces 6-digit current code for authenticator simulator', () => {
  const secret = totp.generateSecret();
  const code = totp.currentCode(secret);
  assert.equal(code.length, 6);
  assert.match(code, /^\d{6}$/);
});

test('TOTP: verifies valid token in current step and +/-1 step window', () => {
  const secret = totp.generateSecret();
  const now = Date.now();

  const codeNow = totp.currentCode(secret, now);
  assert.equal(totp.verifyCode(secret, codeNow, 1, now), true);

  // Past step (-30s)
  const codePast = totp.currentCode(secret, now - 30000);
  assert.equal(totp.verifyCode(secret, codePast, 1, now), true);

  // Future step (+30s)
  const codeFuture = totp.currentCode(secret, now + 30000);
  assert.equal(totp.verifyCode(secret, codeFuture, 1, now), true);

  // Beyond window (-90s)
  const codeTooOld = totp.currentCode(secret, now - 90000);
  assert.equal(totp.verifyCode(secret, codeTooOld, 1, now), false);
});

test('TOTP: rejects invalid or malformed tokens', () => {
  const secret = totp.generateSecret();
  assert.equal(totp.verifyCode(secret, '000000'), false);
  assert.equal(totp.verifyCode(secret, '12345'), false);
  assert.equal(totp.verifyCode(secret, 'abcdef'), false);
  assert.equal(totp.verifyCode(secret, null), false);
});
