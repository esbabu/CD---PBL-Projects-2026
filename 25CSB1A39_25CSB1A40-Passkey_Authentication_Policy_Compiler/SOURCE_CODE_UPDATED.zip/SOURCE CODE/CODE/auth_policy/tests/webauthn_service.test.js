/**
 * tests/webauthn_service.test.js
 * 
 * Unit tests for WebAuthn passkey ceremonies: options generation, virtual assertion verification,
 * and sign-count rollback prevention.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const os = require('os');
const fs = require('fs');
const crypto = require('crypto');

const webauthn = require('../services/webauthn_service');
const { AuthStore } = require('../services/store');
const { createVirtualAssertion, encodeCoseKey } = require('../agents/id5_red_team');

test('WebAuthn Service: generates registration and authentication options', async () => {
  const tmpPath = path.join(os.tmpdir(), `test_wa_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  const store = new AuthStore(tmpPath);

  const regOpts = await webauthn.generateRegisterOptions('alice', null, store);
  assert.equal(regOpts.rp.id, 'localhost');
  assert.equal(regOpts.user.name, 'alice');
  assert.ok(regOpts.challenge);

  const authOpts = await webauthn.generateLoginOptions('alice', null, store);
  assert.equal(authOpts.rpId, 'localhost');
  assert.ok(authOpts.challenge);

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});

test('WebAuthn Service: verifies virtual passkey authentication assertion', async () => {
  const tmpPath = path.join(os.tmpdir(), `test_wa_auth_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  const store = new AuthStore(tmpPath);

  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const coseKey = encodeCoseKey(Buffer.from(jwk.x, 'base64url'), Buffer.from(jwk.y, 'base64url'));
  const credId = Buffer.from('test_pk_01').toString('base64url');

  // Seed credential
  const user = store.getUser('alice');
  user.passkeys.push({
    id: credId,
    publicKey: coseKey.toString('base64'),
    counter: 5,
    transports: ['internal']
  });
  store.saveUser(user);

  const authOpts = await webauthn.generateLoginOptions('alice', null, store);
  const assertion = createVirtualAssertion({
    challenge: authOpts.challenge,
    counter: 10,
    uv: true,
    privateKey
  });
  assertion.id = credId;
  assertion.rawId = credId;
  assertion.challenge = authOpts.challenge;

  const result = await webauthn.verifyLoginResponse('alice', assertion, null, store);
  assert.equal(result.verified, true);
  assert.equal(result.counter, 10);

  // Counter updated in store
  assert.equal(store.getUser('alice').passkeys[0].counter, 10);

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});

test('WebAuthn Service: detects and blocks sign-count rollback for hardware passkeys', async () => {
  const tmpPath = path.join(os.tmpdir(), `test_wa_counter_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  const store = new AuthStore(tmpPath);

  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const coseKey = encodeCoseKey(Buffer.from(jwk.x, 'base64url'), Buffer.from(jwk.y, 'base64url'));
  const credId = Buffer.from('test_pk_counter').toString('base64url');

  const user = store.getUser('alice');
  user.passkeys.push({
    id: credId,
    publicKey: coseKey.toString('base64'),
    counter: 50,
    transports: ['usb']
  });
  store.saveUser(user);

  const authOpts = await webauthn.generateLoginOptions('alice', null, store);
  const assertion = createVirtualAssertion({
    challenge: authOpts.challenge,
    counter: 20, // Rollback (20 < 50)
    uv: true,
    privateKey
  });
  assertion.id = credId;
  assertion.rawId = credId;
  assertion.challenge = authOpts.challenge;

  await assert.rejects(
    () => webauthn.verifyLoginResponse('alice', assertion, null, store),
    /Sign-count rollback detected/
  );

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});

test('WebAuthn Service: allows sign counter 0 for synced passkeys', async () => {
  const tmpPath = path.join(os.tmpdir(), `test_wa_synced_${Date.now()}_${Math.random().toString(36).slice(2)}.json`);
  const store = new AuthStore(tmpPath);

  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const coseKey = encodeCoseKey(Buffer.from(jwk.x, 'base64url'), Buffer.from(jwk.y, 'base64url'));
  const credId = Buffer.from('test_pk_synced').toString('base64url');

  const user = store.getUser('alice');
  user.passkeys.push({
    id: credId,
    publicKey: coseKey.toString('base64'),
    counter: 0,
    transports: ['hybrid']
  });
  store.saveUser(user);

  const authOpts = await webauthn.generateLoginOptions('alice', null, store);
  const assertion = createVirtualAssertion({
    challenge: authOpts.challenge,
    counter: 0, // Synced passkeys report 0
    uv: true,
    privateKey
  });
  assertion.id = credId;
  assertion.rawId = credId;
  assertion.challenge = authOpts.challenge;

  const result = await webauthn.verifyLoginResponse('alice', assertion, null, store);
  assert.equal(result.verified, true);
  assert.equal(result.counter, 0);

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});
