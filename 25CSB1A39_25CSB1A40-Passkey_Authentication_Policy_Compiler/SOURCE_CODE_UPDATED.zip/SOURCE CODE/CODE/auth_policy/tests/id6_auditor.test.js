/**
 * tests/id6_auditor.test.js
 * 
 * Unit tests for Agent ID-6 Auditor: checklist synthesis, scoring, and markdown export.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const auditor = require('../agents/id6_auditor');

test('Agent ID-6: generates passing checklist and high score for strong policy', () => {
  const bundle = {
    ast: { policy: 'Secure Corp', adminAuth: 'passkeyOnly' },
    assurance: { nistLevel: 'AAL3', phishingResistant: true },
    redTeam: { resilienceScore: 100 },
    allFindings: []
  };

  const res = auditor.run(bundle);
  assert.equal(res.ok, true);
  assert.equal(res.output.score, 100);
  assert.ok(res.output.checklist.every(c => c.status === 'PASS'));
  assert.ok(res.output.toMarkdown().includes('# Passkey-First Authentication Policy Security Audit'));
  assert.ok(res.output.toJson().includes('"score": 100'));
});

test('Agent ID-6: deducts score and adds warnings for phishable configuration', () => {
  const bundle = {
    ast: { policy: 'Legacy Corp', adminAuth: 'passwordOnly' },
    assurance: { nistLevel: 'AAL1', phishingResistant: false },
    redTeam: { resilienceScore: 50 },
    allFindings: [{ severity: 'DOWNGRADE_BLOCKED' }]
  };

  const res = auditor.run(bundle);
  assert.equal(res.ok, true);
  assert.ok(res.output.score < 50);
  assert.ok(res.output.checklist.some(c => c.status === 'FAIL' || c.status === 'WARN'));
});
