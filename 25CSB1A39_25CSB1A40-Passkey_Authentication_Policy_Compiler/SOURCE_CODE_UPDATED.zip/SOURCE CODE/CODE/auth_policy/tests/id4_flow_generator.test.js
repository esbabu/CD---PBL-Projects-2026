/**
 * tests/id4_flow_generator.test.js
 * 
 * Unit tests for Agent ID-4 Flow Generator: WebAuthn config, state machine, and decide() matrix.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const flowGenerator = require('../agents/id4_flow_generator');

test('Agent ID-4: outputs valid WebAuthn JSON config', () => {
  const ast = {
    policy: 'Acme Corp',
    requireUserVerification: true,
    residentKey: 'required',
    passkeyType: 'deviceBound'
  };
  const res = flowGenerator.run(ast);
  assert.equal(res.ok, true);
  const cfg = res.output.webauthnConfig;
  assert.equal(cfg.rp.name, 'Acme Corp');
  assert.equal(cfg.authenticatorSelection.userVerification, 'required');
  assert.equal(cfg.authenticatorSelection.residentKey, 'required');
  assert.equal(cfg.authenticatorSelection.authenticatorAttachment, 'cross-platform');
  assert.deepEqual(cfg.pubKeyCredParams, [
    { alg: -7, type: 'public-key' },
    { alg: -257, type: 'public-key' }
  ]);
  assert.equal(cfg.timeout, 60000);
  assert.equal(cfg.attestation, 'none');
});

test('Agent ID-4: decide() for admin with passkeyOnly enforcement', () => {
  const ast = {
    primaryAuth: 'passkey',
    adminAuth: 'passkeyOnly',
    passwordFallback: 'requireMfa'
  };
  const { decide } = flowGenerator.run(ast).output;

  // Admin using password is rejected
  const adminWithPassword = decide({ role: 'admin', requestedMethod: 'password', hasPasskey: false });
  assert.equal(adminWithPassword.allowed, false);
  assert.deepEqual(adminWithPassword.requiredSteps, ['passkey']);

  // Admin using passkey is allowed
  const adminWithPasskey = decide({ role: 'admin', requestedMethod: 'passkey', hasPasskey: true });
  assert.equal(adminWithPasskey.allowed, true);
  assert.deepEqual(adminWithPasskey.requiredSteps, ['passkey']);
});

test('Agent ID-4: decide() for employee with fallback to password + MFA', () => {
  const ast = {
    primaryAuth: 'passkey',
    adminAuth: 'passkeyOnly',
    passwordFallback: 'requireMfa'
  };
  const { decide } = flowGenerator.run(ast).output;

  // Employee with passkey uses passkey directly
  const empWithPasskey = decide({ role: 'employee', requestedMethod: 'passkey', hasPasskey: true });
  assert.equal(empWithPasskey.allowed, true);
  assert.deepEqual(empWithPasskey.requiredSteps, ['passkey']);

  // Employee without passkey gets routed to password + MFA
  const empWithoutPasskey = decide({ role: 'employee', requestedMethod: 'password', hasPasskey: false });
  assert.equal(empWithoutPasskey.allowed, true);
  assert.deepEqual(empWithoutPasskey.requiredSteps, ['password', 'mfa']);
});

test('Agent ID-4: decide() for new device triggers step-up verification', () => {
  const ast = {
    primaryAuth: 'passkey',
    stepUpOn: ['newDevice'],
    passwordFallback: 'requireMfa'
  };
  const { decide } = flowGenerator.run(ast).output;

  const newDeviceUser = decide({
    role: 'employee',
    deviceKnown: false,
    hasPasskey: true
  });
  assert.equal(newDeviceUser.allowed, true);
  assert.deepEqual(newDeviceUser.requiredSteps, ['passkey', 'device_verification']);
  assert.ok(newDeviceUser.reason.includes('New device detected'));
});

test('Agent ID-4: decide() for high risk triggers step-up challenge', () => {
  const ast = {
    primaryAuth: 'passkey',
    stepUpOn: ['highRisk'],
    passwordFallback: 'requireMfa'
  };
  const { decide } = flowGenerator.run(ast).output;

  const highRiskUser = decide({
    role: 'employee',
    risk: 'high',
    hasPasskey: true
  });
  assert.equal(highRiskUser.allowed, true);
  assert.deepEqual(highRiskUser.requiredSteps, ['passkey', 'step_up_challenge']);
  assert.ok(highRiskUser.reason.includes('High risk session'));
});

test('Agent ID-4: compiles nested passwordPolicy DSL through compiler_engine', () => {
  const ast = {
    primaryAuth: 'passkey',
    passwordPolicyRaw: 'minLength 12\nrequireUpper true\nrequireDigit true'
  };
  const res = flowGenerator.run(ast);
  assert.equal(res.ok, true);
  assert.ok(res.output.passwordRules);
  assert.equal(res.output.passwordRules.success, true);
});
