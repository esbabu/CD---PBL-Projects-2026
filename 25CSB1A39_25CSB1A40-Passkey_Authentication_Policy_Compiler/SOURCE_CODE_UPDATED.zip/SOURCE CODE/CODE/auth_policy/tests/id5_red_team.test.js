/**
 * tests/id5_red_team.test.js
 * 
 * Unit tests for Agent ID-5 Red Team: headless virtual authenticator & 10 adversarial scenarios.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const redTeam = require('../agents/id5_red_team');

test('Agent ID-5: executes all 10 adversarial scenarios against live verification engines', async () => {
  const scenarios = await redTeam.runScenarios();
  assert.equal(scenarios.length, 10);

  const expectedNames = [
    'phishing origin',
    'wrong rpId',
    'replayed challenge',
    'expired challenge',
    'missing user verification',
    'password fallback without MFA',
    'admin password-only',
    'recovery with one factor',
    'downgrade DSL',
    'password+TOTP relayed by a phishing proxy succeeds'
  ];

  scenarios.forEach((sc, i) => {
    assert.equal(sc.name, expectedNames[i]);
    assert.equal(sc.pass, true, `Scenario '${sc.name}' failed: expected ${sc.expected}, got ${sc.actual}`);
  });
});
