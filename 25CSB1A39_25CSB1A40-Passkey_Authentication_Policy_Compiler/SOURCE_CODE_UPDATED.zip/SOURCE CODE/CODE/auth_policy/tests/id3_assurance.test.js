/**
 * tests/id3_assurance.test.js
 * 
 * Unit tests for Agent ID-3 Assurance: NIST SP 800-63B-4 level mappings and phishing resistance.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const assurance = require('../agents/id3_assurance');
const { NIST_DISCLAIMER } = require('../config/nist_mapping');

test('Agent ID-3: maps password only to AAL1 (phishing-resistant: false)', () => {
  const ast = {
    primaryAuth: 'password',
    passwordFallback: 'allow'
  };
  const res = assurance.run(ast);
  assert.equal(res.ok, true);
  assert.equal(res.output.nistLevel, 'AAL1');
  assert.equal(res.output.phishingResistant, false);
  assert.equal(res.output.disclaimer, NIST_DISCLAIMER);
});

test('Agent ID-3: maps password + TOTP/MFA to AAL2 but phishable', () => {
  const ast = {
    primaryAuth: 'password',
    passwordFallback: 'requireMfa'
  };
  const res = assurance.run(ast);
  assert.equal(res.ok, true);
  assert.equal(res.output.nistLevel, 'AAL2');
  assert.equal(res.output.phishingResistant, false);
  assert.equal(res.output.disclaimer, NIST_DISCLAIMER);
});

test('Agent ID-3: maps passkey with UV to AAL2 phishing-resistant', () => {
  const ast = {
    primaryAuth: 'passkey',
    requireUserVerification: true,
    passkeyType: 'synced'
  };
  const res = assurance.run(ast);
  assert.equal(res.ok, true);
  assert.equal(res.output.nistLevel, 'AAL2');
  assert.equal(res.output.phishingResistant, true);
  assert.equal(res.output.disclaimer, NIST_DISCLAIMER);
});

test('Agent ID-3: maps deviceBound passkey with UV to AAL3 phishing-resistant', () => {
  const ast = {
    primaryAuth: 'passkeyOnly',
    requireUserVerification: true,
    passkeyType: 'deviceBound'
  };
  const res = assurance.run(ast);
  assert.equal(res.ok, true);
  assert.equal(res.output.nistLevel, 'AAL3');
  assert.equal(res.output.phishingResistant, true);
  assert.equal(res.output.disclaimer, NIST_DISCLAIMER);
});
