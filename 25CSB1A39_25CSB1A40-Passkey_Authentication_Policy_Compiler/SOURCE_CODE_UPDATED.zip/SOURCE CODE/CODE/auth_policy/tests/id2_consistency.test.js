/**
 * tests/id2_consistency.test.js
 * 
 * Unit tests for Agent ID-2 Consistency: contradiction trapping and lockout warnings.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const consistency = require('../agents/id2_consistency');

test('Agent ID-2: passes consistent policy without contradictions', () => {
  const ast = {
    primaryAuth: 'passkey',
    passwordFallback: 'requireMfa',
    adminAuth: 'passkeyPlusMfa',
    stepUpOn: ['newDevice'],
    recovery: 'requireTwoFactors',
    requireUserVerification: true,
    residentKey: 'required'
  };
  const res = consistency.run(ast);
  assert.equal(res.ok, true);
  assert.equal(res.findings.length, 0);
});

test('Agent ID-2: catches contradiction: primaryAuth passkeyOnly with passwordFallback != none', () => {
  const ast = {
    primaryAuth: 'passkeyOnly',
    passwordFallback: 'requireMfa',
    recovery: 'requireTwoFactors'
  };
  const res = consistency.run(ast);
  assert.equal(res.ok, false);
  const err = res.findings.find(f => f.field === 'passwordFallback' && f.type === 'CONTRADICTION');
  assert.ok(err);
  assert.ok(err.message.includes("Fallback must be 'none'"));
});

test('Agent ID-2: catches contradiction: stepUpOn used while no strong method exists', () => {
  const ast = {
    primaryAuth: 'password',
    passwordFallback: 'allow',
    adminAuth: 'passwordOnly',
    stepUpOn: ['newDevice', 'highRisk']
  };
  const res = consistency.run(ast);
  assert.equal(res.ok, false);
  const err = res.findings.find(f => f.field === 'stepUpOn' && f.type === 'CONTRADICTION');
  assert.ok(err);
  assert.ok(err.message.includes('no strong authentication method'));
});

test('Agent ID-2: warns about admin lockout risk when adminAuth passkeyOnly lacks two-factor recovery', () => {
  const ast = {
    primaryAuth: 'passkey',
    passwordFallback: 'requireMfa',
    adminAuth: 'passkeyOnly',
    recovery: 'requireOneFactor'
  };
  const res = consistency.run(ast);
  assert.equal(res.ok, true); // warning does not block compilation
  const warn = res.findings.find(f => f.field === 'recovery' && f.type === 'LOCKOUT_RISK');
  assert.ok(warn);
  assert.equal(warn.severity, 'WARNING');
  assert.ok(warn.message.includes('Lockout Risk Warning'));
});
