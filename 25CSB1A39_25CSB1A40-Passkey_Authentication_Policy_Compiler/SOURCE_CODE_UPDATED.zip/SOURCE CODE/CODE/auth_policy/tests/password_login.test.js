/**
 * tests/password_login.test.js
 * 
 * Unit tests for Password Login: credential validation, admin lockout, and MFA requirement.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const os = require('os');
const fs = require('fs');

const { authenticatePassword } = require('../services/password_login');
const { AuthStore } = require('../services/store');

test('Password Login: authenticates alice with valid scrypt password', () => {
  const tmpPath = path.join(os.tmpdir(), `test_pw_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);

  const res = authenticatePassword('alice', 'AlicePassword123!', {}, store);
  assert.equal(res.ok, true);
  assert.equal(res.authenticated, true);
  assert.equal(res.user.username, 'alice');

  try { fs.unlinkSync(tmpPath); } catch (e) { }
});

test('Password Login: rejects invalid password', () => {
  const tmpPath = path.join(os.tmpdir(), `test_pw_bad_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);

  const res = authenticatePassword('alice', 'WrongPassword!', {}, store);
  assert.equal(res.ok, false);
  assert.equal(res.error, 'Invalid username or password.');

  try { fs.unlinkSync(tmpPath); } catch (e) { }
});

test('Password Login: denies admin password-only when policy requires passkeyOnly', () => {
  const tmpPath = path.join(os.tmpdir(), `test_pw_admin_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);
  store.setActivePolicy({
    ast: { adminAuth: 'passkeyOnly' },
    flow: { decide: () => ({ allowed: false, requiredSteps: ['passkey'] }) }
  });

  const res = authenticatePassword('admin', 'AdminPassword123!', {}, store);
  assert.equal(res.ok, false);
  assert.ok(res.error.includes('strictly requires passkeyOnly'));

  try { fs.unlinkSync(tmpPath); } catch (e) { }
});

test('Password Login: flags requireMfa when policy enforces secondary factor', () => {
  const tmpPath = path.join(os.tmpdir(), `test_pw_mfa_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);
  store.setActivePolicy({
    ast: { primaryAuth: 'passkey', passwordFallback: 'requireMfa' },
    flow: { decide: () => ({ allowed: true, requiredSteps: ['password', 'mfa'], reason: 'Fallback requires MFA' }) }
  });

  const res = authenticatePassword('alice', 'AlicePassword123!', {}, store);
  assert.equal(res.ok, true);
  assert.equal(res.requiresMfa, true);
  assert.equal(res.mfaType, 'totp');

  try { fs.unlinkSync(tmpPath); } catch (e) { }
});
