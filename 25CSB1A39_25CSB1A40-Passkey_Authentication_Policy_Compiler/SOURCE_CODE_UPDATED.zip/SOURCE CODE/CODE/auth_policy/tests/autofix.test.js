/**
 * tests/autofix.test.js
 * 
 * Automated test suite for the deterministic Auto-Error Fix service (autofix.js).
 * Validates keyword/enum typo correction, tie/no-match handling, downgrade preservation,
 * block closure/formatting repairs, and multi-pass compile pipeline integration.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { suggestFixes, applyFix, applySafeFixes, findClosestCandidate } = require('../services/autofix');
const orchestrator = require('../agents/orchestrator');

const TYPOS_DSL = `policy "Employee Portal"
primaryAuth passkey
passwordFallback requireMfa
adminAuth passkeyPlusMfa
recovery requireTwoFactors
requireUrVerification true
residentKey required
passkeyType deviceBou`;

const DOWNGRADE_DSL = `policy "Downgrade Attempt"
primaryAuth passkey
passwordFallback allow
adminAuth passwordOnly
recovery requireOneFactor
requireUserVerification false`;

const CONTRADICTION_DSL = `policy "Contradiction Demo"
primaryAuth passkeyOnly
passwordFallback requireMfa
adminAuth passkeyOnly
recovery requireTwoFactors
requireUserVerification true`;

test('AutoFix: fixes keyword and enum typos, allowing clean 7-stage compile', async () => {
  const fixes = suggestFixes(TYPOS_DSL);
  assert.equal(fixes.length, 2, 'Should identify exactly 2 typos');

  const kwFix = fixes.find(f => f.before === 'requireUrVerification');
  assert.ok(kwFix, 'Finds requireUrVerification typo');
  assert.equal(kwFix.after, 'requireUserVerification');
  assert.equal(kwFix.kind, 'auto');

  const valFix = fixes.find(f => f.before === 'deviceBou');
  assert.ok(valFix, 'Finds deviceBou typo');
  assert.equal(valFix.after, 'deviceBound');
  assert.equal(valFix.kind, 'auto');

  const fixedDsl = applySafeFixes(TYPOS_DSL, fixes);
  assert.ok(fixedDsl.includes('requireUserVerification true'));
  assert.ok(fixedDsl.includes('passkeyType deviceBound'));

  // Compile fixed DSL through all 7 stages
  const compileRes = await orchestrator.run(fixedDsl);
  assert.equal(compileRes.ok, true, 'Clean compilation through orchestrator');
  assert.equal(compileRes.stages.length, 7, 'All 7 stages complete');
  assert.equal(compileRes.assurance.nistLevel, 'AAL3');
});

test('AutoFix: ties and distant typos yield suggested with after=null and preserve text', () => {
  // Test tie detection directly
  const tie = findClosestCandidate('abc', ['abd', 'abe'], 1);
  assert.equal(tie.tie, true);
  assert.equal(tie.winner, null);

  // Policy with an unrecognizable keyword (distance > 2)
  const distantDsl = `policy "Distant"
unknownKeywordXyz 123
primaryAuth passkey`;

  const fixes = suggestFixes(distantDsl);
  const distantFix = fixes.find(f => f.before === 'unknownKeywordXyz');
  assert.ok(distantFix);
  assert.equal(distantFix.after, null);
  assert.equal(distantFix.kind, 'suggested');

  // applySafeFixes must leave the text completely unchanged
  const unchanged = applySafeFixes(distantDsl, fixes);
  assert.equal(unchanged, distantDsl);
});

test('AutoFix: downgrade violations are flagged as suggested and never auto-applied', () => {
  const fixes = suggestFixes(DOWNGRADE_DSL);
  assert.ok(fixes.length >= 4, 'Identifies all downgrade violations');

  for (const fix of fixes) {
    assert.equal(fix.kind, 'suggested', `Downgrade fix for ${fix.before} must be suggested, not auto`);
  }

  // Safe fixes must not alter downgrade DSL
  const afterSafe = applySafeFixes(DOWNGRADE_DSL, fixes);
  assert.equal(afterSafe, DOWNGRADE_DSL, 'applySafeFixes must not apply suggested downgrade changes');

  // Single fix application works on explicit user request
  const adminFix = fixes.find(f => f.before === 'adminAuth passwordOnly');
  assert.ok(adminFix);
  assert.equal(adminFix.after, 'adminAuth passkeyOnly');
  const manuallyFixed = applyFix(DOWNGRADE_DSL, adminFix);
  assert.ok(manuallyFixed.includes('adminAuth passkeyOnly'));
  assert.ok(!manuallyFixed.includes('adminAuth passwordOnly'));
});

test('AutoFix: auto-repairs unquoted policy name, missing brace, and unterminated block', () => {
  const brokenBlocksDsl = `policy Unquoted Name
primaryAuth passkey
passwordPolicy
  minLength 12`;

  const fixes = suggestFixes(brokenBlocksDsl);
  const policyFix = fixes.find(f => f.before === 'policy Unquoted Name');
  assert.ok(policyFix, 'Finds unquoted policy name');
  assert.equal(policyFix.after, 'policy "Unquoted Name"');
  assert.equal(policyFix.kind, 'auto');

  const braceFix = fixes.find(f => f.before === 'passwordPolicy');
  assert.ok(braceFix, 'Finds missing open brace');
  assert.equal(braceFix.after, 'passwordPolicy {');
  assert.equal(braceFix.kind, 'auto');

  const closeFix = fixes.find(f => f.after === '}');
  assert.ok(closeFix, 'Finds missing closing brace');
  assert.equal(closeFix.kind, 'auto');

  const fixed = applySafeFixes(brokenBlocksDsl, fixes);
  assert.ok(fixed.includes('policy "Unquoted Name"'));
  assert.ok(fixed.includes('passwordPolicy {'));
  assert.ok(fixed.endsWith('}'));
});

test('AutoFix: multi-pass unmasks downstream consistency contradictions', () => {
  // DSL with a typo in requireUserVerification plus a contradiction: passkeyOnly + passwordFallback
  const dsl = `policy "Employee Portal"
primaryAuth passkeyOnly
passwordFallback requireMfa
adminAuth passkeyOnly
recovery requireTwoFactors
requireUrVerification true
residentKey required`;

  const fixes = suggestFixes(dsl);

  // Pass 1 fixes typo (auto)
  const typoFix = fixes.find(f => f.before === 'requireUrVerification');
  assert.ok(typoFix);
  assert.equal(typoFix.kind, 'auto');

  // Multi-pass unmasks passkeyOnly contradiction (suggested)
  const contradictionFix = fixes.find(f => f.before === 'passwordFallback requireMfa');
  assert.ok(contradictionFix, 'Unmasks contradiction fix in multi-pass execution');
  assert.equal(contradictionFix.kind, 'suggested');
  assert.equal(contradictionFix.after, 'passwordFallback none');
});
