/**
 * tests/audit_log.test.js
 * 
 * Unit tests for Audit Logging Service: event logging, trail retrieval, and cryptographic integrity.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const os = require('os');
const fs = require('fs');

const auditLog = require('../services/audit_log');
const { AuthStore } = require('../services/store');

test('Audit Log: appends event and preserves chain integrity', () => {
  const tmpPath = path.join(os.tmpdir(), `test_audit_svc_${Date.now()}.json`);
  const store = new AuthStore(tmpPath);

  const entry = auditLog.logEvent('USER_REGISTER', 'alice', { credentialId: 'c1' }, store);
  assert.ok(entry);
  assert.equal(entry.action, 'USER_REGISTER');
  assert.equal(entry.username, 'alice');
  assert.ok(entry.hash);

  const trail = auditLog.getAuditTrail(store);
  assert.ok(trail.length >= 2);

  const valid = auditLog.verifyIntegrity(store);
  assert.equal(valid, true);

  try { fs.unlinkSync(tmpPath); } catch (e) {}
});
