/**
 * dsl_parser.js
 * 
 * Re-export wrapper for Agent ID-1 Parser.
 */
'use strict';
module.exports = require('./agents/id1_parser');
