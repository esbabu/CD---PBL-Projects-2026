/**
 * test_owner_auth.js
 * 
 * Comprehensive Verification Suite for Manual Owner Authorization
 * for Hardened C++ Code Generation.
 * 
 * Verifies:
 * 1. Unapproved access to C++ source is blocked (403 Forbidden).
 * 2. Requester access request creation (Pending status, secure token).
 * 3. Pending status access denial with required message.
 * 4. Owner authentication enforcement (unauthorized callers blocked).
 * 5. Owner approval transitions request to APPROVED.
 * 6. Authorized requester can download/view hardened C++ validator.
 * 7. Unauthorized user / token mismatch is strictly blocked.
 * 8. Owner rejection blocks code release with rejection message.
 * 9. Repeated / tampered requests fail securely.
 * 10. Tamper-evident audit log records all lifecycle events.
 */

const assert = require('assert');

const BASE_URL = process.env.TEST_URL || 'http://127.0.0.1:3000';
const OWNER_SECRET = process.env.OWNER_AUTH_SECRET || 'OwnerSecretKey2026!SecureGate';

async function runTests() {
  console.log('================================================================================');
  console.log('🛡️ MANUAL OWNER AUTHORIZATION FOR HARDENED C++ CODE GENERATION - TEST SUITE');
  console.log('================================================================================');

  let passed = 0;
  let total = 0;

  async function step(name, fn) {
    total++;
    try {
      await fn();
      console.log(`  ✅ Test ${total}: ${name} [PASS]`);
      passed++;
    } catch (err) {
      console.error(`  ❌ Test ${total}: ${name} [FAIL]`);
      console.error(`     Error: ${err.message}`);
      throw err;
    }
  }

  // Compile a sample policy first to make sure validator exists
  await fetch(`${BASE_URL}/api/compile`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ policyDsl: 'minLength 12\nrequireUpper true\nrequireDigit true' })
  });

  let request1 = null;
  let request2 = null;

  // TEST 1: Direct unauthenticated request to /api/generated-code for C++ is blocked
  await step('Direct unauthenticated request for C++ code is blocked (HTTP 403)', async () => {
    const res = await fetch(`${BASE_URL}/api/generated-code?lang=cpp`);
    assert.strictEqual(res.status, 403, `Expected status 403, got ${res.status}`);
    const data = await res.json();
    assert.strictEqual(data.ok, false);
    assert.strictEqual(data.authorizationRequired, true);
    assert.ok(data.message.includes('Manual Owner Authorization is required'));
  });

  // TEST 2: Submit access request for Requester 1 (Alice)
  await step('Requester submits access request -> Returns PENDING and secure token', async () => {
    const res = await fetch(`${BASE_URL}/api/code/request-access`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requesterId: 'alice@enterprise.org',
        policyDsl: 'minLength 14\nrequireUpper true\nrequireSpecial true',
        reason: 'Integration into PCI-DSS payment gateway'
      })
    });
    assert.strictEqual(res.status, 200, `Expected status 200, got ${res.status}`);
    request1 = await res.json();
    assert.strictEqual(request1.ok, true);
    assert.ok(request1.requestId && request1.requestId.startsWith('req_'));
    assert.ok(request1.requesterToken && request1.requesterToken.startsWith('token_'));
    assert.strictEqual(request1.status, 'PENDING');
    assert.strictEqual(
      request1.message,
      'Your request for hardened C++ code has been sent to the project owner. Access will be granted only after manual approval.'
    );
  });

  // TEST 3: Accessing code while status is PENDING must be denied with required message
  await step('Accessing C++ code while PENDING is denied (HTTP 403 with approval pending message)', async () => {
    const res = await fetch(`${BASE_URL}/api/code/access/${request1.requestId}?token=${request1.requesterToken}`);
    assert.strictEqual(res.status, 403, `Expected status 403, got ${res.status}`);
    const data = await res.json();
    assert.strictEqual(data.ok, false);
    assert.strictEqual(data.status, 'PENDING');
    assert.strictEqual(
      data.error,
      'Your request for hardened C++ code has been sent to the project owner. Access will be granted only after manual approval.'
    );
  });

  // TEST 4: Non-owner cannot access owner dashboard or view requests
  await step('Non-owner cannot view owner requests endpoint (HTTP 401)', async () => {
    const res = await fetch(`${BASE_URL}/api/owner/requests`, {
      headers: { 'X-Owner-Token': 'attacker-fake-token' }
    });
    assert.strictEqual(res.status, 401, `Expected status 401, got ${res.status}`);
  });

  // TEST 5: Non-owner cannot approve requests
  await step('Non-owner cannot approve requests (HTTP 401)', async () => {
    const res = await fetch(`${BASE_URL}/api/owner/action`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Owner-Token': 'unauthorized-token'
      },
      body: JSON.stringify({ requestId: request1.requestId, action: 'APPROVE' })
    });
    assert.strictEqual(res.status, 401, `Expected status 401, got ${res.status}`);
  });

  // TEST 6: Owner logs in and views pending requests
  await step('Owner logs in and views pending requests list', async () => {
    const loginRes = await fetch(`${BASE_URL}/api/owner/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ secret: OWNER_SECRET })
    });
    assert.strictEqual(loginRes.status, 200);
    const loginData = await loginRes.json();
    assert.ok(loginData.sessionToken);

    const listRes = await fetch(`${BASE_URL}/api/owner/requests`, {
      headers: { 'X-Owner-Token': loginData.sessionToken }
    });
    assert.strictEqual(listRes.status, 200);
    const listData = await listRes.json();
    assert.strictEqual(listData.ok, true);
    assert.ok(Array.isArray(listData.requests.pending));
    const found = listData.requests.pending.find(r => r.requestId === request1.requestId);
    assert.ok(found, `Pending request ${request1.requestId} should appear in owner pending list`);
    assert.strictEqual(found.requesterId, 'alice@enterprise.org');
  });

  // TEST 7: Owner approves Request 1
  await step('Authenticated Project Owner approves Request 1', async () => {
    const res = await fetch(`${BASE_URL}/api/owner/action`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Owner-Token': OWNER_SECRET
      },
      body: JSON.stringify({ requestId: request1.requestId, action: 'APPROVE' })
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.ok, true);
    assert.strictEqual(data.status, 'APPROVED');
  });

  // TEST 8: Authorized Requester 1 retrieves the hardened C++ code
  await step('Authorized Requester retrieves approved hardened C++ code', async () => {
    const res = await fetch(`${BASE_URL}/api/code/access/${request1.requestId}?token=${request1.requesterToken}`);
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.ok, true);
    assert.strictEqual(data.status, 'APPROVED');
    assert.ok(data.code && data.code.includes('class CompiledPolicyValidator'));
    assert.strictEqual(data.filename, 'generated_validator.cpp');
  });

  // TEST 9: Unauthorized user cannot access Requester 1's approved code
  await step('Unauthorized client with invalid token cannot access approved code (HTTP 401)', async () => {
    const res = await fetch(`${BASE_URL}/api/code/access/${request1.requestId}?token=token_forged_999999`);
    assert.strictEqual(res.status, 401);
    const data = await res.json();
    assert.strictEqual(data.ok, false);
    assert.strictEqual(data.code, 'UNAUTHORIZED_TOKEN');
  });

  // TEST 10: Owner Rejection Workflow
  await step('Owner rejection workflow: Bob requests access -> Owner rejects -> Code release blocked', async () => {
    // 1. Bob requests access
    const reqRes = await fetch(`${BASE_URL}/api/code/request-access`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requesterId: 'bob@partner.io',
        policyDsl: 'minLength 8',
        reason: 'Testing evaluation'
      })
    });
    request2 = await reqRes.json();
    assert.strictEqual(request2.status, 'PENDING');

    // 2. Owner rejects Bob's request
    const rejectRes = await fetch(`${BASE_URL}/api/owner/action`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Owner-Token': OWNER_SECRET
      },
      body: JSON.stringify({
        requestId: request2.requestId,
        action: 'REJECT',
        rejectionReason: 'Policy fails enterprise length threshold requirement.'
      })
    });
    assert.strictEqual(rejectRes.status, 200);
    const rejectData = await rejectRes.json();
    assert.strictEqual(rejectData.status, 'REJECTED');

    // 3. Bob attempts to access code -> Denied
    const accessRes = await fetch(`${BASE_URL}/api/code/access/${request2.requestId}?token=${request2.requesterToken}`);
    assert.strictEqual(accessRes.status, 403);
    const accessData = await accessRes.json();
    assert.strictEqual(accessData.ok, false);
    assert.strictEqual(accessData.status, 'REJECTED');
    assert.ok(accessData.error.includes('Access Denied: Your request for hardened C++ code was rejected by the project owner'));
  });

  // TEST 11: Audit Trail Verification
  await step('Tamper-evident audit trail records all authorization events', async () => {
    const res = await fetch(`${BASE_URL}/api/owner/audit-log?limit=20`, {
      headers: { 'X-Owner-Token': OWNER_SECRET }
    });
    assert.strictEqual(res.status, 200);
    const data = await res.json();
    assert.strictEqual(data.ok, true);
    assert.ok(Array.isArray(data.logs) && data.logs.length >= 4);

    const eventTypes = data.logs.map(l => l.eventType);
    assert.ok(eventTypes.includes('ACCESS_REQUESTED'), 'Audit log should record ACCESS_REQUESTED');
    assert.ok(eventTypes.includes('REQUEST_APPROVED'), 'Audit log should record REQUEST_APPROVED');
    assert.ok(eventTypes.includes('REQUEST_REJECTED'), 'Audit log should record REQUEST_REJECTED');
    assert.ok(eventTypes.includes('CODE_ACCESSED'), 'Audit log should record CODE_ACCESSED');
  });

  console.log('================================================================================');
  console.log(`🎉 ALL ${passed}/${total} OWNER AUTHORIZATION TESTS PASSED!`);
  console.log('================================================================================');
}

runTests().catch(err => {
  console.error('Fatal test failure:', err);
  process.exit(1);
});
