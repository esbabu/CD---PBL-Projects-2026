/**
 * broker.js
 * 
 * Zero-Trust Multi-Agent SQLite Job Broker.
 * Provides ACID-compliant job orchestration, stage transition enforcement,
 * idempotent stage executions, and a cryptographically tamper-evident event log.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { executeStage } = require('./stage_runner');
const {
  generateKeypair,
  createEnvelope,
  verifyEnvelope,
  PERMITTED_ACTIONS
} = require('./crypto_utils');
const { evaluateQuorum } = require('./quorum_engine');
const { verifyGate1Semantic, verifyGate2SecurityAndDifferential } = require('./verification_gates');
const { ReleaseSigner } = require('./release_signer');

// Dual SQLite Adapter: attempts better-sqlite3 first, falls back to Node.js built-in DatabaseSync
let Database;
try {
  const BSqlite = require('better-sqlite3');
  // Probe instantiation to verify if OS Smart App Control allows loading .node binary
  const probe = new BSqlite(':memory:');
  probe.close();
  Database = BSqlite;
} catch (e) {
  // Use Node.js native sqlite when host Smart App Control blocks .node dynamic addons
  const { DatabaseSync } = require('node:sqlite');
  Database = DatabaseSync;
}

const STAGE_TRANSITIONS = {
  'lexer': 'parser',
  'parser': 'semantic',
  'semantic': 'ir',
  'ir': 'codegen',
  'codegen': 'test',
  'test': 'audit',
  'audit': 'COMPLETED'
};

const STAGE_ORDER = ['lexer', 'parser', 'semantic', 'ir', 'codegen', 'test', 'audit'];

function sha256(data) {
  const str = typeof data === 'string' ? data : JSON.stringify(data);
  return crypto.createHash('sha256').update(str).digest('hex');
}

function canonicalString(val) {
  if (val === null || val === undefined) return '';
  if (typeof val === 'string') return val;
  return JSON.stringify(val);
}

class JobBroker {
  /**
   * @param {string} dbPath - File path to SQLite database or ':memory:'
   */
  constructor(dbPath = 'broker.db') {
    this.dbPath = dbPath;
    this.db = new Database(dbPath);
    this.initTables();

    // Initialize rising fencing counter to highest token previously recorded
    try {
      const maxLease = this.db.prepare('SELECT MAX(token) as max_token FROM leases').get();
      this.fencingCounter = (maxLease && maxLease.max_token) ? Number(maxLease.max_token) : 0;
    } catch (_) {
      this.fencingCounter = 0;
    }

    // Broker's own Ed25519 Keypair for signing task envelopes
    this.brokerKeypair = generateKeypair();
    this.publicKey = this.brokerKeypair.publicKey;
    this._privateKey = this.brokerKeypair.privateKey;
    this.compromisedAgents = new Set();
  }

  initTables() {
    // 1. Jobs Table
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS jobs (
        job_id TEXT PRIMARY KEY,
        current_stage TEXT NOT NULL,
        status TEXT NOT NULL,
        input_dsl TEXT NOT NULL,
        initial_hash TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);

    // 2. Stage Results Table (Idempotent: unique on job_id, stage, input_hash)
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS stage_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id TEXT NOT NULL,
        stage TEXT NOT NULL,
        input_hash TEXT NOT NULL,
        output_hash TEXT NOT NULL,
        status TEXT NOT NULL,
        payload_in TEXT NOT NULL,
        payload_out TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(job_id, stage, input_hash)
      );
    `);

    // 3. Leases Table (Heartbeats, Expirations & Rising Fencing Tokens)
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS leases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id TEXT NOT NULL,
        stage TEXT NOT NULL,
        worker_id TEXT NOT NULL,
        token INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        heartbeat_at INTEGER,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);

    try {
      this.db.exec('ALTER TABLE leases ADD COLUMN heartbeat_at INTEGER');
    } catch (_) {
      // Column already exists in schema
    }

    // 4. Tamper-Evident Events Hash Chain
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS events (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id TEXT NOT NULL UNIQUE,
        job_id TEXT,
        event_type TEXT NOT NULL,
        stage TEXT,
        details TEXT NOT NULL,
        prev_hash TEXT NOT NULL,
        hash TEXT NOT NULL,
        timestamp TEXT NOT NULL
      );
    `);

    // 5. Agent Public Keys Table (Broker stores ONLY public keys, never private keys)
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS agent_keys (
        agent_id TEXT PRIMARY KEY,
        stage TEXT NOT NULL,
        permitted_action TEXT NOT NULL,
        public_key_pem TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `);

    // 6. Used Nonces Table (Replay attack defense)
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS used_nonces (
        nonce TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        sender_id TEXT NOT NULL,
        used_at TEXT NOT NULL
      );
    `);

    // 7. Compromised Agents Table
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS compromised_agents (
        agent_id TEXT PRIMARY KEY,
        reason TEXT NOT NULL,
        flagged_at TEXT NOT NULL
      );
    `);
  }

  /**
   * Appends an event to the tamper-evident hash chain.
   */
  recordEvent(eventType, jobId, stage, details) {
    const timestamp = new Date().toISOString();
    const eventId = crypto.randomUUID ? crypto.randomUUID() : sha256(Date.now() + Math.random().toString());
    const detailsStr = typeof details === 'string' ? details : JSON.stringify(details);

    // Fetch latest event hash for chaining
    const latest = this.db.prepare('SELECT seq, hash FROM events ORDER BY seq DESC LIMIT 1').get();
    const prevHash = latest ? latest.hash : 'GENESIS';
    const nextSeq = latest ? (latest.seq + 1) : 1;

    // Cryptographic hash over all record fields
    const recordPayload = `${nextSeq}|${eventId}|${jobId || ''}|${eventType}|${stage || ''}|${detailsStr}|${prevHash}|${timestamp}`;
    const hash = sha256(recordPayload);

    this.db.prepare(`
      INSERT INTO events (event_id, job_id, event_type, stage, details, prev_hash, hash, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(eventId, jobId || null, eventType, stage || null, detailsStr, prevHash, hash, timestamp);

    return { seq: nextSeq, eventId, hash, prevHash };
  }

  /**
   * Verifies the entire cryptographic integrity of the event chain.
   */
  verifyChain() {
    const rows = this.db.prepare('SELECT * FROM events ORDER BY seq ASC').all();
    if (!rows || rows.length === 0) {
      return { valid: true, count: 0, message: 'Event chain is empty' };
    }

    for (let i = 0; i < rows.length; i++) {
      const current = rows[i];

      // Genesis check
      if (i === 0) {
        if (current.prev_hash !== 'GENESIS') {
          return {
            valid: false,
            brokenSeq: current.seq,
            reason: `Genesis event has invalid prev_hash: '${current.prev_hash}' expected 'GENESIS'`
          };
        }
      } else {
        const prev = rows[i - 1];
        if (current.prev_hash !== prev.hash) {
          return {
            valid: false,
            brokenSeq: current.seq,
            reason: `Broken chain link at seq ${current.seq}: prev_hash '${current.prev_hash}' does not match seq ${prev.seq} hash '${prev.hash}'`
          };
        }
      }

      // Recompute and verify record hash
      const payload = `${current.seq}|${current.event_id}|${current.job_id || ''}|${current.event_type}|${current.stage || ''}|${current.details}|${current.prev_hash}|${current.timestamp}`;
      const expectedHash = sha256(payload);

      if (expectedHash !== current.hash) {
        return {
          valid: false,
          brokenSeq: current.seq,
          reason: `Tampered record detected at seq ${current.seq}: stored hash '${current.hash}' != recomputed hash '${expectedHash}'`
        };
      }
    }

    return {
      valid: true,
      count: rows.length,
      headHash: rows[rows.length - 1].hash,
      message: `Event chain valid across all ${rows.length} records`
    };
  }

  /**
   * Registers an agent's public key with its single authorized permission.
   * Zero-Trust: Broker stores ONLY public keys, never private keys.
   */
  registerAgent(agentId, stage, publicKeyPem) {
    const permittedAction = PERMITTED_ACTIONS[stage];
    if (!permittedAction) {
      throw new Error(`Unknown stage '${stage}' for agent registration`);
    }
    const now = new Date().toISOString();
    this.db.prepare(`
      INSERT OR REPLACE INTO agent_keys (agent_id, stage, permitted_action, public_key_pem, created_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(agentId, stage, permittedAction, publicKeyPem, now);

    this.recordEvent('AGENT_REGISTERED', null, stage, { agentId, permittedAction });
    return { agentId, stage, permittedAction };
  }

  getAgentKey(agentId) {
    return this.db.prepare('SELECT * FROM agent_keys WHERE agent_id = ?').get(agentId);
  }

  /**
   * Resolves input payload for a stage from job or preceding stage result.
   */
  prepareStageInput(jobId, stage) {
    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    if (job.status === 'BLOCKED') {
      this.recordEvent('TASK_DISPATCH_REJECTED', jobId, stage, {
        reason: 'JOB_BLOCKED',
        status: job.status
      });
      throw new Error(`Job '${jobId}' is BLOCKED due to an active security alert. Task dispatch halted.`);
    }

    if (stage === 'lexer') {
      return { input: job.input_dsl };
    }

    const prevIdx = STAGE_ORDER.indexOf(stage) - 1;
    if (prevIdx < 0) throw new Error(`Unknown stage order for '${stage}'`);
    const prevStage = STAGE_ORDER[prevIdx];
    const prevRes = this.getStageResult(jobId, prevStage);
    if (!prevRes) {
      throw new Error(`Cannot dispatch stage '${stage}': preceding stage '${prevStage}' has not completed yet`);
    }

    let payload = prevRes.payload_out;
    if (!payload.constraints && ['ir', 'codegen', 'test', 'audit'].includes(stage)) {
      const semRes = this.getStageResult(jobId, 'semantic');
      if (semRes && semRes.payload_out && semRes.payload_out.constraints) {
        payload = { ...payload, constraints: semRes.payload_out.constraints };
      }
    }
    return payload;
  }

  /**
   * Dispatches a signed task envelope to an agent.
   */
  dispatchTaskEnvelope(jobId, stage, options = 30000) {
    let ttlMs = 30000;
    let fencingToken = null;
    if (typeof options === 'number') {
      ttlMs = options;
    } else if (typeof options === 'object' && options !== null) {
      if (options.ttlMs) ttlMs = options.ttlMs;
      if (options.fencingToken !== undefined) fencingToken = options.fencingToken;
    }

    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    if (job.status === 'BLOCKED') {
      this.recordEvent('TASK_DISPATCH_REJECTED', jobId, stage, {
        reason: 'JOB_BLOCKED',
        status: job.status
      });
      throw new Error(`Job '${jobId}' is BLOCKED due to an active security alert. Task dispatch halted.`);
    }

    // Verify stage transition
    if (stage !== job.current_stage) {
      this.recordEvent('TASK_DISPATCH_REJECTED', jobId, stage, {
        currentStage: job.current_stage,
        attemptedStage: stage
      });
      throw new Error(`Cannot dispatch task for '${stage}': job is currently at stage '${job.current_stage}'`);
    }

    // If fencingToken not explicitly given, lookup active lease
    if (fencingToken === null || fencingToken === undefined) {
      const activeLease = this.getActiveLease(jobId, stage);
      if (activeLease) {
        fencingToken = activeLease.token;
      }
    }

    const inputPayload = this.prepareStageInput(jobId, stage);
    const inputHash = sha256(inputPayload);
    const deadline = Date.now() + ttlMs;
    const permittedAction = PERMITTED_ACTIONS[stage];

    const envelope = createEnvelope({
      jobId,
      stage,
      inputHash,
      deadline,
      permittedAction,
      payload: inputPayload,
      privateKey: this._privateKey,
      senderId: 'broker',
      fencingToken
    });

    this.recordEvent('TASK_DISPATCHED', jobId, stage, {
      nonce: envelope.nonce,
      deadline: envelope.deadline,
      inputHash: envelope.inputHash,
      permittedAction,
      fencingToken
    });

    return envelope;
  }

  /**
   * Processes a response envelope received from an agent.
   * Strictly enforces Zero-Trust validation:
   * 1. Agent must be registered in agent_keys
   * 2. Permission boundary: permittedAction must match stage capability
   * 3. Deadline must not be expired
   * 4. Nonce must never be reused (replay prevention)
   * 5. Ed25519 signature must verify against agent's public key
   * 6. Input hash must match the expected input for this stage
   * 7. Stage transition must be strictly sequential
   */
  processResponseEnvelope(envelope) {
    if (!envelope || typeof envelope !== 'object') {
      throw new Error('[Zero-Trust Rejection] Invalid envelope structure');
    }

    const {
      jobId,
      stage,
      inputHash,
      deadline,
      nonce,
      permittedAction,
      senderId,
      payload
    } = envelope;

    const job = this.getJob(jobId);
    if (!job) {
      throw new Error(`[Zero-Trust Rejection] Job '${jobId}' not found`);
    }

    if (job.status === 'BLOCKED') {
      this.recordEvent('ENVELOPE_REJECTED', jobId, stage, {
        reason: 'JOB_BLOCKED',
        status: job.status
      });
      throw new Error(`[Zero-Trust Rejection] Job '${jobId}' is BLOCKED due to an active security alert.`);
    }

    // 1. Unregistered Agent Check
    const agent = this.getAgentKey(senderId);
    if (!agent) {
      this.recordEvent('UNREGISTERED_AGENT_REJECTED', jobId, stage, { senderId });
      throw new Error(`[Zero-Trust Rejection] Unregistered agent '${senderId}'`);
    }

    // 2. Permission Boundary Check (Agent only gets its one permission)
    const expectedAction = PERMITTED_ACTIONS[stage];
    if (permittedAction !== expectedAction || agent.permitted_action !== expectedAction || agent.stage !== stage) {
      this.recordEvent('PERMISSION_VIOLATION_REJECTED', jobId, stage, {
        senderId,
        attemptedAction: permittedAction,
        agentAuthorizedAction: agent.permitted_action,
        stageRequiredAction: expectedAction
      });
      throw new Error(`[Zero-Trust Rejection] Permission boundary violation: agent '${senderId}' is authorized for '${agent.permitted_action}' but attempted '${permittedAction}' on stage '${stage}'`);
    }

    // 3. Expired Deadline Check
    if (Date.now() > deadline) {
      this.recordEvent('EXPIRED_DEADLINE_REJECTED', jobId, stage, {
        senderId,
        deadline,
        now: Date.now()
      });
      throw new Error(`[Zero-Trust Rejection] Expired deadline: envelope expired at ${new Date(deadline).toISOString()}`);
    }

    // 4. Reused Nonce Check (Replay Attack Defense)
    const existingNonce = this.db.prepare('SELECT nonce FROM used_nonces WHERE nonce = ?').get(nonce);
    if (existingNonce) {
      this.recordEvent('REPLAY_NONCE_REJECTED', jobId, stage, { nonce, senderId });
      throw new Error(`[Zero-Trust Rejection] Reused nonce detected: '${nonce}' has already been processed (replay attack blocked)`);
    }

    // 5. Ed25519 Signature Verification
    const sigRes = verifyEnvelope(envelope, agent.public_key_pem);
    if (!sigRes.valid) {
      this.recordEvent('BAD_SIGNATURE_REJECTED', jobId, stage, {
        senderId,
        reason: sigRes.reason
      });
      throw new Error(`[Zero-Trust Rejection] Bad Ed25519 signature from agent '${senderId}': ${sigRes.reason}`);
    }

    // 6. Expected Input Hash Verification
    const expectedInput = this.prepareStageInput(jobId, stage);
    const expectedInputHash = sha256(expectedInput);
    if (inputHash !== expectedInputHash) {
      this.recordEvent('WRONG_INPUT_HASH_REJECTED', jobId, stage, {
        providedInputHash: inputHash,
        expectedInputHash
      });
      throw new Error(`[Zero-Trust Rejection] Wrong input hash: provided '${inputHash}' != expected '${expectedInputHash}'`);
    }

    // 7. Invalid Stage Transition Check
    if (stage !== job.current_stage) {
      this.recordEvent('STAGE_TRANSITION_REJECTED', jobId, stage, {
        currentStage: job.current_stage,
        attemptedStage: stage
      });
      throw new Error(`[Zero-Trust Rejection] Invalid stage transition: cannot execute '${stage}' when job is at stage '${job.current_stage}'`);
    }

    // Mark nonce as used
    this.db.prepare(`
      INSERT INTO used_nonces (nonce, job_id, sender_id, used_at) VALUES (?, ?, ?, ?)
    `).run(nonce, jobId, senderId, new Date().toISOString());

    // Extract fencing token if present
    const fencingToken = envelope.fencingToken !== undefined ? envelope.fencingToken : null;

    // Submit stage result and advance state
    const submitRes = this.submitStageResult(jobId, stage, expectedInput, payload, senderId, fencingToken);

    this.recordEvent('ENVELOPE_ACCEPTED', jobId, stage, {
      senderId,
      nonce,
      outputHash: submitRes.outputHash,
      status: submitRes.status,
      fencingToken
    });

    return {
      ok: true,
      jobId,
      stage,
      senderId,
      status: submitRes.status,
      outputHash: submitRes.outputHash,
      fencingToken,
      outputPayload: payload
    };
  }

  /**
   * Dispatches task to an AgentWorker with signed envelopes both ways.
   */
  runStageWithEnvelope(jobId, stage, agentWorker) {
    const taskEnvelope = this.dispatchTaskEnvelope(jobId, stage);
    const responseEnvelope = agentWorker.processTaskEnvelope(taskEnvelope);
    return this.processResponseEnvelope(responseEnvelope);
  }

  /**
   * PHASE 5: Dual Codegen Execution
   * Runs two independent codegen workers on the same input and compares the SHA-256
   * of their outputs. A mismatch immediately blocks the job and raises an alert.
   *
   * @param {string} jobId
   * @param {object} workerA - Primary codegen AgentWorker
   * @param {object} workerB - Secondary redundant codegen AgentWorker
   * @param {object} options - Optional execution parameters
   * @returns {object} { ok, jobId, stage: 'codegen', dualVerified: true, outputHash, status, nextStage }
   */
  runDualCodegen(jobId, workerA, workerB, options = {}) {
    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    if (job.status === 'BLOCKED') {
      this.recordEvent('DUAL_CODEGEN_REJECTED', jobId, 'codegen', { reason: 'JOB_BLOCKED' });
      throw new Error(`Job '${jobId}' is BLOCKED due to an active security alert. Dual codegen refused.`);
    }

    if (job.current_stage !== 'codegen') {
      this.recordEvent('STAGE_TRANSITION_REJECTED', jobId, 'codegen', {
        currentStage: job.current_stage,
        attemptedStage: 'codegen'
      });
      throw new Error(`Cannot run dual codegen: job '${jobId}' is currently at stage '${job.current_stage}'`);
    }

    // 1. Prepare identical input payload for both codegen workers
    const inputPayload = this.prepareStageInput(jobId, 'codegen');
    const inputHash = sha256(inputPayload);

    // 2. Dispatch signed task envelope to each worker
    const ttlMs = options.ttlMs || 30000;
    const taskEnvA = this.dispatchTaskEnvelope(jobId, 'codegen', { ttlMs, workerId: workerA.agentId });
    const taskEnvB = this.dispatchTaskEnvelope(jobId, 'codegen', { ttlMs, workerId: workerB.agentId });

    // 3. Process task envelopes in each worker
    const respA = workerA.processTaskEnvelope(taskEnvA);
    const respB = workerB.processTaskEnvelope(taskEnvB);

    // 4. Verify signatures and permission boundaries for both envelopes
    const keyA = this.getAgentKey(workerA.agentId);
    const keyB = this.getAgentKey(workerB.agentId);
    if (!keyA) throw new Error(`[Dual Codegen] Unregistered codegen worker A '${workerA.agentId}'`);
    if (!keyB) throw new Error(`[Dual Codegen] Unregistered codegen worker B '${workerB.agentId}'`);

    const sigA = verifyEnvelope(respA, keyA.public_key_pem);
    if (!sigA.valid) {
      this.recordEvent('BAD_SIGNATURE_REJECTED', jobId, 'codegen', { worker: workerA.agentId, reason: sigA.reason });
      throw new Error(`[Dual Codegen] Worker A ('${workerA.agentId}') signature invalid: ${sigA.reason}`);
    }

    const sigB = verifyEnvelope(respB, keyB.public_key_pem);
    if (!sigB.valid) {
      this.recordEvent('BAD_SIGNATURE_REJECTED', jobId, 'codegen', { worker: workerB.agentId, reason: sigB.reason });
      throw new Error(`[Dual Codegen] Worker B ('${workerB.agentId}') signature invalid: ${sigB.reason}`);
    }

    // 5. Compute SHA-256 of outputs
    const hashA = sha256(respA.payload);
    const hashB = sha256(respB.payload);

    // 6. Handle mismatch: Block job and raise security alert
    if (hashA !== hashB) {
      const nowIso = new Date().toISOString();
      this.db.prepare(`
        UPDATE jobs SET status = 'BLOCKED', updated_at = ? WHERE job_id = ?
      `).run(nowIso, jobId);

      const alertDetails = {
        alert: 'DUAL_CODEGEN_MISMATCH',
        jobId,
        stage: 'codegen',
        workerA: workerA.agentId,
        workerB: workerB.agentId,
        hashA,
        hashB,
        codeLengthA: (respA.payload && respA.payload.code) ? respA.payload.code.length : null,
        codeLengthB: (respB.payload && respB.payload.code) ? respB.payload.code.length : null,
        timestamp: nowIso
      };

      this.recordEvent('DUAL_CODEGEN_MISMATCH_ALERT', jobId, 'codegen', alertDetails);

      throw new Error(`[Dual Codegen Alert] Cryptographic hash mismatch between codegen workers! Worker A ('${workerA.agentId}') hash: ${hashA}, Worker B ('${workerB.agentId}') hash: ${hashB}. Job '${jobId}' has been BLOCKED.`);
    }

    // 7. Hashes match: Record verification and mark nonces as used
    const now = new Date().toISOString();
    this.db.prepare(`INSERT INTO used_nonces (nonce, job_id, sender_id, used_at) VALUES (?, ?, ?, ?)`).run(respA.nonce, jobId, workerA.agentId, now);
    this.db.prepare(`INSERT INTO used_nonces (nonce, job_id, sender_id, used_at) VALUES (?, ?, ?, ?)`).run(respB.nonce, jobId, workerB.agentId, now);

    this.recordEvent('DUAL_CODEGEN_VERIFIED', jobId, 'codegen', {
      workerA: workerA.agentId,
      workerB: workerB.agentId,
      outputHash: hashA,
      match: true
    });

    // 8. Submit verified stage result to advance to test stage
    const fencingToken = respA.fencingToken || null;
    const submitRes = this.submitStageResult(jobId, 'codegen', inputPayload, respA.payload, workerA.agentId, fencingToken);

    return {
      ok: true,
      jobId,
      stage: 'codegen',
      dualVerified: true,
      workerA: workerA.agentId,
      workerB: workerB.agentId,
      outputHash: hashA,
      status: submitRes.status,
      nextStage: submitRes.nextStage,
      outputPayload: respA.payload
    };
  }

  /**
   * Retrieves security alerts recorded in the event log.
   */
  getAlerts(jobId = null) {
    if (jobId) {
      return this.db.prepare(`
        SELECT seq, event_id, job_id, event_type, stage, details, timestamp 
        FROM events 
        WHERE job_id = ? AND event_type LIKE '%ALERT%' 
        ORDER BY seq ASC
      `).all(jobId).map(r => ({ ...r, details: JSON.parse(r.details) }));
    }
    return this.db.prepare(`
      SELECT seq, event_id, job_id, event_type, stage, details, timestamp 
      FROM events 
      WHERE event_type LIKE '%ALERT%' 
      ORDER BY seq ASC
    `).all().map(r => ({ ...r, details: JSON.parse(r.details) }));
  }

  /**
   * Flags an agent as compromised. Automatically triggers degraded security mode.
   */
  flagAgentCompromised(agentId, reason = 'Flagged compromised by security audit') {
    this.compromisedAgents.add(agentId);
    const now = new Date().toISOString();
    this.db.prepare(`
      INSERT OR REPLACE INTO compromised_agents (agent_id, reason, flagged_at)
      VALUES (?, ?, ?)
    `).run(agentId, reason, now);

    this.recordEvent('AGENT_COMPROMISED_ALERT', null, null, {
      alert: 'AGENT_COMPROMISED',
      agentId,
      reason,
      degradedModeActivated: true
    });
    return { agentId, compromised: true, reason };
  }

  /**
   * Checks whether an agent is currently flagged as compromised.
   */
  isAgentCompromised(agentId) {
    if (this.compromisedAgents.has(agentId)) return true;
    try {
      const row = this.db.prepare('SELECT agent_id FROM compromised_agents WHERE agent_id = ?').get(agentId);
      if (row) {
        this.compromisedAgents.add(agentId);
        return true;
      }
    } catch (_) {}
    return false;
  }

  /**
   * PHASE 6: 2-of-3 Quorum Policy Admission
   * Evaluates proposed policy across:
   * - Agent 0A (Pattern Detector)
   * - Agent 0B (Strict Allowlist Check)
   * - Deterministic Parser
   * Rejects if acceptCount < 2. In degraded mode, requires both Agent 0B & Parser.
   * Note: The LLM can propose policies but has zero (0) votes.
   */
  submitPolicyWithQuorum(proposedDsl, customJobId = null, options = {}) {
    const isDegraded = this.isAgentCompromised('agent_0') ||
                       this.isAgentCompromised('agent-00-policy-evaluator') ||
                       Boolean(options.degradedMode);

    const quorumRes = evaluateQuorum(proposedDsl, {
      degradedMode: isDegraded,
      agent0Compromised: isDegraded,
      ...options
    });

    if (!quorumRes.admitted) {
      this.recordEvent('QUORUM_REJECTED', null, null, {
        reason: 'Quorum policy admission failed',
        acceptCount: quorumRes.acceptCount,
        requiredVotes: quorumRes.requiredVotes,
        degradedMode: quorumRes.degradedMode,
        votes: quorumRes.votes
      });
      const rejectReasons = quorumRes.votes.filter(v => v.vote === 'REJECT').map(v => `${v.voter}: ${v.reason}`).join('; ');
      throw new Error(`[Quorum Admission Refused] Proposed policy rejected by quorum (${quorumRes.acceptCount}/${quorumRes.totalVotes} votes). Reasons: ${rejectReasons}`);
    }

    const job = this.createJob(proposedDsl, customJobId);

    this.recordEvent('QUORUM_ADMITTED', job.jobId, null, {
      acceptCount: quorumRes.acceptCount,
      totalVotes: quorumRes.totalVotes,
      degradedMode: quorumRes.degradedMode,
      rule: quorumRes.rule
    });

    return {
      ...job,
      quorum: quorumRes
    };
  }

  /**
   * PHASE 6: Gate 1 Semantic Verification
   */
  verifyGate1(jobId) {
    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    const semRes = this.getStageResult(jobId, 'semantic');
    let constraints = {};
    if (semRes && semRes.payload_out && semRes.payload_out.constraints) {
      constraints = semRes.payload_out.constraints;
    } else {
      const { compilePolicy } = require('./compiler_engine');
      const comp = compilePolicy(job.input_dsl);
      constraints = comp.constraints;
    }

    const receipt = verifyGate1Semantic(constraints);

    if (!receipt.approved) {
      this.recordEvent('GATE1_REJECTED', jobId, 'semantic', {
        reason: 'Semantic verification failure',
        errors: receipt.errors
      });
      throw new Error(`[Gate 1 Semantic Rejection] ${receipt.errors.join('; ')}`);
    }

    this.recordEvent('GATE1_VERIFIED', jobId, 'semantic', {
      receiptHash: receipt.receiptHash,
      constraintSummary: receipt.constraintSummary
    });

    return receipt;
  }

  /**
   * PHASE 6: Gate 2 Security Audit & Polyglot Differential Testing
   */
  verifyGate2(jobId, generatedCodes = {}, differentialOverride = null) {
    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    const semRes = this.getStageResult(jobId, 'semantic');
    let constraints = {};
    if (semRes && semRes.payload_out && semRes.payload_out.constraints) {
      constraints = semRes.payload_out.constraints;
    } else {
      const { compilePolicy } = require('./compiler_engine');
      const comp = compilePolicy(job.input_dsl);
      constraints = comp.constraints;
    }

    const receipt = verifyGate2SecurityAndDifferential(constraints, generatedCodes, differentialOverride);

    if (!receipt.approved) {
      this.recordEvent('GATE2_REJECTED', jobId, 'codegen', {
        reason: receipt.reason,
        errors: receipt.errors || receipt.disagreements
      });
      throw new Error(`[Gate 2 Security & Differential Rejection] ${receipt.reason}`);
    }

    this.recordEvent('GATE2_VERIFIED', jobId, 'codegen', {
      receiptHash: receipt.receiptHash,
      testVectorCount: receipt.testVectorCount,
      languagesVerified: receipt.languagesVerified,
      agreementRate: receipt.agreementRate
    });

    return receipt;
  }

  /**
   * PHASE 6: Release Signer Orchestration
   * Signs the final validator only when both gates approve and artifact hash matches.
   */
  releaseArtifact(jobId, releaseSigner, options = {}) {
    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    if (job.status === 'BLOCKED') {
      this.recordEvent('RELEASE_REJECTED', jobId, null, { reason: 'JOB_BLOCKED' });
      throw new Error(`Cannot release artifact: Job '${jobId}' is BLOCKED due to an active security alert.`);
    }

    // 1. Quorum verification receipt
    const isDegraded = this.isAgentCompromised('agent_0') || Boolean(options.degradedMode);
    const quorumReceipt = evaluateQuorum(job.input_dsl, {
      degradedMode: isDegraded,
      agent0Compromised: isDegraded
    });

    if (!quorumReceipt.admitted) {
      this.recordEvent('RELEASE_REJECTED', jobId, null, { reason: 'QUORUM_NOT_MET' });
      throw new Error(`[Release Rejection] Policy failed 2-of-3 quorum verification`);
    }

    // 2. Gate 1 Receipt
    const gate1Receipt = this.verifyGate1(jobId);

    // 3. Artifact extraction and Gate 2 Receipt
    const codegenRes = this.getStageResult(jobId, 'codegen');
    const artifact = options.artifact || (codegenRes ? codegenRes.payload_out.code : null);
    if (!artifact) {
      throw new Error(`[Release Rejection] No compiled artifact found for job '${jobId}'`);
    }

    const expectedHash = options.expectedHash || sha256(artifact);
    const generatedCodes = options.generatedCodes || { cpp: artifact };

    const gate2Receipt = this.verifyGate2(jobId, generatedCodes, options.differentialOverride || null);

    // 4. Standalone Release Signer program signs release bundle
    const releaseBundle = releaseSigner.signRelease({
      jobId,
      artifact,
      expectedHash,
      gate1Receipt,
      gate2Receipt,
      quorumReceipt,
      auditDir: options.auditDir || null
    });

    this.recordEvent('RELEASE_SIGNED', jobId, 'audit', {
      signerId: releaseBundle.signerId,
      artifactHash: releaseBundle.artifactHash,
      signature: releaseBundle.signature,
      auditReportPath: (releaseBundle.auditReport && releaseBundle.auditReport.auditFilePath) || null
    });

    return releaseBundle;
  }

  /**
   * Creates a new compilation job.
   */
  createJob(inputDsl, customJobId = null) {
    if (!inputDsl || typeof inputDsl !== 'string') {
      throw new Error('createJob requires non-empty inputDsl string');
    }

    const jobId = customJobId || `job_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const initialHash = sha256(inputDsl);
    const now = new Date().toISOString();

    this.db.prepare(`
      INSERT INTO jobs (job_id, current_stage, status, input_dsl, initial_hash, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(jobId, 'lexer', 'PENDING', inputDsl, initialHash, now, now);

    this.recordEvent('JOB_CREATED', jobId, null, { initialHash, length: inputDsl.length });
    return { jobId, initialHash, currentStage: 'lexer', status: 'PENDING' };
  }

  /**
   * Retrieves a job by ID.
   */
  getJob(jobId) {
    return this.db.prepare('SELECT * FROM jobs WHERE job_id = ?').get(jobId);
  }

  /**
   * Retrieves stage result for a given stage of a job.
   */
  getStageResult(jobId, stage) {
    const row = this.db.prepare(`
      SELECT * FROM stage_results WHERE job_id = ? AND stage = ? ORDER BY id DESC LIMIT 1
    `).get(jobId, stage);

    if (!row) return null;
    return {
      ...row,
      payload_in: JSON.parse(row.payload_in),
      payload_out: JSON.parse(row.payload_out)
    };
  }

  /**
   * Returns the active (unexpired) lease for a job stage, if one exists.
   * If a lease exists but has expired, updates its status to 'EXPIRED' and returns null.
   */
  getActiveLease(jobId, stage) {
    const lease = this.db.prepare(`
      SELECT * FROM leases 
      WHERE job_id = ? AND stage = ? AND status = 'ACTIVE' 
      ORDER BY token DESC LIMIT 1
    `).get(jobId, stage);

    if (!lease) return null;

    const now = Date.now();
    if (now > lease.expires_at) {
      const isoNow = new Date(now).toISOString();
      this.db.prepare(`
        UPDATE leases SET status = 'EXPIRED', updated_at = ? WHERE id = ?
      `).run(isoNow, lease.id);

      this.recordEvent('LEASE_EXPIRED', jobId, stage, {
        workerId: lease.worker_id,
        token: lease.token,
        expiresAt: lease.expires_at,
        expiredAt: now
      });
      return null;
    }

    return lease;
  }

  /**
   * Returns the most recent lease for a job stage (regardless of status).
   */
  getLatestLease(jobId, stage) {
    return this.db.prepare(`
      SELECT * FROM leases WHERE job_id = ? AND stage = ? ORDER BY token DESC LIMIT 1
    `).get(jobId, stage);
  }

  /**
   * Scans and marks all expired active leases as EXPIRED.
   */
  expireStaleLeases() {
    const now = Date.now();
    const expired = this.db.prepare(`
      SELECT * FROM leases WHERE status = 'ACTIVE' AND expires_at < ?
    `).all(now);

    const isoNow = new Date(now).toISOString();
    for (const l of expired) {
      this.db.prepare(`UPDATE leases SET status = 'EXPIRED', updated_at = ? WHERE id = ?`).run(isoNow, l.id);
      this.recordEvent('LEASE_EXPIRED', l.job_id, l.stage, {
        workerId: l.worker_id,
        token: l.token,
        expiresAt: l.expires_at,
        expiredAt: now
      });
    }
    return expired;
  }

  /**
   * Acquires a lease for a worker to execute a stage.
   * Monotonically rising fencing token is assigned.
   * Rejects if active lease is currently held by another worker.
   * If a previous lease expired, this represents a standby takeover.
   */
  acquireLease(jobId, stage, workerId, ttlMs = null) {
    if (!ttlMs) {
      ttlMs = parseInt(process.env.DEMO_LEASE_TTL_MS || '5000', 10);
    }
    const job = this.getJob(jobId);
    if (!job) {
      throw new Error(`Job '${jobId}' not found`);
    }

    if (job.status === 'BLOCKED') {
      this.recordEvent('LEASE_REJECTED', jobId, stage, {
        reason: 'JOB_BLOCKED',
        status: job.status
      });
      throw new Error(`Cannot acquire lease: Job '${jobId}' is BLOCKED due to a security alert.`);
    }

    // Verify stage transition
    if (stage !== job.current_stage) {
      this.recordEvent('LEASE_REJECTED', jobId, stage, {
        reason: 'Out-of-order stage',
        currentStage: job.current_stage,
        attemptedStage: stage
      });
      throw new Error(`Out-of-order stage: cannot acquire lease for '${stage}' when job is at stage '${job.current_stage}'.`);
    }

    // Check if there is already an active (unexpired) lease
    const activeLease = this.getActiveLease(jobId, stage);
    if (activeLease) {
      if (activeLease.worker_id === workerId) {
        // Same worker refreshing/re-acquiring
        return activeLease;
      }
      // Another worker holds this lease and it has not expired!
      this.recordEvent('LEASE_CONFLICT_REJECTED', jobId, stage, {
        activeHolder: activeLease.worker_id,
        attemptedWorker: workerId,
        token: activeLease.token,
        expiresAt: activeLease.expires_at
      });
      throw new Error(`Lease conflict: stage '${stage}' is actively held by '${activeLease.worker_id}' until ${new Date(activeLease.expires_at).toISOString()}`);
    }

    // Previous lease check (for standby takeover detection)
    const prevLease = this.getLatestLease(jobId, stage);
    const isStandbyTakeover = Boolean(prevLease && prevLease.worker_id !== workerId);

    // Monotonically rising fencing token: always strictly greater than all previous tokens
    const maxRow = this.db.prepare('SELECT MAX(token) as max_token FROM leases').get();
    const highestToken = (maxRow && maxRow.max_token) ? Number(maxRow.max_token) : 0;
    this.fencingCounter = Math.max(this.fencingCounter, highestToken) + 1;
    const token = this.fencingCounter;

    const now = Date.now();
    const expiresAt = now + ttlMs;
    const isoNow = new Date(now).toISOString();

    this.db.prepare(`
      INSERT INTO leases (job_id, stage, worker_id, token, expires_at, heartbeat_at, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(jobId, stage, workerId, token, expiresAt, now, 'ACTIVE', isoNow, isoNow);

    if (isStandbyTakeover) {
      this.recordEvent('STANDBY_TAKEOVER', jobId, stage, {
        previousWorker: prevLease.worker_id,
        previousToken: prevLease.token,
        newWorker: workerId,
        newToken: token,
        expiresAt
      });
    } else {
      this.recordEvent('LEASE_ACQUIRED', jobId, stage, { workerId, token, expiresAt });
    }

    return { jobId, stage, workerId, token, expiresAt, status: 'ACTIVE' };
  }

  /**
   * Processes a heartbeat from a worker to extend its task lease.
   */
  heartbeat(jobId, stage, workerId, fencingToken, extensionMs = 5000) {
    if (fencingToken === undefined || fencingToken === null) {
      throw new Error(`[Heartbeat Rejected] Missing fencing token`);
    }

    const lease = this.db.prepare(`
      SELECT * FROM leases WHERE job_id = ? AND stage = ? AND token = ?
    `).get(jobId, stage, fencingToken);

    if (!lease) {
      this.recordEvent('HEARTBEAT_REJECTED', jobId, stage, {
        workerId,
        token: fencingToken,
        reason: 'UNKNOWN_LEASE_TOKEN'
      });
      throw new Error(`[Heartbeat Rejected] No lease found with token ${fencingToken}`);
    }

    if (lease.worker_id !== workerId) {
      this.recordEvent('HEARTBEAT_REJECTED', jobId, stage, {
        workerId,
        token: fencingToken,
        reason: 'WORKER_MISMATCH',
        owner: lease.worker_id
      });
      throw new Error(`[Heartbeat Rejected] Worker mismatch: lease belongs to '${lease.worker_id}', got '${workerId}'`);
    }

    // Check if superseded by higher fencing token
    const higherLease = this.db.prepare(`
      SELECT token, worker_id FROM leases WHERE job_id = ? AND stage = ? AND token > ?
    `).get(jobId, stage, fencingToken);

    if (higherLease) {
      this.db.prepare(`UPDATE leases SET status = 'SUPERSEDED', updated_at = ? WHERE id = ?`)
        .run(new Date().toISOString(), lease.id);
      this.recordEvent('HEARTBEAT_REJECTED', jobId, stage, {
        workerId,
        token: fencingToken,
        reason: 'STALE_FENCING_TOKEN',
        supersededByToken: higherLease.token
      });
      throw new Error(`[Heartbeat Rejected] Stale fencing token ${fencingToken}: superseded by token ${higherLease.token}`);
    }

    if (lease.status !== 'ACTIVE') {
      this.recordEvent('HEARTBEAT_REJECTED', jobId, stage, {
        workerId,
        token: fencingToken,
        reason: `LEASE_NOT_ACTIVE (${lease.status})`
      });
      throw new Error(`[Heartbeat Rejected] Lease is already '${lease.status}'`);
    }

    const now = Date.now();
    if (now > lease.expires_at) {
      this.db.prepare(`UPDATE leases SET status = 'EXPIRED', updated_at = ? WHERE id = ?`)
        .run(new Date(now).toISOString(), lease.id);
      this.recordEvent('HEARTBEAT_REJECTED', jobId, stage, {
        workerId,
        token: fencingToken,
        reason: 'LEASE_EXPIRED'
      });
      throw new Error(`[Heartbeat Rejected] Lease expired at ${new Date(lease.expires_at).toISOString()}`);
    }

    const newExpiresAt = now + extensionMs;
    const isoNow = new Date(now).toISOString();

    this.db.prepare(`
      UPDATE leases SET expires_at = ?, heartbeat_at = ?, updated_at = ? WHERE id = ?
    `).run(newExpiresAt, now, isoNow, lease.id);

    this.recordEvent('HEARTBEAT_ACCEPTED', jobId, stage, {
      workerId,
      token: fencingToken,
      heartbeatAt: now,
      newExpiresAt
    });

    return {
      ok: true,
      jobId,
      stage,
      workerId,
      token: fencingToken,
      expiresAt: newExpiresAt
    };
  }

  /**
   * Submits a completed stage result.
   * Enforces:
   * 1. Rising fencing token and zombie worker rejection
   * 2. Idempotency on (job_id, stage, input_hash)
   * 3. Allowed transition checking
   * 4. Tamper-evident logging
   */
  submitStageResult(jobId, stage, inputPayload, outputPayload, workerId = 'system', fencingToken = null) {
    const job = this.getJob(jobId);
    if (!job) {
      throw new Error(`Job '${jobId}' not found`);
    }

    if (job.status === 'BLOCKED') {
      this.recordEvent('STAGE_REJECTED', jobId, stage, {
        reason: 'JOB_BLOCKED',
        status: job.status
      });
      throw new Error(`Cannot submit stage result: Job '${jobId}' is BLOCKED due to a security alert.`);
    }

    const inputHash = sha256(inputPayload);
    const outputHash = sha256(outputPayload);
    const now = new Date().toISOString();

    // Fencing token validation: if leases exist for this job & stage, enforce fencing rules!
    const latestLease = this.getLatestLease(jobId, stage);
    if (latestLease) {
      if (fencingToken === undefined || fencingToken === null) {
        this.recordEvent('FENCING_REJECTED', jobId, stage, {
          reason: 'MISSING_FENCING_TOKEN',
          workerId,
          activeToken: latestLease.token
        });
        throw new Error(`[Fencing Rejection] Stage '${stage}' requires a valid fencing token (latest issued is ${latestLease.token})`);
      }

      // 1. Stale token check (rising fencing token rule)
      if (fencingToken < latestLease.token) {
        this.recordEvent('FENCING_REJECTED', jobId, stage, {
          reason: 'STALE_FENCING_TOKEN',
          providedToken: fencingToken,
          activeToken: latestLease.token,
          workerId
        });
        throw new Error(`[Fencing Rejection] Stale fencing token ${fencingToken}: active token is ${latestLease.token}. Write refused.`);
      }

      // 2. Fetch specific lease corresponding to this token
      const lease = this.db.prepare(`
        SELECT * FROM leases WHERE job_id = ? AND stage = ? AND token = ?
      `).get(jobId, stage, fencingToken);

      if (!lease) {
        this.recordEvent('FENCING_REJECTED', jobId, stage, {
          reason: 'UNKNOWN_FENCING_TOKEN',
          providedToken: fencingToken,
          workerId
        });
        throw new Error(`[Fencing Rejection] Unknown fencing token ${fencingToken}. Write refused.`);
      }

      // 3. Worker mismatch check
      if (lease.worker_id !== workerId) {
        this.recordEvent('FENCING_REJECTED', jobId, stage, {
          reason: 'WORKER_MISMATCH',
          leaseHolder: lease.worker_id,
          attemptedWorker: workerId,
          fencingToken
        });
        throw new Error(`[Fencing Rejection] Worker mismatch: token ${fencingToken} was issued to '${lease.worker_id}', not '${workerId}'. Write refused.`);
      }

      // 4. Lease expiration / Zombie worker check
      const nowMs = Date.now();
      if (lease.status === 'EXPIRED' || nowMs > lease.expires_at) {
        if (lease.status !== 'EXPIRED') {
          this.db.prepare(`UPDATE leases SET status = 'EXPIRED', updated_at = ? WHERE id = ?`)
            .run(new Date(nowMs).toISOString(), lease.id);
        }
        this.recordEvent('FENCING_REJECTED', jobId, stage, {
          reason: 'LEASE_EXPIRED_ZOMBIE_WORKER',
          workerId,
          token: fencingToken,
          expiresAt: lease.expires_at,
          attemptedAt: nowMs
        });
        throw new Error(`[Fencing Rejection] Lease expired for token ${fencingToken} at ${new Date(lease.expires_at).toISOString()}. Zombie worker write refused.`);
      }

      // 5. Active status check
      if (lease.status !== 'ACTIVE') {
        this.recordEvent('FENCING_REJECTED', jobId, stage, {
          reason: `LEASE_NOT_ACTIVE (${lease.status})`,
          workerId,
          token: fencingToken
        });
        throw new Error(`[Fencing Rejection] Lease token ${fencingToken} is '${lease.status}'. Write refused.`);
      }
    }

    // Check idempotency first: (job_id, stage, input_hash)
    const existing = this.db.prepare(`
      SELECT * FROM stage_results WHERE job_id = ? AND stage = ? AND input_hash = ?
    `).get(jobId, stage, inputHash);

    if (existing) {
      this.recordEvent('IDEMPOTENT_HIT', jobId, stage, {
        inputHash,
        outputHash: existing.output_hash,
        workerId
      });
      return {
        ok: true,
        cached: true,
        jobId,
        stage,
        inputHash,
        outputHash: existing.output_hash,
        outputPayload: JSON.parse(existing.payload_out)
      };
    }

    // Allowed transition check for new execution
    if (stage !== job.current_stage) {
      this.recordEvent('STAGE_REJECTED', jobId, stage, {
        reason: 'Out-of-order stage transition',
        currentStage: job.current_stage,
        attemptedStage: stage
      });
      throw new Error(`Invalid stage transition: cannot execute '${stage}' when job is at stage '${job.current_stage}'.`);
    }

    const payloadInStr = typeof inputPayload === 'string' ? inputPayload : JSON.stringify(inputPayload);
    const payloadOutStr = typeof outputPayload === 'string' ? outputPayload : JSON.stringify(outputPayload);
    const status = outputPayload && outputPayload.success === false ? 'FAILED' : 'COMPLETED';

    // Insert stage result
    this.db.prepare(`
      INSERT INTO stage_results (job_id, stage, input_hash, output_hash, status, payload_in, payload_out, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(jobId, stage, inputHash, outputHash, status, payloadInStr, payloadOutStr, now);

    // Advance job state
    const nextStage = status === 'FAILED' ? job.current_stage : (STAGE_TRANSITIONS[stage] || 'COMPLETED');
    const jobStatus = status === 'FAILED' ? 'FAILED' : (nextStage === 'COMPLETED' ? 'COMPLETED' : 'RUNNING');

    this.db.prepare(`
      UPDATE jobs SET current_stage = ?, status = ?, updated_at = ? WHERE job_id = ?
    `).run(nextStage, jobStatus, now, jobId);

    // If a lease was used, mark it completed
    if (latestLease && fencingToken) {
      this.db.prepare(`
        UPDATE leases SET status = 'COMPLETED', updated_at = ? WHERE job_id = ? AND stage = ? AND token = ?
      `).run(now, jobId, stage, fencingToken);
      this.recordEvent('LEASE_COMPLETED', jobId, stage, { workerId, token: fencingToken });
    }

    this.recordEvent('STAGE_COMPLETED', jobId, stage, {
      workerId,
      inputHash,
      outputHash,
      status,
      nextStage,
      jobStatus,
      fencingToken
    });

    return {
      ok: true,
      cached: false,
      jobId,
      stage,
      inputHash,
      outputHash,
      status,
      nextStage,
      jobStatus,
      fencingToken,
      outputPayload
    };
  }

  /**
   * Executes a stage automatically using the isolated stage runner.
   */
  runStage(jobId, stage, workerId = 'system') {
    const job = this.getJob(jobId);
    if (!job) throw new Error(`Job '${jobId}' not found`);

    if (job.status === 'BLOCKED') {
      this.recordEvent('TASK_DISPATCH_REJECTED', jobId, stage, {
        reason: 'JOB_BLOCKED',
        status: job.status
      });
      throw new Error(`Job '${jobId}' is BLOCKED due to an active security alert. Task dispatch halted.`);
    }

    // Prepare input payload depending on stage
    let inputPayload;
    if (stage === 'lexer') {
      inputPayload = { input: job.input_dsl };
    } else {
      // Input is the output of the preceding stage
      const prevIdx = STAGE_ORDER.indexOf(stage) - 1;
      if (prevIdx < 0) throw new Error(`Unknown stage order for '${stage}'`);
      const prevStage = STAGE_ORDER[prevIdx];
      const prevRes = this.getStageResult(jobId, prevStage);
      if (!prevRes) {
        throw new Error(`Cannot run '${stage}': preceding stage '${prevStage}' has not been completed yet`);
      }
      inputPayload = prevRes.payload_out;
      if (!inputPayload.constraints && ['ir', 'codegen', 'test', 'audit'].includes(stage)) {
        const semRes = this.getStageResult(jobId, 'semantic');
        if (semRes && semRes.payload_out && semRes.payload_out.constraints) {
          inputPayload = { ...inputPayload, constraints: semRes.payload_out.constraints };
        }
      }
    }

    const inputHash = sha256(inputPayload);

    // Idempotency check before execution
    const cached = this.db.prepare(`
      SELECT * FROM stage_results WHERE job_id = ? AND stage = ? AND input_hash = ?
    `).get(jobId, stage, inputHash);

    if (cached) {
      this.recordEvent('IDEMPOTENT_HIT', jobId, stage, { inputHash, workerId });
      return {
        ok: true,
        cached: true,
        jobId,
        stage,
        inputHash,
        outputHash: cached.output_hash,
        outputPayload: JSON.parse(cached.payload_out)
      };
    }

    // Execute isolated stage
    const tmpDir = path.join(__dirname, 'tests', 'broker_tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

    const inPath = path.join(tmpDir, `${jobId}_${stage}_in.json`);
    const outPath = path.join(tmpDir, `${jobId}_${stage}_out.json`);

    fs.writeFileSync(inPath, JSON.stringify(inputPayload, null, 2), 'utf8');

    const exitCode = executeStage(stage, inPath, outPath);
    let outputPayload = {};
    try {
      outputPayload = JSON.parse(fs.readFileSync(outPath, 'utf8'));
    } catch (e) {
      outputPayload = { success: false, stage, errors: [{ message: 'Failed to read stage output: ' + e.message }] };
    }

    // Cleanup temp files
    try {
      if (fs.existsSync(inPath)) fs.unlinkSync(inPath);
      if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
    } catch (_) {}

    return this.submitStageResult(jobId, stage, inputPayload, outputPayload, workerId);
  }

  /**
   * Executes all pipeline stages sequentially for a job.
   */
  runAllStages(jobId, workerId = 'system') {
    const results = {};
    for (const st of STAGE_ORDER) {
      const res = this.runStage(jobId, st, workerId);
      results[st] = res;
      if (res.status === 'FAILED') break;
    }
    return {
      job: this.getJob(jobId),
      results
    };
  }

  close() {
    if (this.db && typeof this.db.close === 'function') {
      this.db.close();
    }
  }
}

// ---------------------------------------------------------------------------
// CLI HANDLER
// ---------------------------------------------------------------------------
function printCliUsage() {
  console.log('Usage: node broker.js <command> [options]');
  console.log('Commands:');
  console.log('  submit --file <dsl_file> [--db <db_file>]');
  console.log('  run-stage --job <job_id> --stage <stage> [--db <db_file>]');
  console.log('  run-all --job <job_id> [--db <db_file>]');
  console.log('  status --job <job_id> [--db <db_file>]');
  console.log('  verify-chain [--db <db_file>]');
  console.log('  events [--job <job_id>] [--db <db_file>]');
  console.log('  acquire-lease --job <job_id> --stage <stage> --worker <worker_id> [--ttl <ms>] [--db <db_file>]');
  console.log('  heartbeat --job <job_id> --stage <stage> --worker <worker_id> --token <token> [--ttl <ms>] [--db <db_file>]');
  console.log('  leases [--job <job_id>] [--db <db_file>]');
  console.log('  alerts [--job <job_id>] [--db <db_file>]');
  console.log('  dual-codegen --job <job_id> [--db <db_file>]');
}

function parseCliArgs() {
  const args = process.argv.slice(2);
  const parsed = { command: args[0], flags: {} };
  for (let i = 1; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2);
      const next = args[i + 1];
      if (next && !next.startsWith('--')) {
        parsed.flags[key] = next;
        i++;
      } else {
        parsed.flags[key] = true;
      }
    }
  }
  return parsed;
}

if (require.main === module) {
  const { command, flags } = parseCliArgs();
  const dbFile = flags.db || 'broker.db';

  if (!command || command === '--help' || command === '-h') {
    printCliUsage();
    process.exit(0);
  }

  const broker = new JobBroker(dbFile);

  try {
    switch (command) {
      case 'submit': {
        const file = flags.file;
        if (!file || !fs.existsSync(file)) {
          console.error('Error: valid --file path required');
          process.exit(1);
        }
        const dsl = fs.readFileSync(file, 'utf8');
        const res = broker.createJob(dsl, flags.job);
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      case 'run-stage': {
        if (!flags.job || !flags.stage) {
          console.error('Error: --job and --stage required');
          process.exit(1);
        }
        const res = broker.runStage(flags.job, flags.stage, flags.worker || 'cli');
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      case 'run-all': {
        if (!flags.job) {
          console.error('Error: --job required');
          process.exit(1);
        }
        const res = broker.runAllStages(flags.job, flags.worker || 'cli');
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      case 'status': {
        if (!flags.job) {
          console.error('Error: --job required');
          process.exit(1);
        }
        const job = broker.getJob(flags.job);
        console.log(JSON.stringify(job, null, 2));
        break;
      }

      case 'verify-chain': {
        const res = broker.verifyChain();
        console.log(JSON.stringify(res, null, 2));
        process.exit(res.valid ? 0 : 1);
        break;
      }

      case 'events': {
        const query = flags.job
          ? broker.db.prepare('SELECT seq, event_id, job_id, event_type, stage, prev_hash, hash, timestamp FROM events WHERE job_id = ? ORDER BY seq ASC').all(flags.job)
          : broker.db.prepare('SELECT seq, event_id, job_id, event_type, stage, prev_hash, hash, timestamp FROM events ORDER BY seq ASC').all();
        console.log(JSON.stringify(query, null, 2));
        break;
      }

      case 'acquire-lease': {
        if (!flags.job || !flags.stage || !flags.worker) {
          console.error('Error: --job, --stage, and --worker required');
          process.exit(1);
        }
        const ttl = flags.ttl ? parseInt(flags.ttl, 10) : 5000;
        const res = broker.acquireLease(flags.job, flags.stage, flags.worker, ttl);
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      case 'heartbeat': {
        if (!flags.job || !flags.stage || !flags.worker || flags.token === undefined) {
          console.error('Error: --job, --stage, --worker, and --token required');
          process.exit(1);
        }
        const token = parseInt(flags.token, 10);
        const ttl = flags.ttl ? parseInt(flags.ttl, 10) : 5000;
        const res = broker.heartbeat(flags.job, flags.stage, flags.worker, token, ttl);
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      case 'leases': {
        const query = flags.job
          ? broker.db.prepare('SELECT * FROM leases WHERE job_id = ? ORDER BY token ASC').all(flags.job)
          : broker.db.prepare('SELECT * FROM leases ORDER BY token ASC').all();
        console.log(JSON.stringify(query, null, 2));
        break;
      }

      case 'alerts': {
        const res = broker.getAlerts(flags.job || null);
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      case 'dual-codegen': {
        if (!flags.job) {
          console.error('Error: --job required');
          process.exit(1);
        }
        const { createDualCodegenAgents } = require('./agent_workers');
        const dualAgents = createDualCodegenAgents(broker.publicKey);
        broker.registerAgent(dualAgents.codegenA.agentId, 'codegen', dualAgents.codegenA.getPublicKey());
        broker.registerAgent(dualAgents.codegenB.agentId, 'codegen', dualAgents.codegenB.getPublicKey());
        const res = broker.runDualCodegen(flags.job, dualAgents.codegenA, dualAgents.codegenB);
        console.log(JSON.stringify(res, null, 2));
        break;
      }

      default:
        console.error(`Unknown command: '${command}'`);
        printCliUsage();
        process.exit(1);
    }
  } catch (err) {
    console.error('Broker error:', err.message);
    process.exit(1);
  } finally {
    broker.close();
  }
}

module.exports = {
  JobBroker,
  STAGE_TRANSITIONS,
  ALLOWED_TRANSITIONS: STAGE_TRANSITIONS,
  STAGE_ORDER,
  PERMITTED_ACTIONS,
  sha256,
  evaluateQuorum,
  verifyGate1Semantic,
  verifyGate2SecurityAndDifferential,
  ReleaseSigner
};
