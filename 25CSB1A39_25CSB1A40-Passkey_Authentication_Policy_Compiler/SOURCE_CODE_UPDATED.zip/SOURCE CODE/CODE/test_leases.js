/**
 * test_leases.js
 * 
 * Verification Suite for Phase 4:
 * Leases, Heartbeats, Standby Takeover, and Rising Fencing Tokens.
 */

const fs = require('fs');
const path = require('path');
const { JobBroker } = require('./broker');
const { AgentWorker, createPipelineAgents, createStandbyWorker } = require('./agent_workers');
const { createEnvelope } = require('./crypto_utils');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function runLeaseTests() {
  console.log('================================================================================');
  console.log('🧪 PHASE 4: LEASES, HEARTBEATS, STANDBY TAKEOVER & FENCING TEST SUITE');
  console.log('================================================================================\n');

  const testDb = path.join(__dirname, 'tests', 'test_phase4_leases.db');
  if (fs.existsSync(testDb)) fs.unlinkSync(testDb);

  const broker = new JobBroker(testDb);
  let testsPassed = 0;
  const totalTests = 8;

  try {
    // ------------------------------------------------------------------------
    // Setup Agents
    // ------------------------------------------------------------------------
    const primaryAgents = createPipelineAgents(broker.publicKey);
    for (const [st, ag] of Object.entries(primaryAgents)) {
      broker.registerAgent(ag.agentId, st, ag.getPublicKey());
    }

    const standbyCodegen = createStandbyWorker('codegen', broker.publicKey, 'standby');
    broker.registerAgent(standbyCodegen.agentId, 'codegen', standbyCodegen.getPublicKey());

    console.log('  ✓ Registered Primary Pipeline Agents & Standby Codegen Agent');

    // Create a job and advance to 'codegen' stage
    const sampleDsl = 'minLength 12\nrequireUpper true\nrequireDigit true\n';
    const job = broker.createJob(sampleDsl);

    // Run stages lexer -> parser -> semantic -> ir
    for (const st of ['lexer', 'parser', 'semantic', 'ir']) {
      broker.runStageWithEnvelope(job.jobId, st, primaryAgents[st]);
    }
    console.log('  ✓ Pipeline advanced to [codegen] stage');

    // ------------------------------------------------------------------------
    // TEST 1: Lease Acquisition & Rising Fencing Token
    // ------------------------------------------------------------------------
    console.log('\n--- Test 1: Lease Acquisition & Rising Fencing Token Monotonicity ---');
    const lease1 = broker.acquireLease(job.jobId, 'codegen', primaryAgents.codegen.agentId, 1500); // 1.5s TTL
    console.log(`  ✓ Lease 1 acquired: Worker=${lease1.workerId}, Token=${lease1.token}, TTL=1500ms`);

    if (typeof lease1.token !== 'number' || lease1.token <= 0) {
      throw new Error(`Invalid fencing token: ${lease1.token}`);
    }
    testsPassed++;
    console.log('  ✅ Test 1 Passed: Initial lease issued with valid positive fencing token');

    // ------------------------------------------------------------------------
    // TEST 2: Active Lease Conflict Rejection
    // ------------------------------------------------------------------------
    console.log('\n--- Test 2: Active Lease Conflict Rejection ---');
    let conflictRejected = false;
    try {
      broker.acquireLease(job.jobId, 'codegen', standbyCodegen.agentId, 3000);
    } catch (e) {
      conflictRejected = true;
      console.log(`  ✓ Rejection verified: ${e.message.split('\n')[0]}`);
    }
    if (!conflictRejected) {
      throw new Error('Broker failed to reject standby acquiring lease while primary lease was still active!');
    }
    testsPassed++;
    console.log('  ✅ Test 2 Passed: Broker blocked premature standby lease acquisition');

    // ------------------------------------------------------------------------
    // TEST 3: Heartbeat Renewal & Extension
    // ------------------------------------------------------------------------
    console.log('\n--- Test 3: Heartbeat Renewal & Lease Extension ---');
    const initialExpires = lease1.expiresAt;
    await sleep(200);

    const hbRes = broker.heartbeat(job.jobId, 'codegen', primaryAgents.codegen.agentId, lease1.token, 2000);
    console.log(`  ✓ Heartbeat sent: New ExpiresAt=${hbRes.expiresAt} (Extended by ${hbRes.expiresAt - initialExpires}ms)`);
    if (hbRes.expiresAt <= initialExpires) {
      throw new Error('Heartbeat did not extend expires_at');
    }
    testsPassed++;
    console.log('  ✅ Test 3 Passed: Heartbeat successfully extended active lease');

    // ------------------------------------------------------------------------
    // TEST 4: Primary Agent Freeze / Crash (Heartbeat Stops -> Lease Expires)
    // ------------------------------------------------------------------------
    console.log('\n--- Test 4: Heartbeat Cessation & Lease Expiry Detection ---');
    primaryAgents.codegen.simulateCrash();
    console.log('  ✓ Simulated primary codegen worker crash (heartbeats stopped)');
    
    // Wait for the lease to expire (2000ms TTL from heartbeat)
    const waitTime = Math.max(100, (hbRes.expiresAt - Date.now()) + 150);
    console.log(`  ⏳ Waiting ${waitTime}ms for lease expiration...`);
    await sleep(waitTime);

    const activeCheck = broker.getActiveLease(job.jobId, 'codegen');
    if (activeCheck !== null) {
      throw new Error('Active lease still returned after expiration window!');
    }
    testsPassed++;
    console.log('  ✅ Test 4 Passed: Expired lease automatically marked EXPIRED');

    // ------------------------------------------------------------------------
    // TEST 5: Standby Worker Takeover with Rising Fencing Token
    // ------------------------------------------------------------------------
    console.log('\n--- Test 5: Standby Worker Takeover & Rising Fencing Token ---');
    const standbyLease = broker.acquireLease(job.jobId, 'codegen', standbyCodegen.agentId, 5000);
    console.log(`  ✓ Standby Lease Acquired: Worker=${standbyLease.workerId}, Token=${standbyLease.token}`);

    if (standbyLease.token <= lease1.token) {
      throw new Error(`Fencing token did not strictly rise! Standby token=${standbyLease.token} <= Primary token=${lease1.token}`);
    }
    testsPassed++;
    console.log(`  ✅ Test 5 Passed: Standby took over with strictly higher fencing token (${standbyLease.token} > ${lease1.token})`);

    // ------------------------------------------------------------------------
    // TEST 6: Standby Executes & Submits Task Envelope with Fencing Token
    // ------------------------------------------------------------------------
    console.log('\n--- Test 6: Standby Executes & Submits with Valid Fencing Token ---');
    const taskEnv = broker.dispatchTaskEnvelope(job.jobId, 'codegen');
    console.log(`  ✓ Dispatched task envelope carrying fencing token ${taskEnv.fencingToken}`);
    if (taskEnv.fencingToken !== standbyLease.token) {
      throw new Error(`Task envelope fencing token ${taskEnv.fencingToken} != active standby lease token ${standbyLease.token}`);
    }

    const standbyResp = standbyCodegen.processTaskEnvelope(taskEnv);
    const acceptRes = broker.processResponseEnvelope(standbyResp);
    if (!acceptRes.ok) {
      throw new Error('Broker failed to accept valid response from standby worker');
    }
    console.log(`  ✓ Standby worker write accepted! Output Hash: ${acceptRes.outputHash.slice(0, 16)}...`);
    testsPassed++;
    console.log('  ✅ Test 6 Passed: Standby worker successfully completed stage under active lease');

    // ------------------------------------------------------------------------
    // TEST 7: Zombie Worker Rejection (Stale Fencing Token Defense)
    // ------------------------------------------------------------------------
    console.log('\n--- Test 7: Zombie Worker Rejection (Stale Fencing Token Defense) ---');
    
    // Create a dedicated job to test stale token rejection while stage is STILL matching
    const fenceJob = broker.createJob('minLength 8\nrequireUpper true\n');
    broker.runStageWithEnvelope(fenceJob.jobId, 'lexer', primaryAgents.lexer);
    broker.runStageWithEnvelope(fenceJob.jobId, 'parser', primaryAgents.parser);
    broker.runStageWithEnvelope(fenceJob.jobId, 'semantic', primaryAgents.semantic);
    broker.runStageWithEnvelope(fenceJob.jobId, 'ir', primaryAgents.ir);
    // fenceJob is now at stage 'codegen'

    // Worker A acquires lease with token A (TTL 300ms)
    const leaseA = broker.acquireLease(fenceJob.jobId, 'codegen', primaryAgents.codegen.agentId, 300);
    console.log(`  ✓ Primary Worker acquired lease token=${leaseA.token} on test job`);
    await sleep(350); // Let lease expire

    // Standby Worker acquires lease with rising token B
    const leaseB = broker.acquireLease(fenceJob.jobId, 'codegen', standbyCodegen.agentId, 5000);
    console.log(`  ✓ Standby Worker acquired lease token=${leaseB.token} (tokenB > tokenA)`);

    // fenceJob is STILL at stage 'codegen'.
    // Zombie primary worker attempts to submit with stale token A
    const staleTaskEnv = broker.dispatchTaskEnvelope(fenceJob.jobId, 'codegen', { fencingToken: leaseA.token });
    const zombieResp = primaryAgents.codegen.processTaskEnvelope(staleTaskEnv);
    zombieResp.fencingToken = leaseA.token; // force stale token

    let staleRejected = false;
    try {
      broker.processResponseEnvelope(zombieResp);
    } catch (e) {
      staleRejected = true;
      console.log(`  ✓ Stale fencing token correctly refused: ${e.message.split('\n')[0]}`);
      if (!e.message.includes('Stale fencing token')) {
        throw new Error(`Expected stale fencing token rejection, got: ${e.message}`);
      }
    }
    if (!staleRejected) {
      throw new Error('CRITICAL: Broker failed to reject stale fencing token while stage was active!');
    }

    // Now standby worker submits with valid token B
    const validStandbyTaskEnv = broker.dispatchTaskEnvelope(fenceJob.jobId, 'codegen', { fencingToken: leaseB.token });
    const validStandbyResp = standbyCodegen.processTaskEnvelope(validStandbyTaskEnv);
    const validStandbyRes = broker.processResponseEnvelope(validStandbyResp);
    if (!validStandbyRes.ok) throw new Error('Standby write with valid token failed');
    console.log(`  ✓ Standby worker write with valid token=${leaseB.token} succeeded`);

    testsPassed++;
    console.log('  ✅ Test 7 Passed: Zombie worker write blocked by rising fencing token');

    // ------------------------------------------------------------------------
    // TEST 8: Full Pipeline Completion & Tamper-Evident Event Chain Verification
    // ------------------------------------------------------------------------
    console.log('\n--- Test 8: Pipeline Completion & Tamper-Evident Event Chain ---');
    for (const st of ['test', 'audit']) {
      const lease = broker.acquireLease(job.jobId, st, primaryAgents[st].agentId, 5000);
      const res = broker.runStageWithEnvelope(job.jobId, st, primaryAgents[st]);
      if (!res.ok) throw new Error(`Stage '${st}' failed`);
    }

    const finalJob = broker.getJob(job.jobId);
    if (finalJob.status !== 'COMPLETED') {
      throw new Error(`Job status is ${finalJob.status}, expected COMPLETED`);
    }

    const chainCheck = broker.verifyChain();
    if (!chainCheck.valid) {
      throw new Error(`Event chain broken: ${chainCheck.reason}`);
    }
    console.log(`  ✓ Final Job Status: ${finalJob.status}`);
    console.log(`  ✓ Event Chain Verified: ${chainCheck.count} records intact`);
    testsPassed++;
    console.log('  ✅ Test 8 Passed: Complete pipeline and cryptographic event chain intact');

    console.log('\n================================================================================');
    console.log(`🎉 PHASE 4 RESULT: ${testsPassed} / ${totalTests} TESTS PASSED (100%)`);
    console.log('================================================================================\n');

    return { success: true, testsPassed, totalTests };
  } finally {
    broker.close();
    if (fs.existsSync(testDb)) fs.unlinkSync(testDb);
  }
}

if (require.main === module) {
  runLeaseTests()
    .then(r => process.exit(r.success ? 0 : 1))
    .catch(err => {
      console.error('Fatal lease test error:', err);
      process.exit(1);
    });
}

module.exports = { runLeaseTests };
