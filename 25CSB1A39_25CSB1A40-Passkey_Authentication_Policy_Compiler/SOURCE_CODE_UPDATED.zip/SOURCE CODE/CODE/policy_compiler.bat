@echo off
setlocal
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" (
        set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"
    ) else if exist "%ProgramFiles%\nodejs\node.exe" (
        set "PATH=%ProgramFiles%\nodejs;%PATH%"
    ) else if exist "%USERPROFILE%\AppData\Local\Programs\nodejs\node.exe" (
        set "PATH=%USERPROFILE%\AppData\Local\Programs\nodejs;%PATH%"
    )
)
node "%~dp0policy_compiler.js" %*
exit /b %ERRORLEVEL%
