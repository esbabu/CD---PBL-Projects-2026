/**
 * test_dual_codegen.js
 * 
 * Verification Suite for Phase 5:
 * Dual Codegen Redundancy, SHA-256 Output Verification, and Mismatch Alert Blocking.
 */

const fs = require('fs');
const path = require('path');
const { JobBroker, sha256 } = require('./broker');
const { createPipelineAgents, createDualCodegenAgents } = require('./agent_workers');

async function runDualCodegenTests() {
  console.log('================================================================================');
  console.log('🧪 PHASE 5: DUAL CODEGEN & MISMATCH ALERT VERIFICATION SUITE');
  console.log('================================================================================\n');

  const testDb = path.join(__dirname, 'tests', 'test_phase5_dual_codegen.db');
  if (fs.existsSync(testDb)) fs.unlinkSync(testDb);

  const broker = new JobBroker(testDb);
  let testsPassed = 0;
  const totalTests = 7;

  try {
    // ------------------------------------------------------------------------
    // Setup Pipeline & Dual Codegen Agents
    // ------------------------------------------------------------------------
    const pipelineAgents = createPipelineAgents(broker.publicKey);
    for (const [st, ag] of Object.entries(pipelineAgents)) {
      broker.registerAgent(ag.agentId, st, ag.getPublicKey());
    }

    const { codegenA, codegenB } = createDualCodegenAgents(broker.publicKey);
    broker.registerAgent(codegenA.agentId, 'codegen', codegenA.getPublicKey());
    broker.registerAgent(codegenB.agentId, 'codegen', codegenB.getPublicKey());

    console.log('  ✓ Registered Dual Codegen Agents:');
    console.log(`    - Primary Worker  : ${codegenA.agentId}`);
    console.log(`    - Secondary Worker: ${codegenB.agentId}`);

    // ------------------------------------------------------------------------
    // TEST 1: Honest Dual Codegen Execution & SHA-256 Match
    // ------------------------------------------------------------------------
    console.log('\n--- Test 1: Honest Dual Codegen Execution & Matching Hashes ---');
    const dsl1 = 'minLength 12\nrequireUpper true\nrequireDigit true\n';
    const job1 = broker.createJob(dsl1);

    // Advance through lexer -> parser -> semantic -> ir
    for (const st of ['lexer', 'parser', 'semantic', 'ir']) {
      broker.runStageWithEnvelope(job1.jobId, st, pipelineAgents[st]);
    }
    console.log(`  ✓ Job 1 reached stage [${broker.getJob(job1.jobId).current_stage}]`);

    const dualRes = broker.runDualCodegen(job1.jobId, codegenA, codegenB);
    console.log(`  ✓ Dual codegen output hash: ${dualRes.outputHash.slice(0, 16)}...`);
    console.log(`  ✓ Next stage after dual codegen: [${dualRes.nextStage}]`);

    if (!dualRes.ok || !dualRes.dualVerified) {
      throw new Error('Dual codegen did not report dualVerified=true');
    }
    if (dualRes.nextStage !== 'test') {
      throw new Error(`Expected nextStage 'test', got '${dualRes.nextStage}'`);
    }

    const updatedJob1 = broker.getJob(job1.jobId);
    if (updatedJob1.current_stage !== 'test') {
      throw new Error(`Job stage is '${updatedJob1.current_stage}', expected 'test'`);
    }
    testsPassed++;
    console.log('  ✅ Test 1 Passed: Redundant codegen workers produced matching hashes, job advanced');

    // ------------------------------------------------------------------------
    // TEST 2: Injected Divergence (Adversarial Codegen Output Mutation)
    // ------------------------------------------------------------------------
    console.log('\n--- Test 2: Adversarial Divergence Injection (Mismatch Trapping) ---');
    const job2 = broker.createJob(dsl1);
    for (const st of ['lexer', 'parser', 'semantic', 'ir']) {
      broker.runStageWithEnvelope(job2.jobId, st, pipelineAgents[st]);
    }

    // Inject 1-byte discrepancy into Worker B's generated code
    codegenB.setMutator((output) => {
      const corruptedCode = output.code + '\n// INJECTED ADVERSARIAL BACKDOOR BYTE\n';
      return {
        ...output,
        code: corruptedCode,
        codeLength: corruptedCode.length
      };
    });

    let mismatchAlertRaised = false;
    let alertMessage = '';
    try {
      broker.runDualCodegen(job2.jobId, codegenA, codegenB);
    } catch (err) {
      mismatchAlertRaised = true;
      alertMessage = err.message;
      console.log(`  ✓ Security alert successfully triggered:\n    "${alertMessage.split('\n')[0]}"`);
    }

    // Clean up mutator
    codegenB.clearMutator();

    if (!mismatchAlertRaised) {
      throw new Error('CRITICAL FLAW: Dual codegen failed to detect divergence between workers!');
    }
    testsPassed++;
    console.log('  ✅ Test 2 Passed: Hash mismatch detected and blocked');

    // ------------------------------------------------------------------------
    // TEST 3: Job Status Changed to BLOCKED
    // ------------------------------------------------------------------------
    console.log('\n--- Test 3: Job Status Lockdown to BLOCKED ---');
    const blockedJob = broker.getJob(job2.jobId);
    console.log(`  ✓ Job status: '${blockedJob.status}' (expected 'BLOCKED')`);
    if (blockedJob.status !== 'BLOCKED') {
      throw new Error(`Expected job status 'BLOCKED', got '${blockedJob.status}'`);
    }
    testsPassed++;
    console.log('  ✅ Test 3 Passed: Discrepant job immediately placed into BLOCKED status');

    // ------------------------------------------------------------------------
    // TEST 4: Querying Security Alerts
    // ------------------------------------------------------------------------
    console.log('\n--- Test 4: Querying Security Alert Event Log ---');
    const alerts = broker.getAlerts(job2.jobId);
    console.log(`  ✓ Found ${alerts.length} security alert record(s) for Job 2`);
    if (alerts.length === 0) {
      throw new Error('No alert event found in broker tamper-evident log');
    }
    const alert = alerts[0];
    console.log(`  ✓ Alert Event Type: ${alert.event_type}`);
    console.log(`  ✓ Worker A Hash: ${alert.details.hashA.slice(0, 16)}...`);
    console.log(`  ✓ Worker B Hash: ${alert.details.hashB.slice(0, 16)}... (DISCREPANCY)`);

    if (alert.details.hashA === alert.details.hashB) {
      throw new Error('Alert logged matching hashes, expected mismatch');
    }
    testsPassed++;
    console.log('  ✅ Test 4 Passed: Security alert audit log correctly recorded in event chain');

    // ------------------------------------------------------------------------
    // TEST 5: Blocked Job Rejects Subsequent Task Dispatch
    // ------------------------------------------------------------------------
    console.log('\n--- Test 5: Refusal to Dispatch on BLOCKED Job ---');
    let dispatchRefused = false;
    try {
      broker.dispatchTaskEnvelope(job2.jobId, 'codegen');
    } catch (err) {
      dispatchRefused = true;
      console.log(`  ✓ Dispatch refused: ${err.message.split('\n')[0]}`);
    }
    if (!dispatchRefused) {
      throw new Error('Broker permitted task dispatch on a BLOCKED job');
    }
    testsPassed++;
    console.log('  ✅ Test 5 Passed: Zero-trust lockdown prevents dispatch on blocked jobs');

    // ------------------------------------------------------------------------
    // TEST 6: Blocked Job Rejects Lease Acquisition & Writes
    // ------------------------------------------------------------------------
    console.log('\n--- Test 6: Refusal to Grant Leases on BLOCKED Job ---');
    let leaseRefused = false;
    try {
      broker.acquireLease(job2.jobId, 'codegen', codegenA.agentId);
    } catch (err) {
      leaseRefused = true;
      console.log(`  ✓ Lease acquisition refused: ${err.message.split('\n')[0]}`);
    }
    if (!leaseRefused) {
      throw new Error('Broker permitted lease acquisition on a BLOCKED job');
    }
    testsPassed++;
    console.log('  ✅ Test 6 Passed: Lease acquisition blocked on quarantined job');

    // ------------------------------------------------------------------------
    // TEST 7: Tamper-Evident Event Chain Verification with Alert Records
    // ------------------------------------------------------------------------
    console.log('\n--- Test 7: Cryptographic Event Chain Integrity Across Alerts ---');
    const chainCheck = broker.verifyChain();
    console.log(`  ✓ Event chain validation: valid=${chainCheck.valid}, total=${chainCheck.count} records`);
    if (!chainCheck.valid) {
      throw new Error(`Tamper-evident chain broken: ${chainCheck.reason}`);
    }
    testsPassed++;
    console.log('  ✅ Test 7 Passed: Cryptographic hash chain unbroken across alerts and verifications');

    console.log('\n================================================================================');
    console.log(`🎉 PHASE 5 RESULT: ${testsPassed} / ${totalTests} TESTS PASSED (100%)`);
    console.log('================================================================================\n');

    return { success: true, testsPassed, totalTests };
  } finally {
    broker.close();
    if (fs.existsSync(testDb)) fs.unlinkSync(testDb);
  }
}

if (require.main === module) {
  runDualCodegenTests()
    .then(r => process.exit(r.success ? 0 : 1))
    .catch(err => {
      console.error('Fatal dual codegen test error:', err);
      process.exit(1);
    });
}

module.exports = { runDualCodegenTests };
