# Deterministic Password Policy Compiler with Multi-Agent AI Guardrails

An enterprise-grade, Zero-Trust Domain-Specific Language (DSL) Compiler for Password Security Policies, coupled with an **8-Agent Multi-Agent AI Guardrail Network**, **Automata DFA Engine (Thompson-Hopcroft)**, **Visual AST & Dragon-Book Quadruple IR**, **Polyglot Target Code Generation (C++17, Python 3, TypeScript, Rust)**, **100 Production QA Test Cases Oracle**, and a **55-Scenario Adversarial Benchmark Suite**.

---

## 🏛️ Comprehensive System Architecture

```
                                [ User / Natural Language / Policy DSL ]
                                                    │
                                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ 🛡️ 5-LAYER ZERO-TRUST AGENTIC GUARDRAIL NETWORK                                                              │
│                                                                                                             │
│  [Agent 0: Policy Security Guard] ──► Input Sanitizer (Regex, 50KB Payload Cap, Leakage & Injection Blocker)│
│  [Agent 1: Agentic Lexer]         ──► Deterministic Tokenizer (Position tracking, Canary validation)        │
│  [Agent 2: Agentic Parser]        ──► Context-Free Grammar, Visual AST Hierarchy Construction              │
│  [Agent 3: Policy Semantic]       ──► SAT Contradiction Trapping, Levenshtein Typo Repair Suggestion        │
│  [Agent 4: Policy IR Engine]      ──► Dragon-Book 3-Address Code (TAC) Quadruples, Invariant Proofs         │
│  [Agent 5: Polyglot CodeGen]      ──► Target Code Synthesizer (C++17, Python 3, TypeScript, Rust)           │
│  [Agent 6: Validation Engine]     ──► Thompson NFA ──► Powerset DFA ──► Hopcroft Minimized DFA (O(N) Trace)  │
│  [Agent 7: Security Audit]        ──► Live HaveIBeenPwned k-Anonymity API + Leetspeak + Bloom Filter        │
└───────────────────────────────────────────────────┬─────────────────────────────────────────────────────────┘
                                                    │
                                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ ⚙️ DUAL COMPILATION & EXECUTION ORACLE                                                                      │
│                                                                                                             │
│  • Deterministic C++ Compiler Pipeline (policy_compiler.exe / compiler_engine.js)                           │
│  • Visual Abstract Syntax Tree (AST SVG hierarchy with typed node abstractions)                             │
│  • Three-Address Code (TAC) Quadruple Intermediate Representation Matrix                                    │
│  • Hopcroft-Minimized Automata DFA with live Accepted / Trap state tracking                                 │
│  • HaveIBeenPwned k-Anonymity Breach Oracle (SHA-1 prefixing; password never leaves client)                 │
│  • 100 Production QA Test Cases Suite (NIST SP 800-63B / OWASP ASVS v4.0 / ISO 27001)                      │
│  • 55-Scenario Adversarial Attack Benchmark & 2x2 Confusion Matrix                                          │
└─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js:** v18+ (tested on Node v20 & v24)
- **C++ Compiler (Optional for C++ binary build):** `g++` (C++14 or higher)
- **Python (Optional for dataset generation):** Python 3.9+

### 2. Install & Start Server
```bash
# Navigate to project directory
cd CODE

# Install dependencies (Express, CORS, Dotenv)
npm install

# Start the secure server
npm start
# or: node server.js
```
The server will boot at: **`http://localhost:3000`**

### 3. Run the Unified Quality Assurance & Security Verification Suite
```bash
npm test
# or: node run_all_tests.js
```
Runs all **5 Verification Pillars** with 100% automated assertion coverage:
1. Compiler Pipeline, Visual AST, TAC Quadruples & Automata DFA Simulation
2. Polyglot Target Code Generation (C++17, Python 3, TypeScript, Rust)
3. 100 Production QA Test Cases Oracle (NIST SP 800-63B / OWASP ASVS v4.0)
4. 55-Scenario Adversarial Benchmark Suite & Confusion Matrix
5. 8-Layer Zero-Trust Adversarial Pen-Test Suite

---

## 🤖 The 8 Autonomous AI Agents (O-A-D-A-V Architecture)

Each stage of the compiler pipeline is governed by a dedicated autonomous agent adhering to the **Observation ➔ Analysis ➔ Decision ➔ Action ➔ Verification (O-A-D-A-V)** telemetric model:

| Agent Identifier | Agent Name & Role | Primary Responsibility | Telemetry Output |
| :--- | :--- | :--- | :--- |
| **AGENT-00** | **Policy Security Guard** | Pre-compilation sanitization, prompt injection screening, Canary validation, payload size enforcement (<50KB). | Block/Allow verdict, risk score |
| **AGENT-01** | **Agentic Lexer** | Tokenization of DSL text into typed lexical symbols, line/column coordinate mapping. | Token stream count, coordinates |
| **AGENT-02** | **Agentic Parser & AST** | Context-free grammar validation, hierarchical Visual AST node tree construction. | Hierarchical AST node vector |
| **AGENT-03** | **Policy Semantic** | Constraint satisfiability (SAT), contradiction trapping (`minLength > maxLength`), Levenshtein typo repair. | Semantic constraint table, typos |
| **AGENT-04** | **Policy IR & Constraints** | Emits Dragon-Book Three-Address Code (TAC) Quadruples `[PC, Target, Opcode, Arg1, Arg2]`. | TAC instruction quadruples |
| **AGENT-05** | **Polyglot CodeGen** | Generates standalone, thread-safe validator classes for C++17, Python 3, TypeScript, and Rust. | Emitted target language files |
| **AGENT-06** | **Automata Validation** | Thompson NFA ➔ Powerset DFA ➔ Hopcroft state minimization with $O(N)$ runtime simulation. | State transition table, DFA trace |
| **AGENT-07** | **Security Audit** | Live HaveIBeenPwned $k$-Anonymity breach verification, Leetspeak normalization, Bloom filter lookup. | Breach count, entropy bits |

---

## 🧪 Quality Assurance & Test Suites

### 1. 100 Production Test Cases Oracle (`test_cases_100.json`)
Conforms to **NIST SP 800-63B**, **OWASP ASVS v4.0**, and **ISO/IEC 27001** standards. Organized across 5 core security categories:
- **Complexity (25 tests):** Character pool combinations, multi-class presence, entropy scoring.
- **Boundary & Length (20 tests):** Edge bounds, off-by-one lengths, zero-length strings, oversized payloads.
- **Encoding & Unicode (20 tests):** UTF-8 multi-byte glyphs, whitespace variations, emoji handling.
- **Injection & Pen-Test (20 tests):** SQLi, command injection strings, side-channel timing attack checks.
- **Rate Limiting (15 tests):** Sliding-window thresholds, subnet burst aggregation.

### 2. 55-Scenario Adversarial Benchmark Suite (`benchmark_scenarios.js`)
Evaluates compiler resilience against 55 adversarial vectors, producing a real-time **2x2 Confusion Matrix**:
- **True Positives (TP):** 43 attacks correctly blocked.
- **False Positives (FP):** 0 benign policies blocked.
- **True Negatives (TN):** 12 compliant policies permitted.
- **False Negatives (FN):** 0 undetected attacks.
- **Accuracy:** **100.0%** (Mean latency: **0.026 ms**).

### 3. Practical Regulatory Compliance Presets (`tests/`)
Includes 11 enterprise policy templates accessible via one-click UI buttons:
- `test_nist_sp800_63b.txt`: NIST SP 800-63B Digital Identity standard.
- `test_pci_dss_v4.txt`: PCI-DSS v4.0 Payment Card Industry standard.
- `test_fintech_banking.txt`: High-assurance financial banking policy.
- `test_hipaa_healthcare.txt`: Healthcare ePHI data protection standard.
- `test_attack_prompt_injection.txt`: Adversarial jailbreak and override test.
- `test_contradiction.txt`: Semantic contradiction and dead-code trapping.
- `test_practical_edge_cases.txt`: Extreme boundary condition verification.

---

## 🎨 Interactive Web IDE Features

Navigating to **`http://localhost:3000`** provides an enterprise split-screen dashboard:
1. **Interactive DSL Code Editor:** Syntax highlighting, line numbers, error markers, and one-click presets (`NIST 800-63B`, `PCI-DSS v4`, `FinTech`, `HIPAA`, `DSL 2.0`, `Strong`, `Medium`, `Weak`, `Errors`).
2. **Visual AST Hierarchy:** Full-width SVG graph visualizing the abstract syntax tree with typed constraint nodes (`PolicyRoot`, `LengthConstraintNode`, `CharacterConstraintNode`, `PatternConstraintNode`, `DictionaryConstraintNode`).
3. **Three-Address Code (TAC) Quadruple Matrix:** Live Dragon-Book style IR table displaying `[PC]`, `Target Register`, `Opcode`, `Arg1`, `Arg2`, and `Semantic Invariant Comments`.
4. **Visual DFA State Transition Diagram (SVG Graph):** Interactive Hopcroft-minimized state transition diagram displaying $q_0$ (Start), scanning states, double-circle accepting states ($q_{acc}$), and absorbing trap sinks ($q_{trap}$) with live active path traversal and character-level edge highlighting.
5. **Compact Automata DFA Flow:** Real-time state traversal scanner and linear $O(N)$ execution path monitor.
6. **Polyglot Code Viewer:** Live-generated standalone code for C++17, Python 3, TypeScript, and Rust with one-click copy buttons.
7. **Multi-Agent Telemetry Modal:** Detailed inspection of all 8 agents' live O-A-D-A-V execution audit trails.
8. **100-Test Suite QA Modal:** Filterable by category, status, live search, and one-click batch execution with real-time latency metrics.
9. **55-Scenario Benchmark Modal:** Complete adversarial scenario inspection with Confusion Matrix KPI scorecards.
10. **Zero-Trust Breach Checker:** Live HaveIBeenPwned $k$-Anonymity SHA-1 lookup + Leetspeak canonicalization + 2-probe Bloom filter dictionary.

---

## ⚙️ REST API Reference

| Endpoint | Method | Description |
| :--- | :--- | :--- |
| `/api/status` | `GET` | Health check, compiler status, active AI provider |
| `/api/compile` | `POST` | Compiles DSL, emits tokens, AST, IR, automata, and polyglot code |
| `/api/test-cases` | `GET` | Retrieves the 100-test production QA test catalog |
| `/api/test-cases/run` | `POST` | Executes the 100-test QA batch suite with latency metrics |
| `/api/benchmark/run` | `POST` | Evaluates all 55 adversarial scenarios and returns Confusion Matrix |
| `/api/automata` | `POST` | Generates Thompson NFA, Powerset DFA, and Hopcroft Min DFA |
| `/api/agents/telemetry` | `POST` | Retrieves live O-A-D-A-V telemetry across all 8 agents |
| `/api/check-breach` | `POST` | Verifies password breach status via HaveIBeenPwned $k$-Anonymity |
| `/api/generated-code` | `GET` | Returns synthesized validator code for C++, Python, TS, Rust |
| `/api/ai/nl-to-policy` | `POST` | Translates natural language into compiler-verified policy DSL |
| `/api/ai/review` | `POST` | Audits policy against NIST SP 800-63B standards |
| `/api/ai/synthetic-tests`| `POST` | Generates 6 mock test cases (guaranteed fake credentials only) |
| `/api/ai/explain-error` | `POST` | Diagnoses compiler errors with educational explanations and auto-fixes |

---

## 📁 Repository File Layout

```
CODE/
├── server.js                     # Secure Express backend with Zero-Trust static guardrails
├── compiler_engine.js            # Pure JS & C++ compiler bridge, AST builder, TAC IR generator
├── automata_engine.js            # Thompson NFA -> Powerset DFA -> Hopcroft Minimization engine
├── agent_telemetry_engine.js     # 8-Agent O-A-D-A-V telemetry and 55-scenario benchmark evaluator
├── benchmark_scenarios.js        # 55 sanitized adversarial attack benchmark scenarios
├── test_cases_engine.js          # 100 Production QA test cases execution oracle
├── test_cases_100.json           # 100 NIST SP 800-63B / OWASP ASVS v4.0 test cases
├── generate_100_tests.py         # Synthetic generator for 100 QA test cases
├── leetspeak_bloom_engine.js     # Leetspeak normalization and Murmur/FNV-1a Bloom Filter
├── safety_checker.js             # Zero-Trust input/output sanitization guardrails
├── ai_service.js                 # Multi-LLM provider (Gemini 2.0/1.5, OpenAI, Offline fallback)
├── run_all_tests.js              # Unified 5-pillar QA & security verification runner
├── policy_compiler.html          # Interactive Web IDE (100% synchronized with index.html)
├── index.html                    # Root entrypoint Web IDE
├── package.json                  # Node.js project manifest ("npm test" -> run_all_tests.js)
│
├── tests/                        # 11 Practical Regulatory & Adversarial Policy Test Files
│   ├── test_nist_sp800_63b.txt   # NIST SP 800-63B Digital Identity standard
│   ├── test_pci_dss_v4.txt       # PCI-DSS v4.0 Payment Card Industry standard
│   ├── test_fintech_banking.txt  # FinTech banking high-entropy standard
│   ├── test_hipaa_healthcare.txt # HIPAA healthcare ePHI protection standard
│   ├── test_attack_prompt_injection.txt # Adversarial prompt injection pen-test
│   ├── test_contradiction.txt    # Semantic contradiction trapping
│   └── test_practical_edge_cases.txt   # Boundary condition test suite
│
├── tools/                        # Auxiliary Dataset & Benchmark Tooling
│   └── generate_dataset_curation.py # Script for generating synthetic benchmark datasets
│
├── data/                         # Pre-compiled blocklist dictionaries
│   └── common_passwords.txt      # 10,000 top leaked password blocklist
│
├── generated_validator.cpp       # Auto-generated C++17 validator class
├── generated_validator.py        # Auto-generated Python 3 validator class
├── generated_validator.ts        # Auto-generated TypeScript validator class
└── generated_validator.rs        # Auto-generated Rust validator module
```

---

## 🔒 Security & Privacy Guarantees

1. **Deterministic Consensus:** AI proposals are never committed blindly. Every proposal passes through schema validation, compiler dry-run, and an explicit Human-in-the-Loop user approval gate.
2. **$k$-Anonymity Privacy:** Breach checks query the HaveIBeenPwned API using only the first 5 hexadecimal characters of the SHA-1 hash. The user's actual password never leaves the local machine.
3. **Air-Gapped Offline Operation:** The compiler operates completely offline with zero external network dependencies using the built-in deterministic NLP engine.
4. **Source Code Shielding:** The server strictly denies direct HTTP requests for source code, configuration files, dotfiles, and build artifacts (`.env`, `.js`, `.cpp`, `.h`, `.exe`).
