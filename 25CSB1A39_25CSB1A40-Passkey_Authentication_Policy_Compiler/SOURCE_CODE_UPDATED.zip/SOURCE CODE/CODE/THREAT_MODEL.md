# THREAT MODEL: Zero-Trust Multi-Agent Policy Compiler Pipeline

## 1. System Overview

This document specifies the security boundaries, threat vectors, trust assumptions, and mitigation invariants for the **Zero-Trust Multi-Agent Password Policy Compiler Pipeline**.

The pipeline compiles declarative password policy domain-specific language (DSL) into high-performance, polyglot production validators (C++17, Python 3, TypeScript, and Rust) under the supervision of specialized neuro-symbolic and deterministic guardrail agents.

```
                    ┌───────────────────────────────────────────────┐
                    │            PROPOSED POLICY (DSL)              │
                    └───────────────────────┬───────────────────────┘
                                            │
                                  [2-of-3 Quorum Gate]
                         ┌──────────────────┼──────────────────┐
                         │                  │                  │
                    Agent 0A (Pattern)  Agent 0B (Allow)   Parser (AST)
                    [LLM: 0 Votes]     [Degraded Mode]
                                            │ (≥ 2 votes)
                                            ▼
                    ┌───────────────────────────────────────────────┐
                    │               SQLITE JOB BROKER               │
                    │  * Signed Ed25519 Task & Response Envelopes   │
                    │  * Heartbeat Leases & Rising Fencing Tokens   │
                    │  * Tamper-Evident SHA-256 Event Hash Chain    │
                    └───────────────────────┬───────────────────────┘
                                            │
                         ┌──────────────────┴──────────────────┐
                         ▼                                     ▼
                   Dual Codegen A                        Dual Codegen B
                 (EMIT_VALIDATOR)                      (EMIT_VALIDATOR)
                         │                                     │
                         └───────────────┬─────────────────────┘
                                         ▼
                             [SHA-256 Output Match?]
                            ├── MISMATCH ──► [JOB BLOCKED + ALERT]
                            └── MATCH
                                         │
                                         ▼
                    ┌───────────────────────────────────────────────┐
                    │              VERIFICATION GATES               │
                    │  Gate 1: Semantic Verification (Bounds/Logic) │
                    │  Gate 2: Security Audit + Polyglot Diff Test  │
                    │          (C++, Python, TypeScript, Rust)      │
                    └───────────────────────┬───────────────────────┘
                                            │
                                      (Both Approve)
                                            ▼
                    ┌───────────────────────────────────────────────┐
                    │           STANDALONE RELEASE SIGNER           │
                    │  * Verifies Gate 1 + Gate 2 + Quorum          │
                    │  * Verifies Artifact Hash (1-Byte Flip Guard) │
                    │  * Signs Release Cert & Emits Audit Report    │
                    └───────────────────────────────────────────────┘
```

---

## 2. Core Assumptions

1. **Trusted Computing Base (TCB):**
   - The **Job Broker** runtime, its local **SQLite database**, and the **Release Authority Root Key** reside within the trusted security perimeter.
   - The host operating system kernel and local file system permissions are trusted to maintain process boundaries.

2. **Threshold Compromise Model (1-of-N):**
   - **At most one agent worker or verification gate is compromised, malicious, or Byzantine at any given time.**
   - No colluding coalition of two or more agents can compromise independent cryptographic boundaries simultaneously.

3. **Resilience & State Recovery Invariant:**
   - **Valid, started jobs resume execution from their last persisted state** in the event of worker crash, lease expiration, or pipeline restart without losing idempotent work.
   - **Unsafe, tampered, or unverified new work is immediately blocked and quarantined.** No unverified artifact is ever released.

4. **Cryptographic Primitives:**
   - Standard cryptographic primitives (Ed25519 digital signatures and SHA-256 cryptographic digests) are computationally infeasible to invert or forge.

---

## 3. Threat Actors & Attack Vectors

| Threat Vector | Description | Zero-Trust Mitigation |
| :--- | :--- | :--- |
| **T1: Prompt Injection & Adversarial Payload** | Attacker injects jailbreaks, prompt overrides, or system leaks into the policy input. | **2-of-3 Quorum Gate:** Evaluated by Agent 0A (pattern detector), Agent 0B (strict allowlist), and Deterministic Parser. The LLM has zero (0) voting rights. |
| **T2: Compromised Front-End / Agent 0** | Agent 0 is manipulated into approving an unsafe or contradictory policy. | **Safe Degraded Mode:** When Agent 0 is flagged as compromised, its vote is disregarded. The policy must strictly pass dual deterministic grammar (Agent 0B + Parser) and Gate 1. |
| **T3: Forged Messages & Impersonation** | Attacker sends forged stage completions or impersonates pipeline agents. | **Ed25519 Signed Envelopes:** Broker verifies digital signatures against stored public keys. Broker stores zero private keys. |
| **T4: Privilege Escalation** | An agent performs actions beyond its mandate (e.g. Lexer attempting Codegen). | **Single Permitted Action Enforcement:** Broker enforces strict 1:1 stage-to-action permission boundaries (`EMIT_TOKENS`, `EMIT_AST`, `EMIT_VALIDATOR`, etc.). |
| **T5: Replay Attacks** | Attacker intercepts a valid signed response and re-transmits it later. | **Cryptographic Nonce & Deadline Tracking:** Broker records nonces in `used_nonces` and enforces strict epoch deadlines (`Date.now() > deadline` rejection). |
| **T6: Worker Crash / Freeze** | Worker hangs or terminates mid-task, blocking pipeline progression. | **Heartbeat Leases & Standby Failover:** Leases expire if heartbeats cease. Standby worker acquires lease and resumes stage execution. |
| **T7: Zombie Worker Stale Writes** | A frozen worker unfreezes after lease expiry and attempts to submit delayed work. | **Monotonically Rising Fencing Tokens:** Every lease increments the fencing counter. The broker rejects any submission with `token < latestLease.token`. |
| **T8: Backdoored / Non-Deterministic Codegen** | A single codegen agent injects backdoors, telemetry, or divergent code. | **Dual Codegen Redundancy:** Two independent codegen workers run concurrently on the same IR. SHA-256 output mismatch immediately triggers `BLOCKED` status and raises a security alert. |
| **T9: Polyglot Implementation Discrepancy** | Target validators (C++, Python, TypeScript, Rust) evaluate passwords differently. | **Gate 2 Polyglot Differential Testing:** Battery of test vectors is executed across all 4 targets. Zero disagreement allowed. |
| **T10: Supply Chain / Bit-Flip Artifact Tampering** | An attacker flips a single byte in the compiled validator before deployment. | **Standalone Release Signer:** Release authority checks that `sha256(artifact) === expectedHash`. A 1-byte discrepancy aborts release. |
| **T11: Audit Trail Tampering** | Attacker modifies historical event logs or job statuses in the database. | **Tamper-Evident SHA-256 Hash Chain:** Every event record stores $H_i = \text{SHA-256}(\dots \mid H_{i-1})$. `verify-chain` detects any modification. |

---

## 4. Security Invariants & Guarantees

1. **Least Privilege:** Each agent worker holds only its own private key and is restricted to a single permitted action. The broker stores public keys only.
2. **Deterministic Governance:** Policy syntax and semantics are governed by formal grammar rules and automated semantic analyzers. LLMs are advisory only and possess no voting authority.
3. **Fail-Closed Operations:** Any signature failure, hash mismatch, lease expiration, differential discrepancy, or quorum failure transitions the pipeline into a rejected or `BLOCKED` state.
4. **Idempotency:** Stage executions are keyed on `(job_id, stage, input_hash)`. Repeated submissions return cached, verified outputs without re-executing unverified code.
5. **Non-Repudiation & Auditability:** Every stage transition, lease transfer, heartbeat, security alert, and release certificate is cryptographically chained and verifiable through `verifyChain()`.
