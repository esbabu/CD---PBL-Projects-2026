#ifndef JSON_HELPER_H
#define JSON_HELPER_H

#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <cmath>
#include <stdexcept>

enum class JsonType {
    Null,
    Bool,
    Number,
    String,
    Array,
    Object
};

class JsonValue {
public:
    JsonType type = JsonType::Null;
    bool boolVal = false;
    double numVal = 0.0;
    std::string strVal;
    std::vector<JsonValue> arrVal;
    std::vector<std::pair<std::string, JsonValue>> objVal;

    JsonValue() : type(JsonType::Null) {}
    JsonValue(bool b) : type(JsonType::Bool), boolVal(b) {}
    JsonValue(int n) : type(JsonType::Number), numVal(n) {}
    JsonValue(size_t n) : type(JsonType::Number), numVal(static_cast<double>(n)) {}
    JsonValue(double d) : type(JsonType::Number), numVal(d) {}
    JsonValue(const char* s) : type(JsonType::String), strVal(s ? s : "") {}
    JsonValue(std::string s) : type(JsonType::String), strVal(std::move(s)) {}
    JsonValue(JsonType t) : type(t) {}

    static JsonValue makeArray() {
        JsonValue v;
        v.type = JsonType::Array;
        return v;
    }

    static JsonValue makeObject() {
        JsonValue v;
        v.type = JsonType::Object;
        return v;
    }

    bool isNull() const { return type == JsonType::Null; }
    bool isBool() const { return type == JsonType::Bool; }
    bool isNumber() const { return type == JsonType::Number; }
    bool isString() const { return type == JsonType::String; }
    bool isArray() const { return type == JsonType::Array; }
    bool isObject() const { return type == JsonType::Object; }

    bool asBool(bool def = false) const {
        if (type == JsonType::Bool) return boolVal;
        if (type == JsonType::Number) return numVal != 0.0;
        if (type == JsonType::String) return strVal == "true" || strVal == "1";
        return def;
    }

    int asInt(int def = 0) const {
        if (type == JsonType::Number) return static_cast<int>(std::round(numVal));
        if (type == JsonType::String) {
            try { return std::stoi(strVal); } catch (...) { return def; }
        }
        if (type == JsonType::Bool) return boolVal ? 1 : 0;
        return def;
    }

    double asDouble(double def = 0.0) const {
        if (type == JsonType::Number) return numVal;
        if (type == JsonType::String) {
            try { return std::stod(strVal); } catch (...) { return def; }
        }
        return def;
    }

    std::string asString(const std::string& def = "") const {
        if (type == JsonType::String) return strVal;
        if (type == JsonType::Number) {
            if (std::floor(numVal) == numVal && !std::isinf(numVal)) {
                return std::to_string(static_cast<long long>(numVal));
            }
            std::ostringstream ss;
            ss << numVal;
            return ss.str();
        }
        if (type == JsonType::Bool) return boolVal ? "true" : "false";
        if (type == JsonType::Null) return "null";
        return def;
    }

    const std::vector<JsonValue>& asArray() const {
        return arrVal;
    }

    std::vector<JsonValue>& asArray() {
        return arrVal;
    }

    bool has(const std::string& key) const {
        if (type != JsonType::Object) return false;
        for (const auto& kv : objVal) {
            if (kv.first == key) return true;
        }
        return false;
    }

    const JsonValue& get(const std::string& key) const {
        static const JsonValue nullVal;
        if (type != JsonType::Object) return nullVal;
        for (const auto& kv : objVal) {
            if (kv.first == key) return kv.second;
        }
        return nullVal;
    }

    void set(const std::string& key, JsonValue val) {
        if (type != JsonType::Object) {
            type = JsonType::Object;
            objVal.clear();
        }
        for (auto& kv : objVal) {
            if (kv.first == key) {
                kv.second = std::move(val);
                return;
            }
        }
        objVal.emplace_back(key, std::move(val));
    }

    void push(JsonValue val) {
        if (type != JsonType::Array) {
            type = JsonType::Array;
            arrVal.clear();
        }
        arrVal.push_back(std::move(val));
    }

    static std::string escape(const std::string& s) {
        std::ostringstream o;
        for (char c : s) {
            if (c == '"') o << "\\\"";
            else if (c == '\\') o << "\\\\";
            else if (c == '\b') o << "\\b";
            else if (c == '\f') o << "\\f";
            else if (c == '\n') o << "\\n";
            else if (c == '\r') o << "\\r";
            else if (c == '\t') o << "\\t";
            else if ((unsigned char)c < 0x20) {
                o << "\\u" << std::hex << std::setw(4) << std::setfill('0') << (int)(unsigned char)c << std::dec;
            } else {
                o << c;
            }
        }
        return o.str();
    }

    std::string serialize(int indentLevel = 0, int indentStep = 2) const {
        std::string ind(indentLevel * indentStep, ' ');
        std::string nextInd((indentLevel + 1) * indentStep, ' ');

        switch (type) {
            case JsonType::Null:
                return "null";
            case JsonType::Bool:
                return boolVal ? "true" : "false";
            case JsonType::Number: {
                if (std::floor(numVal) == numVal && !std::isinf(numVal) && !std::isnan(numVal)) {
                    return std::to_string(static_cast<long long>(numVal));
                }
                std::ostringstream ss;
                ss << numVal;
                return ss.str();
            }
            case JsonType::String:
                return "\"" + escape(strVal) + "\"";
            case JsonType::Array: {
                if (arrVal.empty()) return "[]";
                std::ostringstream ss;
                ss << "[\n";
                for (size_t i = 0; i < arrVal.size(); ++i) {
                    ss << nextInd << arrVal[i].serialize(indentLevel + 1, indentStep);
                    if (i + 1 < arrVal.size()) ss << ",";
                    ss << "\n";
                }
                ss << ind << "]";
                return ss.str();
            }
            case JsonType::Object: {
                if (objVal.empty()) return "{}";
                std::ostringstream ss;
                ss << "{\n";
                for (size_t i = 0; i < objVal.size(); ++i) {
                    ss << nextInd << "\"" << escape(objVal[i].first) << "\": "
                       << objVal[i].second.serialize(indentLevel + 1, indentStep);
                    if (i + 1 < objVal.size()) ss << ",";
                    ss << "\n";
                }
                ss << ind << "}";
                return ss.str();
            }
        }
        return "null";
    }

    static JsonValue parse(std::string src, std::string& err) {
        if (src.size() >= 3 && (unsigned char)src[0] == 0xEF && (unsigned char)src[1] == 0xBB && (unsigned char)src[2] == 0xBF) {
            src = src.substr(3);
        }
        size_t idx = 0;
        skipWs(src, idx);
        if (idx >= src.size()) {
            err = "Empty JSON input";
            return JsonValue();
        }
        JsonValue root = parseElement(src, idx, err);
        skipWs(src, idx);
        return root;
    }

private:
    static void skipWs(const std::string& s, size_t& idx) {
        while (idx < s.size()) {
            char c = s[idx];
            if (std::isspace((unsigned char)c)) {
                idx++;
            } else if (c == '/' && idx + 1 < s.size() && s[idx + 1] == '/') {
                idx += 2;
                while (idx < s.size() && s[idx] != '\n' && s[idx] != '\r') idx++;
            } else if (c == '/' && idx + 1 < s.size() && s[idx + 1] == '*') {
                idx += 2;
                while (idx + 1 < s.size() && !(s[idx] == '*' && s[idx + 1] == '/')) idx++;
                if (idx + 1 < s.size()) idx += 2;
            } else {
                break;
            }
        }
    }

    static JsonValue parseElement(const std::string& s, size_t& idx, std::string& err) {
        skipWs(s, idx);
        if (idx >= s.size()) {
            err = "Unexpected end of input";
            return JsonValue();
        }
        char c = s[idx];
        if (c == '{') return parseObject(s, idx, err);
        if (c == '[') return parseArray(s, idx, err);
        if (c == '"') return parseString(s, idx, err);
        if (c == 't' || c == 'f') return parseBool(s, idx, err);
        if (c == 'n') return parseNull(s, idx, err);
        if (c == '-' || std::isdigit((unsigned char)c)) return parseNumber(s, idx, err);

        err = std::string("Unexpected character: '") + c + "' at position " + std::to_string(idx);
        return JsonValue();
    }

    static JsonValue parseObject(const std::string& s, size_t& idx, std::string& err) {
        JsonValue obj = JsonValue::makeObject();
        idx++; // consume '{'
        skipWs(s, idx);
        if (idx < s.size() && s[idx] == '}') {
            idx++;
            return obj;
        }

        while (idx < s.size()) {
            skipWs(s, idx);
            if (idx >= s.size() || s[idx] != '"') {
                err = "Expected string key in object at position " + std::to_string(idx);
                return obj;
            }
            JsonValue keyVal = parseString(s, idx, err);
            if (!err.empty()) return obj;

            skipWs(s, idx);
            if (idx >= s.size() || s[idx] != ':') {
                err = "Expected ':' after key at position " + std::to_string(idx);
                return obj;
            }
            idx++; // consume ':'

            JsonValue val = parseElement(s, idx, err);
            if (!err.empty()) return obj;

            obj.set(keyVal.strVal, std::move(val));

            skipWs(s, idx);
            if (idx < s.size() && s[idx] == ',') {
                idx++;
                skipWs(s, idx);
                if (idx < s.size() && s[idx] == '}') { // allow trailing comma
                    idx++;
                    return obj;
                }
            } else if (idx < s.size() && s[idx] == '}') {
                idx++;
                return obj;
            } else {
                err = "Expected ',' or '}' in object at position " + std::to_string(idx);
                return obj;
            }
        }
        err = "Unterminated object";
        return obj;
    }

    static JsonValue parseArray(const std::string& s, size_t& idx, std::string& err) {
        JsonValue arr = JsonValue::makeArray();
        idx++; // consume '['
        skipWs(s, idx);
        if (idx < s.size() && s[idx] == ']') {
            idx++;
            return arr;
        }

        while (idx < s.size()) {
            JsonValue val = parseElement(s, idx, err);
            if (!err.empty()) return arr;

            arr.push(std::move(val));

            skipWs(s, idx);
            if (idx < s.size() && s[idx] == ',') {
                idx++;
                skipWs(s, idx);
                if (idx < s.size() && s[idx] == ']') { // allow trailing comma
                    idx++;
                    return arr;
                }
            } else if (idx < s.size() && s[idx] == ']') {
                idx++;
                return arr;
            } else {
                err = "Expected ',' or ']' in array at position " + std::to_string(idx);
                return arr;
            }
        }
        err = "Unterminated array";
        return arr;
    }

    static JsonValue parseString(const std::string& s, size_t& idx, std::string& err) {
        idx++; // consume opening '"'
        std::string res;
        while (idx < s.size()) {
            char c = s[idx++];
            if (c == '"') {
                return JsonValue(res);
            }
            if (c == '\\') {
                if (idx >= s.size()) {
                    err = "Unterminated escape sequence in string";
                    return JsonValue();
                }
                char esc = s[idx++];
                if (esc == '"') res.push_back('"');
                else if (esc == '\\') res.push_back('\\');
                else if (esc == '/') res.push_back('/');
                else if (esc == 'b') res.push_back('\b');
                else if (esc == 'f') res.push_back('\f');
                else if (esc == 'n') res.push_back('\n');
                else if (esc == 'r') res.push_back('\r');
                else if (esc == 't') res.push_back('\t');
                else if (esc == 'u') {
                    if (idx + 4 <= s.size()) {
                        std::string hexStr = s.substr(idx, 4);
                        idx += 4;
                        try {
                            int code = std::stoi(hexStr, nullptr, 16);
                            if (code < 128) res.push_back(static_cast<char>(code));
                            else res.push_back('?');
                        } catch (...) {
                            res.push_back('?');
                        }
                    } else {
                        err = "Incomplete unicode escape in string";
                        return JsonValue();
                    }
                } else {
                    res.push_back(esc);
                }
            } else {
                res.push_back(c);
            }
        }
        err = "Unterminated string";
        return JsonValue();
    }

    static JsonValue parseNumber(const std::string& s, size_t& idx, std::string& err) {
        size_t start = idx;
        if (s[idx] == '-') idx++;
        while (idx < s.size() && (std::isdigit((unsigned char)s[idx]) || s[idx] == '.' ||
               s[idx] == 'e' || s[idx] == 'E' || s[idx] == '+' || s[idx] == '-')) {
            idx++;
        }
        std::string numStr = s.substr(start, idx - start);
        try {
            double val = std::stod(numStr);
            return JsonValue(val);
        } catch (...) {
            err = "Invalid number format: " + numStr;
            return JsonValue(0.0);
        }
    }

    static JsonValue parseBool(const std::string& s, size_t& idx, std::string& err) {
        if (s.compare(idx, 4, "true") == 0) {
            idx += 4;
            return JsonValue(true);
        }
        if (s.compare(idx, 5, "false") == 0) {
            idx += 5;
            return JsonValue(false);
        }
        err = "Invalid boolean literal";
        return JsonValue();
    }

    static JsonValue parseNull(const std::string& s, size_t& idx, std::string& err) {
        if (s.compare(idx, 4, "null") == 0) {
            idx += 4;
            return JsonValue();
        }
        err = "Invalid null literal";
        return JsonValue();
    }
};

#endif // JSON_HELPER_H
