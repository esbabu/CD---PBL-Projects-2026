import os
import sys
import html as html_mod
import torch
import tempfile
import time
import json

if hasattr(torch, 'classes'): 
    torch.classes.__path__ = [os.path.join(torch.__path__[0], torch.classes.__file__)]

import streamlit as st
import streamlit.components.v1 as st_components

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.ast_parser import ASTParser
from src.feature_extractor import FeatureExtractor
from src.scanner import Scanner
from src.enrichment import PromptEnricher
from src.inference import InferenceEngine
from web.energy_monitor import measure_energy

st.set_page_config(
    page_title="NLP-Based Code Summarizer with Security Audits",
    page_icon="https://api.iconify.design/tabler:shield-lock.svg",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown(
    '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.24.0/dist/tabler-icons.min.css">',
    unsafe_allow_html=True
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap');

/* ═══════════════════════════════════════════════════
   DESIGN TOKENS — Clean White & Slate (LeetCode Light Mode)
   ═══════════════════════════════════════════════════ */
:root {
    --bg:          #f8fafc;
    --surface:     #ffffff;
    --surface-2:   #f1f5f9;
    --surface-3:   #e2e8f0;
    --border:      #e2e8f0;
    --border-light:#cbd5e1;

    --accent:      #0284c7;
    --accent-hover:#0369a1;
    --accent-bg:   rgba(2, 132, 199, 0.08);
    --accent-rim:  rgba(2, 132, 199, 0.25);

    --danger:      #dc2626;
    --danger-bg:   rgba(220, 38, 38, 0.08);
    --warning:     #d97706;
    --warning-bg:  rgba(217, 119, 6, 0.08);
    --success:     #059669;
    --success-bg:  rgba(5, 150, 105, 0.08);
    --success-rim: rgba(5, 150, 105, 0.25);

    --ink:         #0f172a;
    --ink-2:       #334155;
    --ink-muted:   #64748b;
    --ink-faint:   #94a3b8;

    --mono: 'JetBrains Mono', 'Fira Code', ui-monospace, 'SF Mono', Menlo, Consolas, monospace;
    --sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-title: 'Space Grotesk', -apple-system, BlinkMacSystemFont, sans-serif;

    --radius: 8px;
    --radius-lg: 12px;
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.06);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.07), 0 2px 4px -1px rgba(0, 0, 0, 0.04);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.03);
    --shadow-glow: 0 0 20px -3px rgba(2, 132, 199, 0.2);
}

/* BASE */
html, body {
    font-family: var(--sans);
    background-color: var(--bg) !important;
    color: var(--ink) !important;
}
.stApp {
    background-color: var(--bg) !important;
    color: var(--ink) !important;
}
.block-container {
    padding-top: 1rem !important;
    padding-left: 1.25rem !important;
    padding-right: 1.25rem !important;
    padding-bottom: 2rem !important;
    max-width: 98% !important;
    margin: 0 auto !important;
}

/* SPLIT PANE SCROLLABLE CONTAINERS */
.split-pane-scroll {
    max-height: 720px;
    overflow-y: auto;
    padding-right: 8px;
    padding-bottom: 20px;
}
.split-pane-scroll::-webkit-scrollbar,
.hl-code-wrap::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}
.split-pane-scroll::-webkit-scrollbar-track,
.hl-code-wrap::-webkit-scrollbar-track {
    background: #f1f5f9;
}
.split-pane-scroll::-webkit-scrollbar-thumb,
.hl-code-wrap::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
}
.split-pane-scroll::-webkit-scrollbar-thumb:hover,
.hl-code-wrap::-webkit-scrollbar-thumb:hover {
    background: #0284c7;
}

/* TABS STYLING */
.stTabs [data-baseweb="tab-list"] {
    background-color: var(--surface) !important;
    border-radius: var(--radius) !important;
    padding: 4px !important;
    gap: 4px !important;
    border: 1px solid var(--border) !important;
    margin-bottom: 12px !important;
}
.stTabs [data-baseweb="tab"] {
    color: var(--ink-muted) !important;
    font-size: 0.82rem !important;
    font-weight: 650 !important;
    padding: 8px 14px !important;
    border-radius: 6px !important;
    border: none !important;
    transition: all 0.2s ease !important;
}
.stTabs [aria-selected="true"] {
    background-color: var(--surface-2) !important;
    color: var(--accent) !important;
    font-weight: 750 !important;
    box-shadow: 0 1px 4px rgba(0,0,0,0.4) !important;
}
#MainMenu, footer, header { visibility: hidden; }

/* TEXT */
.stMarkdown p, .stMarkdown span, .stMarkdown li,
.stMarkdown h1, .stMarkdown h2, .stMarkdown h3, .stMarkdown h4, .stMarkdown h5 {
    color: var(--ink) !important;
}
.stTextInput > label > div > p,
.stSelectbox  > label > div > p {
    color: var(--ink) !important;
    font-weight: 600 !important;
}

/* INPUTS */
.stTextInput input {
    background: var(--surface-2) !important;
    border: 1px solid var(--border) !important;
    border-radius: var(--radius) !important;
    color: var(--ink) !important;
    padding: 0.5rem 0.85rem !important;
    transition: all 0.2s ease !important;
}
.stTextInput input:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 3px var(--accent-rim) !important;
    outline: none !important;
}

/* CODE BLOCKS (st.code) & PRE BLOCKS */
[data-testid="stCode"],
[data-testid="stCodeBlock"],
[data-testid="stCodeBlock"] > div,
.stCodeBlock,
.stCodeBlock pre,
pre,
[data-testid="stCode"] pre {
    background-color: #f8fafc !important;
    background: #f8fafc !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: var(--radius) !important;
    box-shadow: var(--shadow-sm) !important;
}
[data-testid="stCode"] code,
[data-testid="stCodeBlock"] code,
.stCodeBlock code,
pre code {
    font-family: var(--mono) !important;
    font-size: 0.86rem !important;
    line-height: 1.6 !important;
    color: #0f172a !important;
    background: transparent !important;
    background-color: transparent !important;
}

/* Light Theme Code Tokens inside st.code */
[data-testid="stCode"] span.token.keyword { color: #0000ff !important; font-weight: 700 !important; }
[data-testid="stCode"] span.token.string { color: #a31515 !important; }
[data-testid="stCode"] span.token.comment { color: #57606a !important; font-style: italic !important; }
[data-testid="stCode"] span.token.number { color: #098658 !important; }
[data-testid="stCode"] span.token.function { color: #795e26 !important; font-weight: 600 !important; }
[data-testid="stCode"] span.token.operator { color: #24292f !important; }
[data-testid="stCode"] span.token.punctuation { color: #24292f !important; }

/* Inline Code Pills */
code:not(pre code),
.stMarkdown code,
p code,
li code,
div code {
    background-color: #f1f5f9 !important;
    background: #f1f5f9 !important;
    color: #0284c7 !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 4px !important;
    padding: 2px 6px !important;
    font-size: 0.84rem !important;
    font-weight: 600 !important;
}

/* EXPANDER */
details {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: var(--radius) !important;
    margin-bottom: 10px !important;
    box-shadow: var(--shadow-sm) !important;
    transition: border-color 0.15s ease !important;
}
details:hover {
    border-color: var(--border-light) !important;
}
details > summary {
    background: var(--surface-2) !important;
    color: var(--ink) !important;
    padding: 10px 14px !important;
    border-radius: var(--radius) !important;
}
details > summary p { color: var(--ink) !important; font-weight: 600; margin: 0 !important; }

/* TABS */
[data-testid="stTabs"] { background: transparent !important; margin-bottom: 16px !important; }
[data-testid="stTabs"] [role="tab"] {
    color: var(--ink-muted) !important; font-weight: 600 !important;
    font-size: 0.92rem !important; padding: 8px 20px !important;
    border-radius: 6px 6px 0 0 !important;
    transition: all 0.15s ease !important;
}
[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    color: var(--accent) !important; border-bottom: 3px solid var(--accent) !important;
    background: transparent !important;
}
[data-testid="stTabs"] [role="tab"]:hover {
    color: var(--ink) !important; background: var(--surface-2) !important;
}

/* BUTTONS — LUMINOUS MODERN GRADIENTS */
button[data-testid="baseButton-primary"],
.stButton > button[kind="primary"],
[data-testid="stBaseButton-primary"] button,
button[kind="primary"] {
    background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
    color: #ffffff !important;
    font-weight: 650 !important;
    font-size: 0.9rem !important;
    border: 1px solid rgba(2, 132, 199, 0.4) !important;
    border-radius: var(--radius) !important;
    padding: 0.55rem 1.4rem !important;
    box-shadow: 0 2px 8px rgba(2, 132, 199, 0.25) !important;
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
}
button[data-testid="baseButton-primary"]:hover,
.stButton > button[kind="primary"]:hover,
[data-testid="stBaseButton-primary"] button:hover,
button[kind="primary"]:hover {
    background: linear-gradient(135deg, #0369a1 0%, #075985 100%) !important;
    box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35) !important;
    transform: translateY(-1px) !important;
}

button[data-testid="baseButton-secondary"],
.stButton > button[kind="secondary"],
[data-testid="stBaseButton-secondary"] button,
button[kind="secondary"] {
    background: #ffffff !important;
    color: var(--ink-2) !important;
    border: 1px solid var(--border-light) !important;
    border-radius: var(--radius) !important;
    font-weight: 550 !important;
    font-size: 0.88rem !important;
    padding: 0.55rem 1.2rem !important;
    box-shadow: var(--shadow-sm) !important;
    transition: all 0.15s ease !important;
}
button[data-testid="baseButton-secondary"]:hover,
.stButton > button[kind="secondary"]:hover,
[data-testid="stBaseButton-secondary"] button:hover,
button[kind="secondary"]:hover {
    background: var(--surface-2) !important;
    border-color: var(--accent) !important;
    color: var(--accent) !important;
    transform: translateY(-1px) !important;
}

[data-testid="stLinkButton"] a {
    background: #ffffff !important;
    color: var(--ink-2) !important;
    border: 1px solid var(--border-light) !important;
    border-radius: var(--radius) !important;
    font-weight: 600 !important;
    box-shadow: var(--shadow-sm) !important;
    transition: all 0.15s ease !important;
}
[data-testid="stLinkButton"] a:hover {
    background: var(--surface-2) !important;
    border-color: var(--accent) !important;
    color: var(--accent) !important;
}

/* METRICS & ALERTS */
[data-testid="stMetricValue"] { color: var(--ink) !important; font-weight: 850 !important; }
[data-testid="stMetricLabel"] > div > p { color: var(--ink-muted) !important; font-weight: 600 !important; }
[data-testid="stSpinner"] p { color: var(--ink-muted) !important; }
[data-testid="stAlert"] {
    background: #ffffff !important;
    border: 1px solid var(--border) !important;
    border-radius: var(--radius) !important;
    box-shadow: var(--shadow-sm) !important;
}
[data-testid="stAlert"] p { color: var(--ink) !important; }

/* FILE UPLOADER */
[data-testid="stFileUploadDropzone"] {
    background: #ffffff !important;
    border: 2px dashed #cbd5e1 !important;
    border-radius: var(--radius-lg) !important;
    padding: 24px 16px !important;
    transition: all 0.2s ease !important;
}
[data-testid="stFileUploadDropzone"]:hover {
    border-color: var(--accent) !important;
    background: var(--surface-2) !important;
}
[data-testid="stFileUploadDropzone"] * { color: var(--ink-muted) !important; }
[data-testid="stFileUploader"] [data-testid="stBaseButton-secondary"] button {
    background: #ffffff !important;
    color: var(--ink-2) !important;
    border-color: var(--border-light) !important;
}

/* CODE EDITOR TEXTAREA — in-place editor */
.stTextArea { margin-top: 0 !important; margin-bottom: 0 !important; }
.stTextArea > label { display: none !important; }
.stTextArea [data-baseweb="textarea"] { background: transparent !important; border: none !important; padding: 0 !important; }
.stTextArea textarea {
    font-family: var(--mono) !important;
    font-size: 0.88rem !important;
    line-height: 1.6 !important;
    background: #ffffff !important;
    color: #0f172a !important;
    border: 1px solid var(--border) !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    padding: 8px 18px 18px 14px !important;
    resize: vertical !important;
    outline: none !important;
    caret-color: var(--accent) !important;
}
.stTextArea textarea:focus {
    outline: none !important;
    box-shadow: none !important;
    border: 1px solid var(--accent) !important;
}

/* SIDEBAR */
section[data-testid="stSidebar"] {
    background: #ffffff !important;
    border-right: 1px solid var(--border) !important;
}
.sb-section-title {
    font-size: 0.68rem; font-weight: 700; text-transform: uppercase;
    letter-spacing: 1.8px; color: var(--accent);
    margin: 20px 0 10px 0; padding-bottom: 6px; border-bottom: 1px solid var(--border);
}
.sb-lang-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 6px; }
.sb-lang {
    background: var(--surface-2); border: 1px solid var(--border); border-radius: 6px;
    padding: 4px 10px; font-size: 0.78rem; font-weight: 550; color: var(--ink-2);
    display: flex; align-items: center; gap: 6px;
}
.sb-step-row { display: flex; align-items: center; gap: 9px; padding: 6px 0; font-size: 0.83rem; color: var(--ink-2); font-weight: 500; }
.sb-step-num {
    width: 20px; height: 20px; border-radius: 50%;
    background: var(--surface-2); border: 1px solid var(--border);
    color: var(--accent); font-size: 0.68rem; font-weight: 700;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.model-pill {
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 10px 14px; font-family: var(--mono); font-size: 0.78rem; color: var(--ink-2);
    word-break: break-all; display: flex; align-items: center; gap: 8px; margin: 6px 0 14px 0;
    box-shadow: var(--shadow-sm);
}
.model-pill .ti { color: var(--accent); font-size: 1rem; flex-shrink: 0; }

/* ─────────────────────────────────────────────────────
   LIGHT MODERN LANDING HERO BANNER
   ───────────────────────────────────────────────────── */
.cyber-landing-hero {
    background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 34px 38px 28px 38px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
    box-shadow: var(--shadow-md);
}
.cyber-landing-hero::before {
    content: '';
    position: absolute;
    inset: 0;
    background-image: 
        linear-gradient(to right, rgba(2, 132, 199, 0.04) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(2, 132, 199, 0.04) 1px, transparent 1px);
    background-size: 32px 32px;
    pointer-events: none;
    opacity: 0.7;
}
.cyber-landing-hero::after {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg, #0284c7 0%, #6366f1 50%, #059669 100%);
}
.hero-top-badge {
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(2, 132, 199, 0.08);
    border: 1px solid rgba(2, 132, 199, 0.25);
    border-radius: 99px;
    padding: 4px 14px;
    font-size: 0.72rem;
    font-weight: 750;
    color: var(--accent);
    letter-spacing: 1.2px;
    text-transform: uppercase;
    margin-bottom: 12px;
}
.badge-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #059669;
    box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.2);
}
.hero-title-text {
    position: relative;
    font-family: var(--font-title);
    font-size: 2.3rem;
    font-weight: 850;
    letter-spacing: -0.6px;
    background: linear-gradient(135deg, #0f172a 0%, #334155 45%, #0284c7 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 0 0 8px 0;
    line-height: 1.2;
}
.hero-phrase-main {
    position: relative;
    font-family: var(--font-title);
    font-size: 1.15rem;
    font-weight: 650;
    color: #0284c7;
    letter-spacing: 0.2px;
    margin-bottom: 8px;
}
.hero-phrase-sub {
    position: relative;
    font-size: 0.92rem;
    color: var(--ink-muted);
    font-weight: 450;
    line-height: 1.6;
    margin: 0 0 22px 0;
    max-width: 980px;
}
.hero-pills-grid {
    position: relative;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 10px;
}
.hero-pill {
    background: #ffffff;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 0.78rem;
    color: var(--ink-2);
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: var(--shadow-sm);
}

/* ─────────────────────────────────────────────────────
   WORKSPACE TOP BREADCRUMB (Clean & Distraction-Free)
   ───────────────────────────────────────────────────── */
.workspace-nav-bar {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 12px 18px;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    box-shadow: var(--shadow-sm);
}
.ws-brand-badge {
    font-size: 0.85rem;
    font-weight: 750;
    color: var(--ink);
    display: flex;
    align-items: center;
    gap: 6px;
}
.ws-file-chip {
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 3px 10px;
    font-family: var(--mono);
    font-size: 0.78rem;
    font-weight: 600;
    color: var(--accent);
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.ws-status-chip {
    font-size: 0.74rem;
    font-weight: 700;
    border-radius: 99px;
    padding: 3px 12px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.ws-status-audit {
    background: rgba(56, 189, 248, 0.12);
    border: 1px solid rgba(56, 189, 248, 0.35);
    color: var(--accent);
}
.ws-status-edit {
    background: rgba(245, 158, 11, 0.12);
    border: 1px solid rgba(245, 158, 11, 0.35);
    color: var(--warning);
}

/* WORKFLOW INDICATOR */
.workflow-bar {
    display: flex; align-items: stretch;
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); overflow: hidden;
    margin-bottom: 16px;
    box-shadow: var(--shadow-sm);
}
.wf-step {
    flex: 1; display: flex; align-items: center; justify-content: center;
    gap: 6px; padding: 10px 8px; font-size: 0.75rem; font-weight: 650;
    text-transform: uppercase; letter-spacing: 0.6px; color: var(--ink-faint);
    border-right: 1px solid var(--border); white-space: nowrap;
    transition: all 0.2s ease;
}
.wf-step:last-child { border-right: none; }
.wf-step.wf-done   { color: var(--accent); background: rgba(56, 189, 248, 0.08); }
.wf-step.wf-active { color: var(--ink); background: var(--surface-2); font-weight: 750; border-bottom: 3px solid var(--accent); }
.wf-step.wf-verify-done { color: var(--success); background: rgba(52, 211, 153, 0.08); border-bottom: 3px solid var(--success); }
.wf-step i { font-size: 0.9rem; }

/* METRIC CARDS — MODERN ELEVATED DARK */
.metric-card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 16px 18px; text-align: center;
    box-shadow: var(--shadow-sm);
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}
.metric-card:hover {
    border-color: var(--border-light);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}
.metric-value { font-size: 1.95rem; font-weight: 850; line-height: 1; color: var(--ink); font-family: var(--mono); }
.metric-label { font-size: 0.72rem; color: var(--ink-muted); text-transform: uppercase; letter-spacing: 1.2px; font-weight: 650; margin-top: 6px; }

/* FINDING CARDS */
.finding-card {
    border-radius: var(--radius); padding: 14px 18px; margin-bottom: 10px;
    background: var(--surface); border: 1px solid var(--border);
    border-left: 4px solid var(--border);
    box-shadow: var(--shadow-sm);
    transition: transform 0.15s ease;
}
.finding-card:hover {
    transform: translateX(2px);
}
.finding-HIGH   { border-left-color: var(--danger);  background: rgba(239, 68, 68, 0.08); }
.finding-MEDIUM { border-left-color: var(--warning); background: rgba(245, 158, 11, 0.08); }
.finding-LOW    { border-left-color: var(--accent);  background: rgba(56, 189, 248, 0.08); }
.finding-header { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1.2px; font-weight: 750; margin-bottom: 6px; display: flex; align-items: center; gap: 7px; }
.finding-msg  { font-size: 0.92rem; color: var(--ink-2); line-height: 1.55; }
.finding-line { font-size: 0.78rem; color: var(--ink-muted); margin-top: 6px; font-family: var(--mono); }

/* ─────────────────────────────────────────────────────
   CODE PANEL — CLEAN LIGHT IDE WORKSPACE
   ───────────────────────────────────────────────────── */
.code-panel {
    background: #ffffff;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: var(--shadow-sm);
}
.code-panel-bar {
    display: flex; align-items: center; justify-content: space-between;
    background: #f8fafc; border-bottom: 1px solid var(--border);
    padding: 8px 16px; font-size: 0.8rem; font-family: var(--mono); color: var(--ink-muted);
}
.code-panel-dots {
    display: flex; align-items: center; gap: 6px; margin-right: 10px;
}
.mac-dot {
    width: 10px; height: 10px; border-radius: 50%; display: inline-block;
}
.mac-dot.close { background: #ff5f56; }
.mac-dot.min   { background: #ffbd2e; }
.mac-dot.max   { background: #27c93f; }

.code-panel-lang {
    display: inline-flex; align-items: center; gap: 5px;
    background: rgba(2, 132, 199, 0.08); border: 1px solid rgba(2, 132, 199, 0.25);
    border-radius: 4px; padding: 2px 10px; font-size: 0.72rem; color: var(--accent);
    font-weight: 700; letter-spacing: 0.8px; text-transform: uppercase;
}
.hl-code-wrap {
    background: #ffffff; overflow: auto; max-height: 560px; margin: 0;
}
.hl-code-table {
    border-collapse: collapse; width: 100%; border-spacing: 0;
}
.hl-code-table tr,
.hl-code-table td { border-top: none !important; border-bottom: none !important; }

.hl-line-num {
    user-select: none; text-align: right; padding: 0 12px 0 8px;
    color: #64748b; font-size: 0.8rem; font-family: var(--mono);
    border-right: 1px solid var(--border); white-space: nowrap; vertical-align: top;
    min-width: 48px; background: #f8fafc;
    font-weight: 450; letter-spacing: 0; line-height: 1.6;
}
.hl-line-code {
    padding: 0 20px 0 14px; font-size: 0.875rem; font-family: var(--mono);
    line-height: 1.6; white-space: pre; color: #1e293b;
    vertical-align: top; width: 100%; font-weight: 400;
}
/* Highlighted rows */
tr.hl-HIGH   .hl-line-num,
tr.hl-HIGH   .hl-line-code { background: rgba(220, 38, 38, 0.08); }
tr.hl-HIGH   .hl-line-num  { border-left: 3px solid #dc2626; color: #dc2626; font-weight: 700; border-right-color: rgba(220, 38, 38, 0.25); }

tr.hl-MEDIUM .hl-line-num,
tr.hl-MEDIUM .hl-line-code { background: rgba(217, 119, 6, 0.08); }
tr.hl-MEDIUM .hl-line-num  { border-left: 3px solid #d97706; color: #d97706; font-weight: 700; border-right-color: rgba(217, 119, 6, 0.25); }

tr.hl-LOW    .hl-line-num,
tr.hl-LOW    .hl-line-code { background: rgba(2, 132, 199, 0.08); }
tr.hl-LOW    .hl-line-num  { border-left: 3px solid #0284c7; color: #0284c7; font-weight: 700; border-right-color: rgba(2, 132, 199, 0.25); }

/* Legend row inside panel bar */
.hl-legend {
    display: flex; gap: 14px; flex-wrap: wrap; font-size: 0.74rem;
    color: var(--ink-muted); align-items: center;
}
.hl-legend-item { display: flex; align-items: center; gap: 6px; font-weight: 600; }
.hl-dot { width: 8px; height: 8px; border-radius: 2px; flex-shrink: 0; }
.hl-dot-HIGH   { background: #dc2626; }
.hl-dot-MEDIUM { background: #d97706; }
.hl-dot-LOW    { background: #0284c7; }

/* TAGS */
.tag-container { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
.tag {
    background: var(--surface-2); border: 1px solid var(--border); color: var(--ink-2);
    border-radius: 4px; padding: 2px 8px; font-size: 0.74rem; font-family: var(--mono);
}
.tag.sink    { border-color: var(--danger); color: var(--danger); background: var(--danger-bg); }
.tag.none    { color: var(--ink-faint); }
.tag-HIGH   { background: var(--danger-bg);  color: var(--danger); border: 1px solid rgba(220,38,38,0.3); font-weight: 700; border-radius: 4px; padding: 2px 8px; font-size: 0.74rem; }
.tag-MEDIUM { background: var(--warning-bg); color: var(--warning); border: 1px solid rgba(217,119,6,0.3); font-weight: 700; border-radius: 4px; padding: 2px 8px; font-size: 0.74rem; }
.tag-LOW    { background: var(--accent-bg);  color: var(--accent); border: 1px solid rgba(2,132,199,0.3); font-weight: 700; border-radius: 4px; padding: 2px 8px; font-size: 0.74rem; }

/* STAGE HEADERS */
.stage-header {
    font-size: 0.98rem; font-weight: 750; color: var(--ink);
    padding: 10px 16px; margin: 18px 0 14px 0;
    background: var(--surface); border: 1px solid var(--border);
    border-left: 4px solid var(--accent);
    border-radius: 0 var(--radius) var(--radius) 0;
    display: flex; align-items: center; gap: 12px;
    box-shadow: var(--shadow-sm);
}
.stage-header i { color: var(--accent); font-size: 1.15rem; }
.stage-header .stage-num {
    background: var(--accent); color: #ffffff; border-radius: 50%;
    width: 22px; height: 22px; font-size: 0.72rem; font-weight: 800;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}

/* SECTION HEADER */
.section-header {
    font-size: 0.82rem; font-weight: 750; text-transform: uppercase; letter-spacing: 1.5px;
    color: var(--accent); padding: 0 0 8px 0; border-bottom: 1px solid var(--border);
    margin-bottom: 14px; display: flex; align-items: center; gap: 8px;
}

/* SUMMARY BOX */
.summary-box {
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 18px 22px; font-size: 0.92rem; line-height: 1.65;
    color: var(--ink-2); box-shadow: var(--shadow-sm);
}

/* GAUGE */
.gauge-container {
    background: var(--surface); border-radius: var(--radius); border: 1px solid var(--border);
    padding: 18px 20px; text-align: center; margin-bottom: 14px;
    box-shadow: var(--shadow-sm);
}
.gauge-label { font-size: 0.72rem; color: var(--ink-muted); text-transform: uppercase; letter-spacing: 1.5px; font-weight: 650; margin-bottom: 8px; }
.gauge-score { font-size: 3rem; font-weight: 900; line-height: 1; font-family: var(--mono); }
.gauge-score-denom { font-size: 1.15rem; color: var(--ink-faint); font-weight: 500; }
.gauge-bar-bg { background: var(--surface-2); border-radius: 99px; height: 9px; margin: 12px 0 6px 0; overflow: hidden; border: 1px solid var(--border); }
.gauge-bar-fill { height: 100%; border-radius: 99px; transition: width 0.3s ease; }
.gauge-range { font-size: 0.72rem; color: var(--ink-muted); font-weight: 500; }

/* BASELINE BANNER */
.baseline-banner {
    background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 12px 18px; margin-bottom: 16px;
    display: flex; align-items: center; gap: 12px; font-size: 0.86rem; color: var(--ink);
    box-shadow: var(--shadow-sm);
}
.baseline-banner i { color: var(--accent); font-size: 1.25rem; flex-shrink: 0; }
.baseline-banner strong { color: var(--accent); }

/* VERIFY STAGE */
.verif-status-row {
    display: flex; align-items: center; gap: 8px; margin-bottom: 8px; flex-wrap: wrap;
}
.verif-badge {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 4px 12px; border-radius: 6px; font-size: 0.76rem; font-weight: 700;
}
.verif-badge.resolved      { background: var(--success-bg); color: var(--success); border: 1px solid var(--success-rim); }
.verif-badge.still-present { background: var(--warning-bg); color: var(--warning); border: 1px solid rgba(245,158,11,0.35); }
.verif-badge.new-issue     { background: var(--danger-bg);  color: var(--danger); border: 1px solid rgba(239,68,68,0.35); }

/* PIPELINE STEPS */
.pipeline-step {
    display: flex; align-items: center; gap: 10px; padding: 10px 14px;
    background: var(--surface); border-radius: var(--radius); margin-bottom: 6px;
    font-size: 0.85rem; border: 1px solid var(--border); color: var(--ink);
    box-shadow: var(--shadow-sm);
}
.step-status { margin-left: auto; font-size: 0.72rem; font-weight: 600; display: flex; align-items: center; gap: 4px; }
.step-done .step-status { color: var(--success); }
.step-run  .step-status { color: var(--accent); }
.step-wait .step-status { color: var(--ink-faint); }

.ti     { vertical-align: -0.125em; }
.ti-lg  { font-size: 1.3rem; vertical-align: -0.2em; }
.ti-hero { font-size: 2rem; vertical-align: -0.25em; margin-right: 8px; }
.ti-step { font-size: 0.95rem; vertical-align: -0.12em; }
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════
# CACHED MODEL LOAD
# ═══════════════════════════════════════════════════
@st.cache_resource(show_spinner=False)
def load_inference_engine():
    return InferenceEngine()


# ═══════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════
def execute_full_reaudit(scan_code: str, active_name: str, language: str, inference) -> bool:
    """
    Executes a full multi-agent re-scan and intelligence pipeline on user-edited code.
    Updates all tabs (Summary, Vulnerabilities, Remediation & Teaching, Fix Verification)
    and synchronizes line findings with the code viewer.
    """
    orig_audit = st.session_state.get('original_audit')
    if not orig_audit and 'audit_results' in st.session_state:
        st.session_state['original_audit'] = {
            'source':     st.session_state.get('active_code', scan_code),
            'language':   language,
            'findings':   st.session_state['audit_results'].get('findings', []),
            'risk_score': st.session_state['audit_results'].get('risk_score', 0.0),
        }
        orig_audit = st.session_state['original_audit']

    if not orig_audit:
        st.error("Baseline audit missing. Please run initial audit first.")
        return False

    with st.spinner("Re-auditing updated code across multi-agent pipeline..."):
        ext = os.path.splitext(active_name)[1].lower() or '.py'
        with tempfile.NamedTemporaryFile(delete=False, suffix=ext, mode='w', encoding='utf-8') as tmp:
            tmp.write(scan_code)
            tmp_path = tmp.name

        fresh = {}
        try:
            with measure_energy(sample_interval_s=0.2) as col:
                col.begin_phase("Guardrail & AST")
                from src.security_guardrail import SecurityGuardrailAgent
                guard = SecurityGuardrailAgent()
                guard_report = guard.inspect_and_defang(scan_code)
                fresh['guard_report'] = guard_report

                ast_parser        = ASTParser()
                feature_extractor = FeatureExtractor()
                tree     = ast_parser.parse(scan_code, language)
                features = feature_extractor.extract_features(tree, scan_code, language)
                features['lang']       = language
                features['line_count'] = scan_code.count('\n') + 1
                fresh['features'] = features
                col.end_phase()

                col.begin_phase("Semgrep Scan")
                scanner = Scanner()
                findings, risk_score = scanner.scan_file(tmp_path)
                fresh['findings']   = findings
                fresh['risk_score'] = risk_score
                col.end_phase()

                col.begin_phase("Prompt Engine")
                enricher = PromptEnricher()
                prompt   = enricher.construct_prompt(findings, features, scan_code)
                col.end_phase()

                col.begin_phase("CodeT5 Gen")
                summary = inference.generate_summary(prompt)
                summary = PromptEnricher.enrich_summary(summary, features)
                fresh['summary'] = summary
                col.end_phase()

            reports_dir = os.path.join(os.path.dirname(__file__), "frontend", "public", "reports")
            os.makedirs(reports_dir, exist_ok=True)
            with open(os.path.join(reports_dir, "latest_report.json"), "w") as f:
                json.dump(col.report.to_dict(), f)

        except Exception as e:
            st.error(f"Re-audit error: {e}")
            return False
        finally:
            try: os.unlink(tmp_path)
            except Exception: pass

        from src.agent_tools import match_findings
        verif_result = match_findings(orig_audit.get('findings', []), fresh['findings'])
        verif_result['verification_risk_score'] = fresh['risk_score']

        st.session_state['audit_results']       = fresh
        st.session_state['verification_result'] = verif_result
        st.session_state['current_findings']   = fresh['findings']
        st.session_state['editor_code']        = scan_code
        st.session_state['active_code']        = scan_code
        st.session_state['code_editor_area']   = scan_code
        return True


def risk_color(score: float) -> str:
    if score >= 8: return "var(--danger)"
    if score >= 5: return "var(--warning)"
    if score >= 2: return "var(--accent)"
    return "var(--ink-muted)"

def risk_label(score: float) -> str:
    if score >= 8:  return "CRITICAL"
    if score >= 5:  return "HIGH"
    if score >= 2:  return "MEDIUM"
    return "LOW"

def sev_color(sev: str) -> str:
    return {"HIGH": "var(--danger)", "MEDIUM": "var(--warning)", "LOW": "var(--accent)"}.get(sev, "var(--ink-muted)")

def severity_icon_html(sev: str) -> str:
    icons = {
        "HIGH":   '<i class="ti ti-circle-x"></i>',
        "MEDIUM": '<i class="ti ti-alert-triangle"></i>',
        "LOW":    '<i class="ti ti-info-circle"></i>',
    }
    return icons.get(sev.upper(), '<i class="ti ti-circle"></i>')


def render_diff_code(code: str, language: str = "python", is_dark: bool = True) -> str:
    """
    Syntax highlights code snippets for Before/After remediation blocks using Pygments.
    Preserves exact formatting and tokens for Python, JavaScript, Java, and C.
    """
    from pygments import highlight
    from pygments.lexers import get_lexer_by_name, PythonLexer
    from pygments.formatters import HtmlFormatter
    try:
        lang_key = (language or 'python').lower()
        if lang_key in ('py', 'python', 'python3'):
            lexer = PythonLexer()
        else:
            lexer = get_lexer_by_name(lang_key)
    except Exception:
        lexer = PythonLexer()

    formatter = HtmlFormatter(nowrap=True)
    try:
        highlighted = highlight(code.rstrip('\r\n'), lexer, formatter)
    except Exception:
        highlighted = html_mod.escape(code.rstrip('\r\n'))
    return highlighted


def render_gauge(score: float, title: str = "Baseline Risk Score"):
    color = risk_color(score)
    label = risk_label(score)
    pct   = int((score / 10.0) * 100)
    st.markdown(f"""
    <div class="gauge-container" style="background:var(--st-card-header, #f8fafc);border:1px solid var(--st-border, #e2e8f0);padding:10px 14px;margin-bottom:6px;border-radius:8px;">
        <div class="gauge-label" style="font-size:0.68rem;margin-bottom:2px;color:var(--st-text-muted, #64748b);"><i class="ti ti-shield-half-filled" style="margin-right:5px;"></i>{title}</div>
        <div class="gauge-score" style="font-size:2rem;line-height:1.1;color:{color};">{score}<span class="gauge-score-denom" style="font-size:0.95rem;color:var(--st-text-muted, #94a3b8);">/10</span></div>
        <div style="font-size:0.75rem;font-weight:700;letter-spacing:1px;color:{color};margin-top:2px;">{label}</div>
        <div class="gauge-bar-bg" style="height:6px;margin:6px 0 3px 0;background:var(--st-border, #e2e8f0);border-radius:3px;overflow:hidden;">
            <div class="gauge-bar-fill" style="width:{pct}%;background-color:{color};height:100%;border-radius:3px;"></div>
        </div>
        <div class="gauge-range" style="font-size:0.68rem;color:var(--st-text-muted, #94a3b8);">0 &mdash; Safe &nbsp;&nbsp;&nbsp; 10 &mdash; Critical</div>
    </div>""", unsafe_allow_html=True)


def render_finding(f: dict):
    from src.vuln_classifier import normalize_severity
    sev   = normalize_severity(f.get('severity', 'INFO')).upper()
    msg   = f.get('message', '')
    line  = f.get('line', '?')
    icon  = severity_icon_html(sev)
    hdr_color = sev_color(sev)
    st.markdown(f"""
    <div class="finding-card finding-{sev}" style="background:var(--st-card, #ffffff);border:1px solid var(--st-border, #e2e8f0);border-left:3px solid {hdr_color};border-radius:6px;padding:10px 14px;margin-bottom:8px;box-shadow:var(--shadow-sm);">
        <div class="finding-header" style="display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--st-border, #f1f5f9);padding-bottom:5px;margin-bottom:6px;">
            <span style="color:{hdr_color};display:inline-flex;align-items:center;gap:6px;font-weight:700;font-size:0.78rem;">{icon} {sev} VULNERABILITY</span>
            <span class="lc-tag" style="font-size:0.7rem;"><i class="ti ti-code"></i> Line {line}</span>
        </div>
        <div class="finding-msg" style="font-size:0.86rem;color:var(--st-text-secondary, #334155);line-height:1.5;">{msg}</div>
    </div>""", unsafe_allow_html=True)


def render_tags(items: list, kind: str = "source"):
    if not items:
        st.markdown('<div class="tag-container"><span class="tag none">none detected</span></div>', unsafe_allow_html=True)
        return
    tags_html = "".join(f'<span class="tag {kind}">{x}</span>' for x in set(items))
    st.markdown(f'<div class="tag-container">{tags_html}</div>', unsafe_allow_html=True)


def render_workflow(stage: str):
    """Render the workflow progress bar. stage: analyze|understand|learn|edit|verify|verified"""
    stages = [
        ("ti-upload",       "1. Analyze"),
        ("ti-book",         "2. Understand"),
        ("ti-school",       "3. Learn"),
        ("ti-pencil",       "4. Edit Code"),
        ("ti-pencil-check", "5. Verify Fix"),
    ]
    stage_map = {
        "analyze": 0, "understand": 1, "learn": 2,
        "edit": 3, "verify": 4, "verified": 4,
    }
    active_idx = stage_map.get(stage, 0)
    html = '<div class="workflow-bar">'
    for idx, (icon, name) in enumerate(stages):
        if idx < active_idx:
            cls    = "wf-step wf-done"
            prefix = '<i class="ti ti-circle-check"></i>'
        elif idx == active_idx:
            if stage == "verified":
                cls    = "wf-step wf-verify-done"
                prefix = '<i class="ti ti-circle-check"></i>'
            else:
                cls    = "wf-step wf-active"
                prefix = f'<i class="ti {icon}"></i>'
        else:
            cls    = "wf-step"
            prefix = f'<i class="ti {icon}"></i>'
        html += f'<div class="{cls}">{prefix} {name}</div>'
    html += '</div>'
    st.markdown(html, unsafe_allow_html=True)


def render_stage_header(num: int, icon: str, title: str, subtitle: str = ""):
    sub_html = f'<div style="font-size:0.82rem;font-weight:400;color:var(--ink-muted);margin-top:2px;">{subtitle}</div>' if subtitle else ""
    st.markdown(f"""
    <div class="stage-header">
        <div class="stage-num">{num}</div>
        <i class="ti {icon}"></i>
        <div>
            <div>{title}</div>
            {sub_html}
        </div>
    </div>""", unsafe_allow_html=True)


def render_highlighted_code(code: str, findings: list, language: str = ""):
    """
    Render source code as an HTML table with LeetCode/VSCode syntax highlighting
    and per-line security severity highlighting.
    """
    from src.vuln_classifier import normalize_severity
    from pygments import highlight
    from pygments.lexers import get_lexer_by_name, PythonLexer
    from pygments.formatters import HtmlFormatter

    line_sev: dict[int, str] = {}
    sev_order = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    for f in findings:
        try:
            ln = int(f.get('line', 0))
        except (ValueError, TypeError):
            continue
        s = normalize_severity(f.get('severity', 'INFO')).upper()
        if ln not in line_sev or sev_order.get(s, 0) > sev_order.get(line_sev[ln], 0):
            line_sev[ln] = s

    has_high   = any(v == "HIGH"   for v in line_sev.values())
    has_medium = any(v == "MEDIUM" for v in line_sev.values())
    has_low    = any(v == "LOW"    for v in line_sev.values())

    legend_items = []
    if has_high:
        legend_items.append('<div class="hl-legend-item"><div class="hl-dot hl-dot-HIGH"></div><span>High Severity</span></div>')
    if has_medium:
        legend_items.append('<div class="hl-legend-item"><div class="hl-dot hl-dot-MEDIUM"></div><span>Medium Severity</span></div>')
    if has_low:
        legend_items.append('<div class="hl-legend-item"><div class="hl-dot hl-dot-LOW"></div><span>Low Severity</span></div>')
    if legend_items:
        legend_items.append('<div class="hl-legend-item" style="margin-left:auto;font-style:italic;">Highlighted lines contain detected security issues</div>')

    legend_html = f'<div class="hl-legend">{"".join(legend_items)}</div>' if legend_items else ""

    # Pygments syntax highlighting matching LeetCode / VS Code Dark theme
    try:
        lang_key = (language or 'python').lower()
        if lang_key in ('py', 'python', 'python3'):
            lexer = PythonLexer()
        else:
            lexer = get_lexer_by_name(lang_key)
    except Exception:
        lexer = PythonLexer()

    formatter = HtmlFormatter(nowrap=True)
    try:
        highlighted_code = highlight(code, lexer, formatter)
        highlighted_lines = highlighted_code.split('\n')
    except Exception:
        highlighted_lines = [html_mod.escape(l) for l in code.split('\n')]

    code_lines = code.split('\n')
    rows = []
    for i, line in enumerate(code_lines, 1):
        sev = line_sev.get(i, '')
        row_cls  = f'hl-{sev}' if sev else ''
        sev_icon = ''
        if sev == 'HIGH':
            sev_icon = ' ●'
        elif sev == 'MEDIUM':
            sev_icon = ' ◆'
        elif sev == 'LOW':
            sev_icon = ' ▸'
        
        hl_code = highlighted_lines[i - 1] if i - 1 < len(highlighted_lines) else html_mod.escape(line)
        if not hl_code.strip():
            hl_code = '&nbsp;'

        rows.append(
            f'<tr class="{row_cls}">'
            f'<td class="hl-line-num">{i}{sev_icon}</td>'
            f'<td class="hl-line-code">{hl_code}</td>'
            f'</tr>'
        )

    # Legend chips for the IDE tab-bar
    legend_chips = ""
    if has_high:
        legend_chips += '<span style="display:inline-flex;align-items:center;gap:3px;background:var(--danger-bg);border:1px solid rgba(220,38,38,0.3);border-radius:4px;padding:2px 8px;font-size:0.71rem;color:var(--danger);font-weight:700;">● HIGH</span>'
    if has_medium:
        legend_chips += '<span style="display:inline-flex;align-items:center;gap:3px;background:var(--warning-bg);border:1px solid rgba(217,119,6,0.3);border-radius:4px;padding:2px 8px;font-size:0.71rem;color:var(--warning);font-weight:700;">◆ MEDIUM</span>'
    if has_low:
        legend_chips += '<span style="display:inline-flex;align-items:center;gap:3px;background:var(--accent-bg);border:1px solid rgba(37,99,235,0.3);border-radius:4px;padding:2px 8px;font-size:0.71rem;color:var(--accent);font-weight:700;">▸ LOW</span>'
    lang_display = language.upper() if language else "CODE"
    total_vuln = len(line_sev)
    vuln_chip = (
        f'<span style="font-size:0.72rem;color:var(--ink-faint);">{total_vuln} issue{"s" if total_vuln != 1 else ""} flagged</span>'
        if total_vuln > 0 else '<span style="font-size:0.72rem;color:var(--success);font-weight:600;">✓ Clean (No issues flagged)</span>'
    )

    table_html = (
        f'<style>'
        f'.hl-code-table {{ font-family: var(--mono) !important; font-size: 0.86rem !important; line-height: 1.6 !important; background: #ffffff !important; }}'
        f'.hl-code-table .k, .hl-code-table .kn, .hl-code-table .kd, .hl-code-table .kp, .hl-code-table .kr {{ color: #0000ff !important; font-weight: 600 !important; }}'
        f'.hl-code-table .nc, .hl-code-table .nn {{ color: #0550ae !important; font-weight: 600 !important; }}'
        f'.hl-code-table .nf, .hl-code-table .fm {{ color: #795e26 !important; }}'
        f'.hl-code-table .bp {{ color: #0000ff !important; font-style: italic !important; }}'
        f'.hl-code-table .nb {{ color: #0550ae !important; }}'
        f'.hl-code-table .s, .hl-code-table .s1, .hl-code-table .s2, .hl-code-table .sa, .hl-code-table .sb, .hl-code-table .sc, .hl-code-table .sd, .hl-code-table .se, .hl-code-table .sh, .hl-code-table .si, .hl-code-table .sx, .hl-code-table .sr, .hl-code-table .ss {{ color: #a31515 !important; }}'
        f'.hl-code-table .m, .hl-code-table .mi, .hl-code-table .mf, .hl-code-table .mh, .hl-code-table .mo {{ color: #098658 !important; }}'
        f'.hl-code-table .c, .hl-code-table .c1, .hl-code-table .ch, .hl-code-table .cm, .hl-code-table .cp, .hl-code-table .cpf, .hl-code-table .cs {{ color: #57606a !important; font-style: italic !important; }}'
        f'.hl-code-table .o, .hl-code-table .ow {{ color: #24292f !important; }}'
        f'.hl-code-table .p {{ color: #24292f !important; }}'
        f'.hl-code-table .n, .hl-code-table .na, .hl-code-table .nv {{ color: #1f2328 !important; }}'
        f'</style>'
        f'<div class="code-panel">'
        f'<div class="code-panel-bar">'
        f'<div style="display:flex;align-items:center;gap:10px;">'
        f'<span style="font-weight:700;color:#0f172a;font-size:0.82rem;display:inline-flex;align-items:center;gap:6px;"><i class="ti ti-code" style="color:var(--accent);"></i> Code</span>'
        f'<span class="code-panel-lang" style="background:rgba(2,132,199,0.08);border:1px solid rgba(2,132,199,0.25);color:var(--accent);">{lang_display}</span>'
        f'<span style="color:#64748b;font-size:0.75rem;font-weight:500;">{len(code_lines)} lines</span>'
        f'</div>'
        f'<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">{legend_chips}&nbsp;{vuln_chip}</div>'
        f'</div>'
        f'<div class="hl-code-wrap">'
        f'<table class="hl-code-table"><tbody>{"".join(rows)}</tbody></table>'
        f'</div>'
        f'</div>'
    )
    st.markdown(table_html, unsafe_allow_html=True)



# ═══════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════
with st.sidebar:
    st.markdown("""
    <div style="font-size:1.1rem;font-weight:800;color:var(--ink);display:flex;align-items:center;gap:8px;padding-bottom:12px;border-bottom:1px solid var(--border);">
        <i class="ti ti-shield-code" style="color:var(--accent);font-size:1.3rem;"></i> SecureLearn
    </div>

    <div class="sb-section-title">Supported Languages</div>
    <div class="sb-lang-row">
        <span class="sb-lang"><i class="ti ti-brand-python" style="color:var(--accent);"></i> Python</span>
        <span class="sb-lang"><i class="ti ti-coffee" style="color:var(--accent);"></i> Java</span>
        <span class="sb-lang"><i class="ti ti-brand-javascript" style="color:var(--accent);"></i> JS</span>
        <span class="sb-lang"><i class="ti ti-letter-c" style="color:var(--accent);"></i> C</span>
    </div>

    <div class="sb-section-title">Workflow Stages</div>
    <div class="sb-step-row"><span class="sb-step-num">1</span><i class="ti ti-upload" style="color:var(--accent);"></i> Upload &amp; Analyze</div>
    <div class="sb-step-row"><span class="sb-step-num">2</span><i class="ti ti-book" style="color:var(--accent);"></i> Understand Code &amp; Risks</div>
    <div class="sb-step-row"><span class="sb-step-num">3</span><i class="ti ti-school" style="color:var(--accent);"></i> Learn Security Concepts</div>
    <div class="sb-step-row"><span class="sb-step-num">4</span><i class="ti ti-pencil" style="color:var(--accent);"></i> Edit Code In-Browser</div>
    <div class="sb-step-row"><span class="sb-step-num">5</span><i class="ti ti-pencil-check" style="color:var(--accent);"></i> Re-Audit &amp; Verify Fix</div>

    <div class="sb-section-title">AI &amp; Scanner Engines</div>
    """, unsafe_allow_html=True)

    has_active_gemini = bool(os.getenv("GEMINI_API_KEY", "").strip())
    if has_active_gemini:
        st.markdown("""
        <div class="model-pill" style="border-left:3px solid #1a7f37;background:#dafbe1;color:#1a7f37;">
            <i class="ti ti-sparkles" style="color:#1a7f37;"></i>Agent: Gemini Flash
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="model-pill">
            <i class="ti ti-brain"></i>Local: CodeT5-base-multi-sum
        </div>
        """, unsafe_allow_html=True)

    with st.expander("🔑 Gemini Key (Optional)", expanded=False):
        gemini_input = st.text_input(
            "Gemini API Key",
            value=os.getenv("GEMINI_API_KEY", ""),
            type="password",
            placeholder="AIzaSy...",
            label_visibility="collapsed",
            help="Leave blank to run local CodeT5 fallback. Paste free Google AI Studio key to unlock Gemini 2.0 Flash."
        )
        if gemini_input:
            os.environ["GEMINI_API_KEY"] = gemini_input.strip()

    st.markdown("""
    <div style="font-size:0.83rem;color:var(--ink-2);display:flex;align-items:center;gap:6px;margin:6px 0 4px 0;">
        <i class="ti ti-shield-check" style="color:var(--accent);"></i> Semgrep + AST/Regex Fallback
    </div>
    <div style="font-size:0.83rem;color:#1a7f37;display:flex;align-items:center;gap:6px;margin:4px 0 4px 0;font-weight:600;">
        <i class="ti ti-shield-lock" style="color:#1a7f37;"></i> Guardrail: SecurityGuardrailAgent
    </div>
    <div style="font-size:0.83rem;color:var(--ink-2);display:flex;align-items:center;gap:6px;margin:4px 0 4px 0;">
        <i class="ti ti-tool" style="color:#1a7f37;"></i> Local Agent: FixTemplateAgent
    </div>
    <div style="font-size:0.83rem;color:var(--ink-2);display:flex;align-items:center;gap:6px;margin:4px 0 12px 0;">
        <i class="ti ti-hierarchy" style="color:#0969da;"></i> Local Agent: AnalysisOrchestratorAgent
    </div>

    <div style="margin-top:20px; margin-bottom: 10px;">
        <div class="sb-section-title">Visualization</div>
    </div>
    """, unsafe_allow_html=True)

    st.link_button("View Advanced Analytics (React Frontend)", "http://localhost:5173", use_container_width=True)

    st.markdown("""
    <div style="margin-top:24px;padding-top:16px;border-top:1px solid var(--border);font-size:0.75rem;color:var(--ink-muted);text-align:center;">
        <i class="ti ti-lock" style="margin-right:4px;"></i> SecureLearn v2.0
    </div>
    """, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════
# ═══════════════════════════════════════════════════
# HERO / WORKSPACE NAV PLACEHOLDER & ACTIVE FILE STATE
# ═══════════════════════════════════════════════════
if 'active_code' not in st.session_state:
    st.session_state['active_code'] = None
    st.session_state['active_file_name'] = None
    st.session_state['active_language'] = None

active_code = st.session_state.get('active_code')
active_file_name = st.session_state.get('active_file_name')
active_lang = st.session_state.get('active_language')

top_header_placeholder = st.empty()

def open_file_in_studio(file_path: str, fallback_name: str = "source_code.py", fallback_lang: str = "python"):
    code_content = ""
    base = os.path.basename(file_path) if file_path else fallback_name

    # 1. First check if the file genuinely exists on disk
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code_content = f.read()
        except Exception as e:
            code_content = f"# Error reading file {file_path}: {e}"
    else:
        # 2. Check in project directories (tests, src, etc.)
        possible_paths = [
            os.path.join(os.path.dirname(__file__), '..', 'tests', base),
            os.path.join(os.path.dirname(__file__), '..', 'src', base),
            os.path.join(os.path.dirname(__file__), '..', base),
        ]
        for p in possible_paths:
            if os.path.exists(p):
                try:
                    with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                        code_content = f.read()
                    break
                except Exception:
                    pass

    # 3. If still empty, provide rich demo code tailored for demo files or generic files
    if not code_content:
        if base == 'db.js':
            code_content = """const { Pool } = require('pg');
require('dotenv').config();

// Connect to a PostgreSQL database
const pool = new Pool({
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'ecommerce_db',
    password: process.env.DB_PASSWORD || 'secret123',
    port: parseInt(process.env.DB_PORT || '5432'),
});

async function findUserById(userId) {
    // SECURITY RISK: Direct SQL string concatenation (SQL Injection)
    const sqlQuery = "SELECT id, username, email, role FROM users WHERE id = '" + userId + "'";
    const client = await pool.connect();
    try {
        const result = await client.query(sqlQuery);
        return result.rows[0];
    } finally {
        client.release();
    }
}

async function updateUserRole(userId, newRole) {
    // SECURITY RISK: Dynamic query execution
    const rawSql = `UPDATE users SET role = '${newRole}' WHERE id = '${userId}'`;
    return pool.query(rawSql);
}

module.exports = { pool, findUserById, updateUserRole };
"""
        elif base == 'pool.js':
            code_content = """const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://app_user:default_pass@localhost:5432/app',
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

pool.on('error', (err, client) => {
    console.error('Unexpected error on idle client', err);
    process.exit(-1);
});

module.exports = pool;
"""
        elif base in ('auth.js', 'passport.js'):
            code_content = """const jwt = require('jsonwebtoken');

// HARDCODED SECRET: Insecure key usage
const JWT_SECRET = 'hardcoded_jwt_secret_token_12345';

function verifyAuthToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) {
        return res.status(401).json({ error: 'Access denied. No token provided.' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token.' });
        }
        req.user = user;
        next();
    });
}

module.exports = { verifyAuthToken };
"""
        elif base == 'index.js':
            code_content = """const express = require('express');
const app = express();
const db = require('./db/pool');

app.use(express.json());

app.get('/api/users/:id', async (req, res) => {
    const userId = req.params.id;
    // Vulnerability: Concatenation into SQL command
    const query = 'SELECT * FROM users WHERE id = ' + userId;
    try {
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
"""
        elif base.endswith('.py'):
            code_content = f"""import os
import sqlite3

# Audited Target: {base}
def get_user_records(user_input):
    conn = sqlite3.connect("production.db")
    cursor = conn.cursor()
    # SQL injection vulnerability
    query = f"SELECT id, name, email FROM accounts WHERE username = '{{user_input}}'"
    cursor.execute(query)
    records = cursor.fetchall()
    conn.close()
    return records

if __name__ == '__main__':
    data = get_user_records("admin' OR '1'='1")
    print("Retrieved records:", len(data))
"""
        else:
            code_content = f"""// Source Code for: {base}
// Directory Audit Target

const express = require('express');
const router = express.Router();

router.get('/data', async (req, res) => {{
    const searchFilter = req.query.filter;
    // Direct concatenation query
    const sql = "SELECT * FROM entities WHERE name LIKE '%" + searchFilter + "%'";
    console.log("Executing query:", sql);
    res.json({{ status: "success", filter: searchFilter }});
}});

module.exports = router;
"""

    fname = base if base else fallback_name
    ext = os.path.splitext(fname)[1].lower()
    l_map = {'.py': 'python', '.java': 'java', '.js': 'javascript', '.c': 'c', '.cpp': 'c', '.jsx': 'javascript', '.ts': 'javascript'}
    lang = l_map.get(ext, fallback_lang or 'python')

    st.session_state['active_code'] = code_content
    st.session_state['active_file_name'] = fname
    st.session_state['active_language'] = lang
    st.session_state.pop('audit_results', None)
    st.session_state.pop('initial_audit_results', None)
    st.session_state.pop('original_audit', None)
    st.session_state.pop('verification_result', None)
    st.session_state.pop('editor_code', None)
    st.session_state.pop('code_editor_area', None)
    st.session_state.pop('current_findings', None)
    st.session_state.pop('edit_mode', None)
    st.session_state.pop('active_view', None)
    st.rerun()

# ═══════════════════════════════════════════════════
# TABS + INPUTS (SHOWN WHEN NO ACTIVE FILE IN STUDIO)
# ═══════════════════════════════════════════════════
uploaded_file = None
dir_path_input = ""
uploaded_dir_files = None
run_btn        = False
demo_btn       = False

if not active_code:
    top_header_placeholder.markdown("""
    <div class="cyber-landing-hero">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:24px;">
            <div style="flex:1;min-width:320px;">
                <div class="hero-top-badge">
                    <span class="badge-dot"></span>
                    <span>ENTERPRISE CODE SECURITY &middot; AUTONOMOUS MULTI-AGENT DEFENSE</span>
                </div>
                <h1 class="hero-title-text" style="text-transform: uppercase;">
                    NLP-BASED CODE SUMMARIZER WITH SECURITY AUDITS
                </h1>
                <div class="hero-phrase-main" style="font-size:1.18rem;font-weight:600;margin-bottom:20px;letter-spacing:0.3px;">
                    AI-Powered Code Understanding, Real-Time Vulnerability Auditing &amp; Autonomous AST Remediation
                </div>
                <div class="hero-pills-grid">
                    <div class="hero-pill"><i class="ti ti-shield-lock" style="color:var(--accent);font-size:1.05rem;"></i> <div><b>Perimeter Defense:</b> Nonce Sandboxing</div></div>
                    <div class="hero-pill"><i class="ti ti-binary-tree" style="color:var(--success);font-size:1.05rem;"></i> <div><b>AST Semantic Parsing:</b> Tree-sitter + Gemini Flash</div></div>
                    <div class="hero-pill"><i class="ti ti-route-2" style="color:var(--warning);font-size:1.05rem;"></i> <div><b>Taint Reachability:</b> Alert Fatigue Suppression</div></div>
                    <div class="hero-pill"><i class="ti ti-wand" style="color:#a78bfa;font-size:1.05rem;"></i> <div><b>Auto-Remediation:</b> Context-Aware 1-Click Fixes</div></div>
                </div>
            </div>
            <div style="display:flex;align-items:center;justify-content:center;min-width:200px;">
                <svg width="210" height="210" viewBox="0 0 240 240" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 0 25px rgba(56, 189, 248, 0.35));">
                    <defs>
                        <linearGradient id="shieldGrad" x1="20" y1="20" x2="220" y2="220" gradientUnits="userSpaceOnUse">
                            <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.9"/>
                            <stop offset="50%" stop-color="#2563eb" stop-opacity="0.6"/>
                            <stop offset="100%" stop-color="#818cf8" stop-opacity="0.25"/>
                        </linearGradient>
                        <linearGradient id="coreGlow" x1="120" y1="80" x2="120" y2="160" gradientUnits="userSpaceOnUse">
                            <stop offset="0%" stop-color="#38bdf8"/>
                            <stop offset="100%" stop-color="#34d399"/>
                        </linearGradient>
                    </defs>
                    <circle cx="120" cy="120" r="105" stroke="#1f293d" stroke-width="2" stroke-dasharray="4 8"/>
                    <circle cx="120" cy="120" r="88" stroke="rgba(56, 189, 248, 0.25)" stroke-width="1.5" stroke-dasharray="8 6"/>
                    <path d="M120 30L190 62V124C190 170 160 205 120 218C80 205 50 170 50 124V62L120 30Z" fill="url(#shieldGrad)" stroke="#38bdf8" stroke-width="2.5"/>
                    <path d="M120 48L174 72V122C174 158 151 187 120 198C89 187 66 158 66 122V72L120 48Z" fill="#0b1329" stroke="rgba(56, 189, 248, 0.45)" stroke-width="1.5"/>
                    <path d="M95 110V98C95 84.2 106.2 73 120 73C133.8 73 145 84.2 145 98V110" stroke="url(#coreGlow)" stroke-width="4" stroke-linecap="round"/>
                    <rect x="90" y="110" width="60" height="46" rx="8" fill="url(#coreGlow)"/>
                    <circle cx="120" cy="130" r="5" fill="#090d16"/>
                    <path d="M120 135V144" stroke="#090d16" stroke-width="3" stroke-linecap="round"/>
                    <circle cx="50" cy="62" r="4" fill="#38bdf8"/>
                    <circle cx="190" cy="62" r="4" fill="#818cf8"/>
                    <circle cx="120" cy="30" r="5" fill="#34d399"/>
                    <circle cx="120" cy="218" r="4" fill="#38bdf8"/>
                </svg>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    cards = [
        ("ti-shield-lock",   "Perimeter Defense",   "SecurityGuardrailAgent", "Dynamic threat neutralization, Unicode canonicalization, and cryptographic nonce isolation preventing prompt injection jailbreaks."),
        ("ti-binary-tree",   "Semantic Intel",      "Tree-sitter + Gemini",   "Multi-pass AST parsing and Gemini Flash deep reasoning mapping system architecture and contracts."),
        ("ti-route-2",       "Taint Dataflow",      "TaintReachabilityEngine","Source-to-sink variable tracing eliminating false-positive alert fatigue from static constants."),
        ("ti-tools",         "1-Click Remediation", "FixTemplateAgent",       "Context-aware AST-verified patches with 1-click in-browser patch applicator and re-audit verification."),
    ]
    for col, (icon, title, agent, desc) in zip([c1, c2, c3, c4], cards):
        with col:
            st.markdown(f"""
            <div class="metric-card" style="text-align:left;padding:22px 18px;min-height:200px;display:flex;flex-direction:column;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                    <span style="width:38px;height:38px;border-radius:8px;background:var(--accent-bg);display:inline-flex;align-items:center;justify-content:center;">
                        <i class="ti {icon}" style="font-size:1.3rem;color:var(--accent);"></i>
                    </span>
                    <span style="font-size:0.7rem;font-weight:700;color:var(--accent);background:var(--accent-bg);padding:2px 8px;border-radius:20px;">{agent}</span>
                </div>
                <div style="font-weight:750;font-size:1.02rem;color:var(--ink);margin-bottom:8px;">{title}</div>
                <div style="font-size:0.83rem;color:var(--ink-muted);line-height:1.55;flex-grow:1;">{desc}</div>
            </div>""", unsafe_allow_html=True)

    st.markdown("<div style='height:16px;'></div>", unsafe_allow_html=True)

    tab_file, tab_dir = st.tabs(["⚡ Single File Audit", "📁 Directory Bulk Scan"])

    with tab_file:
        uploaded_file = st.file_uploader(
            "Drop a source file to begin single file audit",
            type=['py', 'java', 'c', 'js'],
            help="Supported: Python (.py), Java (.java), JavaScript (.js), C (.c)"
        )
        if uploaded_file is not None:
            c_content = uploaded_file.getvalue().decode("utf-8", errors="ignore")
            f_ext = os.path.splitext(uploaded_file.name)[1].lower()
            l_map = {'.py': 'python', '.java': 'java', '.js': 'javascript', '.c': 'c'}
            st.session_state['active_code'] = c_content
            st.session_state['active_file_name'] = uploaded_file.name
            st.session_state['active_language'] = l_map.get(f_ext, 'python')
            st.session_state.pop('audit_results', None)
            st.session_state.pop('original_audit', None)
            st.session_state.pop('verification_result', None)
            st.session_state.pop('editor_code', None)
            st.session_state.pop('current_findings', None)
            st.session_state.pop('edit_mode', None)
            st.session_state.pop('active_view', None)
            st.rerun()

        st.markdown("<div style='margin-top:14px;'></div>", unsafe_allow_html=True)
        st.markdown("<div style='font-size:0.86rem;font-weight:700;color:var(--accent);margin-bottom:8px;'><i class='ti ti-bolt'></i> Quick Start: Load Pre-Built Production Testcases</div>", unsafe_allow_html=True)
        dm_col1, dm_col2, dm_col3 = st.columns(3)
        with dm_col1:
            if st.button("⚡ Demo 1: Multi-Vulnerability App", use_container_width=True, help="Loads consolidated_vuln.py (SQLi, Command Injection, Pickle Deserialization, MD5, XSS)"):
                demo_path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'consolidated_vuln.py')
                if os.path.exists(demo_path):
                    with open(demo_path, 'r', encoding='utf-8') as df:
                        st.session_state['active_code'] = df.read()
                    st.session_state['active_file_name'] = "consolidated_vuln.py"
                    st.session_state['active_language'] = "python"
                    st.session_state.pop('audit_results', None)
                    st.session_state.pop('original_audit', None)
                    st.session_state.pop('verification_result', None)
                    st.session_state.pop('editor_code', None)
                    st.session_state.pop('current_findings', None)
                    st.session_state.pop('edit_mode', None)
                    st.session_state.pop('active_view', None)
                    st.rerun()
        with dm_col2:
            if st.button("🔴 Demo 2: Prompt Injection Jailbreak", use_container_width=True, help="Loads attack_sample_prompt_injection.py with adversarial override signatures"):
                demo_path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'attack_sample_prompt_injection.py')
                if os.path.exists(demo_path):
                    with open(demo_path, 'r', encoding='utf-8') as df:
                        st.session_state['active_code'] = df.read()
                    st.session_state['active_file_name'] = "attack_sample_prompt_injection.py"
                    st.session_state['active_language'] = "python"
                    st.session_state.pop('audit_results', None)
                    st.session_state.pop('original_audit', None)
                    st.session_state.pop('verification_result', None)
                    st.session_state.pop('editor_code', None)
                    st.session_state.pop('current_findings', None)
                    st.session_state.pop('edit_mode', None)
                    st.session_state.pop('active_view', None)
                    st.rerun()
        with dm_col3:
            if st.button("🟢 Demo 3: Safe Taint Static Constant", use_container_width=True, help="Loads static safe SQL query demonstrating false-positive triage suppression"):
                safe_sample = (
                    "import sqlite3\n\n"
                    "def fetch_system_status():\n"
                    '    """Retrieves operational status using a static immutable query (Static Safe)."""\n'
                    '    query = "SELECT service_name, status, uptime FROM cluster_services WHERE active = 1"\n'
                    '    conn = sqlite3.connect("infra.db")\n'
                    "    cursor = conn.cursor()\n"
                    "    cursor.execute(query)\n"
                    "    results = cursor.fetchall()\n"
                    "    conn.close()\n"
                    "    return results\n\n"
                    'if __name__ == "__main__":\n'
                    "    status = fetch_system_status()\n"
                    '    print("Services operational:", len(status))\n'
                )
                st.session_state['active_code'] = safe_sample
                st.session_state['active_file_name'] = "safe_taint_sample.py"
                st.session_state['active_language'] = "python"
                st.session_state.pop('audit_results', None)
                st.session_state.pop('original_audit', None)
                st.session_state.pop('verification_result', None)
                st.session_state.pop('editor_code', None)
                st.session_state.pop('current_findings', None)
                st.session_state.pop('edit_mode', None)
                st.session_state.pop('active_view', None)
                st.rerun()
        st.markdown("<div style='margin-top:10px;'></div>", unsafe_allow_html=True)
        st.markdown("<div style='font-size:0.86rem;font-weight:700;color:var(--danger);margin-bottom:8px;'><i class='ti ti-shield-alert'></i> Red-Team Adversarial Exploit Presets (Live Defense Verification)</div>", unsafe_allow_html=True)
        rt_col1, rt_col2, rt_col3, rt_col4 = st.columns(4)
        with rt_col1:
            if st.button("🎭 Roleplay Jailbreak", use_container_width=True, help="Fictional scenario attempting to force 0 flaws"):
                from src.attack_simulator import PRESET_SAMPLES
                st.session_state['active_code'] = PRESET_SAMPLES['roleplay_jailbreak']['code']
                st.session_state['active_file_name'] = "attack_roleplay_jailbreak.py"
                st.session_state['active_language'] = "python"
                for k in ['audit_results', 'original_audit', 'verification_result', 'editor_code', 'current_findings', 'edit_mode', 'active_view']:
                    st.session_state.pop(k, None)
                st.rerun()
        with rt_col2:
            if st.button("📦 Binary Polyglot", use_container_width=True, help="Executable binary headers & null bytes disguised as .py"):
                from src.attack_simulator import PRESET_SAMPLES
                st.session_state['active_code'] = PRESET_SAMPLES['binary_polyglot']['code']
                st.session_state['active_file_name'] = "attack_binary_polyglot.py"
                st.session_state['active_language'] = "python"
                for k in ['audit_results', 'original_audit', 'verification_result', 'editor_code', 'current_findings', 'edit_mode', 'active_view']:
                    st.session_state.pop(k, None)
                st.rerun()
        with rt_col3:
            if st.button("🖼️ Markdown Exfiltrate", use_container_width=True, help="Injected markdown tracking pixel designed to leak private tokens"):
                from src.attack_simulator import PRESET_SAMPLES
                st.session_state['active_code'] = PRESET_SAMPLES['markdown_exfiltration']['code']
                st.session_state['active_file_name'] = "attack_markdown_exfiltration.py"
                st.session_state['active_language'] = "python"
                for k in ['audit_results', 'original_audit', 'verification_result', 'editor_code', 'current_findings', 'edit_mode', 'active_view']:
                    st.session_state.pop(k, None)
                st.rerun()
        with rt_col4:
            if st.button("💣 System Fork Bomb", use_container_width=True, help="Unbounded os.fork() replication bomb (CWE-400)"):
                from src.attack_simulator import PRESET_SAMPLES
                st.session_state['active_code'] = PRESET_SAMPLES['fork_bomb']['code']
                st.session_state['active_file_name'] = "attack_fork_bomb.py"
                st.session_state['active_language'] = "python"
                for k in ['audit_results', 'original_audit', 'verification_result', 'editor_code', 'current_findings', 'edit_mode', 'active_view']:
                    st.session_state.pop(k, None)
                st.rerun()

    with tab_dir:
        st.markdown("""
        <div style="font-size:0.86rem;color:var(--ink-muted);margin-bottom:12px;line-height:1.5;">
            Scan an entire project folder or upload files from a directory to audit all files.
            Each file has an <b>⚡ Audit File</b> option to launch deep analysis in the Single File Audit studio.
        </div>
        """, unsafe_allow_html=True)
        dir_path_input = st.text_input("Enter absolute local folder path to scan:", value=st.session_state.get('scanned_dir_path', ''))
        uploaded_dir_files = st.file_uploader(
            "Or upload multiple files from a folder:",
            type=['py', 'java', 'c', 'js'],
            accept_multiple_files=True,
            help="Select and upload multiple files to audit them together as a directory",
            key="dir_file_uploader"
        )
        c_btn1, c_btn2, c_btn3 = st.columns([1, 1, 0.6])
        with c_btn1:
            run_btn = st.button("Run Full Directory Audit", type="primary", use_container_width=True)
        with c_btn2:
            demo_btn = st.button("Load Demo Directory Data (Fast)", use_container_width=True)
        with c_btn3:
            if st.session_state.get('dir_scan_results'):
                if st.button("✕ Reset", use_container_width=True, help="Clear directory scan results"):
                    st.session_state.pop('dir_scan_results', None)
                    st.session_state.pop('scanned_dir_path', None)
                    st.rerun()
        st.markdown("<div style='margin-top:6px;'></div>", unsafe_allow_html=True)
        t_col1, t_col2 = st.columns([1, 1])
        with t_col1:
            if st.button("🚨 Test Path Traversal Defense (CWE-22)", use_container_width=True, help="Simulates an attacker entering ../../Windows to test directory traversal containment"):
                st.session_state['scanned_dir_path'] = r"..\..\..\..\Windows\System32\drivers\etc"
                st.rerun()


    has_dir_results = bool(st.session_state.get('dir_scan_results'))

    # ═══════════════════════════════════════════════════
    # DIRECTORY SCAN
    # ═══════════════════════════════════════════════════
    if run_btn or demo_btn:
        # Security Guardrail: Directory Traversal Validation (CWE-22)
        if run_btn and dir_path_input and not uploaded_dir_files:
            raw_path = dir_path_input.strip()
            norm_path = os.path.normpath(raw_path)
            real_path = os.path.realpath(os.path.abspath(raw_path))
            is_traversal = ".." in raw_path or ".." in norm_path
            
            restricted_patterns = [
                r'^[a-zA-Z]:\\windows', r'^[a-zA-Z]:\\program files', r'^[a-zA-Z]:\\system',
                r'^/etc', r'^/usr', r'^/var', r'^/proc', r'^/sys', r'^/root'
            ]
            import re
            is_restricted_os = any(re.search(pat, real_path, re.IGNORECASE) for pat in restricted_patterns)

            if is_traversal or is_restricted_os:
                st.markdown(f'''
                <div style="background:linear-gradient(135deg, rgba(239,68,68,0.14) 0%, rgba(239,68,68,0.06) 100%);border:2px solid var(--danger);border-radius:var(--radius);padding:14px 18px;margin-bottom:14px;box-shadow:var(--shadow-sm);">
                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                        <div style="font-weight:750;font-size:0.95rem;color:var(--danger);display:flex;align-items:center;gap:8px;">
                            <i class="ti ti-shield-alert" style="font-size:1.25rem;"></i>
                            <span>🚨 PATH TRAVERSAL BLOCKED (CWE-22)</span>
                        </div>
                        <span style="font-size:0.75rem;font-weight:700;background:rgba(239,68,68,0.2);color:var(--danger);padding:3px 10px;border-radius:20px;">
                            Arbitrary File Read Intercepted
                        </span>
                    </div>
                    <div style="font-size:0.83rem;color:var(--st-text-secondary);margin-top:6px;line-height:1.5;">
                        <b>Security Perimeter Active:</b> Attempt to traverse out of project boundaries or access restricted host OS path (<code>{html_mod.escape(raw_path)}</code>) was neutralized.
                        Zero system files were read, and the directory scanner remained securely sandboxed.
                    </div>
                </div>
                ''', unsafe_allow_html=True)
                st.stop()

        if run_btn and not (uploaded_dir_files or (dir_path_input and os.path.isdir(dir_path_input))):
            st.error("Directory not found or path empty! Please provide a valid absolute directory path or upload files.")
            st.stop()

        if run_btn and uploaded_dir_files:
            import tempfile
            temp_dir = tempfile.mkdtemp(prefix="dir_upload_")
            for uf in uploaded_dir_files:
                safe_name = os.path.basename(uf.name)
                target_p = os.path.join(temp_dir, safe_name)
                with open(target_p, 'wb') as f:
                    f.write(uf.getvalue())
            dir_path_input = temp_dir

        st.markdown('''<div class="section-header">
            <i class="ti ti-folder"></i> Directory Scan
        </div>''', unsafe_allow_html=True)

        import json
        from main_folder import bulk_semgrep_scan, analyze_all_files, build_project_map
        inference = load_inference_engine()

        pipeline_ph = st.empty()

        if demo_btn:
            pipeline_ph.markdown("### <i class='ti ti-loader-2'></i> Loading Full Directory Demo Data...", unsafe_allow_html=True)
            time.sleep(0.5)
            demo_res_path = os.path.join(os.path.dirname(__file__), "demo_assets", "demo_results.json")
            demo_energy_path = os.path.join(os.path.dirname(__file__), "demo_assets", "demo_energy.json")
            with open(demo_res_path, 'r') as f:
                results_arr = json.load(f)
            dir_path_input = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
            reports_dir = os.path.join(os.path.dirname(__file__), "frontend", "public", "reports")
            os.makedirs(reports_dir, exist_ok=True)
            import shutil
            shutil.copyfile(demo_energy_path, os.path.join(reports_dir, "latest_report.json"))
        else:
            pipeline_ph.markdown("### <i class='ti ti-loader-2'></i> Running Bulk Directory Scan... This may take a while.", unsafe_allow_html=True)
            with measure_energy(sample_interval_s=0.2) as col:
                col.begin_phase("Semgrep Bulk Scan")
                semgrep_map = bulk_semgrep_scan(dir_path_input)
                col.begin_phase("AI Parallel Processing")
                results_arr = analyze_all_files(dir_path_input, semgrep_map, inference)
                col.begin_phase("Map Assembly")
                project_map = build_project_map(results_arr, dir_path_input, inference)
                col.end_phase()
            reports_dir = os.path.join(os.path.dirname(__file__), "frontend", "public", "reports")
            os.makedirs(reports_dir, exist_ok=True)
            with open(os.path.join(reports_dir, "latest_report.json"), "w") as f:
                json.dump(col.report.to_dict(), f)

        pipeline_ph.empty()
        st.session_state['dir_scan_results'] = results_arr
        st.session_state['scanned_dir_path'] = dir_path_input

    if st.session_state.get('dir_scan_results'):
        results_arr = st.session_state['dir_scan_results']
        dir_path_input = st.session_state.get('scanned_dir_path', dir_path_input)

        st.markdown('''<div class="section-header"><i class="ti ti-chart-bar"></i> Directory Pipeline Results</div>''', unsafe_allow_html=True)

        total_counts = {'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        from src.vuln_classifier import normalize_severity
        for r in results_arr:
            if 'error' in r: continue
            for f in r.get('findings', []):
                sev = normalize_severity(f.get('severity', 'INFO')).upper()
                if sev in total_counts: total_counts[sev] += 1
                else: total_counts['LOW'] += 1

        c1, c2, c3, c4 = st.columns(4)
        with c1: st.markdown(f"""<div class="metric-card"><div class="metric-value">{len(results_arr)}</div><div class="metric-label">Files Scanned</div></div>""", unsafe_allow_html=True)
        with c2: st.markdown(f"""<div class="metric-card"><div class="metric-value" style="color:var(--danger);">{total_counts['HIGH']}</div><div class="metric-label">High Severity</div></div>""", unsafe_allow_html=True)
        with c3: st.markdown(f"""<div class="metric-card"><div class="metric-value" style="color:var(--warning);">{total_counts['MEDIUM']}</div><div class="metric-label">Medium Severity</div></div>""", unsafe_allow_html=True)
        with c4: st.markdown(f"""<div class="metric-card"><div class="metric-value" style="color:var(--accent);">{total_counts['LOW']}</div><div class="metric-label">Low Severity</div></div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('''<div class="section-header"><i class="ti ti-article"></i> Project AI Overview
            <span style="font-weight:400;font-size:0.8rem;color:var(--ink-muted);margin-left:8px;">(Click "⚡ Audit File" to inspect any file in the studio)</span>
        </div>''', unsafe_allow_html=True)

        from collections import defaultdict
        groups = defaultdict(list)
        for r in sorted(results_arr, key=lambda x: x.get('file', '')):
            if 'error' in r: continue
            try:
                rel = os.path.relpath(r['file'], dir_path_input).replace('\\', '/')
            except Exception:
                rel = os.path.basename(r.get('file', ''))
            parts = rel.split('/')
            group = parts[0] if len(parts) > 1 else 'root'
            fname = os.path.basename(r.get('file', ''))
            s = r.get('summary', '').strip()
            groups[group].append({
                'fname': fname,
                'file': r.get('file', ''),
                'language': r.get('language', 'python'),
                'summary': s,
                'score': r.get('risk_score', 0)
            })

        file_counter = 0
        for group, entries in sorted(groups.items()):
            with st.expander(f"📁 {group.upper()} ({len(entries)} file{'s' if len(entries)>1 else ''})", expanded=True if len(groups) <= 2 else False):
                for e in entries:
                    file_counter += 1
                    row_c1, row_c2 = st.columns([0.80, 0.20])
                    score = e['score']
                    sc_color = 'var(--danger)' if score >= 8 else 'var(--warning)' if score >= 4 else 'var(--success)'
                    with row_c1:
                        st.markdown(
                            f"<div style='padding:4px 0;'>"
                            f"<b><i class='ti ti-file-code' style='color:var(--accent);margin-right:4px;'></i>{e['fname']}</b> &nbsp;&middot;&nbsp; "
                            f"<span style='font-family:var(--mono);font-size:0.75rem;font-weight:700;color:{sc_color};background:rgba(0,0,0,0.03);padding:2px 8px;border-radius:4px;'>Risk: {score}/10</span><br>"
                            f"<span style='color:var(--ink-muted);font-size:0.83rem;'>{e['summary']}</span>"
                            f"</div>",
                            unsafe_allow_html=True
                        )
                    with row_c2:
                        st.markdown("<div style='height:4px;'></div>", unsafe_allow_html=True)
                        if st.button("⚡ Audit File", key=f"btn_audit_grp_{file_counter}", use_container_width=True, help=f"Audit {e['fname']} in Single File Audit Studio"):
                            open_file_in_studio(e['file'], e['fname'], e.get('language', 'python'))
                    st.markdown("<div style='border-bottom:1px solid #f1f5f9;margin:2px 0 6px 0;'></div>", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('''<div class="section-header"><i class="ti ti-skull"></i> Top 5 Riskiest Files</div>''', unsafe_allow_html=True)
        ranked_risk = sorted([r for r in results_arr if 'error' not in r], key=lambda x: x.get('risk_score', 0), reverse=True)
        for idx, r in enumerate(ranked_risk[:5]):
            try:
                rel_path = os.path.relpath(r['file'], dir_path_input)
            except Exception:
                rel_path = os.path.basename(r.get('file', ''))
            sev = "HIGH" if r.get('risk_score', 0) >= 8 else "MEDIUM" if r.get('risk_score', 0) >= 5 else "LOW"
            rf_col1, rf_col2 = st.columns([0.80, 0.20])
            with rf_col1:
                st.markdown(f"""
                <div class="finding-card finding-{sev}" style="margin-bottom:6px;padding:12px 14px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-weight:600; font-size:0.88rem; color:var(--ink);"><i class="ti ti-file-code" style="color:var(--accent);margin-right:4px;"></i>{rel_path}</span>
                        <span style="font-family:var(--mono); font-weight:800; font-size:0.95rem; color:var(--ink);">{r.get('risk_score',0)}/10</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            with rf_col2:
                st.markdown("<div style='height:4px;'></div>", unsafe_allow_html=True)
                if st.button("⚡ Audit File", key=f"btn_audit_riskiest_{idx}", use_container_width=True, help=f"Open {os.path.basename(r['file'])} in single-file audit studio"):
                    open_file_in_studio(r['file'], os.path.basename(r['file']), r.get('language', 'python'))

        st.markdown("<br>", unsafe_allow_html=True)
        st.link_button("Open Advanced Analytics (React Frontend)", "http://localhost:5173", use_container_width=True)

    st.stop()





# ═══════════════════════════════════════════════════
# ═══════════════════════════════════════════════════
# SINGLE FILE AUDIT — LEETCODE-STYLE SPLIT-VIEW STUDIO WORKSPACE
# ═══════════════════════════════════════════════════
elif st.session_state.get('active_code'):
    code_content = st.session_state['active_code']
    active_name  = st.session_state.get('active_file_name', 'source_code.py')
    language     = st.session_state.get('active_language', 'python')
    lines        = code_content.count('\n') + 1

    # Active Workspace Theme Toggle (default: dark matching LeetCode / VS Code reference)
    current_theme = st.session_state.get('studio_theme', 'dark')
    is_dark = (current_theme == 'dark')

    if is_dark:
        st_theme_css = """
        --st-bg: #0b0f19;
        --st-panel: #101623;
        --st-header: #141b2d;
        --st-card: #131a29;
        --st-card-header: #192237;
        --st-border: #232d42;
        --st-border-subtle: #1c2438;
        --st-gutter: #0d121c;
        --st-gutter-num: #64748b;
        --st-text: #f1f5f9;
        --st-text-secondary: #cbd5e1;
        --st-text-muted: #94a3b8;
        --st-accent: #38bdf8;
        --st-accent-hover: #0ea5e9;
        --st-accent-bg: rgba(56, 189, 248, 0.12);
        --st-tab-bar: #0d121c;
        --st-tab-active: #192237;
        --st-tab-text: #94a3b8;
        --st-tab-active-text: #38bdf8;
        --st-handle-bg: #1e293b;
        --st-handle-border: #334155;
        --st-handle-color: #94a3b8;
        --st-scrollbar-track: #0d121c;
        --st-scrollbar-thumb: #232d42;
        --st-scrollbar-thumb-hover: #38bdf8;
        --st-syn-kw: #38bdf8;
        --st-syn-fn: #facc15;
        --st-syn-cls: #7dd3fc;
        --st-syn-str: #4ade80;
        --st-syn-com: #6ee7b7;
        --st-syn-num: #c084fc;
        --st-syn-op: #cbd5e1;
        --st-syn-bt: #e879f9;
        --st-syn-ident: #f1f5f9;
        """
    else:
        st_theme_css = """
        --st-bg: #f1f5f9;
        --st-panel: #ffffff;
        --st-header: #f8fafc;
        --st-card: #ffffff;
        --st-card-header: #f8fafc;
        --st-border: #cbd5e1;
        --st-border-subtle: #e2e8f0;
        --st-gutter: #f8fafc;
        --st-gutter-num: #94a3b8;
        --st-text: #0f172a;
        --st-text-secondary: #334155;
        --st-text-muted: #64748b;
        --st-accent: #0284c7;
        --st-accent-hover: #0369a1;
        --st-accent-bg: rgba(2, 132, 199, 0.08);
        --st-tab-bar: #f1f5f9;
        --st-tab-active: #ffffff;
        --st-tab-text: #64748b;
        --st-tab-active-text: #0284c7;
        --st-handle-bg: #ffffff;
        --st-handle-border: #cbd5e1;
        --st-handle-color: #64748b;
        --st-scrollbar-track: #f1f5f9;
        --st-scrollbar-thumb: #cbd5e1;
        --st-scrollbar-thumb-hover: #0284c7;
        --st-syn-kw: #0000ff;
        --st-syn-fn: #795e26;
        --st-syn-cls: #0550ae;
        --st-syn-str: #098658;
        --st-syn-com: #57606a;
        --st-syn-num: #098658;
        --st-syn-op: #24292f;
        --st-syn-bt: #0550ae;
        --st-syn-ident: #1f2328;
        """

    # Inject Complete Fixed-Viewport & Themed Studio CSS
    st.markdown(f"""
    <style>
    /* Complete suppression of Streamlit top and bottom chrome */
    header[data-testid="stHeader"] {{
        display: none !important;
        height: 0 !important;
        visibility: hidden !important;
    }}
    footer {{
        display: none !important;
        height: 0 !important;
    }}
    #MainMenu {{
        display: none !important;
    }}

    :root {{
        {st_theme_css}
        --bg: var(--st-bg);
        --surface: var(--st-card);
        --surface-2: var(--st-card-header);
        --surface-3: var(--st-border);
        --border: var(--st-border);
        --border-light: var(--st-border);
        --ink: var(--st-text);
        --ink-2: var(--st-text-secondary);
        --ink-muted: var(--st-text-muted);
        --ink-faint: var(--st-text-muted);
    }}

    /* Pinned outer viewport: page never scrolls down */
    html, body, [data-testid="stAppViewContainer"], .stApp {{
        height: 100vh !important;
        max-height: 100vh !important;
        overflow: hidden !important;
        background-color: var(--st-bg) !important;
        color: var(--st-text) !important;
    }}
    [data-testid="stAppViewContainer"] > section.main {{
        height: 100vh !important;
        max-height: 100vh !important;
        overflow: hidden !important;
        padding: 0 !important;
        background-color: var(--st-bg) !important;
    }}
    .block-container {{
        height: 100vh !important;
        max-height: 100vh !important;
        overflow: hidden !important;
        padding-top: 4px !important;
        padding-bottom: 8px !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
    }}

    /* ALL inner columns inside tab panels or buttons MUST flow naturally */
    [data-testid="stTabPanel"] [data-testid="stHorizontalBlock"],
    [data-testid="stTabPanel"] [data-testid="column"],
    [data-testid="stTabPanel"] [data-testid="stVerticalBlock"],
    [data-testid="stTabPanel"] [data-testid="element-container"],
    [data-baseweb="tab-panel"] [data-testid="stHorizontalBlock"],
    [data-baseweb="tab-panel"] [data-testid="column"],
    [data-baseweb="tab-panel"] [data-testid="stVerticalBlock"],
    [data-baseweb="tab-panel"] [data-testid="element-container"] {{
        height: auto !important;
        max-height: none !important;
        overflow: visible !important;
    }}

    /* Top Workspace Nav Bar */
    .workspace-top-bar {{
        background: var(--st-header);
        border: 1px solid var(--st-border);
        border-radius: 8px;
        padding: 4px 12px;
        min-height: 38px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 4px;
        box-sizing: border-box;
    }}

    /* Top nav action buttons */
    .stButton > button#btn_theme_toggle,
    .stButton > button#btn_exit_home,
    div[data-testid="column"] button[kind="secondary"] {{
        height: 32px !important;
        min-height: 32px !important;
        padding: 3px 12px !important;
        font-size: 0.78rem !important;
        font-weight: 650 !important;
        border-radius: 6px !important;
        background: var(--st-card) !important;
        color: var(--st-text) !important;
        border: 1px solid var(--st-border) !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05) !important;
        transition: all 0.15s ease !important;
    }}
    .stButton > button#btn_theme_toggle:hover,
    .stButton > button#btn_exit_home:hover,
    div[data-testid="column"] button[kind="secondary"]:hover {{
        background: var(--st-card-header) !important;
        border-color: var(--st-accent) !important;
        color: var(--st-accent) !important;
    }}

    /* Left pane code panel & scroll wrapper - LeetCode card */
    .code-panel {{
        background: var(--st-panel) !important;
        border: 1px solid var(--st-border) !important;
        border-radius: 8px !important;
        overflow: hidden !important;
        display: flex !important;
        flex-direction: column !important;
        height: 100% !important;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1) !important;
        box-sizing: border-box !important;
    }}

    /* PART 2: Left Header Bar (Code Tab, Filename Tab, Language, Lines, Run Audit button) */
    .part2-header-container {{
        background: var(--st-header) !important;
        border: 1px solid var(--st-border) !important;
        border-bottom: 1px solid var(--st-border-subtle) !important;
        border-radius: 8px 8px 0 0 !important;
        padding: 4px 10px !important;
        min-height: 38px !important;
        height: 38px !important;
        box-sizing: border-box !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        gap: 6px !important;
        user-select: none !important;
    }}
    .part2-code-tab {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 5px !important;
        font-weight: 750 !important;
        font-size: 0.8rem !important;
        color: var(--st-text) !important;
        background: var(--st-panel) !important;
        border: 1px solid var(--st-border) !important;
        border-bottom: 2px solid var(--st-accent) !important;
        padding: 3px 10px !important;
        border-radius: 6px 6px 0 0 !important;
    }}
    .part2-file-tab {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 5px !important;
        font-weight: 600 !important;
        font-size: 0.76rem !important;
        color: var(--st-text-secondary) !important;
        background: var(--st-card) !important;
        border: 1px solid var(--st-border) !important;
        padding: 3px 8px !important;
        border-radius: 5px !important;
    }}
    .part2-file-close {{
        font-size: 0.65rem !important;
        color: var(--st-text-muted) !important;
        margin-left: 3px !important;
        cursor: default !important;
    }}
    .part2-lang-dropdown {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 4px !important;
        background: var(--st-card) !important;
        border: 1px solid var(--st-border) !important;
        color: var(--st-text) !important;
        border-radius: 5px !important;
        padding: 2px 8px !important;
        font-size: 0.74rem !important;
        font-weight: 650 !important;
        font-family: var(--mono), monospace !important;
        letter-spacing: 0.3px !important;
    }}
    .part2-lines {{
        font-size: 0.7rem !important;
        color: var(--st-text-muted) !important;
        background: rgba(100, 116, 139, 0.12) !important;
        padding: 2px 7px !important;
        border-radius: 4px !important;
        font-weight: 600 !important;
    }}

    /* Run Audit Button Styling */
    div[data-testid="column"]:first-child button[data-testid="baseButton-primary"],
    div[data-testid="column"]:first-child .stButton > button[kind="primary"] {{
        height: 38px !important;
        min-height: 38px !important;
        padding: 4px 14px !important;
        font-size: 0.82rem !important;
        font-weight: 750 !important;
        border-radius: 6px !important;
        background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
        color: #ffffff !important;
        border: 1px solid #0284c7 !important;
        box-shadow: 0 1px 3px rgba(2, 132, 199, 0.3) !important;
        transition: all 0.15s ease !important;
    }}
    div[data-testid="column"]:first-child button[data-testid="baseButton-primary"]:hover,
    div[data-testid="column"]:first-child .stButton > button[kind="primary"]:hover {{
        background: linear-gradient(135deg, #0369a1 0%, #075985 100%) !important;
        box-shadow: 0 3px 8px rgba(2, 132, 199, 0.45) !important;
        transform: translateY(-1px) !important;
    }}

    /* Line Numbers Gutter & Code Editor Layout */
    .code-gutter-scroll {{
        background: var(--st-gutter) !important;
        border-left: 1px solid var(--st-border) !important;
        border-right: 1px solid var(--st-border) !important;
        height: calc(100vh - 128px) !important;
        max-height: calc(100vh - 128px) !important;
        overflow-y: hidden !important;
        overflow-x: hidden !important;
        padding-top: 10px !important;
        padding-bottom: 40px !important;
        user-select: none !important;
        box-sizing: border-box !important;
    }}
    .gutter-line {{
        height: 24px !important;
        min-height: 24px !important;
        max-height: 24px !important;
        line-height: 24px !important;
        font-family: 'JetBrains Mono', 'Fira Code', Consolas, 'Courier New', monospace !important;
        font-size: 0.84rem !important;
        text-align: right !important;
        padding-right: 8px !important;
        padding-left: 2px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: flex-end !important;
        gap: 3px !important;
        box-sizing: border-box !important;
        white-space: nowrap !important;
        color: var(--st-gutter-num) !important;
    }}
    .gutter-line.g-vuln-high {{
        background: rgba(239, 68, 68, 0.18) !important;
        color: #ef4444 !important;
        font-weight: 700 !important;
    }}
    .gutter-line.g-vuln-med {{
        background: rgba(245, 158, 11, 0.18) !important;
        color: #f59e0b !important;
        font-weight: 700 !important;
    }}
    .gutter-line.g-vuln-low {{
        background: rgba(2, 132, 199, 0.18) !important;
        color: var(--st-accent) !important;
        font-weight: 700 !important;
    }}
    .g-dot-high {{ color: #ef4444 !important; font-size: 0.62rem !important; }}
    .g-dot-med  {{ color: #f59e0b !important; font-size: 0.62rem !important; }}
    .g-dot-low  {{ color: var(--st-accent) !important; font-size: 0.62rem !important; }}

    div[data-testid="column"]:first-child .stTextArea {{
        margin: 0 !important;
        padding: 0 !important;
    }}
    div[data-testid="column"]:first-child .stTextArea > label {{
        display: none !important;
    }}
    div[data-testid="column"]:first-child .stTextArea [data-baseweb="textarea"] {{
        background: var(--st-panel) !important;
        border: 1px solid var(--st-border) !important;
        border-left: none !important;
        border-top: none !important;
        border-bottom: none !important;
        border-radius: 0 !important;
        padding: 0 !important;
        box-shadow: none !important;
    }}
    div[data-testid="column"]:first-child .stTextArea textarea {{
        height: calc(100vh - 128px) !important;
        min-height: calc(100vh - 128px) !important;
        max-height: calc(100vh - 128px) !important;
        border: none !important;
        border-radius: 0 !important;
        font-family: 'JetBrains Mono', 'Fira Code', Consolas, 'Courier New', monospace !important;
        font-size: 0.84rem !important;
        line-height: 24px !important;
        letter-spacing: 0.15px !important;
        background: transparent !important;
        color: transparent !important;
        padding-top: 10px !important;
        padding-bottom: 40px !important;
        padding-left: 10px !important;
        padding-right: 16px !important;
        resize: none !important;
        outline: none !important;
        box-shadow: none !important;
        caret-color: var(--st-accent) !important;
        overflow-y: auto !important;
        overflow-x: auto !important;
        white-space: pre !important;
        word-wrap: normal !important;
        tab-size: 4 !important;
        box-sizing: border-box !important;
    }}
    div[data-testid="column"]:first-child .stTextArea textarea:focus {{
        border: none !important;
        outline: none !important;
        box-shadow: none !important;
    }}

    div[data-testid="stHorizontalBlock"]:has(#editor-gutter-lines) {{
        align-items: stretch !important;
        gap: 0 !important;
    }}
    div[data-testid="stHorizontalBlock"] > div[data-testid="column"]:has(#editor-gutter-lines) {{
        width: 52px !important;
        min-width: 52px !important;
        max-width: 52px !important;
        flex: 0 0 52px !important;
    }}

    /* Bottom IDE Status Bar */
    .editor-status-bar {{
        background: var(--st-header) !important;
        border: 1px solid var(--st-border) !important;
        border-top: 1px solid var(--st-border-subtle) !important;
        border-radius: 0 0 8px 8px !important;
        padding: 3px 12px !important;
        min-height: 26px !important;
        height: 26px !important;
        box-sizing: border-box !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        font-size: 0.7rem !important;
        color: var(--st-text-muted) !important;
        user-select: none !important;
    }}
    .editor-status-item {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 4px !important;
    }}

    /* Right pane tab container - LeetCode card with fixed bottom boundary & full vertical scroll */
    div[data-testid="column"]:has(#lc-col-right-anchor),
    div[data-testid="column"]:has([data-testid="stTabs"]) {{
        display: flex !important;
        flex-direction: column !important;
        height: 100% !important;
        max-height: calc(100vh - 65px) !important;
        min-height: 0 !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
    }}

    div[data-testid="column"]:has(#lc-col-right-anchor) [data-testid="stVerticalBlockBorderWrapper"],
    div[data-testid="column"]:has([data-testid="stTabs"]) [data-testid="stVerticalBlockBorderWrapper"],
    div[data-testid="column"]:has(#lc-col-right-anchor) .stVerticalBlockBorderWrapper,
    div[data-testid="column"]:has([data-testid="stTabs"]) .stVerticalBlockBorderWrapper {{
        height: 100% !important;
        min-height: 0 !important;
        display: flex !important;
        flex-direction: column !important;
        flex: 1 1 auto !important;
    }}

    div[data-testid="column"]:has(#lc-col-right-anchor) [data-testid="stVerticalBlock"],
    div[data-testid="column"]:has([data-testid="stTabs"]) [data-testid="stVerticalBlock"] {{
        display: flex !important;
        flex-direction: column !important;
        min-height: 0 !important;
        flex: 1 1 auto !important;
        gap: 0px !important;
    }}

    div[data-testid="column"]:has(#lc-col-right-anchor) div[data-testid="element-container"]:has(#lc-col-right-anchor) {{
        display: none !important;
        height: 0px !important;
        max-height: 0px !important;
        margin: 0px !important;
        padding: 0px !important;
        overflow: hidden !important;
    }}

    div[data-testid="column"]:has(#lc-col-right-anchor) div[data-testid="element-container"]:has([data-testid="stTabs"]),
    div[data-testid="column"]:has([data-testid="stTabs"]) div[data-testid="element-container"]:has([data-testid="stTabs"]) {{
        display: flex !important;
        flex-direction: column !important;
        min-height: 0 !important;
        flex: 1 1 auto !important;
        margin: 0px !important;
        padding: 0px !important;
    }}

    .stTabs, [data-testid="stTabs"] {{
        min-height: 0 !important;
        display: flex !important;
        flex-direction: column !important;
        flex: 1 1 auto !important;
        margin-bottom: 0 !important;
    }}
    .stTabs [data-baseweb="tab-list"],
    [data-testid="stTabs"] [role="tablist"] {{
        background-color: var(--st-tab-bar) !important;
        border: 1px solid var(--st-border) !important;
        border-bottom: none !important;
        border-radius: 8px 8px 0 0 !important;
        padding: 3px !important;
        gap: 4px !important;
        margin-bottom: 0px !important;
        flex-shrink: 0 !important;
        height: 38px !important;
        min-height: 38px !important;
        max-height: 38px !important;
        box-sizing: border-box !important;
    }}
    .stTabs [data-baseweb="tab"],
    [data-testid="stTab"],
    [data-testid="stTabs"] [role="tab"] {{
        padding: 6px 14px !important;
        font-size: 0.8rem !important;
        font-weight: 600 !important;
        color: var(--st-tab-text) !important;
        border-radius: 6px !important;
        transition: all 0.15s ease !important;
        border: none !important;
        border-bottom: none !important;
        background: transparent !important;
    }}
    .stTabs [aria-selected="true"],
    [data-testid="stTab"][aria-selected="true"],
    [data-testid="stTabs"] [role="tab"][aria-selected="true"] {{
        background-color: var(--st-tab-active) !important;
        color: var(--st-tab-active-text) !important;
        font-weight: 750 !important;
        border-bottom: 2px solid var(--st-accent) !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.12) !important;
    }}
    [data-testid="stTabPanel"],
    [data-baseweb="tab-panel"] {{
        flex: 1 1 auto !important;
        min-height: 0 !important;
        max-height: calc(100vh - 120px) !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        padding: 14px 14px 140px 14px !important;
        background: var(--st-panel) !important;
        border: 1px solid var(--st-border) !important;
        border-top: 1px solid var(--st-border-subtle) !important;
        border-radius: 0 0 8px 8px !important;
        box-sizing: border-box !important;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08) !important;
        -webkit-overflow-scrolling: touch !important;
        overscroll-behavior-y: contain !important;
    }}

    /* Unified Sleek Scrollbars */
    [data-testid="stTabPanel"]::-webkit-scrollbar,
    [data-baseweb="tab-panel"]::-webkit-scrollbar,
    div[data-testid="column"]:first-child .stTextArea textarea::-webkit-scrollbar,
    .diff-pre::-webkit-scrollbar {{
        width: 8px !important;
        height: 8px !important;
    }}
    [data-testid="stTabPanel"]::-webkit-scrollbar-track,
    [data-baseweb="tab-panel"]::-webkit-scrollbar-track,
    div[data-testid="column"]:first-child .stTextArea textarea::-webkit-scrollbar-track,
    .diff-pre::-webkit-scrollbar-track {{
        background: var(--st-scrollbar-track) !important;
        border-radius: 4px !important;
    }}
    [data-testid="stTabPanel"]::-webkit-scrollbar-thumb,
    [data-baseweb="tab-panel"]::-webkit-scrollbar-thumb,
    div[data-testid="column"]:first-child .stTextArea textarea::-webkit-scrollbar-thumb,
    .diff-pre::-webkit-scrollbar-thumb {{
        background: var(--st-scrollbar-thumb) !important;
        border-radius: 4px !important;
    }}
    [data-testid="stTabPanel"]::-webkit-scrollbar-thumb:hover,
    [data-baseweb="tab-panel"]::-webkit-scrollbar-thumb:hover,
    div[data-testid="column"]:first-child .stTextArea textarea::-webkit-scrollbar-thumb:hover,
    .diff-pre::-webkit-scrollbar-thumb:hover {{
        background: var(--st-scrollbar-thumb-hover) !important;
    }}

    /* LeetCode Boxed Section System */
    .lc-box {{
        background: var(--st-card) !important;
        border: 1px solid var(--st-border) !important;
        border-radius: 8px !important;
        margin-bottom: 10px !important;
        overflow: hidden !important;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06) !important;
    }}
    .lc-box-header {{
        background: var(--st-card-header) !important;
        border-bottom: 1px solid var(--st-border) !important;
        padding: 8px 14px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        font-weight: 700 !important;
        font-size: 0.82rem !important;
        color: var(--st-text) !important;
        letter-spacing: 0.3px !important;
    }}
    .lc-box-title {{
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
    }}
    .lc-box-body {{
        padding: 12px 14px !important;
        background: var(--st-card) !important;
        font-size: 0.86rem !important;
        color: var(--st-text-secondary) !important;
        line-height: 1.55 !important;
    }}
    .lc-inner-box {{
        background: var(--st-card-header) !important;
        border: 1px solid var(--st-border) !important;
        border-radius: 6px !important;
        padding: 10px 12px !important;
        margin-bottom: 8px !important;
    }}
    .lc-inner-title {{
        font-size: 0.76rem !important;
        font-weight: 700 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.6px !important;
        color: var(--st-text-muted) !important;
        margin-bottom: 4px !important;
        display: flex !important;
        align-items: center !important;
        gap: 6px !important;
    }}
    .lc-inner-text {{
        font-size: 0.86rem !important;
        line-height: 1.55 !important;
        color: var(--st-text-secondary) !important;
    }}
    .lc-tag {{
        display: inline-flex !important;
        align-items: center !important;
        gap: 4px !important;
        background: var(--st-card-header) !important;
        border: 1px solid var(--st-border) !important;
        border-radius: 12px !important;
        padding: 2px 10px !important;
        font-size: 0.72rem !important;
        font-weight: 600 !important;
        color: var(--st-text-secondary) !important;
    }}

    .metric-card {{
        background: var(--st-card) !important;
        border: 1px solid var(--st-border) !important;
        border-radius: 8px !important;
    }}
    .metric-value {{
        color: var(--st-text) !important;
        font-weight: 800 !important;
    }}
    .metric-label {{
        color: var(--st-text-muted) !important;
        text-transform: uppercase !important;
        font-weight: 600 !important;
    }}

    /* ═══════════════════════════════════════════════════
       REMEDIATION DIFF CONTAINER — CRITICAL OVERFLOW FIX
       ═══════════════════════════════════════════════════ */
    .diff-patch-section {{
        margin-bottom: 12px !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }}
    .diff-patch-caption {{
        font-size: 0.78rem !important;
        color: var(--st-text-muted) !important;
        font-weight: 600 !important;
        margin-bottom: 6px !important;
        display: flex !important;
        align-items: center !important;
        gap: 6px !important;
    }}
    .remediation-diff-container {{
        display: grid !important;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)) !important;
        gap: 12px !important;
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
    }}
    .remediation-diff-card {{
        min-width: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        border-radius: 8px !important;
        overflow: hidden !important;
        display: flex !important;
        flex-direction: column !important;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08) !important;
    }}
    .remediation-diff-header {{
        padding: 6px 12px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        font-size: 0.78rem !important;
        font-weight: 700 !important;
        box-sizing: border-box !important;
    }}
    .diff-code-wrapper {{
        min-width: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        overflow-x: auto !important;
        overflow-y: hidden !important;
        box-sizing: border-box !important;
    }}
    .diff-pre {{
        margin: 0 !important;
        padding: 10px 14px !important;
        font-family: var(--mono), monospace !important;
        font-size: 0.83rem !important;
        line-height: 1.55 !important;
        min-width: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        white-space: pre !important;
        word-break: normal !important;
        word-wrap: normal !important;
        overflow-x: auto !important;
        tab-size: 4 !important;
    }}

    /* Before Card Colors */
    .diff-before-card {{
        background: {'#191012' if is_dark else '#fef2f2'} !important;
        border: 1px solid {'#7f1d1d' if is_dark else '#fecaca'} !important;
        border-left: 4px solid #ef4444 !important;
    }}
    .diff-before-header {{
        background: {'#261317' if is_dark else '#fee2e2'} !important;
        border-bottom: 1px solid {'#7f1d1d' if is_dark else '#fecaca'} !important;
        color: {'#fca5a5' if is_dark else '#991b1b'} !important;
    }}
    .diff-before-pre {{
        color: {'#fecaca' if is_dark else '#991b1b'} !important;
    }}
    .diff-before-badge {{
        background: rgba(239, 68, 68, 0.2) !important;
        color: #ef4444 !important;
        border: 1px solid rgba(239, 68, 68, 0.4) !important;
        border-radius: 4px !important;
        padding: 1px 6px !important;
        font-size: 0.68rem !important;
    }}

    /* After Card Colors */
    .diff-after-card {{
        background: {'#0d1912' if is_dark else '#f0fdf4'} !important;
        border: 1px solid {'#065f46' if is_dark else '#bbf7d0'} !important;
        border-left: 4px solid #10b981 !important;
    }}
    .diff-after-header {{
        background: {'#12271c' if is_dark else '#dcfce7'} !important;
        border-bottom: 1px solid {'#065f46' if is_dark else '#bbf7d0'} !important;
        color: {'#86efac' if is_dark else '#166534'} !important;
    }}
    .diff-after-pre {{
        color: {'#bbf7d0' if is_dark else '#166534'} !important;
    }}
    .diff-after-badge {{
        background: rgba(16, 185, 129, 0.2) !important;
        color: #10b981 !important;
        border: 1px solid rgba(16, 185, 129, 0.4) !important;
        border-radius: 4px !important;
        padding: 1px 6px !important;
        font-size: 0.68rem !important;
    }}

    /* Pygments Syntax Tokens in Code Viewer & Diff */
    .diff-pre .kd, .diff-pre .k, .diff-pre .kn, .diff-pre .kp, .diff-pre .kr {{ color: var(--st-syn-kw) !important; font-weight: 700 !important; }}
    .diff-pre .nx, .diff-pre .n, .diff-pre .na, .diff-pre .nv {{ color: var(--st-syn-ident) !important; }}
    .diff-pre .nf, .diff-pre .fm {{ color: var(--st-syn-fn) !important; }}
    .diff-pre .nc, .diff-pre .nn {{ color: var(--st-syn-cls) !important; font-weight: 600 !important; }}
    .diff-pre .s, .diff-pre .s1, .diff-pre .s2, .diff-pre .sa, .diff-pre .sb, .diff-pre .sc, .diff-pre .sd, .diff-pre .se, .diff-pre .sh, .diff-pre .si, .diff-pre .sx, .diff-pre .sr, .diff-pre .ss {{ color: var(--st-syn-str) !important; }}
    .diff-pre .m, .diff-pre .mi, .diff-pre .mf, .diff-pre .mh, .diff-pre .mo {{ color: var(--st-syn-num) !important; }}
    .diff-pre .c, .diff-pre .c1, .diff-pre .ch, .diff-pre .cm, .diff-pre .cp, .diff-pre .cpf, .diff-pre .cs {{ color: var(--st-syn-com) !important; font-style: italic !important; }}
    .diff-pre .o, .diff-pre .ow, .diff-pre .p {{ color: var(--st-syn-op) !important; }}
    .diff-pre .nb, .diff-pre .bp, .diff-pre .kc {{ color: var(--st-syn-bt) !important; font-weight: 600 !important; }}

    /* LeetCode Draggable Splitter Handle */
    #lc-split-gutter {{
        width: 10px !important;
        min-width: 10px !important;
        max-width: 10px !important;
        cursor: col-resize !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        z-index: 999 !important;
        user-select: none !important;
        position: relative !important;
        align-self: stretch !important;
        height: 100% !important;
        min-height: calc(100vh - 56px) !important;
        background: var(--st-bg) !important;
        border-left: 1px solid var(--st-border) !important;
        border-right: 1px solid var(--st-border) !important;
        margin: 0 -1px !important;
        padding: 0 !important;
        touch-action: none !important;
        flex-shrink: 0 !important;
        transition: background 0.15s ease !important;
    }}
    #lc-split-gutter:hover,
    #lc-split-gutter.dragging {{
        background: var(--st-accent) !important;
    }}
    .lc-gutter-bar {{
        width: 2px !important;
        height: 100% !important;
        background: var(--st-border) !important;
        pointer-events: none !important;
        position: absolute !important;
        top: 0 !important;
        bottom: 0 !important;
        left: 50% !important;
        transform: translateX(-50%) !important;
    }}
    .lc-gutter-handle {{
        width: 24px !important;
        height: 24px !important;
        border-radius: 50% !important;
        background: var(--st-handle-bg) !important;
        border: 1px solid var(--st-handle-border) !important;
        color: var(--st-handle-color) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) !important;
        z-index: 1000 !important;
        pointer-events: none !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3) !important;
        transition: all 0.2s ease !important;
    }}
    #lc-split-gutter:hover .lc-gutter-handle,
    #lc-split-gutter.dragging .lc-gutter-handle {{
        background: var(--st-accent) !important;
        border-color: var(--st-accent) !important;
        color: #ffffff !important;
        box-shadow: 0 0 12px var(--st-accent) !important;
        transform: translate(-50%, -50%) scale(1.15) !important;
    }}
    </style>
    """, unsafe_allow_html=True)

    # Session reset when a new/different file is loaded
    audit_file_key = f"audit_{active_name}_{lines}"
    if st.session_state.get('current_audit_key') != audit_file_key:
        st.session_state['current_audit_key'] = audit_file_key
        st.session_state.pop('audit_results', None)
        st.session_state.pop('initial_audit_results', None)
        st.session_state.pop('original_audit', None)
        st.session_state.pop('verification_result', None)
        st.session_state.pop('modified_code', None)
        st.session_state.pop('editor_code', None)
        st.session_state.pop('code_editor_area', None)
        st.session_state.pop('current_findings', None)
        st.session_state.pop('edit_mode', None)
        st.session_state.pop('active_view', None)

    inference = load_inference_engine()

    current_code = st.session_state.get('editor_code', code_content)
    cur_lines    = current_code.count('\n') + 1
    has_audit    = 'audit_results' in st.session_state
    has_verif    = 'verification_result' in st.session_state
    in_edit      = st.session_state.get('edit_mode', False)
    active_view  = st.session_state.get('active_view', 'verification' if has_verif else 'audit')

    # Top Workspace Minimal Brand Bar with Theme Toggle & Home Button
    nav_c1, nav_theme, nav_c2 = st.columns([0.76, 0.12, 0.12], gap="small")
    with nav_c1:
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:10px;padding:2px 4px;margin-bottom:2px;">
            <span style="font-weight:800;font-size:0.92rem;color:var(--st-text);display:inline-flex;align-items:center;gap:6px;">
                <i class="ti ti-shield-code" style="color:var(--st-accent);font-size:1.1rem;"></i> NLP CODE AUDITOR
            </span>
            <span style="color:var(--st-text-muted);font-size:0.85rem;">/</span>
            <span style="font-size:0.82rem;font-weight:650;color:var(--st-text-secondary);background:var(--st-header);border:1px solid var(--st-border);border-radius:6px;padding:2px 8px;display:inline-flex;align-items:center;gap:5px;">
                <i class="ti ti-file-code" style="color:var(--st-accent);"></i> {active_name}
            </span>
            <span style="font-size:0.74rem;font-weight:700;border-radius:20px;padding:2px 10px;background:{'rgba(5, 150, 105, 0.15)' if has_audit else 'var(--st-header)'};color:{'#10b981' if has_audit else 'var(--st-text-muted)'};border:1px solid {'rgba(16, 185, 129, 0.4)' if has_audit else 'var(--st-border)'};">
                {'🛡️ Audit Active' if has_audit else '⚡ Ready'}
            </span>
        </div>
        """, unsafe_allow_html=True)
    with nav_theme:
        theme_btn_label = "☀️ Light" if is_dark else "🌙 Dark"
        if st.button(theme_btn_label, use_container_width=True, key="btn_theme_toggle", help="Switch between Dark and Light mode"):
            st.session_state['studio_theme'] = 'light' if is_dark else 'dark'
            st.rerun()
    with nav_c2:
        if st.button("🏠 Home", use_container_width=True, key="btn_exit_home", help="Return to home screen"):
            st.session_state['active_code'] = None
            st.session_state['active_file_name'] = None
            st.session_state['active_language'] = None
            st.session_state.pop('audit_results', None)
            st.session_state.pop('initial_audit_results', None)
            st.session_state.pop('original_audit', None)
            st.session_state.pop('verification_result', None)
            st.session_state.pop('editor_code', None)
            st.session_state.pop('code_editor_area', None)
            st.session_state.pop('current_findings', None)
            st.session_state.pop('edit_mode', None)
            st.session_state.pop('active_view', None)
            st.rerun()

    # Determine findings to highlight on source lines
    if 'current_findings' in st.session_state:
        display_findings = st.session_state['current_findings']
    elif 'audit_results' in st.session_state:
        display_findings = st.session_state['audit_results'].get('findings', [])
    elif 'original_audit' in st.session_state:
        display_findings = st.session_state['original_audit'].get('findings', [])
    else:
        display_findings = []

    vuln_lines = sorted({f.get('line', 0) for f in display_findings if f.get('line', 0) > 0})
    sev_map = {}
    for f in display_findings:
        ln = f.get('line', 0)
        sv = f.get('severity', 'LOW').upper()
        if ln > 0:
            if ln not in sev_map or {'HIGH': 2, 'MEDIUM': 1, 'LOW': 0}.get(sv, 0) > {'HIGH': 2, 'MEDIUM': 1, 'LOW': 0}.get(sev_map[ln], 0):
                sev_map[ln] = sv

    ref_chips = ""
    for ln in vuln_lines[:16]:
        sv = sev_map.get(ln, 'LOW')
        color_map = {'HIGH': 'var(--danger)', 'MEDIUM': 'var(--warning)', 'LOW': 'var(--accent)'}
        bg_map    = {'HIGH': 'var(--danger-bg)', 'MEDIUM': 'var(--warning-bg)', 'LOW': 'var(--accent-bg)'}
        c  = color_map.get(sv, 'var(--accent)')
        bg = bg_map.get(sv, 'var(--accent-bg)')
        ref_chips += (
            f'<span style="background:{bg};border:1px solid {c}55;border-radius:4px;'
            f'padding:1px 6px;font-size:0.7rem;font-family:var(--mono);color:{c};font-weight:700;'
            f'display:inline-block;margin-right:3px;">L{ln}</span>'
        )
    if len(vuln_lines) > 16:
        ref_chips += f'<span style="font-size:0.68rem;color:var(--ink-faint);">+{len(vuln_lines)-16}</span>'
    chips_html = ref_chips if ref_chips else '<span style="font-size:0.7rem;color:var(--success);font-weight:600;">✓ Clean</span>'

    # ══════════════════════════════════════════════════════════
    # TWO-COLUMN SPLIT: LEFT (PARTS 1 & 2) VS RIGHT (PARTS 3, 4, 5 & 6)
    # ══════════════════════════════════════════════════════════
    col_code, col_results = st.columns([50, 50], gap=None)

    # ──────────────────────────────────────────────────────────
    # LEFT PANE: PART 2 (HEADER & RUN AUDIT) + PART 1 (CODE EDITOR)
    # ──────────────────────────────────────────────────────────
    with col_code:
        st.markdown('<div id="lc-col-left-anchor" style="display:none;"></div>', unsafe_allow_html=True)

        # ── PART 2: Left Header Bar (Code, Language, File Name, Lines, Run Audit button) ──
        p2_meta, p2_btn = st.columns([0.74, 0.26], gap="small")
        with p2_meta:
            st.markdown(f"""
            <div class="part2-header-container">
                <div style="display:flex;align-items:center;gap:6px;overflow:hidden;">
                    <span class="part2-code-tab"><i class="ti ti-code"></i> Code</span>
                    <span class="part2-file-tab">
                        <i class="ti ti-file-code" style="color:var(--st-accent);"></i>
                        <span class="part2-file-title">{active_name}</span>
                        <span class="part2-file-close">✕</span>
                    </span>
                </div>
                <div style="display:flex;align-items:center;gap:6px;">
                    <span class="part2-lang-dropdown">
                        <span>{language.capitalize()}</span>
                        <i class="ti ti-chevron-down" style="font-size:0.7rem;margin-left:2px;"></i>
                    </span>
                    <span class="part2-lines">{cur_lines} lines</span>
                    <div style="display:flex;align-items:center;gap:4px;">
                        <span style="font-size:0.68rem;font-weight:600;color:var(--st-text-muted);">Flagged:</span>
                        {chips_html}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        with p2_btn:
            run_audit_clicked = st.button("▶ Run Audit", type="primary", use_container_width=True, key="btn_run_audit", help="Run multi-agent security audit on current code")

        if run_audit_clicked:
            scan_code = st.session_state.get('code_editor_area') or code_content
            if not has_audit:
                # Initial security audit
                fresh = {}
                ext = os.path.splitext(active_name)[1].lower() or '.py'
                with tempfile.NamedTemporaryFile(delete=False, suffix=ext, mode='w', encoding='utf-8') as tmp:
                    tmp.write(scan_code)
                    tmp_path = tmp.name

                try:
                    with st.spinner("Analyzing code with multi-agent security audit..."):
                        with measure_energy(sample_interval_s=0.2) as col:
                            col.begin_phase("Guardrail & AST")
                            from src.security_guardrail import SecurityGuardrailAgent
                            guard = SecurityGuardrailAgent()
                            guard_report = guard.inspect_and_defang(scan_code)
                            fresh['guard_report'] = guard_report

                            ast_parser        = ASTParser()
                            feature_extractor = FeatureExtractor()
                            tree     = ast_parser.parse(scan_code, language)
                            features = feature_extractor.extract_features(tree, scan_code, language)
                            features['lang']       = language
                            features['line_count'] = scan_code.count('\n') + 1
                            fresh['features'] = features
                            col.end_phase()

                            col.begin_phase("Semgrep Scan")
                            scanner = Scanner()
                            findings, risk_score = scanner.scan_file(tmp_path)
                            fresh['findings']   = findings
                            fresh['risk_score'] = risk_score
                            col.end_phase()

                            col.begin_phase("Prompt Engine")
                            enricher = PromptEnricher()
                            prompt   = enricher.construct_prompt(findings, features, scan_code)
                            col.end_phase()

                            col.begin_phase("CodeT5 Gen")
                            summary = inference.generate_summary(prompt)
                            summary = PromptEnricher.enrich_summary(summary, features)
                            fresh['summary'] = summary
                            col.end_phase()

                        reports_dir = os.path.join(os.path.dirname(__file__), "frontend", "public", "reports")
                        os.makedirs(reports_dir, exist_ok=True)
                        with open(os.path.join(reports_dir, "latest_report.json"), "w") as f:
                            json.dump(col.report.to_dict(), f)

                except Exception as e:
                    st.error(f"Pipeline error: {e}")
                    st.stop()
                finally:
                    try: os.unlink(tmp_path)
                    except: pass

                st.session_state['audit_results'] = fresh
                st.session_state['initial_audit_results'] = dict(fresh)
                st.session_state['original_audit'] = {
                    'source':     scan_code,
                    'language':   language,
                    'findings':   fresh['findings'],
                    'risk_score': fresh['risk_score'],
                }
                st.session_state['current_findings'] = fresh['findings']
                st.session_state['editor_code']      = scan_code
                st.session_state['code_editor_area'] = scan_code
                st.session_state['active_view']      = 'audit'
                st.session_state.pop('verification_result', None)
                st.toast("✅ Full Security Audit Complete!", icon="🛡️")
                st.rerun()
            else:
                # Re-Audit in loop
                if execute_full_reaudit(scan_code, active_name, language, inference):
                    st.toast("✅ Re-Audit Complete! Updated summary, vulnerabilities, and remediations.", icon="🛡️")
                    st.rerun()

        # ── PART 1: LeetCode Code Editor (Colors, Line Numbers, Directly Editable) ──
        num_lines = max(len(current_code.splitlines()), 1)
        gutter_rows = []
        for i in range(1, num_lines + 1):
            sev = sev_map.get(i)
            if sev == 'HIGH':
                dot = '<span class="g-dot-high">●</span>'
                cls = "gutter-line g-vuln-high"
            elif sev == 'MEDIUM':
                dot = '<span class="g-dot-med">◆</span>'
                cls = "gutter-line g-vuln-med"
            elif sev == 'LOW':
                dot = '<span class="g-dot-low">▸</span>'
                cls = "gutter-line g-vuln-low"
            else:
                dot = ''
                cls = "gutter-line"
            gutter_rows.append(f'<div class="{cls}"><span class="g-num">{i}</span>{dot}</div>')
        gutter_html = f'<div id="editor-gutter-lines" class="code-gutter-scroll">{"".join(gutter_rows)}</div>'

        col_gut, col_ta = st.columns([1.1, 14.9], gap=None)
        with col_gut:
            st.markdown(gutter_html, unsafe_allow_html=True)
        with col_ta:
            edited_text = st.text_area(
                label="code_editor",
                value=current_code,
                height=620,
                key="code_editor_area",
                label_visibility="collapsed",
                help="Directly edit code here with cursor. Click '▶ Run Audit' to re-audit."
            )
            st.session_state['editor_code'] = edited_text

        # Bottom IDE Status Bar
        st.markdown(f"""
        <div class="editor-status-bar">
          <div style="display:flex;align-items:center;gap:12px;">
            <span class="editor-status-item"><i class="ti ti-terminal-2" style="color:var(--st-accent);"></i> {language.capitalize()}</span>
            <span class="editor-status-item"><i class="ti ti-file-text"></i> UTF-8</span>
            <span class="editor-status-item"><i class="ti ti-shield-check" style="color:var(--success);"></i> Guardrail Active</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px;">
            <span class="editor-status-item" style="color:var(--st-accent);font-weight:600;"><i class="ti ti-cursor-text"></i> Live LeetCode Editor</span>
            <span class="editor-status-item">· Edit &amp; Run Audit</span>
          </div>
        </div>""", unsafe_allow_html=True)

    # ──────────────────────────────────────────────────────────
    # RIGHT PANE: LEETCODE TABS (INDEPENDENT INTERNAL SCROLL)
    # ──────────────────────────────────────────────────────────
    with col_results:
        st.markdown('<div id="lc-col-right-anchor" style="display:none;"></div>', unsafe_allow_html=True)
        tab_sum, tab_vuln, tab_fix = st.tabs([
            "🧠 Code Summary",
            "🛡️ Vulnerabilities",
            "🛠️ Remediation"
        ])

        # ── TAB 1: CODE SUMMARIZATION (Executive Intent, Flow, Function Contracts) ──
        with tab_sum:
            if not has_audit:
                st.markdown("""
                <div style="text-align:center;padding:50px 20px;color:var(--st-text-muted);background:var(--st-card);border:1px solid var(--st-border);border-radius:var(--radius);">
                    <i class="ti ti-brain" style="font-size:2.8rem;color:var(--st-accent);display:block;margin-bottom:12px;"></i>
                    <div style="font-weight:700;font-size:1.05rem;color:var(--st-text);">Code Understanding Agent Ready</div>
                    <div style="font-size:0.86rem;margin-top:6px;line-height:1.5;color:var(--st-text-secondary);">
                        Click <b style="color:var(--st-accent);">▶ Run Audit</b> on the left to extract the AST architecture, 
                        map system logic, and generate operational contracts.
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                results = st.session_state['audit_results']
                raw_summary = results.get('summary', '').replace("<!-- engine: agent -->", "").strip()
                is_agent_generated = bool(os.getenv("GEMINI_API_KEY", "").strip())
                if is_agent_generated:
                    engine_pill = '<span style="display:inline-flex;align-items:center;gap:6px;background:rgba(52,211,153,0.15);border:1px solid rgba(52,211,153,0.4);border-radius:20px;padding:2px 10px;font-size:0.72rem;font-weight:700;color:var(--success);"><i class="ti ti-sparkles"></i> Gemini Flash</span>'
                else:
                    engine_pill = '<span style="display:inline-flex;align-items:center;gap:6px;background:var(--st-card-header);border:1px solid var(--st-border);border-radius:20px;padding:2px 10px;font-size:0.72rem;font-weight:600;color:var(--st-text-muted);"><i class="ti ti-cpu"></i> CodeT5 Local</span>'

                import re as _re
                import html as _html
                def _render_body(body_text, accent_color):
                    def _inline_code(text):
                        return _re.sub(
                            r'`([^`]+)`',
                            lambda m: (
                                f'<code style="background:var(--st-card-header);border:1px solid var(--st-border);border-radius:3px;'
                                f'padding:1px 5px;font-size:0.82rem;font-family:var(--mono);color:var(--st-accent);">'
                                f'{_html.escape(m.group(1))}</code>'
                            ),
                            text
                        )
                    lines_arr = body_text.strip().splitlines()
                    html_parts = []
                    for line in lines_arr:
                        line = line.strip()
                        if not line:
                            continue
                        if line.startswith(('-', '*', '•')):
                            item = line.lstrip('-*•').strip()
                            if ' — ' in item:
                                fn_part, desc_part = item.split(' — ', 1)
                                item_html = _inline_code(fn_part) + f' <span style="color:var(--st-text-muted);">—</span> ' + _inline_code(desc_part)
                            else:
                                item_html = _inline_code(item)
                            html_parts.append(
                                f'<div style="display:flex;align-items:flex-start;gap:8px;'
                                f'margin-bottom:6px;padding:6px 10px;background:var(--st-card-header);'
                                f'border-radius:6px;border:1px solid var(--st-border);border-left:3px solid {accent_color};">'
                                f'<span style="width:6px;height:6px;min-width:6px;border-radius:1px;'
                                f'background:{accent_color};margin-top:6px;flex-shrink:0;'
                                f'display:inline-block;"></span>'
                                f'<span style="font-size:0.85rem;line-height:1.55;color:var(--st-text-secondary);">'
                                f'{item_html}</span>'
                                f'</div>'
                            )
                        else:
                            html_parts.append(
                                f'<p style="font-size:0.88rem;line-height:1.6;color:var(--st-text-secondary);'
                                f'margin:0 0 6px 0;">{_inline_code(_html.escape(line))}</p>'
                            )
                    return ''.join(html_parts) if html_parts else '<span style="color:var(--st-text-muted);font-style:italic;font-size:0.84rem;">Not available</span>'

                section_pattern = _re.compile(r'###\s+(.+?)(?=\n###|\Z)', _re.DOTALL)
                parsed = {}
                for s in section_pattern.findall(raw_summary):
                    lines_s = s.strip().splitlines()
                    if lines_s:
                        title = lines_s[0].strip()
                        body  = '\n'.join(lines_s[1:]).strip()
                        parsed[title] = body

                overview_text  = parsed.get('Overview') or (raw_summary if raw_summary else 'This program executes application logic.')
                behavior_text  = parsed.get('Key Behavior', '')
                functions_text = parsed.get('Key Functions', '')

                # 1. Executive Intent & Architecture Box
                st.markdown(f"""
                <div class="lc-box" style="border-top:3px solid var(--st-accent);">
                  <div class="lc-box-header">
                    <div class="lc-box-title">
                      <i class="ti ti-layout-dashboard" style="color:var(--st-accent);font-size:0.95rem;"></i>
                      <span>Executive Intent &amp; System Architecture</span>
                    </div>
                    {engine_pill}
                  </div>
                  <div class="lc-box-body">
                    {_html.escape(overview_text)}
                  </div>
                </div>
                """, unsafe_allow_html=True)

                # 2. Operational Flow & Data Behavior Box
                st.markdown(f"""
                <div class="lc-box" style="border-top:3px solid var(--warning);">
                  <div class="lc-box-header">
                    <div class="lc-box-title">
                      <i class="ti ti-activity" style="color:var(--warning);font-size:0.95rem;"></i>
                      <span>Operational Flow &amp; Data Behavior</span>
                    </div>
                  </div>
                  <div class="lc-box-body">
                    {_render_body(behavior_text, 'var(--warning)')}
                  </div>
                </div>
                """, unsafe_allow_html=True)

                # 3. Function Contract Matrix Box
                st.markdown(f"""
                <div class="lc-box" style="border-top:3px solid var(--success);">
                  <div class="lc-box-header">
                    <div class="lc-box-title">
                      <i class="ti ti-code" style="color:var(--success);font-size:0.95rem;"></i>
                      <span>Function Contract Matrix &amp; Boundaries</span>
                    </div>
                  </div>
                  <div class="lc-box-body">
                    {_render_body(functions_text, 'var(--success)')}
                  </div>
                </div>
                """, unsafe_allow_html=True)

                # 4. AST Features Box (Sources, Sinks, Complexity)
                with st.expander("Technical Details — AST Feature Extraction", expanded=False):
                    feat = results.get('features', {})
                    fa, fb = st.columns(2)
                    with fa:
                        st.markdown("<div style='font-size:0.78rem;font-weight:600;color:var(--st-text-muted);margin-bottom:4px;'><i class='ti ti-database-import'></i> Data Sources</div>", unsafe_allow_html=True)
                        render_tags(feat.get('sources', []), "source")
                    with fb:
                        st.markdown("<div style='font-size:0.78rem;font-weight:600;color:var(--st-text-muted);margin-bottom:4px;'><i class='ti ti-skull'></i> Dangerous Sinks</div>", unsafe_allow_html=True)
                        render_tags(feat.get('sinks', []), "sink")
                    complexity = feat.get('complexity', 0)
                    st.markdown(f"""
                    <div class="lc-inner-box" style="margin-top:10px;display:flex;align-items:center;gap:14px;padding:10px 14px;">
                        <i class="ti ti-git-branch" style="font-size:1.5rem;color:var(--st-accent);flex-shrink:0;"></i>
                        <div>
                            <div style="font-size:0.68rem;color:var(--st-text-muted);text-transform:uppercase;letter-spacing:1px;">Cyclomatic Complexity</div>
                            <div style="font-size:1.5rem;font-weight:800;color:var(--st-text);">{complexity}</div>
                        </div>
                    </div>""", unsafe_allow_html=True)

            # tab end

        # ── TAB 2: VULNERABILITIES & AUDIT (Risk Gauge, Guardrail, Orchestrator, Semgrep Findings) ──
        with tab_vuln:
            if not has_audit:
                st.markdown("""
                <div style="text-align:center;padding:50px 20px;color:var(--st-text-muted);background:var(--st-card);border:1px solid var(--st-border);border-radius:var(--radius);">
                    <i class="ti ti-shield-search" style="font-size:2.8rem;color:var(--st-accent);display:block;margin-bottom:12px;"></i>
                    <div style="font-weight:700;font-size:1.05rem;color:var(--st-text);">Security Guardrail &amp; Scanner Ready</div>
                    <div style="font-size:0.86rem;margin-top:6px;line-height:1.5;color:var(--st-text-secondary);">
                        Click <b style="color:var(--st-accent);">▶ Run Audit</b> on the left to scan for vulnerabilities, 
                        establish risk scores, and triage taint paths.
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                results = st.session_state['audit_results']
                # Guardrail Telemetry Alert / Clean Assurance
                guard_rep = results.get('guard_report')
                if guard_rep:
                    if not guard_rep.get('is_clean', True):
                        n_threats = guard_rep.get('incident_count', len(guard_rep.get('threats_detected', [])))
                        st.markdown(f"""
                        <div style="background:linear-gradient(135deg, rgba(239,68,68,0.14) 0%, rgba(239,68,68,0.06) 100%);border:1px solid rgba(239,68,68,0.4);border-left:4px solid var(--danger);border-radius:var(--radius);padding:8px 14px;margin-bottom:8px;box-shadow:var(--shadow-sm);">
                            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                                <div style="font-weight:750;font-size:0.84rem;color:var(--danger);display:flex;align-items:center;gap:6px;">
                                    <i class="ti ti-shield-alert" style="font-size:1.05rem;"></i>
                                    <span>SecurityGuardrail: {guard_rep.get('threats_detected', [{}])[0].get('category', 'PROMPT_INJECTION').replace('_', ' ').title()} Neutralized!</span>
                                </div>
                                <span style="font-size:0.7rem;font-weight:700;background:rgba(239,68,68,0.2);color:var(--danger);padding:2px 8px;border-radius:20px;">
                                    {n_threats} Adversarial Exploit{'s' if n_threats!=1 else ''} Defanged
                                </span>
                            </div>
                            <div style="font-size:0.77rem;color:var(--st-text-secondary);margin-top:4px;">
                                Cryptographic nonce isolation &amp; AST canonicalization actively defanged inbound prompt injection payload before reaching code intelligence engines.
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        st.markdown("""
                        <div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-left:4px solid var(--success);border-radius:var(--radius);padding:6px 12px;font-size:0.78rem;font-weight:600;color:var(--success);display:flex;align-items:center;gap:6px;margin-bottom:8px;">
                            <i class="ti ti-shield-check" style="font-size:0.84rem;"></i> SecurityGuardrail: Input Sandboxed (0 Adversarial Threats)
                        </div>
                        """, unsafe_allow_html=True)

                # Risk Gauge + Metric Cards Box
                st.markdown("""
                <div class="lc-box" style="margin-bottom:6px;">
                    <div class="lc-box-header" style="padding:6px 12px;font-size:0.78rem;">
                        <div class="lc-box-title">
                            <i class="ti ti-chart-bar" style="color:var(--st-accent);"></i>
                            <span>Security Risk Distribution &amp; Flaw Count</span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

                g_col1, g_col2 = st.columns([1, 1])
                with g_col1:
                    render_gauge(results['risk_score'], "Risk Score")
                with g_col2:
                    from src.vuln_classifier import normalize_severity
                    sev_counts = {'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
                    for f in results['findings']:
                        s = normalize_severity(f.get('severity', 'INFO')).upper()
                        sev_counts[s] = sev_counts.get(s, 0) + 1

                    m1, m2 = st.columns(2)
                    with m1:
                        st.markdown(f"""<div class="metric-card" style="padding:6px 8px;margin-bottom:4px;"><div class="metric-value" style="font-size:1.35rem;">{len(results['findings'])}</div><div class="metric-label" style="font-size:0.65rem;">Total</div></div>""", unsafe_allow_html=True)
                    with m2:
                        st.markdown(f"""<div class="metric-card" style="padding:6px 8px;margin-bottom:4px;"><div class="metric-value" style="color:var(--danger);font-size:1.35rem;">{sev_counts.get('HIGH',0)}</div><div class="metric-label" style="font-size:0.65rem;">High</div></div>""", unsafe_allow_html=True)
                    m3, m4 = st.columns(2)
                    with m3:
                        st.markdown(f"""<div class="metric-card" style="padding:6px 8px;"><div class="metric-value" style="color:var(--warning);font-size:1.35rem;">{sev_counts.get('MEDIUM',0)}</div><div class="metric-label" style="font-size:0.65rem;">Medium</div></div>""", unsafe_allow_html=True)
                    with m4:
                        st.markdown(f"""<div class="metric-card" style="padding:6px 8px;"><div class="metric-value" style="color:var(--st-accent);font-size:1.35rem;">{sev_counts.get('LOW',0)}</div><div class="metric-label" style="font-size:0.65rem;">Low</div></div>""", unsafe_allow_html=True)

                # Strategic Audit Directive from AnalysisOrchestratorAgent Box
                from src.orchestrator_agent import AnalysisOrchestratorAgent
                orch_agent = AnalysisOrchestratorAgent()
                orch_plan = orch_agent.orchestrate_audit(
                    features=results.get('features', {}),
                    findings=results.get('findings', []),
                    risk_score=results.get('risk_score', 0.0),
                    summary_text=results.get('summary', ''),
                    language=language
                )

                st.markdown(f"""
                <div class="lc-box" style="border-top:3px solid {orch_plan['health_badge_color']};margin-top:6px;margin-bottom:8px;">
                    <div class="lc-box-header" style="padding:6px 12px;font-size:0.78rem;">
                        <div class="lc-box-title">
                            <i class="ti ti-compass" style="color:{orch_plan['health_badge_color']};"></i>
                            <span>AnalysisOrchestrator Directive</span>
                        </div>
                        <span style="background:{orch_plan['health_badge_color']}18;border:1px solid {orch_plan['health_badge_color']}66;
                                     color:{orch_plan['health_badge_color']};border-radius:20px;padding:1px 8px;font-size:0.68rem;font-weight:700;">
                            {orch_plan['health_grade']}
                        </span>
                    </div>
                    <div class="lc-box-body" style="padding:8px 12px;">
                        <div style="font-size:0.82rem;line-height:1.45;color:var(--st-text-secondary);margin-bottom:6px;">{orch_plan['verdict']}</div>
                        <div style="font-size:0.72rem;color:var(--st-text-muted);display:flex;gap:10px;flex-wrap:wrap;">
                            <span class="lc-tag"><b>Exposure Ratio:</b> {orch_plan['exposure_ratio']}</span>
                            <span class="lc-tag"><b>Cyclomatic Complexity:</b> {orch_plan['cyclomatic_complexity']}</span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

                # Detected Findings List Box
                st.markdown(f"""
                <div class="lc-box" style="margin-top:6px;margin-bottom:8px;">
                    <div class="lc-box-header" style="padding:6px 12px;font-size:0.78rem;">
                        <div class="lc-box-title">
                            <i class="ti ti-alert-triangle" style="color:var(--danger);"></i>
                            <span>Detected Flaws &amp; Security Findings ({len(results['findings'])})</span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                if results['findings']:
                    for f in results['findings']:
                        render_finding(f)
                else:
                    st.markdown("""<div class="finding-card finding-LOW">
                        <div class="finding-header" style="color:var(--success);"><i class="ti ti-shield-check"></i> CLEAN</div>
                        <div class="finding-msg">No vulnerabilities detected. All security checks passed.</div>
                    </div>""", unsafe_allow_html=True)

            # tab end

        # ── TAB 3: REMEDIATION & TEACHING (FixTemplateAgent Context-Aware Diffs & 1-Click Patch) ──
        with tab_fix:
            if not has_audit:
                st.markdown("""
                <div style="text-align:center;padding:50px 20px;color:var(--st-text-muted);background:var(--st-card);border:1px solid var(--st-border);border-radius:var(--radius);">
                    <i class="ti ti-tools" style="font-size:2.8rem;color:var(--st-accent);display:block;margin-bottom:12px;"></i>
                    <div style="font-weight:700;font-size:1.05rem;color:var(--st-text);">Autonomous Remediation Ready</div>
                    <div style="font-size:0.86rem;margin-top:6px;line-height:1.5;color:var(--st-text-secondary);">
                        Click <b style="color:var(--st-accent);">▶ Run Audit</b> on the left to generate context-aware AST patches 
                        and remediation guidance.
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                results = st.session_state['audit_results']
                from src.fix_agent import FixTemplateAgent
                fix_agent = FixTemplateAgent()
                grouped_remediations = fix_agent.analyze_and_remediate(
                    results['findings'], current_code, language, results.get('features', {})
                )

                if grouped_remediations:
                    for i, item in enumerate(grouped_remediations):
                        cwe  = item['cwe']
                        cat  = item['category']
                        sev  = item['severity']
                        sc   = sev_color(sev)
                        lines_list = item['lines']
                        lines_str  = ", ".join(f"Line {ln}" for ln in lines_list)
                        exp  = item['explanation']
                        tch  = item['teaching']

                        # Master Finding Header Box
                        st.markdown(f"""
                        <div class="lc-box" style="margin-bottom:12px;">
                            <div class="lc-box-header" style="padding:8px 12px;">
                                <div class="lc-box-title" style="font-size:0.88rem;">
                                    <i class="ti ti-shield-alert" style="color:{sc};font-size:1.05rem;"></i>
                                    <span>Finding #{i+1}: <span style="color:var(--st-accent);">{cat}</span></span>
                                </div>
                                <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap;">
                                    <span class="tag tag-{sev}">{sev}</span>
                                    <span class="tag">{cwe}</span>
                                    <span class="tag" style="background:rgba(2,132,199,0.12);color:var(--st-accent);border-color:rgba(2,132,199,0.3);font-weight:600;">
                                        {lines_str}
                                    </span>
                                </div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)

                        # Taint Reachability & Exploitability Triage Box
                        reach = item.get('reachability')
                        if reach:
                            b_col = reach.get('badge_color', '#cf222e')
                            b_lbl = reach.get('badge_label', 'CONFIRMED EXPLOITABLE')
                            r_path = reach.get('reachability_path', '')
                            r_rat = reach.get('triage_rationale', '')
                            st.markdown(f"""
                            <div class="lc-inner-box" style="border-left:3px solid {b_col};margin-bottom:10px;">
                                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;margin-bottom:4px;">
                                    <div class="lc-inner-title" style="color:var(--st-text);margin-bottom:0;">
                                        <i class="ti ti-route" style="color:{b_col};"></i>
                                        <span>Taint Reachability Triage</span>
                                    </div>
                                    <span style="background:{b_col}18;color:{b_col};border:1px solid {b_col}55;border-radius:12px;padding:1px 8px;font-size:0.68rem;font-weight:700;">
                                        {b_lbl}
                                    </span>
                                </div>
                                <div style="font-size:0.82rem;color:var(--st-text-secondary);margin-bottom:3px;"><b>Dataflow:</b> {r_path}</div>
                                <div style="font-size:0.78rem;color:var(--st-text-muted);"><b>Rationale:</b> {r_rat}</div>
                            </div>
                            """, unsafe_allow_html=True)

                        # Security Diagnostic Assessment Box (What is wrong? & Why is it vulnerable?)
                        st.markdown(f"""
                        <div class="lc-inner-box" style="border-left:3px solid {sc};margin-bottom:10px;">
                            <div class="lc-inner-title" style="color:var(--st-text);margin-bottom:8px;">
                                <i class="ti ti-help-circle" style="color:{sc};"></i> Security Diagnostic Analysis
                            </div>
                            <div style="background:var(--st-card);border:1px solid var(--st-border);border-radius:6px;padding:8px 12px;margin-bottom:8px;">
                                <div style="font-weight:700;font-size:0.78rem;color:#dc2626;margin-bottom:3px;">
                                    <i class="ti ti-alert-triangle" style="margin-right:4px;"></i> What is wrong?
                                </div>
                                <div style="font-size:0.84rem;line-height:1.5;color:var(--st-text-secondary);">
                                    {exp.get('what_is_wrong', item.get('diagnosis', ''))}
                                </div>
                            </div>
                            <div style="background:var(--st-card);border:1px solid var(--st-border);border-radius:6px;padding:8px 12px;">
                                <div style="font-weight:700;font-size:0.78rem;color:#dc2626;margin-bottom:3px;">
                                    <i class="ti ti-flame" style="margin-right:4px;"></i> Why is it vulnerable?
                                </div>
                                <div style="font-size:0.84rem;line-height:1.5;color:var(--st-text-secondary);">
                                    {exp.get('why_is_it_vulnerable', '')}
                                </div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)

                        # Context-Aware Code Remediation Box (Responsive diff cards with horizontal scrollbar)
                        st.markdown("""
                        <div class="lc-inner-box" style="margin-bottom:8px;">
                            <div class="lc-inner-title" style="color:var(--st-text);margin-bottom:4px;">
                                <i class="ti ti-tool" style="color:var(--st-accent);"></i> Context-Aware Code Remediation
                            </div>
                        </div>
                        """, unsafe_allow_html=True)

                        for fidx, fx in enumerate(item['fixes'], 1):
                            before_code = fx.get('before', '')
                            after_code  = fx.get('after', '')
                            before_hl   = render_diff_code(before_code, language, is_dark=is_dark)
                            after_hl    = render_diff_code(after_code, language, is_dark=is_dark)

                            st.markdown(f"""
                            <div class="diff-patch-section">
                                <div class="diff-patch-caption">
                                    <i class="ti ti-git-commit" style="color:var(--st-accent);"></i>
                                    <span>Patch for <b>Line {fx['line']}</b>:</span>
                                </div>
                                <div class="remediation-diff-container">
                                    <div class="remediation-diff-card diff-before-card">
                                        <div class="remediation-diff-header diff-before-header">
                                            <span>❌ Before (Line {fx['line']}):</span>
                                            <span class="diff-before-badge">VULNERABLE</span>
                                        </div>
                                        <div class="diff-code-wrapper">
                                            <div class="diff-pre diff-before-pre">{before_hl}</div>
                                        </div>
                                    </div>
                                    <div class="remediation-diff-card diff-after-card">
                                        <div class="remediation-diff-header diff-after-header">
                                            <span>✅ After (Line {fx['line']}):</span>
                                            <span class="diff-after-badge">REMEDIATED</span>
                                        </div>
                                        <div class="diff-code-wrapper">
                                            <div class="diff-pre diff-after-pre">{after_hl}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)

                        # Defensive Principle & Beginner Takeaway Box
                        st.markdown(f"""
                        <div class="lc-inner-box" style="border-left:4px solid var(--st-accent);background:var(--st-card);margin-top:8px;margin-bottom:12px;padding:12px 16px;">
                            <div class="lc-inner-title" style="color:var(--st-accent);font-weight:750;font-size:0.82rem;margin-bottom:6px;">
                                <i class="ti ti-shield-check" style="font-size:1.1rem;"></i> DEFENSIVE PRINCIPLE
                            </div>
                            <div style="font-weight:750;color:var(--st-text);font-size:0.92rem;margin-bottom:6px;">
                                {tch.get('concept_name', cat)}: 
                                <span style="display:inline-block;background:var(--st-card-header);color:var(--st-accent);border:1px solid var(--st-border);border-radius:6px;padding:2px 8px;font-size:0.84rem;font-weight:700;font-family:var(--mono);">
                                    {item.get('defensive_principle', '')}
                                </span>
                            </div>
                            <div style="font-size:0.88rem;color:var(--st-text-secondary);line-height:1.6;font-weight:450;">{tch.get('what_to_learn', '')}</div>
                        </div>""", unsafe_allow_html=True)
                        if tch.get('beginner_takeaway'):
                            st.info(f"💡 **Beginner Takeaway:** {tch['beginner_takeaway']}")
                else:
                    st.success("🎉 All clean! No vulnerabilities require remediation.")

            # tab end

    # ══════════════════════════════════════════════════════════
    # INTERACTIVE DRAGGABLE DIVIDER (PART 6 RESIZER) & LEETCODE SYNTAX ENGINE
    # ══════════════════════════════════════════════════════════
    st.html(f"""
    <script>
    (function() {{
      window._studioVulnMap = {json.dumps(sev_map)};
      var isDarkTheme = {'true' if is_dark else 'false'};

      // 1. DRAGGABLE SPLIT RESIZER (INTERSECTION LINE BETWEEN LEFT & RIGHT)
      function initResizer() {{
        try {{
          var leftAnchor = document.getElementById('lc-col-left-anchor');
          var rightAnchor = document.getElementById('lc-col-right-anchor');
          if (!leftAnchor || !rightAnchor) {{
            setTimeout(initResizer, 100);
            return;
          }}

          var leftCol = leftAnchor.closest('[data-testid="column"]');
          var rightCol = rightAnchor.closest('[data-testid="column"]');
          if (!leftCol || !rightCol) {{
            setTimeout(initResizer, 100);
            return;
          }}

          var parentBlock = leftCol.parentElement;
          if (!parentBlock) return;

          var pRect = parentBlock.getBoundingClientRect();
          var topOffset = pRect.top > 0 ? pRect.top : 46;
          var availHeight = Math.max(window.innerHeight - topOffset - 6, 380);

          parentBlock.style.setProperty('display', 'flex', 'important');
          parentBlock.style.setProperty('flex-direction', 'row', 'important');
          parentBlock.style.setProperty('flex-wrap', 'nowrap', 'important');
          parentBlock.style.setProperty('gap', '0px', 'important');
          parentBlock.style.setProperty('align-items', 'stretch', 'important');
          parentBlock.style.setProperty('height', availHeight + 'px', 'important');
          parentBlock.style.setProperty('max-height', availHeight + 'px', 'important');
          parentBlock.style.setProperty('overflow', 'hidden', 'important');
          parentBlock.style.setProperty('width', '100%', 'important');

          function applyRatio(pct) {{
            if (pct < 18) pct = 18;
            if (pct > 82) pct = 82;

            leftCol.style.setProperty('flex', '0 0 calc(' + pct + '% - 5px)', 'important');
            leftCol.style.setProperty('width', 'calc(' + pct + '% - 5px)', 'important');
            leftCol.style.setProperty('max-width', 'calc(' + pct + '% - 5px)', 'important');
            leftCol.style.setProperty('min-width', '0px', 'important');
            leftCol.style.setProperty('height', '100%', 'important');
            leftCol.style.setProperty('max-height', '100%', 'important');
            leftCol.style.setProperty('overflow', 'hidden', 'important');

            var tabContentMaxH = Math.max(availHeight - 48, 300);

            rightCol.style.setProperty('flex', '0 0 calc(' + (100 - pct) + '% - 5px)', 'important');
            rightCol.style.setProperty('width', 'calc(' + (100 - pct) + '% - 5px)', 'important');
            rightCol.style.setProperty('max-width', 'calc(' + (100 - pct) + '% - 5px)', 'important');
            rightCol.style.setProperty('min-width', '0px', 'important');
            rightCol.style.setProperty('height', availHeight + 'px', 'important');
            rightCol.style.setProperty('max-height', availHeight + 'px', 'important');
            rightCol.style.setProperty('display', 'flex', 'important');
            rightCol.style.setProperty('flex-direction', 'column', 'important');
            rightCol.style.setProperty('overflow-y', 'auto', 'important');
            rightCol.style.setProperty('overflow-x', 'hidden', 'important');

            // Find all tab panels inside rightCol and enforce full scrolling
            var tabPanels = rightCol.querySelectorAll('[data-baseweb="tab-panel"], [data-testid="stTabPanel"]');
            for (var p = 0; p < tabPanels.length; p++) {{
              var panel = tabPanels[p];
              panel.style.setProperty('flex', '1 1 auto', 'important');
              panel.style.setProperty('min-height', '0px', 'important');
              panel.style.setProperty('max-height', tabContentMaxH + 'px', 'important');
              panel.style.setProperty('overflow-y', 'auto', 'important');
              panel.style.setProperty('overflow-x', 'hidden', 'important');
              panel.style.setProperty('box-sizing', 'border-box', 'important');
              panel.style.setProperty('overscroll-behavior-y', 'contain', 'important');
            }}
          }}

          var saved = localStorage.getItem('nlp_auditor_split_ratio');
          var currentRatio = saved ? parseFloat(saved) : 50;
          if (isNaN(currentRatio) || currentRatio < 18 || currentRatio > 82) currentRatio = 50;
          applyRatio(currentRatio);

          var existingGutter = document.getElementById('lc-split-gutter');
          if (!existingGutter || existingGutter.parentElement !== parentBlock) {{
            if (existingGutter) existingGutter.remove();

            var gutter = document.createElement('div');
            gutter.id = 'lc-split-gutter';
            gutter.title = 'Drag intersection line to resize panes (Double-click to reset 50/50)';
            gutter.innerHTML = `
              <div class="lc-gutter-bar"></div>
              <div class="lc-gutter-handle" title="Drag to resize panels (Double click to reset 50/50)">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
              </div>
            `;
            parentBlock.insertBefore(gutter, rightCol);

            var isDragging = false;
            gutter.addEventListener('mousedown', function(e) {{
              isDragging = true;
              document.body.style.setProperty('cursor', 'col-resize', 'important');
              document.body.style.setProperty('user-select', 'none', 'important');
              gutter.classList.add('dragging');
              e.preventDefault();
            }});

            document.addEventListener('mousemove', function(e) {{
              if (!isDragging) return;
              var rect = parentBlock.getBoundingClientRect();
              var offsetX = e.clientX - rect.left;
              var pct = (offsetX / rect.width) * 100;
              pct = Math.round(pct * 10) / 10;
              applyRatio(pct);
              localStorage.setItem('nlp_auditor_split_ratio', pct);
            }});

            document.addEventListener('mouseup', function() {{
              if (isDragging) {{
                isDragging = false;
                document.body.style.removeProperty('cursor');
                document.body.style.removeProperty('user-select');
                gutter.classList.remove('dragging');
              }}
            }});

            gutter.addEventListener('dblclick', function() {{
              applyRatio(50);
              localStorage.setItem('nlp_auditor_split_ratio', 50);
            }});
          }}
        }} catch(err) {{
          console.warn('Split resizer error:', err);
        }}
      }}

      // 2. LEETCODE SYNTAX HIGHLIGHTING & SYNC GUTTER ENGINE
      function initLeetCodeSyntax() {{
        try {{
          var ta = document.querySelector('[data-testid="stTextArea"] textarea');
          var gut = document.getElementById('editor-gutter-lines');
          if (!ta || !gut) {{
            setTimeout(initLeetCodeSyntax, 120);
            return;
          }}

          var base = ta.closest('[data-baseweb="textarea"]');
          if (!base) return;

          base.style.setProperty('position', 'relative', 'important');
          base.style.setProperty('background', isDarkTheme ? '#101623' : '#ffffff', 'important');

          var pre = document.getElementById('lc-syntax-underlay');
          if (!pre) {{
            pre = document.createElement('pre');
            pre.id = 'lc-syntax-underlay';
            pre.setAttribute('aria-hidden', 'true');
            base.insertBefore(pre, ta);
          }}

          pre.style.cssText = `
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: 100% !important;
            margin: 0 !important;
            padding: 10px 16px 40px 10px !important;
            box-sizing: border-box !important;
            font-family: 'JetBrains Mono', 'Fira Code', Consolas, 'Courier New', monospace !important;
            font-size: 0.84rem !important;
            line-height: 24px !important;
            letter-spacing: 0.15px !important;
            white-space: pre !important;
            word-wrap: normal !important;
            tab-size: 4 !important;
            pointer-events: none !important;
            z-index: 1 !important;
            background: transparent !important;
            border: none !important;
            overflow: hidden !important;
            color: ${{isDarkTheme ? '#f1f5f9' : '#0f172a'}} !important;
          `;

          ta.style.setProperty('position', 'relative', 'important');
          ta.style.setProperty('z-index', '2', 'important');
          ta.style.setProperty('background', 'transparent', 'important');
          ta.style.setProperty('color', 'transparent', 'important');
          ta.style.setProperty('caret-color', isDarkTheme ? '#38bdf8' : '#0284c7', 'important');

          function highlightSyntax(code) {{
            var h = code
              .replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;');

            var cKw  = isDarkTheme ? '#38bdf8' : '#0000ff';
            var cFn  = isDarkTheme ? '#facc15' : '#795e26';
            var cStr = isDarkTheme ? '#4ade80' : '#098658';
            var cCom = isDarkTheme ? '#6ee7b7' : '#57606a';
            var cNum = isDarkTheme ? '#c084fc' : '#098658';
            var cCls = isDarkTheme ? '#7dd3fc' : '#0550ae';
            var cBt  = isDarkTheme ? '#e879f9' : '#0550ae';
            var cOp  = isDarkTheme ? '#cbd5e1' : '#24292f';

            var tokens = [];
            function saveTok(s) {{
              tokens.push(s);
              return '___TOK_' + (tokens.length - 1) + '___';
            }}

            // 1. Strings & template literals
            h = h.replace(/(\"\"\"[\\s\\S]*?\"\"\"|\'\'\'[\\s\\S]*?\'\'\'|\"[^\"\\n\\\\]*(?:\\\\.[^\"\\n\\\\]*)*\"|\'[^\'\\n\\\\]*(?:\\\\.[^\'\\n\\\\]*)*\'|`[^`\\\\]*(?:\\\\.[^`\\\\]*)*`)/g, function(m) {{
              return saveTok('<span style="color:' + cStr + ';">' + m + '</span>');
            }});

            // 2. Comments (Python #, JS/Java/C // and /* ... */)
            h = h.replace(/(#[^\\n]*|\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/)/g, function(m) {{
              return saveTok('<span style="color:' + cCom + ';font-style:italic;">' + m + '</span>');
            }});

            // 3. Numbers
            h = h.replace(/\\b(0x[0-9a-fA-F]+|\\d+(?:\\.\\d+)?)\\b/g, function(m) {{
              return saveTok('<span style="color:' + cNum + ';">' + m + '</span>');
            }});

            // 4. Keywords
            var kw = /\\b(def|class|import|from|return|if|elif|else|for|while|try|except|finally|with|as|in|is|not|and|or|lambda|pass|break|continue|async|await|yield|raise|assert|global|nonlocal|function|const|let|var|switch|case|default|catch|throw|new|extends|super|this|typeof|instanceof|void|delete|public|private|protected|static|final|interface|enum|implements|throws|package|int|float|double|char|boolean|byte|short|long|struct|union|typedef|extern|volatile|register|sizeof|goto|include|define|ifdef|ifndef|endif)\\b/g;
            h = h.replace(kw, function(m) {{
              return saveTok('<span style="color:' + cKw + ';font-weight:700;">' + m + '</span>');
            }});

            // 5. Builtins & Booleans
            var bt = /\\b(True|False|None|true|false|null|undefined|self|cls|NaN|Infinity|printf|scanf|malloc|free|cout|cin|console|document|window|print|len|range|str|int|dict|list|set|tuple|open)\\b/g;
            h = h.replace(bt, function(m) {{
              return saveTok('<span style="color:' + cBt + ';font-weight:600;">' + m + '</span>');
            }});

            // 6. Classes
            h = h.replace(/\\b([A-Z][a-zA-Z0-9_]*)\\b/g, function(m) {{
              return saveTok('<span style="color:' + cCls + ';font-weight:600;">' + m + '</span>');
            }});

            // 7. Functions
            h = h.replace(/\\b([a-zA-Z_]\\w*)(?=\\s*\\()/g, function(m) {{
              return saveTok('<span style="color:' + cFn + ';">' + m + '</span>');
            }});

            // 8. Operators
            h = h.replace(/(&amp;&amp;|\\|\\||===|!==|==|!=|&lt;=|&gt;=|&lt;|&gt;|\\+|-|\\*|\\/|%|=|!|\\?|:)/g, function(m) {{
              return saveTok('<span style="color:' + cOp + ';">' + m + '</span>');
            }});

            for (var i = 0; i < tokens.length; i++) {{
              h = h.replace('___TOK_' + i + '___', tokens[i]);
            }}

            return h;
          }}

          function updateGutterLines() {{
            var linesArr = ta.value.split('\\n');
            var lineCount = Math.max(linesArr.length, 1);
            if (gut.children.length !== lineCount) {{
              var vulnMap = window._studioVulnMap || {{}};
              var rowsHtml = '';
              for (var i = 1; i <= lineCount; i++) {{
                var sv = vulnMap[i];
                var dot = '';
                var cls = 'gutter-line';
                if (sv === 'HIGH') {{
                  dot = '<span class="g-dot-high">●</span>';
                  cls = 'gutter-line g-vuln-high';
                }} else if (sv === 'MEDIUM') {{
                  dot = '<span class="g-dot-med">◆</span>';
                  cls = 'gutter-line g-vuln-med';
                }} else if (sv === 'LOW') {{
                  dot = '<span class="g-dot-low">▸</span>';
                  cls = 'gutter-line g-vuln-low';
                }}
                rowsHtml += '<div class="' + cls + '"><span class="g-num">' + i + '</span>' + dot + '</div>';
              }}
              gut.innerHTML = rowsHtml;
            }}
          }}

          function syncEditor() {{
            pre.innerHTML = highlightSyntax(ta.value) + '\\n ';
            pre.scrollTop = ta.scrollTop;
            pre.scrollLeft = ta.scrollLeft;
            gut.scrollTop = ta.scrollTop;
            updateGutterLines();
          }}

          ta.removeEventListener('input', syncEditor);
          ta.addEventListener('input', syncEditor);

          ta.removeEventListener('scroll', syncEditor);
          ta.addEventListener('scroll', syncEditor, {{ passive: true }});

          gut.removeEventListener('wheel', handleGutterWheel);
          function handleGutterWheel(e) {{
            ta.scrollTop += e.deltaY;
          }}
          gut.addEventListener('wheel', handleGutterWheel, {{ passive: true }});

          syncEditor();
        }} catch(err) {{
          console.warn('Syntax editor error:', err);
        }}
      }}

      setTimeout(function() {{
        initResizer();
        initLeetCodeSyntax();
      }}, 50);

      setInterval(function() {{
        initResizer();
        initLeetCodeSyntax();
      }}, 800);
    }})();
    </script>
    """, unsafe_allow_javascript=True)
