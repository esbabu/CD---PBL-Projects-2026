# NLP-Based Code Summarizer with Security Audits

**Authors: Sri Cheran (25CSB1A34) & Sai Vara Prasad (25CSB1A43)**  
*Department of Computer Science & Engineering | Theory of Automata & Compiler Design*

An intelligent developer security copilot that combines Abstract Syntax Tree (AST) parsing, dual-engine static analysis, and a **multi-agent pipeline** to reverse-engineer software architectures, autonomously triage security vulnerabilities, defend against adversarial prompt injections, generate concrete code-level remediations with 1-click in-browser patch execution, and verify fixes in real time. Supports Python, Java, JavaScript, and C.

---

## Multi-Agent Architecture & Pipeline Overview

The application coordinates dedicated autonomous agents across a secure, multi-stage analysis and remediation workflow:

```
[Uploaded Source Code (.py, .js, .java, .c)]
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│ [Perimeter Defense] SecurityGuardrailAgent                  │
│ • Unicode NFKD Canonicalization & Zero-Width Stripping      │
│ • OWASP LLM01 Indirect Prompt Injection Detection           │
│ • Delimiter Sandboxing (<untrusted_code_boundary nonce="...">)│
│ • Canary Token Leakage Detection & Fail-Closed Defense      │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ [Stage 1] Perception & Static Scanning                      │
│ • Tree-sitter AST Parser & Feature Extractor                │
│   (AST tree, Cyclomatic Complexity, Data Sources & Sinks)   │
│ • Dual-Engine Scanner: Semgrep CLI + 12 Local AST Detectors │
│   (Vulnerability findings, CWE classification & risk score) │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ├──────────────────────────────────────────────────────┐
                       ▼                                                      ▼
┌──────────────────────────────────────────────┐    ┌──────────────────────────────────────────────┐
│ [Stage 2] Architectural Comprehension        │    │ Strategic Audit Directive & Priority Triage  │
│ 🤖 Agent 1: CodeUnderstandingAgent           │    │ 🛡️ Agent 3: AnalysisOrchestratorAgent        │
│ • AST Grounding Toolkit (zero hallucination) │    │ • Multi-source correlation:                  │
│ • Gemini Flash reasoning (or CodeT5 fallback)│    │   AST Complexity + Input Ingress + Sinks     │
│ • Self-Validation post-processing            │    │ • Utility-Based Priority Scoring             │
│ • 3-Tier Structured Report:                  │    │ • Outputs: Health Grade (Grade A+ to F)      │
│   1. Executive Intent & Architecture         │    │   & Ranked Action Directives (#1, #2, ...)   │
│   2. Operational Flow & Data Behavior        │    └──────────────────────┬───────────────────────┘
│   3. Function Contract Matrix (100% coverage)│                           │
└──────────────────────┬───────────────────────┘                           │
                       │                                                   │
                       └───────────────────────┬───────────────────────────┘
                                               ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ [Stage 3 & 4] Security Education & Concrete Remediation                     │
│ 🛠️ Agent 2: FixTemplateAgent (100% Local — Zero API Keys Required)          │
│ • Groups recurring findings by CWE type (zero duplicate alert fatigue)      │
│ • Contextual diagnosis & beginner-friendly explanations (What, Why, Principle)│
│ • Synthesizes concrete ❌ Before vs. ✅ After code diffs using real vars     │
│ • 1-Click "Apply Fix to Editor" in-browser patch execution                  │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ [Stage 5] In-Browser Code Editing & Instant Re-Auditing                     │
│ • Interactive in-browser syntax-highlighted code editor                     │
│ • Real-time "Run Audit" re-execution on updated code                        │
│ • Fresh audit report confirming flaw resolution & clean health score        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Core Features

| Feature | Description |
|---|---|
| **Zero-Trust Security Guardrail** | Hardened perimeter agent defending against prompt injections, Unicode homoglyphs, and delimiter escapes |
| **Full-File AST Parsing** | Complete Tree-sitter parsing across 4 languages with zero artificial character cutoffs |
| **Dual-Engine Security Auditing** | Semgrep rules (`rules.yaml`) with 12 local AST/regex fallback analyzers when offline |
| **Fact-Grounded Summarization** | 3-card architecture report (Executive Intent, Operational Flow, Function Matrix) grounded in AST facts |
| **Autonomous Action Planning** | Health Grade calculation (Grade A+ to F) and ranked priority action directives |
| **Concrete Code Diffs & 1-Click Apply** | Customized Before/After diffs with real variable names and 1-click in-browser patch application |
| **Interactive In-Browser Re-Auditing** | Edit code directly in-app and trigger automated re-audits to confirm bug resolution |
| **Hybrid & Offline Resilient** | Gemini Flash online with silent, 100% reliable local CodeT5 fallback; local deterministic fix agent |
| **Interactive Directory Bulk Scan** | Scan whole repositories with KPI cards and **`⚡ Audit File`** buttons redirecting directly to Single File Studio |
| **Green Computing Telemetry** | Real-time CPU, memory, and energy monitoring via Linux Intel RAPL and Windows/macOS psutil TDP estimation |
| **Inherited Analytics Visualizer** | Inherited React/Vite/Recharts frontend (`web/frontend/`) for viewing historical serialized JSON audit telemetry |

---

## Project Structure

```
NLP-based-Code-Summarizer-with-Security-Audits-main/
|-- main.py                    # CLI entry point for single-file analysis
|-- main_folder.py             # Directory bulk scan orchestrator
|-- rules.yaml                 # 130 Semgrep rules (40 CWEs, 4 languages)
|-- rules_guardrail.yaml       # Dynamic threat signatures for prompt injection defense
|-- requirements.txt           # Python backend dependencies
|-- cwe_report.txt             # CWE coverage report
|-- README.md
|
|-- src/
|   |-- security_guardrail.py       # Perimeter Agent: Prompt injection & Unicode defense
|   |-- ast_parser.py               # Tree-sitter AST parser (Python, Java, JS, C)
|   |-- feature_extractor.py        # Full-file AST feature & complexity extraction
|   |-- scanner.py                  # Dual-engine scanner (Semgrep + 12 local AST detectors)
|   |-- enrichment.py               # Pipeline integration & CodeT5 prompt constructor
|   |-- inference.py                # Local CodeT5 offline model wrapper
|   |-- understanding_tools.py      # AST Grounding Toolkit (structural & dataflow maps)
|   |-- code_understanding_agent.py # Agent 1: Gemini Flash + AST validation & CodeT5 fallback
|   |-- fix_agent.py                # Agent 2: Local FixTemplateAgent (diff & patch synthesis)
|   |-- orchestrator_agent.py       # Agent 3: Local AnalysisOrchestratorAgent (triage & health)
|   |-- agent_tools.py              # Security education knowledge base
|   |-- vuln_classifier.py          # CWE mapping & severity normalization
|
|-- web/
|   |-- app.py                      # Main Streamlit studio (Single File Audit & Directory Scan)
|   |-- energy_monitor.py           # Cross-platform hardware profiler (RAPL / psutil TDP)
|   |-- frontend/                   # React Advanced Analytics Dashboard
|       |-- src/App.jsx             # Recharts interactive charts & metrics
|       |-- public/reports/         # Serialized latest audit JSON reports
|       |-- package.json
|       |-- vite.config.js
|
|-- tests/                          # Curated test files for security validation
```

---

## Setup & Running the Application

### 1. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Environment (Optional for Online LLM)

Create a `.env` file in the project root (or copy `.env.example`):

```bash
GEMINI_API_KEY=your_gemini_api_key_here
```
*(Note: If no API key is provided, the app runs completely offline using local CodeT5 and local AST heuristics!)*

### 3. Run the Main Studio (Streamlit)

```bash
streamlit run web/app.py
```
This opens the studio at `http://localhost:8501`:
* **⚡ Single File Audit**: Ingest code, run full audits, inspect 3-card summaries, view vulnerabilities, apply 1-click diffs, and verify fixes.
* **📁 Directory Bulk Scan**: Select or enter a project folder to scan all files and use **`⚡ Audit File`** to jump straight into single file auditing.

### 4. Run the Advanced Analytics Dashboard (Optional)

In a separate terminal:

```bash
cd web/frontend
npm install    # (First time only)
npm run dev
```
Open `http://localhost:5173` to explore interactive radial risk gauges, severity breakdown charts, and CWE tags.

### 5. CLI Execution

```bash
python main.py --file tests/01_ecommerce_order_processor.py
```

---

## Rule & Language Coverage

| Language | Extension | Semgrep Rules | Local AST Detectors |
|---|---|---|---|
| **Python** | `.py` | 47 | Yes |
| **JavaScript** | `.js` | 35 | Yes |
| **Java** | `.java` | 24 | Yes |
| **C** | `.c` | 24 | Yes |
| **Total** | | **130 rules across 40 CWEs** | **12 Local Fallbacks** |

---

## Authors & Acknowledgments

* **Sricheran & Saivaraprasad**  
* Department of Computer Science & Engineering  
* Course: Compiler Design & Natural Language Processing (PBL)
