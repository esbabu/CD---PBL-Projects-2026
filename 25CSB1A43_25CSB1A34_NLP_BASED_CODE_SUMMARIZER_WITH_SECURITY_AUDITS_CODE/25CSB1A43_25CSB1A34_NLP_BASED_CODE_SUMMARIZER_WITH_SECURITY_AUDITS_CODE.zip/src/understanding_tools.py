"""
Grounding & Perception Tools for CodeUnderstandingAgent
=======================================================
Phase 2: Tool-Augmented Code Grounding

Provides deterministic Tree-sitter AST queries that serve as the
perception tools for the CodeUnderstandingAgent. The agent uses these
tools to verify facts, map control flow, and ground all natural language
claims in concrete code reality, eliminating hallucinations.
"""

from typing import Dict, List, Any, Optional
import os
import re

from src.ast_parser import ASTParser
from src.feature_extractor import FeatureExtractor


class CodeGroundingToolkit:
    """
    Toolkit that converts raw AST and Tree-sitter features into structured,
    auditable grounding facts for the CodeUnderstandingAgent.
    """

    def __init__(self):
        self.parser = ASTParser()
        self.extractor = FeatureExtractor()

    def inspect_code(self, code_str: str, language: str) -> Dict[str, Any]:
        """
        Primary perception tool: parses the AST and extracts complete structural,
        behavioral, and interface facts from the uploaded code.
        """
        try:
            tree = self.parser.parse(code_str, language)
            features = self.extractor.extract_features(tree, code_str, language)
        except Exception as e:
            # Safe fallback if parsing encounters minor syntax quirks
            features = {
                'functions': [],
                'classes': [],
                'imports': [],
                'params_by_fn': {},
                'return_info': {},
                'output_calls': [],
                'fn_body_facts': {},
                'doc_context': '',
                'fn_docs': {},
                'sources': [],
                'sinks': [],
            }

        features['lang'] = language
        features['line_count'] = code_str.count('\n') + 1
        return features

    @staticmethod
    def format_structural_map(features: Dict[str, Any]) -> str:
        """
        Tool output 1: Structural Architecture Map.
        Outlines language, imports, classes, and function signatures.
        """
        lang = features.get('lang', 'code').capitalize()
        lines = features.get('line_count', 0)
        imports = features.get('imports', [])
        classes = features.get('classes', [])
        functions = features.get('functions', [])
        params = features.get('params_by_fn', {})

        sections = []
        sections.append(f"• Language & Size: {lang} ({lines} lines)")

        if imports:
            sections.append(f"• External Dependencies / Imports: {', '.join(imports[:6])}")
        else:
            sections.append("• External Dependencies: None (Self-contained)")

        if classes:
            sections.append(f"• Classes Defined: {', '.join(classes)}")

        fn_sigs = []
        for fn in functions:
            p_list = params.get(fn, [])
            fn_sigs.append(f"`{fn}({', '.join(p_list)})`")

        if fn_sigs:
            sections.append(f"• Defined Functions: {', '.join(fn_sigs)}")
        else:
            sections.append("• Defined Functions: Top-level script execution")

        return "\n".join(sections)

    @staticmethod
    def format_dataflow_map(features: Dict[str, Any]) -> str:
        """
        Tool output 2: Dataflow & Execution Graph.
        Identifies input ingress points, function invocation chains, and output sinks.
        """
        sources = features.get('sources', [])
        outputs = features.get('output_calls', [])
        returns = features.get('return_info', {})
        fn_facts = features.get('fn_body_facts', {})
        functions = features.get('functions', [])

        lines = []

        # 1. Ingress / Inputs
        input_desc = []
        if any(fn_facts.get(f, {}).get('web_ops') for f in functions) or any(s in ('request.args', 'request.form', 'req.query', 'req.body') for s in sources):
            input_desc.append("HTTP Request parameters / payload")
        if any(fn_facts.get(f, {}).get('file_ops') for f in functions) or 'open' in sources:
            input_desc.append("Local disk file access")
        if any('input' in s or 'scanf' in s or 'Scanner' in s or 'prompt' in s for s in sources):
            input_desc.append("Interactive standard user input")
        if not input_desc:
            input_desc.append("Function argument parameters")

        lines.append(f"• Data Ingress (Inputs): {', '.join(input_desc)}")

        # 2. Inter-function Call Graph
        calls_found = []
        for fn, facts in fn_facts.items():
            intra = facts.get('intra_calls', [])
            if intra:
                calls_found.append(f"`{fn}()` -> `{', '.join(intra)}()`")

        if calls_found:
            lines.append(f"• Call Graph Flow: {' | '.join(calls_found[:4])}")
        else:
            lines.append("• Call Graph Flow: Independent functions or sequential execution")

        # 3. State & Core Operations
        ops = []
        if any(fn_facts.get(f, {}).get('crypto_ops') for f in functions):
            ops.append("Cryptographic key derivation / hashing")
        if any(fn_facts.get(f, {}).get('file_ops') for f in functions):
            ops.append("File system read/write")
        if any(fn_facts.get(f, {}).get('dom_writes') for f in functions):
            ops.append("DOM element mutation")
        if any(fn_facts.get(f, {}).get('has_loop') for f in functions):
            ops.append("Iterative collection processing")

        if ops:
            lines.append(f"• Core Transformations: {', '.join(ops)}")

        # 4. Egress / Outputs
        out_desc = []
        if outputs:
            out_desc.append(f"Standard console prints ({outputs[0]})")
        if any(returns.values()):
            ret_examples = [r for r in returns.values() if r and r != 'a computed result'][:2]
            if ret_examples:
                out_desc.append(f"Returns {', '.join(ret_examples)}")
            else:
                out_desc.append("Returns computed values to caller")

        if out_desc:
            lines.append(f"• Data Egress (Outputs): {'; '.join(out_desc)}")

        return "\n".join(lines)

    @staticmethod
    def format_function_matrix(features: Dict[str, Any]) -> List[Dict[str, str]]:
        """
        Tool output 3: Verified Function Contract Matrix.
        Builds grounded signature-to-responsibility pairs.
        """
        functions = features.get('functions', [])
        params = features.get('params_by_fn', {})
        returns = features.get('return_info', {})
        fn_facts = features.get('fn_body_facts', {})
        fn_docs = features.get('fn_docs', {})

        contracts = []
        for fn in functions:
            p = params.get(fn, [])
            sig = f"{fn}({', '.join(p)})"
            doc = fn_docs.get(fn, '')
            ret = returns.get(fn, '')
            facts = fn_facts.get(fn, {})

            # Synthesize grounded single responsibility description
            if doc:
                responsibility = doc.strip().rstrip('.')
            elif facts.get('crypto_ops'):
                responsibility = "Performs cryptographic hashing or key derivation"
            elif facts.get('file_ops') and facts.get('web_ops'):
                responsibility = "Reads file content requested via HTTP parameters"
            elif facts.get('file_ops'):
                responsibility = "Handles disk file reading or access"
            elif facts.get('has_loop') and ret:
                responsibility = f"Iterates through input to compute {ret}"
            elif ret and ret != 'a computed result':
                responsibility = f"Computes and returns {ret}"
            else:
                responsibility = f"Executes `{fn}` routine logic"

            contracts.append({
                'name': fn,
                'signature': sig,
                'responsibility': responsibility,
                'returns': ret if ret else 'void / None',
                'calls': facts.get('intra_calls', [])
            })

        return contracts

    def build_grounding_bundle(self, code_str: str, language: str) -> Dict[str, Any]:
        """
        Convenience method to run all tools and produce the complete grounded package.
        """
        features = self.inspect_code(code_str, language)
        return {
            'features': features,
            'structural_map': self.format_structural_map(features),
            'dataflow_map': self.format_dataflow_map(features),
            'function_matrix': self.format_function_matrix(features),
            'doc_intent': features.get('doc_context', '')
        }
