"""
AnalysisOrchestratorAgent: Local Static Analysis & Audit Orchestrator
=====================================================================
100% Local Agentic AI — Zero Network Calls, Zero API Keys Required.

Multi-Source Reasoning Agent that cross-correlates:
  1. AST & Structural Metrics (Tree-sitter cyclomatic complexity, params, imports)
  2. Security Vulnerability Scan (Semgrep / Regex findings, CWEs, risk score)
  3. Executive Architectural Understanding (Stage 2 Summary & Function Matrix)

Produces an autonomous strategic directive:
  - Overall Architectural Security Grade (Grade A through F)
  - Executive Security Posture Verdict
  - Ranked Action Directives with Multi-Factor Priority Scoring
  - Attack Surface & Complexity Exposure Analysis
"""

import re
from typing import Dict, List, Any, Optional


class AnalysisOrchestratorAgent:
    """
    Autonomous local orchestrator that coordinates multi-stage pipeline intelligence,
    cross-references vulnerabilities with structural complexity, and formulates
    a prioritized remediation action plan.
    """

    def __init__(self):
        pass

    def orchestrate_audit(
        self,
        features: Dict[str, Any],
        findings: List[Dict[str, Any]],
        risk_score: float,
        summary_text: str = "",
        language: str = "python"
    ) -> Dict[str, Any]:
        """
        Main orchestration loop:
          1. Perception: Ingest and correlate multi-stage artifacts
          2. Correlation: Map security flaws to enclosing functions and AST complexity
          3. Scoring: Apply multi-factor prioritization formula
          4. Synthesis: Generate executive verdict and ranked action plan
        """
        # ── 1. Perception & Feature Extraction ─────────────────────────
        total_functions = len(features.get('functions', []))
        complexity = features.get('complexity', 0)
        params_by_fn = features.get('params_by_fn', {})
        fn_facts = features.get('fn_body_facts', {})
        imports = features.get('imports', [])
        fn_names = features.get('functions', [])

        # ── 2. Correlate Vulnerabilities with Functions ────────────────
        vulnerable_functions: Dict[str, List[Dict[str, Any]]] = {}
        unmapped_findings: List[Dict[str, Any]] = []

        for f in findings:
            target_fn = self._find_enclosing_function(f, features)
            if target_fn:
                vulnerable_functions.setdefault(target_fn, []).append(f)
            else:
                unmapped_findings.append(f)

        # ── 3. Multi-Factor Prioritization Scoring ─────────────────────
        action_directives = []

        for fn_name, fn_findings in vulnerable_functions.items():
            facts = fn_facts.get(fn_name, {})
            fn_params = params_by_fn.get(fn_name, [])
            has_loops = facts.get('has_loop', False)
            has_web_input = facts.get('web_ops', False) or any(
                p.lower() in ('req', 'request', 'data', 'user', 'payload') for p in fn_params
            )

            for finding in fn_findings:
                sev = (finding.get('severity') or 'INFO').upper()
                cwe = finding.get('cwe') or 'VULN'
                msg = finding.get('message', '')
                line = finding.get('line', '?')

                # Base severity score
                if 'HIGH' in sev or 'ERROR' in sev:
                    base_pts = 10
                elif 'MED' in sev or 'WARN' in sev:
                    base_pts = 6
                else:
                    base_pts = 3

                # Multipliers & bonuses
                multipliers = []
                bonus_pts = 0

                if has_web_input or len(fn_params) > 0:
                    bonus_pts += 4
                    multipliers.append("Direct Data Ingress / Parameterized Exposure")

                if complexity >= 6:
                    bonus_pts += 3
                    multipliers.append(f"High Cyclomatic Complexity ({complexity})")

                if has_loops:
                    bonus_pts += 2
                    multipliers.append("Loop Traversal Execution Path")

                total_score = base_pts + bonus_pts

                action_directives.append({
                    'score': total_score,
                    'priority': 'CRITICAL' if total_score >= 14 else ('HIGH' if total_score >= 10 else 'MEDIUM'),
                    'target_function': fn_name,
                    'line': line,
                    'cwe': cwe,
                    'message': msg,
                    'multipliers': multipliers,
                    'recommended_action': f"Remediate `{cwe}` in `{fn_name}()` at line {line}.",
                    'rationale': (
                        f"Function `{fn_name}()` accepts external parameters and exhibits structural complexity. "
                        f"A {sev} vulnerability here has high exploitability and systemic impact."
                    )
                })

        # Process top-level unmapped findings (e.g. script root)
        for finding in unmapped_findings:
            sev = (finding.get('severity') or 'INFO').upper()
            cwe = finding.get('cwe') or 'VULN'
            msg = finding.get('message', '')
            line = finding.get('line', '?')
            base_pts = 10 if ('HIGH' in sev or 'ERROR' in sev) else (6 if 'MED' in sev else 3)
            action_directives.append({
                'score': base_pts,
                'priority': 'CRITICAL' if base_pts >= 10 else 'MEDIUM',
                'target_function': 'Top-Level Global Scope',
                'line': line,
                'cwe': cwe,
                'message': msg,
                'multipliers': ["Global Application Execution Scope"],
                'recommended_action': f"Remediate `{cwe}` at line {line} in global script scope.",
                'rationale': f"Root-level {sev} vulnerability executed upon module initialization."
            })

        # Sort action directives by priority score descending
        action_directives.sort(key=lambda x: x['score'], reverse=True)

        # ── 4. Strategic Verdict & Health Rating ───────────────────────
        high_count = sum(1 for f in findings if (f.get('severity') or '').upper() in ('HIGH', 'ERROR'))
        med_count = sum(1 for f in findings if (f.get('severity') or '').upper() in ('MED', 'MEDIUM', 'WARNING'))

        if len(findings) == 0:
            health_grade = "Grade A+ (Robust & Compliant)"
            health_badge_color = "#1a7f37"
            verdict = "Zero security vulnerabilities detected. Code structure adheres to clean architecture principles."
        elif high_count >= 2 or risk_score >= 70:
            health_grade = "Grade F (Critical Intervention Required)"
            health_badge_color = "#cf222e"
            verdict = (
                f"Severe architectural compromise. {high_count} high-severity vulnerability(ies) detected with "
                f"a combined risk score of {risk_score:.1f}/100. Immediate remediation required before deployment."
            )
        elif high_count == 1 or risk_score >= 40:
            health_grade = "Grade C (Elevated Risk)"
            health_badge_color = "#9a6700"
            verdict = (
                f"Elevated security exposure detected. Identified {high_count} high and {med_count} medium finding(s). "
                f"Critical execution paths require parameter sanitization and isolation."
            )
        else:
            health_grade = "Grade B- (Moderate Review Advised)"
            health_badge_color = "#0969da"
            verdict = f"Manageable risk profile. Identified {len(findings)} low/medium issue(s). Follow proactive remediation directives."

        # Exposure ratio
        vuln_fn_count = len(vulnerable_functions)
        exposure_ratio = f"{vuln_fn_count}/{total_functions}" if total_functions > 0 else "N/A"

        return {
            'health_grade': health_grade,
            'health_badge_color': health_badge_color,
            'risk_score': risk_score,
            'verdict': verdict,
            'action_directives': action_directives[:4],  # Top 4 most impactful actions
            'total_findings': len(findings),
            'vulnerable_functions_count': vuln_fn_count,
            'exposure_ratio': exposure_ratio,
            'total_functions': total_functions,
            'cyclomatic_complexity': complexity,
            'imports_count': len(imports)
        }

    # ─────────────────────────────────────────────────────────────────────────
    # Helper: Correlate Finding to Function
    # ─────────────────────────────────────────────────────────────────────────

    def _find_enclosing_function(self, finding: Dict[str, Any], features: Dict[str, Any]) -> Optional[str]:
        """Correlates a line number to the enclosing AST function name."""
        line = finding.get('line')
        if not line:
            return None

        fn_body_facts = features.get('fn_body_facts', {})
        code_content = features.get('code', '')
        lines = code_content.splitlines()

        # Check by matching function name in code before line
        functions = features.get('functions', [])
        if not functions:
            return None

        # Look backwards from line to find the closest def / function declaration
        for idx in range(min(line - 1, len(lines) - 1), -1, -1):
            curr_line = lines[idx]
            for fn in functions:
                pattern = rf'\b(def|function|public|private|void|int|char|bool)\s+{re.escape(fn)}\b'
                if re.search(pattern, curr_line) or f"{fn}(" in curr_line:
                    return fn

        # Fallback: check if finding message or snippet mentions any function name
        msg = (finding.get('message') or '') + ' ' + (finding.get('snippet') or '')
        for fn in functions:
            if re.search(rf'\b{re.escape(fn)}\b', msg):
                return fn

        return None
