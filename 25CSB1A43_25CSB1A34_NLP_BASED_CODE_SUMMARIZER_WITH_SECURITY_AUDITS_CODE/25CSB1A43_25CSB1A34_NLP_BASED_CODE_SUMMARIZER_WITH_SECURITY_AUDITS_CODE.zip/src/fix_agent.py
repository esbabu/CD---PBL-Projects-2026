"""
FixTemplateAgent: Unified Local Security Remediation & Teaching Agent
======================================================================
100% Local Agentic AI — Zero Network Calls, Zero API Keys Required.

Performs deterministic reasoning over vulnerability context:
  1. Analyzes findings: extracts code context, explains root cause, teaches defense principles
  2. Groups findings by vulnerability type to eliminate duplicate explanations
  3. Inspects language, AST structure, and imported libraries
  4. Synthesizes concrete, code-grounded Before/After remediation diffs
  5. Verifies fix status against modified code
"""

import re
from typing import Dict, List, Any, Optional, Tuple


class FixTemplateAgent:
    """
    Autonomous local agent for vulnerability explanation, beginner teaching,
    and concrete remediation code diff synthesis grounded in AST and CWE anti-patterns.
    """

    def __init__(self):
        pass

    def analyze_finding(self, finding: Dict[str, Any], code_str: str = "", language: str = "") -> Dict[str, Any]:
        """
        Analyze a single scanner finding to produce code context,
        grounded vulnerability explanation, and beginner teaching concepts.
        """
        from src.agent_tools import (
            extract_finding_context,
            explain_vulnerability,
            teach_security_concept
        )
        context = extract_finding_context(finding, code_str, language)
        explanation = explain_vulnerability(context)
        teaching = teach_security_concept(context)

        return {
            'context': context,
            'explanation': explanation,
            'teaching': teaching,
        }

    def analyze_all_findings(self, findings: List[Dict[str, Any]], code_str: str = "", language: str = "") -> List[Dict[str, Any]]:
        """
        Analyze all findings individually, preserving separate context for each issue.
        """
        results = []
        for f in findings:
            results.append(self.analyze_finding(f, code_str, language))
        return results

    def analyze_and_remediate(
        self,
        findings: List[Dict[str, Any]],
        code_content: str,
        language: str,
        features: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Unified End-to-End Remediation Pipeline:
          1. Analyzes all findings (context extraction, vulnerability diagnosis, teaching).
          2. Groups findings sharing the same category/CWE to eliminate duplicate explanations.
          3. Synthesizes concrete Before/After code diffs and checklists for all affected lines.
        """
        raw_analyses = self.analyze_all_findings(findings, code_content, language)
        return self.group_and_remediate(raw_analyses, code_content, language, features)

    def verify_all_findings(
        self,
        original_findings: List[Dict[str, Any]],
        modified_code: str,
        language: str
    ) -> Dict[str, Any]:
        """
        Verify all original baseline findings against modified code in a single rescan.
        """
        from src.agent_tools import verify_fix_pipeline
        return verify_fix_pipeline(original_findings, modified_code, language)

    def _validate_patch_syntax(self, code_str: str, language: str) -> bool:
        """
        Tree-sitter AST validation: verifies that the candidate patched code compiles
        cleanly without syntax errors before presenting or applying it.
        """
        try:
            from src.ast_parser import ASTParser
            parser = ASTParser()
            tree = parser.parse(code_str, language)
            return tree is not None and not tree.root_node.has_error
        except Exception:
            return True

    def analyze_reachability(
        self,
        finding_ctx: Dict[str, Any],
        code_content: str,
        language: str,
        features: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Taint Reachability & Exploitability Triage:
        Determines whether the flagged vulnerability sink actually receives untrusted
        dynamic user inputs (reachable exploit), or if it is a harmless static literal
        (false positive suppression).
        """
        features = features or {}
        line_num = finding_ctx.get('line', 1)
        lines = code_content.splitlines()

        target_line = ""
        if 1 <= line_num <= len(lines):
            target_line = lines[line_num - 1].strip()

        # Check preceding 6 lines for variable definitions feeding this sink
        surrounding_window = lines[max(0, line_num - 7):line_num]
        context_block = "\n".join(surrounding_window)

        # 1. Identify parameter sources from AST features
        all_params = []
        for fn_p in features.get('params_by_fn', {}).values():
            all_params.extend(fn_p)

        # 2. Check for dynamic interpolation patterns
        has_fstring = "f\"" in context_block or "f'" in context_block or "f\"" in target_line or "f'" in target_line
        has_format = ".format(" in context_block or "%" in context_block or ".format(" in target_line
        has_concat = "+" in context_block or "+" in target_line

        # 3. Check for specific tainted variable names
        combined_text = context_block + "\n" + target_line
        interpolated_vars = re.findall(r'\{([a-zA-Z_]\w*)\}', combined_text)
        concat_vars = re.findall(r'\+\s*([a-zA-Z_]\w*)', combined_text)
        active_vars = list(dict.fromkeys(interpolated_vars + concat_vars))

        # 4. Check if active variables trace to function parameters or user inputs
        tainted_hit = any(v in all_params for v in active_vars) or any(
            re.search(rf'\b{re.escape(v)}\b', combined_text) for v in all_params
        )

        # 5. Check if the line or preceding assignment uses a static string literal with zero variable interpolation
        has_static_var_assignment = bool(re.search(r'\w+\s*=\s*["\'][^"\'\{\}%]+["\']', context_block))
        has_hardcoded_literal = bool(re.search(r'execute\(["\'][^"\'\{\}%]+["\']\)', target_line)) or (
            has_static_var_assignment and not has_fstring and not has_format and not has_concat and not tainted_hit
        )

        if tainted_hit or (has_fstring and active_vars):
            tainted_name = active_vars[0] if active_vars else (all_params[0] if all_params else "input_param")
            return {
                'status': 'CONFIRMED_EXPLOITABLE',
                'exploitability': 'HIGH',
                'is_false_alarm': False,
                'badge_color': '#cf222e',
                'badge_label': 'CRITICAL EXPLOITABLE',
                'reachability_path': f"External parameter '{tainted_name}' flows directly into dynamic sink execution at Line {line_num}.",
                'triage_rationale': f"Taint dataflow confirmed: dynamic interpolation of '{tainted_name}' bypasses static boundaries and can be manipulated by untrusted callers."
            }
        elif has_hardcoded_literal and not has_fstring and not has_concat:
            return {
                'status': 'UNREACHABLE_STATIC_SAFE',
                'exploitability': 'SAFE',
                'is_false_alarm': True,
                'badge_color': '#1a7f37',
                'badge_label': 'UNREACHABLE / SAFE (FALSE ALARM)',
                'reachability_path': f"Sink on Line {line_num} executes a static literal constant with zero variable interpolation.",
                'triage_rationale': "Verified safe: No untrusted external user input reaches this operation. False alarm suppressed."
            }
        else:
            return {
                'status': 'POTENTIALLY_EXPLOITABLE',
                'exploitability': 'MEDIUM',
                'is_false_alarm': False,
                'badge_color': '#d4a72c',
                'badge_label': 'MEDIUM EXPLOITABILITY',
                'reachability_path': f"Execution sink at Line {line_num} receives dynamic reference. Verifying call graph reachability.",
                'triage_rationale': "Input reaches sensitive sink through indirect reference. Defensive sanitization recommended."
            }

    def apply_patch_to_code(self, full_code: str, before_snippet: str, after_snippet: str) -> str:
        """
        Replaces vulnerable code in full_code with the synthesized patch,
        preserving line structure and indentation.
        """
        if not before_snippet or not full_code:
            return full_code

        # Clean header comment from after_snippet if applying directly to source code
        clean_after = after_snippet
        lines_after = clean_after.splitlines()
        filtered = [l for l in lines_after if not l.strip().startswith("# Context-Aware Remediation")]
        if filtered:
            clean_after = "\n".join(filtered)

        # 1. Exact match replacement
        if before_snippet in full_code:
            return full_code.replace(before_snippet, clean_after, 1)

        # 2. Line-by-line fuzzy match (preserving leading indentation)
        lines = full_code.splitlines()
        clean_before = before_snippet.strip()

        for idx, ln in enumerate(lines):
            if clean_before and (clean_before in ln or ln.strip() == clean_before):
                indent = len(ln) - len(ln.lstrip())
                indented_after = "\n".join(" " * indent + al.lstrip() for al in clean_after.splitlines())
                lines[idx] = indented_after
                return "\n".join(lines)

        return full_code

    def group_and_remediate(
        self,
        analyses: List[Dict[str, Any]],
        code_content: str,
        language: str,
        features: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Groups findings sharing the same category/CWE to eliminate duplicate explanations.
        Explains once per vulnerability type, while collecting all affected lines and
        synthesizing concrete fixes for all identified lines.
        """
        features = features or {}
        from collections import OrderedDict
        grouped: Dict[str, Dict[str, Any]] = OrderedDict()

        for item in analyses:
            ctx = item.get('context', {})
            exp = item.get('explanation', {})
            tch = item.get('teaching', {})
            cwe = (ctx.get('cwe') or 'VULN').upper().strip()
            cat = ctx.get('category') or cwe
            group_key = f"{cwe}::{cat}"

            line_num = ctx.get('line', '?')
            surrounding = ctx.get('surrounding_code', {})
            snippet = surrounding.get('snippet', '') or ctx.get('snippet', '')

            # Generate individual fix for this line
            fix_single = self.suggest_fix(ctx, code_content, language, features)
            # Taint reachability & exploitability triage
            reach_triage = self.analyze_reachability(ctx, code_content, language, features)

            if group_key not in grouped:
                grouped[group_key] = {
                    'cwe': cwe,
                    'category': cat,
                    'severity': ctx.get('severity', 'HIGH'),
                    'lines': [line_num],
                    'snippets': [(line_num, snippet)],
                    'explanation': exp,
                    'teaching': tch,
                    'reachability': reach_triage,
                    'diagnosis': fix_single.get('diagnosis', ''),
                    'defensive_principle': fix_single.get('defensive_principle', tch.get('principle', '')),
                    'remediation_steps': fix_single.get('remediation_steps', []),
                    'fixes': [{
                        'line': line_num,
                        'before': fix_single.get('vulnerable_snippet', ''),
                        'after': fix_single.get('fixed_snippet', '')
                    }]
                }
            else:
                entry = grouped[group_key]
                if line_num not in entry['lines']:
                    entry['lines'].append(line_num)
                    entry['snippets'].append((line_num, snippet))
                    entry['fixes'].append({
                        'line': line_num,
                        'before': fix_single.get('vulnerable_snippet', ''),
                        'after': fix_single.get('fixed_snippet', '')
                    })

        return list(grouped.values())

    def suggest_fix(
        self,
        finding: Dict[str, Any],
        code_content: str,
        language: str,
        features: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Main agentic reasoning loop for generating a grounded fix.
        Returns a dictionary with:
          - 'diagnosis': Specific anti-pattern detected
          - 'vulnerable_snippet': The Before code
          - 'fixed_snippet': The After code with fix applied
          - 'remediation_steps': Step-by-step instructions
          - 'defensive_principle': Principle applied
        """
        features = features or {}
        line_num = finding.get('line', 1)
        raw_msg = finding.get('message', '')
        cwe = finding.get('cwe', '')
        if not cwe:
            from src.vuln_classifier import classify_vulnerability
            cwe, _ = classify_vulnerability(raw_msg)

        cwe = cwe.upper().strip()
        snippet = finding.get('snippet', '').strip()
        lines = code_content.splitlines()

        # ── 1. Tool: Surrounding context extraction ──────────────────────
        target_line = ""
        if 1 <= line_num <= len(lines):
            target_line = lines[line_num - 1].strip()
        if not snippet:
            snippet = target_line

        # ── 2. Tool: Language & Import Context Inspection ────────────────
        imports = features.get('imports', [])
        lang = (language or 'python').lower()

        # ── 3. Decision & Reasoning by CWE Family ────────────────────────
        if 'CWE-89' in cwe or 'sql' in raw_msg.lower():
            return self._remediate_sqli(target_line, snippet, lang, imports, code_content)

        elif 'CWE-78' in cwe or 'command' in raw_msg.lower() or 'shell' in raw_msg.lower():
            return self._remediate_command_injection(target_line, snippet, lang, code_content)

        elif 'CWE-94' in cwe or 'eval' in raw_msg.lower():
            return self._remediate_code_injection(target_line, snippet, lang)

        elif 'CWE-79' in cwe or 'xss' in raw_msg.lower():
            return self._remediate_xss(target_line, snippet, lang)

        elif any(k in cwe for k in ('CWE-338', 'CWE-336', 'CWE-337')) or 'prng' in raw_msg.lower() or 'random' in raw_msg.lower() or 'randint' in raw_msg.lower():
            return self._remediate_weak_prng(target_line, snippet, lang)

        elif any(k in cwe for k in ('CWE-327', 'CWE-328')) or 'weak crypto' in raw_msg.lower() or 'md5' in raw_msg.lower():
            return self._remediate_weak_crypto(target_line, snippet, lang)

        elif any(k in cwe for k in ('CWE-798', 'CWE-259', 'CWE-321')) or 'hardcoded' in raw_msg.lower() or ('secret' in raw_msg.lower() and 'prng' not in raw_msg.lower() and 'random' not in raw_msg.lower()):
            return self._remediate_hardcoded_secrets(target_line, snippet, lang)

        elif 'CWE-22' in cwe or 'traversal' in raw_msg.lower():
            return self._remediate_path_traversal(target_line, snippet, lang)

        elif any(k in cwe for k in ('CWE-502', 'pickle', 'deserialization')):
            return self._remediate_deserialization(target_line, snippet, lang)

        elif any(k in cwe for k in ('CWE-532', 'CWE-209')) or 'log' in raw_msg.lower() or 'print(' in target_line.lower() or 'exposure' in raw_msg.lower():
            return self._remediate_log_exposure(target_line, snippet, lang)

        elif 'CWE-120' in cwe or 'buffer' in raw_msg.lower() or 'strcpy' in raw_msg.lower() or 'gets(' in target_line.lower():
            return self._remediate_buffer_overflow(target_line, snippet, lang)

        elif 'CWE-295' in cwe or 'verify=false' in target_line.lower() or 'ssl' in raw_msg.lower():
            return self._remediate_tls_bypass(target_line, snippet, lang)

        elif 'CWE-611' in cwe or 'xml' in raw_msg.lower():
            return self._remediate_xxe(target_line, snippet, lang)

        elif 'CWE-400' in cwe or 'fork' in raw_msg.lower():
            return self._remediate_fork_bomb(target_line, snippet, lang)

        else:
            return self._generic_remediation(target_line, snippet, cwe, raw_msg, lang)

    # ─────────────────────────────────────────────────────────────────────────
    # Domain-Specific Local Reasoning Engines
    # ─────────────────────────────────────────────────────────────────────────

    def _remediate_sqli(self, line: str, snippet: str, lang: str, imports: List[str], full_code: str = "") -> Dict[str, Any]:
        """Synthesizes context-aware parameterized database queries."""
        lines = full_code.splitlines() if full_code else [line]
        query_def_line = ""
        var_name = "account_id"

        # Search for query definition in surrounding lines
        for ln in lines:
            if re.search(r'SELECT\s+.*FROM\s+', ln, re.IGNORECASE) and ('{' in ln or '%' in ln or '+' in ln):
                query_def_line = ln.strip()
                break

        search_target = query_def_line if query_def_line else (line or snippet)
        var_match = (
            re.search(r'\{([a-zA-Z_]\w*)\}', search_target) or
            re.search(r'%\s*\(?([a-zA-Z_]\w*)', search_target) or
            re.search(r'\+\s*([a-zA-Z_]\w*)', search_target)
        )
        if var_match:
            var_name = var_match.group(1)

        # Detect driver placeholder
        placeholder = "?"
        if any("psycopg" in imp or "mysql" in imp for imp in imports):
            placeholder = "%s"

        if lang == 'python':
            if query_def_line:
                # Context-aware patch preserving user's query statement & table
                param_pattern = re.compile(rf'[\'"]?\{{{var_name}\}}[\'"]?')
                clean_query = param_pattern.sub(placeholder, query_def_line)
                if clean_query.startswith('f"') or clean_query.startswith("f'"):
                    clean_query = clean_query[1:]

                before = f"{query_def_line}\n    {line}" if line and line != query_def_line else query_def_line
                after = (
                    f"# Context-Aware Remediation: Parameterized prepared statement\n"
                    f"    {clean_query}\n"
                    f"    cursor.execute(query, ({var_name},))"
                )
            else:
                before = line or f'cursor.execute(f"SELECT * FROM users WHERE id = {{{var_name}}}")'
                after = (
                    f"# Context-Aware Remediation: Parameterized query placeholder\n"
                    f'query = "SELECT * FROM users WHERE id = {placeholder}"\n'
                    f'cursor.execute(query, ({var_name},))'
                )

            # AST syntax pre-validation
            if not self._validate_patch_syntax(after, 'python'):
                after = f'cursor.execute("SELECT * FROM users WHERE id = ?", ({var_name},))'

            return {
                'diagnosis': f"Dynamic SQL query construction detected with direct variable interpolation (`{var_name}`).",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    f"Replace dynamic string interpolation with driver placeholder (`{placeholder}`).",
                    f"Pass user parameter `{var_name}` as a bound parameter tuple.",
                    "Never format inputs directly into the SQL string."
                ],
                'defensive_principle': "Separation of Code and Data (Prepared Statements)"
            }
        elif lang in ('javascript', 'js'):
            before = line or f'db.query(`SELECT * FROM users WHERE id = ${{ {var_name} }}`)'
            after = (
                f'// Remediation: Use bound parameters\n'
                f'const query = "SELECT * FROM users WHERE id = $1";\n'
                f'db.query(query, [{var_name}]);'
            )
            return {
                'diagnosis': f"String interpolation in database query allows SQL syntax injection.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Use parameterized queries with driver placeholders (`$1`, `$2` or `?`).",
                    "Provide inputs inside a parameters array."
                ],
                'defensive_principle': "Parameterized Queries"
            }
        elif lang == 'java':
            before = line or f'Statement stmt = conn.createStatement(); stmt.executeQuery("SELECT * FROM users WHERE id = " + {var_name});'
            after = (
                f'// Remediation: Use PreparedStatement\n'
                f'String sql = "SELECT * FROM users WHERE id = ?";\n'
                f'try (PreparedStatement pstmt = conn.prepareStatement(sql)) {{\n'
                f'    pstmt.setString(1, {var_name});\n'
                f'    ResultSet rs = pstmt.executeQuery();\n'
                f'}}'
            )
            return {
                'diagnosis': "String concatenation inside Statement.executeQuery() allows SQL injection.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Replace `java.sql.Statement` with `java.sql.PreparedStatement`.",
                    "Bind parameters with strongly typed setter methods (`setString`, `setInt`)."
                ],
                'defensive_principle': "PreparedStatement Binding"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-89", "SQL Injection", lang)

    def _remediate_command_injection(self, line: str, snippet: str, lang: str, full_code: str = "") -> Dict[str, Any]:
        """Synthesizes context-aware safe process execution without system shell."""
        target = line or snippet
        var_match = re.search(r'\{([a-zA-Z_]\w*)\}', target) or re.search(r'\+\s*([a-zA-Z_]\w*)', target)
        var_name = var_match.group(1) if var_match else "command_arg"

        if lang == 'python':
            if "os.system" in target and ("f\"" in target or "f'" in target):
                before = target
                inner = target.replace("os.system(", "").rstrip(")")
                after = (
                    f"# Context-Aware Remediation: Use subprocess.run with argument list (shell=False)\n"
                    f"    import subprocess, shlex\n"
                    f"    cmd_args = shlex.split({inner})\n"
                    f"    subprocess.run(cmd_args, shell=False, check=True)"
                )
            else:
                before = target or f'os.system("ping " + {var_name})'
                after = (
                    f"# Context-Aware Remediation: Use subprocess.run with argument sequence (shell=False)\n"
                    f"    import subprocess\n"
                    f"    subprocess.run([\"ping\", \"-c\", \"1\", {var_name}], shell=False, check=True)"
                )

            if not self._validate_patch_syntax(after, 'python'):
                after = f'import subprocess\nsubprocess.run(["sh", "-c", {var_name}], check=True)'

            return {
                'diagnosis': "Executing commands through a system shell exposes process to metacharacter chaining (`;`, `&&`, `|`).",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Avoid `os.system()` or `subprocess.Popen(..., shell=True)`.",
                    "Pass executable and arguments as an explicit list of strings with `shell=False`.",
                    "Validate or whitelist permitted input arguments."
                ],
                'defensive_principle': "Avoid Shell Interpretation & Principle of Least Privilege"
            }
        elif lang in ('javascript', 'js'):
            before = line or f'exec("ping " + {var_name});'
            after = (
                f'// Remediation: Use execFile or spawn with argument array\n'
                f'const {{ execFile }} = require("child_process");\n'
                f'execFile("ping", ["-c", "1", {var_name}], (error, stdout) => {{\n'
                f'    if (error) throw error;\n'
                f'}});'
            )
            return {
                'diagnosis': "Passing dynamic input to `child_process.exec` spawns a subshell prone to command injection.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Switch from `exec()` to `execFile()` or `spawn()`.",
                    "Pass arguments in an array to bypass shell parser."
                ],
                'defensive_principle': "Shell-less Process Execution"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-78", "Command Injection", lang)

    def _remediate_code_injection(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes safe alternatives to eval / exec."""
        if lang == 'python':
            before = line or 'result = eval(user_input)'
            after = (
                f'# Remediation: Replace eval with safe parser (ast.literal_eval or math parsing)\n'
                f'import ast\n\n'
                f'# If evaluating data structures (lists, dicts, numbers):\n'
                f'result = ast.literal_eval(user_input)\n\n'
                f'# If computing expressions, use a strict math parser library instead of eval()'
            )
            return {
                'diagnosis': "Dynamic code evaluation via `eval()` executes arbitrary Python bytecode.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Remove `eval()` and `exec()` completely.",
                    "For literal parsing (JSON/dicts/numbers), use `ast.literal_eval()`.",
                    "For mathematical calculators, use an AST arithmetic grammar or parser combinator."
                ],
                'defensive_principle': "Strict Input Parsing over Dynamic Evaluation"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-94", "Code Injection", lang)

    def _remediate_xss(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes safe text insertion to prevent XSS."""
        if lang in ('javascript', 'js'):
            before = line or 'element.innerHTML = user_content;'
            after = (
                f'// Remediation: Use textContent or HTML encoding\n'
                f'element.textContent = user_content; // Safe: browser treats as plain text\n'
                f'// Or if HTML is necessary, sanitize using DOMPurify.sanitize(user_content)'
            )
            return {
                'diagnosis': "Assigning untrusted data directly to `innerHTML` or `document.write` enables Cross-Site Scripting (XSS).",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Use `.textContent` or `.innerText` instead of `.innerHTML` when inserting text.",
                    "If rich HTML formatting is required, sanitize with a battle-tested library like DOMPurify."
                ],
                'defensive_principle': "Context-Aware Output Encoding"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-79", "Cross-Site Scripting", lang)

    def _remediate_hardcoded_secrets(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes environment variable loading for secrets."""
        var_match = re.search(r'([A-Za-z_]\w*)\s*=', line)
        var_name = var_match.group(1) if var_match else "SECRET_KEY"

        if lang == 'python':
            before = line or f'{var_name} = "my_secret_token_12345"'
            after = (
                f'# Remediation: Load secret from environment variables or secret manager\n'
                f'import os\n\n'
                f'{var_name} = os.getenv("{var_name.upper()}")\n'
                f'if not {var_name}:\n'
                f'    raise RuntimeError("Missing required environment variable: {var_name.upper()}")'
            )
            return {
                'diagnosis': f"Hardcoded credential or key `{var_name}` stored in plaintext source code.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Remove secret literal immediately and revoke/rotate any exposed keys.",
                    "Use `os.getenv()` or a `.env` loader (`python-dotenv`) for local development.",
                    "Use a dedicated Secret Manager (HashiCorp Vault, AWS Secrets Manager) in production."
                ],
                'defensive_principle': "External Configuration of Credentials"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-798", "Hardcoded Credentials", lang)

    def _remediate_weak_crypto(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes modern cryptographic hash upgrades."""
        if lang == 'python':
            before = line or 'hasher = hashlib.md5(data.encode())'
            after = (
                f'# Remediation: Upgrade to SHA-256 for integrity, or PBKDF2/Argon2 for passwords\n'
                f'import hashlib\n\n'
                f'# For general hashing:\n'
                f'hasher = hashlib.sha256(data.encode())\n\n'
                f'# For passwords, use hashlib.pbkdf2_hmac or bcrypt:'
            )
            return {
                'diagnosis': "Obsolete cryptographic algorithm (MD5/SHA1/DES) vulnerable to collision or brute-force attacks.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Replace MD5 and SHA-1 with SHA-256 or SHA-3 for digital signatures and hashing.",
                    "For passwords, use salt + PBKDF2-HMAC-SHA256, bcrypt, or Argon2."
                ],
                'defensive_principle': "Cryptographic Agility & Industry Standard Ciphers"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-327", "Weak Cryptography", lang)

    def _remediate_weak_prng(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes cryptographically secure random number generation."""
        if lang == 'python':
            before = line or snippet or 'token = random.randint(100000, 999999)'
            if 'return ' in before:
                after = (
                    f'# Remediation: Use secrets module for cryptographically secure randomness\n'
                    f'import secrets\n\n'
                    f'return secrets.randbelow(900000) + 100000'
                )
            else:
                var_match = re.search(r'([a-zA-Z_]\w*)\s*=', before)
                vname = var_match.group(1) if var_match else 'token'
                after = (
                    f'# Remediation: Use secrets module for cryptographically secure randomness\n'
                    f'import secrets\n\n'
                    f'{vname} = secrets.randbelow(900000) + 100000\n'
                    f'# Or generate high-entropy hex token:\n'
                    f'{vname}_hex = secrets.token_hex(32)'
                )
            return {
                'diagnosis': "Standard pseudo-random generator (`random`) produces predictable sequences unsuitable for security tokens.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Replace `import random` with `import secrets` for all security contexts.",
                    "Use `secrets.token_hex()`, `secrets.token_urlsafe()`, or `secrets.randbelow()`."
                ],
                'defensive_principle': "Cryptographically Secure Randomness (CSPRNG)"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-338", "Weak PRNG", lang)

    def _remediate_path_traversal(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes path sanitization to prevent ../ directory escape."""
        if lang == 'python':
            before = line or 'with open(filename, "r") as f:'
            after = (
                f'# Remediation: Sanitize filename and restrict to base directory\n'
                f'import os\n\n'
                f'SAFE_DIR = os.path.abspath("/safe/storage")\n'
                f'clean_filename = os.path.basename(filename)\n'
                f'target_path = os.path.abspath(os.path.join(SAFE_DIR, clean_filename))\n\n'
                f'if not target_path.startswith(SAFE_DIR):\n'
                f'    raise PermissionError("Path traversal attempt detected")\n\n'
                f'with open(target_path, "r") as f:\n'
                f'    content = f.read()'
            )
            return {
                'diagnosis': "Direct use of user-supplied filename enables directory traversal (`../`) to access system files.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Strip directory prefixes using `os.path.basename()`.",
                    "Verify canonical path with `os.path.abspath()` starts with safe directory root."
                ],
                'defensive_principle': "Canonicalization & Jail Enclosure"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-22", "Path Traversal", lang)

    def _remediate_deserialization(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes safe serialization replacing pickle with json."""
        if lang == 'python':
            before = line or 'data = pickle.loads(untrusted_payload)'
            after = (
                f'# Remediation: Replace unsafe deserialization with JSON or protocol buffers\n'
                f'import json\n\n'
                f'data = json.loads(untrusted_payload)  # Safe: processes data, not executable objects'
            )
            return {
                'diagnosis': "Deserializing untrusted data with `pickle` allows arbitrary code execution via `__reduce__`.",
                'vulnerable_snippet': before,
                'fixed_snippet': after,
                'remediation_steps': [
                    "Never unpickle untrusted data.",
                    "Switch to safe serialization formats like JSON, MessagePack, or Protocol Buffers."
                ],
                'defensive_principle': "Safe Data Serialization Formats"
            }
        else:
            return self._generic_remediation(line, snippet, "CWE-502", "Insecure Deserialization", lang)

    def _remediate_log_exposure(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes structured, sanitized logging replacing raw print/log of sensitive data."""
        # Detect variable being printed or logged
        var_match = re.search(r'\{([a-zA-Z_]\w*)\}', line) or re.search(r'print\((?:f["\'].*?\{)?([a-zA-Z_]\w*)', line)
        var_name = var_match.group(1) if var_match else "data"
        before = line or f'print(f"User request: {{{var_name}}}")'

        if lang == 'python':
            after = (
                f'# Remediation: Use structured logging with sensitive field masking\n'
                f'import logging\n'
                f'logger = logging.getLogger(__name__)\n\n'
                f'# Mask or sanitize sensitive fields before output:\n'
                f'safe_{var_name} = "[REDACTED]" if is_sensitive else {var_name}\n'
                f'logger.info("Processing request completed successfully")'
            )
        else:
            after = (
                f'// Remediation: Remove sensitive variable from console output\n'
                f'console.log("Operation executed successfully");'
            )

        return {
            'diagnosis': f"Printing or logging potentially sensitive system data (`{var_name}`) leaks internal execution details into logs or consoles.",
            'vulnerable_snippet': before,
            'fixed_snippet': after,
            'remediation_steps': [
                "Never write raw user inputs, internal prompts, tokens, or exceptions directly to standard output.",
                "Use a configurable logging framework (`logging`) with appropriate log levels (DEBUG/INFO).",
                "Sanitize or redact sensitive fields before logging in production environments."
            ],
            'defensive_principle': "Least Privilege Log Minimization & Data Masking"
        }

    def _remediate_buffer_overflow(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes bounded memory operations replacing gets/strcpy/sprintf."""
        before = line or 'strcpy(dest, src);'
        after = (
            f'// Remediation: Use bounded copy operations with explicit buffer size\n'
            f'strncpy(dest, src, sizeof(dest) - 1);\n'
            f'dest[sizeof(dest) - 1] = \'\\0\'; // Ensure null-termination'
        )
        return {
            'diagnosis': "Unbounded memory buffer operation allows input to overflow allocated stack/heap memory.",
            'vulnerable_snippet': before,
            'fixed_snippet': after,
            'remediation_steps': [
                "Replace `strcpy()` with `strncpy()`, or `gets()` with `fgets()`.",
                "Always enforce destination buffer boundaries using `sizeof(dest)`."
            ],
            'defensive_principle': "Explicit Bounds Checking & Memory Safety"
        }

    def _remediate_tls_bypass(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes verified TLS certificate connections."""
        before = line or 'requests.get(url, verify=False)'
        after = (
            f'# Remediation: Enforce SSL/TLS certificate verification\n'
            f'requests.get(url, verify=True)  # Or pass path to trusted root CA cert bundle'
        )
        return {
            'diagnosis': "Disabling certificate validation (`verify=False`) exposes network communications to Man-in-the-Middle (MITM) attacks.",
            'vulnerable_snippet': before,
            'fixed_snippet': after,
            'remediation_steps': [
                "Always keep `verify=True` enabled in HTTPS requests.",
                "Install corporate certificates in the trusted system CA store rather than disabling verification globally."
            ],
            'defensive_principle': "Authenticated Encryption & Encrypted Channel Integrity"
        }

    def _remediate_xxe(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        """Synthesizes secure XML parser configuration disabling external DTD entities."""
        before = line or 'parser.parse(xml_input)'
        after = (
            f'# Remediation: Use defusedxml or disable external DTDs\n'
            f'import defusedxml.minidom\n\n'
            f'dom = defusedxml.minidom.parseString(xml_input)  # Disables entity expansion'
        )
        return {
            'diagnosis': "Parsing XML with external entity resolution allows attackers to read local files or trigger SSRF.",
            'vulnerable_snippet': before,
            'fixed_snippet': after,
            'remediation_steps': [
                "Use `defusedxml` package in Python for parsing untrusted XML input.",
                "Explicitly disable `resolve_entities` and DTD processing in your XML parser."
            ],
            'defensive_principle': "Disable Unneeded Parser Capabilities"
        }

    def _remediate_fork_bomb(self, line: str, snippet: str, lang: str) -> Dict[str, Any]:
        before = line or "while True:\n    os.fork()"
        after = (
            "# Context-Aware Remediation: Use bounded process pool executor\n"
            "from concurrent.futures import ProcessPoolExecutor\n\n"
            "def worker_task(task_id):\n"
            "    return f'Task {task_id} completed safely'\n\n"
            "with ProcessPoolExecutor(max_workers=4) as executor:\n"
            "    results = list(executor.map(worker_task, range(10)))"
        )
        return {
            'diagnosis': "Unbounded process creation or fork bomb pattern detected (CWE-400). Running this consumes all process slots and crashes the host OS.",
            'vulnerable_snippet': before,
            'fixed_snippet': after,
            'remediation_steps': [
                "Remove recursive or infinite os.fork() calls.",
                "Use a bounded ProcessPoolExecutor with a fixed max_workers limit (e.g., max_workers=4).",
                "Ensure worker tasks terminate cleanly."
            ],
            'defensive_principle': "Resource Limitation & Bounded Process Pool Execution (CWE-400)"
        }

    def _generic_remediation(self, line: str, snippet: str, cwe: str, msg: str, lang: str) -> Dict[str, Any]:
        """Fallback grounded remediation template."""
        return {
            'diagnosis': f"Vulnerability {cwe} detected: {msg}",
            'vulnerable_snippet': line or snippet or "# Vulnerable statement",
            'fixed_snippet': (
                f"# Remediation for {cwe} ({lang.upper()}):\n"
                f"# 1. Apply strict input validation and boundary checks\n"
                f"# 2. Enforce least privilege and defensive error handling\n"
                f"# 3. Never trust dynamic inputs without sanitization"
            ),
            'remediation_steps': [
                "Isolate input handling and sanitize before passing to sinks.",
                "Review framework-specific secure wrappers."
            ],
            'defensive_principle': "Defense-in-Depth & Robust Input Sanitization"
        }
