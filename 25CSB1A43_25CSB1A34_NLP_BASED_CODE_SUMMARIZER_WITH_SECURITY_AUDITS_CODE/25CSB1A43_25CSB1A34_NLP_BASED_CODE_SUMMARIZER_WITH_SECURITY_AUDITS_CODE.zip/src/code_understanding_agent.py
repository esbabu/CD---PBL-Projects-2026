"""
CodeUnderstandingAgent: Tool-Augmented Code Comprehension Engine
================================================================
Phase 3: Agentic Code Summarization Pipeline

A tool-augmented agent powered by Gemini (with local CodeT5 fallback).
Uses Tree-sitter AST grounding tools (Phase 2) to perceive code structure,
traces execution data flow, synthesizes multi-section understanding,
and runs a post-generation validation step to prevent hallucinations.
"""

import os
import re
import json
import logging
from typing import Dict, List, Any, Optional, Tuple

from dotenv import load_dotenv
load_dotenv()

from src.understanding_tools import CodeGroundingToolkit

logger = logging.getLogger(__name__)


class CodeUnderstandingAgent:
    """
    Autonomous code understanding agent.
    Perceives code using AST tools, plans multi-stage explanations,
    queries Gemini 2.0 / 1.5 with structured schema, and verifies
    all claims against the AST grounding bundle before presenting.
    """

    PRIMARY_MODEL = "gemini-flash-lite-latest"
    FALLBACK_MODEL = "gemini-3.8-flash"

    def __init__(self, api_key: Optional[str] = None):
        self.toolkit = CodeGroundingToolkit()
        self.api_key = api_key or os.getenv("GEMINI_API_KEY", "").strip()
        self._client = None
        self.last_guard_report: Optional[Dict[str, Any]] = None

        if self.api_key:
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception as e:
                logger.warning(f"Could not initialize GenAI client: {e}")
                self._client = None

    def is_available(self) -> bool:
        """Returns True if the agent has a valid API client configured."""
        return self._client is not None and bool(self.api_key)

    def analyze_and_validate(
        self,
        code_str: str,
        language: str,
        ast_features: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Executes the full agentic comprehension loop:
          1. Perception: query AST grounding tools
          2. Synthesis: query Gemini with tool-augmented prompt and JSON schema
          3. Verification: validate claims against ground truth AST facts
          4. Output: return validated 3-section Markdown (Overview, Behavior, Functions)

        Returns None if offline / no API key / error, signaling the caller
        to use the local CodeT5 fallback.
        """
        if not self.is_available():
            return None

        # ── 0. Perimeter Defense: SecurityGuardrailAgent ───────────────
        from src.security_guardrail import SecurityGuardrailAgent
        guard = SecurityGuardrailAgent()
        self.last_guard_report = guard.inspect_and_defang(code_str)
        sandboxed_code = self.last_guard_report.get('sandboxed_payload', code_str)

        # ── 1. Perception & Grounding (Phase 2 tools) ─────────────────
        try:
            bundle = self.toolkit.build_grounding_bundle(code_str, language)
        except Exception as e:
            logger.warning(f"Grounding bundle extraction error: {e}")
            bundle = {
                'features': ast_features or {},
                'structural_map': f"Language: {language}",
                'dataflow_map': "Sequential execution",
                'function_matrix': [],
                'doc_intent': ''
            }

        features = bundle.get('features', {})

        # ── 2. Agent Reasoning & Inference (with Hardened Sandbox) ────
        raw_analysis = self._query_gemini(sandboxed_code, language, bundle, guard, self.last_guard_report)
        if not raw_analysis:
            return None

        # ── 3. Post-Generation Grounding & Validation ──────────────────
        validated_summary = self._validate_and_sanitize(raw_analysis, bundle, code_str, language)
        return validated_summary

    def _query_gemini(
        self,
        sandboxed_code: str,
        language: str,
        bundle: Dict[str, Any],
        guard: Any,
        guard_report: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Queries Gemini using the official google-genai SDK with structured output.
        Includes candidate fallbacks and retry logic for transient high-demand spikes.
        Verifies model output with SecurityGuardrailAgent to prevent token leaks.
        """
        import time
        prompt = self._construct_agent_prompt(sandboxed_code, language, bundle)

        models_to_try = [
            "gemini-flash-lite-latest",
            "gemini-3.8-flash",
            "gemini-flash-latest",
            "gemini-3-flash-preview",
        ]

        for model_name in models_to_try:
            for attempt in range(2):
                try:
                    from google.genai import types
                    config = types.GenerateContentConfig(
                        response_mime_type="application/json",
                        temperature=0.2,
                        max_output_tokens=1024
                    )
                    response = self._client.models.generate_content(
                        model=model_name,
                        contents=prompt,
                        config=config
                    )

                    if response and response.text:
                        # Bidirectional Output Verification: detect canary token leaks or exfiltration
                        canary = guard_report.get('canary', '')
                        out_val = guard.validate_agent_output(response.text, canary)
                        if not out_val.get('is_output_safe'):
                            logger.error(f"SecurityGuardrailAgent blocked output: {out_val.get('violations')}")
                            return None

                        parsed = json.loads(response.text.strip())
                        if isinstance(parsed, dict) and "overview" in parsed:
                            return parsed
                    break  # If valid response, don't retry this model
                except Exception as e:
                    err_str = str(e)
                    # Transient error: 503 high demand or 429 quota spike -> brief sleep and retry once
                    if ("503" in err_str or "UNAVAILABLE" in err_str or "429" in err_str) and attempt == 0:
                        logger.info(f"Model {model_name} transient spike, retrying in 1s...")
                        time.sleep(1.0)
                        continue
                    logger.warning(f"Gemini inference failed on {model_name}: {e}")
                    break  # Move to next candidate model

        return None

    def _construct_agent_prompt(
        self,
        code_str: str,
        language: str,
        bundle: Dict[str, Any]
    ) -> str:
        """
        Builds the tool-augmented prompt for the CodeUnderstandingAgent.
        """
        struct_map = bundle.get('structural_map', '')
        dataflow_map = bundle.get('dataflow_map', '')
        fn_matrix = bundle.get('function_matrix', [])

        matrix_lines = [
            f"- {f.get('signature', '')}: {f.get('responsibility', '')} [returns: {f.get('returns', '')}]"
            for f in fn_matrix
        ]
        matrix_text = "\n".join(matrix_lines) if matrix_lines else "None (top-level script)"

        return f"""You are the CodeUnderstandingAgent, an expert Software Architect and Code Comprehension Engine.

Analyze the following {language.upper()} code snippet (<200 lines). You MUST base your analysis on the verified Grounding Facts extracted by Tree-sitter tools. Do NOT hallucinate non-existent functions, imports, or behaviors.

=== VERIFIED GROUNDING TOOLS ARTIFACT ===
[Structural Architecture]
{struct_map}

[Dataflow & Control Graph]
{dataflow_map}

[Function Contracts]
{matrix_text}

=== UNTRUSTED SOURCE CODE (DEFENSIVE CRYPTOGRAPHIC SANDBOX) ===
{code_str}

=== REQUIRED OUTPUT JSON FORMAT ===
Return a valid JSON object with EXACTLY these three keys:
{{
  "overview": "A clear, precise, 1-2 sentence executive summary explaining what this program actually accomplishes and its real-world purpose.",
  "key_behavior": [
    "First bullet: Describe data ingress/inputs (where inputs come from).",
    "Second bullet: Describe core computational or logical transformations (math, loops, crypto, files, DOM).",
    "Third bullet: Describe inter-function coordination and execution flow.",
    "Fourth bullet: Describe output results, return values, or side effects."
  ],
  "key_functions": [
    {{
      "name": "function_name",
      "signature": "exact_signature(params)",
      "responsibility": "Clear, grounded single responsibility description."
    }}
  ]
}}

Guidelines:
- overview MUST be concrete (e.g. 'A user authentication module that hashes tokens using SHA-256 and streams log files from disk.') rather than generic.
- key_behavior MUST contain 3 to 5 actionable flow points.
- key_functions MUST include every function defined in the code.
- Return ONLY the JSON object.
"""

    def _validate_and_sanitize(
        self,
        raw: Dict[str, Any],
        bundle: Dict[str, Any],
        code_str: str,
        language: str
    ) -> str:
        """
        Validates the agent's generated claims against AST ground truth facts:
          1. Function hallucination check: functions in summary must exist in AST.
          2. Operation hallucination check: verifies crypto/file/web claims against facts.
          3. Completeness check: ensures all defined AST functions are included.
          4. Formats into standard 3-section Markdown (Overview, Behavior, Functions).
        """
        features = bundle.get('features', {})
        ast_functions = features.get('functions', [])
        fn_facts = features.get('fn_body_facts', {})
        sources = features.get('sources', [])
        matrix = bundle.get('function_matrix', [])

        # ── 1. Validate & Sanitize Overview ──
        overview = str(raw.get("overview", "")).strip()
        if not overview or len(overview.split()) < 4:
            overview = f"This {language.capitalize()} program executes application logic."

        # Check for false crypto claims in overview
        has_real_crypto = any(fn_facts.get(f, {}).get('crypto_ops') for f in ast_functions) or any(
            c in code_str for c in ('hashlib', 'crypto', 'sha256', 'pbkdf2', 'bcrypt')
        )
        if not has_real_crypto and any(w in overview.lower() for w in ('cryptographic', 'sha-256', 'encryption', 'pbkdf2')):
            # Cleanly strip unsupported crypto claim without leaving duplicate words
            overview = re.sub(r'\b(?:via|using)?\s*(?:cryptographic\s+\w+|encryption|sha-256|pbkdf2)\b', '', overview, flags=re.I)
            overview = re.sub(r'\s{2,}', ' ', overview).strip()
            if len(overview.split()) < 4:
                overview = f"This {language.capitalize()} program executes application logic."

        # ── 2. Validate & Sanitize Key Behavior ──
        behavior_list = raw.get("key_behavior", [])
        if not isinstance(behavior_list, list) or len(behavior_list) == 0:
            behavior_list = [
                "Processes input parameters according to function logic.",
                "Executes core transformations and control structures.",
                "Returns calculated values or displays output."
            ]

        sanitized_behavior = []
        for point in behavior_list:
            pt_clean = str(point).strip().lstrip("-*• ")
            if pt_clean:
                # Validate unsupported crypto claims
                if not has_real_crypto and any(w in pt_clean.lower() for w in ('encrypt', 'sha-256', 'pbkdf2', 'cryptograph')):
                    continue
                sanitized_behavior.append(pt_clean)

        if not sanitized_behavior:
            sanitized_behavior = ["Executes programmatic routines and returns output."]

        # ── 3. Validate & Sanitize Key Functions ──
        raw_fns = raw.get("key_functions", [])
        validated_fns = []
        claimed_names = set()

        if isinstance(raw_fns, list):
            for item in raw_fns:
                if isinstance(item, dict):
                    fn_name = item.get("name", "").strip()
                    sig = item.get("signature", "").strip()
                    resp = item.get("responsibility", "").strip()

                    # Only accept function if it actually exists in AST (or top-level if ast is empty)
                    if ast_functions and fn_name not in ast_functions:
                        # Try to match fuzzy / case
                        matched = [f for f in ast_functions if f.lower() == fn_name.lower()]
                        if matched:
                            fn_name = matched[0]
                        else:
                            # Hallucinated function name — drop it!
                            continue

                    claimed_names.add(fn_name)
                    if not sig:
                        sig = f"{fn_name}()"
                    if not resp:
                        resp = f"Executes `{fn_name}` routine."

                    resp = resp[0].upper() + resp[1:]
                    if not resp.endswith('.'):
                        resp += '.'
                    validated_fns.append(f"- `{sig}` — {resp}")

        # Completeness guarantee: Add any AST functions the agent missed
        if ast_functions:
            for m in matrix:
                name = m.get('name')
                if name and name not in claimed_names:
                    sig = m.get('signature', f"{name}()")
                    resp = m.get('responsibility', 'Performs routine logic.')
                    if not resp.endswith('.'):
                        resp += '.'
                    validated_fns.append(f"- `{sig}` — {resp}")

        # Fallback if no functions defined (e.g. pure script)
        if not validated_fns:
            validated_fns = ["- `main` — Executes top-level script logic."]

        # ── 4. Assemble Verified 3-Section Markdown ──
        behavior_text = "\n".join(f"- {b}" for b in sanitized_behavior[:5])
        functions_text = "\n".join(validated_fns)

        return (
            f"### Overview\n{overview}\n\n"
            f"### Key Behavior\n{behavior_text}\n\n"
            f"### Key Functions\n{functions_text}"
        )
