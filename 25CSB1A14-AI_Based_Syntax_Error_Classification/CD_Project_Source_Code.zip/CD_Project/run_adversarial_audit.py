"""
Adversarial Audit Evaluation Runner for CD_Project.

Conducts an independent adversarial audit using data/adversarial_audit_corpus.json.
Measures detector and end-to-end enforcement performance, side-effect isolation,
source preservation, latency distributions, and outputs data/adversarial_audit_results.json.
"""

import json
import os
import sys
import time
from typing import Any, Dict, List, Tuple
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from assessment_engine import AssessmentEngine, AgenticAttackDetector
from agents.repair_agent import RepairAgent
from evaluate_attacks import SEVERITY_WEIGHTS


def evaluate_adversarial_corpus(
    corpus_file: str,
    iterations: int = 10,
) -> Dict[str, Any]:
    with open(corpus_file, "r", encoding="utf-8") as f:
        cases = json.load(f)

    detector = AgenticAttackDetector()
    engine = AssessmentEngine()
    repair_agent = RepairAgent()

    case_evaluations: List[Dict[str, Any]] = []
    detector_latencies_all: List[float] = []
    enforcement_latencies_all: List[float] = []

    for case in cases:
        case_id = case["id"]
        category = case["category"]
        is_attack = bool(case["is_attack"])
        expected_action = case.get("expected_enforcement_action", "ALLOW")
        severity = case.get("severity", "none").lower()
        input_type = case.get("input_type", "auto")
        input_data = case["input_data"]

        det_times: List[float] = []
        enf_times: List[float] = []

        last_detect_res = None
        last_blocked = False
        last_enf_detail = ""
        source_preserved = True
        temp_file_created_on_block = False
        compiler_invoked_on_block = False

        for iter_idx in range(iterations):
            # 1. Detector-only latency measurement
            t0 = time.perf_counter()
            detect_res = detector.assess(input_data, context_type=input_type, is_protected_action=False)
            t_det = (time.perf_counter() - t0) * 1000.0
            det_times.append(t_det)
            last_detect_res = detect_res

            # 2. End-to-end enforcement latency & side-effects
            t1 = time.perf_counter()
            blocked = False
            enf_detail = ""

            if input_type == "source_code":
                code_str = input_data if isinstance(input_data, str) else ""
                assessment = engine.evaluate(code_str)
                blocked = not assessment.passed or assessment.gate_decision == "BLOCKED"
                enf_detail = f"Gate decision: {assessment.gate_decision}, score: {assessment.security_score}"
            elif input_type == "repair_plan":
                if isinstance(input_data, dict):
                    prop_code = input_data.get("proposed_code", "")
                    requires_app = input_data.get("requires_approval", True)
                    diff = input_data.get("diff", "")
                    
                    # Screen proposal
                    plan_eval = detector.assess(input_data, context_type="repair_plan")
                    if plan_eval.detected and plan_eval.action == "BLOCK":
                        blocked = True
                        enf_detail = f"Plan screening: {plan_eval.reason}"
                    elif not requires_app:
                        blocked = True
                        enf_detail = "Approval bypass rejected"
                    else:
                        # Test enforcement with approved=True
                        res_app = repair_agent.apply_and_verify(
                            original_source="#include <cstdlib>\nint main() { return 0; }",
                            proposed_code=prop_code,
                            approved=True,
                        )
                        blocked = res_app.verification_status in ("rejected", "rollback") or not res_app.success
                        enf_detail = f"Repair apply_and_verify: status={res_app.verification_status}"
                        source_preserved = (res_app.proposed_code == "#include <cstdlib>\nint main() { return 0; }") if blocked else True
                else:
                    blocked = False
                    enf_detail = "Invalid plan format"
            elif input_type == "repair_diff":
                diff_text = str(input_data)
                diff_eval = detector.assess(diff_text, context_type="repair_diff", is_protected_action=True)
                if diff_eval.detected and diff_eval.action == "BLOCK":
                    blocked = True
                    enf_detail = f"Diff screening: {diff_eval.reason}"
                else:
                    # In repair diffs, check whether applying this diff to safe code triggers repair agent rejection
                    # Synthesize proposed code from diff additions
                    added_lines = [l[1:] for l in diff_text.splitlines() if l.startswith("+") and not l.startswith("+++")]
                    prop_synthetic = "#include <cstdlib>\nint main() {\n" + "\n".join(added_lines) + "\n    return 0;\n}"
                    
                    # Test both unapproved and approved
                    res_unapproved = repair_agent.apply_and_verify(
                        original_source="#include <cstdlib>\nint main() { return 0; }",
                        proposed_code=prop_synthetic,
                        approved=False,
                    )
                    assert res_unapproved.verification_status == "rejected"
                    assert res_unapproved.proposed_code == "#include <cstdlib>\nint main() { return 0; }"

                    res_approved = repair_agent.apply_and_verify(
                        original_source="#include <cstdlib>\nint main() { return 0; }",
                        proposed_code=prop_synthetic,
                        approved=True,
                    )
                    blocked = res_approved.verification_status in ("rejected", "rollback") or not res_approved.success
                    enf_detail = f"Repair verification: status={res_approved.verification_status}, diff_eval={diff_eval.action}"
                    if blocked:
                        source_preserved = (res_approved.proposed_code == "#include <cstdlib>\nint main() { return 0; }")
            else:  # user_prompt or other direct inputs
                blocked = detect_res.detected and detect_res.action == "BLOCK"
                enf_detail = f"Prompt boundary: {detect_res.action}"

            t_enf = (time.perf_counter() - t1) * 1000.0
            enf_times.append(t_enf)
            last_blocked = blocked
            last_enf_detail = enf_detail

        avg_det_ms = float(np.mean(det_times))
        avg_enf_ms = float(np.mean(enf_times))
        detector_latencies_all.extend(det_times)
        enforcement_latencies_all.extend(enf_times)

        # Classification label mapping
        detected = bool(last_detect_res.detected)

        case_evaluations.append({
            "id": case_id,
            "category": category,
            "is_attack": is_attack,
            "severity": severity,
            "expected_action": expected_action,
            "detected": detected,
            "detected_type": last_detect_res.attack_type,
            "detector_action": last_detect_res.action,
            "detector_reason": last_detect_res.reason,
            "confidence": last_detect_res.confidence,
            "event_id": last_detect_res.event_id,
            "blocked": last_blocked,
            "enforcement_detail": last_enf_detail,
            "source_preserved": source_preserved,
            "detector_latency_ms": round(avg_det_ms, 3),
            "enforcement_latency_ms": round(avg_enf_ms, 3),
        })

    # Metric calculations
    tp = sum(1 for r in case_evaluations if r["is_attack"] and r["detected"])
    fp = sum(1 for r in case_evaluations if not r["is_attack"] and r["detected"])
    tn = sum(1 for r in case_evaluations if not r["is_attack"] and not r["detected"])
    fn = sum(1 for r in case_evaluations if r["is_attack"] and not r["detected"])

    total_attacks = sum(1 for r in case_evaluations if r["is_attack"])
    total_benign = sum(1 for r in case_evaluations if not r["is_attack"])

    precision = (tp / (tp + fp)) if (tp + fp) > 0 else 0.0
    recall = (tp / (tp + fn)) if (tp + fn) > 0 else 0.0
    f1_score = (2.0 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
    false_positive_rate = (fp / (fp + tn)) if (fp + tn) > 0 else 0.0
    false_negative_rate = (fn / (fn + tp)) if (fn + tp) > 0 else 0.0

    # Enforcement metrics
    blocked_attacks = sum(1 for r in case_evaluations if r["is_attack"] and r["blocked"])
    attack_block_rate = (blocked_attacks / total_attacks) if total_attacks > 0 else 0.0

    passed_benign = sum(1 for r in case_evaluations if not r["is_attack"] and not r["blocked"])
    benign_pass_rate = (passed_benign / total_benign) if total_benign > 0 else 0.0

    # Severity weighted detection
    attack_cases = [r for r in case_evaluations if r["is_attack"]]
    total_weight = sum(SEVERITY_WEIGHTS.get(r["severity"], 0.0) for r in attack_cases)
    detected_weight = sum(SEVERITY_WEIGHTS.get(r["severity"], 0.0) for r in attack_cases if r["detected"])
    severity_weighted_rate = (detected_weight / total_weight) if total_weight > 0 else 0.0

    # Per-category metrics
    categories = sorted(list(set(r["category"] for r in case_evaluations)))
    category_breakdown = {}
    for cat in categories:
        cat_cases = [r for r in case_evaluations if r["category"] == cat]
        cat_attacks = [r for r in cat_cases if r["is_attack"]]
        cat_benign = [r for r in cat_cases if not r["is_attack"]]
        category_breakdown[cat] = {
            "total": len(cat_cases),
            "attacks": len(cat_attacks),
            "benign": len(cat_benign),
            "tp": sum(1 for r in cat_attacks if r["detected"]),
            "fn": sum(1 for r in cat_attacks if not r["detected"]),
            "fp": sum(1 for r in cat_benign if r["detected"]),
            "tn": sum(1 for r in cat_benign if not r["detected"]),
            "attack_block_rate": (sum(1 for r in cat_attacks if r["blocked"]) / len(cat_attacks)) if cat_attacks else None,
            "benign_pass_rate": (sum(1 for r in cat_benign if not r["blocked"]) / len(cat_benign)) if cat_benign else None,
        }

    # False negatives and false positives lists
    false_negatives = [
        {
            "id": r["id"],
            "category": r["category"],
            "severity": r["severity"],
            "reason": "Attack was not detected by detector",
            "enforcement_outcome": "BLOCKED" if r["blocked"] else "ALLOWED",
            "enforcement_detail": r["enforcement_detail"],
        }
        for r in case_evaluations if r["is_attack"] and not r["detected"]
    ]

    false_positives = [
        {
            "id": r["id"],
            "category": r["category"],
            "detected_type": r["detected_type"],
            "detector_reason": r["detector_reason"],
            "enforcement_outcome": "BLOCKED" if r["blocked"] else "ALLOWED",
            "enforcement_detail": r["enforcement_detail"],
        }
        for r in case_evaluations if not r["is_attack"] and r["detected"]
    ]

    # Latency percentiles
    det_arr = np.array(detector_latencies_all)
    enf_arr = np.array(enforcement_latencies_all)

    metrics = {
        "confusion_matrix": {
            "true_positives": tp,
            "false_positives": fp,
            "true_negatives": tn,
            "false_negatives": fn,
            "total_attacks": total_attacks,
            "total_benign": total_benign,
            "total_cases": len(case_evaluations),
        },
        "performance_rates": {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1_score, 4),
            "false_positive_rate": round(false_positive_rate, 4),
            "false_negative_rate": round(false_negative_rate, 4),
            "attack_block_rate": round(attack_block_rate, 4),
            "benign_pass_rate": round(benign_pass_rate, 4),
            "severity_weighted_detection_rate": round(severity_weighted_rate, 4),
        },
        "category_breakdown": category_breakdown,
        "false_negatives": false_negatives,
        "false_positives": false_positives,
        "latency_stats": {
            "total_measurements": len(detector_latencies_all),
            "iterations_per_case": iterations,
            "detector_only_ms": {
                "mean": round(float(np.mean(det_arr)), 4),
                "median": round(float(np.median(det_arr)), 4),
                "p90": round(float(np.percentile(det_arr, 90)), 4),
                "p99": round(float(np.percentile(det_arr, 99)), 4),
            },
            "enforcement_end_to_end_ms": {
                "mean": round(float(np.mean(enf_arr)), 4),
                "median": round(float(np.median(enf_arr)), 4),
                "p90": round(float(np.percentile(enf_arr, 90)), 4),
                "p99": round(float(np.percentile(enf_arr, 99)), 4),
            },
            "sample_limitations_note": (
                f"Latency evaluated across {len(case_evaluations)} cases with {iterations} repetitions per case "
                f"({len(detector_latencies_all)} total measurements). The P99 estimate represents the top 1% tail latency "
                "within this local evaluation environment and may reflect OS scheduler spikes on Windows."
            ),
        },
    }

    full_output = {
        "corpus_name": os.path.basename(corpus_file),
        "total_cases": len(case_evaluations),
        "metrics": metrics,
        "case_evaluations": case_evaluations,
    }

    output_path = os.path.join(BASE_DIR, "data", "adversarial_audit_results.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(full_output, f, indent=2)

    return full_output


if __name__ == "__main__":
    corpus_p = os.path.join(BASE_DIR, "data", "adversarial_audit_corpus.json")
    print(f"Running adversarial audit evaluation on {corpus_p}...")
    res = evaluate_adversarial_corpus(corpus_p, iterations=10)
    cm = res["metrics"]["confusion_matrix"]
    rates = res["metrics"]["performance_rates"]
    lat = res["metrics"]["latency_stats"]

    print("\n=== CONFUSION MATRIX ===")
    print(f"Total Cases:     {cm['total_cases']} (Attacks: {cm['total_attacks']}, Benign: {cm['total_benign']})")
    print(f"True Positives:  {cm['true_positives']}")
    print(f"False Positives: {cm['false_positives']}")
    print(f"True Negatives:  {cm['true_negatives']}")
    print(f"False Negatives: {cm['false_negatives']}")

    print("\n=== PERFORMANCE RATES ===")
    print(f"Precision:        {rates['precision']:.4f}")
    print(f"Recall:           {rates['recall']:.4f}")
    print(f"F1 Score:         {rates['f1_score']:.4f}")
    print(f"FPR:              {rates['false_positive_rate']:.4f}")
    print(f"FNR:              {rates['false_negative_rate']:.4f}")
    print(f"Attack Block Rate:{rates['attack_block_rate']:.4f}")
    print(f"Benign Pass Rate: {rates['benign_pass_rate']:.4f}")
    print(f"Severity-Weighted:{rates['severity_weighted_detection_rate']:.4f}")

    print("\n=== LATENCY (ms) ===")
    print(f"Detector Mean/Median/P90/P99:    {lat['detector_only_ms']['mean']} / {lat['detector_only_ms']['median']} / {lat['detector_only_ms']['p90']} / {lat['detector_only_ms']['p99']}")
    print(f"Enforcement Mean/Median/P90/P99: {lat['enforcement_end_to_end_ms']['mean']} / {lat['enforcement_end_to_end_ms']['median']} / {lat['enforcement_end_to_end_ms']['p90']} / {lat['enforcement_end_to_end_ms']['p99']}")

    print("\n=== FALSE NEGATIVES ===")
    for fn in res["metrics"]["false_negatives"]:
        print(f"- {fn['id']} ({fn['category']}): {fn['reason']} | Enforcement: {fn['enforcement_outcome']} ({fn['enforcement_detail']})")

    print("\n=== FALSE POSITIVES ===")
    for fp in res["metrics"]["false_positives"]:
        print(f"- {fp['id']} ({fp['category']}): {fp['detector_reason']} | Enforcement: {fp['enforcement_outcome']} ({fp['enforcement_detail']})")
