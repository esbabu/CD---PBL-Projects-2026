"""
Pre-Diagnostic Security and Code Quality Assessment Engine for C++.

Provides deterministic, rule-based static analysis to evaluate C++ code
in two independent dimensions before syntax diagnosis:
1. Security Assessment: Rule-based checks for command execution, buffer overflows,
   risky memory handling, format string attacks, path traversal, hardcoded secrets.
2. Code Quality Assessment: Measurable checks for function length, nesting depth,
   cyclomatic complexity approximation, pass-by-value of heavy containers, endl in loops,
   duplicate logic, and magic numbers.

Lexical awareness ensures that comments and string literals are never misidentified
as executable code.
"""

import base64
import collections
import hashlib
import os
import re
import time
import uuid
import unicodedata
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Tuple, Set
from engine.cpp_tokenizer import EnhancedCppLexicalMasker, CppToken

try:
    from agents.base import append_audit_log
except ImportError:
    append_audit_log = None



DEFAULT_SECURITY_THRESHOLD = 90.0
DEFAULT_QUALITY_THRESHOLD = 90.0

# Severity deduction weights
SECURITY_SEVERITY_WEIGHTS = {
    "critical": 35.0,
    "high": 20.0,
    "medium": 10.0,
    "low": 5.0,
    "info": 0.0,
}

QUALITY_SEVERITY_WEIGHTS = {
    "high": 15.0,
    "medium": 8.0,
    "low": 4.0,
    "info": 0.0,
}

# Maximum deduction caps per quality category to ensure calibrated scoring
QUALITY_CATEGORY_CAPS = {
    "magic_numbers": 12.0,
    "endl_in_loop": 8.0,
    "post_increment": 8.0,
    "pass_by_value": 20.0,
    "nesting": 25.0,
    "complexity": 25.0,
    "function_length": 25.0,
    "duplicate_logic": 16.0,
}


@dataclass
class Finding:
    rule_id: str
    title: str
    severity: str  # "critical", "high", "medium", "low", "info"
    line: int
    description: str
    mitigation: str
    evidence: str
    cwe_id: str = "N/A"
    category: str = "General Security"
    confidence: str = "High"
    column: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AssessmentResult:
    security_score: float
    quality_score: float
    security_threshold: float
    quality_threshold: float
    security_findings: List[Dict[str, Any]]
    quality_findings: List[Dict[str, Any]]
    critical_security_issue: bool
    assessment_completed: bool
    assessment_errors: List[str]
    gate_decision: str  # "PASSED" or "BLOCKED"
    passed: bool
    metrics: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AttackAssessmentResult:
    detected: bool
    attack_type: Optional[str] = None
    severity: str = "none"  # "critical", "high", "medium", "low", "none"
    confidence: float = 0.0
    reason: str = ""
    action: str = "ALLOW"  # "BLOCK", "ALERT", "ALLOW", "LOG"
    event_id: str = ""
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# Zero-width, invisible formatting, and bidirectional control characters
# (U+200B-U+200F, U+FEFF, U+2060-U+206F, U+00AD, U+202A-U+202E, U+180E)
ZERO_WIDTH_CHARS_PATTERN: re.Pattern = re.compile(
    r'[\u200B-\u200F\uFEFF\u2060-\u206F\u00AD\u202A-\u202E\u180E]'
)

# Bounded deduplication cache for audit logging: (audit_log_path, event_id, event_type, payload_signature)
_LOGGED_AUDIT_EVENTS: "collections.OrderedDict[Tuple[str, str, str, str], bool]" = collections.OrderedDict()
_MAX_AUDIT_DEDUP_SIZE = 5000


def reset_audit_dedup() -> None:
    """Resets the audit logging deduplication cache (useful in test suites)."""
    _LOGGED_AUDIT_EVENTS.clear()


def _record_audit_safely(
    audit_log_path: Optional[str],
    event_id: str,
    event_type: str,
    agent_name: str,
    severity: str,
    decision: str,
    enforcement_outcome: str,
    error_summary: str,
    attack_category: Optional[str] = None,
    error_category: Optional[str] = None,
    latency_ms: float = 0.0,
    payload_hash: Optional[str] = None,
    **extra_metadata: Any,
) -> bool:
    """
    Safely records an audit log entry using append_audit_log while:
    1. Deduplicating entries by (audit_log_path, event_id, event_type, payload_signature).
    2. Ensuring distinct security events cannot be silently omitted even if truncated event IDs collide.
    3. Ensuring no secrets or sensitive source content are logged.
    4. Handling all logging errors safely without crashing callers.
    """
    norm_path = os.path.abspath(audit_log_path) if audit_log_path else "default"

    if payload_hash:
        payload_sig = str(payload_hash)
    elif "payload_hash" in extra_metadata:
        payload_sig = str(extra_metadata["payload_hash"])
    else:
        fp_parts = [
            str(agent_name),
            str(error_summary),
            str(attack_category),
            str(severity),
            str(decision),
            str(enforcement_outcome),
        ]
        if extra_metadata:
            fp_parts.append(str(sorted((k, str(v)) for k, v in extra_metadata.items() if k != "payload_hash")))
        payload_sig = hashlib.sha256("|".join(fp_parts).encode("utf-8", errors="ignore")).hexdigest()

    dedup_key = (norm_path, str(event_id), str(event_type), payload_sig)
    if dedup_key in _LOGGED_AUDIT_EVENTS:
        return False

    if len(_LOGGED_AUDIT_EVENTS) >= _MAX_AUDIT_DEDUP_SIZE:
        _LOGGED_AUDIT_EVENTS.popitem(last=False)
    _LOGGED_AUDIT_EVENTS[dedup_key] = True

    if append_audit_log is not None:
        clean_extra = {k: v for k, v in extra_metadata.items() if k != "payload_hash"}
        try:
            append_audit_log(
                agent_name=agent_name,
                latency_ms=round(latency_ms, 2),
                success=False,
                fallback=False,
                event=event_type,
                event_id=str(event_id),
                attack_category=attack_category,
                severity=severity,
                decision=decision,
                requested_action=decision,
                enforcement_outcome=enforcement_outcome,
                error_category=error_category or "security_violation",
                error_summary=str(error_summary)[:200],
                audit_log_path=audit_log_path,
                **clean_extra,
            )
            return True
        except Exception:
            pass
    return False



class CppLexicalMasker(EnhancedCppLexicalMasker):
    """
    Splits C++ source code into executable code, comments, and string literals,
    producing a masked version of the source where comments and strings are replaced
    by whitespace preserving line numbers and character offsets.
    Maintains a token stream with exact line/column metadata.
    """

    def __init__(self, source: str):
        super().__init__(source)


class SecurityAnalyzer:
    """
    Deterministic rule-based static security analyzer for C++ code.
    Runs checks on masked code to ensure comments and string literals
    do not cause false positives.
    """

    def __init__(self, raw_source: str, masker: CppLexicalMasker):
        self.raw_source = raw_source
        self.masker = masker
        self.masked_source = masker.masked_source
        self.lines_raw = raw_source.splitlines()
        self.lines_masked = self.masked_source.splitlines()

    def analyze(self) -> Tuple[List[Finding], bool]:
        findings: List[Finding] = []

        # 1. Unsafe Stream Input Handling (cin >> char[])
        findings.extend(self._check_input_handling())

        # 2. Path Traversal & Sensitive File Access
        findings.extend(self._check_file_and_paths())

        # 3. Hardcoded Credentials / Secrets
        findings.extend(self._check_hardcoded_secrets())

        # 4. Declarative Sinks & Modular SecurityRuleRegistry extensions
        try:
            from security_rules import REGISTRY
            ext_findings, _ = REGISTRY.analyze(self.raw_source, self.masker)
            findings.extend(ext_findings)
        except Exception as e:
            logger.warning("Error running SecurityRuleRegistry: %s", e)

        # Deduplicate findings by (rule_id, line, column)
        deduped = self._deduplicate_findings(findings)

        has_critical = any(f.severity == "critical" for f in deduped)
        return deduped, has_critical

    def _get_raw_line(self, line_num: int) -> str:
        if 1 <= line_num <= len(self.lines_raw):
            return self.lines_raw[line_num - 1].strip()
        return ""

    def _check_command_execution(self) -> List[Finding]:
        try:
            from engine.sink_detector import detect_declarative_sinks
            from security_rules import AnalysisContext
            ctx = AnalysisContext(self.raw_source, self.masker)
            return [f for f in detect_declarative_sinks(ctx) if f.rule_id.startswith("SEC-CMD")]
        except Exception:
            return []

    def _check_buffer_and_memory(self) -> List[Finding]:
        try:
            from engine.sink_detector import detect_declarative_sinks
            from security_rules import AnalysisContext
            ctx = AnalysisContext(self.raw_source, self.masker)
            return [f for f in detect_declarative_sinks(ctx) if f.rule_id.startswith("SEC-BUF")]
        except Exception:
            return []

    def _check_format_strings(self) -> List[Finding]:
        try:
            from engine.sink_detector import detect_declarative_sinks
            from security_rules import AnalysisContext
            ctx = AnalysisContext(self.raw_source, self.masker)
            return [f for f in detect_declarative_sinks(ctx) if f.rule_id.startswith("SEC-FMT")]
        except Exception:
            return []

    def _check_input_handling(self) -> List[Finding]:
        findings = []
        # Check unbounded cin >> buf into raw char arrays (scanf is handled by declarative sinks)
        cin_raw_regex = re.compile(r'\bcin\s*>>\s*([a-zA-Z_][a-zA-Z0-9_]*)')
        char_array_decl = re.compile(r'\bchar\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\[\s*\d+\s*\]')
        declared_char_arrays = set()
        for line in self.lines_masked:
            for match in char_array_decl.finditer(line):
                declared_char_arrays.add(match.group(1))

        if declared_char_arrays:
            for idx, line in enumerate(self.lines_masked, start=1):
                # If setw is used on this line, extraction is bounded and safe
                if "setw" in line:
                    continue
                for m in cin_raw_regex.finditer(line):
                    var_name = m.group(1)
                    if var_name in declared_char_arrays:
                        findings.append(Finding(
                            rule_id="SEC-INP-002",
                            title="Potential Buffer Overflow Risk via Unbounded cin >> char[]",
                            severity="high",
                            line=idx,
                            description=f"Direct extraction 'cin >> {var_name}' into raw fixed-size char array without std::setw() risks unbounded input overflow into adjacent memory.",
                            mitigation=f"Use std::cin >> std::setw(sizeof({var_name})) {var_name}; or migrate {var_name} to std::string.",
                            evidence=self._get_raw_line(idx),
                        ))
        return findings

    def _check_file_and_paths(self) -> List[Finding]:
        findings = []
        # Inspect raw string literals for directory traversal or sensitive OS files
        sensitive_targets = [
            (r"\.\./\.\./", "SEC-PATH-001", "Relative Path Traversal Sequence", "high",
             "Hardcoded relative directory traversal '../' detected in path specification.",
             "Sanitize and validate paths against an approved base directory using canonical paths."),
            (r"/etc/(passwd|shadow|hosts)", "SEC-PATH-002", "Access to Sensitive System Configuration File", "high",
             "Reference to sensitive operating system security file detected.",
             "Do not access OS-level credential files directly."),
            (r"[A-Za-z]:\\Windows\\System32", "SEC-PATH-003", "Hardcoded System Directory Access", "medium",
             "Direct reference to Windows System32 directory detected.",
             "Use environment variables or standard system API lookup instead of hardcoded paths."),
        ]

        # Only check string literals that are part of file open / include / stream operations in masked lines
        file_op_regex = re.compile(r'\b(fopen|freopen|ifstream|ofstream|fstream|remove|unlink)\b')
        for idx, line in enumerate(self.lines_masked, start=1):
            if file_op_regex.search(line):
                raw_line = self._get_raw_line(idx)
                norm_line = ZERO_WIDTH_CHARS_PATTERN.sub('', raw_line)
                for pat, rule_id, title, severity, desc, mitig in sensitive_targets:
                    if re.search(pat, norm_line, re.IGNORECASE):
                        findings.append(Finding(
                            rule_id=rule_id,
                            title=title,
                            severity=severity,
                            line=idx,
                            description=desc,
                            mitigation=mitig,
                            evidence=raw_line,
                        ))
        return findings

    def _check_hardcoded_secrets(self) -> List[Finding]:
        findings = []
        # Check variable declarations in masked lines that assign string literals in raw lines
        # e.g., const char* password = "..."; or string api_key = "...";
        secret_var_regex = re.compile(r'\b(password|passwd|secret|api_key|token|auth_token|private_key)\s*=\s*"([^"]+)"', re.IGNORECASE)
        for idx, raw_line in enumerate(self.lines_raw, start=1):
            # Check if this line actually contains executable assignment in masked line
            masked_line = self.lines_masked[idx - 1]
            if '=' in masked_line and not masked_line.strip().startswith('//'):
                norm_line = ZERO_WIDTH_CHARS_PATTERN.sub('', raw_line)
                m = secret_var_regex.search(norm_line)
                if m:
                    val = m.group(2)
                    if len(val.strip()) > 3 and not val.startswith("YOUR_") and not val == "test":
                        findings.append(Finding(
                            rule_id="SEC-CRED-001",
                            title="Hardcoded Credential / Secret in Source",
                            severity="medium",
                            line=idx,
                            description="Hardcoded authentication credential or secret detected in source text.",
                            mitigation="Store credentials in environment variables or a dedicated secret management vault.",
                            evidence=f"{m.group(1)} = \"***\"",
                        ))
        return findings

    def _deduplicate_findings(self, findings: List[Finding]) -> List[Finding]:
        seen_keys: Dict[Tuple[str, int], Finding] = {}
        deduped: List[Finding] = []
        severity_rank = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

        for f in findings:
            key = (f.rule_id, f.line)
            if key not in seen_keys:
                seen_keys[key] = f
                deduped.append(f)
            else:
                existing = seen_keys[key]
                # Keep higher-severity finding if the same rule triggers multiple times on a line
                if severity_rank.get(f.severity, 0) > severity_rank.get(existing.severity, 0):
                    deduped.remove(existing)
                    seen_keys[key] = f
                    deduped.append(f)
        return deduped


class QualityAnalyzer:
    """
    Deterministic rule-based code quality and optimization analyzer.
    Analyzes measurable structural metrics:
    - Function length (LOC)
    - Control flow nesting depth
    - Cyclomatic complexity approximation
    - Pass-by-value of heavy containers
    - std::endl inside loops
    - Post-increment on iterators
    - Duplicate logic branches
    - Magic numbers
    """

    def __init__(self, raw_source: str, masker: CppLexicalMasker):
        self.raw_source = raw_source
        self.masker = masker
        self.masked_source = masker.masked_source
        self.lines_raw = raw_source.splitlines()
        self.lines_masked = self.masked_source.splitlines()

    def analyze(self) -> Tuple[List[Finding], Dict[str, Any]]:
        findings: List[Finding] = []
        metrics: Dict[str, Any] = {
            "max_function_length": 0,
            "max_nesting_depth": 0,
            "cyclomatic_complexity": 1,
            "heavy_pass_by_value_count": 0,
            "endl_in_loops_count": 0,
        }

        # 1. Nesting Depth Analysis
        max_nest, nest_findings = self._check_nesting_depth()
        metrics["max_nesting_depth"] = max_nest
        findings.extend(nest_findings)

        # 2. Function Length Analysis
        max_fn_len, fn_findings = self._check_function_length()
        metrics["max_function_length"] = max_fn_len
        findings.extend(fn_findings)

        # 3. Cyclomatic Complexity
        cc_score, cc_findings = self._check_cyclomatic_complexity()
        metrics["cyclomatic_complexity"] = cc_score
        findings.extend(cc_findings)

        # 4. Inefficient Patterns
        perf_findings, pass_val_cnt, endl_cnt = self._check_inefficient_patterns()
        metrics["heavy_pass_by_value_count"] = pass_val_cnt
        metrics["endl_in_loops_count"] = endl_cnt
        findings.extend(perf_findings)

        # 5. Duplicate Logic
        findings.extend(self._check_duplicate_logic())

        # 6. Magic Numbers
        findings.extend(self._check_magic_numbers())

        deduped = self._deduplicate_findings(findings)
        return deduped, metrics

    def _get_raw_line(self, line_num: int) -> str:
        if 1 <= line_num <= len(self.lines_raw):
            return self.lines_raw[line_num - 1].strip()
        return ""

    def _check_nesting_depth(self) -> Tuple[int, List[Finding]]:
        max_depth = 0
        current_depth = 0
        findings = []
        reported_lines = set()

        # Track block depth based on { and } in masked source
        for idx, line in enumerate(self.lines_masked, start=1):
            # Count braces in line
            opens = line.count('{')
            closes = line.count('}')

            if opens > 0:
                current_depth += opens
                if current_depth > max_depth:
                    max_depth = current_depth

                if current_depth >= 5 and idx not in reported_lines:
                    reported_lines.add(idx)
                    findings.append(Finding(
                        rule_id="QUAL-NEST-001",
                        title=f"Excessive Control Flow Nesting (Depth {current_depth})",
                        severity="high",
                        line=idx,
                        description=f"Nesting depth reached {current_depth} levels, significantly impairing readability and maintainability.",
                        mitigation="Refactor nested blocks using early guard clauses, inverted conditionals, or helper function extraction.",
                        evidence=self._get_raw_line(idx),
                    ))
                elif current_depth == 4 and idx not in reported_lines:
                    reported_lines.add(idx)
                    findings.append(Finding(
                        rule_id="QUAL-NEST-002",
                        title=f"Deep Control Flow Nesting (Depth {current_depth})",
                        severity="medium",
                        line=idx,
                        description=f"Nesting depth of {current_depth} increases cognitive complexity and defect rate.",
                        mitigation="Consider extracting inner logic into a helper function or using early returns.",
                        evidence=self._get_raw_line(idx),
                    ))

            current_depth = max(0, current_depth - closes)

        return max_depth, findings

    def _check_function_length(self) -> Tuple[int, List[Finding]]:
        findings = []
        max_len = 0
        fn_header_regex = re.compile(
            r'^\s*(?:[a-zA-Z_][a-zA-Z0-9_:*&<>\s]*\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s*\([^;)]*\)\s*(?:const)?\s*\{'
        )

        in_function = False
        fn_name = ""
        fn_start_line = 0
        brace_balance = 0

        for idx, line in enumerate(self.lines_masked, start=1):
            if not in_function:
                m = fn_header_regex.search(line)
                # Ensure not control statements like if, while, for, switch
                if m and m.group(1) not in ("if", "while", "for", "switch", "catch"):
                    in_function = True
                    fn_name = m.group(1)
                    fn_start_line = idx
                    brace_balance = line.count('{') - line.count('}')
            else:
                brace_balance += line.count('{') - line.count('}')
                if brace_balance <= 0:
                    fn_len = idx - fn_start_line + 1
                    if fn_len > max_len:
                        max_len = fn_len

                    if fn_len > 80:
                        findings.append(Finding(
                            rule_id="QUAL-FN-LEN-001",
                            title=f"Excessive Function Length ({fn_len} lines in '{fn_name}')",
                            severity="high",
                            line=fn_start_line,
                            description=f"Function '{fn_name}' has {fn_len} lines, violating the Single Responsibility Principle.",
                            mitigation="Decompose this function into smaller, single-purpose helper functions.",
                            evidence=self._get_raw_line(fn_start_line),
                        ))
                    elif fn_len > 45:
                        findings.append(Finding(
                            rule_id="QUAL-FN-LEN-002",
                            title=f"High Function Length ({fn_len} lines in '{fn_name}')",
                            severity="medium",
                            line=fn_start_line,
                            description=f"Function '{fn_name}' exceeds 45 lines, making maintenance and unit testing harder.",
                            mitigation="Extract cohesive sub-tasks into modular helper functions.",
                            evidence=self._get_raw_line(fn_start_line),
                        ))
                    in_function = False
                    brace_balance = 0

        return max_len, findings

    def _check_cyclomatic_complexity(self) -> Tuple[int, List[Finding]]:
        findings = []
        # Approximate Cyclomatic Complexity:
        # 1 + decision points (if, else if, for, while, case, catch, &&, ||, ?)
        decision_patterns = [
            r"\bif\b",
            r"\bfor\b",
            r"\bwhile\b",
            r"\bcase\b",
            r"\bcatch\b",
            r"&&",
            r"\|\|",
            r"\?",
        ]
        combined = re.compile("|".join(f"(?:{p})" for p in decision_patterns))

        total_decisions = 0
        high_complexity_lines = []

        for idx, line in enumerate(self.lines_masked, start=1):
            matches = combined.findall(line)
            count = len(matches)
            total_decisions += count
            if count >= 4:
                high_complexity_lines.append((idx, count))

        cc = 1 + total_decisions

        if cc > 20:
            findings.append(Finding(
                rule_id="QUAL-CC-001",
                title=f"Excessive Overall Cyclomatic Complexity (Score: {cc})",
                severity="high",
                line=1,
                description=f"The program exhibits an estimated cyclomatic complexity of {cc}, indicating an excessive number of linear execution paths.",
                mitigation="Simplify composite boolean expressions, replace complex switch/if cascades with polymorphism or lookup tables.",
                evidence=f"Total estimated complexity: {cc}",
            ))
        elif cc > 12:
            findings.append(Finding(
                rule_id="QUAL-CC-002",
                title=f"Elevated Cyclomatic Complexity (Score: {cc})",
                severity="medium",
                line=1,
                description=f"Cyclomatic complexity of {cc} indicates multiple branching decisions across code paths.",
                mitigation="Break down complex branching structures into simpler, well-isolated routines.",
                evidence=f"Total estimated complexity: {cc}",
            ))

        return cc, findings

    def _check_inefficient_patterns(self) -> Tuple[List[Finding], int, int]:
        findings = []
        pass_val_cnt = 0
        endl_cnt = 0

        # Pattern 1: Pass-by-value of heavy containers in function parameters
        heavy_containers = (
            "string", "vector", "map", "unordered_map", "set", "unordered_set",
            "list", "deque", "multimap", "multiset", "unordered_multimap",
            "unordered_multiset", "forward_list", "array"
        )
        heavy_types_regex = re.compile(
            rf"\b(?:std::)?(?:{'|'.join(re.escape(c) for c in heavy_containers)})\b"
        )
        fn_header_regex = re.compile(
            r'^\s*(?:[a-zA-Z_][a-zA-Z0-9_:*&<>\s]*\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)'
        )

        for idx, line in enumerate(self.lines_masked, start=1):
            m = fn_header_regex.search(line)
            if m and m.group(1) not in ("if", "while", "for", "switch", "catch"):
                params_str = m.group(2)
                # Split top-level parameters accounting for template angle brackets <...>
                raw_params = []
                cur_param = []
                angle_depth = 0
                for ch in params_str:
                    if ch == '<':
                        angle_depth += 1
                        cur_param.append(ch)
                    elif ch == '>':
                        if angle_depth > 0:
                            angle_depth -= 1
                        cur_param.append(ch)
                    elif ch == ',' and angle_depth == 0:
                        raw_params.append("".join(cur_param).strip())
                        cur_param = []
                    else:
                        cur_param.append(ch)
                if cur_param:
                    raw_params.append("".join(cur_param).strip())

                for param in raw_params:
                    # Strip default argument if present
                    param_clean = param.split('=')[0].strip()
                    if not param_clean:
                        continue
                    # Skip if already passed by reference or pointer
                    if '&' in param_clean or '*' in param_clean:
                        continue
                    # Check if type matches heavy container
                    if heavy_types_regex.search(param_clean):
                        # Extract parameter name (last identifier) and type (everything before it)
                        parts = param_clean.rsplit(maxsplit=1)
                        if len(parts) == 2 and re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', parts[1]):
                            type_name = parts[0].strip()
                            param_name = parts[1].strip()
                            pass_val_cnt += 1
                            target_ref = type_name if type_name.startswith("const ") else f"const {type_name}"
                            findings.append(Finding(
                                rule_id="QUAL-PERF-001",
                                title=f"Inefficient Pass-by-Value of Heavy Container '{type_name}'",
                                severity="medium",
                                line=idx,
                                description=f"Parameter '{param_name}' of type '{type_name}' is passed by value, triggering unnecessary deep copies.",
                                mitigation=f"Pass by const reference ('{target_ref}& {param_name}') unless an independent copy is strictly required.",
                                evidence=self._get_raw_line(idx),
                            ))

        # Pattern 2: std::endl in loops
        # Look for while / for loop blocks containing endl
        loop_depth = 0
        for idx, line in enumerate(self.lines_masked, start=1):
            if re.search(r'\b(for|while)\s*\(', line):
                loop_depth += 1
            if loop_depth > 0:
                if re.search(r'\b(?:std::)?endl\b', line):
                    endl_cnt += 1
                    findings.append(Finding(
                        rule_id="QUAL-PERF-002",
                        title="Suboptimal Stream Flushing via std::endl Inside Loop",
                        severity="low",
                        line=idx,
                        description="Using std::endl inside loops forces a stream buffer flush on every iteration, causing significant I/O overhead.",
                        mitigation="Use '\\n' instead of std::endl inside loops, flushing only when necessary outside the loop.",
                        evidence=self._get_raw_line(idx),
                    ))
            if '}' in line and loop_depth > 0:
                loop_depth = max(0, loop_depth - line.count('}'))

        # Pattern 3: Post-increment on iterators
        post_inc_iter_regex = re.compile(r'\b([a-zA-Z0-9_]*it(?:er(?:ator)?)?)\s*\+\+')
        for idx, line in enumerate(self.lines_masked, start=1):
            m = post_inc_iter_regex.search(line)
            if m:
                findings.append(Finding(
                    rule_id="QUAL-PERF-003",
                    title=f"Suboptimal Post-Increment on Iterator '{m.group(1)}'",
                    severity="low",
                    line=idx,
                    description=f"Post-increment '{m.group(1)}++' instantiates an unnecessary temporary copy of the iterator object.",
                    mitigation=f"Use pre-increment '++{m.group(1)}' for iterators.",
                    evidence=self._get_raw_line(idx),
                ))

        return findings, pass_val_cnt, endl_cnt

    def _check_duplicate_logic(self) -> List[Finding]:
        findings = []
        # Detect identical consecutive branches or duplicated blocks of >= 3 lines
        cleaned_lines = []
        line_indices = []
        for idx, l in enumerate(self.lines_masked, start=1):
            stripped = l.strip()
            if stripped and stripped not in ("{", "}", "};", "public:", "private:"):
                cleaned_lines.append(stripped)
                line_indices.append(idx)

        # Check for duplicate 3-line consecutive blocks
        if len(cleaned_lines) >= 6:
            for i in range(len(cleaned_lines) - 5):
                block1 = cleaned_lines[i:i + 3]
                for j in range(i + 3, min(i + 15, len(cleaned_lines) - 2)):
                    block2 = cleaned_lines[j:j + 3]
                    if block1 == block2:
                        findings.append(Finding(
                            rule_id="QUAL-DUP-001",
                            title="Duplicated Code Logic Block Detected",
                            severity="medium",
                            line=line_indices[j],
                            description="Identical multi-statement logic block detected, violating the DRY (Don't Repeat Yourself) principle.",
                            mitigation="Extract duplicated statements into a shared helper function or reusable loop construct.",
                            evidence=self._get_raw_line(line_indices[j]),
                        ))
                        break
        return findings

    def _check_magic_numbers(self) -> List[Finding]:
        findings = []
        # Detect magic numbers in logic expressions (e.g., if (x > 86400) or while (count < 997))
        # Exclude common benign numbers: 0, 1, 2, -1, 10, 100
        magic_regex = re.compile(r'(?:==|!=|<|>|<=|>=|\+|\-|\*|\/)\s*([0-9]{2,})\b')
        benign = {"0", "1", "2", "10", "100"}

        found_count = 0
        for idx, line in enumerate(self.lines_masked, start=1):
            # Skip #define and const declarations
            if line.strip().startswith('#') or 'const ' in line or 'constexpr ' in line:
                continue
            for m in magic_regex.finditer(line):
                val = m.group(1)
                if val not in benign:
                    found_count += 1
                    if found_count <= 2:  # Report at most 2 to avoid spamming
                        findings.append(Finding(
                            rule_id="QUAL-MAGIC-001",
                            title=f"Unexplained Magic Number '{val}' in Logic Expression",
                            severity="low",
                            line=idx,
                            description=f"Magic numeric literal '{val}' used without explanatory named constant.",
                            mitigation=f"Declare a descriptive named constant (e.g., 'constexpr int kTimeoutSeconds = {val};').",
                            evidence=self._get_raw_line(idx),
                        ))
        return findings

    def _deduplicate_findings(self, findings: List[Finding]) -> List[Finding]:
        seen = set()
        deduped = []
        for f in findings:
            col = getattr(f, "column", 1)
            key = (f.rule_id, f.line, col)
            if key not in seen:
                seen.add(key)
                deduped.append(f)
        return deduped


# Shared pattern for dangerous command, pipe, and process execution functions.
def extract_added_lines_from_diff(diff_text: str) -> str:
    """Extracts added lines from unified diff, removing the leading '+'."""
    added_lines = []
    for line in diff_text.splitlines():
        if line.startswith("+") and not line.startswith("+++"):
            added_lines.append(line[1:])
    return "\n".join(added_lines)


LEET_TRANSLATION_MAP = str.maketrans({
    '0': 'o',
    '1': 'i',
    '3': 'e',
    '4': 'a',
    '5': 's',
    '7': 't',
    '@': 'a',
    '$': 's',
})


def _leetspeak_normalize(text: str) -> str:
    """Normalizes leetspeak alphanumeric substitutions within candidate word tokens."""
    def _replace_word(m: re.Match) -> str:
        word = m.group(0)
        if any(c in "013457@$" for c in word):
            return word.translate(LEET_TRANSLATION_MAP)
        return word
    return re.sub(r'\b[A-Za-z0-9@$]{3,}\b', _replace_word, text)


ALLOWED_AGENTIC_TOOLS = frozenset({
    "diagnose_syntax",
    "parse_ast",
    "extract_features",
    "classify_error",
    "explain_diagnostic",
    "propose_repair",
})


def authorize_tool_request(tool_name: str, args: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
    """Authorizes agent tool invocations independently of LLM decisions.
    
    Enforces strict allowlisting of permissible diagnostic tools.
    Blocks unauthorized shell, system, file-write, or secret-access operations.
    """
    if not isinstance(tool_name, str) or not tool_name.strip():
        return False, "Empty or invalid tool name requested"
    
    norm_name = tool_name.strip().lower()
    if norm_name not in ALLOWED_AGENTIC_TOOLS:
        return False, f"Unauthorized tool '{tool_name}' requested: not in allowed agent toolset."
    
    if args and isinstance(args, dict):
        for k, v in args.items():
            k_str = str(k).lower()
            v_str = str(v).lower()
            if "allow_execution" in k_str and str(v).lower() in ("true", "1"):
                return False, "Execution override forbidden in tool arguments."
            if any(bad in k_str for bad in ("command", "cmd", "shell", "exec", "script")):
                return False, f"Unauthorized parameter '{k}' in tool arguments."
    return True, "Authorized"


def validate_diff_paths(diff_text: str) -> Tuple[bool, str]:
    """Validates that unified diff headers only target authorized C++ files within the workspace.
    
    Blocks directory traversal, absolute paths, system directories, and sensitive file modifications.
    """
    if not diff_text or not isinstance(diff_text, str):
        return True, "Empty diff"
    
    for line in diff_text.splitlines():
        if line.startswith("--- ") or line.startswith("+++ "):
            target = line[4:].strip().split("\t")[0]
            if target.startswith("a/") or target.startswith("b/"):
                target = target[2:]
            if (
                os.path.isabs(target)
                or ".." in target
                or target.startswith("/")
                or target.startswith("\\")
                or re.search(r"^[a-zA-Z]:", target)
                or re.search(r"(?i)\.(env|py|json|pkl|key|sh|bat|cmd|ps1|exe)$", target)
                or re.search(r"(?i)(/etc/|/bin/|/usr/|/root/|/home/|c:[/\\]windows|c:[/\\]program)", target)
            ):
                return False, f"Diff targets unauthorized or prohibited file path: '{target}'"
    return True, "Diff paths valid"


def normalize_for_screening(text: str) -> str:
    """Normalizes text for adversarial prompt-injection screening.
    
    Applies:
    1. Hex-escaped ASCII sequence decoding (e.g., \\x69\\x67\\x6e\\x6f\\x72\\x65 -> ignore).
    2. Stripping zero-width and invisible formatting characters.
    3. Cyrillic and Greek homoglyph transliteration to ASCII equivalents.
    4. Unicode NFKC normalization (converting full-width characters like \uff49 -> i).
    5. Leetspeak substitution normalization on mixed alphanumeric tokens.
    
    NOTE: Used solely as a detection screening aid; never modifies original source code.
    """
    if not text:
        return ""
    
    def _hex_unescape(match: re.Match) -> str:
        try:
            raw_hex = match.group(0).replace(r"\x", "")
            return bytes.fromhex(raw_hex).decode("utf-8", errors="ignore")
        except Exception:
            return match.group(0)

    screening = re.sub(r'(?:\\x[0-9a-fA-F]{2})+', _hex_unescape, text)
    screening = ZERO_WIDTH_CHARS_PATTERN.sub('', screening)

    homoglyphs = {
        '\u0430': 'a', '\u0435': 'e', '\u043e': 'o', '\u0440': 'p', '\u0441': 'c',
        '\u0443': 'y', '\u0445': 'x', '\u0456': 'i', '\u0458': 'j', '\u0455': 's',
        '\u0410': 'A', '\u0412': 'B', '\u0421': 'C', '\u0415': 'E', '\u041d': 'H',
        '\u0406': 'I', '\u0408': 'J', '\u041a': 'K', '\u041c': 'M', '\u041e': 'O',
        '\u0420': 'P', '\u0421': 'C', '\u0422': 'T', '\u0425': 'X', '\u04AE': 'Y',
        '\u03bf': 'o', '\u03c1': 'p', '\u03b1': 'a', '\u03b5': 'e', '\u03b9': 'i',
    }
    for k, v in homoglyphs.items():
        screening = screening.replace(k, v)

    screening = unicodedata.normalize('NFKC', screening)
    screening = _leetspeak_normalize(screening)
    return screening


# Shared pattern for dangerous command, pipe, and process execution functions.
# Unifies the 4 execution families from SecurityAnalyzer (SEC-CMD-001 through SEC-CMD-004)
# with robust handling of parenthesized identifiers and multiline calls.
DANGEROUS_COMMAND_FNS: str = (
    r"system|_wsystem|"
    r"popen|_popen|_wpopen|"
    r"execl|execle|execlp|"
    r"execv|execve|execvp|execvpe|"
    r"WinExec|ShellExecute[AW]?|CreateProcess[AW]?"
)
DANGEROUS_COMMAND_EXECUTION_PATTERN: str = (
    rf"(?i)(?:(?:\(\s*)+\b(?:{DANGEROUS_COMMAND_FNS})\b(?:\s*\))+|\b(?:{DANGEROUS_COMMAND_FNS})\b)\s*\("
)


class AgenticAttackDetector:
    """
    Deterministic rule-based attack detector for the agentic AI pipeline.
    Treats user instructions, source code, comments, string literals,
    model responses, tool requests, and repair diffs as untrusted data.
    """

    COMMAND_EXECUTION_PATTERN = re.compile(DANGEROUS_COMMAND_EXECUTION_PATTERN)
    PROHIBITED_GETS_PATTERN = re.compile(r"(?:(?:\(\s*)+\bgets\b(?:\s*\))+|\bgets\b)\s*\(")

    DIRECT_INJECTION_PATTERNS = [
        re.compile(r"(?i)\b(?:ignore|disregard|forget|override)\s+(?:all\s+)?(?:the\s+)?(?:(?:previous|prior|earlier|above|system|model|security|safety)\s+)+(?:instructions?|directives?|prompts?|rules?|constraints?|guardrails?|guidelines?|policies|policy)\b"),
        re.compile(r"(?i)\b(?:ignore|disregard|forget|override)\s+(?:all\s+)?(?:the\s+)?(?:security|safety)\s+(?:rules?|checks?|constraints?|guardrails?|guidelines?|policies|policy)\b"),
        re.compile(r"(?i)\b(?:system|admin|root|security)\s+override\b"),
        re.compile(r"(?i)\b(?:developer\s+mode\s+enabled|jailbreak|unrestricted\s+mode|act\s+as\s+dan|do\s+anything\s+now)\b"),
        re.compile(r"(?i)<\s*/\s*untrusted_source_code(?:\s+[^>]*)?>"),
        re.compile(r"(?i)\[\s*(?:admin|system|developer)\s+instruction\s*:\s*[^\]]+\]"),
        re.compile(r"(?i)\boutput\s+only\s+['\"]?access_granted['\"]?\b"),
    ]

    VALIDATION_BYPASS_PATTERNS = [
        re.compile(r"(?i)\b(?:skip|bypass|disable|override|suppress)\s+(?:all\s+)?(?:the\s+)?(?:(?:structural\s+|input\s+|security\s+|safety\s+)?(?:validation|checks?)|security\s+gate|pre-diagnostic\s+gate|syntax\s+checking|ast\s+validation)\b"),
        re.compile(r"(?i)\bmark\s+(?:all\s+|any\s+)?(?:detected\s+)?(?:vulnerabilit(?:y|ies)|findings?|issues?|defects?|security\s+(?:issues?|findings?|alerts?|vulnerabilities))\s+as\s+(?:safe|clean|passed|ok|benign|false_positive)\b"),
        re.compile(r"(?i)\bset\s+(?:security_threshold|quality_threshold)\s*=\s*0(?:\.0)?\b"),
        re.compile(r"(?i)\b(?:suppress\s+all\s+syntax\s+errors|force\s+passed|mark\s+classification\s+as\s+clean)\b"),
        re.compile(r"(?i)#pragma\s+disable_security_gate\b"),
        re.compile(r"(?i)\[\s*directive\s*:\s*skip\s+[^\]]+\]"),
        re.compile(r"(?i)\b(?:skip|bypass)\s+pre-diagnostic\s+security\s+checks?\b"),
        re.compile(r"(?i)\b(?:disable|suppress|wipe|bypass|delete|clear|stop)\s+(?:all\s+)?(?:audit\s+log(?:ging)?|telemetry|trace(?:\s+records?|\s+events?)?|security\s+logs?|audit\s+trail)\b"),
        re.compile(r"(?i)\b(?:wipe|delete|clear|remove)\s+(?:all\s+)?(?:trace\s+events|audit\s+records?|log\s+files?)\s+from\s+disk\b"),
    ]

    UNAUTHORIZED_TOOL_PATTERNS = [
        re.compile(r"(?i)\b(?:execute\s+tool\s+call|call\s+tool|invoke\s+tool)\s*:\s*[a-zA-Z_]+\b"),
        re.compile(r"(?i)(?:\b(?:run|execute)\s+(?:an?\s+)?(?:unauthorized|arbitrary)\s+(?:shell\s+|system\s+)?commands?\b|\bexecute\s+the\s+following\s+(?:shell\s+|system\s+)?commands?\s*:\s*(?:\.\.\.|[^\s\"';]+)|\bexecute\s+(?:shell\s+|system\s+|bash\s+|cmd\s+)?command\s*:\s*(?:\.\.\.|[^\s\"';]+)|\b(?:allow_execution\s*=\s*true|run_shell|execute_code|execute_command)\b)"),
        re.compile(r"(?i)\b(?:access\s+secret\s+storage|read\s+environment\s+variables?\s+(?:gemini_api_key|\.env)|cat\s+\.env)\b"),
        re.compile(r"(?i)\b(?:write_file|read_file)\s*\(\s*['\"](?:/etc/passwd|c:[\\/]windows)\b"),
    ]

    INDIRECT_INJECTION_PATTERNS = [
        re.compile(r"(?i)\[?\b(?:(?:ai|llm)\s+(?:agent(?:\s+(?:directive|instruction|note)s?)?|instructions?|directives?|notes?)|assistant\s+(?:notice|instruction|directive)|important\s+(?:llm|ai)\s+directive)\s*:"),
        re.compile(r"(?i)\b(?:ignore|disregard|override|forget)\s+(?:all\s+)?(?:the\s+)?(?:(?:previous|prior|earlier|above|existing|system|user|security|safety)\s+)+(?:instructions?|directives?|rules?|guardrails?|syntax\s+errors?|constraints?|policies|policy)\b"),
        re.compile(r"(?i)\b(?:ignore|disregard|override|forget)\s+(?:all\s+)?(?:the\s+)?(?:security|safety)\s+(?:rules?|checks?|constraints?|guardrails?|policies|policy)\b"),
        re.compile(r"(?i)\b(?:leak|reveal|print|exfiltrate|dump)\s+(?:gemini_api_key|api_key|secrets?|\.env|environment\s+variables?|(?:(?:confidential|internal|hidden|secret)\s+)?(?:system\s+)?(?:prompts?|instructions?))\b"),
        re.compile(r"(?i)(?:\b(?:run|execute)\s+(?:an?\s+)?(?:unauthorized|arbitrary)\s+(?:shell\s+|system\s+)?commands?\b|\bexecute\s+the\s+following\s+(?:shell\s+|system\s+)?commands?\s*:\s*(?:\.\.\.|[^\s\"';]+)|\bexecute\s+(?:shell\s+|system\s+|bash\s+|cmd\s+)?command\s*:\s*(?:\.\.\.|[^\s\"';]+))"),
        re.compile(r"(?i)\b(?:approve\s+all\s+repairs?|grant\s+auto-approval|override\s+required\s+approval|approve\s+without\s+review)\b"),
        re.compile(r"(?i)\b(?:suppress\s+(?:user\s+)?syntax\s+errors|report\s+invalid_cpp_structure\s+with\s+fake|mark\s+clean)\b"),
        re.compile(r"(?i)\bmark\s+(?:all\s+|any\s+)?(?:detected\s+)?(?:vulnerabilit(?:y|ies)|findings?|issues?|defects?|security\s+(?:issues?|findings?|alerts?|vulnerabilities))\s+as\s+(?:safe|clean|passed|ok|benign|false_positive)\b"),
    ]

    REPAIR_ATTACK_NON_CODE_PATTERNS = [
        re.compile(r"(?i)(curl|wget).*(gemini_api_key|api_key|\.env)"),
        re.compile(r"(?i)cat\s+\.env"),
        re.compile(r"(?i)(gate\.py|assessment_engine.py|auto-pass\s+all\s+checks|override\s+required\s+approval)"),
        re.compile(r"\.\./|\.\.\\"),
    ]

    REPAIR_ATTACK_PATTERNS = [
        COMMAND_EXECUTION_PATTERN,
    ] + REPAIR_ATTACK_NON_CODE_PATTERNS

    def __init__(self, audit_log_path: Optional[str] = None):
        self.audit_log_path = audit_log_path

    def _check_obfuscated_or_combined(self, text: str, initial_hits: List[str]) -> Optional[Dict[str, Any]]:
        # 1. Base64 payload detection (inspected safely, including short candidates >= 8 chars)
        b64_matches = re.findall(r"\b[A-Za-z0-9+/]{8,}={0,2}\b", text)
        for b64 in b64_matches:
            try:
                padded = b64 + "=" * ((4 - len(b64) % 4) % 4)
                decoded = base64.b64decode(padded).decode("utf-8", errors="ignore").lower()
                if any(k in decoded for k in ["ignore", "disregard", "override", "bypass", "secret", "gemini", "disable", "system", "admin", "root", "jailbreak"]):
                    return {
                        "attack_type": "obfuscated_combined_attacks",
                        "severity": "critical",
                        "confidence": 0.95,
                        "reason": f"Decoded base64 payload contains malicious instructions: '{decoded[:80]}'",
                        "action": "BLOCK",
                        "evidence": b64,
                    }
            except Exception:
                pass

        # 2. Mixed-case obfuscated prompt injection (e.g. iGnOrE pReViOuS...)
        words = re.findall(r"\b[A-Za-z]{4,}\b", text)
        is_mixed_cased = any(
            any(c.islower() for c in w) and any(c.isupper() for c in w) and not w.istitle() and not w.isupper()
            for w in words
            if w.lower() in ("ignore", "previous", "instructions", "disregard", "override", "disable", "bypass")
        )
        if is_mixed_cased:
            return {
                "attack_type": "obfuscated_combined_attacks",
                "severity": "critical",
                "confidence": 0.95,
                "reason": "Case-obfuscated prompt injection directive detected.",
                "action": "BLOCK",
                "evidence": text[:150],
            }

        # 3. Multiple vectors combined
        if len(set(initial_hits)) >= 2:
            return {
                "attack_type": "obfuscated_combined_attacks",
                "severity": "critical",
                "confidence": 0.95,
                "reason": f"Multiple attack vectors detected in single input: {', '.join(sorted(set(initial_hits)))}",
                "action": "BLOCK",
                "evidence": text[:150],
            }
        return None

    def assess(
        self,
        input_data: Any,
        context_type: str = "auto",
        masker: Optional[CppLexicalMasker] = None,
        is_protected_action: bool = False,
        audit_log_path: Optional[str] = None,
    ) -> AttackAssessmentResult:
        t0 = time.perf_counter()
        target_log_path = audit_log_path or self.audit_log_path
        res = self._assess_internal(
            input_data=input_data,
            context_type=context_type,
            masker=masker,
            is_protected_action=is_protected_action,
        )
        latency_ms = (time.perf_counter() - t0) * 1000.0
        if res.detected:
            raw_repr = str(input_data)
            payload_hash = hashlib.sha256(raw_repr.encode("utf-8", errors="ignore")).hexdigest()
            _record_audit_safely(
                audit_log_path=target_log_path,
                event_id=res.event_id,
                event_type="attack_detected",
                agent_name="AgenticAttackDetector",
                severity=res.severity,
                decision=res.action,
                enforcement_outcome="blocked" if res.action == "BLOCK" else "flagged",
                error_summary=res.reason,
                attack_category=res.attack_type,
                error_category="security_violation",
                latency_ms=latency_ms,
                payload_hash=payload_hash,
            )
        return res

    def _assess_internal(
        self,
        input_data: Any,
        context_type: str = "auto",
        masker: Optional[CppLexicalMasker] = None,
        is_protected_action: bool = False,
    ) -> AttackAssessmentResult:
        try:
            raw_repr = str(input_data)
            stable_hash = hashlib.sha256(raw_repr.encode("utf-8", errors="ignore")).hexdigest()[:12]
            event_id = f"evt-{stable_hash}"

            # Handle structured tool calls in dict
            if isinstance(input_data, dict) and ("tool_name" in input_data or "tool" in input_data or context_type == "tool_call"):
                tool_name = input_data.get("tool_name") or input_data.get("tool") or ""
                tool_params = input_data.get("parameters") or input_data.get("args") or {}
                is_auth, auth_err = authorize_tool_request(tool_name, tool_params)
                if not is_auth:
                    return AttackAssessmentResult(
                        detected=True,
                        attack_type="unauthorized_tool_requests",
                        severity="critical",
                        confidence=0.98,
                        reason=auth_err,
                        action="BLOCK",
                        event_id=event_id,
                        details={"tool": tool_name, "error": auth_err},
                    )

            # Handle dict (e.g. repair plan)
            if isinstance(input_data, dict):
                if input_data.get("requires_approval") is False:
                    return AttackAssessmentResult(
                        detected=True,
                        attack_type="repair_agent_attacks",
                        severity="critical",
                        confidence=0.98,
                        reason="Repair proposal attempted to bypass human approval (requires_approval set to false).",
                        action="BLOCK",
                        event_id=event_id,
                        details={"field": "requires_approval", "value": False},
                    )

                prop_code = input_data.get("proposed_code") or ""
                diff = input_data.get("diff") or ""

                if diff:
                    is_safe_path, path_err = validate_diff_paths(diff)
                    if not is_safe_path:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="repair_agent_attacks",
                            severity="critical",
                            confidence=0.98,
                            reason=path_err,
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": path_err},
                        )

                # Screen proposed code if present
                if prop_code:
                    code_masker = CppLexicalMasker(prop_code)
                    m = self.COMMAND_EXECUTION_PATTERN.search(code_masker.masked_source)
                    if m:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="repair_agent_attacks",
                            severity="critical",
                            confidence=0.98,
                            reason=f"Repair proposal contains unauthorized command execution call: {m.group(0).strip()}",
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": m.group(0).strip()},
                        )
                    if self.PROHIBITED_GETS_PATTERN.search(code_masker.masked_source):
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="repair_agent_attacks",
                            severity="critical",
                            confidence=0.98,
                            reason="Repair proposal contains prohibited gets() function",
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": "gets("},
                        )

                # Screen diff additions if present
                if diff:
                    diff_added = extract_added_lines_from_diff(diff)
                    if diff_added:
                        diff_masker = CppLexicalMasker(diff_added)
                        m = self.COMMAND_EXECUTION_PATTERN.search(diff_masker.masked_source)
                        if m:
                            return AttackAssessmentResult(
                                detected=True,
                                attack_type="repair_agent_attacks",
                                severity="critical",
                                confidence=0.98,
                                reason=f"Repair proposal diff contains unauthorized command execution call: {m.group(0).strip()}",
                                action="BLOCK",
                                event_id=event_id,
                                details={"evidence": m.group(0).strip()},
                            )

                combined_text = f"{prop_code}\n{diff}"
                for pat in self.REPAIR_ATTACK_NON_CODE_PATTERNS:
                    m = pat.search(combined_text)
                    if m:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="repair_agent_attacks",
                            severity="critical",
                            confidence=0.95,
                            reason=f"Repair proposal contains unauthorized malicious pattern: {m.group(0)}",
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": m.group(0)},
                        )

            if context_type == "repair_diff" and isinstance(input_data, str):
                diff_text = input_data
                is_safe_path, path_err = validate_diff_paths(diff_text)
                if not is_safe_path:
                    return AttackAssessmentResult(
                        detected=True,
                        attack_type="repair_agent_attacks",
                        severity="critical",
                        confidence=0.98,
                        reason=path_err,
                        action="BLOCK",
                        event_id=event_id,
                        details={"evidence": path_err},
                    )

                added_code = extract_added_lines_from_diff(diff_text)
                target_code = added_code if added_code.strip() else diff_text

                # Lexical masking of reconstructed added code
                diff_masker = CppLexicalMasker(target_code)

                # Check command execution on lexically masked code (comments/strings don't trigger false positives)
                m_cmd = self.COMMAND_EXECUTION_PATTERN.search(diff_masker.masked_source)
                if m_cmd:
                    return AttackAssessmentResult(
                        detected=True,
                        attack_type="repair_agent_attacks",
                        severity="critical",
                        confidence=0.98,
                        reason=f"Repair diff contains prohibited command execution: {m_cmd.group(0).strip()}",
                        action="BLOCK",
                        event_id=event_id,
                        details={"evidence": m_cmd.group(0).strip()},
                    )

                if self.PROHIBITED_GETS_PATTERN.search(diff_masker.masked_source):
                    return AttackAssessmentResult(
                        detected=True,
                        attack_type="repair_agent_attacks",
                        severity="critical",
                        confidence=0.98,
                        reason="Repair diff contains prohibited function gets()",
                        action="BLOCK",
                        event_id=event_id,
                        details={"evidence": "gets("},
                    )

                # Check non-code repair attack patterns on reconstructed text
                for pat in self.REPAIR_ATTACK_NON_CODE_PATTERNS:
                    m = pat.search(target_code)
                    if m:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="repair_agent_attacks",
                            severity="critical",
                            confidence=0.95,
                            reason=f"Repair diff contains prohibited malicious modification: {m.group(0)}",
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": m.group(0)},
                        )

            if context_type == "tool_call" and isinstance(input_data, str):
                # Check string tool call authorization
                m_tool = re.search(r"(?i)\b(?:execute\s+tool\s+call|call\s+tool|invoke\s+tool)\s*:\s*([a-zA-Z0-9_]+)", input_data)
                if m_tool:
                    t_name = m_tool.group(1)
                    is_auth, auth_err = authorize_tool_request(t_name)
                    if not is_auth:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="unauthorized_tool_requests",
                            severity="critical",
                            confidence=0.98,
                            reason=auth_err,
                            action="BLOCK",
                            event_id=event_id,
                            details={"tool": t_name, "error": auth_err},
                        )

            text = input_data if isinstance(input_data, str) else str(input_data)
            if not text.strip():
                return AttackAssessmentResult(
                    detected=False,
                    attack_type=None,
                    severity="none",
                    confidence=1.0,
                    reason="Empty input is inert.",
                    action="ALLOW",
                    event_id=event_id,
                )

            initial_hits: List[str] = []

            # 1. Obfuscated Base64 check
            b64_res = self._check_obfuscated_or_combined(text, [])
            if b64_res:
                return AttackAssessmentResult(
                    detected=True,
                    attack_type=b64_res["attack_type"],
                    severity=b64_res["severity"],
                    confidence=b64_res["confidence"],
                    reason=b64_res["reason"],
                    action=b64_res["action"],
                    event_id=event_id,
                    details={"evidence": b64_res.get("evidence", "")},
                )

            # 2. Source code context checks (command execution, gets, indirect injection)
            if context_type in ("source_code", "auto") and ("//" in text or "/*" in text or '"' in text or "(" in text):
                if masker is None:
                    try:
                        masker = CppLexicalMasker(text)
                    except Exception:
                        masker = None

                if masker:
                    # Check indirect prompt injection in comments and string literals
                    for c in masker.comments:
                        c_text = c.get("text", "")
                        c_norm = normalize_for_screening(c_text)
                        c_clean = re.sub(r"\n\s*\*\s*", " ", c_text)
                        c_clean_norm = normalize_for_screening(c_clean)
                        for pat in self.INDIRECT_INJECTION_PATTERNS:
                            m = pat.search(c_text) or pat.search(c_norm) or pat.search(c_clean) or pat.search(c_clean_norm)
                            if m:
                                return AttackAssessmentResult(
                                    detected=True,
                                    attack_type="indirect_prompt_injection",
                                    severity="high",
                                    confidence=0.92,
                                    reason=f"Adversarial instruction embedded in C++ comment: {m.group(0)}",
                                    action="BLOCK",
                                    event_id=event_id,
                                    details={"evidence": m.group(0), "line": c.get("line", 1)},
                                )
                    for s in masker.string_literals:
                        s_text = s.get("text", "")
                        s_norm = normalize_for_screening(s_text)
                        for pat in self.INDIRECT_INJECTION_PATTERNS:
                            m = pat.search(s_text) or pat.search(s_norm)
                            if m:
                                return AttackAssessmentResult(
                                    detected=True,
                                    attack_type="indirect_prompt_injection",
                                    severity="high",
                                    confidence=0.92,
                                    reason=f"Adversarial instruction embedded in string literal: {m.group(0)}",
                                    action="BLOCK",
                                    event_id=event_id,
                                    details={"evidence": m.group(0), "line": s.get("line", 1)},
                                )

                    # Check command execution on lexically masked source code
                    m_cmd = self.COMMAND_EXECUTION_PATTERN.search(masker.masked_source)
                    if m_cmd:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="command_execution",
                            severity="critical",
                            confidence=0.98,
                            reason=f"Dangerous command execution function detected in C++ source: {m_cmd.group(0).strip()}",
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": m_cmd.group(0).strip()},
                        )

                    # Check gets() prohibited buffer overflow on lexically masked source
                    m_gets = self.PROHIBITED_GETS_PATTERN.search(masker.masked_source)
                    if m_gets:
                        return AttackAssessmentResult(
                            detected=True,
                            attack_type="buffer_overflow",
                            severity="critical",
                            confidence=0.98,
                            reason=f"Prohibited buffer overflow function gets() detected in C++ source: {m_gets.group(0).strip()}",
                            action="BLOCK",
                            event_id=event_id,
                            details={"evidence": m_gets.group(0).strip()},
                        )

            # Screening text normalized for adversarial injection checks
            screening_text = normalize_for_screening(text)
            hit_details: Dict[str, Dict[str, Any]] = {}

            # 3. Direct Prompt Injection
            for pat in self.DIRECT_INJECTION_PATTERNS:
                m_raw = pat.search(text)
                m_norm = pat.search(screening_text)
                if m_raw or m_norm:
                    initial_hits.append("direct_prompt_injection")
                    ev = m_raw.group(0) if m_raw else (m_norm.group(0) if m_norm else text[:120])
                    ln = (text[:m_raw.start()].count('\n') + 1) if m_raw else 1
                    hit_details["direct_prompt_injection"] = {"evidence": ev, "line": ln}
                    break

            # 4. Validation Bypass
            for pat in self.VALIDATION_BYPASS_PATTERNS:
                m_raw = pat.search(text)
                m_norm = pat.search(screening_text)
                if m_raw or m_norm:
                    initial_hits.append("validation_bypass")
                    ev = m_raw.group(0) if m_raw else (m_norm.group(0) if m_norm else text[:120])
                    ln = (text[:m_raw.start()].count('\n') + 1) if m_raw else 1
                    hit_details["validation_bypass"] = {"evidence": ev, "line": ln}
                    break

            # 5. Unauthorized tool calls / Secret access
            for pat in self.UNAUTHORIZED_TOOL_PATTERNS:
                m_raw = pat.search(text)
                m_norm = pat.search(screening_text)
                if m_raw or m_norm:
                    initial_hits.append("unauthorized_tool_requests")
                    ev = m_raw.group(0) if m_raw else (m_norm.group(0) if m_norm else text[:120])
                    ln = (text[:m_raw.start()].count('\n') + 1) if m_raw else 1
                    hit_details["unauthorized_tool_requests"] = {"evidence": ev, "line": ln}
                    break

            # If multiple vectors combined:
            effective_hits = list(initial_hits)
            if "direct_prompt_injection" in effective_hits and "validation_bypass" in effective_hits:
                text_without_admin_tags = re.sub(r"(?i)\[\s*(?:admin|system|developer)\s+instruction\s*:\s*[^\]]+\]", "", text)
                norm_without_admin_tags = normalize_for_screening(text_without_admin_tags)
                has_external_bypass = any(
                    pat.search(text_without_admin_tags) or pat.search(norm_without_admin_tags)
                    for pat in self.VALIDATION_BYPASS_PATTERNS
                )
                if not has_external_bypass:
                    effective_hits = [h for h in effective_hits if h != "validation_bypass"]

            if len(set(effective_hits)) >= 2:
                comb = self._check_obfuscated_or_combined(text, effective_hits)
                if comb:
                    return AttackAssessmentResult(
                        detected=True,
                        attack_type=comb["attack_type"],
                        severity=comb["severity"],
                        confidence=comb["confidence"],
                        reason=comb["reason"],
                        action=comb["action"],
                        event_id=event_id,
                        details={"evidence": text[:120]},
                    )

            if "direct_prompt_injection" in initial_hits:
                return AttackAssessmentResult(
                    detected=True,
                    attack_type="direct_prompt_injection",
                    severity="critical",
                    confidence=0.95,
                    reason="Direct prompt injection attempt detected.",
                    action="BLOCK",
                    event_id=event_id,
                    details=hit_details.get("direct_prompt_injection", {"evidence": text[:120], "line": 1}),
                )

            if "validation_bypass" in initial_hits:
                return AttackAssessmentResult(
                    detected=True,
                    attack_type="validation_bypass",
                    severity="critical",
                    confidence=0.95,
                    reason="Security gate or validation bypass directive detected.",
                    action="BLOCK",
                    event_id=event_id,
                    details=hit_details.get("validation_bypass", {"evidence": text[:120], "line": 1}),
                )

            if "unauthorized_tool_requests" in initial_hits:
                return AttackAssessmentResult(
                    detected=True,
                    attack_type="unauthorized_tool_requests",
                    severity="critical",
                    confidence=0.95,
                    reason="Unauthorized tool/action or credential access requested.",
                    action="BLOCK",
                    event_id=event_id,
                    details=hit_details.get("unauthorized_tool_requests", {"evidence": text[:120], "line": 1}),
                )

            return AttackAssessmentResult(
                detected=False,
                attack_type=None,
                severity="none",
                confidence=1.0,
                reason="No malicious agentic attack detected.",
                action="ALLOW",
                event_id=event_id,
            )

        except Exception as exc:
            raw_repr = str(input_data)
            stable_hash = hashlib.sha256(raw_repr.encode("utf-8", errors="ignore")).hexdigest()[:8]
            event_id = f"evt-err-{stable_hash}"
            if is_protected_action:
                return AttackAssessmentResult(
                    detected=True,
                    attack_type="assessment_failure_fail_closed",
                    severity="critical",
                    confidence=1.0,
                    reason=f"Security assessment failed or timed out: failing closed for protected action ({str(exc)})",
                    action="BLOCK",
                    event_id=event_id,
                )
            return AttackAssessmentResult(
                detected=False,
                attack_type=None,
                severity="none",
                confidence=0.0,
                reason=f"Assessment error during diagnostics: {str(exc)}",
                action="ALLOW",
                event_id=event_id,
            )


class AssessmentEngine:
    """
    Unified Pre-Diagnostic Security and Code Quality Gate Assessment Engine.
    Executes independent static security and quality analyses on C++ source code.
    """

    def __init__(
        self,
        security_threshold: float = DEFAULT_SECURITY_THRESHOLD,
        quality_threshold: float = DEFAULT_QUALITY_THRESHOLD,
        audit_log_path: Optional[str] = None,
    ):
        self.security_threshold = float(security_threshold)
        self.quality_threshold = float(quality_threshold)
        self.audit_log_path = audit_log_path
        self.attack_detector = AgenticAttackDetector(audit_log_path=audit_log_path)

    def assess_attack(
        self,
        input_data: Any,
        context_type: str = "auto",
        is_protected_action: bool = False,
        audit_log_path: Optional[str] = None,
    ) -> AttackAssessmentResult:
        """Evaluates arbitrary inputs for Agentic AI pipeline attacks."""
        return self.attack_detector.assess(
            input_data,
            context_type=context_type,
            is_protected_action=is_protected_action,
            audit_log_path=audit_log_path or self.audit_log_path,
        )

    def evaluate(
        self,
        source_code: str,
        audit_log_path: Optional[str] = None,
    ) -> AssessmentResult:
        target_log_path = audit_log_path or self.audit_log_path
        res = self._evaluate_internal(source_code, audit_log_path=target_log_path)
        if not res.passed or res.gate_decision == "BLOCKED":
            raw_source = str(source_code)
            payload_hash = hashlib.sha256(raw_source.encode("utf-8", errors="ignore")).hexdigest()
            stable_hash = payload_hash[:12]
            attack_meta = res.metrics.get("attack_assessment") or {}
            attack_detected = bool(attack_meta.get("detected", False))
            gate_event_id = attack_meta.get("event_id") if (attack_detected and attack_meta.get("event_id")) else f"evt-gate-{stable_hash}"
            crit_titles = [f["title"] for f in res.security_findings if f.get("severity") == "critical"]
            if attack_detected:
                reason = f"Pre-diagnostic gate blocked by detected agentic attack: {attack_meta.get('reason', '')}"
                attack_cat = attack_meta.get("attack_type") or "agentic_attack"
                sev = attack_meta.get("severity") if attack_meta.get("severity") in ("critical", "high") else "critical"
            elif crit_titles:
                reason = f"Pre-diagnostic gate blocked: {'; '.join(crit_titles)}"
                attack_cat = "security_finding"
                sev = "critical"
            elif res.assessment_errors:
                reason = f"Pre-diagnostic gate blocked: {'; '.join(res.assessment_errors)}"
                attack_cat = "assessment_error"
                sev = "high"
            else:
                reason = f"Pre-diagnostic gate blocked: security score below threshold ({res.security_score} < {res.security_threshold})"
                attack_cat = "threshold_failure"
                sev = "medium"

            _record_audit_safely(
                audit_log_path=target_log_path,
                event_id=gate_event_id,
                event_type="gate_blocked",
                agent_name="AssessmentEngine",
                severity=sev,
                decision="BLOCK",
                enforcement_outcome="pre_diagnostic_gate_blocked",
                error_summary=reason,
                attack_category=attack_cat,
                error_category="security_violation" if res.critical_security_issue else "gate_threshold_failure",
                payload_hash=payload_hash,
            )
        return res

    def _evaluate_internal(
        self,
        source_code: str,
        audit_log_path: Optional[str] = None,
    ) -> AssessmentResult:
        if not isinstance(source_code, str):
            return AssessmentResult(
                security_score=0.0,
                quality_score=0.0,
                security_threshold=self.security_threshold,
                quality_threshold=self.quality_threshold,
                security_findings=[],
                quality_findings=[],
                critical_security_issue=False,
                assessment_completed=False,
                assessment_errors=["Invalid input type: expected string source code."],
                gate_decision="BLOCKED",
                passed=False,
                metrics={},
            )

        stripped = source_code.strip()
        if not stripped:
            return AssessmentResult(
                security_score=0.0,
                quality_score=0.0,
                security_threshold=self.security_threshold,
                quality_threshold=self.quality_threshold,
                security_findings=[],
                quality_findings=[],
                critical_security_issue=False,
                assessment_completed=False,
                assessment_errors=["Source code is empty or whitespace-only: insufficient input for assessment."],
                gate_decision="BLOCKED",
                passed=False,
                metrics={"empty_source": True},
            )

        # Require at least one valid identifier, keyword, or alphanumeric token
        if not re.search(r'[a-zA-Z_]', stripped):
            return AssessmentResult(
                security_score=0.0,
                quality_score=0.0,
                security_threshold=self.security_threshold,
                quality_threshold=self.quality_threshold,
                security_findings=[],
                quality_findings=[],
                critical_security_issue=False,
                assessment_completed=False,
                assessment_errors=["Source code contains no valid statements, keywords, or identifiers: insufficient input for assessment."],
                gate_decision="BLOCKED",
                passed=False,
                metrics={"insufficient_source": True},
            )

        errors = []
        try:
            masker = CppLexicalMasker(source_code)
            if masker.has_unclosed_comment:
                errors.append("Lexical analysis incomplete: unterminated block comment (/* without */).")
            if masker.has_unclosed_string:
                errors.append("Lexical analysis incomplete: unterminated string literal.")
        except Exception as e:
            return AssessmentResult(
                security_score=0.0,
                quality_score=0.0,
                security_threshold=self.security_threshold,
                quality_threshold=self.quality_threshold,
                security_findings=[],
                quality_findings=[],
                critical_security_issue=False,
                assessment_completed=False,
                assessment_errors=[f"Lexical masking error: {str(e)}"],
                gate_decision="BLOCKED",
                passed=False,
                metrics={},
            )

        security_findings: List[Finding] = []
        has_critical = False

        # 1. Agentic AI Attack Assessment
        attack_assessment = self.attack_detector.assess(
            source_code, context_type="source_code", masker=masker, is_protected_action=False,
            audit_log_path=audit_log_path,
        )
        if attack_assessment.detected and attack_assessment.action == "BLOCK":
            has_critical = True
            if attack_assessment.attack_type != "command_execution":
                security_findings.append(Finding(
                    rule_id=f"SEC-ATK-{attack_assessment.attack_type.upper().replace('_', '-')}",
                    title=f"Agentic Attack Detected: {attack_assessment.attack_type.replace('_', ' ').title()}",
                    severity="critical" if (attack_assessment.action == "BLOCK" or attack_assessment.severity == "critical") else attack_assessment.severity,
                    line=attack_assessment.details.get("line", 1),
                    description=attack_assessment.reason,
                    mitigation="Remove adversarial injection, bypass directives, or unauthorized payload.",
                    evidence=attack_assessment.details.get("evidence", "")[:200],
                ))

        # 2. Traditional C++ Security Static Analysis
        try:
            sec_analyzer = SecurityAnalyzer(source_code, masker)
            sec_finds, sec_crit = sec_analyzer.analyze()
            security_findings.extend(sec_finds)
            if sec_crit:
                has_critical = True
        except Exception as e:
            errors.append(f"Security assessment execution error: {str(e)}")

        # 3. Quality Analysis
        quality_findings: List[Finding] = []
        metrics: Dict[str, Any] = {"attack_assessment": attack_assessment.to_dict()}
        try:
            qual_analyzer = QualityAnalyzer(source_code, masker)
            quality_findings, qual_metrics = qual_analyzer.analyze()
            metrics.update(qual_metrics)
        except Exception as e:
            errors.append(f"Quality assessment execution error: {str(e)}")

        if errors:
            return AssessmentResult(
                security_score=0.0,
                quality_score=0.0,
                security_threshold=self.security_threshold,
                quality_threshold=self.quality_threshold,
                security_findings=[f.to_dict() for f in security_findings],
                quality_findings=[f.to_dict() for f in quality_findings],
                critical_security_issue=has_critical,
                assessment_completed=False,
                assessment_errors=errors,
                gate_decision="BLOCKED",
                passed=False,
                metrics=metrics,
            )

        # Calculate Scores
        sec_score = self._compute_security_score(security_findings)
        qual_score = self._compute_quality_score(quality_findings)

        # Gate Evaluation Condition:
        # Pre-Diagnostic Gate blocks on security threshold failure or critical security issues.
        # Code quality is evaluated and reported for actionable optimization suggestions, but does not block syntax diagnostics.
        gate_passed = (
            sec_score >= self.security_threshold and
            not has_critical
        )
        gate_decision = "PASSED" if gate_passed else "BLOCKED"

        return AssessmentResult(
            security_score=round(sec_score, 1),
            quality_score=round(qual_score, 1),
            security_threshold=self.security_threshold,
            quality_threshold=self.quality_threshold,
            security_findings=[f.to_dict() for f in security_findings],
            quality_findings=[f.to_dict() for f in quality_findings],
            critical_security_issue=has_critical,
            assessment_completed=True,
            assessment_errors=[],
            gate_decision=gate_decision,
            passed=gate_passed,
            metrics=metrics,
        )

    def _compute_security_score(self, findings: List[Finding]) -> float:
        """
        Deterministic security score formula:
        Baseline = 100.0.
        Deductions:
          - critical: 35 points per finding
          - high: 20 points per finding
          - medium: 10 points per finding
          - low: 5 points per finding
          - info: 0 points
        Score = max(0.0, 100.0 - sum(deductions))
        """
        total_deduction = 0.0
        for f in findings:
            weight = SECURITY_SEVERITY_WEIGHTS.get(f.severity, 0.0)
            if f.rule_id.startswith("SEC-CMD"):
                weight = max(weight, 35.0)
            total_deduction += weight
        return max(0.0, 100.0 - total_deduction)

    def _compute_quality_score(self, findings: List[Finding]) -> float:
        """
        Deterministic quality score formula:
        Baseline = 100.0.
        Deductions based on severity with category capping:
          - high: 15 points per finding
          - medium: 8 points per finding
          - low: 4 points per finding
        Score = max(0.0, 100.0 - sum(capped deductions))
        """
        category_deductions: Dict[str, float] = {}
        for f in findings:
            # Map rule to category
            category = "other"
            if "MAGIC" in f.rule_id:
                category = "magic_numbers"
            elif "PERF-002" in f.rule_id:
                category = "endl_in_loop"
            elif "PERF-003" in f.rule_id:
                category = "post_increment"
            elif "PERF-001" in f.rule_id:
                category = "pass_by_value"
            elif "NEST" in f.rule_id:
                category = "nesting"
            elif "CC" in f.rule_id:
                category = "complexity"
            elif "FN-LEN" in f.rule_id:
                category = "function_length"
            elif "DUP" in f.rule_id:
                category = "duplicate_logic"

            weight = QUALITY_SEVERITY_WEIGHTS.get(f.severity, 0.0)
            category_deductions[category] = category_deductions.get(category, 0.0) + weight

        # Apply category caps
        total_deduction = 0.0
        for cat, ded in category_deductions.items():
            cap = QUALITY_CATEGORY_CAPS.get(cat, 30.0)
            total_deduction += min(ded, cap)

        return max(0.0, 100.0 - total_deduction)
