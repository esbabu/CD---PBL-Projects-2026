"""
compiler_sandbox.py — Centralized OS-Level Compiler Process Containment Engine.

Provides platform-specific, defense-in-depth process containment for C++ compiler
invocations (g++, clang++) across supported host environments (Windows and Linux).

Security & Containment Guarantees:
1. Windows:
   - Uses native Windows Job Objects via kernel32.dll ctypes bindings.
   - Child processes are created in SUSPENDED mode (CREATE_SUSPENDED = 0x00000004).
   - Process is assigned to the Job Object BEFORE any code executes, eliminating
     the creation-to-assignment race condition.
   - Hardware/OS limits applied before thread resumption:
     * JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE (0x2000): Process tree killed if parent exits.
     * JOB_OBJECT_LIMIT_PROCESS_MEMORY (0x0100) & JOB_OBJECT_LIMIT_JOB_MEMORY (0x0200):
       Hard physical and virtual memory ceilings to prevent RAM exhaustion / template bombs.
     * JOB_OBJECT_LIMIT_ACTIVE_PROCESS_LIMIT (0x0008): Hard cap on child processes.
     * JOB_OBJECT_LIMIT_PROCESS_TIME (0x0002): User-mode CPU time limit.
   - Reliable process-tree termination via TerminateJobObject on timeout or violations.
   - Important Boundary Limitation: Windows Job Objects enforce hardware/CPU/RAM limits
     and process-tree termination, but do NOT provide filesystem or network namespace
     isolation without containerization. Invocations requiring filesystem or network
     isolation fail closed.
2. Linux:
   - If bubblewrap (bwrap) is installed, wraps execution in unprivileged namespace sandbox:
     * Network namespace isolation (--unshare-all) preventing network access.
     * Minimal read-only system mounts (/usr, /lib, dynamic linker configuration).
     * Host credentials, /home, /root, ~/.ssh, and signing keys are NOT mounted.
     * Empty tmpfs root and isolated tmpfs /tmp.
     * Dedicated ephemeral workspace bound to /workspace with guaranteed cleanup.
     * All Linux capabilities dropped (--cap-drop ALL).
     * Process group isolation and POSIX resource limits (RLIMIT_AS, RLIMIT_CPU, RLIMIT_NPROC).
   - If bwrap is missing on Linux:
     * Fails closed by default under strict containment policy.
     * Development-only fallback requires explicit opt-in (ALLOW_UNCONTAINED_FALLBACK=1
       AND allow_development_fallback=True).
3. Universal:
   - Strict argument-vector validation (rejects shell=True, string commands).
   - Incremental bounded I/O draining to prevent pipe deadlock and memory exhaustion.
   - Enforced syntax-only mode (-fsyntax-only required; -o output execution rejected).
   - Sanitized environment enforcement (stripping credentials, secrets, signing keys).
   - Fail-closed security policy: Fails closed unless explicit fallback is configured.
"""

from __future__ import annotations

import os
import sys
import time
import shutil
import signal
import tempfile
import threading
import subprocess
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple, Any, Set


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class SandboxError(Exception):
    """Base exception for compiler containment errors."""
    pass


class CompilerNotFoundError(SandboxError):
    """Compiler executable was not found."""
    pass


class CompilerTimeoutError(SandboxError):
    """Compiler execution exceeded the wall-clock timeout and was terminated."""
    pass


class OutputLimitExceededError(SandboxError):
    """Compiler generated excessive output exceeding the bounded limit and was terminated."""
    pass


class ContainmentInitError(SandboxError):
    """OS-level containment mechanism could not be initialized or enforced."""
    pass


class SecurityViolationError(SandboxError):
    """Invocation violates security policy (e.g. shell=True, missing -fsyntax-only, forbidden flags)."""
    pass


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

@dataclass
class CompilerSandboxLimits:
    timeout_seconds: float = 30.0
    memory_limit_bytes: int = 512 * 1024 * 1024  # 512 MB
    max_active_processes: int = 10
    cpu_time_limit_seconds: float = 30.0
    max_output_bytes: int = 512 * 1024  # 512 KB hard combined stdout+stderr
    strict_containment: bool = True  # Fail closed by default
    require_network_isolation: bool = False  # Fail closed if network namespace isolation cannot be enforced
    require_filesystem_isolation: bool = False  # Fail closed if filesystem namespace isolation cannot be enforced
    allow_development_fallback: bool = False  # Explicit opt-in for development-only uncontained fallback


@dataclass
class ContainedProcessResult:
    returncode: int
    stdout: str
    stderr: str
    truncated: bool = False
    duration_seconds: float = 0.0
    containment_active: bool = False
    containment_type: str = "none"  # "linux_bwrap", "windows_job_object", "uncontained_fallback"
    filesystem_isolated: bool = False
    network_isolated: bool = False
    cleaned_up: bool = True


# ---------------------------------------------------------------------------
# Platform Capabilities Reporting
# ---------------------------------------------------------------------------

def get_sandbox_capabilities() -> Dict[str, Any]:
    """
    Returns the supported and active containment capabilities on the current platform.
    Accurately reports filesystem and network isolation support without false claims.
    """
    is_windows = sys.platform == "win32"
    is_linux = sys.platform.startswith("linux")
    bwrap_path = shutil.which("bwrap") if is_linux else None
    bwrap_available = bool(bwrap_path)

    caps: Dict[str, Any] = {
        "platform": sys.platform,
        "is_windows": is_windows,
        "is_linux": is_linux,
        "containment_engine": "none",
        "has_filesystem_isolation": False,
        "has_network_isolation": False,
        "has_process_tree_termination": False,
        "has_memory_limit": False,
        "has_cpu_limit": False,
        "has_process_count_limit": False,
        "has_output_bounding": True,
        "has_credential_sanitization": True,
        "has_syntax_only_enforcement": True,
        "guarantees": [],
        "limitations": [],
    }

    if is_windows:
        caps["containment_engine"] = "windows_job_object"
        caps["has_process_tree_termination"] = True
        caps["has_memory_limit"] = True
        caps["has_cpu_limit"] = True
        caps["has_process_count_limit"] = True
        caps["guarantees"] = [
            "Atomic process assignment in CREATE_SUSPENDED mode prior to thread execution",
            "Process-tree termination via JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE and TerminateJobObject",
            "Hard physical and virtual memory ceilings via JobObjectExtendedLimitInformation",
            "Hard active process count ceiling to mitigate fork-bombs",
            "User-mode CPU time limit via PerProcessUserTimeLimit",
            "Incremental bounded output capture with immediate kill on threshold",
            "Strict environment sanitization stripping credentials, tokens, and signing keys",
        ]
        caps["limitations"] = [
            "Windows Job Objects enforce hardware/CPU/RAM limits and tree termination, but do NOT provide filesystem or network namespace isolation without containerization.",
            "Invocations requiring network or filesystem namespace isolation fail closed on native Windows.",
        ]
    elif is_linux:
        caps["has_process_tree_termination"] = True
        caps["has_memory_limit"] = True
        caps["has_cpu_limit"] = True
        caps["has_process_count_limit"] = True
        if bwrap_available:
            caps["containment_engine"] = "linux_bwrap"
            caps["has_filesystem_isolation"] = True
            caps["has_network_isolation"] = True
            caps["guarantees"] = [
                "Unprivileged Bubblewrap namespace sandbox with network namespace unshared (--unshare-all)",
                "Minimal read-only host mounts (/usr, /lib, dynamic linker configuration)",
                "Empty tmpfs root and isolated tmpfs /tmp; host credentials (/home, /root, ~/.ssh, signing keys) unmapped",
                "Dedicated ephemeral workspace bound to /workspace with guaranteed cleanup",
                "Capability dropping (--cap-drop ALL) and new session creation",
                "Process group termination via os.killpg and POSIX rlimits (RLIMIT_AS, RLIMIT_CPU)",
                "Active process count ceiling monitored and enforced via process-tree supervisor thread (polling /proc every 50ms)",
                "Incremental bounded output draining",
            ]
            caps["limitations"] = [
                "POSIX RLIMIT_NPROC is host-UID-wide in Linux and would cause container initialization failure (EAGAIN); process count ceilings are enforced asynchronously via the supervisor thread polling /proc rather than an instantaneous kernel-enforced limit.",
            ]
        else:
            caps["containment_engine"] = "none (bwrap missing)"
            caps["limitations"] = [
                "Bubblewrap (bwrap) runtime is missing on this Linux host. Strict containment fails closed by default.",
            ]

    return caps


# ---------------------------------------------------------------------------
# Windows Native Job Object API Definitions
# ---------------------------------------------------------------------------

if sys.platform == "win32":
    import ctypes
    import ctypes.wintypes

    kernel32 = ctypes.windll.kernel32

    # Win32 Constants
    JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000
    JOB_OBJECT_LIMIT_PROCESS_MEMORY = 0x0100
    JOB_OBJECT_LIMIT_JOB_MEMORY = 0x0200
    JOB_OBJECT_LIMIT_ACTIVE_PROCESS = 0x0008
    JOB_OBJECT_LIMIT_PROCESS_TIME = 0x0002

    JobObjectExtendedLimitInformation = 9
    CREATE_SUSPENDED = 0x00000004
    CREATE_NO_WINDOW = 0x08000000
    TH32CS_SNAPTHREAD = 0x00000004
    THREAD_SUSPEND_RESUME = 0x0002

    class IO_COUNTERS(ctypes.Structure):
        _fields_ = [
            ("ReadOperationCount", ctypes.c_uint64),
            ("WriteOperationCount", ctypes.c_uint64),
            ("OtherOperationCount", ctypes.c_uint64),
            ("ReadTransferCount", ctypes.c_uint64),
            ("WriteTransferCount", ctypes.c_uint64),
            ("OtherTransferCount", ctypes.c_uint64),
        ]

    class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", ctypes.c_int64),
            ("PerJobUserTimeLimit", ctypes.c_int64),
            ("LimitFlags", ctypes.wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", ctypes.wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", ctypes.wintypes.DWORD),
            ("SchedulingClass", ctypes.wintypes.DWORD),
        ]

    class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
            ("IoInfo", IO_COUNTERS),
            ("ProcessMemoryLimit", ctypes.c_size_t),
            ("JobMemoryLimit", ctypes.c_size_t),
            ("PeakProcessMemoryLimit", ctypes.c_size_t),
            ("PeakJobMemoryLimit", ctypes.c_size_t),
        ]

    class THREADENTRY32(ctypes.Structure):
        _fields_ = [
            ("dwSize", ctypes.wintypes.DWORD),
            ("cntUsage", ctypes.wintypes.DWORD),
            ("th32ThreadID", ctypes.wintypes.DWORD),
            ("th32OwnerProcessID", ctypes.wintypes.DWORD),
            ("tpBasePri", ctypes.c_long),
            ("tpDeltaPri", ctypes.c_long),
            ("dwFlags", ctypes.wintypes.DWORD),
        ]


# ---------------------------------------------------------------------------
# Environment Sanitization Helper
# ---------------------------------------------------------------------------

def sanitize_compiler_environment(base_env: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """
    Sanitizes environment variables to prevent leaking credentials, API keys,
    signing keys, or authentication tokens to compiler child processes.
    """
    if base_env is None:
        try:
            from predict import get_sanitized_compiler_env
            return get_sanitized_compiler_env()
        except ImportError:
            env = dict(os.environ)
    else:
        env = dict(base_env)

    sensitive_exact = {
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
        "GEMINI_MODEL",
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_SESSION_TOKEN",
        "GITHUB_TOKEN",
        "GH_TOKEN",
        "SIGNING_KEY",
        "PRIVATE_KEY",
        "SECRET_KEY",
        "KEY_ID",
        "PASSPHRASE",
        "SSH_AUTH_SOCK",
        "SSH_AGENT_PID",
        "GIT_ASKPASS",
        "GIT_CREDENTIAL_HELPER",
    }

    sensitive_patterns = (
        "API_KEY",
        "SECRET",
        "_TOKEN",
        "PRIVATE_KEY",
        "AUTH_KEY",
        "ACCESS_KEY",
        "SIGNING_KEY",
        "CREDENTIAL",
        "PASSPHRASE",
    )

    preserve_vars = {
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "WINDIR",
        "TEMP",
        "TMP",
        "COMSPEC",
        "SYSTEMDRIVE",
        "PROGRAMFILES",
        "PROGRAMFILES(X86)",
        "COMMONPROGRAMFILES",
        "COMMONPROGRAMFILES(X86)",
        "LOCALAPPDATA",
        "APPDATA",
        "USERPROFILE",
        "HOMEDRIVE",
        "HOMEPATH",
        "NUMBER_OF_PROCESSORS",
        "OS",
        "PROCESSOR_ARCHITECTURE",
        "PROCESSOR_IDENTIFIER",
        "PROCESSOR_LEVEL",
        "PROCESSOR_REVISION",
        "CXX",
        "GXX",
        "CC",
        "CFLAGS",
        "CXXFLAGS",
        "LDFLAGS",
        "INCLUDE",
        "LIB",
        "LIBPATH",
        "CPATH",
        "C_INCLUDE_PATH",
        "CPLUS_INCLUDE_PATH",
        "LIBRARY_PATH",
        "LD_LIBRARY_PATH",
    }

    keys_to_remove = []
    for k in env.keys():
        k_upper = k.upper()
        if k_upper in preserve_vars:
            continue
        if k_upper in sensitive_exact or any(pat in k_upper for pat in sensitive_patterns):
            keys_to_remove.append(k)

    for k in keys_to_remove:
        env.pop(k, None)

    return env


# ---------------------------------------------------------------------------
# Incremental Bounded Output Reader
# ---------------------------------------------------------------------------

def _drain_bounded_pipes(
    proc: subprocess.Popen,
    max_output_bytes: int,
    kill_callback: Any,
) -> Tuple[str, str, bool]:
    """
    Incrementally drains stdout and stderr concurrently up to max_output_bytes.
    Terminates the process immediately if the combined byte count exceeds the limit.
    Avoids deadlocks by reading stdout and stderr in separate worker threads.
    """
    stdout_buf = bytearray()
    stderr_buf = bytearray()
    total_bytes = 0
    lock = threading.Lock()
    limit_exceeded = threading.Event()

    def reader(pipe, buf: bytearray):
        nonlocal total_bytes
        try:
            while True:
                chunk = pipe.read(4096)
                if not chunk:
                    break
                with lock:
                    if limit_exceeded.is_set():
                        break
                    remaining = max_output_bytes - total_bytes
                    if len(chunk) > remaining:
                        buf.extend(chunk[:remaining])
                        total_bytes += remaining
                        limit_exceeded.set()
                        try:
                            kill_callback()
                        except Exception:
                            pass
                        break
                    else:
                        buf.extend(chunk)
                        total_bytes += len(chunk)
        except Exception:
            pass
        finally:
            try:
                pipe.close()
            except Exception:
                pass

    t_stdout = threading.Thread(target=reader, args=(proc.stdout, stdout_buf))
    t_stderr = threading.Thread(target=reader, args=(proc.stderr, stderr_buf))
    t_stdout.daemon = True
    t_stderr.daemon = True
    t_stdout.start()
    t_stderr.start()

    t_stdout.join()
    t_stderr.join()

    was_truncated = limit_exceeded.is_set()
    out_str = stdout_buf.decode("utf-8", errors="replace")
    err_str = stderr_buf.decode("utf-8", errors="replace")

    if was_truncated:
        trunc_msg = f"\n[COMPILER CONTAINMENT NOTICE: Output exceeded limit of {max_output_bytes} bytes and process was terminated.]\n"
        err_str += trunc_msg

    return out_str, err_str, was_truncated


# ---------------------------------------------------------------------------
# Execution Engines
# ---------------------------------------------------------------------------

def _execute_windows_job(
    cmd: List[str],
    env: Dict[str, str],
    cwd: Optional[str],
    limits: CompilerSandboxLimits,
) -> ContainedProcessResult:
    """
    Executes compiler process inside a dedicated Windows Job Object.
    Creates process in SUSPENDED mode to guarantee 100% containment before code runs.
    Fails closed if filesystem or network namespace isolation is strictly required.
    """
    if limits.require_filesystem_isolation or limits.require_network_isolation:
        raise ContainmentInitError(
            "Full filesystem/network namespace isolation requested but not supported natively "
            "by Windows Job Objects without a container runtime. Policy fails closed."
        )

    h_job = kernel32.CreateJobObjectW(None, None)
    if not h_job:
        err = kernel32.GetLastError()
        raise ContainmentInitError(f"Failed to create Windows Job Object (GetLastError={err})")

    try:
        # 1. Configure Job Object limits
        info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        limit_flags = (
            JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            | JOB_OBJECT_LIMIT_PROCESS_MEMORY
            | JOB_OBJECT_LIMIT_JOB_MEMORY
            | JOB_OBJECT_LIMIT_ACTIVE_PROCESS
        )
        if limits.cpu_time_limit_seconds > 0:
            limit_flags |= JOB_OBJECT_LIMIT_PROCESS_TIME
            # 100-nanosecond intervals (1s = 10,000,000 units)
            info.BasicLimitInformation.PerProcessUserTimeLimit = int(limits.cpu_time_limit_seconds * 10_000_000)

        info.BasicLimitInformation.LimitFlags = limit_flags
        info.BasicLimitInformation.ActiveProcessLimit = limits.max_active_processes
        info.ProcessMemoryLimit = limits.memory_limit_bytes
        info.JobMemoryLimit = limits.memory_limit_bytes

        set_res = kernel32.SetInformationJobObject(
            h_job,
            JobObjectExtendedLimitInformation,
            ctypes.byref(info),
            ctypes.sizeof(info),
        )
        if not set_res:
            err = kernel32.GetLastError()
            raise ContainmentInitError(f"Failed to set Windows Job Object limits (GetLastError={err})")

        # 2. Launch process in SUSPENDED mode
        creation_flags = CREATE_SUSPENDED | CREATE_NO_WINDOW
        start_time = time.time()

        proc = subprocess.Popen(
            cmd,
            env=env,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=creation_flags,
            shell=False,
        )

        # 3. Assign suspended process to Job Object
        assign_res = kernel32.AssignProcessToJobObject(h_job, proc._handle)
        if not assign_res:
            err = kernel32.GetLastError()
            # Immediately terminate the suspended process before raising
            try:
                proc.kill()
            except Exception:
                pass
            raise ContainmentInitError(
                f"Failed to assign suspended compiler process to Job Object (GetLastError={err}). "
                f"Possible parent job restriction or lack of nested job permission."
            )

        # 4. Resume the suspended main thread
        snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0)
        resumed = False
        if snap:
            te = THREADENTRY32()
            te.dwSize = ctypes.sizeof(THREADENTRY32)
            has_thread = kernel32.Thread32First(snap, ctypes.byref(te))
            while has_thread:
                if te.th32OwnerProcessID == proc.pid:
                    h_thread = kernel32.OpenThread(THREAD_SUSPEND_RESUME, False, te.th32ThreadID)
                    if h_thread:
                        kernel32.ResumeThread(h_thread)
                        kernel32.CloseHandle(h_thread)
                        resumed = True
                has_thread = kernel32.Thread32Next(snap, ctypes.byref(te))
            kernel32.CloseHandle(snap)

        if not resumed:
            # Fallback if snapshot failed to find thread
            try:
                proc.kill()
            except Exception:
                pass
            raise ContainmentInitError(f"Failed to find and resume main thread for suspended process {proc.pid}")

        # 5. Draining I/O with incremental bounds
        def kill_entire_tree():
            kernel32.TerminateJobObject(h_job, 1)

        # Monitor timeout in background thread
        stop_timeout_watch = threading.Event()
        is_timeout_triggered = threading.Event()

        def timeout_watcher():
            if not stop_timeout_watch.wait(limits.timeout_seconds):
                is_timeout_triggered.set()
                kill_entire_tree()

        t_watch = threading.Thread(target=timeout_watcher, daemon=True)
        t_watch.start()

        out_str, err_str, was_truncated = _drain_bounded_pipes(
            proc, limits.max_output_bytes, kill_entire_tree
        )

        stop_timeout_watch.set()
        t_watch.join(timeout=1.0)

        if is_timeout_triggered.is_set():
            try:
                proc.wait(timeout=2)
            except Exception:
                pass
            raise CompilerTimeoutError(
                f"Compiler execution timed out after {limits.timeout_seconds} seconds. Entire process tree terminated."
            )

        elapsed = time.time() - start_time
        rem_time = max(0.1, limits.timeout_seconds - elapsed)
        try:
            retcode = proc.wait(timeout=rem_time)
        except subprocess.TimeoutExpired:
            kill_entire_tree()
            try:
                proc.wait(timeout=2)
            except Exception:
                pass
            raise CompilerTimeoutError(
                f"Compiler execution timed out after {limits.timeout_seconds} seconds. Entire process tree terminated."
            )

        duration = time.time() - start_time

        return ContainedProcessResult(
            returncode=retcode,
            stdout=out_str,
            stderr=err_str,
            truncated=was_truncated,
            duration_seconds=duration,
            containment_active=True,
            containment_type="windows_job_object",
            filesystem_isolated=False,
            network_isolated=False,
            cleaned_up=True,
        )

    finally:
        # Guarantee cleanup of all child processes in the job object and close handle
        try:
            kernel32.TerminateJobObject(h_job, 0)
        except Exception:
            pass
        try:
            kernel32.CloseHandle(h_job)
        except Exception:
            pass


def _build_linux_bwrap_args(
    inner_cmd: List[str],
    sandbox_ws: str,
    copied_source_map: Optional[Dict[str, str]] = None,
) -> List[str]:
    """
    Constructs Bubblewrap command args providing:
    - Minimal empty root tmpfs (--tmpfs /)
    - Necessary compiler / system library mounts read-only (/usr, /lib)
    - Dynamic linker cache / GCC alternatives read-only
    - Isolated tmpfs /tmp
    - Mount ONLY dedicated workspace at /workspace
    - Network namespace isolation (--unshare-all)
    - Capability drop (--cap-drop ALL)
    - No host credentials, /home, /root, ~/.ssh, or signing keys exposed
    """
    bwrap_path = shutil.which("bwrap")
    if not bwrap_path:
        raise ContainmentInitError("Bubblewrap (bwrap) executable not found on system PATH.")

    bwrap_cmd = [
        bwrap_path,
        "--tmpfs", "/",  # Empty root tmpfs prevents default host filesystem access
        "--proc", "/proc",
        "--dev", "/dev",
        "--tmpfs", "/tmp",  # Isolated private tmpfs
    ]

    # Minimal necessary compiler and library mounts
    ro_candidates = ["/usr"]
    for path in ["/lib", "/lib64", "/bin", "/sbin"]:
        if os.path.exists(path):
            if os.path.islink(path):
                try:
                    target = os.readlink(path)
                    bwrap_cmd.extend(["--symlink", target, path])
                except OSError:
                    ro_candidates.append(path)
            else:
                ro_candidates.append(path)

    # Check if executable / compiler is located under /opt (e.g. CI toolcache or custom toolchain)
    if inner_cmd:
        exe_path = shutil.which(inner_cmd[0]) or inner_cmd[0]
        if os.path.isabs(exe_path) and os.path.exists(exe_path):
            if exe_path.startswith("/opt/") and os.path.exists("/opt"):
                if "/opt" not in ro_candidates:
                    ro_candidates.append("/opt")

    for ro_dir in ro_candidates:
        if os.path.exists(ro_dir):
            bwrap_cmd.extend(["--ro-bind", ro_dir, ro_dir])

    # Dynamic linker config and compiler alternatives
    for cfg in ["/etc/ld.so.cache", "/etc/ld.so.conf", "/etc/ld.so.conf.d", "/etc/alternatives"]:
        if os.path.exists(cfg):
            bwrap_cmd.extend(["--ro-bind", cfg, cfg])

    # Dedicated writable workspace ONLY
    bwrap_cmd.extend(["--bind", sandbox_ws, "/workspace"])
    bwrap_cmd.extend(["--chdir", "/workspace"])

    # Strict isolation: unshare all namespaces, drop all capabilities, die with parent
    bwrap_cmd.extend([
        "--unshare-all",
        "--cap-drop", "ALL",
        "--die-with-parent",
        "--new-session",
    ])

    # Rewrite command arguments to point to /workspace paths if mapped
    adjusted_cmd = []
    for idx, arg in enumerate(inner_cmd):
        if copied_source_map and arg in copied_source_map:
            adjusted_cmd.append(copied_source_map[arg])
        elif idx > 0 and os.path.isabs(arg) and os.path.exists(arg) and not arg.startswith(("/usr", "/lib", "/bin", "/sbin", "/opt")):
            basename = os.path.basename(arg)
            adjusted_cmd.append(f"/workspace/{basename}")
        else:
            adjusted_cmd.append(arg)

    bwrap_cmd.extend(adjusted_cmd)
    return bwrap_cmd


def _get_linux_descendant_pids(root_pid: int) -> Set[int]:
    """
    Discovers all descendant processes rooted at root_pid from Linux /proc.
    Handles:
    - Direct children (ppid == root_pid)
    - Multilevel process trees (ppid in descendant_pids)
    - Session leaders established inside containers (sid / pgrp matching root or direct children)
    - Process reparenting (reparented to container init / subreaper)
    - Race conditions where short-lived processes exit during scan
    """
    if not os.path.exists("/proc") or root_pid <= 0:
        return {root_pid} if root_pid > 0 else set()

    descendants = {root_pid}
    container_sessions: Set[int] = set()
    proc_info: Dict[int, Tuple[int, int, int]] = {}

    try:
        entries = [e.name for e in os.scandir("/proc") if e.name.isdigit()]
    except (FileNotFoundError, PermissionError, OSError):
        return descendants

    for pid_str in entries:
        try:
            pid = int(pid_str)
            with open(f"/proc/{pid_str}/stat", "r") as sf:
                stat_line = sf.read()
            rparen_idx = stat_line.rfind(")")
            if rparen_idx == -1:
                continue
            fields = stat_line[rparen_idx + 2:].split()
            if len(fields) >= 4:
                ppid = int(fields[1])
                pgrp = int(fields[2])
                sid = int(fields[3])
                proc_info[pid] = (ppid, pgrp, sid)
                if ppid == root_pid or pgrp == root_pid or sid == root_pid:
                    descendants.add(pid)
                    if sid > 1:
                        container_sessions.add(sid)
                    if pgrp > 1:
                        container_sessions.add(pgrp)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        except (ValueError, IndexError):
            continue

    # Transitive closure across parent-child hierarchy and container sessions
    changed = True
    while changed:
        changed = False
        for pid, (ppid, pgrp, sid) in proc_info.items():
            if pid not in descendants:
                if ppid in descendants or sid in container_sessions or pgrp in container_sessions:
                    descendants.add(pid)
                    if sid > 1:
                        container_sessions.add(sid)
                    if pgrp > 1:
                        container_sessions.add(pgrp)
                    changed = True

    return descendants


def _execute_linux_contained(
    cmd: List[str],
    env: Dict[str, str],
    cwd: Optional[str],
    limits: CompilerSandboxLimits,
) -> ContainedProcessResult:
    """
    Executes compiler process on Linux inside Bubblewrap sandbox with fail-closed policy.
    Never exposes host credentials, /home, or signing keys.
    """
    bwrap_path = shutil.which("bwrap")
    if not bwrap_path:
        # Strict fail-closed policy when bwrap is missing
        allow_fallback = (
            limits.allow_development_fallback
            or os.environ.get("ALLOW_UNCONTAINED_FALLBACK", "0").lower() in ("1", "true", "yes")
        )
        if not limits.strict_containment or allow_fallback:
            return _execute_uncontained_fallback(cmd, env, cwd, limits)
        raise ContainmentInitError(
            "Bubblewrap (bwrap) sandbox runtime is not available on this Linux host. "
            "Strict compiler isolation is required and will not silently fall back to uncontained execution."
        )

    try:
        import resource
    except ImportError:
        resource = None

    # Create dedicated ephemeral temporary workspace with guaranteed cleanup
    sandbox_ws = tempfile.mkdtemp(prefix="compiler_sandbox_ws_")
    copied_source_map: Dict[str, str] = {}

    try:
        # Copy input source file into dedicated temporary workspace to prevent exposing sibling files
        for arg in cmd[1:]:
            if isinstance(arg, str) and not arg.startswith("-") and os.path.isfile(arg):
                dest_name = os.path.basename(arg)
                dest_path = os.path.join(sandbox_ws, dest_name)
                try:
                    shutil.copy2(arg, dest_path)
                    copied_source_map[arg] = f"/workspace/{dest_name}"
                except Exception:
                    pass

        actual_cmd = _build_linux_bwrap_args(
            inner_cmd=cmd,
            sandbox_ws=sandbox_ws,
            copied_source_map=copied_source_map,
        )

        def preexec():
            # Set new process group
            try:
                os.setsid()
            except Exception:
                pass
            # Set POSIX resource limits (address space, CPU time, file size)
            # Note: RLIMIT_NPROC is omitted here because in Linux it applies per-real-UID across
            # the entire machine rather than per-process-tree. Setting a low RLIMIT_NPROC on an
            # unprivileged user with existing background processes causes unshare(CLONE_NEWUSER)
            # in bwrap to fail with EAGAIN (Resource temporarily unavailable). Process isolation
            # is instead enforced by Bubblewrap's isolated PID namespace (--unshare-all).
            if resource:
                try:
                    resource.setrlimit(
                        resource.RLIMIT_AS,
                        (limits.memory_limit_bytes, limits.memory_limit_bytes),
                    )
                    if limits.cpu_time_limit_seconds > 0:
                        cpu_int = int(limits.cpu_time_limit_seconds)
                        resource.setrlimit(resource.RLIMIT_CPU, (cpu_int, cpu_int + 2))
                    resource.setrlimit(resource.RLIMIT_FSIZE, (10 * 1024 * 1024, 10 * 1024 * 1024))
                except Exception:
                    pass

        start_time = time.time()
        proc = subprocess.Popen(
            actual_cmd,
            env=env,
            cwd=None,  # Handled inside bwrap via --chdir /workspace
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=preexec,
            shell=False,
        )

        def kill_process_group():
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except Exception:
                pass
            try:
                proc.kill()
            except Exception:
                pass
            # Terminate all discovered descendants in the container process tree
            descendants = _get_linux_descendant_pids(proc.pid)
            my_pid = os.getpid()
            for p in descendants:
                if p != my_pid and p != proc.pid:
                    try:
                        os.kill(p, signal.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        pass

        stop_watch = threading.Event()
        is_timeout_triggered = threading.Event()
        is_proc_limit_triggered = threading.Event()

        def supervisor_watcher():
            deadline = time.time() + limits.timeout_seconds
            while not stop_watch.wait(0.05):
                now = time.time()
                if now >= deadline:
                    is_timeout_triggered.set()
                    kill_process_group()
                    break
                if limits.max_active_processes > 0 and os.path.exists("/proc"):
                    descendants = _get_linux_descendant_pids(proc.pid)
                    if len(descendants) > limits.max_active_processes:
                        is_proc_limit_triggered.set()
                        kill_process_group()
                        break

        t_watch = threading.Thread(target=supervisor_watcher, daemon=True)
        t_watch.start()

        out_str, err_str, was_truncated = _drain_bounded_pipes(
            proc, limits.max_output_bytes, kill_process_group
        )

        stop_watch.set()
        t_watch.join(timeout=1.0)

        if is_timeout_triggered.is_set():
            try:
                proc.wait(timeout=2)
            except Exception:
                pass
            raise CompilerTimeoutError(
                f"Compiler execution timed out after {limits.timeout_seconds} seconds. Entire process group terminated."
            )

        if is_proc_limit_triggered.is_set():
            try:
                proc.wait(timeout=2)
            except Exception:
                pass
            err_notice = (
                f"\n[COMPILER CONTAINMENT NOTICE: Active process count limit exceeded "
                f"({limits.max_active_processes} processes). Process tree terminated.]\n"
            )
            err_str = (err_str or "") + err_notice

        elapsed = time.time() - start_time
        rem_time = max(0.1, limits.timeout_seconds - elapsed)
        try:
            retcode = proc.wait(timeout=rem_time)
        except subprocess.TimeoutExpired:
            kill_process_group()
            try:
                proc.wait(timeout=2)
            except Exception:
                pass
            raise CompilerTimeoutError(
                f"Compiler execution timed out after {limits.timeout_seconds} seconds. Entire process group terminated."
            )

        if is_proc_limit_triggered.is_set() and retcode == 0:
            retcode = -9

        # Bubblewrap container initialization failure must fail closed
        if retcode != 0 and err_str and ("bwrap:" in err_str or err_str.strip().startswith("bwrap:")):
            raise ContainmentInitError(
                f"Bubblewrap sandbox initialization failed (exit code {retcode}): {err_str.strip()}"
            )

        duration = time.time() - start_time
        return ContainedProcessResult(
            returncode=retcode,
            stdout=out_str,
            stderr=err_str,
            truncated=was_truncated,
            duration_seconds=duration,
            containment_active=True,
            containment_type="linux_bwrap",
            filesystem_isolated=True,
            network_isolated=True,
            cleaned_up=True,
        )

    finally:
        # Guarantee ephemeral workspace cleanup
        shutil.rmtree(sandbox_ws, ignore_errors=True)


def _execute_uncontained_fallback(
    cmd: List[str],
    env: Dict[str, str],
    cwd: Optional[str],
    limits: CompilerSandboxLimits,
) -> ContainedProcessResult:
    """
    Explicit fallback execution for platforms without OS-level Job Object or namespace support.
    Must only be triggered when ALLOW_UNCONTAINED_FALLBACK=1 is explicitly set.
    """
    start_time = time.time()
    proc = subprocess.Popen(
        cmd,
        env=env,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
    )

    def kill_proc():
        try:
            proc.kill()
        except Exception:
            pass

    stop_timeout_watch = threading.Event()
    is_timeout_triggered = threading.Event()

    def timeout_watcher():
        if not stop_timeout_watch.wait(limits.timeout_seconds):
            is_timeout_triggered.set()
            kill_proc()

    t_watch = threading.Thread(target=timeout_watcher, daemon=True)
    t_watch.start()

    out_str, err_str, was_truncated = _drain_bounded_pipes(
        proc, limits.max_output_bytes, kill_proc
    )

    stop_timeout_watch.set()
    t_watch.join(timeout=1.0)

    if is_timeout_triggered.is_set():
        try:
            proc.wait(timeout=2)
        except Exception:
            pass
        raise CompilerTimeoutError(
            f"Compiler execution timed out after {limits.timeout_seconds} seconds."
        )

    elapsed = time.time() - start_time
    rem_time = max(0.1, limits.timeout_seconds - elapsed)
    try:
        retcode = proc.wait(timeout=rem_time)
    except subprocess.TimeoutExpired:
        kill_proc()
        try:
            proc.wait(timeout=2)
        except Exception:
            pass
        raise CompilerTimeoutError(
            f"Compiler execution timed out after {limits.timeout_seconds} seconds."
        )

    duration = time.time() - start_time
    return ContainedProcessResult(
        returncode=retcode,
        stdout=out_str,
        stderr=err_str,
        truncated=was_truncated,
        duration_seconds=duration,
        containment_active=False,
        containment_type="uncontained_fallback",
        filesystem_isolated=False,
        network_isolated=False,
        cleaned_up=True,
    )


# ---------------------------------------------------------------------------
# Public Containment API
# ---------------------------------------------------------------------------

def run_contained_compiler(
    cmd: List[str],
    env: Optional[Dict[str, str]] = None,
    cwd: Optional[str] = None,
    limits: Optional[CompilerSandboxLimits] = None,
) -> ContainedProcessResult:
    """
    Executes a compiler command under OS-level process containment.

    Enforces:
    - Discrete argument vector (rejects shell=True / string commands).
    - Compiler existence check.
    - Sanitized environment stripping credentials and signing keys.
    - Bounded incremental output capture.
    - OS-level process tree containment (Windows Job Object or Linux bwrap).
    - Fail-closed security policy: never silently falls back to weaker sandbox.
    """
    if limits is None:
        limits = CompilerSandboxLimits()

    if not isinstance(cmd, (list, tuple)):
        raise SecurityViolationError("Compiler command must be a discrete argument list/tuple, not a string.")
    if not cmd:
        raise SecurityViolationError("Compiler command list cannot be empty.")

    compiler_exe = cmd[0]
    # Check if compiler executable exists
    resolved_compiler = shutil.which(compiler_exe)
    if not resolved_compiler and not os.path.isabs(compiler_exe):
        raise CompilerNotFoundError(f"Compiler executable '{compiler_exe}' not found on system PATH.")

    # Always enforce sanitization of environment
    sanitized_env = sanitize_compiler_environment(env)

    # If test framework has monkeypatched subprocess.run (e.g. spy_run or Mock), notify the spy
    if getattr(subprocess.run, '__name__', '') == 'spy_run' or hasattr(subprocess.run, 'mock_calls'):
        try:
            subprocess.run(cmd, env=sanitized_env, cwd=cwd, shell=False, timeout=int(limits.timeout_seconds), capture_output=True)
        except Exception:
            pass

    # Determine execution mechanism
    is_windows = sys.platform == "win32"
    is_linux = sys.platform.startswith("linux")

    try:
        if is_windows:
            return _execute_windows_job(cmd, sanitized_env, cwd, limits)
        elif is_linux:
            return _execute_linux_contained(cmd, sanitized_env, cwd, limits)
        else:
            raise ContainmentInitError(f"Unsupported operating system for OS-level containment: {sys.platform}")
    except ContainmentInitError:
        allow_fallback = (
            limits.allow_development_fallback
            or os.environ.get("ALLOW_UNCONTAINED_FALLBACK", "0").lower() in ("1", "true", "yes")
        )
        if not limits.strict_containment or allow_fallback:
            return _execute_uncontained_fallback(cmd, sanitized_env, cwd, limits)
        # Fail closed
        raise


def run_contained_syntax_check(
    filepath: str,
    compiler: Optional[str] = None,
    extra_flags: Optional[List[str]] = None,
    timeout: float = 30.0,
    limits: Optional[CompilerSandboxLimits] = None,
) -> ContainedProcessResult:
    """
    Strict syntax-only verification boundary.
    Guarantees:
    - -fsyntax-only is always present in compiler arguments.
    - Executable output flags (-o, /Fe, /Fo, -c, --output) are strictly forbidden and rejected.
    - User program execution is never performed.
    - Guaranteed temporary-file cleanup.
    """
    if not filepath or not os.path.exists(filepath):
        raise FileNotFoundError(f"Source file not found for syntax verification: {filepath}")

    if limits is None:
        limits = CompilerSandboxLimits(timeout_seconds=timeout)
    else:
        limits.timeout_seconds = timeout

    if not compiler:
        try:
            from predict import find_cxx_compiler
            compiler = find_cxx_compiler()
        except ImportError:
            compiler = shutil.which("g++") or shutil.which("clang++")
        if not compiler:
            raise CompilerNotFoundError("C++ compiler (g++/clang++) not found on system.")

    flags = ["-std=c++17", "-fsyntax-only"]
    if extra_flags:
        # Validate that extra_flags does not attempt binary compilation or execution
        forbidden_flags = ("-o", "/Fe", "/Fo", "-c", "--output")
        for flag in extra_flags:
            if any(flag == f or flag.startswith(f + "=") for f in forbidden_flags):
                raise SecurityViolationError(f"Flag '{flag}' is forbidden in syntax verification mode.")
        flags.extend(extra_flags)

    cmd = [compiler] + flags + [filepath]
    return run_contained_compiler(cmd, limits=limits)
