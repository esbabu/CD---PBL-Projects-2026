# AI-Based C++ Syntax Error Classifier — Desktop IDE

An installable desktop IDE for diagnosing, explaining, and repairing C++ syntax errors with hybrid compiler acceleration and machine learning heuristics.

Built with an **Electron shell** and a **hardened Python engine** communicating exclusively over **stdio JSON-RPC 2.0 (Zero Open Ports)**.

---

## Architecture & Security Design

1. **Zero Open Ports**:
   - Communication operates strictly over standard input/output (`stdio`) pipes between Electron's main process and the child Python engine.
   - No TCP or UDP listening sockets exist. Neither the engine nor Electron opens any local HTTP port.
2. **Mandatory Approval Gate**:
   - Code repairs cannot be applied automatically. The user is presented with a Monaco diff view (side-by-side or inline) and a compiler verification badge.
   - Any repair request over JSON-RPC requires explicit user approval (`{ proposalId, bufferSha256, approved: true }`). Caller-supplied patches are strictly rejected.
3. **Protected Credential Storage**:
   - Google Gemini API keys are encrypted at rest using Windows DPAPI (`safeStorage`) into `userData/secrets.enc`.
   - The key is never logged, never exposed to the renderer UI, never passed over JSON-RPC, and never reaches compiler subprocesses or compiled programs.
4. **Binary Hardening**:
   - Hardened with `@electron/fuses`: `RunAsNode` disabled, `NODE_OPTIONS` environment variable disabled, Node inspect arguments disabled, Embedded Asar integrity validation enabled, Only-load-from-asar enabled.
   - DevTools disabled in packaged production builds.

---

## Folder Structure

```
CD_Project/
├── desktop/                    # Electron desktop shell
│   ├── src/
│   │   ├── main/               # Main process (store, secrets, engine_manager, compiler_service)
│   │   ├── preload/            # Context-isolated secure preload bridge
│   │   └── renderer/           # Monaco editor, tabs, diff view, dashboards, settings
│   ├── build/                  # App icon (.ico, .png)
│   ├── release/                # Packaged NSIS installer and ZIP archive
│   └── package.json
├── engine/                     # Python service layer & stdio JSON-RPC server
│   ├── rpc_main.py             # Stdio JSON-RPC 2.0 server & predict worker
│   ├── service_layer.py        # Business logic service abstraction
│   └── proposal_store.py       # In-memory cryptographically verified proposal store
├── scripts/                    # Automation scripts
│   ├── build_engine.ps1        # Reproducible PyInstaller build script
│   ├── cd_engine.spec          # PyInstaller engine bundle specification
│   ├── parity_check.py         # 19-fixture dev vs built parity harness
│   └── leak_scan.py            # Packaging secret and sensitive file scanner
├── docs/desktop_plan/          # Conversion plans, audits, and gap closures
├── model.pkl                   # Trained RandomForest classifier
├── scaler.pkl                  # Feature scaler
├── label_encoder.pkl           # Label encoder
├── model_checksums.json        # HMAC-signed model integrity manifest
└── requirements.txt            # Python dependencies
```

---

## Development Setup

### Prerequisites
- Windows 10/11
- Python 3.14.5 with dependencies in `requirements.txt`
- Node.js v24+
- Optional: C++ Compiler (`g++` or `clang++` on PATH) for compiler-accelerated diagnostics.

### Running in Development Mode
1. Install desktop dependencies:
   ```bash
   cd desktop
   npm install
   ```
2. Launch development IDE:
   ```bash
   npm start
   ```

### Running Tests
- **Targeted Python Tests**:
  ```bash
  python -m pytest tests/test_apply_repair_three_layers.py tests/test_proposal_api.py tests/test_service_layer.py -q
  ```
- **Desktop Unit Test Suites** (Settings, Secrets, Canary, Compiler, Dashboards, Store, FileService, Markers, Diff):
  ```bash
  cd desktop
  npm run test:unit
  ```
- **Playwright Automated E2E Tests**:
  ```bash
  cd desktop
  npm run test:smoke
  npm run test:xss
  npm run test:diff-e2e
  ```

---

## Building & Packaging

### 1. Build the Python Engine Bundle
```powershell
powershell -ExecutionPolicy Bypass -File scripts/build_engine.ps1
```
Builds `dist/cd_engine/cd_engine.exe` (`--onedir`), purges temporary logs and pycache, and verifies `--predict-worker`.

### 2. Build the Packaged Installer & Zip Archive
```bash
cd desktop
npm run dist:package
```
Generates in `desktop/release/`:
- `AI Syntax Diagnostics IDE Setup 1.0.0.exe` (NSIS per-user installer, no admin elevation required)
- `AI Syntax Diagnostics IDE-1.0.0-win.zip` (Portable unpacked distribution)
- `SHA256SUMS.txt` (Cryptographic verification checksums)

---

## Memory Profile & Resource Utilization

The application is engineered with strong process isolation between the UI shell, background daemon, and computational workers:

### 1. Baseline Idle Memory (App + Persistent Daemon)
At idle (with the editor open and engine connected), memory consumption is steady:
- **Electron Main Process**: ~45–50 MB private working set
- **Monaco Renderer Process**: ~80–90 MB private working set
- **GPU & Utility Processes**: ~30–40 MB private working set
- **Engine Daemon (`cd_engine.exe`)**: ~28 MB private working set
- **Combined Idle Memory**: **~180–210 MB** total resident working set.

### 2. Transient Memory Peak During Diagnostics (~1 GB Virtual Peak)
- When a syntax diagnostic is triggered, the engine spawns an isolated ephemeral worker (`cd_engine.exe --predict-worker <temp_file>`).
- The worker loads scikit-learn, joblib, and the model weights into memory, computes AST and token heuristics, emits the diagnostic result over stdout, and immediately exits.
- **Worker Resident RSS**: ~350 MB resident physical memory during prediction.
- **Worker Virtual Address Space**: ~1 GB virtual address space allocation (runtime allocations and memory-mapped shared libraries in Windows Python runtime).
- **Process Lifecycle & Cleanup**: The ~1 GB peak belongs **exclusively to the ephemeral worker process**, which terminates in < 1 second. The persistent daemon and Electron shell never retain or accumulate worker memory, ensuring zero memory creep over extended IDE sessions.

---

## Known Limitations & Considerations

1. **Unsigned Installer & Windows SmartScreen**:
   - The installer and application binaries are intentionally unsigned (no commercial EV code signing certificate or self-signed certificates). Windows SmartScreen displays *"Windows protected your PC"* on initial run. Users must click *"More info"* $\rightarrow$ *"Run anyway"*.
2. **Antivirus Heuristic False Positives (PyInstaller Engine)**:
   - Standalone executables bundled with PyInstaller (`cd_engine.exe`) are occasionally flagged by generic heuristic antivirus scanners (e.g. Windows Defender heuristic detection) due to the nature of self-extracting runtime packers. The code contains zero malicious logic; verify authenticity using the published `SHA256SUMS.txt`.
3. **Compiler Not Bundled**:
   - The IDE does not bundle a C++ compiler (`g++`/`clang++`) to keep package sizes reasonable and avoid compiler dependency collisions. If no compiler is detected on `PATH`, the IDE operates in AST/ML heuristic fallback mode with clear installation guidance (`winget install BrechtSanders.WinLibs.POSIX.UCRT`).
4. **Heuristic False Positives (Legacy Engine Heuristics)**:
   - Certain valid C++ constructs (specifically valid `do-while` loops) trigger legacy heuristic parser false positives (e.g. `do {` incorrectly flagged as `MISSING_SEMICOLON` at line 4). While `g++ -fsyntax-only` confirms validity, the engine's internal rule priority assigns precedence to statement-level heuristics.
5. **Windows Smart App Control & WDAC Effects**:
   - On systems with Windows Smart App Control or Windows Defender Application Control (WDAC) enforcing strict script and binary policies in `AppData\Local\Temp`, executing newly compiled test executables during code optimization behavioral verification is intercepted by the OS. In such cases, behavioral verification fails closed: the unverified optimization proposal is rejected and the user is notified with an explanatory diagnostic message.
6. **Model Integrity HMAC Key Threat Model**:
   - The cryptographic signing key used to verify `model.pkl`, `scaler.pkl`, and `label_encoder.pkl` integrity (`trusted_keys/model_signing.key`) ships inside the read-only application resource directory. This design effectively detects accidental disk corruption, partial file truncation, and tampering by unprivileged users, but does not defend against a malicious actor possessing write access to the application install folder.

