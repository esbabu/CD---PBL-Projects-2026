"""
retraining_pipeline.py — Controlled, Reproducible ML Candidate Retraining Pipeline.

Guarantees:
1. Production artifacts are NEVER touched during candidate training.
2. Trains candidates in isolated directories: models/candidates/<candidate_id>/.
3. Strict data-leakage prevention: StandardScaler is fitted strictly on the train split.
4. Stratified, reproducible split protocol with recorded sample identities and split hash.
5. Apples-to-apples comparison: evaluates candidate and production baseline on the identical held-out test split.
6. Acceptance gates enforce schema, class order, performance regressions (2% policy limit), and serialization integrity.
7. Generates training manifest, model_checksums.json, confusion matrix, and feature importances.
"""

from __future__ import annotations

import os
import sys
import json
import time
import math
import pickle
import hashlib
import datetime
import importlib.metadata
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Optional, Any

import pandas as pd
import numpy as np
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support,
    classification_report, confusion_matrix
)

from dataset_versioning import (
    CANONICAL_FEATURE_NAMES, CANONICAL_CLASSES,
    load_dataset_version, compute_file_sha256, get_git_revision,
    extract_sample_group
)


@dataclass
class CandidateTrainingConfig:
    dataset_version: str
    random_seed: int = 42
    test_size: float = 0.15
    val_size: float = 0.15
    split_strategy: str = "stratified"  # 'stratified' (row-stratified) or 'grouped' (grouped by base snippet)
    n_estimators: int = 200
    max_depth: Optional[int] = None
    max_features: str = "sqrt"
    max_accuracy_regression_pct: float = 2.0  # Configurable project policy limit
    min_test_accuracy: float = 0.85
    candidate_id: Optional[str] = None


@dataclass
class EvaluationMetrics:
    accuracy: float
    macro_precision: float
    macro_recall: float
    macro_f1: float
    weighted_precision: float
    weighted_recall: float
    weighted_f1: float
    per_class: Dict[str, Dict[str, float]]
    confidence_interval_95: Tuple[float, float]


def compute_wilson_score_interval(correct: int, total: int, z: float = 1.96) -> Tuple[float, float]:
    """Calculates Wilson score 95% confidence interval for classification accuracy."""
    if total <= 0:
        return (0.0, 0.0)
    p = correct / total
    denom = 1 + z**2 / total
    center = (p + z**2 / (2 * total)) / denom
    half_width = (z * math.sqrt((p * (1 - p) + z**2 / (4 * total)) / total)) / denom
    lower = max(0.0, center - half_width)
    upper = min(1.0, center + half_width)
    return (round(lower * 100, 2), round(upper * 100, 2))


def evaluate_model_on_split(
    model: Any,
    scaler: Any,
    X_raw: np.ndarray,
    y_true: np.ndarray,
    classes: List[str],
) -> EvaluationMetrics:
    """Evaluates a model on a given split and computes comprehensive metrics."""
    X_scaled = scaler.transform(X_raw)
    y_pred = model.predict(X_scaled)

    acc = float(accuracy_score(y_true, y_pred))
    correct = int(np.sum(y_true == y_pred))
    ci = compute_wilson_score_interval(correct, len(y_true))

    prec_m, rec_m, f1_m, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    prec_w, rec_w, f1_w, _ = precision_recall_fscore_support(y_true, y_pred, average="weighted", zero_division=0)
    prec_c, rec_c, f1_c, supp_c = precision_recall_fscore_support(y_true, y_pred, average=None, zero_division=0)

    per_class_metrics = {}
    for idx, cls_name in enumerate(classes):
        per_class_metrics[cls_name] = {
            "precision": round(float(prec_c[idx]) * 100, 2),
            "recall": round(float(rec_c[idx]) * 100, 2),
            "f1": round(float(f1_c[idx]) * 100, 2),
            "support": int(supp_c[idx]),
        }

    return EvaluationMetrics(
        accuracy=round(acc * 100, 2),
        macro_precision=round(float(prec_m) * 100, 2),
        macro_recall=round(float(rec_m) * 100, 2),
        macro_f1=round(float(f1_m) * 100, 2),
        weighted_precision=round(float(prec_w) * 100, 2),
        weighted_recall=round(float(rec_w) * 100, 2),
        weighted_f1=round(float(f1_w) * 100, 2),
        per_class=per_class_metrics,
        confidence_interval_95=ci,
    )


def train_and_evaluate_candidate(
    config: CandidateTrainingConfig,
    base_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Executes reproducible candidate model training:
    1. Loads versioned, verified dataset.
    2. Performs stratified train/val/test split and records sample identities.
    3. Fits StandardScaler strictly on X_train.
    4. Trains RandomForestClassifier.
    5. Evaluates candidate and baseline on the identical held-out test split.
    6. Evaluates acceptance gates.
    7. Writes candidate artifacts and manifests to models/candidates/<candidate_id>/.
    """
    start_time = time.time()
    root_dir = base_dir or os.path.dirname(os.path.abspath(__file__))

    # 1. Load dataset version
    df, dataset_manifest = load_dataset_version(
        config.dataset_version,
        base_dir=os.path.join(root_dir, "datasets", "versions")
    )

    feature_cols = CANONICAL_FEATURE_NAMES
    X = df[feature_cols].values
    y = df["label"].values

    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    encoder_classes = list(le.classes_)

    # 2. Split Protocol (Stratified or Grouped by Base Program)
    sample_groups = df["file_name"].apply(extract_sample_group).values

    if config.split_strategy == "grouped":
        # Grouped split: Base program mutations stay strictly within one split
        gss_test = GroupShuffleSplit(n_splits=1, test_size=config.test_size, random_state=config.random_seed)
        train_val_idx, idx_test = next(gss_test.split(X, y_enc, groups=sample_groups))

        val_rel = config.val_size / (1.0 - config.test_size)
        gss_val = GroupShuffleSplit(n_splits=1, test_size=val_rel, random_state=config.random_seed)
        train_sub_idx, val_sub_idx = next(gss_val.split(X[train_val_idx], y_enc[train_val_idx], groups=sample_groups[train_val_idx]))

        idx_train = train_val_idx[train_sub_idx]
        idx_val = train_val_idx[val_sub_idx]

        X_train, y_train = X[idx_train], y_enc[idx_train]
        X_val, y_val = X[idx_val], y_enc[idx_val]
        X_test, y_test = X[idx_test], y_enc[idx_test]
    else:
        # Standard row-stratified split
        X_tmp, X_test, y_tmp, y_test, idx_tmp, idx_test = train_test_split(
            X, y_enc, np.arange(len(df)),
            test_size=config.test_size,
            random_state=config.random_seed,
            stratify=y_enc,
        )
        val_rel = config.val_size / (1.0 - config.test_size)
        X_train, X_val, y_train, y_val, idx_train, idx_val = train_test_split(
            X_tmp, y_tmp, idx_tmp,
            test_size=val_rel,
            random_state=config.random_seed,
            stratify=y_tmp,
        )

    # Audit group distribution across splits
    train_groups = set(df["file_name"].iloc[idx_train].apply(extract_sample_group))
    val_groups = set(df["file_name"].iloc[idx_val].apply(extract_sample_group))
    test_groups = set(df["file_name"].iloc[idx_test].apply(extract_sample_group))
    train_test_overlap = len(train_groups.intersection(test_groups))

    # Compute split manifest & hash
    split_manifest = {
        "dataset_version": config.dataset_version,
        "split_strategy": config.split_strategy,
        "random_seed": config.random_seed,
        "train_size": len(idx_train),
        "val_size": len(idx_val),
        "test_size": len(idx_test),
        "train_groups_count": len(train_groups),
        "val_groups_count": len(val_groups),
        "test_groups_count": len(test_groups),
        "train_test_group_overlap_count": train_test_overlap,
        "train_indices": [int(i) for i in idx_train],
        "val_indices": [int(i) for i in idx_val],
        "test_indices": [int(i) for i in idx_test],
        "train_samples": [str(df["file_name"].iloc[i]) for i in idx_train],
        "val_samples": [str(df["file_name"].iloc[i]) for i in idx_val],
        "test_samples": [str(df["file_name"].iloc[i]) for i in idx_test],
    }
    split_manifest_str = json.dumps(split_manifest, sort_keys=True)
    split_hash = hashlib.sha256(split_manifest_str.encode("utf-8")).hexdigest()

    # 3. Fit Preprocessing STRICTLY on X_train (Leakage Prevention)
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_val_s = scaler.transform(X_val)
    X_test_s = scaler.transform(X_test)

    # 4. Fit Candidate Random Forest
    rf = RandomForestClassifier(
        n_estimators=config.n_estimators,
        max_depth=config.max_depth,
        max_features=config.max_features,
        random_state=config.random_seed,
        n_jobs=-1,
    )
    rf.fit(X_train_s, y_train)

    # 5. Evaluate Candidate
    cand_train_metrics = evaluate_model_on_split(rf, scaler, X_train, y_train, encoder_classes)
    cand_val_metrics = evaluate_model_on_split(rf, scaler, X_val, y_val, encoder_classes)
    cand_test_metrics = evaluate_model_on_split(rf, scaler, X_test, y_test, encoder_classes)

    # 6. Evaluate Baseline Model on Identical Test Set (if baseline exists)
    baseline_path = os.path.join(root_dir, "model.pkl")
    baseline_scaler_path = os.path.join(root_dir, "scaler.pkl")
    baseline_metrics = None

    if os.path.exists(baseline_path) and os.path.exists(baseline_scaler_path):
        try:
            base_rf = joblib.load(baseline_path)
            base_scaler = joblib.load(baseline_scaler_path)
            baseline_metrics = evaluate_model_on_split(base_rf, base_scaler, X_test, y_test, encoder_classes)
        except Exception as e:
            baseline_metrics = None

    # 7. Evaluate Acceptance Gates
    gate_results = {}
    # Gate 1: Canonical Feature Schema
    gate_results["feature_dimension_30"] = bool(rf.n_features_in_ == 30)

    # Gate 2: All 13 canonical classes in alphabetical order
    gate_results["classes_match_canonical"] = bool(encoder_classes == CANONICAL_CLASSES)

    # Gate 3: Absolute Test Accuracy Threshold
    gate_results["min_test_accuracy_met"] = bool(cand_test_metrics.accuracy >= config.min_test_accuracy * 100)

    # Gate 4: Policy Regression Gate vs Baseline
    if baseline_metrics:
        acc_drop = baseline_metrics.accuracy - cand_test_metrics.accuracy
        gate_results["accuracy_regression_within_policy"] = bool(acc_drop <= config.max_accuracy_regression_pct)
        gate_results["accuracy_delta_vs_baseline"] = round(cand_test_metrics.accuracy - baseline_metrics.accuracy, 2)
    else:
        gate_results["accuracy_regression_within_policy"] = True
        gate_results["accuracy_delta_vs_baseline"] = 0.0

    # Gate 5: No zero F1 scores
    gate_results["no_zero_f1_classes"] = all(
        v["f1"] > 0.0 for v in cand_test_metrics.per_class.values()
    )

    all_gates_passed = all([
        gate_results["feature_dimension_30"],
        gate_results["classes_match_canonical"],
        gate_results["min_test_accuracy_met"],
        gate_results["accuracy_regression_within_policy"],
        gate_results["no_zero_f1_classes"],
    ])

    # 8. Setup Candidate Directory & Write Artifacts
    candidate_id = config.candidate_id or f"cand-{int(time.time())}-{split_hash[:8]}"
    cand_dir = os.path.join(root_dir, "models", "candidates", candidate_id)
    os.makedirs(cand_dir, exist_ok=True)

    cand_model_path = os.path.join(cand_dir, "model.pkl")
    cand_scaler_path = os.path.join(cand_dir, "scaler.pkl")
    cand_le_path = os.path.join(cand_dir, "label_encoder.pkl")
    cand_checksums_path = os.path.join(cand_dir, "model_checksums.json")
    cand_manifest_path = os.path.join(cand_dir, "training_manifest.json")
    split_manifest_path = os.path.join(cand_dir, "split_manifest.json")

    # Serialize candidate artifacts with standard pickle protocol=5 (avoids joblib.numpy_pickle array.shape deprecation)
    with open(cand_model_path, "wb") as f:
        pickle.dump(rf, f, protocol=5)
    with open(cand_scaler_path, "wb") as f:
        pickle.dump(scaler, f, protocol=5)
    with open(cand_le_path, "wb") as f:
        pickle.dump(le, f, protocol=5)

    # Write split manifest
    with open(split_manifest_path, "w", encoding="utf-8") as f:
        json.dump(split_manifest, f, indent=2)

    # Compute candidate checksums and sign with trusted key
    from make_checksums import sign_manifest
    checksums = {
        "model.pkl": compute_file_sha256(cand_model_path),
        "scaler.pkl": compute_file_sha256(cand_scaler_path),
        "label_encoder.pkl": compute_file_sha256(cand_le_path),
    }
    sign_manifest(checksums, base_dir=root_dir)
    with open(cand_checksums_path, "w", encoding="utf-8") as f:
        json.dump(checksums, f, indent=2)

    # Generate Confusion Matrix PNG
    cm = confusion_matrix(y_test, rf.predict(X_test_s))
    plt.figure(figsize=(14, 10))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=encoder_classes, yticklabels=encoder_classes)
    plt.title(f"Confusion Matrix — Candidate {candidate_id}\nTest Accuracy: {cand_test_metrics.accuracy}%", fontsize=14)
    plt.xlabel("Predicted", fontsize=11)
    plt.ylabel("True", fontsize=11)
    plt.xticks(rotation=45, ha="right", fontsize=8)
    plt.yticks(rotation=0, fontsize=8)
    plt.tight_layout()
    cm_path = os.path.join(cand_dir, "confusion_matrix.png")
    plt.savefig(cm_path, dpi=150)
    plt.close()

    # Generate Feature Importance PNG
    fi_df = pd.DataFrame({
        "feature": feature_cols,
        "importance": rf.feature_importances_
    }).sort_values("importance", ascending=False)
    plt.figure(figsize=(12, 7))
    top20 = fi_df.head(20)
    plt.barh(top20["feature"][::-1], top20["importance"][::-1], color="steelblue")
    plt.xlabel("Importance Score")
    plt.title(f"Top 20 Features — Candidate {candidate_id}")
    plt.tight_layout()
    fi_path = os.path.join(cand_dir, "feature_importance.png")
    plt.savefig(fi_path, dpi=150)
    plt.close()

    # 9. Write Comprehensive Training Manifest
    training_manifest = {
        "candidate_id": candidate_id,
        "status": "validated_candidate" if all_gates_passed else "rejected_candidate",
        "gates_passed": all_gates_passed,
        "gate_results": gate_results,
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "training_duration_seconds": round(time.time() - start_time, 2),
        "config": asdict(config),
        "dataset_version": config.dataset_version,
        "dataset_content_sha256": dataset_manifest.get("content_sha256"),
        "split_manifest_hash": split_hash,
        "classes": encoder_classes,
        "checksums": checksums,
        "metrics": {
            "train": asdict(cand_train_metrics),
            "val": asdict(cand_val_metrics),
            "test": asdict(cand_test_metrics),
        },
        "baseline_test_metrics": asdict(baseline_metrics) if baseline_metrics else None,
        "environment": {
            "python_version": sys.version,
            "platform": sys.platform,
            "scikit_learn_version": importlib.metadata.version("scikit-learn"),
            "numpy_version": importlib.metadata.version("numpy"),
            "pandas_version": importlib.metadata.version("pandas"),
            "joblib_version": importlib.metadata.version("joblib"),
            "git_revision": get_git_revision(root_dir),
        },
        "policy_notes": {
            "regression_limit": f"{config.max_accuracy_regression_pct}% tolerance is an agreed engineering policy limit, not a statistical guarantee.",
            "generalization_note": "Single test split provides point estimate. Wilson 95% CI reported for uncertainty.",
        }
    }

    with open(cand_manifest_path, "w", encoding="utf-8") as f:
        json.dump(training_manifest, f, indent=2)

    return training_manifest
