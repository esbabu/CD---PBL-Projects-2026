"""
dataset_versioning.py — Dataset Versioning, Hashing, Validation, and Manifest Engine.

Guarantees:
1. Validates exact canonical 30-feature schema and column order against CANONICAL_FEATURE_NAMES.
2. Validates labels against known canonical classes, checks row counts, finite values, and duplicate records.
3. Content-addressed deterministic dataset ID (dsv-<content_sha256[:16]>).
4. Stores immutable dataset versions under datasets/versions/<dataset_id>/.
5. Records comprehensive metadata manifests including per-class distributions and git commit if available.
6. Refuses to overwrite registered dataset versions with divergent contents.
"""

from __future__ import annotations

import os
import sys
import json
import hashlib
import datetime
import subprocess
from typing import Dict, List, Tuple, Optional, Any
import pandas as pd
import numpy as np

# Canonical feature list from feature_agent.py
CANONICAL_FEATURE_NAMES: List[str] = [
    "num_function_decls",
    "num_var_decls",
    "num_assign_exprs",
    "num_array_decls",
    "num_if_stmts",
    "num_else_stmts",
    "num_while_stmts",
    "num_for_stmts",
    "num_return_stmts",
    "num_compound_stmts",
    "num_expr_stmts",
    "total_nodes",
    "max_depth",
    "avg_depth",
    "num_leaf_nodes",
    "error_invalid_assignment",
    "error_unmatched_brace",
    "error_unmatched_paren",
    "error_missing_semicolon",
    "error_invalid_conditional",
    "error_invalid_loop",
    "error_invalid_type",
    "error_invalid_array",
    "error_invalid_func_decl",
    "total_error_nodes",
    "scope_depth_max",
    "has_orphan_else",
    "func_missing_return",
    "assign_in_condition",
    "nested_func_decl",
]

CANONICAL_CLASSES: List[str] = [
    "EXTRA_TOKENS",
    "INVALID_ARRAY_DECL",
    "INVALID_ASSIGNMENT",
    "INVALID_CONDITIONAL",
    "INVALID_DECLARATION",
    "INVALID_FUNCTION_DECL",
    "INVALID_LOOP",
    "INVALID_TYPE",
    "MISPLACED_KEYWORD",
    "MISSING_SEMICOLON",
    "UNMATCHED_BRACE",
    "UNMATCHED_PARANTHESES",
    "UNTERMINATED_STRING",
]

EXPECTED_COLUMNS: List[str] = ["file_name", "label"] + CANONICAL_FEATURE_NAMES


class DatasetValidationError(Exception):
    """Raised when a dataset violates schema, value, or integrity constraints."""
    pass


class DatasetIntegrityError(Exception):
    """Raised when an immutable dataset version is tampered with or corrupted."""
    pass


def compute_file_sha256(filepath: str) -> str:
    """Computes SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def compute_content_sha256(content_bytes: bytes) -> str:
    """Computes SHA-256 hash of byte content."""
    return hashlib.sha256(content_bytes).hexdigest()


def get_git_revision(cwd: Optional[str] = None) -> Optional[str]:
    """Retrieves current git commit hash if available, else None."""
    try:
        res = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=cwd or os.path.dirname(os.path.abspath(__file__)),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            shell=False,
        )
        if res.returncode == 0:
            return res.stdout.strip()
    except Exception:
        pass
    return None


def extract_sample_group(file_name: str) -> str:
    """Extracts base group identifier from a file_name (e.g. 'aug_0_EXTRA_TOKENS.cpp' -> 'aug_0')."""
    base = os.path.basename(str(file_name))
    if base.startswith("aug_"):
        parts = base.split("_")
        if len(parts) >= 2:
            return f"{parts[0]}_{parts[1]}"
    return os.path.splitext(base)[0]


def validate_dataset_df(
    df: pd.DataFrame,
    required_classes: Optional[List[str]] = None,
    allow_extra_classes: bool = False,
) -> Dict[str, Any]:
    """
    Validates that a DataFrame adheres strictly to the canonical training schema:
    1. Exact column names and order: ['file_name', 'label', ...CANONICAL_FEATURE_NAMES].
    2. Non-empty DataFrame.
    3. No NaN, Null, or Infinite values in feature columns.
    4. Label column contains only non-empty strings.
    5. All required classes are present with count >= 1.
    6. Identifies duplicate rows and near-duplicate feature vectors.

    Returns validation summary dictionary.
    """
    if df.empty:
        raise DatasetValidationError("Dataset is empty; 0 rows found.")

    # 1. Exact Column Order and Names
    cols = list(df.columns)
    if cols != EXPECTED_COLUMNS:
        missing_cols = [c for c in EXPECTED_COLUMNS if c not in cols]
        extra_cols = [c for c in cols if c not in EXPECTED_COLUMNS]
        if missing_cols or extra_cols:
            raise DatasetValidationError(
                f"Schema column mismatch. Missing: {missing_cols}, Unexpected extra: {extra_cols}"
            )
        else:
            raise DatasetValidationError(
                f"Column ordering mismatch. Expected: {EXPECTED_COLUMNS}, Got: {cols}"
            )

    # 2. Check for Nulls or Non-finite numbers in Feature Columns
    feature_df = df[CANONICAL_FEATURE_NAMES]
    if feature_df.isnull().any().any():
        null_counts = feature_df.isnull().sum()[lambda x: x > 0].to_dict()
        raise DatasetValidationError(f"Dataset contains null values in feature columns: {null_counts}")

    # Ensure all feature columns are numeric and finite
    for col in CANONICAL_FEATURE_NAMES:
        if not np.issubdtype(feature_df[col].dtype, np.number):
            raise DatasetValidationError(f"Feature column '{col}' is not numeric (dtype={feature_df[col].dtype})")
        values = feature_df[col].values
        if np.isinf(values).any():
            raise DatasetValidationError(f"Feature column '{col}' contains non-finite (+/-Inf) values.")

    # 3. Label Validation
    if df["label"].isnull().any():
        raise DatasetValidationError("Dataset contains null or missing labels.")

    labels = df["label"].astype(str).str.strip()
    if (labels == "").any():
        raise DatasetValidationError("Dataset contains empty string labels.")

    class_distribution = labels.value_counts().to_dict()

    target_classes = required_classes or CANONICAL_CLASSES
    for req_cls in target_classes:
        if req_cls not in class_distribution:
            raise DatasetValidationError(f"Missing required class '{req_cls}' from dataset.")
        if class_distribution[req_cls] < 1:
            raise DatasetValidationError(f"Class '{req_cls}' has 0 samples.")

    if not allow_extra_classes:
        unexpected_classes = [c for c in class_distribution if c not in target_classes]
        if unexpected_classes:
            raise DatasetValidationError(
                f"Dataset contains unrecognized class labels: {unexpected_classes}. "
                f"Allowed canonical classes: {target_classes}"
            )

    # 4. Duplicate checks
    exact_duplicates = int(df.duplicated().sum())
    feature_duplicates = int(df.duplicated(subset=CANONICAL_FEATURE_NAMES).sum())

    # 5. Group distribution (augmentation families)
    groups = df["file_name"].apply(extract_sample_group)
    group_count = int(groups.nunique())
    group_dist = {str(k): int(v) for k, v in groups.value_counts().items()}

    return {
        "valid": True,
        "sample_count": len(df),
        "feature_count": len(CANONICAL_FEATURE_NAMES),
        "classes": sorted(list(class_distribution.keys())),
        "class_distribution": class_distribution,
        "exact_duplicate_count": exact_duplicates,
        "feature_duplicate_count": feature_duplicates,
        "group_count": group_count,
        "group_distribution": group_dist,
    }


def register_dataset_version(
    csv_path: str,
    output_base_dir: Optional[str] = None,
    generation_method: str = "curated_benchmark",
    description: str = "",
    allow_extra_classes: bool = False,
) -> Dict[str, Any]:
    """
    Validates a CSV dataset, computes its content-addressed identifier,
    and registers it immutably under datasets/versions/<dataset_id>/.

    Guarantees:
    - Never overwrites an existing version with differing content.
    - Preserves exact raw CSV file and writes a metadata manifest.json.
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Source dataset not found at: {csv_path}")

    with open(csv_path, "rb") as f:
        content_bytes = f.read()

    file_sha256 = compute_content_sha256(content_bytes)
    df = pd.read_csv(csv_path)

    # Validate schema and contents
    validation_info = validate_dataset_df(df, allow_extra_classes=allow_extra_classes)

    # Content-addressed deterministic version ID
    version_id = f"dsv-{file_sha256[:16]}"

    if output_base_dir is None:
        root_dir = os.path.dirname(os.path.abspath(__file__))
        output_base_dir = os.path.join(root_dir, "datasets", "versions")

    version_dir = os.path.join(output_base_dir, version_id)
    target_csv = os.path.join(version_dir, "features.csv")
    manifest_path = os.path.join(version_dir, "dataset_manifest.json")

    # If version directory already exists, verify immutability
    if os.path.exists(version_dir):
        if os.path.exists(target_csv):
            existing_sha = compute_file_sha256(target_csv)
            if existing_sha != file_sha256:
                raise DatasetIntegrityError(
                    f"Immutability violation: Version {version_id} already exists with different content SHA {existing_sha} (new: {file_sha256})"
                )
        with open(manifest_path, "r", encoding="utf-8") as f:
            existing_manifest = json.load(f)
        return existing_manifest

    os.makedirs(version_dir, exist_ok=True)

    # Copy raw CSV
    with open(target_csv, "wb") as f:
        f.write(content_bytes)

    manifest = {
        "dataset_version": version_id,
        "content_sha256": file_sha256,
        "file_name": "features.csv",
        "sample_count": validation_info["sample_count"],
        "feature_count": validation_info["feature_count"],
        "feature_schema": CANONICAL_FEATURE_NAMES,
        "classes": validation_info["classes"],
        "class_distribution": validation_info["class_distribution"],
        "exact_duplicate_count": validation_info["exact_duplicate_count"],
        "feature_duplicate_count": validation_info["feature_duplicate_count"],
        "generation_method": generation_method,
        "description": description,
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "git_revision": get_git_revision(os.path.dirname(os.path.abspath(__file__))),
    }

    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    return manifest


def load_dataset_version(
    version_id: str,
    base_dir: Optional[str] = None,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Loads an immutable dataset version and verifies its SHA-256 against the manifest.
    """
    if base_dir is None:
        root_dir = os.path.dirname(os.path.abspath(__file__))
        base_dir = os.path.join(root_dir, "datasets", "versions")

    version_dir = os.path.join(base_dir, version_id)
    target_csv = os.path.join(version_dir, "features.csv")
    manifest_path = os.path.join(version_dir, "dataset_manifest.json")

    if not os.path.exists(target_csv) or not os.path.exists(manifest_path):
        raise FileNotFoundError(f"Dataset version {version_id} not found in {base_dir}")

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    # Verify integrity
    current_sha256 = compute_file_sha256(target_csv)
    if current_sha256 != manifest.get("content_sha256"):
        raise DatasetIntegrityError(
            f"Integrity check failed for dataset {version_id}: SHA-256 mismatch! "
            f"Expected {manifest.get('content_sha256')}, got {current_sha256}"
        )

    df = pd.read_csv(target_csv)
    return df, manifest
