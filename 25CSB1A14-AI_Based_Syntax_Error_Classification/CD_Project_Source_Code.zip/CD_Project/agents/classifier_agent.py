"""Classifier Agent for CD_Project.

Provides a second opinion when Random Forest classifier confidence falls
below a configurable threshold (default 0.60). Validates output classes
against label_encoder.pkl and never overrides the Random Forest silently.
"""

import os
import re
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from agents.base import execute_gemini_call, format_untrusted_code

DEFAULT_CONFIDENCE_THRESHOLD = 0.60

DEFAULT_DIAGNOSTIC_REASONS: Dict[str, str] = {
    "EXTRA_TOKENS": "extraneous tokens are present where not permitted",
    "INVALID_ARRAY_DECL": "array declaration syntax is malformed",
    "INVALID_ASSIGNMENT": "assignment syntax or target is malformed",
    "INVALID_CONDITIONAL": "conditional statement syntax is malformed",
    "INVALID_DECLARATION": "the construct lacks a valid type or declaration",
    "INVALID_FUNCTION_DECL": "function declaration syntax is malformed",
    "INVALID_LOOP": "loop header or construct syntax is malformed",
    "INVALID_TYPE": "the specified type is invalid or unsupported",
    "MISPLACED_KEYWORD": "keyword is used in an invalid syntax context",
    "MISSING_SEMICOLON": "statement does not terminate with ';'",
    "UNMATCHED_BRACE": "brace is unmatched",
    "UNMATCHED_PARANTHESES": "parenthesis is unmatched",
    "UNTERMINATED_STRING": "string literal lacks a closing quote",
    "INVALID_CPP_STRUCTURE": "input lacks recognizable C++ declaration, statement, or program structure",
}


def _clean_reason(reason: Optional[str]) -> str:
    """Cleans up raw reason text, filtering out generic non-informative boilerplate."""
    if not reason:
        return ""
    r = str(reason).strip()
    r = r.rstrip(".;")
    if (r.startswith('"') and r.endswith('"')) or (r.startswith("'") and r.endswith("'")):
        r = r[1:-1].strip()
    lower = r.lower()
    if lower in ("agree with rf", "agree with detector", "agree", "second opinion", "no opinion"):
        return ""
    return r


def _format_reason_for_because(reason: str) -> str:
    """Formats a reason phrase cleanly for inclusion after 'because'."""
    r = reason.strip().rstrip(".")
    if not r:
        return ""
    if r.lower().startswith("because "):
        r = r[8:].strip()
    r_lower = r[0].lower() + r[1:] if len(r) > 1 else r.lower()
    return r_lower


def _has_lexer_token_defect(
    lexer_errors: Optional[List[Dict[str, Any]]] = None,
    tokens: Optional[List[Dict[str, Any]]] = None,
    line: Optional[int] = None,
    snippet: Optional[str] = None,
    source_code: Optional[str] = "",
) -> bool:
    """Checks whether explicit lexer evidence identifies a token or construct as invalid/unknown/malformed.
    
    Returns True ONLY if lexer evidence explicitly reports an invalid, unknown, or malformed token.
    """
    if lexer_errors:
        for le in lexer_errors:
            if not isinstance(le, dict):
                continue
            etype = str(le.get("type", "")).upper()
            emsg = str(le.get("message", "")).lower()
            val = str(le.get("value", "")).strip() if le.get("value") is not None else ""
            err_line = le.get("line")

            is_defect = (
                etype in ("INVALID_TOKEN", "UNTERMINATED_STRING", "UNTERMINATED_CHAR", "EMPTY_CHAR_LITERAL")
                or any(term in emsg for term in ("unrecognized", "invalid token", "unknown token", "malformed token", "unterminated"))
            )
            if not is_defect:
                continue

            if line is not None and line > 0 and err_line is not None and err_line > 0:
                if err_line == line:
                    return True
            elif snippet and val and (snippet.strip() == val or val in snippet or snippet in val):
                return True
            elif line is None or line <= 0:
                return True

    if tokens:
        for tok in tokens:
            if not isinstance(tok, dict):
                continue
            ttype = str(tok.get("token_type", "")).upper()
            tval = str(tok.get("token_value", "")).strip()
            tline = tok.get("line")

            if ttype in ("UNKNOWN", "INVALID"):
                if line is not None and line > 0 and tline is not None and tline > 0:
                    if tline == line:
                        return True
                elif snippet and tval and (snippet.strip() == tval or tval in snippet):
                    return True
                elif line is None or line <= 0:
                    return True

    if tokens is None and source_code:
        try:
            import lexer
            from agents.lexer_agent import detect_malformed_tokens
            derived_toks = list(lexer.tokenize_source(source_code))
            derived_errs, _ = detect_malformed_tokens(derived_toks)
            return _has_lexer_token_defect(lexer_errors=derived_errs, tokens=derived_toks, line=line, snippet=snippet)
        except Exception:
            pass

    return False


def _is_valid_identifier(
    snippet: Optional[str] = None,
    tokens: Optional[List[Dict[str, Any]]] = None,
    line: Optional[int] = None,
) -> bool:
    """Checks whether snippet or the primary token at line is a lexically valid C++ identifier."""
    if snippet:
        clean = snippet.strip().strip("'\"")
        if re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", clean):
            from lexer import CPP_KEYWORDS
            if clean not in CPP_KEYWORDS:
                return True

    if tokens and line is not None and line > 0:
        for t in tokens:
            if isinstance(t, dict) and t.get("line") == line:
                ttype = str(t.get("token_type", "")).upper()
                if ttype == "IDENTIFIER":
                    return True

    return False


def _ground_evidence_reason(
    reason: str,
    lexer_errors: Optional[List[Dict[str, Any]]] = None,
    tokens: Optional[List[Dict[str, Any]]] = None,
    source_code: Optional[str] = "",
    snippet: Optional[str] = "",
    target_line: Optional[int] = None,
    parser_errors: Optional[List[Dict[str, Any]]] = None,
    target_labels: Optional[List[str]] = None,
) -> str:
    """Ensures reason wording distinguishes lexical from syntactic invalidity.
    
    Only allows 'unrecognized token', 'invalid token', 'unknown token', or 'lexically invalid'
    if actual lexer evidence explicitly identifies a malformed or unknown token.
    Otherwise, rewrites with evidence-grounded syntactic wording dynamically.
    """
    if not reason:
        return ""

    r = str(reason).strip()

    # Fast check: does reason contain lexical invalidity claims?
    has_claim = bool(re.search(
        r"(?i)\b(unrecognized\s+token|invalid\s+token|unknown\s+token|lexically\s+invalid|unrecognized\s+tokens|invalid\s+tokens|unknown\s+tokens|unrecognized\s+identifier|unknown\s+identifier)\b",
        r,
    ))
    if not has_claim:
        return r

    # If actual lexer evidence exists, the claim is supported!
    if _has_lexer_token_defect(lexer_errors=lexer_errors, tokens=tokens, line=target_line, snippet=snippet, source_code=source_code):
        return r

    # Determine context dynamically from available evidence
    is_id = _is_valid_identifier(snippet=snippet, tokens=tokens, line=target_line)
    if not is_id and snippet:
        clean_snip = snippet.strip().strip("'\"")
        if re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", clean_snip):
            from lexer import CPP_KEYWORDS
            if clean_snip not in CPP_KEYWORDS:
                is_id = True

    has_parser = bool(parser_errors)
    is_decl_lbl = bool(target_labels and any(lbl in ("INVALID_DECLARATION", "INVALID_FUNCTION_DECL", "INVALID_TYPE") for lbl in target_labels))

    # Pattern 1: e.g. "The word 'start' is an unrecognized token inside the function body"
    def _sub_word_is_unrecognized(match: re.Match) -> str:
        lead = match.group(1) or ""
        tok = match.group(2) or ""
        clean_tok = tok.strip("'\"")
        tok_is_id = bool(re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", clean_tok)) or is_id
        if tok_is_id:
            return f"{lead}{tok} is an identifier in an invalid syntactic context"
        elif has_parser:
            return f"{lead}{tok} appears in an invalid statement context"
        else:
            return f"{lead}{tok} appears in an unexpected syntactic position"

    r_sub = re.sub(
        r"(?i)\b(the\s+word\s+|the\s+token\s+|token\s+)?(['\"]?[a-zA-Z_][a-zA-Z0-9_]*['\"]?)\s+is\s+(?:an?\s+)?(?:unrecognized|invalid|unknown|lexically\s+invalid)\s+token\b",
        _sub_word_is_unrecognized,
        r,
    )
    if r_sub != r:
        return r_sub

    # Pattern 2: e.g. "unrecognized token 'start'" or "invalid token 'start'"
    def _sub_token_name(match: re.Match) -> str:
        tok = match.group(1)
        clean_tok = tok.strip("'\"")
        tok_is_id = bool(re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", clean_tok)) or is_id
        if tok_is_id:
            return f"identifier {tok} in an invalid syntactic context"
        else:
            return f"token {tok} appears in an unexpected syntactic position"

    r_sub = re.sub(
        r"(?i)\b(?:an?\s+)?(?:unrecognized|invalid|unknown|lexically\s+invalid)\s+token\s+(['\"]?[a-zA-Z_][a-zA-Z0-9_]*['\"]?)\b",
        _sub_token_name,
        r,
    )
    if r_sub != r:
        return r_sub

    # Pattern 3: e.g. "unrecognized identifier 'start'" or "unknown identifier 'start'"
    r_sub = re.sub(
        r"(?i)\b(?:unrecognized|invalid|unknown|lexically\s+invalid)\s+identifier(?:\s+(['\"]?[a-zA-Z_][a-zA-Z0-9_]*['\"]?))?\b",
        lambda m: f"identifier {m.group(1)} in an invalid syntactic context" if m.group(1) else "identifier in an invalid syntactic context",
        r,
    )
    if r_sub != r:
        return r_sub

    # Pattern 4: General "unrecognized token", "invalid token" phrases
    if is_id:
        replacement = "an identifier in an invalid syntactic context"
    elif has_parser:
        replacement = "the parser evidence indicates an invalid statement/declaration context"
    elif is_decl_lbl:
        replacement = "the source context is inconsistent with the predicted declaration"
    else:
        replacement = "token appears in an unexpected syntactic position"

    r_sub = re.sub(
        r"(?i)\b(?:an?\s+)?(?:unrecognized|invalid|unknown|lexically\s+invalid)\s+(?:token|tokens)\b",
        replacement,
        r,
    )
    return r_sub


def _extract_source_context(
    candidates: Optional[List[Dict[str, Any]]],
    source_code: Optional[str] = "",
    tokens: Optional[List[Dict[str, Any]]] = None,
    parser_errors: Optional[List[Dict[str, Any]]] = None,
    detector_errors: Optional[List[Dict[str, Any]]] = None,
) -> Optional[str]:
    """Extracts a concise, evidence-grounded source location string (e.g. line 5 ('start')).
    
    Returns None if source localization is uncertain (line <= 0).
    """
    code_lines = source_code.splitlines() if source_code else []
    valid_lines: List[int] = []

    if candidates:
        valid_lines.extend([c["line"] for c in candidates if c.get("line") and c["line"] > 0])

    if not valid_lines:
        for pe in (parser_errors or []):
            if isinstance(pe, dict) and pe.get("line") and pe["line"] > 0:
                valid_lines.append(pe["line"])
        for de in (detector_errors or []):
            if isinstance(de, dict) and de.get("line") and de["line"] > 0:
                valid_lines.append(de["line"])

    if not valid_lines:
        return None

    unique_lines = sorted(list(dict.fromkeys(valid_lines)))
    snippets = [c.get("source", "").strip() for c in (candidates or []) if c.get("source", "").strip()]
    if not snippets and 1 <= unique_lines[0] <= len(code_lines):
        fallback_snip = code_lines[unique_lines[0] - 1].strip()
        if fallback_snip:
            snippets.append(fallback_snip)

    if len(unique_lines) == 1:
        line_num = unique_lines[0]
        if snippets:
            snip = snippets[0]
            snip = " ".join(snip.split())
            if len(snip) > 40:
                snip = snip[:37] + "..."
            return f"line {line_num} ('{snip}')"
        return f"line {line_num}"
    else:
        return f"lines {', '.join(str(l) for l in unique_lines)}"


def _extract_evidence_reason(
    candidates: Optional[List[Dict[str, Any]]] = None,
    detector_errors: Optional[List[Dict[str, Any]]] = None,
    lexer_errors: Optional[List[Dict[str, Any]]] = None,
    parser_errors: Optional[List[Dict[str, Any]]] = None,
    target_labels: Optional[List[str]] = None,
    raw_note: Optional[str] = "",
    source_code: Optional[str] = "",
    tokens: Optional[List[Dict[str, Any]]] = None,
    validated_diagnostics: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """Extracts, grounds, and combines evidence-backed reasons across candidates, parser/lexer data, and diagnostics."""
    cand_list = candidates or []
    reasons: List[str] = []

    cand_snippet = ""
    cand_line = None
    if cand_list:
        cand_snippet = cand_list[0].get("source", "").strip()
        cand_line = cand_list[0].get("line")

    # 1. Candidate reasons
    for c in cand_list:
        rsn = _clean_reason(c.get("reason", ""))
        if rsn:
            c_snip = c.get("source", "").strip() or cand_snippet
            c_line = c.get("line") or cand_line
            grounded_rsn = _ground_evidence_reason(
                reason=rsn,
                lexer_errors=lexer_errors,
                tokens=tokens,
                source_code=source_code,
                snippet=c_snip,
                target_line=c_line,
                parser_errors=parser_errors,
                target_labels=target_labels,
            )
            if grounded_rsn and grounded_rsn not in reasons:
                reasons.append(grounded_rsn)

    # 2. Check parser / root-cause errors
    for pe in (parser_errors or []):
        msg = pe.get("message") if isinstance(pe, dict) else str(pe)
        cleaned = _clean_reason(msg)
        if cleaned:
            pe_line = pe.get("line") if isinstance(pe, dict) else None
            grounded_pe = _ground_evidence_reason(
                reason=cleaned,
                lexer_errors=lexer_errors,
                tokens=tokens,
                source_code=source_code,
                snippet=cand_snippet,
                target_line=pe_line or cand_line,
                parser_errors=parser_errors,
                target_labels=target_labels,
            )
            if grounded_pe and grounded_pe not in reasons:
                reasons.append(grounded_pe)

    # 3. Check lexer errors (these represent true lexical defects)
    for le in (lexer_errors or []):
        msg = le.get("message") if isinstance(le, dict) else str(le)
        cleaned = _clean_reason(msg)
        if cleaned and cleaned not in reasons:
            reasons.append(cleaned)

    # 4. Check detector errors matching candidate labels
    labels_to_check = target_labels or [c.get("label") for c in cand_list if c.get("label")]
    for de in (detector_errors or []):
        if isinstance(de, dict) and de.get("type") in labels_to_check:
            msg = de.get("message") or de.get("description")
            cleaned = _clean_reason(msg)
            if cleaned:
                de_line = de.get("line")
                de_snip = de.get("context") or cand_snippet
                grounded_de = _ground_evidence_reason(
                    reason=cleaned,
                    lexer_errors=lexer_errors,
                    tokens=tokens,
                    source_code=source_code,
                    snippet=de_snip,
                    target_line=de_line or cand_line,
                    parser_errors=parser_errors,
                    target_labels=labels_to_check,
                )
                if grounded_de and grounded_de not in reasons:
                    reasons.append(grounded_de)

    # 5. Check validated diagnostics matching candidate labels
    for vd in (validated_diagnostics or []):
        if isinstance(vd, dict) and vd.get("type") in labels_to_check:
            msg = vd.get("description") or vd.get("message")
            cleaned = _clean_reason(msg)
            if cleaned:
                vd_line = vd.get("line")
                vd_snip = vd.get("context") or cand_snippet
                grounded_vd = _ground_evidence_reason(
                    reason=cleaned,
                    lexer_errors=lexer_errors,
                    tokens=tokens,
                    source_code=source_code,
                    snippet=vd_snip,
                    target_line=vd_line or cand_line,
                    parser_errors=parser_errors,
                    target_labels=labels_to_check,
                )
                if grounded_vd and grounded_vd not in reasons:
                    reasons.append(grounded_vd)

    # 6. Fallback to default diagnostic descriptions for labels that had no specific reason
    if not reasons:
        for lbl in labels_to_check:
            def_rsn = DEFAULT_DIAGNOSTIC_REASONS.get(lbl)
            if def_rsn and def_rsn not in reasons:
                reasons.append(def_rsn)

    # 7. Check raw_note if still empty or provides non-redundant explanation
    if not reasons and raw_note:
        cleaned_raw = _clean_reason(raw_note)
        if cleaned_raw and len(cleaned_raw) > 5 and "unrecognized class" not in cleaned_raw.lower():
            grounded_raw = _ground_evidence_reason(
                reason=cleaned_raw,
                lexer_errors=lexer_errors,
                tokens=tokens,
                source_code=source_code,
                snippet=cand_snippet,
                target_line=cand_line,
                parser_errors=parser_errors,
                target_labels=labels_to_check,
            )
            if grounded_raw and grounded_raw not in reasons:
                reasons.append(grounded_raw)

    clean_unique: List[str] = []
    for r in reasons:
        r_strip = r.strip().rstrip(".")
        if r_strip and not any(r_strip.lower() == u.lower() for u in clean_unique):
            clean_unique.append(r_strip)

    if not clean_unique:
        return ""
    if len(clean_unique) == 1:
        return clean_unique[0]
    if len(clean_unique) == 2:
        return f"{clean_unique[0]} and {clean_unique[1]}"
    return f"{', '.join(clean_unique[:-1])}, and {clean_unique[-1]}"


def generate_reviewer_note(
    rf_label: str,
    rf_confidence: float,
    candidates: Optional[List[Dict[str, Any]]] = None,
    disagreement: bool = False,
    abstain: bool = False,
    source_code: Optional[str] = "",
    raw_note: Optional[str] = "",
    detector_errors: Optional[List[Dict[str, Any]]] = None,
    lexer_errors: Optional[List[Dict[str, Any]]] = None,
    parser_errors: Optional[List[Dict[str, Any]]] = None,
    tokens: Optional[List[Dict[str, Any]]] = None,
    validated_diagnostics: Optional[List[Dict[str, Any]]] = None,
    unrecognized_label: Optional[str] = None,
) -> str:
    """Generates a concise, evidence-grounded reviewer note dynamically across all error types.
    
    Never hardcodes wording specific to any single error or identifier.
    Grounded strictly in available RF, secondary candidate, source, parser, and delimiter evidence.
    """
    effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
    conf_pct = f"{round(effective_conf * 100, 1)}%"

    # 1. Secondary Abstention
    if abstain:
        conf_phrase = f" with low confidence ({conf_pct})" if effective_conf is not None else " with low confidence"
        if unrecognized_label:
            return (
                f"The primary classifier predicted {rf_label}{conf_phrase}. "
                f"[Note: Unrecognized class '{unrecognized_label}' coerced to abstain] "
                f"The secondary reviewer could not establish a sufficiently reliable alternative "
                f"diagnosis from the available evidence, so the system abstains from making a stronger classification."
            )
        reason_detail = ""
        if raw_note:
            cleaned_raw = raw_note.strip().rstrip(".")
            cleaned_raw = re.sub(r"(?i)\b(abstaining|abstain|i abstain)\b", "", cleaned_raw).strip(" ,;.-")
            if cleaned_raw and len(cleaned_raw) > 3 and "unrecognized class" not in cleaned_raw.lower():
                grounded_raw = _ground_evidence_reason(
                    reason=cleaned_raw,
                    lexer_errors=lexer_errors,
                    tokens=tokens,
                    source_code=source_code,
                    snippet="",
                    target_line=None,
                    parser_errors=parser_errors,
                    target_labels=[rf_label],
                )
                reason_detail = f" ({grounded_raw[0].lower() + grounded_raw[1:] if len(grounded_raw) > 1 else grounded_raw.lower()})"

        return (
            f"The primary classifier predicted {rf_label}{conf_phrase}. "
            f"The secondary reviewer could not establish a sufficiently reliable alternative "
            f"diagnosis from the available evidence{reason_detail}, so the system abstains "
            f"from making a stronger classification."
        )

    # 2. Agreement
    if not disagreement:
        source_ctx = _extract_source_context(
            candidates, source_code, tokens, parser_errors, detector_errors
        )
        reason_phrase = _extract_evidence_reason(
            candidates=candidates,
            detector_errors=detector_errors,
            lexer_errors=lexer_errors,
            parser_errors=parser_errors,
            target_labels=[rf_label],
            raw_note=raw_note,
            source_code=source_code,
            tokens=tokens,
            validated_diagnostics=validated_diagnostics,
        )
        if source_ctx and reason_phrase:
            return (
                f"The secondary review supports the primary {rf_label} prediction, "
                f"with the source/parser evidence around {source_ctx} consistent with "
                f"the diagnosed error because {_format_reason_for_because(reason_phrase)}."
            )
        elif source_ctx:
            return (
                f"The secondary review supports the primary {rf_label} prediction, "
                f"with the source/parser evidence around {source_ctx} consistent with "
                f"the diagnosed error."
            )
        elif reason_phrase:
            return (
                f"The secondary review supports the primary {rf_label} prediction, "
                f"with the source/parser evidence consistent with the diagnosed error "
                f"because {_format_reason_for_because(reason_phrase)}."
            )
        else:
            return (
                f"The secondary review supports the primary {rf_label} prediction, "
                f"with the source/parser evidence consistent with the diagnosed error."
            )

    # 3. Disagreement
    cand_list = candidates or []
    cand_labels = [c["label"] for c in cand_list if c.get("label")]
    unique_labels = list(dict.fromkeys(cand_labels))
    if not unique_labels:
        unique_labels = [rf_label]

    if len(unique_labels) == 1:
        cands_phrase = unique_labels[0]
    elif len(unique_labels) == 2:
        cands_phrase = f"{unique_labels[0]} and {unique_labels[1]}"
    else:
        cands_phrase = f"{', '.join(unique_labels[:-1])}, and {unique_labels[-1]}"

    source_ctx = _extract_source_context(
        cand_list, source_code, tokens, parser_errors, detector_errors
    )
    combined_reason = _extract_evidence_reason(
        candidates=cand_list,
        detector_errors=detector_errors,
        lexer_errors=lexer_errors,
        parser_errors=parser_errors,
        target_labels=unique_labels,
        raw_note=raw_note,
        source_code=source_code,
        tokens=tokens,
        validated_diagnostics=validated_diagnostics,
    )

    # Handle multiple candidates collectively
    if len(unique_labels) > 1:
        if source_ctx:
            lead = f"The primary classifier predicted {rf_label}, but the available evidence at {source_ctx} is more consistent with {cands_phrase}."
        else:
            lead = f"The primary classifier predicted {rf_label}, but the available evidence (with uncertain source localization) is more consistent with {cands_phrase}."

        if combined_reason:
            conclusion = f" The parser/source context indicates {combined_reason}, making the primary prediction less supported."
        else:
            conclusion = f" This makes the primary prediction less supported by the observed syntax structure."
        return lead + conclusion

    # Handle single candidate
    if source_ctx:
        around_phrase = f"around {source_ctx}"
    else:
        around_phrase = "(with uncertain source localization)"

    if combined_reason:
        reason_flow = _format_reason_for_because(combined_reason)
        return (
            f"The primary classifier predicted {rf_label}, but the available source/parser evidence "
            f"{around_phrase} is more consistent with {cands_phrase} because {reason_flow}. "
            f"This makes the primary prediction less supported."
        )
    else:
        return (
            f"The primary classifier predicted {rf_label}, but the available source/parser evidence "
            f"{around_phrase} is more consistent with {cands_phrase}. "
            f"This makes the primary prediction less supported."
        )


def get_known_classes(base_dir: Optional[str] = None) -> List[str]:
    """Retrieves the list of valid error classes from label_encoder.pkl.
    
    Verifies model artifact checksums before deserializing label_encoder.pkl.
    Falls back to canonical known error classes if the pickle file cannot be read.
    """
    fallback_classes = [
        "EXTRA_TOKENS",
        "INVALID_ARRAY_DECL",
        "INVALID_ASSIGNMENT",
        "INVALID_CONDITIONAL",
        "INVALID_DECLARATION",
        "INVALID_FUNCTION_DECL",
        "INVALID_LOOP",
        "INVALID_TYPE",
        "MISPLACED_KEYWORD",
        "MISSING_SEMICOLON",
        "UNMATCHED_BRACE",
        "UNMATCHED_PARANTHESES",
        "UNTERMINATED_STRING",
    ]
    if base_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    try:
        from model_promoter import resolve_active_artifacts_dir
        artifacts_dir, _ = resolve_active_artifacts_dir(base_dir)
    except Exception:
        artifacts_dir = base_dir
    le_path = os.path.join(artifacts_dir, "label_encoder.pkl")
    if os.path.exists(le_path):
        from predict import verify_model_checksums
        verify_model_checksums(artifacts_dir)
        try:
            import joblib
            le = joblib.load(le_path)
            return sorted(list(str(c) for c in le.classes_))
        except Exception:
            return sorted(fallback_classes)
    return sorted(fallback_classes)


class DiagnosticCandidate(BaseModel):
    label: str = Field(description="Predicted C++ syntax error class from allowed list")
    line: Optional[int] = Field(default=None, description="1-based line number of the error")
    source: Optional[str] = Field(default="", description="Relevant code snippet or token")
    confidence: Optional[float] = Field(default=None, description="Confidence score between 0.0 and 1.0")
    reason: Optional[str] = Field(default="", description="Reason for diagnosing this error")


class ClassifierAgentResponse(BaseModel):
    label: str = Field(default="", description="Predicted C++ syntax error class from the allowed list")
    confidence_note: str = Field(default="", description="Concise rationale explaining the second opinion or why uncertainty remains")
    abstain: bool = Field(default=False, description="True if uncertain and choosing to abstain from proposing a label")
    candidates: List[DiagnosticCandidate] = Field(
        default_factory=list,
        description="Independently supported diagnostic candidates when genuine multiple problems exist",
    )


class ClassifierAgent:
    """Agent providing low-confidence second opinions alongside Random Forest."""

    def __init__(
        self,
        threshold: float = DEFAULT_CONFIDENCE_THRESHOLD,
        client: Optional[Any] = None,
        base_dir: Optional[str] = None,
    ):
        self.threshold = threshold
        self.client = client
        self.known_classes = get_known_classes(base_dir=base_dir)

    def should_run(self, rf_confidence: float) -> bool:
        """Determines if the Random Forest confidence falls below threshold.
        
        Handles both 0.0-1.0 and 0.0-100.0 representations safely.
        """
        effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
        return effective_conf < self.threshold

    def classify(
        self,
        source_code: str,
        rf_label: str,
        rf_confidence: float,
        detector_errors: Optional[List[Dict[str, Any]]] = None,
        timeout_seconds: float = 10.0,
        lexer_errors: Optional[List[Dict[str, Any]]] = None,
        parser_errors: Optional[List[Dict[str, Any]]] = None,
        tokens: Optional[List[Dict[str, Any]]] = None,
        validated_diagnostics: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Provides a second opinion if RF confidence is below threshold.
        
        Args:
            source_code: User submitted C++ code (untrusted data).
            rf_label: Label predicted by Random Forest.
            rf_confidence: Confidence score from Random Forest (0-100 or 0-1).
            detector_errors: Optional structured errors found by rule detector.
            timeout_seconds: Maximum time in seconds allocated for this model call.
            lexer_errors: Optional errors from lexer analysis.
            parser_errors: Optional errors from parser analysis / root causes.
            tokens: Optional tokens from lexer analysis.
            validated_diagnostics: Optional pre-synthesized diagnostics.
            
        Returns:
            Dict containing:
                - ran: bool
                - rf_label: str
                - rf_confidence: float
                - label: Optional[str]
                - confidence_note: str
                - reviewer_note: str
                - abstain: bool
                - disagreement: bool
                - ai_unavailable: bool
                - candidates: List[Dict[str, Any]]
        """
        from source_locator import resolve_source_location

        effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
        if not self.should_run(rf_confidence):
            high_conf_note = "Random Forest confidence exceeds threshold; second opinion not required."
            return {
                "ran": False,
                "rf_label": rf_label,
                "rf_confidence": round(effective_conf, 4),
                "label": rf_label,
                "confidence_note": high_conf_note,
                "reviewer_note": high_conf_note,
                "abstain": False,
                "disagreement": False,
                "ai_unavailable": False,
                "candidates": [],
            }

        prompt = (
            "You are a C++ syntax error classification expert acting as a secondary reviewer.\n"
            f"The primary Random Forest classifier has low confidence ({round(effective_conf * 100, 1)}%) "
            f"on the prediction: '{rf_label}'.\n\n"
            "ALLOWED CLASSES (You MUST pick from these exact strings if not abstaining):\n"
            f"{self.known_classes}\n\n"
            "SOURCE CODE:\n"
            f"{format_untrusted_code(source_code)}\n\n"
            "TASK:\n"
            "Review the source code carefully.\n"
            "1. If you identify one or multiple genuine syntax problems, provide them in 'candidates'.\n"
            "   Each candidate must include:\n"
            "     - 'label': exact string from ALLOWED CLASSES\n"
            "     - 'line': exact 1-based source line number\n"
            "     - 'source': exact source snippet or token\n"
            "     - 'confidence': confidence score (0.0 - 1.0)\n"
            "     - 'reason': concise explanation for why this error exists\n"
            "2. IMPORTANT: Only report multiple candidates when the source code genuinely contains multiple independent problems "
            "   supported by actual code evidence (for example, an undeclared identifier AND a missing semicolon).\n"
            "   If only one issue is supported, return only that one candidate. Do NOT manufacture or guess multiple errors.\n"
            "3. Set 'label' to the primary error class, and 'confidence_note' summarizing your secondary opinion.\n"
            "4. If the code is ambiguous or you are not confident, set abstain=true with an empty candidates list.\n"
            "5. TECHNICAL PRECISION GUIDELINE:\n"
            "   Distinguish lexical invalidity from syntactic invalidity.\n"
            "   - Only describe a token as an 'unrecognized token', 'invalid token', 'unknown token', or 'lexically invalid' if actual lexer analysis explicitly rejects it (e.g. unknown character '@', malformed escape sequence, or unterminated string/char literal).\n"
            "   - If a token is a lexically valid identifier or keyword placed in an invalid syntactic context, describe it as an identifier/token in an invalid syntactic context, unexpected syntactic position, or inconsistent declaration/statement context."
        )

        response_obj, is_fallback = execute_gemini_call(
            agent_name="ClassifierAgent",
            prompt=prompt,
            schema_cls=ClassifierAgentResponse,
            client=self.client,
            timeout_seconds=timeout_seconds,
        )

        if is_fallback or response_obj is None:
            ai_unavail_note = "AI Classifier second opinion unavailable (retaining Random Forest prediction)."
            return {
                "ran": True,
                "rf_label": rf_label,
                "rf_confidence": round(effective_conf, 4),
                "label": rf_label,
                "confidence_note": ai_unavail_note,
                "reviewer_note": ai_unavail_note,
                "abstain": True,
                "disagreement": False,
                "ai_unavailable": True,
                "candidates": [],
            }

        raw_label = (response_obj.label or "").strip()
        abstain = response_obj.abstain
        confidence_note = response_obj.confidence_note or ""
        code_lines = source_code.splitlines() if source_code else []

        validated_candidates: List[Dict[str, Any]] = []

        if not abstain:
            raw_cands = getattr(response_obj, "candidates", []) or []
            for c in raw_cands:
                c_lbl = getattr(c, "label", "").strip()
                if c_lbl in self.known_classes:
                    c_line = getattr(c, "line", None)
                    c_src = getattr(c, "source", "") or ""
                    c_conf = getattr(c, "confidence", None)
                    c_rsn = getattr(c, "reason", "") or confidence_note

                    if c_line is None or c_line <= 0:
                        c_line, loc_src, _ = resolve_source_location(source_code, error_type=c_lbl, tokens=tokens)
                        if not c_src:
                            c_src = loc_src

                    if not c_src and 1 <= c_line <= len(code_lines):
                        c_src = code_lines[c_line - 1].strip()

                    validated_candidates.append({
                        "label": c_lbl,
                        "line": c_line if (c_line and c_line > 0) else 0,
                        "source": c_src,
                        "confidence": c_conf if c_conf is not None else 0.85,
                        "reason": c_rsn,
                    })

            # If candidates list was empty but primary label is valid, ground the primary label
            if not validated_candidates and raw_label in self.known_classes:
                line_no, snippet, _ = resolve_source_location(source_code, error_type=raw_label, tokens=tokens)
                validated_candidates.append({
                    "label": raw_label,
                    "line": line_no if line_no > 0 else 0,
                    "source": snippet,
                    "confidence": round(effective_conf, 4),
                    "reason": confidence_note,
                })

            # If undeclared construct also independently lacks a semicolon on the same line,
            # verify and preserve both candidates if supported by actual source syntax
            cand_labels = {c["label"] for c in validated_candidates}
            if "INVALID_DECLARATION" in cand_labels and "MISSING_SEMICOLON" not in cand_labels:
                inv_cand = next(c for c in validated_candidates if c["label"] == "INVALID_DECLARATION")
                target_line = inv_cand["line"]
                if 1 <= target_line <= len(code_lines):
                    line_text = code_lines[target_line - 1].strip()
                    if line_text and not line_text.endswith(";") and not line_text.endswith("{") and not line_text.endswith("}"):
                        validated_candidates.append({
                            "label": "MISSING_SEMICOLON",
                            "line": target_line,
                            "source": inv_cand["source"] or line_text,
                            "confidence": 0.85,
                            "reason": f"Statement '{line_text}' on line {target_line} does not terminate with ';'.",
                        })

        unrecognized_label = None
        if not abstain and not validated_candidates:
            if raw_label not in self.known_classes:
                abstain = True
                unrecognized_label = raw_label
                confidence_note = f"{confidence_note} [Note: Unrecognized class '{raw_label}' coerced to abstain]"
            else:
                line_no, snippet, _ = resolve_source_location(source_code, error_type=raw_label, tokens=tokens)
                validated_candidates.append({
                    "label": raw_label,
                    "line": line_no if line_no > 0 else 0,
                    "source": snippet,
                    "confidence": round(effective_conf, 4),
                    "reason": confidence_note,
                })

        final_label = validated_candidates[0]["label"] if validated_candidates else (raw_label if not abstain else rf_label)
        disagreement = (not abstain) and (final_label != rf_label)

        reviewer_note = generate_reviewer_note(
            rf_label=rf_label,
            rf_confidence=rf_confidence,
            candidates=validated_candidates,
            disagreement=disagreement,
            abstain=abstain,
            source_code=source_code,
            raw_note=confidence_note,
            detector_errors=detector_errors,
            lexer_errors=lexer_errors,
            parser_errors=parser_errors,
            tokens=tokens,
            validated_diagnostics=validated_diagnostics,
            unrecognized_label=unrecognized_label,
        )

        return {
            "ran": True,
            "rf_label": rf_label,
            "rf_confidence": round(effective_conf, 4),
            "label": final_label,
            "confidence_note": reviewer_note,
            "reviewer_note": reviewer_note,
            "abstain": abstain,
            "disagreement": disagreement,
            "ai_unavailable": False,
            "candidates": validated_candidates,
        }
