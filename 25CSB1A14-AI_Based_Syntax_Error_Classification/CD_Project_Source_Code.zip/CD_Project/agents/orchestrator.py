"""Orchestrator for CD_Project.

Acts as the central planner and coordinator for the agentic layer:
- Decides which agents to invoke based on request flags and adaptive diagnosis
- Enforces an explicit 10-step orchestrator-level budget and tracks steps taken
- Enforces a strict 20-second total time budget across all agent operations
- Propagates dynamic remaining timeouts to child operations (timeout_seconds = min(10.0, remaining_budget()))
- Provides per-agent failure isolation with targeted try/except handling
- Coordinates structured agent-to-agent handoffs via typed OrchestrationContext
- Performs root-cause-driven adaptive routing (adaptive_diagnose=True)
- Directs downstream routing based on ClassifierAgent confidence, disagreement, and abstention
- Runs a final lightweight deterministic reflection/consistency check
- Strictly preserves human approval workflow for all repairs
- Logs metadata-only audit events via append_audit_log()
- Preserves 100% backward compatibility with existing callers, return keys, and tests
"""

import time
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field

from agents.base import append_audit_log
from agents.classifier_agent import ClassifierAgent, get_known_classes
from agents.explain_agent import ExplainAgent
from agents.feature_agent import (
    DriftDetail,
    FeatureAgent,
    FeatureAnalysis,
    FeatureRequest,
)
from agents.lexer_agent import LexerAgent, LexerAnalysis, LexerRequest
from agents.parser_agent import ParserAgent, ParserAnalysis, ParserRequest
from agents.repair_agent import RepairAgent, RepairPlan, RepairResult

DEFAULT_TOTAL_TIME_BUDGET = 20.0
DEFAULT_MAX_STEPS = 10
TOTAL_DIAGNOSTIC_AGENTS = 6


def _dump_or_dict(obj: Any) -> Any:
    """Safely extracts dictionary from Pydantic model or returns object as-is."""
    if obj is None:
        return None
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    return obj


class OrchestrationContext(BaseModel):
    """Internal orchestration state holding typed Pydantic models for agent-to-agent handoff."""
    source_code: str = Field(description="Untrusted C++ source code being analyzed")
    lexer_result: Optional[LexerAnalysis] = Field(default=None, description="LexerAgent result")
    parser_result: Optional[ParserAnalysis] = Field(default=None, description="ParserAgent result")
    feature_result: Optional[FeatureAnalysis] = Field(default=None, description="FeatureAgent result")
    classifier_result: Optional[Dict[str, Any]] = Field(default=None, description="ClassifierAgent second opinion result")
    explanation_result: Optional[List[Dict[str, Any]]] = Field(default=None, description="ExplainAgent explanations")
    repair_plan: Optional[RepairPlan] = Field(default=None, description="RepairAgent proposal")
    repair_result: Optional[RepairResult] = Field(default=None, description="RepairAgent verification result")
    root_cause_errors: List[Dict[str, Any]] = Field(default_factory=list, description="Parser diagnosed root cause errors")
    cascade_errors: List[Dict[str, Any]] = Field(default_factory=list, description="Parser diagnosed cascade errors")
    tokens: List[Dict[str, Any]] = Field(default_factory=list, description="Token stream from lexer")
    ast_node_count: int = Field(default=0, description="Total AST node count from parser")
    feature_vector: List[Union[int, float]] = Field(default_factory=list, description="Canonical 30 feature vector")
    features: Dict[str, Any] = Field(default_factory=dict, description="Feature dictionary")
    classifier_disagreement: bool = Field(default=False, description="Whether classifier disagreed with primary label")
    classifier_abstain: bool = Field(default=False, description="Whether classifier abstained")
    validated_diagnostics: List[Dict[str, Any]] = Field(default_factory=list, description="Source-grounded, validated diagnostics")
    primary_rf: Optional[Dict[str, Any]] = Field(default=None, description="Primary Random Forest prediction")
    secondary_review: Optional[Dict[str, Any]] = Field(default=None, description="Secondary Classifier Agent review")
    steps_taken: int = Field(default=0, description="Number of agent/tool steps executed")
    max_steps: int = Field(default=DEFAULT_MAX_STEPS, description="Maximum allowable step budget")
    total_agents: int = Field(default=TOTAL_DIAGNOSTIC_AGENTS, description="Total number of diagnostic pipeline agents")
    total_time_budget: float = Field(default=DEFAULT_TOTAL_TIME_BUDGET, description="Global time budget in seconds")
    elapsed_seconds: float = Field(default=0.0, description="Elapsed orchestration time in seconds")
    budget_exhausted: bool = Field(default=False, description="Whether time or step budget was exhausted")
    ai_unavailable: bool = Field(default=False, description="Whether any AI call was unavailable")
    reflection_issues: List[Dict[str, Any]] = Field(default_factory=list, description="Issues flagged during reflection")
    requires_review: bool = Field(default=False, description="Whether human review is required due to inconsistencies")
    agent_errors: Dict[str, str] = Field(default_factory=dict, description="Recorded errors by agent")


class Orchestrator:
    """Coordinates and budgets multi-agent diagnostic execution."""

    def __init__(
        self,
        total_time_budget: float = DEFAULT_TOTAL_TIME_BUDGET,
        classifier_threshold: float = 0.60,
        client: Optional[Any] = None,
        max_steps: int = DEFAULT_MAX_STEPS,
        audit_log_path: Optional[str] = None,
    ):
        self.total_time_budget = total_time_budget
        self.classifier_threshold = classifier_threshold
        self.client = client
        self.max_steps = max_steps
        self.audit_log_path = audit_log_path

        self.explain_agent = ExplainAgent(client=self.client)
        self.classifier_agent = ClassifierAgent(
            threshold=self.classifier_threshold, client=self.client
        )
        self.repair_agent = RepairAgent(client=self.client, audit_log_path=self.audit_log_path)
        self.lexer_agent = LexerAgent(client=self.client)
        self.parser_agent = ParserAgent(client=self.client)
        self.feature_agent = FeatureAgent(
            lexer_agent=self.lexer_agent,
            parser_agent=self.parser_agent,
            client=self.client,
        )

    def _log_event(
        self,
        event: str,
        agent_name: str = "Orchestrator",
        latency_ms: float = 0.0,
        success: bool = True,
        fallback: bool = False,
        step: Optional[int] = None,
        approval_state: Optional[str] = None,
        error_category: Optional[str] = None,
        error_summary: Optional[str] = None,
        extra_metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Appends metadata-only audit entries to agent_audit.jsonl.
        
        Strictly omits source code, prompts, credentials, or secrets.
        """
        extra = extra_metadata or {}
        append_audit_log(
            agent_name=agent_name,
            latency_ms=latency_ms,
            success=success,
            fallback=fallback,
            error_summary=error_summary,
            audit_log_path=self.audit_log_path,
            event=event,
            step=step,
            approval_state=approval_state,
            error_category=error_category,
            **extra,
        )

    def _synthesize_validated_diagnostics(
        self,
        context: OrchestrationContext,
        detector_errors: List[Dict[str, Any]],
        rf_label: str,
        rf_confidence: float,
        source_code: str,
    ) -> List[Dict[str, Any]]:
        """Synthesizes validated diagnostics combining deterministic parser root causes,
        Classifier Agent candidate opinions, and source grounding.
        
        Strictly prevents assigning errors to line 1 merely because an ML classifier predicted
        a label without explicit location.
        """
        from predict import DIAGNOSTICS
        from source_locator import resolve_source_location

        effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
        context.primary_rf = {
            "label": rf_label,
            "confidence": round(effective_conf, 4),
            "confidence_pct": round(effective_conf * 100, 1),
            "low_confidence": self.classifier_agent.should_run(rf_confidence),
        }
        if context.classifier_result:
            context.secondary_review = context.classifier_result

        validated: List[Dict[str, Any]] = []
        code_lines = source_code.splitlines() if source_code else []

        # 1. Check structural validity FIRST
        import lexer
        from structural_validator import validate_cpp_structure, StructuralClassification
        tokens_for_struct = context.tokens if context.tokens else lexer.tokenize_source(source_code, clean=True)
        struct_eval = validate_cpp_structure(tokens_for_struct, source_code)

        is_struct_invalid = (
            struct_eval.classification in (StructuralClassification.UNRECOGNIZED_STRUCTURE, StructuralClassification.AMBIGUOUS_INCOMPLETE)
            or rf_label == "INVALID_CPP_STRUCTURE"
        )

        if is_struct_invalid:
            # Check for higher-precedence lexical errors (e.g. unterminated string)
            lexical_errors = [e for e in (context.root_cause_errors or []) if e.get("type") == "UNTERMINATED_STRING"]
            if lexical_errors:
                for err in lexical_errors:
                    ec = dict(err)
                    diag = DIAGNOSTICS.get(ec.get("type"), {})
                    ec.setdefault("description", diag.get("description", ""))
                    ec.setdefault("fix", diag.get("fix", ""))
                    ec.setdefault("example", diag.get("example", ""))
                    validated.append(ec)
            else:
                loc_line, loc_ctx, _ = resolve_source_location(
                    source_code=source_code,
                    error_type="INVALID_CPP_STRUCTURE",
                    tokens=tokens_for_struct,
                )
                diag = DIAGNOSTICS.get("INVALID_CPP_STRUCTURE", {})
                is_ambig = (struct_eval.is_ambiguous or struct_eval.classification == StructuralClassification.AMBIGUOUS_INCOMPLETE)
                desc = (
                    "The input is unrecognized or incomplete; it does not form a complete C++ declaration, statement, expression, or program structure."
                    if is_ambig else
                    diag.get("description", "The input does not match a recognizable C++ declaration, statement, expression, or program structure.")
                )
                conf_val = 0.40 if is_ambig else 0.95
                validated.append({
                    "type": "INVALID_CPP_STRUCTURE",
                    "line": loc_line,
                    "context": loc_ctx,
                    "uncertain_location": is_ambig,
                    "confidence": conf_val,
                    "description": desc,
                    "fix": diag.get("fix", ""),
                    "example": diag.get("example", ""),
                })
        else:
            # 2. Concrete parser root causes (authoritative for concrete parser locations)
            if context.root_cause_errors:
                for err in context.root_cause_errors:
                    ec = dict(err)
                    diag = DIAGNOSTICS.get(ec.get("type"), {})
                    ec.setdefault("description", diag.get("description", ""))
                    ec.setdefault("fix", diag.get("fix", ""))
                    ec.setdefault("example", diag.get("example", ""))
                    validated.append(ec)

            # 3. Classifier Agent candidates (when agent ran and did not abstain)
            if context.classifier_result and context.classifier_result.get("ran") and not context.classifier_abstain:
                cands = context.classifier_result.get("candidates", [])
                for c in cands:
                    c_lbl = c.get("label")
                    c_line = c.get("line", 0)
                    c_src = c.get("source", "")
                    if c_line is None or c_line <= 0:
                        c_line, c_src, _ = resolve_source_location(
                            source_code=source_code,
                            error_type=c_lbl,
                            tokens=context.tokens,
                        )
                    if not c_src and 1 <= c_line <= len(code_lines):
                        c_src = code_lines[c_line - 1].strip()

                    if not any(e.get("type") == c_lbl and e.get("line") == c_line for e in validated):
                        diag = DIAGNOSTICS.get(c_lbl, {})
                        validated.append({
                            "type": c_lbl,
                            "line": c_line if c_line > 0 else 0,
                            "context": c_src,
                            "confidence": c.get("confidence", 0.85),
                            "reason": c.get("reason", ""),
                            "description": diag.get("description", ""),
                            "fix": diag.get("fix", ""),
                            "example": diag.get("example", ""),
                            "from_secondary_review": True,
                        })

            # 4. Integrate detector errors (deduplicating by type and line)
            if detector_errors:
                for de in detector_errors:
                    dec = dict(de)
                    if dec.get("type") in ("NONE", "NO_ERROR", "CLEAN"):
                        continue
                    # If this line is already diagnosed by root causes or classifier candidate, don't duplicate/conflict
                    if any(v.get("line") == dec.get("line") for v in validated if v.get("line", 0) > 0):
                        continue
                    if any(v.get("type") == dec.get("type") and v.get("line") == dec.get("line") for v in validated):
                        continue
                    if dec.get("line", 0) <= 0 or dec.get("uncertain_location"):
                        loc_line, loc_ctx, loc_unc = resolve_source_location(
                            source_code=source_code,
                            error_type=dec.get("type"),
                            tokens=context.tokens,
                        )
                        dec["line"] = loc_line
                        dec["context"] = loc_ctx
                        dec["uncertain_location"] = loc_unc
                        if any(v.get("line") == dec.get("line") for v in validated if v.get("line", 0) > 0):
                            continue
                    diag = DIAGNOSTICS.get(dec.get("type"), {})
                    dec.setdefault("description", diag.get("description", ""))
                    dec.setdefault("fix", diag.get("fix", ""))
                    dec.setdefault("example", diag.get("example", ""))
                    validated.append(dec)

            # 5. Fallback when still no validated errors
            if not validated:
                err_type = rf_label or "UNKNOWN"
                if err_type and err_type not in ("NONE", "NO_ERROR", "CLEAN", "UNKNOWN"):
                    loc_line, loc_ctx, loc_unc = resolve_source_location(
                        source_code=source_code,
                        error_type=err_type,
                        tokens=context.tokens,
                    )
                    diag = DIAGNOSTICS.get(err_type, {})
                    validated.append({
                        "type": err_type,
                        "line": loc_line,
                        "context": loc_ctx,
                        "uncertain_location": loc_unc,
                        "description": diag.get("description", ""),
                        "fix": diag.get("fix", ""),
                        "example": diag.get("example", ""),
                    })


        # Number and deduplicate
        unique_validated: List[Dict[str, Any]] = []
        seen = set()
        for item in validated:
            key = (item.get("type"), item.get("line"))
            if key not in seen:
                seen.add(key)
                item["index"] = len(unique_validated) + 1
                unique_validated.append(item)

        context.validated_diagnostics = unique_validated
        if context.classifier_result and context.classifier_result.get("ran"):
            context.classifier_result["validated_diagnostics"] = unique_validated
        return unique_validated

    def reflect_and_verify_consistency(
        self,
        context: OrchestrationContext,
        detector_errors: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Lightweight consistency check across agent outputs before finalizing results.
        
        Verifies:
        1. Parser root causes exist in diagnostic context
        2. Classifier labels correspond to supported classes
        3. ExplainAgent explanations refer to diagnosed error lines
        4. Repair proposal targets diagnosed error lines
        5. Repair result status is consistent with verification outcome
        6. Feature drift warnings are preserved and surfaced
        """
        issues: List[Dict[str, Any]] = []

        # 1. Parser root causes exist in diagnostic context
        if context.parser_result and context.parser_result.errors:
            if not context.parser_result.root_cause_errors and not detector_errors:
                issues.append({
                    "check": "parser_root_causes",
                    "severity": "warning",
                    "issue": "Parser detected errors but identified 0 root causes",
                })

        # 2. Classifier labels correspond to supported classes
        if context.classifier_result and context.classifier_result.get("ran"):
            label = context.classifier_result.get("label")
            abstain = context.classifier_result.get("abstain", False)
            known = self.classifier_agent.known_classes
            if not abstain and label and label not in known:
                issues.append({
                    "check": "classifier_label",
                    "severity": "critical",
                    "issue": f"Classifier predicted unsupported class '{label}'",
                })

        # 3. ExplainAgent explanations refer to diagnosed error lines
        diagnosed_lines = {
            int(e["line"])
            for e in (context.root_cause_errors or detector_errors)
            if e.get("line") is not None and int(e.get("line", 0)) > 0
        }
        if context.explanation_result and diagnosed_lines:
            for exp in context.explanation_result:
                exp_line = exp.get("line")
                if exp_line is not None and int(exp_line) not in diagnosed_lines:
                    issues.append({
                        "check": "explain_grounding",
                        "severity": "warning",
                        "issue": f"Explanation for line {exp_line} does not match diagnosed error lines {sorted(list(diagnosed_lines))}",
                    })

        # 4. Repair proposal targets diagnosed error lines
        if context.repair_plan and context.repair_plan.changes and diagnosed_lines:
            for ch in context.repair_plan.changes:
                ch_line = getattr(ch, "line", None) if hasattr(ch, "line") else ch.get("line")
                if ch_line and ch_line > 0 and ch_line not in diagnosed_lines:
                    issues.append({
                        "check": "repair_targeting",
                        "severity": "info",
                        "issue": f"Repair change on line {ch_line} does not match diagnosed error lines {sorted(list(diagnosed_lines))}",
                    })

        # 5. Repair result status is consistent with verification outcome
        if context.repair_result:
            res = context.repair_result
            status = getattr(res, "verification_status", None) if hasattr(res, "verification_status") else res.get("verification_status")
            success = getattr(res, "success", None) if hasattr(res, "success") else res.get("success")
            if status in ("compile_failed", "syntax_error_remaining", "rollback", "rejected") and success:
                issues.append({
                    "check": "repair_consistency",
                    "severity": "critical",
                    "issue": f"Repair status '{status}' contradicts success=True",
                })
            elif status == "verified" and not success:
                issues.append({
                    "check": "repair_consistency",
                    "severity": "critical",
                    "issue": "Repair status 'verified' contradicts success=False",
                })

        # 6. Feature drift warnings are not silently discarded
        if context.feature_result and context.feature_result.drift_detected:
            drift_details = context.feature_result.drift_details or []
            issues.append({
                "check": "feature_drift",
                "severity": "warning",
                "issue": f"Feature drift detected with {len(drift_details)} drift signal(s)",
                "details": [d.model_dump() if hasattr(d, "model_dump") else d for d in drift_details],
            })

        return issues

    def plan_and_execute(
        self,
        source_code: str,
        detector_errors: List[Dict[str, Any]],
        rf_label: str = "UNKNOWN",
        rf_confidence: float = 100.0,
        request_explain: bool = True,
        request_repair: bool = False,
        approved: bool = False,
        approved_code: Optional[str] = None,
        request_lexer: bool = False,
        request_parser: bool = False,
        request_feature: bool = False,
        adaptive_diagnose: bool = False,
        max_steps: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Plans and runs relevant agents within step and time budgets.
        
        Args:
            source_code: User submitted C++ code (untrusted data).
            detector_errors: Errors detected by rule detector.
            rf_label: Label predicted by Random Forest.
            rf_confidence: Confidence score from Random Forest.
            request_explain: True if AI explanation was requested.
            request_repair: True if AI repair was requested.
            approved: True if user approved applying the repair patch.
            approved_code: Proposed code string approved by user to verify and apply.
            request_lexer: True if Lexer Agent analysis was requested.
            request_parser: True if Parser Agent analysis was requested.
            request_feature: True if Feature Agent analysis was requested.
            adaptive_diagnose: True to enable root-cause-driven adaptive routing.
            max_steps: Optional override for orchestrator max_steps budget.
            
        Returns:
            Dict containing combined explanations, classifier opinion,
            repair plan / result, timing, step count, and budget indicators.
        """
        start_time = time.time()
        effective_max_steps = max_steps if max_steps is not None else self.max_steps
        context = OrchestrationContext(
            source_code=source_code,
            max_steps=effective_max_steps,
            total_time_budget=self.total_time_budget,
        )

        self._log_event(
            event="session_start",
            agent_name="Orchestrator",
            step=0,
            extra_metadata={"adaptive_diagnose": adaptive_diagnose},
        )

        def remaining_budget() -> float:
            return max(0.0, self.total_time_budget - (time.time() - start_time))

        def can_step(agent_label: str) -> bool:
            if context.steps_taken >= context.max_steps:
                context.budget_exhausted = True
                self._log_event(
                    event="budget_exhaustion",
                    agent_name=agent_label,
                    step=context.steps_taken,
                    success=False,
                    fallback=True,
                    error_summary=f"Step budget exhausted: {context.steps_taken}/{context.max_steps}",
                )
                return False
            if remaining_budget() <= 1.0:
                context.budget_exhausted = True
                self._log_event(
                    event="budget_exhaustion",
                    agent_name=agent_label,
                    step=context.steps_taken,
                    success=False,
                    fallback=True,
                    error_summary=f"Time budget exhausted: {round(remaining_budget(), 2)}s remaining",
                )
                return False
            return True

        def child_timeout() -> float:
            return max(0.1, min(10.0, remaining_budget()))

        # ======================================================================
        # ADAPTIVE ORCHESTRATION PIPELINE (adaptive_diagnose=True)
        # ======================================================================
        if adaptive_diagnose:
            # 1. Lexer Agent (always runs first in adaptive mode)
            if can_step("LexerAgent"):
                context.steps_taken += 1
                self._log_event(event="agent_invocation", agent_name="LexerAgent", step=context.steps_taken)
                t0 = time.time()
                try:
                    lexer_res = self.lexer_agent.analyze(LexerRequest(source_code=source_code))
                    context.lexer_result = lexer_res
                    context.tokens = lexer_res.tokens or lexer_res.recovered_tokens or []
                    self._log_event(
                        event="agent_success",
                        agent_name="LexerAgent",
                        latency_ms=(time.time() - t0) * 1000.0,
                        success=lexer_res.success,
                        step=context.steps_taken,
                    )
                except Exception as exc:
                    self._log_event(
                        event="agent_failure",
                        agent_name="LexerAgent",
                        latency_ms=(time.time() - t0) * 1000.0,
                        success=False,
                        fallback=True,
                        error_category=type(exc).__name__,
                        error_summary=str(exc),
                        step=context.steps_taken,
                    )
                    context.agent_errors["LexerAgent"] = str(exc)
                    context.lexer_result = LexerAnalysis(
                        success=False,
                        tokens=[],
                        errors=[{"type": "LEXER_FAILURE", "message": str(exc)}],
                        explanation=f"Lexer analysis failed: {str(exc)}",
                    )
            else:
                context.budget_exhausted = True
                context.lexer_result = LexerAnalysis(
                    success=False,
                    tokens=[],
                    errors=[{"type": "TIMEOUT", "message": "Time budget exhausted"}],
                    explanation="Time budget exhausted before lexer analysis could run.",
                )

            # 2. Parser Agent (receives recovered/verified tokens from Lexer)
            if can_step("ParserAgent"):
                context.steps_taken += 1
                self._log_event(event="agent_invocation", agent_name="ParserAgent", step=context.steps_taken)
                t0 = time.time()
                try:
                    tokens_to_pass = context.tokens if context.tokens else None
                    parser_res = self.parser_agent.analyze(
                        ParserRequest(source_code=source_code, tokens=tokens_to_pass)
                    )
                    context.parser_result = parser_res
                    context.root_cause_errors = parser_res.root_cause_errors
                    context.cascade_errors = parser_res.cascade_errors
                    context.ast_node_count = parser_res.ast_node_count
                    self._log_event(
                        event="agent_success",
                        agent_name="ParserAgent",
                        latency_ms=(time.time() - t0) * 1000.0,
                        success=parser_res.success,
                        step=context.steps_taken,
                    )
                except Exception as exc:
                    self._log_event(
                        event="agent_failure",
                        agent_name="ParserAgent",
                        latency_ms=(time.time() - t0) * 1000.0,
                        success=False,
                        fallback=True,
                        error_category=type(exc).__name__,
                        error_summary=str(exc),
                        step=context.steps_taken,
                    )
                    context.agent_errors["ParserAgent"] = str(exc)
                    context.parser_result = ParserAnalysis(
                        success=False,
                        errors=[{"type": "PARSER_FAILURE", "message": str(exc)}],
                        explanation=f"Parser analysis failed: {str(exc)}",
                    )
            else:
                context.budget_exhausted = True
                context.parser_result = ParserAnalysis(
                    success=False,
                    errors=[{"type": "TIMEOUT", "message": "Time budget exhausted"}],
                    explanation="Time budget exhausted before parser analysis could run.",
                )

            # Root-cause-driven error resolution
            diagnosed_errors = (
                context.root_cause_errors
                if context.root_cause_errors
                else detector_errors
            )

            # 3. Feature Agent (runs when AST/syntax representation is valid)
            should_run_feature = (
                request_feature
                or (context.ast_node_count > 0)
                or (context.parser_result and context.parser_result.success)
            )
            if should_run_feature:
                if can_step("FeatureAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="FeatureAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        feature_res = self.feature_agent.analyze(FeatureRequest(source_code=source_code))
                        context.feature_result = feature_res
                        context.feature_vector = feature_res.feature_vector
                        context.features = feature_res.features
                        self._log_event(
                            event="agent_success",
                            agent_name="FeatureAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=feature_res.success,
                            step=context.steps_taken,
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="FeatureAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["FeatureAgent"] = str(exc)
                        context.feature_result = FeatureAnalysis(
                            success=False,
                            drift_detected=True,
                            drift_details=[DriftDetail(drift_type="error", message=str(exc), severity="critical")],
                            explanation=f"Feature analysis failed: {str(exc)}",
                        )
                else:
                    context.budget_exhausted = True
                    context.feature_result = FeatureAnalysis(
                        success=False,
                        drift_detected=True,
                        drift_details=[DriftDetail(drift_type="timeout", message="Time budget exhausted", severity="warning")],
                        explanation="Time budget exhausted before feature analysis could run.",
                    )

            # 4. Classifier Agent (runs second opinion if confidence is low)
            if self.classifier_agent.should_run(rf_confidence):
                if can_step("ClassifierAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="ClassifierAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        opinion = self.classifier_agent.classify(
                            source_code=source_code,
                            rf_label=rf_label,
                            rf_confidence=rf_confidence,
                            detector_errors=diagnosed_errors,
                            timeout_seconds=child_timeout(),
                            tokens=context.tokens,
                            lexer_errors=context.lexer_result.errors if context.lexer_result else None,
                            parser_errors=context.root_cause_errors or (context.parser_result.errors if context.parser_result else None),
                        )
                        context.classifier_result = opinion
                        context.classifier_disagreement = bool(opinion.get("disagreement", False))
                        context.classifier_abstain = bool(opinion.get("abstain", False))
                        if opinion.get("ai_unavailable"):
                            context.ai_unavailable = True
                        self._log_event(
                            event="agent_success",
                            agent_name="ClassifierAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=not opinion.get("ai_unavailable", False),
                            fallback=bool(opinion.get("abstain", False)),
                            step=context.steps_taken,
                            extra_metadata={
                                "disagreement": context.classifier_disagreement,
                                "abstain": context.classifier_abstain,
                            },
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="ClassifierAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
                        context.classifier_result = {
                            "ran": True,
                            "rf_label": rf_label,
                            "rf_confidence": round(effective_conf, 4),
                            "label": rf_label,
                            "confidence_note": f"Classifier failed: {str(exc)}",
                            "abstain": True,
                            "disagreement": False,
                            "ai_unavailable": True,
                        }
                        context.classifier_abstain = True
                        context.ai_unavailable = True
                else:
                    effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
                    context.budget_exhausted = True
                    context.classifier_result = {
                        "ran": True,
                        "rf_label": rf_label,
                        "rf_confidence": round(effective_conf, 4),
                        "label": rf_label,
                        "confidence_note": "Time budget exhausted before classifier second opinion could complete.",
                        "abstain": True,
                        "disagreement": False,
                        "ai_unavailable": True,
                    }
                    context.classifier_abstain = True
                    context.ai_unavailable = True

            # Synthesize validated diagnostics from parser root causes, classifier candidates, and grounded source evidence
            diagnosed_errors = self._synthesize_validated_diagnostics(
                context=context,
                detector_errors=detector_errors,
                rf_label=rf_label,
                rf_confidence=rf_confidence,
                source_code=source_code,
            )

            # 5. Explain Agent (grounded in diagnosed root cause errors and classifier context)
            if request_explain and diagnosed_errors:
                if can_step("ExplainAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="ExplainAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        errors_to_explain = list(diagnosed_errors)
                        if context.classifier_disagreement and context.classifier_result:
                            # Enrich errors with classifier disagreement note for educational context
                            alt_label = context.classifier_result.get("label", "")
                            annotated_errors = []
                            for e in errors_to_explain:
                                ec = dict(e)
                                orig_ctx = ec.get("context", "")
                                ec["context"] = f"{orig_ctx} [Note: Random Forest predicted '{rf_label}', but secondary classifier reviewer suggests '{alt_label}']".strip()
                                annotated_errors.append(ec)
                            errors_to_explain = annotated_errors

                        explain_res = self.explain_agent.explain(
                            detector_errors=errors_to_explain,
                            source_code=source_code,
                            timeout_seconds=child_timeout(),
                        )
                        context.explanation_result = explain_res.get("explanations", [])
                        if explain_res.get("ai_unavailable"):
                            context.ai_unavailable = True
                        self._log_event(
                            event="agent_success",
                            agent_name="ExplainAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=not explain_res.get("ai_unavailable", False),
                            step=context.steps_taken,
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="ExplainAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["ExplainAgent"] = str(exc)
                        context.explanation_result = []
                        context.ai_unavailable = True
                else:
                    context.budget_exhausted = True
                    context.ai_unavailable = True
                    context.explanation_result = []

            # 6. Repair Agent (strictly bounded by approval; routing influenced by classifier)
            if request_repair and diagnosed_errors:
                if can_step("RepairAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="RepairAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        if approved and approved_code:
                            self._log_event(
                                event="repair_approval",
                                agent_name="RepairAgent",
                                step=context.steps_taken,
                                approval_state="approved",
                            )
                            repair_res = self.repair_agent.apply_and_verify(
                                original_source=source_code,
                                proposed_code=approved_code,
                                approved=True,
                                detector_errors=diagnosed_errors,
                            )
                            context.repair_result = repair_res
                            lat = (time.time() - t0) * 1000.0
                            if repair_res.success:
                                self._log_event(
                                    event="repair_verification",
                                    agent_name="RepairAgent",
                                    latency_ms=lat,
                                    success=True,
                                    step=context.steps_taken,
                                    approval_state="verified",
                                )
                            elif repair_res.rollback_performed:
                                extra_meta = {}
                                if getattr(repair_res, "event_id", None):
                                    extra_meta["event_id"] = repair_res.event_id
                                if getattr(repair_res, "severity", None):
                                    extra_meta["severity"] = repair_res.severity
                                if getattr(repair_res, "action", None):
                                    extra_meta["requested_action"] = repair_res.action
                                if getattr(repair_res, "rejection_outcome", None):
                                    extra_meta["enforcement_outcome"] = repair_res.rejection_outcome
                                self._log_event(
                                    event="repair_rollback",
                                    agent_name="RepairAgent",
                                    latency_ms=lat,
                                    success=False,
                                    fallback=True,
                                    step=context.steps_taken,
                                    approval_state="rollback",
                                    error_summary=repair_res.error,
                                    extra_metadata=extra_meta,
                                )
                            else:
                                extra_meta = {}
                                if getattr(repair_res, "rejection_outcome", None):
                                    extra_meta["enforcement_outcome"] = repair_res.rejection_outcome
                                self._log_event(
                                    event="repair_rejection",
                                    agent_name="RepairAgent",
                                    latency_ms=lat,
                                    success=False,
                                    step=context.steps_taken,
                                    approval_state="failed",
                                    error_summary=repair_res.error,
                                    extra_metadata=extra_meta,
                                )
                        else:
                            self._log_event(
                                event="repair_proposal",
                                agent_name="RepairAgent",
                                step=context.steps_taken,
                                approval_state="pending",
                            )
                            # Classifier Confidence Routing
                            if context.classifier_abstain:
                                # When classifier abstains, avoid aggressive repair; prefer conservative deterministic repair
                                det_plan = self.repair_agent.create_deterministic_repair_plan(
                                    source_code=source_code,
                                    detector_errors=diagnosed_errors,
                                )
                                det_plan.explanation = f"[Conservative Repair: Classifier abstained] {det_plan.explanation}"
                                context.repair_plan = det_plan
                            else:
                                plan = self.repair_agent.propose_repair(
                                    source_code=source_code,
                                    detector_errors=diagnosed_errors,
                                    timeout_seconds=child_timeout(),
                                )
                                if plan.ai_unavailable or not plan.success:
                                    det_plan = self.repair_agent.create_deterministic_repair_plan(
                                        source_code=source_code,
                                        detector_errors=diagnosed_errors,
                                    )
                                    context.repair_plan = det_plan
                                    if plan.ai_unavailable:
                                        context.ai_unavailable = True
                                else:
                                    if context.classifier_disagreement:
                                        # Clamp confidence and note conservative routing due to disagreement
                                        plan.confidence = min(plan.confidence, 0.6)
                                        disagree_note = f"[Conservative Repair: Classifier disagreed ({context.classifier_result.get('label')} vs {rf_label})]"
                                        plan.explanation = f"{disagree_note} {plan.explanation}"
                                    context.repair_plan = plan

                            lat = (time.time() - t0) * 1000.0
                            self._log_event(
                                event="agent_success",
                                agent_name="RepairAgent",
                                latency_ms=lat,
                                success=context.repair_plan.success,
                                step=context.steps_taken,
                                approval_state="pending",
                            )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="RepairAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["RepairAgent"] = str(exc)
                        context.repair_plan = RepairPlan(
                            success=False,
                            explanation=f"Repair proposal failed: {str(exc)}",
                            requires_approval=True,
                            confidence=0.0,
                            ai_unavailable=True,
                        )
                else:
                    context.budget_exhausted = True
                    context.ai_unavailable = True
                    context.repair_plan = RepairPlan(
                        success=False,
                        explanation="Time budget exhausted before repair could complete.",
                        requires_approval=True,
                        confidence=0.0,
                        ai_unavailable=True,
                    )

        # ======================================================================
        # STATIC FLAG-BASED PIPELINE (adaptive_diagnose=False, for backward compatibility)
        # ======================================================================
        else:
            # 0a. Lexer Agent
            if request_lexer:
                if can_step("LexerAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="LexerAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        lexer_res = self.lexer_agent.analyze(LexerRequest(source_code=source_code))
                        context.lexer_result = lexer_res
                        context.tokens = lexer_res.tokens or lexer_res.recovered_tokens or []
                        self._log_event(
                            event="agent_success",
                            agent_name="LexerAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=lexer_res.success,
                            step=context.steps_taken,
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="LexerAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["LexerAgent"] = str(exc)
                        context.lexer_result = LexerAnalysis(
                            success=False,
                            tokens=[],
                            errors=[{"type": "LEXER_FAILURE", "message": str(exc)}],
                            explanation=f"Lexer analysis failed: {str(exc)}",
                        )
                else:
                    context.budget_exhausted = True
                    context.lexer_result = LexerAnalysis(
                        success=False,
                        tokens=[],
                        errors=[{"type": "TIMEOUT", "message": "Time budget exhausted"}],
                        explanation="Time budget exhausted before lexer analysis could run.",
                    )

            # 0b. Parser Agent
            if request_parser:
                if can_step("ParserAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="ParserAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        tokens_to_pass = context.tokens if context.tokens else None
                        parser_res = self.parser_agent.analyze(
                            ParserRequest(source_code=source_code, tokens=tokens_to_pass)
                        )
                        context.parser_result = parser_res
                        context.root_cause_errors = parser_res.root_cause_errors
                        context.cascade_errors = parser_res.cascade_errors
                        context.ast_node_count = parser_res.ast_node_count
                        self._log_event(
                            event="agent_success",
                            agent_name="ParserAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=parser_res.success,
                            step=context.steps_taken,
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="ParserAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["ParserAgent"] = str(exc)
                        context.parser_result = ParserAnalysis(
                            success=False,
                            errors=[{"type": "PARSER_FAILURE", "message": str(exc)}],
                            explanation=f"Parser analysis failed: {str(exc)}",
                        )
                else:
                    context.budget_exhausted = True
                    context.parser_result = ParserAnalysis(
                        success=False,
                        errors=[{"type": "TIMEOUT", "message": "Time budget exhausted"}],
                        explanation="Time budget exhausted before parser analysis could run.",
                    )

            # 0c. Feature Agent
            if request_feature:
                if can_step("FeatureAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="FeatureAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        feature_res = self.feature_agent.analyze(FeatureRequest(source_code=source_code))
                        context.feature_result = feature_res
                        context.feature_vector = feature_res.feature_vector
                        context.features = feature_res.features
                        self._log_event(
                            event="agent_success",
                            agent_name="FeatureAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=feature_res.success,
                            step=context.steps_taken,
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="FeatureAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["FeatureAgent"] = str(exc)
                        context.feature_result = FeatureAnalysis(
                            success=False,
                            drift_detected=True,
                            drift_details=[DriftDetail(drift_type="error", message=str(exc), severity="critical")],
                            explanation=f"Feature analysis failed: {str(exc)}",
                        )
                else:
                    context.budget_exhausted = True
                    context.feature_result = FeatureAnalysis(
                        success=False,
                        drift_detected=True,
                        drift_details=[DriftDetail(drift_type="timeout", message="Time budget exhausted", severity="warning")],
                        explanation="Time budget exhausted before feature analysis could run.",
                    )

            # 1. Explain Agent
            if request_explain and (detector_errors or context.root_cause_errors):
                if can_step("ExplainAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="ExplainAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        errs = context.root_cause_errors if context.root_cause_errors else detector_errors
                        explain_res = self.explain_agent.explain(
                            detector_errors=errs,
                            source_code=source_code,
                            timeout_seconds=child_timeout(),
                        )
                        context.explanation_result = explain_res.get("explanations", [])
                        if explain_res.get("ai_unavailable"):
                            context.ai_unavailable = True
                        self._log_event(
                            event="agent_success",
                            agent_name="ExplainAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=not explain_res.get("ai_unavailable", False),
                            step=context.steps_taken,
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="ExplainAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["ExplainAgent"] = str(exc)
                        context.explanation_result = []
                        context.ai_unavailable = True
                else:
                    context.budget_exhausted = True
                    context.ai_unavailable = True
                    context.explanation_result = []

            # 2. Classifier Agent (runs only when RF confidence is below threshold)
            if self.classifier_agent.should_run(rf_confidence):
                if can_step("ClassifierAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="ClassifierAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        errs = context.root_cause_errors if context.root_cause_errors else detector_errors
                        opinion = self.classifier_agent.classify(
                            source_code=source_code,
                            rf_label=rf_label,
                            rf_confidence=rf_confidence,
                            detector_errors=errs,
                            timeout_seconds=child_timeout(),
                            tokens=context.tokens,
                            lexer_errors=context.lexer_result.errors if context.lexer_result else None,
                            parser_errors=context.parser_result.errors if context.parser_result else None,
                        )
                        context.classifier_result = opinion
                        context.classifier_disagreement = bool(opinion.get("disagreement", False))
                        context.classifier_abstain = bool(opinion.get("abstain", False))
                        if opinion.get("ai_unavailable"):
                            context.ai_unavailable = True
                        self._log_event(
                            event="agent_success",
                            agent_name="ClassifierAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=not opinion.get("ai_unavailable", False),
                            fallback=bool(opinion.get("abstain", False)),
                            step=context.steps_taken,
                            extra_metadata={
                                "disagreement": context.classifier_disagreement,
                                "abstain": context.classifier_abstain,
                            },
                        )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="ClassifierAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
                        context.classifier_result = {
                            "ran": True,
                            "rf_label": rf_label,
                            "rf_confidence": round(effective_conf, 4),
                            "label": rf_label,
                            "confidence_note": f"Classifier failed: {str(exc)}",
                            "abstain": True,
                            "disagreement": False,
                            "ai_unavailable": True,
                        }
                        context.classifier_abstain = True
                        context.ai_unavailable = True
                else:
                    effective_conf = rf_confidence / 100.0 if rf_confidence > 1.0 else rf_confidence
                    context.budget_exhausted = True
                    context.classifier_result = {
                        "ran": True,
                        "rf_label": rf_label,
                        "rf_confidence": round(effective_conf, 4),
                        "label": rf_label,
                        "confidence_note": "Time budget exhausted before classifier second opinion could complete.",
                        "abstain": True,
                        "disagreement": False,
                        "ai_unavailable": True,
                    }
                    context.classifier_abstain = True
                    context.ai_unavailable = True

            # 3. Repair Agent (runs when repair is requested)
            if request_repair and (detector_errors or context.root_cause_errors):
                if can_step("RepairAgent"):
                    context.steps_taken += 1
                    self._log_event(event="agent_invocation", agent_name="RepairAgent", step=context.steps_taken)
                    t0 = time.time()
                    try:
                        errs = context.root_cause_errors if context.root_cause_errors else detector_errors
                        if approved and approved_code:
                            self._log_event(
                                event="repair_approval",
                                agent_name="RepairAgent",
                                step=context.steps_taken,
                                approval_state="approved",
                            )
                            repair_res = self.repair_agent.apply_and_verify(
                                original_source=source_code,
                                proposed_code=approved_code,
                                approved=True,
                                detector_errors=errs,
                            )
                            context.repair_result = repair_res
                            lat = (time.time() - t0) * 1000.0
                            if repair_res.success:
                                self._log_event(
                                    event="repair_verification",
                                    agent_name="RepairAgent",
                                    latency_ms=lat,
                                    success=True,
                                    step=context.steps_taken,
                                    approval_state="verified",
                                )
                            elif repair_res.rollback_performed:
                                extra_meta = {}
                                if getattr(repair_res, "event_id", None):
                                    extra_meta["event_id"] = repair_res.event_id
                                if getattr(repair_res, "severity", None):
                                    extra_meta["severity"] = repair_res.severity
                                if getattr(repair_res, "action", None):
                                    extra_meta["requested_action"] = repair_res.action
                                if getattr(repair_res, "rejection_outcome", None):
                                    extra_meta["enforcement_outcome"] = repair_res.rejection_outcome
                                self._log_event(
                                    event="repair_rollback",
                                    agent_name="RepairAgent",
                                    latency_ms=lat,
                                    success=False,
                                    fallback=True,
                                    step=context.steps_taken,
                                    approval_state="rollback",
                                    error_summary=repair_res.error,
                                    extra_metadata=extra_meta,
                                )
                            else:
                                extra_meta = {}
                                if getattr(repair_res, "rejection_outcome", None):
                                    extra_meta["enforcement_outcome"] = repair_res.rejection_outcome
                                self._log_event(
                                    event="repair_rejection",
                                    agent_name="RepairAgent",
                                    latency_ms=lat,
                                    success=False,
                                    step=context.steps_taken,
                                    approval_state="failed",
                                    error_summary=repair_res.error,
                                    extra_metadata=extra_meta,
                                )
                        else:
                            self._log_event(
                                event="repair_proposal",
                                agent_name="RepairAgent",
                                step=context.steps_taken,
                                approval_state="pending",
                            )
                            # Classifier Confidence Routing
                            if context.classifier_abstain:
                                det_plan = self.repair_agent.create_deterministic_repair_plan(
                                    source_code=source_code,
                                    detector_errors=errs,
                                )
                                det_plan.explanation = f"[Conservative Repair: Classifier abstained] {det_plan.explanation}"
                                context.repair_plan = det_plan
                            else:
                                plan = self.repair_agent.propose_repair(
                                    source_code=source_code,
                                    detector_errors=errs,
                                    timeout_seconds=child_timeout(),
                                )
                                if plan.ai_unavailable or not plan.success:
                                    det_plan = self.repair_agent.create_deterministic_repair_plan(
                                        source_code=source_code,
                                        detector_errors=errs,
                                    )
                                    context.repair_plan = det_plan
                                    if plan.ai_unavailable:
                                        context.ai_unavailable = True
                                else:
                                    if context.classifier_disagreement:
                                        plan.confidence = min(plan.confidence, 0.6)
                                        disagree_note = f"[Conservative Repair: Classifier disagreed ({context.classifier_result.get('label')} vs {rf_label})]"
                                        plan.explanation = f"{disagree_note} {plan.explanation}"
                                    context.repair_plan = plan

                            lat = (time.time() - t0) * 1000.0
                            self._log_event(
                                event="agent_success",
                                agent_name="RepairAgent",
                                latency_ms=lat,
                                success=context.repair_plan.success,
                                step=context.steps_taken,
                                approval_state="pending",
                            )
                    except Exception as exc:
                        self._log_event(
                            event="agent_failure",
                            agent_name="RepairAgent",
                            latency_ms=(time.time() - t0) * 1000.0,
                            success=False,
                            fallback=True,
                            error_category=type(exc).__name__,
                            error_summary=str(exc),
                            step=context.steps_taken,
                        )
                        context.agent_errors["RepairAgent"] = str(exc)
                        context.repair_plan = RepairPlan(
                            success=False,
                            explanation=f"Repair proposal failed: {str(exc)}",
                            requires_approval=True,
                            confidence=0.0,
                            ai_unavailable=True,
                        )
                else:
                    context.budget_exhausted = True
                    context.ai_unavailable = True
                    context.repair_plan = RepairPlan(
                        success=False,
                        explanation="Time budget exhausted before repair could complete.",
                        requires_approval=True,
                        confidence=0.0,
                        ai_unavailable=True,
                    )

        # Ensure validated_diagnostics is synthesized if not already done
        if not context.validated_diagnostics:
            self._synthesize_validated_diagnostics(
                context=context,
                detector_errors=detector_errors,
                rf_label=rf_label,
                rf_confidence=rf_confidence,
                source_code=source_code,
            )

        # ======================================================================
        # PHASE 9: ORCHESTRATOR-LEVEL REFLECTION & CONSISTENCY CHECK
        # ======================================================================
        reflection_issues = self.reflect_and_verify_consistency(context, detector_errors)
        context.reflection_issues = reflection_issues
        if any(iss.get("severity") in ("warning", "critical") for iss in reflection_issues):
            context.requires_review = True

        context.elapsed_seconds = round(time.time() - start_time, 3)
        self._log_event(
            event="session_completion",
            agent_name="Orchestrator",
            latency_ms=context.elapsed_seconds * 1000.0,
            success=not context.budget_exhausted,
            step=context.steps_taken,
            extra_metadata={
                "steps_taken": context.steps_taken,
                "requires_review": context.requires_review,
                "issues_count": len(context.reflection_issues),
            },
        )

        combined_result: Dict[str, Any] = {
            "lexer_analysis": _dump_or_dict(context.lexer_result),
            "parser_analysis": _dump_or_dict(context.parser_result),
            "feature_analysis": _dump_or_dict(context.feature_result),
            "explanations": context.explanation_result or [],
            "classifier_opinion": context.classifier_result,
            "validated_diagnostics": context.validated_diagnostics,
            "primary_rf": context.primary_rf,
            "secondary_review": context.secondary_review,
            "disagreement": context.classifier_disagreement,
            "abstain": context.classifier_abstain,
            "repair_plan": _dump_or_dict(context.repair_plan),
            "repair_result": _dump_or_dict(context.repair_result),
            "ai_unavailable": context.ai_unavailable,
            "budget_exhausted": context.budget_exhausted,
            "elapsed_seconds": context.elapsed_seconds,
            "steps_taken": context.steps_taken,
            "max_steps": context.max_steps,
            "total_agents": context.total_agents,
            "agents_executed": context.steps_taken,
            "reflection_issues": context.reflection_issues,
            "requires_review": context.requires_review,
            "orchestration_context": context.model_dump(),
        }
        return combined_result

    def propose_repair(
        self,
        source_code: str,
        detector_errors: List[Dict[str, Any]],
        timeout_seconds: float = 10.0,
    ) -> Dict[str, Any]:
        """Direct helper to propose a repair with deterministic fallback."""
        start_t = time.time()
        self._log_event(
            event="repair_proposal",
            agent_name="Orchestrator",
            approval_state="pending",
        )
        try:
            plan = self.repair_agent.propose_repair(
                source_code=source_code,
                detector_errors=detector_errors,
                timeout_seconds=timeout_seconds,
            )
            if plan.ai_unavailable or not plan.success:
                det_plan = self.repair_agent.create_deterministic_repair_plan(
                    source_code=source_code,
                    detector_errors=detector_errors,
                )
                self._log_event(
                    event="repair_proposal_deterministic",
                    agent_name="RepairAgent",
                    latency_ms=(time.time() - start_t) * 1000.0,
                    success=det_plan.success,
                    fallback=True,
                    approval_state="pending",
                )
                return det_plan.model_dump()

            self._log_event(
                event="repair_proposal_ai",
                agent_name="RepairAgent",
                latency_ms=(time.time() - start_t) * 1000.0,
                success=True,
                approval_state="pending",
            )
            return plan.model_dump()
        except Exception as exc:
            self._log_event(
                event="repair_proposal_failure",
                agent_name="RepairAgent",
                latency_ms=(time.time() - start_t) * 1000.0,
                success=False,
                fallback=True,
                error_category=type(exc).__name__,
                error_summary=str(exc),
                approval_state="pending",
            )
            det_plan = self.repair_agent.create_deterministic_repair_plan(
                source_code=source_code,
                detector_errors=detector_errors,
            )
            return det_plan.model_dump()

    def apply_and_verify_repair(
        self,
        original_source: str,
        proposed_code: str,
        approved: bool = False,
        detector_errors: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Direct helper to apply and verify a proposed repair under explicit approval."""
        start_t = time.time()
        if not approved:
            self._log_event(
                event="repair_rejection",
                agent_name="RepairAgent",
                success=False,
                approval_state="rejected",
                error_summary="Explicit human approval is required before applying any repair.",
            )
            res = self.repair_agent.apply_and_verify(
                original_source=original_source,
                proposed_code=proposed_code,
                approved=False,
                detector_errors=detector_errors,
            )
            return res.model_dump()

        self._log_event(
            event="repair_approval",
            agent_name="RepairAgent",
            success=True,
            approval_state="approved",
        )
        try:
            res = self.repair_agent.apply_and_verify(
                original_source=original_source,
                proposed_code=proposed_code,
                approved=True,
                detector_errors=detector_errors,
            )
            latency_ms = (time.time() - start_t) * 1000.0
            if res.success:
                self._log_event(
                    event="repair_verification",
                    agent_name="RepairAgent",
                    latency_ms=latency_ms,
                    success=True,
                    approval_state="verified",
                )
            elif res.rollback_performed:
                self._log_event(
                    event="repair_rollback",
                    agent_name="RepairAgent",
                    latency_ms=latency_ms,
                    success=False,
                    fallback=True,
                    approval_state="rollback",
                    error_summary=res.error or "Verification failed; rolled back",
                )
            else:
                self._log_event(
                    event="repair_verification_failed",
                    agent_name="RepairAgent",
                    latency_ms=latency_ms,
                    success=False,
                    approval_state="failed",
                    error_summary=res.error or "Verification failed",
                )
            return res.model_dump()
        except Exception as exc:
            self._log_event(
                event="repair_rollback",
                agent_name="RepairAgent",
                latency_ms=(time.time() - start_t) * 1000.0,
                success=False,
                fallback=True,
                approval_state="rollback",
                error_category=type(exc).__name__,
                error_summary=str(exc),
            )
            return RepairResult(
                success=False,
                proposed_code=original_source,
                patch=None,
                verification_status="rollback",
                compile_output=f"Exception during verification: {str(exc)}",
                rollback_performed=True,
                error=str(exc),
                confidence=0.0,
            ).model_dump()

    def analyze_lexer(
        self,
        source_code: str,
        max_retries: int = 1,
    ) -> LexerAnalysis:
        """Direct helper to run Lexer Agent analysis and recovery."""
        return self.lexer_agent.analyze(
            LexerRequest(source_code=source_code, max_retries=max_retries)
        )

    def analyze_parser(
        self,
        source_code: str,
        tokens: Optional[List[Dict[str, Any]]] = None,
        max_retries: int = 1,
    ) -> ParserAnalysis:
        """Direct helper to run Parser Agent analysis, root-cause diagnosis, and reparsing."""
        return self.parser_agent.analyze(
            ParserRequest(source_code=source_code, tokens=tokens, max_retries=max_retries)
        )

    def analyze_features(
        self,
        source_code: str,
        baseline_features: Optional[Dict[str, Any]] = None,
        request_drift_check: bool = True,
        request_new_feature_analysis: bool = True,
        request_synthetic_data: bool = False,
        synthetic_count: int = 3,
        synthetic_seed: Optional[int] = 42,
    ) -> FeatureAnalysis:
        """Direct helper to run Feature Agent analysis, drift verification, and feature proposals."""
        return self.feature_agent.analyze(
            FeatureRequest(
                source_code=source_code,
                baseline_features=baseline_features,
                request_drift_check=request_drift_check,
                request_new_feature_analysis=request_new_feature_analysis,
                request_synthetic_data=request_synthetic_data,
                synthetic_count=synthetic_count,
                synthetic_seed=synthetic_seed,
            )
        )

    def route_task(self, task_payload: Dict[str, Any]) -> Any:
        """Routes structured task dictionary requests to the appropriate agent.
        
        Example task_payload:
            {"task": "lexer_analysis", "source_code": "..."}
            {"task": "parser_analysis", "source_code": "..."}
            {"task": "feature_analysis", "source_code": "..."}
            {"task": "explain", "detector_errors": [...], "source_code": "..."}
            {"task": "classify", "source_code": "...", "rf_label": "...", "rf_confidence": 45.0}
            {"task": "propose_repair", "source_code": "...", "detector_errors": [...]}
            {"task": "apply_and_verify_repair", "original_source": "...", "proposed_code": "...", "approved": True}
        """
        task = task_payload.get("task", "")
        self._log_event(
            event="task_routing",
            step=1,
            extra_metadata={"task_name": task},
        )

        if task == "lexer_analysis":
            source_code = task_payload.get("source_code", "")
            max_retries = int(task_payload.get("max_retries", 1))
            return self.analyze_lexer(source_code=source_code, max_retries=max_retries)

        if task == "parser_analysis":
            source_code = task_payload.get("source_code", "")
            tokens = task_payload.get("tokens")
            max_retries = int(task_payload.get("max_retries", 1))
            return self.analyze_parser(source_code=source_code, tokens=tokens, max_retries=max_retries)

        if task == "feature_analysis":
            source_code = task_payload.get("source_code", "")
            baseline_features = task_payload.get("baseline_features")
            request_drift_check = bool(task_payload.get("request_drift_check", True))
            request_new_feature_analysis = bool(task_payload.get("request_new_feature_analysis", True))
            request_synthetic_data = bool(task_payload.get("request_synthetic_data", False))
            synthetic_count = int(task_payload.get("synthetic_count", 3))
            synthetic_seed = task_payload.get("synthetic_seed", 42)
            return self.analyze_features(
                source_code=source_code,
                baseline_features=baseline_features,
                request_drift_check=request_drift_check,
                request_new_feature_analysis=request_new_feature_analysis,
                request_synthetic_data=request_synthetic_data,
                synthetic_count=synthetic_count,
                synthetic_seed=synthetic_seed,
            )

        if task == "explain":
            source_code = task_payload.get("source_code", "")
            detector_errors = task_payload.get("detector_errors") or task_payload.get("errors") or []
            timeout_seconds = float(task_payload.get("timeout_seconds", 10.0))
            return self.explain_agent.explain(
                detector_errors=detector_errors,
                source_code=source_code,
                timeout_seconds=timeout_seconds,
            )

        if task == "classify":
            source_code = task_payload.get("source_code", "")
            rf_label = task_payload.get("rf_label", "UNKNOWN")
            rf_confidence = float(task_payload.get("rf_confidence", 50.0))
            detector_errors = task_payload.get("detector_errors") or task_payload.get("errors")
            timeout_seconds = float(task_payload.get("timeout_seconds", 10.0))
            return self.classifier_agent.classify(
                source_code=source_code,
                rf_label=rf_label,
                rf_confidence=rf_confidence,
                detector_errors=detector_errors,
                timeout_seconds=timeout_seconds,
            )

        if task == "propose_repair":
            source_code = task_payload.get("source_code", "")
            detector_errors = task_payload.get("detector_errors") or task_payload.get("errors") or []
            return self.propose_repair(
                source_code=source_code,
                detector_errors=detector_errors,
            )

        if task == "apply_and_verify_repair":
            original_source = task_payload.get("original_source") or task_payload.get("source_code", "")
            proposed_code = task_payload.get("proposed_code", "")
            approved = bool(task_payload.get("approved", False))
            detector_errors = task_payload.get("detector_errors") or task_payload.get("errors")
            return self.apply_and_verify_repair(
                original_source=original_source,
                proposed_code=proposed_code,
                approved=approved,
                detector_errors=detector_errors,
            )

        self._log_event(
            event="task_routing_failure",
            success=False,
            fallback=True,
            error_category="ValueError",
            error_summary=f"Unsupported task: '{task}'",
        )
        raise ValueError(f"Unsupported task: '{task}'")

    def execute_task(self, task_payload: Dict[str, Any]) -> Any:
        """Alias for route_task to execute conceptual task requests."""
        return self.route_task(task_payload)
