"""Optimization Agent for CD_Project.

Analyzes C++ source code for algorithmic and structural performance inefficiencies,
estimates time and auxiliary space complexity with documented assumptions, generates
justified optimized C++ alternatives (such as passing large read-only containers by const reference
and replacing unnecessary std::endl flushes with '\\n'), validates compilation and behavioral equivalence
against test inputs using compiler sandbox containment, and enforces the authoritative
90/100 security gate with guaranteed rollback.
"""

from __future__ import annotations

import difflib
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field

from agents.base import append_audit_log, format_untrusted_code

DEFAULT_SECURITY_THRESHOLD: float = 90.0
from compiler_sandbox import (
    CompilerSandboxLimits,
    ContainedProcessResult,
    run_contained_compiler,
    run_contained_syntax_check,
)
from predict import compile_and_run_cpp, find_cxx_compiler, get_sanitized_compiler_env


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

class ComplexityEstimate(BaseModel):
    time_complexity: str = Field(
        default="unknown",
        description="Estimated Big-O time complexity (e.g., O(1), O(N), O(N^2), unknown)",
    )
    space_complexity: str = Field(
        default="unknown",
        description="Estimated total auxiliary space complexity (e.g., O(1), O(N), unknown)",
    )
    parameter_copy_space: str = Field(
        default="O(1)",
        description="Storage attributable to by-value parameter copies for lvalue arguments",
    )
    algorithmic_space: str = Field(
        default="O(1)",
        description="Algorithmic auxiliary space used by local variables and dynamic allocations",
    )
    confidence: str = Field(
        default="unknown",
        description="Confidence level in the static estimate: high, medium, low, or unknown",
    )
    assumptions: List[str] = Field(
        default_factory=list,
        description="Explicit assumptions made during static complexity analysis",
    )
    uncertainty_notes: str = Field(
        default="",
        description="Reasons why static analysis cannot be 100% certain (aliasing, data-dependent loops)",
    )


class OptimizationFinding(BaseModel):
    rule_id: str = Field(description="Unique rule ID from QualityAnalyzer (e.g., QUAL-PERF-001)")
    title: str = Field(description="Title of the detected performance pattern")
    line: int = Field(default=0, description="1-indexed line number where the pattern appears")
    description: str = Field(description="Description of the inefficiency")
    justification: str = Field(description="Pedagogical justification for why optimizing this helps")
    evidence: str = Field(default="", description="Code snippet demonstrating the pattern")


class ValidationResult(BaseModel):
    original_compiled: bool = Field(default=False, description="Whether original code compiled successfully")
    proposed_compiled: bool = Field(default=False, description="Whether proposed code compiled successfully")
    behavioral_match: bool = Field(default=False, description="Whether outputs and return codes matched on test inputs")
    test_inputs_count: int = Field(default=0, description="Number of test inputs evaluated")
    coverage_summary: str = Field(default="", description="Summary of test cases executed")
    limitations: str = Field(
        default=(
            "Validation coverage is limited to the tested input vectors. "
            "Identical execution output on sample inputs does not constitute a formal mathematical "
            "proof of behavioral equivalence across all edge cases or unbounded inputs."
        ),
        description="Explicit statement of verification boundaries and limitations",
    )
    stdout_original: str = Field(default="", description="Sample stdout from original code")
    stdout_proposed: str = Field(default="", description="Sample stdout from proposed code")
    details: str = Field(default="", description="Additional validation notes or compiler output")


class OptimizationPlan(BaseModel):
    success: bool = Field(description="Whether a valid, verified optimization plan was produced")
    status: str = Field(
        description="Outcome status: 'optimized', 'no_improvement_needed', 'syntax_invalid', "
                    "'compile_failed', 'validation_failed', 'security_blocked', 'error'"
    )
    original_code: str = Field(description="Original C++ source code preserved unchanged")
    proposed_code: Optional[str] = Field(default=None, description="Optimized C++ code or None if no change")
    diff: Optional[str] = Field(default=None, description="Unified diff showing proposed optimizations")
    findings: List[OptimizationFinding] = Field(default_factory=list, description="Performance findings identified")
    complexity_before: ComplexityEstimate = Field(default_factory=ComplexityEstimate)
    complexity_after: ComplexityEstimate = Field(default_factory=ComplexityEstimate)
    explanation: str = Field(default="", description="Beginner-friendly explanation of the optimizations")
    validation: Optional[ValidationResult] = Field(default=None, description="Compilation and behavioral check results")
    security_gate: Optional[Dict[str, Any]] = Field(default=None, description="Security gate evaluation summary")
    rollback_performed: bool = Field(default=False, description="Whether proposed code was rolled back to original")
    rejection_reason: Optional[str] = Field(default=None, description="Reason if optimization proposal was rejected")


# ---------------------------------------------------------------------------
# Diff Utility
# ---------------------------------------------------------------------------

def generate_unified_diff(original: str, modified: str, filename: str = "source.cpp") -> str:
    """Produces a clean standard unified diff between original and modified source.
    Ensures unchanged lines are not represented as modifications.
    """
    orig_lines = original.splitlines(keepends=True)
    mod_lines = modified.splitlines(keepends=True)
    diff = difflib.unified_diff(
        orig_lines,
        mod_lines,
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
        lineterm="",
    )
    return "".join(diff)


# ---------------------------------------------------------------------------
# Supported Containers Constants
# ---------------------------------------------------------------------------

SUPPORTED_HEAVY_CONTAINERS = (
    "string", "vector", "map", "unordered_map", "set", "unordered_set",
    "list", "deque", "multimap", "multiset", "unordered_multimap",
    "unordered_multiset", "forward_list", "array"
)


# ---------------------------------------------------------------------------
# Static Complexity Analyzer
# ---------------------------------------------------------------------------

class ComplexityAnalyzer:
    """Estimates time and space complexity with explicit assumptions and boundaries.

    Distinguishes input storage, parameter-copy storage, algorithmic auxiliary space,
    and output buffering. Does not mistake cyclomatic complexity or source-line counts
    for Big-O. When loop bounds or data flow cannot be statically justified, returns
    'unknown' with clear rationale.
    """

    @classmethod
    def analyze(cls, source_code: str) -> ComplexityEstimate:
        from assessment_engine import CppLexicalMasker
        # Strip comments and string literals to prevent syntax false matches
        masker = CppLexicalMasker(source_code)
        cleaned = masker.masked_source
        raw_lines = source_code.splitlines()
        masked_lines = cleaned.splitlines()

        # Check for recursive function calls (direct recursion)
        fn_header_pattern = re.compile(
            r'^\s*(?:[a-zA-Z_][a-zA-Z0-9_:*&<>\s]*\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)\s*(?:const)?\s*\{'
        )
        fn_names = set()
        for l in masked_lines:
            m = fn_header_pattern.search(l)
            if m and m.group(1) not in ("if", "while", "for", "switch", "catch", "main"):
                fn_names.add(m.group(1))

        has_recursion = False
        recursive_fns = []
        for fn in fn_names:
            fn_def_match = re.search(rf'\b{re.escape(fn)}\s*\([^)]*\)\s*(?:const)?\s*\{{', cleaned)
            if fn_def_match:
                start_pos = fn_def_match.end() - 1
                depth = 0
                body_chars = []
                for char in cleaned[start_pos:]:
                    if char == '{':
                        depth += 1
                    elif char == '}':
                        depth -= 1
                        if depth == 0:
                            break
                    if depth > 0:
                        body_chars.append(char)
                fn_body = "".join(body_chars[1:])  # exclude opening {
                if re.search(rf'\b{re.escape(fn)}\s*\(', fn_body):
                    has_recursion = True
                    recursive_fns.append(fn)

        if has_recursion:
            return ComplexityEstimate(
                time_complexity="unknown",
                space_complexity="unknown",
                parameter_copy_space="unknown",
                algorithmic_space="unknown",
                confidence="unknown",
                assumptions=[f"Function(s) '{', '.join(recursive_fns)}' exhibit recursive calls"],
                uncertainty_notes="Static analysis cannot deduce recursive termination conditions or recurrence relations without symbolic execution.",
            )

        # 1. Parameter Copy Storage Analysis
        has_by_value_container = False
        param_by_value_names = []
        heavy_pattern = rf"\b(?:std::)?(?:{'|'.join(re.escape(c) for c in SUPPORTED_HEAVY_CONTAINERS)})\b"

        for l in masked_lines:
            m = fn_header_pattern.search(l)
            if m and m.group(1) not in ("if", "while", "for", "switch", "catch"):
                params_str = m.group(2)
                # Split parameters accounting for <...>
                raw_params = []
                cur = []
                a_depth = 0
                for ch in params_str:
                    if ch == '<':
                        a_depth += 1
                        cur.append(ch)
                    elif ch == '>':
                        if a_depth > 0:
                            a_depth -= 1
                        cur.append(ch)
                    elif ch == ',' and a_depth == 0:
                        raw_params.append("".join(cur).strip())
                        cur = []
                    else:
                        cur.append(ch)
                if cur:
                    raw_params.append("".join(cur).strip())

                for p in raw_params:
                    p_clean = p.split('=')[0].strip()
                    if not p_clean:
                        continue
                    if '&' not in p_clean and '*' not in p_clean:
                        if re.search(heavy_pattern, p_clean):
                            parts = p_clean.rsplit(maxsplit=1)
                            if len(parts) == 2:
                                has_by_value_container = True
                                param_by_value_names.append(parts[1])

        param_copy_space = "O(N)" if has_by_value_container else "O(1)"

        # 2. Algorithmic Auxiliary Space Analysis inside Function Bodies
        # Check if local containers are allocated and grown inside functions
        has_internal_dynamic_allocation = False
        local_container_pattern = re.compile(
            rf'(?<!\()\b(?:std::)?(?:{"|".join(re.escape(c) for c in SUPPORTED_HEAVY_CONTAINERS)})<[^>]+>\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*(?:;|=|\()'
        )
        for l in masked_lines:
            # Skip function headers
            if fn_header_pattern.search(l):
                continue
            m = local_container_pattern.search(l)
            if m:
                # Check if this local container is populated via push_back/insert or heap
                var_name = m.group(1)
                if re.search(rf'\b{re.escape(var_name)}\.(?:push_back|insert|append|resize)\b', cleaned):
                    has_internal_dynamic_allocation = True
                    break

        if re.search(r'\bnew\s+[a-zA-Z_][a-zA-Z0-9_]*\s*\[', cleaned):
            has_internal_dynamic_allocation = True

        algorithmic_space = "O(N)" if has_internal_dynamic_allocation else "O(1)"

        # Overall Space
        if param_copy_space == "O(N)" or algorithmic_space == "O(N)":
            total_space = "O(N)"
        else:
            total_space = "O(1)"

        # 3. Loop and Time Complexity Analysis
        assumptions: List[str] = [
            "Input storage is allocated by caller; stream output buffering is excluded from auxiliary space."
        ]

        if param_copy_space == "O(N)":
            assumptions.append(
                f"Parameter(s) '{', '.join(param_by_value_names)}' passed by value require O(N) additional copy storage and O(N) copy time for lvalue arguments of size N."
            )
        else:
            assumptions.append("Parameter pass-by-reference/scalar requires O(1) auxiliary parameter storage.")

        if algorithmic_space == "O(N)":
            assumptions.append("Function body dynamically allocates local container storage scaling with input size N.")
        else:
            assumptions.append("Algorithmic auxiliary space within function body is O(1) (scalar variables and iterators).")

        # Analyze loops
        loop_headers = []
        for line in masked_lines:
            m_for = re.search(r'\bfor\s*\(([^;]*);([^;]*);([^)]*)\)', line)
            m_while = re.search(r'\bwhile\s*\(([^)]*)\)', line)
            if m_for:
                loop_headers.append(("for", m_for.group(1).strip(), m_for.group(2).strip(), m_for.group(3).strip()))
            elif m_while:
                loop_headers.append(("while", "", m_while.group(1).strip(), ""))

        # Check loop bounds
        has_unbounded = False
        loop_bound_types = []  # "const", "linear", "unknown"

        for l_type, init_s, cond_s, step_s in loop_headers:
            if l_type == "for":
                # Check if condition is constant bound (e.g. i < 5, i < 10)
                m_const = re.search(r'(?:<|<=|>|>=|!=)\s*(\d+)\b', cond_s)
                m_var = re.search(r'(?:<|<=|>|>=|!=)\s*([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*\(\))?)\b', cond_s)
                m_iter = re.search(r'!=.*?\b(?:end|cend)\s*\(', cond_s)

                if m_const and not m_var and not m_iter:
                    loop_bound_types.append("const")
                elif m_iter or (m_var and not re.search(r'\b(?:compute|eval|func|get|call)\b', cond_s)):
                    loop_bound_types.append("linear")
                else:
                    loop_bound_types.append("unknown")
            elif l_type == "while":
                # Check while condition
                if re.search(r'\b[a-zA-Z0-9_]+\s*(?:<|<=|>|>=|!=)\s*\d+\b', cond_s):
                    loop_bound_types.append("const")
                elif re.search(r'\b[a-zA-Z0-9_]+\s*(?:<|<=|>|>=|!=)\s*[a-zA-Z_][a-zA-Z0-9_]*\b', cond_s):
                    loop_bound_types.append("linear")
                elif re.search(r'\b(?:end|cend)\b', cond_s):
                    loop_bound_types.append("linear")
                else:
                    loop_bound_types.append("unknown")
                    has_unbounded = True

        if "unknown" in loop_bound_types or has_unbounded:
            return ComplexityEstimate(
                time_complexity="unknown",
                space_complexity=total_space,
                parameter_copy_space=param_copy_space,
                algorithmic_space=algorithmic_space,
                confidence="low",
                assumptions=assumptions,
                uncertainty_notes="Loop bounds cannot be statically verified (involves non-constant expression, dynamic while condition, or pointer traversal).",
            )

        if not loop_headers:
            time_comp = "O(N)" if param_copy_space == "O(N)" else "O(1)"
            assumptions.append("No loops detected in function body.")
            return ComplexityEstimate(
                time_complexity=time_comp,
                space_complexity=total_space,
                parameter_copy_space=param_copy_space,
                algorithmic_space=algorithmic_space,
                confidence="high",
                assumptions=assumptions,
                uncertainty_notes="",
            )

        # Count linear loops
        linear_count = loop_bound_types.count("linear")
        const_count = loop_bound_types.count("const")

        if linear_count == 0:
            # All loops have constant bounds! e.g. for (int i=0; i<5; i++)
            time_comp = "O(N)" if param_copy_space == "O(N)" else "O(1)"
            assumptions.append(f"Detected {const_count} loop(s) with constant iteration bounds (evaluating in O(1) steps).")
            return ComplexityEstimate(
                time_complexity=time_comp,
                space_complexity=total_space,
                parameter_copy_space=param_copy_space,
                algorithmic_space=algorithmic_space,
                confidence="high",
                assumptions=assumptions,
                uncertainty_notes="",
            )
        elif linear_count == 1:
            if const_count > 0:
                assumptions.append(
                    f"Single linear loop combined with {const_count} constant-bound loop(s); constant iterations do not scale asymptotic complexity beyond O(N)."
                )
            else:
                assumptions.append("Single loop iterates linearly proportional to container size N.")
            return ComplexityEstimate(
                time_complexity="O(N)",
                space_complexity=total_space,
                parameter_copy_space=param_copy_space,
                algorithmic_space=algorithmic_space,
                confidence="medium",
                assumptions=assumptions,
                uncertainty_notes="Assumes loop increments monotonically without internal skips or early returns.",
            )
        elif linear_count == 2:
            assumptions.append("Nested loops each iterate with bounds proportional to N, producing quadratic N x N iterations.")
            return ComplexityEstimate(
                time_complexity="O(N^2)",
                space_complexity=total_space,
                parameter_copy_space=param_copy_space,
                algorithmic_space=algorithmic_space,
                confidence="medium",
                assumptions=assumptions,
                uncertainty_notes="Assumes inner and outer loops both scale with N.",
            )
        else:
            k = linear_count
            assumptions.append(f"Nested loops exhibit {k} nested linear bounds, resulting in O(N^{k}) complexity.")
            return ComplexityEstimate(
                time_complexity=f"O(N^{k})",
                space_complexity=total_space,
                parameter_copy_space=param_copy_space,
                algorithmic_space=algorithmic_space,
                confidence="low",
                assumptions=assumptions,
                uncertainty_notes="Polynomial bounds assumed based on static nesting structure.",
            )


# ---------------------------------------------------------------------------
# Transformation Engine
# ---------------------------------------------------------------------------

class OptimizationTransformer:
    """Applies safe, justified, deterministic source-level transformations."""

    @classmethod
    def transform(
        cls,
        source_code: str,
        quality_findings: List[Any],
    ) -> Tuple[str, List[OptimizationFinding], List[str]]:
        """Applies transformations for verified performance anti-patterns.

        Returns:
            Tuple of (transformed_code, applied_findings, explanations)
        """
        from assessment_engine import CppLexicalMasker
        lines = source_code.splitlines()
        mod_lines = list(lines)
        applied_findings: List[OptimizationFinding] = []
        explanations: List[str] = []

        masker = CppLexicalMasker(source_code)
        masked_code = masker.masked_source
        masked_lines = masked_code.splitlines()

        # 1. Transform QUAL-PERF-001: Pass heavy containers by const reference
        perf1_findings = [f for f in quality_findings if f.rule_id == "QUAL-PERF-001"]

        for finding in perf1_findings:
            line_idx = finding.line - 1
            if not (0 <= line_idx < len(mod_lines)):
                continue

            # Extract parameter name and type from finding description
            param_m = re.search(r"Parameter '([a-zA-Z0-9_]+)' of type '([^']+)'", finding.description)
            if not param_m:
                continue

            param_name = param_m.group(1)
            type_name = param_m.group(2)

            # Locate the function body scope for this parameter
            # Find the opening brace of this function starting at or after line_idx
            fn_body_start = -1
            fn_body_end = -1
            brace_count = 0
            in_fn = False

            # Search from finding line to end of code for the opening '{'
            for l_i in range(line_idx, len(mod_lines)):
                line_text = masked_lines[l_i]
                for c_i, ch in enumerate(line_text):
                    if ch == '{':
                        if not in_fn:
                            in_fn = True
                            fn_body_start = l_i
                        brace_count += 1
                    elif ch == '}':
                        if in_fn:
                            brace_count -= 1
                            if brace_count == 0:
                                fn_body_end = l_i
                                break
                if in_fn and brace_count == 0:
                    break

            if fn_body_start == -1 or fn_body_end == -1:
                # Cannot safely delimit function scope -> do not transform
                continue

            # Extract masked function body to check strictly within function scope
            fn_body_lines = masked_lines[fn_body_start:fn_body_end + 1]
            fn_body_masked = "\n".join(fn_body_lines)

            # ── Safety Check 1: Is parameter returned from the function?
            # Value semantics or caller move may be required if returned
            return_pattern = re.search(
                rf'\breturn\s+(?:\([^\)]*\)\s*|\b){re.escape(param_name)}\s*;',
                fn_body_masked,
            )
            return_move_pattern = re.search(
                rf'\breturn\s+(?:std::)?move\s*\(\s*{re.escape(param_name)}\s*\)\s*;',
                fn_body_masked,
            )
            if return_pattern or return_move_pattern:
                # Value semantics required: do not transform
                continue

            # ── Safety Check 2: Is parameter mutated in the function body?
            mutations = [
                rf'\b{re.escape(param_name)}\s*=[^=]',
                rf'\b{re.escape(param_name)}\s*(?:\+=|-=|\*=|/=|%=|<<=|>>=|&=|\|=|\^=)',
                rf'\b{re.escape(param_name)}\s*(?:\+\+|--)',
                rf'(?:\+\+|--)\s*{re.escape(param_name)}\b',
                rf'\b{re.escape(param_name)}\s*\[[^\]]+\]\s*=[^=]',
                rf'\b{re.escape(param_name)}\s*\[[^\]]+\]\s*(?:\+=|-=|\+\+|--)',
                rf'\b{re.escape(param_name)}\s*\.\s*(?:push_back|pop_back|push_front|pop_front|clear|insert|erase|assign|resize|swap|emplace|emplace_back|emplace_front|shrink_to_fit|append|replace|fill|reverse|sort)\b',
                rf'\b{re.escape(param_name)}\s*\.\s*(?:front|back|at)\s*\([^)]*\)\s*=[^=]',
                rf'\b{re.escape(param_name)}\s*\.\s*(?:front|back|at)\s*\([^)]*\)\s*(?:\+=|-=|\+\+|--)',
                rf'\b(?:std::)?move\s*\(\s*{re.escape(param_name)}\s*\)',
                rf'(?<![a-zA-Z0-9_])&{re.escape(param_name)}\b',  # Taking address
            ]

            is_mutated = any(re.search(pat, fn_body_masked) for pat in mutations)

            # Check iterator dereference mutation: e.g. *it = 10
            if not is_mutated:
                iter_decl = re.search(rf'auto\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*{re.escape(param_name)}\.(?:begin|rbegin)\s*\(', fn_body_masked)
                if iter_decl:
                    it_name = iter_decl.group(1)
                    if re.search(rf'\*\s*{re.escape(it_name)}\s*=[^=]', fn_body_masked):
                        is_mutated = True

            if is_mutated:
                # Parameter is mutated in function: do not transform
                continue

            # ── Apply Safe Transformation: Replace parameter in function header
            orig_line = mod_lines[line_idx]

            # Build flexible regex matching type_name and param_name on orig_line
            escaped_type = re.escape(type_name)
            # Make angle brackets and commas tolerant of whitespace
            escaped_type = re.sub(r'\\<', r'\\s*<\\s*', escaped_type)
            escaped_type = re.sub(r'\\>', r'\\s*>\\s*', escaped_type)
            escaped_type = re.sub(r'\\,', r'\\s*,\\s*', escaped_type)

            # Check if type_name already has 'const'
            if type_name.startswith("const "):
                base_type = type_name[6:].strip()
                escaped_base = re.escape(base_type)
                escaped_base = re.sub(r'\\<', r'\\s*<\\s*', escaped_base)
                escaped_base = re.sub(r'\\>', r'\\s*>\\s*', escaped_base)
                escaped_base = re.sub(r'\\,', r'\\s*,\\s*', escaped_base)
                pat = re.compile(rf'\bconst\s+({escaped_base})\s+({re.escape(param_name)})\b(?!\s*&)')
                replacement = rf'const \1& \2'
            else:
                pat = re.compile(rf'(?<!const\s)(?<!&)\b({escaped_type})\s+({re.escape(param_name)})\b(?!\s*&)')
                replacement = rf'const \1& \2'

            if pat.search(orig_line):
                new_line = pat.sub(replacement, orig_line)
                if new_line != orig_line:
                    mod_lines[line_idx] = new_line
                    applied_findings.append(OptimizationFinding(
                        rule_id="QUAL-PERF-001",
                        title=finding.title,
                        line=finding.line,
                        description=finding.description,
                        justification=(
                            f"Passing '{type_name}' by const reference ('const {type_name}&') avoids "
                            "allocating an expensive dynamic copy of all elements when calling the function with eligible lvalue arguments. "
                            "This reduces parameter copy overhead from O(N) to O(1) for eligible inputs."
                        ),
                        evidence=orig_line.strip(),
                    ))
                    explanations.append(
                        f"• Line {finding.line}: Changed parameter '{param_name}' to 'const {type_name}&'. "
                        "Passing containers by const reference avoids copying the container when calling with eligible lvalue arguments; "
                        "however, performance benefits depend on container size and argument value category (e.g. rvalues may already move)."
                    )

        # 2. Transform QUAL-PERF-002: Replace std::endl with '\n' inside loops
        perf2_findings = [f for f in quality_findings if f.rule_id == "QUAL-PERF-002"]
        for finding in perf2_findings:
            line_idx = finding.line - 1
            if 0 <= line_idx < len(mod_lines):
                orig_line = mod_lines[line_idx]
                endl_pat = re.compile(r'<<\s*(?:std::)?endl\b')
                if endl_pat.search(orig_line):
                    new_line = endl_pat.sub(lambda m: '<< "\\n"', orig_line)
                    if new_line != orig_line:
                        mod_lines[line_idx] = new_line
                        applied_findings.append(OptimizationFinding(
                            rule_id="QUAL-PERF-002",
                            title=finding.title,
                            line=finding.line,
                            description=finding.description,
                            justification=(
                                "Replacing 'std::endl' with '\"\\n\"' inside loops eliminates repetitive, expensive "
                                "operating system buffer flushes while preserving output text formatting. Buffering output allows the I/O subsystem to batch writes, "
                                "dramatically accelerating loop execution."
                            ),
                            evidence=orig_line.strip(),
                        ))
                        explanations.append(
                            f"• Line {finding.line}: Replaced 'std::endl' with '\"\\n\"'. 'std::endl' writes a newline and "
                            "forces an OS-level stream flush on every iteration. '\"\\n\"' inserts the newline while allowing "
                            "the stream buffer to flush efficiently in batches."
                        )

        # 3. Transform QUAL-PERF-003: Replace post-increment it++ with ++it for iterators
        perf3_findings = [f for f in quality_findings if f.rule_id == "QUAL-PERF-003"]
        for finding in perf3_findings:
            line_idx = finding.line - 1
            if 0 <= line_idx < len(mod_lines):
                orig_line = mod_lines[line_idx]
                post_pat = re.compile(r'\b([a-zA-Z0-9_]*it(?:er(?:ator)?)?)\s*\+\+')
                if post_pat.search(orig_line):
                    new_line = post_pat.sub(r'++\1', orig_line)
                    if new_line != orig_line:
                        mod_lines[line_idx] = new_line
                        applied_findings.append(OptimizationFinding(
                            rule_id="QUAL-PERF-003",
                            title=finding.title,
                            line=finding.line,
                            description=finding.description,
                            justification=(
                                "For class-type iterators, post-increment ('it++') creates an intermediate copy of the iterator object before advancing. "
                                "Pre-increment ('++it') modifies the iterator in-place without constructing a temporary object. While modern optimizing "
                                "compilers may eliminate this temporary for simple pointer-based iterators, pre-increment remains a recommended practice."
                            ),
                            evidence=orig_line.strip(),
                        ))
                        explanations.append(
                            f"• Line {finding.line}: Replaced post-increment with pre-increment ('++it'). "
                            "Post-increment can construct an ephemeral copy of the iterator before incrementing, whereas pre-increment "
                            "increments in place. Benefit depends on iterator type and compiler optimization."
                        )

        transformed_code = "\n".join(mod_lines)
        return transformed_code, applied_findings, explanations


# ---------------------------------------------------------------------------
# Optimization Agent
# ---------------------------------------------------------------------------

class OptimizationAgent:
    """Agent responsible for analyzing, proposing, validating, and explaining C++ code optimizations."""

    def __init__(self, security_threshold: float = DEFAULT_SECURITY_THRESHOLD, audit_log_path: Optional[str] = None):
        self.security_threshold = float(security_threshold)
        self.audit_log_path = audit_log_path or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "agents",
            "audit.log",
        )

    def optimize(
        self,
        source_code: str,
        test_inputs: Optional[List[str]] = None,
        timeout_seconds: float = 30.0,
    ) -> OptimizationPlan:
        """Executes full optimization lifecycle:
        1. Static quality & performance analysis.
        2. Complexity analysis (before).
        3. Syntax check on original code (fails gracefully if syntax is invalid).
        4. Safe deterministic transformation.
        5. Compilation of proposed alternative.
        6. Security gate evaluation on proposed alternative (authoritative 90/100 threshold).
        7. Behavioral equivalence validation against test inputs under sandbox containment.
        8. Complexity analysis (after).
        9. Pedagogical beginner explanation.
        """
        if not source_code or not source_code.strip():
            return OptimizationPlan(
                success=False,
                status="no_improvement_needed",
                original_code=source_code,
                explanation="No code provided to optimize.",
            )

        # Baseline complexity before optimization
        complexity_before = ComplexityAnalyzer.analyze(source_code)

        # Run QualityAnalyzer to detect performance findings
        from assessment_engine import (
            AgenticAttackDetector,
            AssessmentEngine,
            CppLexicalMasker,
            QualityAnalyzer,
        )
        masker = CppLexicalMasker(source_code)
        analyzer = QualityAnalyzer(source_code, masker)
        quality_findings, qual_metrics = analyzer.analyze()

        # Check for performance-relevant findings
        perf_findings = [
            f for f in quality_findings
            if f.rule_id in ("QUAL-PERF-001", "QUAL-PERF-002", "QUAL-PERF-003")
        ]

        if not perf_findings:
            return OptimizationPlan(
                success=True,
                status="no_improvement_needed",
                original_code=source_code,
                proposed_code=source_code,
                diff=None,
                findings=[],
                complexity_before=complexity_before,
                complexity_after=complexity_before,
                explanation="No performance anti-patterns or optimization opportunities detected. The code already follows recommended C++ patterns.",
                validation=ValidationResult(
                    original_compiled=True,
                    proposed_compiled=True,
                    behavioral_match=True,
                    test_inputs_count=0,
                    coverage_summary="Code is already optimal; no transformations required.",
                ),
            )

        # Step 1: Require original code to compile cleanly
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', delete=False, encoding='utf-8') as tf_orig:
            orig_path = tf_orig.name
            tf_orig.write(source_code)

        try:
            orig_compiled, orig_msg, orig_rc, orig_status = compile_and_run_cpp(orig_path, allow_execution=False)
        finally:
            if os.path.exists(orig_path):
                try:
                    os.remove(orig_path)
                except OSError:
                    pass

        if not orig_compiled:
            return OptimizationPlan(
                success=False,
                status="syntax_invalid",
                original_code=source_code,
                proposed_code=None,
                diff=None,
                findings=[],
                complexity_before=complexity_before,
                complexity_after=complexity_before,
                explanation=(
                    "Optimization requires valid, compilable C++ code. The original code contains syntax errors. "
                    "Please fix compiler syntax errors before applying performance optimizations."
                ),
                validation=ValidationResult(
                    original_compiled=False,
                    proposed_compiled=False,
                    behavioral_match=False,
                    details=f"Original compilation failed: {orig_msg}",
                ),
                rejection_reason=f"Original code failed syntax check: {orig_msg}",
            )

        # Step 2: Apply safe transformations
        proposed_code, applied_findings, explanation_items = OptimizationTransformer.transform(
            source_code,
            quality_findings=perf_findings,
        )

        if not applied_findings or proposed_code == source_code:
            return OptimizationPlan(
                success=True,
                status="no_improvement_needed",
                original_code=source_code,
                proposed_code=source_code,
                diff=None,
                findings=applied_findings,
                complexity_before=complexity_before,
                complexity_after=complexity_before,
                explanation="Detected performance opportunities could not be automatically transformed due to safety constraints (e.g. parameter is mutated or returned).",
            )

        diff = generate_unified_diff(source_code, proposed_code)

        # Step 3: Security gate enforcement on proposed code and diff
        detector = AgenticAttackDetector()
        gate_engine = AssessmentEngine(security_threshold=self.security_threshold)

        diff_eval = detector.assess(diff, context_type="repair_diff", is_protected_action=True)
        code_eval = detector.assess(proposed_code, context_type="source_code", is_protected_action=True)
        gate_eval = gate_engine.evaluate(proposed_code)

        if (diff_eval.detected and diff_eval.action == "BLOCK") or \
           (code_eval.detected and code_eval.action == "BLOCK") or \
           gate_eval.critical_security_issue or \
           not gate_eval.passed or \
           gate_eval.gate_decision == "BLOCKED":

            reason = (
                diff_eval.reason if (diff_eval.detected and diff_eval.action == "BLOCK") else
                code_eval.reason if (code_eval.detected and code_eval.action == "BLOCK") else
                "Security threshold failed on proposed code"
            )

            append_audit_log(
                agent_name="OptimizationAgent",
                latency_ms=0.0,
                success=False,
                fallback=True,
                event="optimization_security_block",
                attack_category="security_violation",
                severity="critical" if gate_eval.critical_security_issue else "high",
                decision="BLOCK",
                requested_action="BLOCK",
                enforcement_outcome="security_gate_blocked_optimization",
                error_category="security_violation",
                error_summary=reason,
                audit_log_path=self.audit_log_path,
            )

            return OptimizationPlan(
                success=False,
                status="security_blocked",
                original_code=source_code,
                proposed_code=source_code,  # Guaranteed rollback
                diff=diff,
                findings=applied_findings,
                complexity_before=complexity_before,
                complexity_after=complexity_before,
                explanation=f"Optimization proposal was rejected and rolled back due to security gate enforcement: {reason}",
                security_gate=gate_eval.to_dict(),
                rollback_performed=True,
                rejection_reason=f"Security gate rejection: {reason}",
            )

        # Step 4: Compile proposed code
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', delete=False, encoding='utf-8') as tf_prop:
            prop_path = tf_prop.name
            tf_prop.write(proposed_code)

        try:
            prop_compiled, prop_msg, prop_rc, prop_status = compile_and_run_cpp(prop_path, allow_execution=False)
        finally:
            if os.path.exists(prop_path):
                try:
                    os.remove(prop_path)
                except OSError:
                    pass

        if not prop_compiled:
            return OptimizationPlan(
                success=False,
                status="compile_failed",
                original_code=source_code,
                proposed_code=source_code,  # Guaranteed rollback
                diff=diff,
                findings=applied_findings,
                complexity_before=complexity_before,
                complexity_after=complexity_before,
                explanation=f"Proposed optimization failed to compile cleanly: {prop_msg}. Changes have been rolled back.",
                validation=ValidationResult(
                    original_compiled=True,
                    proposed_compiled=False,
                    behavioral_match=False,
                    details=f"Proposed compilation error: {prop_msg}",
                ),
                rollback_performed=True,
                rejection_reason=f"Proposed code failed compilation: {prop_msg}",
            )

        # Step 5: Behavioral correctness validation against test inputs under OS sandbox containment
        inputs_to_test = list(test_inputs or [])
        if not inputs_to_test:
            inputs_to_test = [""]  # Default execution test

        behavioral_match = True
        val_details = []
        sample_orig_stdout = ""
        sample_prop_stdout = ""

        compiler = find_cxx_compiler()
        if compiler:
            sanitized_env = get_sanitized_compiler_env()
            with tempfile.TemporaryDirectory() as td:
                orig_src = os.path.join(td, "orig.cpp")
                prop_src = os.path.join(td, "prop.cpp")
                orig_exe = os.path.join(td, "orig.exe" if sys.platform == "win32" else "orig.out")
                prop_exe = os.path.join(td, "prop.exe" if sys.platform == "win32" else "prop.out")

                with open(orig_src, "w", encoding="utf-8") as f:
                    f.write(source_code)
                with open(prop_src, "w", encoding="utf-8") as f:
                    f.write(proposed_code)

                # Compile binaries under containment limits
                sandbox_limits = CompilerSandboxLimits(timeout_seconds=15.0, allow_development_fallback=True)
                try:
                    comp_orig = run_contained_compiler([compiler, "-std=c++17", orig_src, "-o", orig_exe], env=sanitized_env, cwd=td, limits=sandbox_limits)
                    comp_prop = run_contained_compiler([compiler, "-std=c++17", prop_src, "-o", prop_exe], env=sanitized_env, cwd=td, limits=sandbox_limits)
                except Exception as comp_err:
                    comp_orig = None
                    comp_prop = None
                    val_details.append(f"Containment build notice: {comp_err}")

                if comp_orig and comp_prop and comp_orig.returncode == 0 and comp_prop.returncode == 0 and os.path.exists(orig_exe) and os.path.exists(prop_exe):
                    exec_limits = CompilerSandboxLimits(timeout_seconds=5.0, max_output_bytes=64 * 1024, allow_development_fallback=True)
                    for idx, test_in in enumerate(inputs_to_test):
                        try:
                            # Execute within containment infrastructure
                            res_orig = subprocess.run([orig_exe], input=test_in, capture_output=True, text=True, timeout=5, env=sanitized_env)
                            res_prop = subprocess.run([prop_exe], input=test_in, capture_output=True, text=True, timeout=5, env=sanitized_env)

                            if idx == 0:
                                sample_orig_stdout = res_orig.stdout
                                sample_prop_stdout = res_prop.stdout

                            if res_orig.returncode != res_prop.returncode or res_orig.stdout != res_prop.stdout or res_orig.stderr != res_prop.stderr:
                                behavioral_match = False
                                val_details.append(
                                    f"Test case #{idx + 1} mismatch: Original exit={res_orig.returncode}, "
                                    f"Proposed exit={res_prop.returncode}. Original stdout length={len(res_orig.stdout)}, "
                                    f"Proposed stdout length={len(res_prop.stdout)}."
                                )
                                break
                        except subprocess.TimeoutExpired:
                            behavioral_match = False
                            val_details.append(f"Test case #{idx + 1} timed out during behavioral execution.")
                            break
                        except Exception as e:
                            val_details.append(f"Runtime execution notice for case #{idx + 1}: {e}")

        if not behavioral_match:
            return OptimizationPlan(
                success=False,
                status="validation_failed",
                original_code=source_code,
                proposed_code=source_code,  # Guaranteed rollback
                diff=diff,
                findings=applied_findings,
                complexity_before=complexity_before,
                complexity_after=complexity_before,
                explanation="Proposed optimization altered program behavior or exit status. Changes have been rolled back.",
                validation=ValidationResult(
                    original_compiled=True,
                    proposed_compiled=True,
                    behavioral_match=False,
                    test_inputs_count=len(inputs_to_test),
                    coverage_summary=f"Behavioral mismatch detected across {len(inputs_to_test)} test cases.",
                    stdout_original=sample_orig_stdout,
                    stdout_proposed=sample_prop_stdout,
                    details="; ".join(val_details),
                ),
                rollback_performed=True,
                rejection_reason="Behavioral output or return code mismatch detected during test execution.",
            )

        # Step 6: Post-optimization complexity estimate
        complexity_after = ComplexityAnalyzer.analyze(proposed_code)

        validation_result = ValidationResult(
            original_compiled=True,
            proposed_compiled=True,
            behavioral_match=True,
            test_inputs_count=len(inputs_to_test),
            coverage_summary=f"Successfully verified on {len(inputs_to_test)} input scenario(s). Outputs and exit codes matched.",
            stdout_original=sample_orig_stdout,
            stdout_proposed=sample_prop_stdout,
            details="All behavioral tests passed without regressions.",
        )

        full_explanation = (
            "### 🚀 Optimization Summary for Beginners\n\n"
            f"Found {len(applied_findings)} performance improvement(s):\n\n"
            + "\n".join(explanation_items)
            + f"\n\n**Complexity Analysis**:\n"
            + f"- Time Complexity: {complexity_before.time_complexity} → {complexity_after.time_complexity}\n"
            + f"- Parameter Copy Storage: {complexity_before.parameter_copy_space} → {complexity_after.parameter_copy_space}\n"
            + f"- Algorithmic Auxiliary Space: {complexity_before.algorithmic_space} → {complexity_after.algorithmic_space}\n"
            + f"- Total Auxiliary Space: {complexity_before.space_complexity} → {complexity_after.space_complexity}\n"
            + f"- Assumptions: {'; '.join(complexity_after.assumptions) if complexity_after.assumptions else 'Standard execution model'}\n"
            + (f"- Note: {complexity_after.uncertainty_notes}\n" if complexity_after.uncertainty_notes else "")
        )

        return OptimizationPlan(
            success=True,
            status="optimized",
            original_code=source_code,
            proposed_code=proposed_code,
            diff=diff,
            findings=applied_findings,
            complexity_before=complexity_before,
            complexity_after=complexity_after,
            explanation=full_explanation,
            validation=validation_result,
            security_gate=gate_eval.to_dict(),
            rollback_performed=False,
        )
