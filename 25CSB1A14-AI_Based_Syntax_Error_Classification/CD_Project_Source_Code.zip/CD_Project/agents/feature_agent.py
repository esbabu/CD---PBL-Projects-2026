"""Feature Agent for CD_Project.

Wraps the existing deterministic AST feature extraction system (ast_features.py)
as its trusted tool layer to provide:
- Deterministic 30-feature vector extraction
- Feature drift monitoring (schema, count, types, ranges, baseline comparison)
- New feature proposal analysis based on AST structural evidence
- Bounded synthetic multi-error training data generation
- Centralized audit logging and strict security guardrails
"""

import math
import numbers
import os
import random
import re
import time
import json
import datetime
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from pydantic import BaseModel, Field

import ast_features
import cpp_parser
import lexer
from agents.base import append_audit_log, format_untrusted_code
from agents.lexer_agent import LexerAgent, LexerRequest
from agents.parser_agent import ParserAgent, ParserRequest

MAX_SOURCE_SIZE_BYTES = int(os.environ.get("MAX_SOURCE_SIZE_BYTES", 2 * 1024 * 1024))  # 2 MB default (configurable)
MAX_SYNTHETIC_SAMPLES = 20          # Strict upper bound on synthetic generation
DEFAULT_SYNTHETIC_COUNT = 3

# Canonical 30 features extracted by ast_features.py in exact training ordering
CANONICAL_FEATURE_NAMES: List[str] = [
    "num_function_decls",
    "num_var_decls",
    "num_assign_exprs",
    "num_array_decls",
    "num_if_stmts",
    "num_else_stmts",
    "num_while_stmts",
    "num_for_stmts",
    "num_return_stmts",
    "num_compound_stmts",
    "num_expr_stmts",
    "total_nodes",
    "max_depth",
    "avg_depth",
    "num_leaf_nodes",
    "error_invalid_assignment",
    "error_unmatched_brace",
    "error_unmatched_paren",
    "error_missing_semicolon",
    "error_invalid_conditional",
    "error_invalid_loop",
    "error_invalid_type",
    "error_invalid_array",
    "error_invalid_func_decl",
    "total_error_nodes",
    "scope_depth_max",
    "has_orphan_else",
    "func_missing_return",
    "assign_in_condition",
    "nested_func_decl",
]


class ProposedFeature(BaseModel):
    """Structured candidate feature suggestion derived from AST evidence."""
    name: str = Field(description="Name of the proposed feature candidate")
    reason: str = Field(description="Rationale explaining what syntactic or structural property this feature captures")
    source: str = Field(description="AST/parser evidence identifying the origin of this feature")
    impact: str = Field(description="Expected impact on downstream classification or error localization")
    requires_retraining: bool = Field(default=True, description="Whether adopting this feature requires retraining the production model")


class DriftDetail(BaseModel):
    """Structured report of an identified feature schema, count, type, or baseline drift."""
    drift_type: str = Field(description="Category of drift: schema_drift, count_drift, type_drift, range_drift, or baseline_comparison")
    feature_name: Optional[str] = Field(default=None, description="Affected feature name if specific to a single column")
    message: str = Field(description="Human-readable explanation of the detected drift condition")
    severity: str = Field(default="warning", description="Severity level: critical, warning, or info")
    expected: Optional[Any] = Field(default=None, description="Expected value, type, count, or range")
    observed: Optional[Any] = Field(default=None, description="Observed value, type, count, or range")


class SyntheticSample(BaseModel):
    """In-memory structured synthetic training sample with extracted AST features."""
    sample_id: str = Field(description="Unique identifier for the synthetic sample")
    mutated_source: str = Field(description="Synthetically mutated C++ source code")
    injected_errors: List[str] = Field(default_factory=list, description="List of injected syntax error types")
    primary_label: str = Field(description="Target classification label or dominant error category")
    error_count: int = Field(description="Number of injected syntax defects")
    features: Dict[str, Any] = Field(default_factory=dict, description="Extracted 30 canonical features from mutated code")
    is_synthetic: bool = Field(default=True, description="Explicit marker ensuring synthetic sample is marked and isolated")


class FeatureRequest(BaseModel):
    """Input request specification for Feature Agent analysis."""
    source_code: str = Field(description="Untrusted C++ source code to analyze")
    baseline_features: Optional[Dict[str, Any]] = Field(default=None, description="Optional baseline or reference feature dict to compare against")
    request_drift_check: bool = Field(default=True, description="Whether to perform feature drift verification")
    request_new_feature_analysis: bool = Field(default=True, description="Whether to analyze AST for candidate new features")
    request_synthetic_data: bool = Field(default=False, description="Whether to generate bounded synthetic training samples")
    synthetic_count: int = Field(default=DEFAULT_SYNTHETIC_COUNT, ge=1, le=MAX_SYNTHETIC_SAMPLES, description="Number of synthetic samples to produce")
    synthetic_seed: Optional[int] = Field(default=42, description="Random seed for reproducible synthetic generation")


class FeatureAnalysis(BaseModel):
    """Structured diagnostic and feature extraction output returned by Feature Agent."""
    success: bool = Field(description="True if feature extraction succeeded without fatal schema or extraction failures")
    features: Dict[str, Any] = Field(default_factory=dict, description="Deterministic 30-feature dictionary extracted from AST")
    feature_vector: List[Union[int, float]] = Field(default_factory=list, description="Ordered feature values matching CANONICAL_FEATURE_NAMES")
    feature_count: int = Field(default=0, description="Total number of extracted features (expected 30)")
    drift_detected: bool = Field(default=False, description="True if any critical or warning drift was detected")
    drift_details: List[DriftDetail] = Field(default_factory=list, description="List of identified drift signals or schema validation findings")
    proposed_features: List[ProposedFeature] = Field(default_factory=list, description="Structured proposals for future AST-derived features")
    synthetic_samples_generated: int = Field(default=0, description="Number of bounded synthetic samples created")
    synthetic_samples: List[SyntheticSample] = Field(default_factory=list, description="In-memory synthetic multi-error training samples")
    explanation: str = Field(default="", description="Summary of extraction, drift, and feature analysis results")
    ai_unavailable: bool = Field(default=False, description="Whether AI-assisted reasoning was unavailable")

    def __getitem__(self, item: str) -> Any:
        try:
            return getattr(self, item)
        except AttributeError:
            raise KeyError(item)

    def get(self, item: str, default: Any = None) -> Any:
        return getattr(self, item, default)


def validate_source_input(source_code: Any, max_bytes: int = MAX_SOURCE_SIZE_BYTES) -> Tuple[bool, Optional[str]]:
    """Validates untrusted source code input against size and structure boundaries."""
    if not isinstance(source_code, str):
        return False, "Source code must be a string."
    if "\0" in source_code:
        return False, "Source code contains forbidden null bytes."
    if len(source_code.encode("utf-8")) > max_bytes:
        return False, f"Source code exceeds maximum allowed size of {max_bytes} bytes."
    return True, None


def load_dataset_baseline_summary(base_dir: Optional[str] = None) -> Optional[Dict[str, Dict[str, float]]]:
    """Loads baseline distribution statistics from features.csv if present.
    
    Returns a dictionary mapping feature name to {min, max, mean, std}.
    Never fabricates statistics if the file cannot be loaded.
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    features_csv = os.path.join(base_dir, "features.csv")
    if not os.path.isfile(features_csv):
        return None

    try:
        import pandas as pd
        df = pd.read_csv(features_csv)
        summary: Dict[str, Dict[str, float]] = {}
        for col in CANONICAL_FEATURE_NAMES:
            if col in df.columns:
                summary[col] = {
                    "min": float(df[col].min()),
                    "max": float(df[col].max()),
                    "mean": float(df[col].mean()),
                    "std": float(df[col].std()) if len(df[col]) > 1 else 0.0,
                }
        return summary
    except Exception:
        return None


# ─── FEATURE DRIFT MONITORING ────────────────────────────────────────────────

def check_feature_drift(
    features: Dict[str, Any],
    baseline_features: Optional[Dict[str, Any]] = None,
    dataset_summary: Optional[Dict[str, Dict[str, float]]] = None,
) -> Tuple[bool, List[DriftDetail]]:
    """Performs structural and schema drift verification on extracted features.
    
    Checks:
    1. Feature schema completeness (all 30 canonical features present)
    2. Feature count validity (exactly 30 features)
    3. Unexpected feature keys
    4. Numeric type integrity (int/float, no NaN or Inf)
    5. Non-negative structural AST bounds (counts must be >= 0)
    6. Direct baseline comparison against user-provided baseline_features
    7. Empirical distribution check if dataset_summary is available
    """
    drift_details: List[DriftDetail] = []
    has_critical_or_warning_drift = False

    # 1. Feature schema completeness
    missing_features = [f for f in CANONICAL_FEATURE_NAMES if f not in features]
    if missing_features:
        has_critical_or_warning_drift = True
        drift_details.append(DriftDetail(
            drift_type="schema_drift",
            message=f"Missing {len(missing_features)} canonical feature(s): {', '.join(missing_features)}",
            severity="critical",
            expected=CANONICAL_FEATURE_NAMES,
            observed=list(features.keys()),
        ))

    # 2. Feature count check
    if len(features) != len(CANONICAL_FEATURE_NAMES):
        has_critical_or_warning_drift = True
        drift_details.append(DriftDetail(
            drift_type="count_drift",
            message=f"Feature count mismatch: expected {len(CANONICAL_FEATURE_NAMES)}, observed {len(features)}",
            severity="critical",
            expected=len(CANONICAL_FEATURE_NAMES),
            observed=len(features),
        ))

    # 3. Unexpected extra features
    extra_features = [f for f in features if f not in CANONICAL_FEATURE_NAMES]
    if extra_features:
        has_critical_or_warning_drift = True
        drift_details.append(DriftDetail(
            drift_type="schema_drift",
            message=f"Unexpected feature(s) outside canonical schema: {', '.join(extra_features)}",
            severity="warning",
            expected="Canonical 30 features only",
            observed=extra_features,
        ))

    # 4. Type and valid numerical bounds
    for fname, fval in features.items():
        if not isinstance(fval, (numbers.Number, int, float)) or isinstance(fval, bool):
            has_critical_or_warning_drift = True
            drift_details.append(DriftDetail(
                drift_type="type_drift",
                feature_name=fname,
                message=f"Feature '{fname}' has invalid non-numeric type {type(fval).__name__}",
                severity="critical",
                expected="int or float",
                observed=str(type(fval).__name__),
            ))
            continue

        if math.isnan(fval) or math.isinf(fval):
            has_critical_or_warning_drift = True
            drift_details.append(DriftDetail(
                drift_type="type_drift",
                feature_name=fname,
                message=f"Feature '{fname}' contains NaN or Inf value",
                severity="critical",
                expected="Finite numerical value",
                observed=str(fval),
            ))
            continue

        # AST structural count bounds (counts must never be negative)
        if fname.startswith("num_") or fname.startswith("error_") or fname in ("total_nodes", "total_error_nodes", "max_depth", "scope_depth_max"):
            if fval < 0:
                has_critical_or_warning_drift = True
                drift_details.append(DriftDetail(
                    drift_type="range_drift",
                    feature_name=fname,
                    message=f"Feature '{fname}' has negative count ({fval})",
                    severity="critical",
                    expected=">= 0",
                    observed=fval,
                ))

    # 5. Direct baseline comparison if supplied by caller
    if baseline_features is not None:
        for fname in CANONICAL_FEATURE_NAMES:
            if fname in baseline_features and fname in features:
                bval = baseline_features[fname]
                cval = features[fname]
                if bval != cval:
                    drift_details.append(DriftDetail(
                        drift_type="baseline_comparison",
                        feature_name=fname,
                        message=f"Shift from baseline for '{fname}': {bval} -> {cval}",
                        severity="info",
                        expected=bval,
                        observed=cval,
                    ))

    # 6. Empirical dataset comparison if available, otherwise report limitation truthfully
    if dataset_summary:
        for fname, stats in dataset_summary.items():
            if fname in features:
                val = float(features[fname])
                fmax = stats["max"]
                # Detect extreme outliers (> 4x max training value if max > 0, or value > 0 when max == 0)
                if fmax > 0 and val > fmax * 5.0:
                    drift_details.append(DriftDetail(
                        drift_type="range_drift",
                        feature_name=fname,
                        message=f"Feature '{fname}' value ({val}) exceeds 5x training maximum ({fmax})",
                        severity="warning",
                        expected=f"[0, {fmax}]",
                        observed=val,
                    ))
    elif baseline_features is None:
        drift_details.append(DriftDetail(
            drift_type="distribution_drift",
            message="Statistical distribution drift not evaluated: no baseline distribution supplied; structural and schema drift verified.",
            severity="info",
        ))

    return has_critical_or_warning_drift, drift_details


# ─── NEW FEATURE CANDIDATE ANALYSIS ──────────────────────────────────────────

def analyze_candidate_features(
    ast_root: Any,
    parse_errors: List[str],
    tokens: List[Dict[str, Any]],
) -> List[ProposedFeature]:
    """Identifies possible additional features genuinely observable in the AST and tokens.
    
    CRITICAL:
    - Does NOT modify the production 30-feature vector.
    - Does NOT alter model input dimensions.
    - Proposed features remain suggestions until explicitly approved and retrained.
    """
    proposals: List[ProposedFeature] = []

    # Collect nodes from AST
    nodes: List[Tuple[Any, int]] = []
    if ast_root:
        nodes = ast_features.collect_nodes(ast_root)

    # 1. OOP Structure: num_class_decls
    class_count = sum(1 for n, _ in nodes if getattr(n, "node_type", "") == "ClassDeclNode")
    proposals.append(ProposedFeature(
        name="num_class_decls",
        reason="Captures object-oriented class/struct encapsulation complexity. Current model only counts function declarations.",
        source=f"AST ClassDeclNode occurrences (observed: {class_count})",
        impact="Improves classification sensitivity for INVALID_CLASS_DECL and class member syntax defects.",
        requires_retraining=True,
    ))

    # 2. Scope Boundaries: num_namespace_decls
    namespace_count = sum(1 for n, _ in nodes if getattr(n, "node_type", "") == "NamespaceDeclNode")
    proposals.append(ProposedFeature(
        name="num_namespace_decls",
        reason="Tracks namespace scope boundary definitions. Namespace syntax errors are currently uncounted as distinct declarations.",
        source=f"AST NamespaceDeclNode occurrences (observed: {namespace_count})",
        impact="Disentangles namespace-level syntax errors from global variable/function declarations.",
        requires_retraining=True,
    ))

    # 3. Branching: num_switch_stmts
    switch_count = sum(1 for n, _ in nodes if getattr(n, "node_type", "") == "SwitchStmtNode")
    proposals.append(ProposedFeature(
        name="num_switch_stmts",
        reason="Quantifies multi-way branching constructs and switch blocks. Current features count if/else/while/for but miss switch statements.",
        source=f"AST SwitchStmtNode occurrences (observed: {switch_count})",
        impact="Directly improves classification of INVALID_SWITCH and missing case labels.",
        requires_retraining=True,
    ))

    # 4. Cyclomatic Complexity Proxy
    decision_nodes = sum(1 for n, _ in nodes if getattr(n, "node_type", "") in ("IfStmtNode", "WhileStmtNode", "ForStmtNode", "SwitchStmtNode", "CaseStmtNode"))
    cyclomatic_proxy = decision_nodes + 1
    proposals.append(ProposedFeature(
        name="cyclomatic_complexity_proxy",
        reason="Provides McCabe cyclomatic complexity proxy measuring branch decision density.",
        source=f"AST decision nodes (If/While/For/Switch/Case + 1 = {cyclomatic_proxy})",
        impact="Offers dense continuous metric reflecting cognitive and structural complexity.",
        requires_retraining=True,
    ))

    # 5. String literal error nodes
    unterminated_str_count = sum(1 for n, _ in nodes if getattr(n, "node_type", "") == "ErrorNode" and getattr(n, "value", "") == "UNTERMINATED_STRING")
    proposals.append(ProposedFeature(
        name="error_unterminated_string_node",
        reason="Explicitly registers unterminated string literal errors identified during parsing.",
        source=f"AST ErrorNode with UNTERMINATED_STRING (observed: {unterminated_str_count})",
        impact="Directly maps to the UNTERMINATED_STRING classification category.",
        requires_retraining=True,
    ))

    # 6. Misplaced keyword error nodes
    misplaced_kw_count = sum(1 for n, _ in nodes if getattr(n, "node_type", "") == "ErrorNode" and getattr(n, "value", "") == "MISPLACED_KEYWORD")
    proposals.append(ProposedFeature(
        name="error_misplaced_keyword_node",
        reason="Identifies C++ reserved keywords appearing in illegal grammatical syntactic positions.",
        source=f"AST ErrorNode with MISPLACED_KEYWORD (observed: {misplaced_kw_count})",
        impact="Directly isolates MISPLACED_KEYWORD defects from generic declaration errors.",
        requires_retraining=True,
    ))

    # 7. AST Branching Factor
    non_leaves = [n for n, _ in nodes if len(getattr(n, "children", [])) > 0]
    avg_branching = round(sum(len(n.children) for n in non_leaves) / len(non_leaves), 4) if non_leaves else 0.0
    proposals.append(ProposedFeature(
        name="ast_branching_factor_avg",
        reason="Measures average branch width per non-leaf AST node, capturing statement density per block.",
        source=f"AST graph topology (observed avg branching: {avg_branching})",
        impact="Differentiates deeply nested narrow cascades from broad multi-expression structures.",
        requires_retraining=True,
    ))

    return proposals


# ─── CONTROLLED MUTATION & SYNTHETIC DATA GENERATION ─────────────────────────

def _mutate_missing_semicolon(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Removes a trailing semicolon from a variable declaration, assignment, or return."""
    chosen_rng = rng if rng is not None else random
    lines = code.splitlines()
    candidate_indices = [
        i for i, line in enumerate(lines)
        if line.strip().endswith(";") and not line.strip().startswith("#")
    ]
    if not candidate_indices:
        return code, False
    target = chosen_rng.choice(candidate_indices)
    lines[target] = lines[target].rstrip()[:-1]
    return "\n".join(lines), True


def _mutate_unmatched_brace(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Removes a closing brace '}' or appends an unclosed opening brace."""
    chosen_rng = rng if rng is not None else random
    close_indices = [m.start() for m in re.finditer(r"\}", code)]
    if close_indices:
        target = chosen_rng.choice(close_indices)
        return code[:target] + code[target + 1:], True
    return code + "\nvoid extra_block() {\n", True


def _mutate_unmatched_paren(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Removes a closing parenthesis ')' from an if, while, for condition or call."""
    chosen_rng = rng if rng is not None else random
    close_indices = [m.start() for m in re.finditer(r"\)", code)]
    if not close_indices:
        return code, False
    target = chosen_rng.choice(close_indices)
    return code[:target] + code[target + 1:], True


def _mutate_invalid_assignment(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Injects a literal onto the left-hand side of an assignment (e.g. 42 = x;)."""
    match = re.search(r"\b([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([^;]+);", code)
    if not match:
        return code, False
    var_name, expr = match.group(1), match.group(2)
    mutated = re.sub(
        r"\b" + re.escape(var_name) + r"\s*=\s*" + re.escape(expr) + r";",
        f"42 = {var_name};",
        code,
        count=1,
    )
    return mutated, True


def _mutate_invalid_conditional(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Removes condition parentheses from an if statement."""
    match = re.search(r"\bif\s*\(([^)]+)\)", code)
    if not match:
        return code, False
    cond_inner = match.group(1)
    mutated = code.replace(f"if ({cond_inner})", f"if {cond_inner}", 1)
    return mutated, True


def _mutate_invalid_type(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Duplicates a type keyword to create an invalid type declaration (e.g. int int x)."""
    match = re.search(r"\b(int|float|double|char|bool)\s+([a-zA-Z_][a-zA-Z0-9_]*)\b", code)
    if not match:
        return code, False
    typ, var = match.group(1), match.group(2)
    mutated = re.sub(
        r"\b" + typ + r"\s+" + var + r"\b",
        f"{typ} {typ} {var}",
        code,
        count=1,
    )
    return mutated, True


def _mutate_invalid_array(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Corrupts an array declaration syntax (e.g. int arr[ = 10;)."""
    match = re.search(r"\b(int|float|char)\s+([a-zA-Z_][a-zA-Z0-9_]*)\[([0-9]*)\]", code)
    if not match:
        return code, False
    typ, var, size = match.group(1), match.group(2), match.group(3)
    mutated = code.replace(f"{typ} {var}[{size}]", f"{typ} {var}[ = {size or 5}", 1)
    return mutated, True


def _mutate_unterminated_string(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Removes the closing quote from a string literal."""
    match = re.search(r'"([^"\n\\]*)"', code)
    if not match:
        return code, False
    full_str = match.group(0)
    unclosed = full_str[:-1]
    return code.replace(full_str, unclosed, 1), True


def _mutate_extra_tokens(code: str, rng: Optional[random.Random] = None) -> Tuple[str, bool]:
    """Injects an extra misplaced token before a semicolon."""
    match = re.search(r"([a-zA-Z0-9_]+);", code)
    if not match:
        return code, False
    sub = match.group(0)
    mutated = code.replace(sub, match.group(1) + " @;", 1)
    return mutated, True


MUTATION_FUNCTIONS = {
    "MISSING_SEMICOLON": _mutate_missing_semicolon,
    "UNMATCHED_BRACE": _mutate_unmatched_brace,
    "UNMATCHED_PARANTHESES": _mutate_unmatched_paren,
    "INVALID_ASSIGNMENT": _mutate_invalid_assignment,
    "INVALID_CONDITIONAL": _mutate_invalid_conditional,
    "INVALID_TYPE": _mutate_invalid_type,
    "INVALID_ARRAY_DECL": _mutate_invalid_array,
    "UNTERMINATED_STRING": _mutate_unterminated_string,
    "EXTRA_TOKENS": _mutate_extra_tokens,
}


def generate_synthetic_samples(
    base_source: str,
    count: int = DEFAULT_SYNTHETIC_COUNT,
    seed: Optional[int] = 42,
) -> List[SyntheticSample]:
    """Generates bounded synthetic single-error and multi-error training samples.
    
    SAFETY & BOUNDS GUARANTEES:
    - Bounded sample count: capped at MAX_SYNTHETIC_SAMPLES
    - Bounded source size: operates strictly on valid source
    - In-memory only: NEVER writes to production dataset or disk
    - Deterministic random seed: reproducible results
    - No code execution: strictly static mutation and AST feature extraction
    """
    bounded_count = max(1, min(count, MAX_SYNTHETIC_SAMPLES))
    rng = random.Random(seed if seed is not None else 42)

    # Use default clean base code if provided source is empty or malformed
    clean_base = base_source.strip()
    if not clean_base or "\0" in clean_base:
        clean_base = (
            "#include <iostream>\n"
            "using namespace std;\n\n"
            "int main() {\n"
            "    int total = 100;\n"
            "    int score = 42;\n"
            "    int arr[10];\n"
            "    if (score > 50) {\n"
            "        cout << \"Pass\" << endl;\n"
            "    }\n"
            "    total = score + 5;\n"
            "    return 0;\n"
            "}\n"
        )

    samples: List[SyntheticSample] = []
    error_types = list(MUTATION_FUNCTIONS.keys())

    for idx in range(bounded_count):
        # Alternate between single-error and multi-error samples
        is_multi = (idx % 2 == 1) or (idx >= 2)
        mutation_count = rng.randint(2, 3) if is_multi else 1
        chosen_types = rng.sample(error_types, k=min(mutation_count, len(error_types)))

        current_code = clean_base
        applied_errors: List[str] = []

        for etype in chosen_types:
            mutator = MUTATION_FUNCTIONS[etype]
            mutated, ok = mutator(current_code, rng=rng)
            if ok:
                current_code = mutated
                applied_errors.append(etype)

        if not applied_errors:
            # Fallback simple missing semicolon mutation
            current_code, _ = _mutate_missing_semicolon(clean_base, rng=rng)
            applied_errors = ["MISSING_SEMICOLON"]

        sample_id = f"synth_{idx+1:03d}_{'multi' if len(applied_errors) > 1 else 'single'}_{applied_errors[0]}"
        primary_label = applied_errors[0]

        # Extract features from mutated code using trusted deterministic pipeline
        toks = lexer.tokenize_source(current_code)
        ast_root, parse_errors = cpp_parser.build_ast(toks)
        extracted = ast_features.extract_features(ast_root, parse_errors)

        samples.append(SyntheticSample(
            sample_id=sample_id,
            mutated_source=current_code,
            injected_errors=applied_errors,
            primary_label=primary_label,
            error_count=len(applied_errors),
            features=extracted,
        ))

    return samples


# ─── FEATURE AGENT ───────────────────────────────────────────────────────────

class FeatureAgent:
    """Agent responsible for feature extraction, drift monitoring, new feature analysis,

    and bounded synthetic multi-error training data generation.
    """

    def __init__(
        self,
        lexer_agent: Optional[LexerAgent] = None,
        parser_agent: Optional[ParserAgent] = None,
        client: Optional[Any] = None,
        base_dir: Optional[str] = None,
    ):
        self.client = client
        self.lexer_agent = lexer_agent or LexerAgent(client=self.client)
        self.parser_agent = parser_agent or ParserAgent(client=self.client)
        self.base_dir = base_dir
        self.dataset_summary = load_dataset_baseline_summary(self.base_dir)

    def analyze(self, request_or_source: Union[FeatureRequest, str]) -> FeatureAnalysis:
        """Main entry point to perform complete feature analysis on C++ source code."""
        start_time = time.time()

        if isinstance(request_or_source, str):
            req = FeatureRequest(source_code=request_or_source)
        else:
            req = request_or_source

        # 1. Input validation & security guardrails
        is_valid, err_msg = validate_source_input(req.source_code)
        if not is_valid:
            latency_ms = (time.time() - start_time) * 1000.0
            append_audit_log(
                agent_name="FeatureAgent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=err_msg,
            )
            return FeatureAnalysis(
                success=False,
                features={},
                feature_vector=[],
                feature_count=0,
                drift_detected=True,
                drift_details=[DriftDetail(
                    drift_type="schema_drift",
                    message=err_msg or "Invalid input",
                    severity="critical",
                )],
                proposed_features=[],
                synthetic_samples_generated=0,
                synthetic_samples=[],
                explanation=f"Feature extraction aborted: {err_msg}",
            )

        # 2. Trusted deterministic pipeline execution:
        # source -> Lexer Agent -> Parser Agent -> AST -> existing ast_features.py
        lexer_res = self.lexer_agent.analyze(LexerRequest(source_code=req.source_code))
        tokens = lexer_res.tokens or []

        # Build AST using deterministic parser
        ast_root, parse_errors = cpp_parser.build_ast(tokens)

        # Extract deterministic 30 features using existing trusted ast_features module
        raw_features = ast_features.extract_features(ast_root, parse_errors)

        # Build ordered feature vector matching exact canonical sequence
        feature_vector = [raw_features.get(col, 0) for col in CANONICAL_FEATURE_NAMES]

        # 3. Drift Analysis
        drift_detected = False
        drift_details: List[DriftDetail] = []
        if req.request_drift_check:
            drift_detected, drift_details = check_feature_drift(
                features=raw_features,
                baseline_features=req.baseline_features,
                dataset_summary=self.dataset_summary,
            )

        # 4. New Feature Candidate Analysis
        proposed_features: List[ProposedFeature] = []
        if req.request_new_feature_analysis:
            proposed_features = analyze_candidate_features(
                ast_root=ast_root,
                parse_errors=parse_errors,
                tokens=tokens,
            )

        # 5. Optional Bounded Synthetic Data Generation
        synthetic_samples: List[SyntheticSample] = []
        if req.request_synthetic_data:
            synthetic_samples = generate_synthetic_samples(
                base_source=req.source_code,
                count=req.synthetic_count,
                seed=req.synthetic_seed,
            )

        latency_ms = (time.time() - start_time) * 1000.0
        append_audit_log(
            agent_name="FeatureAgent",
            latency_ms=latency_ms,
            success=True,
            fallback=False,
        )

        explanation = (
            f"Extracted {len(raw_features)} canonical features from AST. "
            f"Drift status: {'DRIFT DETECTED' if drift_detected else 'NOMINAL'}. "
            f"Identified {len(proposed_features)} candidate feature proposals. "
            f"Generated {len(synthetic_samples)} synthetic training samples."
        )

        return FeatureAnalysis(
            success=True,
            features=raw_features,
            feature_vector=feature_vector,
            feature_count=len(raw_features),
            drift_detected=drift_detected,
            drift_details=drift_details,
            proposed_features=proposed_features,
            synthetic_samples_generated=len(synthetic_samples),
            synthetic_samples=synthetic_samples,
            explanation=explanation,
            ai_unavailable=False,
        )


def stage_retraining_request(
    reason: str,
    drift_details: Optional[List[DriftDetail]] = None,
    proposed_features: Optional[List[ProposedFeature]] = None,
    synthetic_samples: Optional[List[SyntheticSample]] = None,
    base_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Stages an offline retraining recommendation ticket under models/retraining_requests/.

    SECURITY GUARANTEES:
    - Never triggers automatic production model replacement or automatic retraining.
    - Requires explicit offline human or pipeline authorization to initiate training.
    - All synthetic samples are explicitly isolated and marked as unreviewed candidates.
    """
    root_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    req_dir = os.path.join(root_dir, "models", "retraining_requests")
    os.makedirs(req_dir, exist_ok=True)

    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S")
    req_id = f"retrain_req_{timestamp}"
    req_path = os.path.join(req_dir, f"{req_id}.json")

    ticket = {
        "request_id": req_id,
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "reason": reason,
        "status": "staged_pending_offline_review",
        "requires_human_approval": True,
        "auto_promotion_authorized": False,
        "drift_signals": [d.dict() for d in (drift_details or [])],
        "proposed_features": [p.dict() for p in (proposed_features or [])],
        "candidate_synthetic_sample_count": len(synthetic_samples or []),
    }

    with open(req_path, "w", encoding="utf-8") as f:
        json.dump(ticket, f, indent=2)

    return ticket

