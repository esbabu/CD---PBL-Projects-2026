"""Explain Agent for CD_Project.

Produces grounded, learner-focused explanations for syntax errors identified
by the multi-error detection layer. Ensures line numbers strictly match
detected errors and drops any hallucinated lines.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from agents.base import execute_gemini_call, format_untrusted_code


class ErrorExplanation(BaseModel):
    line: int = Field(description="Line number matching one of the detected errors")
    plain_explanation: str = Field(description="Clear, plain-language description of the syntax error")
    why_it_happens: str = Field(description="Why the C++ compiler or parser flags this syntax")
    how_to_fix: str = Field(description="Concrete guidance on how to correct the issue")
    learner_tip: str = Field(description="A helpful rule of thumb or tip for C++ learners")


class ExplainAgentResponse(BaseModel):
    explanations: List[ErrorExplanation] = Field(default_factory=list)


class ExplainAgent:
    """Agent that produces grounded explanations for detected syntax errors."""

    def __init__(self, client: Optional[Any] = None):
        self.client = client

    def explain(
        self,
        detector_errors: List[Dict[str, Any]],
        source_code: str = "",
        timeout_seconds: float = 10.0,
    ) -> Dict[str, Any]:
        """Explains syntax errors detected by the compiler frontend/rule-based detector.
        
        Args:
            detector_errors: List of dicts representing detected errors.
            source_code: Full C++ source code (treated as untrusted data).
            timeout_seconds: Maximum time in seconds allocated for this model call.
            
        Returns:
            Dict containing:
                - explanations: List of validated explanation dicts strictly matching detected lines.
                - ai_unavailable: True if Gemini was unreachable/timed out/failed validation, else False.
        """
        if not detector_errors:
            return {"explanations": [], "ai_unavailable": False}

        # Track valid lines from detector output to strictly prevent hallucinations
        valid_lines = {
            int(err["line"])
            for err in detector_errors
            if err.get("line") is not None
        }

        # Format detected errors for grounded context
        error_summary = []
        for err in detector_errors:
            error_summary.append({
                "type": err.get("type", "UNKNOWN"),
                "line": err.get("line", 0),
                "context": err.get("context", ""),
                "description": err.get("description", ""),
            })

        prompt = (
            "Analyze the detected C++ syntax errors below and provide learner-friendly explanations.\n\n"
            "STRICT GROUNDING REQUIREMENT:\n"
            "- You must ONLY explain errors that exist in the DETECTED_ERRORS list.\n"
            "- You may NOT invent new errors, categories, or line numbers.\n"
            f"- Allowed line numbers are strictly: {sorted(list(valid_lines))}.\n\n"
            f"DETECTED_ERRORS:\n{error_summary}\n\n"
            "SOURCE CODE:\n"
            f"{format_untrusted_code(source_code)}\n\n"
            "Respond in JSON matching the schema."
        )

        response_obj, is_fallback = execute_gemini_call(
            agent_name="ExplainAgent",
            prompt=prompt,
            schema_cls=ExplainAgentResponse,
            client=self.client,
            timeout_seconds=timeout_seconds,
        )

        if is_fallback or response_obj is None:
            return {
                "explanations": [],
                "ai_unavailable": True,
            }

        # Enforce grounding guardrail: drop hallucinated lines
        grounded_explanations: List[Dict[str, Any]] = []
        for exp in response_obj.explanations:
            if exp.line in valid_lines:
                grounded_explanations.append(exp.model_dump())

        return {
            "explanations": grounded_explanations,
            "ai_unavailable": False,
        }
