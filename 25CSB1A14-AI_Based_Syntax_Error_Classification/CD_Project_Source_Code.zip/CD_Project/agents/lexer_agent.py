"""Lexer Agent for CD_Project.

Wraps the existing deterministic lexer (lexer.py) to provide:
- Structured tokenization output
- Malformed token detection (unterminated strings, invalid/unterminated chars, unknown tokens)
- Bounded candidate recovery and re-tokenization analysis
- Clear distinction between original, recovery attempt, and recovered results
- Audit logging and strict security guardrails (size limits, filesystem isolation, non-execution)
"""

import os
import time
from typing import Any, Dict, List, Optional, Tuple, Union
from pydantic import BaseModel, Field

import lexer
from agents.base import append_audit_log, format_untrusted_code

MAX_SOURCE_SIZE_BYTES = int(os.environ.get("MAX_SOURCE_SIZE_BYTES", 2 * 1024 * 1024))  # 2 MB default (configurable)
MAX_RECOVERY_RETRIES = 3            # Strict upper bound on recovery attempts


class LexerRequest(BaseModel):
    """Input request specification for Lexer Agent analysis."""
    source_code: str = Field(description="Untrusted C++ source code to analyze")
    max_retries: int = Field(default=1, ge=0, le=MAX_RECOVERY_RETRIES, description="Bounded recovery attempt retries")
    clean_comments: bool = Field(default=True, description="Whether to strip comments prior to tokenization")


class LexerAnalysis(BaseModel):
    """Structured diagnostic and tokenization result returned by Lexer Agent."""
    success: bool = Field(description="True if tokenization succeeded or successfully recovered with zero errors")
    tokens: List[Dict[str, Any]] = Field(default_factory=list, description="Verified tokens (original or recovered)")
    errors: List[Dict[str, Any]] = Field(default_factory=list, description="Active lexer-level errors")
    warnings: List[str] = Field(default_factory=list, description="Non-fatal warnings detected during lexing")
    recovery_attempted: bool = Field(default=False, description="Whether recovery analysis was performed")
    recovery_successful: bool = Field(default=False, description="Whether bounded recovery resolved all malformed tokens")
    explanation: str = Field(default="", description="Summary of lexer findings and recovery outcome")
    original_tokens: Optional[List[Dict[str, Any]]] = Field(default=None, description="Tokens from the initial pass before recovery")
    original_errors: Optional[List[Dict[str, Any]]] = Field(default=None, description="Errors detected in the initial pass before recovery")
    recovered_tokens: Optional[List[Dict[str, Any]]] = Field(default=None, description="Verified tokens produced by successful recovery pass")
    recovered_source: Optional[str] = Field(default=None, description="Candidate source code analyzed during recovery (never applied to user source)")
    recovery_strategy: Optional[str] = Field(default=None, description="Strategy used during recovery analysis")
    ai_unavailable: bool = Field(default=False, description="True if AI-assisted analysis was requested but unavailable")

    def __getitem__(self, item: str) -> Any:
        try:
            return getattr(self, item)
        except AttributeError:
            raise KeyError(item)

    def get(self, item: str, default: Any = None) -> Any:
        return getattr(self, item, default)


def validate_source_input(source_code: Any, max_bytes: int = MAX_SOURCE_SIZE_BYTES) -> Tuple[bool, Optional[str]]:
    """Validates untrusted source code input against size and structure boundaries."""
    if not isinstance(source_code, str):
        return False, "Source code must be a string."
    if "\0" in source_code:
        return False, "Source code contains forbidden null bytes."
    if len(source_code.encode("utf-8")) > max_bytes:
        return False, f"Source code exceeds maximum allowed size of {max_bytes} bytes."
    return True, None


def _is_terminated_string(val: str) -> bool:
    """Checks whether a string token starts and ends with unescaped double quotes."""
    if len(val) < 2 or not val.startswith('"') or not val.endswith('"'):
        return False
    slashes = 0
    for ch in reversed(val[1:-1]):
        if ch == '\\':
            slashes += 1
        else:
            break
    return (slashes % 2) == 0


def _is_terminated_char(val: str) -> bool:
    """Checks whether a character literal token starts and ends with unescaped single quotes."""
    if len(val) < 2 or not val.startswith("'") or not val.endswith("'"):
        return False
    slashes = 0
    for ch in reversed(val[1:-1]):
        if ch == '\\':
            slashes += 1
        else:
            break
    return (slashes % 2) == 0


def detect_malformed_tokens(tokens: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Analyzes token stream produced by deterministic lexer for lexer-level defects.
    
    Returns:
        tuple (errors_list, warnings_list)
    """
    errors: List[Dict[str, Any]] = []
    warnings: List[str] = []

    for tok in tokens:
        kind = tok.get("token_type")
        val = tok.get("token_value", "")
        line = tok.get("line", 1)
        col = tok.get("column", 1)

        # 1. Unterminated string literals
        if kind == "STRING":
            if not _is_terminated_string(val):
                errors.append({
                    "type": "UNTERMINATED_STRING",
                    "line": line,
                    "column": col,
                    "value": val,
                    "message": f"Unterminated string literal at line {line}, column {col}",
                })

        # 2. Malformed / unterminated character literals
        elif kind == "CHAR":
            if not _is_terminated_char(val):
                errors.append({
                    "type": "UNTERMINATED_CHAR",
                    "line": line,
                    "column": col,
                    "value": val,
                    "message": f"Unterminated character literal at line {line}, column {col}",
                })
            elif val == "''":
                errors.append({
                    "type": "EMPTY_CHAR_LITERAL",
                    "line": line,
                    "column": col,
                    "value": val,
                    "message": f"Empty character constant is invalid in C++ at line {line}, column {col}",
                })
            elif len(val) > 3 and not (val.startswith("'\\") and len(val) <= 5):
                warnings.append(
                    f"Multi-character literal '{val}' at line {line}, column {col} may be non-standard"
                )

        # 3. Unrecognized or invalid tokens (matched by UNKNOWN rule '.')
        elif kind == "UNKNOWN":
            errors.append({
                "type": "INVALID_TOKEN",
                "line": line,
                "column": col,
                "value": val,
                "message": f"Unrecognized or invalid token '{val}' at line {line}, column {col}",
            })

    return errors, warnings


def apply_bounded_recovery_patch(source_code: str, errors: List[Dict[str, Any]]) -> Tuple[str, List[str]]:
    """Attempts bounded candidate source modification for re-tokenization analysis.
    
    IMPORTANT: This generates a candidate string for analysis only.
    It does NOT mutate the original user source code.
    """
    lines = source_code.splitlines(keepends=True)
    if not lines:
        return source_code, []

    strategies_used: List[str] = []

    # Sort errors in reverse column order per line so line edits do not invalidate earlier column indices
    sorted_errors = sorted(errors, key=lambda e: (e.get("line", 1), e.get("column", 1)), reverse=True)

    for err in sorted_errors:
        err_type = err.get("type")
        line_num = err.get("line", 1)
        col = err.get("column", 1)
        val = err.get("value", "")

        line_idx = line_num - 1
        if not (0 <= line_idx < len(lines)):
            continue

        orig_line = lines[line_idx]
        start_col = col - 1

        if err_type == "UNTERMINATED_STRING":
            # Unterminated string: inspect token value and surrounding context
            if start_col < len(orig_line):
                # Check if semicolon or closing parenthesis was swallowed into the unterminated string
                if val.endswith(";"):
                    # e.g., 'cout << "hello world;' -> 'cout << "hello world";'
                    fixed_val = val[:-1] + '";'
                    strategies_used.append("close_string_before_semicolon")
                elif val.endswith(");"):
                    fixed_val = val[:-2] + '");'
                    strategies_used.append("close_string_before_paren_semicolon")
                elif val.endswith(")"):
                    fixed_val = val[:-1] + '")'
                    strategies_used.append("close_string_before_paren")
                else:
                    fixed_val = val + '"'
                    strategies_used.append("close_string_at_boundary")

                # Replace the exact token span if matched, else append quote to line
                if orig_line[start_col:start_col + len(val)] == val:
                    lines[line_idx] = orig_line[:start_col] + fixed_val + orig_line[start_col + len(val):]
                else:
                    # Fallback boundary close
                    lines[line_idx] = orig_line.rstrip("\r\n") + '"' + ("\n" if orig_line.endswith("\n") else "")
                    strategies_used.append("append_string_quote")

        elif err_type == "UNTERMINATED_CHAR":
            if start_col < len(orig_line):
                if val.endswith(";"):
                    fixed_val = val[:-1] + "';"
                    strategies_used.append("close_char_before_semicolon")
                elif val.endswith(");"):
                    fixed_val = val[:-2] + "');"
                    strategies_used.append("close_char_before_paren_semicolon")
                elif val.endswith(")"):
                    fixed_val = val[:-1] + "')"
                    strategies_used.append("close_char_before_paren")
                else:
                    fixed_val = val + "'"
                    strategies_used.append("close_char_at_boundary")

                if orig_line[start_col:start_col + len(val)] == val:
                    lines[line_idx] = orig_line[:start_col] + fixed_val + orig_line[start_col + len(val):]
                else:
                    lines[line_idx] = orig_line.rstrip("\r\n") + "'" + ("\n" if orig_line.endswith("\n") else "")
                    strategies_used.append("append_char_quote")

        elif err_type == "EMPTY_CHAR_LITERAL":
            # Replace '' with '\0' for syntactic analysis
            if start_col < len(orig_line) and orig_line[start_col:start_col + len(val)] == val:
                lines[line_idx] = orig_line[:start_col] + r"'\0'" + orig_line[start_col + len(val):]
                strategies_used.append("replace_empty_char_with_null_char")

        elif err_type == "INVALID_TOKEN":
            # Replace unrecognized single character with a whitespace to preserve column alignment
            if start_col < len(orig_line) and orig_line[start_col:start_col + len(val)] == val:
                lines[line_idx] = orig_line[:start_col] + (" " * len(val)) + orig_line[start_col + len(val):]
                strategies_used.append("replace_invalid_token_with_whitespace")

    return "".join(lines), strategies_used


class LexerAgent:
    """Agent that coordinates deterministic lexer analysis, detects malformed tokens,
    and conducts bounded re-tokenization recovery experiments.
    """

    def __init__(self, client: Optional[Any] = None, max_retries: int = 1):
        self.client = client
        self.default_max_retries = max(0, min(max_retries, MAX_RECOVERY_RETRIES))

    def analyze(
        self,
        request: Union[LexerRequest, str, Dict[str, Any]],
        max_retries: Optional[int] = None,
    ) -> LexerAnalysis:
        """Executes the Lexer Agent diagnostic pipeline on untrusted source code.
        
        Guarantees:
        - Never mutates the caller's source code string
        - Never writes to or reads from arbitrary filesystem paths
        - Enforces source size boundaries
        - Uses bounded retry passes to prevent infinite re-tokenization loops
        - Logs audit metadata via agents.base.append_audit_log
        """
        start_time = time.time()

        # Normalize request input
        if isinstance(request, str):
            req = LexerRequest(source_code=request, max_retries=self.default_max_retries)
        elif isinstance(request, dict):
            req = LexerRequest(**request)
        else:
            req = request

        effective_retries = (
            max(0, min(max_retries, MAX_RECOVERY_RETRIES))
            if max_retries is not None
            else req.max_retries
        )

        source_code = req.source_code

        # 1. Security & Guardrail Validation
        valid, err_msg = validate_source_input(source_code)
        if not valid:
            latency_ms = (time.time() - start_time) * 1000.0
            append_audit_log(
                agent_name="lexer_agent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=err_msg,
            )
            return LexerAnalysis(
                success=False,
                tokens=[],
                errors=[{"type": "SECURITY_ERROR", "message": err_msg or "Validation error"}],
                warnings=[],
                recovery_attempted=False,
                recovery_successful=False,
                explanation=f"Lexer analysis rejected by security guardrail: {err_msg}",
            )

        # 2. Normal Deterministic Tokenization Pass
        original_tokens = lexer.tokenize_source(source_code, clean=req.clean_comments)
        initial_errors, initial_warnings = detect_malformed_tokens(original_tokens)

        # 3. Clean tokenization case (no malformed tokens)
        if not initial_errors:
            latency_ms = (time.time() - start_time) * 1000.0
            append_audit_log(
                agent_name="lexer_agent",
                latency_ms=latency_ms,
                success=True,
                fallback=False,
            )
            return LexerAnalysis(
                success=True,
                tokens=original_tokens,
                errors=[],
                warnings=initial_warnings,
                recovery_attempted=False,
                recovery_successful=False,
                explanation=f"Source code tokenized successfully with {len(original_tokens)} tokens and 0 errors.",
                original_tokens=original_tokens,
                original_errors=[],
            )

        # 4. Malformed tokens detected -> Bounded Recovery Attempt
        if effective_retries <= 0:
            latency_ms = (time.time() - start_time) * 1000.0
            append_audit_log(
                agent_name="lexer_agent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=f"Detected {len(initial_errors)} malformed tokens (retries disabled)",
            )
            return LexerAnalysis(
                success=False,
                tokens=original_tokens,
                errors=initial_errors,
                warnings=initial_warnings,
                recovery_attempted=False,
                recovery_successful=False,
                explanation=f"Detected {len(initial_errors)} malformed tokens; recovery retries disabled (max_retries=0).",
                original_tokens=original_tokens,
                original_errors=initial_errors,
            )

        # Iterative bounded recovery loop
        candidate_source = source_code
        current_errors = list(initial_errors)
        strategies_history: List[str] = []
        recovery_successful = False
        final_recovered_tokens: Optional[List[Dict[str, Any]]] = None

        for attempt in range(effective_retries):
            candidate_source, strategies = apply_bounded_recovery_patch(
                candidate_source, current_errors
            )
            strategies_history.extend(strategies)

            # Re-tokenize candidate source with deterministic lexer
            re_tokens = lexer.tokenize_source(candidate_source, clean=req.clean_comments)
            re_errors, _ = detect_malformed_tokens(re_tokens)

            if not re_errors:
                recovery_successful = True
                final_recovered_tokens = re_tokens
                break

            current_errors = re_errors

        latency_ms = (time.time() - start_time) * 1000.0
        strategy_str = ", ".join(strategies_history) if strategies_history else "standard_boundary_patch"

        if recovery_successful and final_recovered_tokens is not None:
            explanation = (
                f"Detected {len(initial_errors)} malformed token(s). "
                f"Successfully recovered and re-tokenized via bounded strategy: [{strategy_str}]."
            )
            append_audit_log(
                agent_name="lexer_agent",
                latency_ms=latency_ms,
                success=True,
                fallback=False,
            )
            return LexerAnalysis(
                success=True,
                tokens=final_recovered_tokens,
                errors=[],
                warnings=initial_warnings,
                recovery_attempted=True,
                recovery_successful=True,
                explanation=explanation,
                original_tokens=original_tokens,
                original_errors=initial_errors,
                recovered_tokens=final_recovered_tokens,
                recovered_source=candidate_source,
                recovery_strategy=strategy_str,
            )
        else:
            explanation = (
                f"Detected {len(initial_errors)} malformed token(s). "
                f"Recovery failed: attempted {effective_retries} bounded recovery pass(es), but {len(current_errors)} error(s) remained."
            )
            append_audit_log(
                agent_name="lexer_agent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=f"Recovery failed ({len(current_errors)} errors remaining)",
            )
            return LexerAnalysis(
                success=False,
                tokens=original_tokens,
                errors=initial_errors,
                warnings=initial_warnings,
                recovery_attempted=True,
                recovery_successful=False,
                explanation=explanation,
                original_tokens=original_tokens,
                original_errors=initial_errors,
                recovered_tokens=None,
                recovered_source=candidate_source,
                recovery_strategy=strategy_str,
            )
