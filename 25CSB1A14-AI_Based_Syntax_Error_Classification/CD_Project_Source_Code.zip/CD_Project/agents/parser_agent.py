"""Parser Agent for CD_Project.

Wraps the existing deterministic C++ parser (cpp_parser.py and predict.py diagnostic pipeline)
as its verification tool layer to provide:
- Structured AST parsing and syntax defect collection
- Root-cause vs cascading error analysis
- Cascade filtering reuse and multi-level cascade detection
- In-memory bounded re-tokenization and reparsing recovery analysis
- Source code immutability (user source code is never mutated)
- Centralized audit logging and strict security guardrails
"""

import os
import re
import time
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from pydantic import BaseModel, Field

import cpp_parser
import lexer
from agents.base import append_audit_log, format_untrusted_code
from predict import (
    apply_autofix,
    build_ast,
    collect_all_errors,
    detect_syntax_errors_in_code_multi,
    filter_cascading_errors,
)

MAX_SOURCE_SIZE_BYTES = int(os.environ.get("MAX_SOURCE_SIZE_BYTES", 2 * 1024 * 1024))  # 2 MB default (configurable)
MAX_REPARSE_RETRIES = 3            # Upper bound on iterative reparse passes


class ParserRequest(BaseModel):
    """Input request specification for Parser Agent analysis."""
    source_code: str = Field(description="Untrusted C++ source code to parse and analyze")
    tokens: Optional[List[Dict[str, Any]]] = Field(default=None, description="Optional pre-tokenized token stream")
    max_retries: int = Field(default=1, ge=0, le=MAX_REPARSE_RETRIES, description="Bounded reparse attempt retries")


class ParserAnalysis(BaseModel):
    """Structured diagnostic and reparsing result returned by Parser Agent."""
    success: bool = Field(description="True if parsing succeeded with zero errors or reparsing resolved all errors")
    errors: List[Dict[str, Any]] = Field(default_factory=list, description="All initially detected parser errors")
    root_cause_errors: List[Dict[str, Any]] = Field(default_factory=list, description="Errors diagnosed as direct root causes")
    cascade_errors: List[Dict[str, Any]] = Field(default_factory=list, description="Errors diagnosed as secondary cascades")
    recovery_attempted: bool = Field(default=False, description="Whether bounded reparse recovery was attempted")
    recovery_successful: bool = Field(default=False, description="Whether bounded reparsing resolved all errors")
    reparsed_errors: Optional[List[Dict[str, Any]]] = Field(default=None, description="Remaining errors after reparse analysis")
    reparsed_source: Optional[str] = Field(default=None, description="Candidate source code analyzed during reparsing (never applied to user source)")
    ast_node_count: int = Field(default=0, description="Total AST nodes produced by deterministic parser")
    explanation: str = Field(default="", description="Detailed summary of root-cause diagnosis, cascades, and reparse outcome")
    ai_unavailable: bool = Field(default=False, description="Whether AI features were unavailable")

    def __getitem__(self, item: str) -> Any:
        try:
            return getattr(self, item)
        except AttributeError:
            raise KeyError(item)

    def get(self, item: str, default: Any = None) -> Any:
        return getattr(self, item, default)


def validate_source_input(source_code: Any, max_bytes: int = MAX_SOURCE_SIZE_BYTES) -> Tuple[bool, Optional[str]]:
    """Validates untrusted source code input against size and structure boundaries."""
    if not isinstance(source_code, str):
        return False, "Source code must be a string."
    if "\0" in source_code:
        return False, "Source code contains forbidden null bytes."
    if len(source_code.encode("utf-8")) > max_bytes:
        return False, f"Source code exceeds maximum allowed size of {max_bytes} bytes."
    return True, None


def count_ast_nodes(node: Any) -> int:
    """Recursively counts AST nodes in the deterministic parser tree."""
    if not node:
        return 0
    count = 1
    for child in getattr(node, "children", []):
        count += count_ast_nodes(child)
    return count


def parse_source_deterministically(
    source_code: str,
    tokens: Optional[List[Dict[str, Any]]] = None,
) -> Tuple[Any, List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Runs the deterministic lexer, cpp_parser, and rule detectors in-memory.
    
    Returns:
        tuple (ast_root, all_raw_errors, filtered_errors, cascade_by_filter)
    """
    code_lines = [l + "\n" for l in source_code.splitlines()] if source_code else []

    if tokens is None:
        tokens = lexer.tokenize_source(source_code, clean=True)

    ast_root, parse_errors = build_ast(tokens) if tokens else (None, [])
    source_errors_multi = detect_syntax_errors_in_code_multi(code_lines) if code_lines else []

    # Reconstruct raw errors before cascade filtering to detect filtered cascades
    seen_keys: Set[Tuple[str, int]] = set()
    raw_errors: List[Dict[str, Any]] = []

    # Map raw parse errors
    for pe in parse_errors:
        etype = None
        for t in [
            "UNTERMINATED_STRING", "MISPLACED_KEYWORD", "INVALID_ASSIGNMENT", "INVALID_CONDITIONAL",
            "INVALID_LOOP", "INVALID_TYPE", "INVALID_ARRAY_DECL",
            "INVALID_FUNCTION_DECL", "INVALID_SWITCH", "INVALID_CLASS_DECL",
            "INVALID_NAMESPACE_DECL", "UNMATCHED_BRACE", "UNMATCHED_PARANTHESES",
            "MISSING_SEMICOLON", "EXTRA_TOKENS", "INVALID_DECLARATION"
        ]:
            if t in pe:
                etype = t
                break
        if not etype:
            continue

        line_num = -1
        match = re.search(r"line\s+(\d+)", pe)
        if match:
            line_num = int(match.group(1))

        ctx = code_lines[line_num - 1].strip() if 1 <= line_num <= len(code_lines) else pe
        key = (etype, line_num)
        if key not in seen_keys:
            seen_keys.add(key)
            raw_errors.append({"type": etype, "line": line_num, "context": ctx})

    for se in source_errors_multi:
        key = (se["type"], se["line"])
        if key not in seen_keys:
            seen_keys.add(key)
            raw_errors.append(dict(se))

    # Standard deterministic pipeline errors (after filter_cascading_errors)
    filtered_errors = collect_all_errors(code_lines, parse_errors, source_errors_multi)

    filtered_keys = {(e["type"], e["line"]) for e in filtered_errors}
    cascade_by_filter = [e for e in raw_errors if (e["type"], e["line"]) not in filtered_keys]

    return ast_root, raw_errors, filtered_errors, cascade_by_filter


def classify_root_causes_and_cascades(
    raw_errors: List[Dict[str, Any]],
    filtered_errors: List[Dict[str, Any]],
    cascades_from_filter: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Analyzes errors to distinguish primary root causes from secondary cascades.
    
    Heuristics:
    1. Errors dropped by filter_cascading_errors() are definite cascades.
    2. Structural root errors (e.g. unclosed parenthesis or brace) cause downstream
       semicolon or conditional errors within the same statement/block.
    3. EOF errors (line <= 0) when an earlier delimiter error exists are cascades.
    4. Independent syntax errors at distinct lines are preserved as root causes.
    """
    cascade_errors: List[Dict[str, Any]] = list(cascades_from_filter)
    root_cause_errors: List[Dict[str, Any]] = []

    # Sort filtered errors by line number
    sorted_filtered = sorted(filtered_errors, key=lambda e: (e.get("line", 1) <= 0, e.get("line", 1)))

    if not sorted_filtered:
        return [], cascade_errors

    # Check for structural root errors that can trigger cascades
    has_unmatched_brace = any(e["type"] == "UNMATCHED_BRACE" and e.get("line", 0) > 0 for e in sorted_filtered)
    has_unmatched_paren = any(e["type"] == "UNMATCHED_PARANTHESES" and e.get("line", 0) > 0 for e in sorted_filtered)
    min_brace_line = min((e["line"] for e in sorted_filtered if e["type"] == "UNMATCHED_BRACE" and e["line"] > 0), default=float('inf'))
    min_paren_line = min((e["line"] for e in sorted_filtered if e["type"] == "UNMATCHED_PARANTHESES" and e["line"] > 0), default=float('inf'))

    for err in sorted_filtered:
        etype = err.get("type", "")
        line = err.get("line", 1)

        # EOF error when genuine unclosed brace/paren exists is a cascade
        if line <= 0 and (has_unmatched_brace or has_unmatched_paren):
            cascade_errors.append(dict(err))
            continue

        # Missing semicolon on the exact same line as unclosed paren is a secondary cascade
        if etype == "MISSING_SEMICOLON" and has_unmatched_paren and line == min_paren_line:
            cascade_errors.append(dict(err))
            continue

        # Repeated delimiter error at end of file after an unclosed block
        if etype == "UNMATCHED_BRACE" and line > min_brace_line and line <= 0:
            cascade_errors.append(dict(err))
            continue

        root_cause_errors.append(dict(err))

    return root_cause_errors, cascade_errors


class ParserAgent:
    """Agent that coordinates deterministic parser analysis, diagnoses root cause vs cascade
    errors, and conducts bounded re-parsing experiments.
    """

    def __init__(self, client: Optional[Any] = None, max_retries: int = 1):
        self.client = client
        self.default_max_retries = max(0, min(max_retries, MAX_REPARSE_RETRIES))

    def analyze(
        self,
        request: Union[ParserRequest, str, Dict[str, Any]],
        max_retries: Optional[int] = None,
    ) -> ParserAnalysis:
        """Executes the Parser Agent diagnostic and reparsing pipeline on untrusted source code.
        
        Guarantees:
        - Never mutates the caller's source code string
        - Never writes to or reads from arbitrary filesystem paths
        - Enforces source size boundaries
        - Uses bounded retry passes to prevent infinite reparsing loops
        - Logs audit metadata via agents.base.append_audit_log
        """
        start_time = time.time()

        # Normalize request input
        if isinstance(request, str):
            req = ParserRequest(source_code=request, max_retries=self.default_max_retries)
        elif isinstance(request, dict):
            req = ParserRequest(**request)
        else:
            req = request

        effective_retries = (
            max(0, min(max_retries, MAX_REPARSE_RETRIES))
            if max_retries is not None
            else req.max_retries
        )

        source_code = req.source_code

        # 1. Security & Guardrail Validation
        valid, err_msg = validate_source_input(source_code)
        if not valid:
            latency_ms = (time.time() - start_time) * 1000.0
            append_audit_log(
                agent_name="parser_agent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=err_msg,
            )
            return ParserAnalysis(
                success=False,
                errors=[{"type": "SECURITY_ERROR", "message": err_msg or "Validation error"}],
                root_cause_errors=[{"type": "SECURITY_ERROR", "message": err_msg or "Validation error"}],
                cascade_errors=[],
                recovery_attempted=False,
                recovery_successful=False,
                explanation=f"Parser analysis rejected by security guardrail: {err_msg}",
            )

        # 2. Normal Deterministic Parsing Pass
        ast_root, raw_errors, filtered_errors, cascades_from_filter = parse_source_deterministically(
            source_code=source_code,
            tokens=req.tokens,
        )
        ast_count = count_ast_nodes(ast_root)

        # 3. Clean parsing case (no syntax errors)
        if not filtered_errors and not raw_errors:
            latency_ms = (time.time() - start_time) * 1000.0
            append_audit_log(
                agent_name="parser_agent",
                latency_ms=latency_ms,
                success=True,
                fallback=False,
            )
            return ParserAnalysis(
                success=True,
                errors=[],
                root_cause_errors=[],
                cascade_errors=[],
                recovery_attempted=False,
                recovery_successful=False,
                ast_node_count=ast_count,
                explanation=f"Source code parsed successfully with {ast_count} AST nodes and 0 syntax errors.",
            )

        # 4. Root-Cause vs Cascade Analysis
        root_causes, cascade_errors = classify_root_causes_and_cascades(
            raw_errors=raw_errors,
            filtered_errors=filtered_errors,
            cascades_from_filter=cascades_from_filter,
        )

        # If retries disabled (max_retries == 0), report pure diagnostic analysis without reparsing
        if effective_retries <= 0:
            latency_ms = (time.time() - start_time) * 1000.0
            explanation = (
                f"Detected {len(filtered_errors)} syntax error(s): "
                f"{len(root_causes)} diagnosed as root cause(s), {len(cascade_errors)} as cascade(s). "
                f"Reparsing disabled (max_retries=0)."
            )
            append_audit_log(
                agent_name="parser_agent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=f"Detected {len(root_causes)} root causes (retries disabled)",
            )
            return ParserAnalysis(
                success=False,
                errors=filtered_errors,
                root_cause_errors=root_causes,
                cascade_errors=cascade_errors,
                recovery_attempted=False,
                recovery_successful=False,
                ast_node_count=ast_count,
                explanation=explanation,
            )

        # 5. Bounded Reparasing Recovery Loop
        # Work on an isolated in-memory copy of lines (never mutating user source)
        candidate_lines = [l + "\n" for l in source_code.splitlines()] if source_code else []
        current_root_causes = list(root_causes)
        reparse_successful = False
        final_reparsed_errors: List[Dict[str, Any]] = list(filtered_errors)
        final_reparsed_source: Optional[str] = None
        current_ast_count = ast_count

        for attempt in range(effective_retries):
            if not current_root_causes:
                break

            # Target the highest priority root cause (earliest in source)
            target_err = current_root_causes[0]
            target_type = target_err.get("type", "")

            # Apply candidate fix in memory
            single_source = {
                target_type: {
                    "line": target_err.get("line", 0),
                    "context": target_err.get("context", ""),
                }
            }
            fixed_lines, changes = apply_autofix(
                code_lines=candidate_lines,
                error_type=target_type,
                parse_errors=[],
                source_errors=single_source,
            )

            # If autofix produced no change, break early to avoid unproductive loop
            if fixed_lines == candidate_lines:
                break

            candidate_lines = fixed_lines
            candidate_source = "".join(candidate_lines)
            final_reparsed_source = candidate_source

            # Re-parse candidate source with deterministic parser
            new_tokens = lexer.tokenize_source(candidate_source, clean=True)
            new_ast, _, new_filtered, new_cascades = parse_source_deterministically(
                source_code=candidate_source,
                tokens=new_tokens,
            )
            current_ast_count = count_ast_nodes(new_ast)
            final_reparsed_errors = new_filtered

            if not new_filtered:
                reparse_successful = True
                break

            # Update remaining root causes for next iteration
            current_root_causes, _ = classify_root_causes_and_cascades(
                raw_errors=new_filtered,
                filtered_errors=new_filtered,
                cascades_from_filter=new_cascades,
            )

        latency_ms = (time.time() - start_time) * 1000.0

        if reparse_successful:
            explanation = (
                f"Detected {len(filtered_errors)} syntax error(s) "
                f"({len(root_causes)} root cause(s), {len(cascade_errors)} cascade(s)). "
                f"Bounded reparsing successfully resolved all errors."
            )
            append_audit_log(
                agent_name="parser_agent",
                latency_ms=latency_ms,
                success=True,
                fallback=False,
            )
            return ParserAnalysis(
                success=True,
                errors=filtered_errors,
                root_cause_errors=root_causes,
                cascade_errors=cascade_errors,
                recovery_attempted=True,
                recovery_successful=True,
                reparsed_errors=[],
                reparsed_source=final_reparsed_source,
                ast_node_count=current_ast_count,
                explanation=explanation,
            )
        else:
            explanation = (
                f"Detected {len(filtered_errors)} syntax error(s) "
                f"({len(root_causes)} root cause(s), {len(cascade_errors)} cascade(s)). "
                f"Bounded reparsing attempted {effective_retries} pass(es); {len(final_reparsed_errors)} error(s) remained."
            )
            append_audit_log(
                agent_name="parser_agent",
                latency_ms=latency_ms,
                success=False,
                fallback=False,
                error_summary=f"Reparsing incomplete ({len(final_reparsed_errors)} errors remaining)",
            )
            return ParserAnalysis(
                success=False,
                errors=filtered_errors,
                root_cause_errors=root_causes,
                cascade_errors=cascade_errors,
                recovery_attempted=True,
                recovery_successful=False,
                reparsed_errors=final_reparsed_errors,
                reparsed_source=final_reparsed_source,
                ast_node_count=current_ast_count,
                explanation=explanation,
            )
