"""
train.py — Controlled ML Training, Evaluation, Promotion, and Rollback CLI.

Usage:
  1. Train and evaluate a candidate model (production artifacts remain UNTOUCHED):
       python train.py
       python train.py --dataset-csv my_dataset.csv
       python train.py --dataset-version dsv-f11f603655e09e20

  2. Explicitly promote a passing candidate model to production:
       python train.py --promote <candidate_id>

  3. Roll back production model to a previous backup snapshot:
       python train.py --rollback [backup_id]

  4. Inspect active production model integrity and status:
       python train.py --status
"""

import os
import sys
import argparse
import dataset_versioning
import retraining_pipeline
import model_promoter


def main():
    parser = argparse.ArgumentParser(description="Controlled C++ Syntax Error ML Classifier Pipeline")
    parser.add_argument("--dataset-csv", default="features.csv", help="Path to input dataset CSV (default: features.csv)")
    parser.add_argument("--dataset-version", default=None, help="Existing immutable dataset version ID to train on")
    parser.add_argument("--promote", metavar="CANDIDATE_ID", default=None, help="Explicitly promote a candidate model to production")
    parser.add_argument("--rollback", metavar="BACKUP_ID", nargs="?", const="", default=None, help="Roll back production model to previous backup")
    parser.add_argument("--status", action="store_true", help="Display active production model status and checksum verification")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for deterministic split and training (default: 42)")
    parser.add_argument("--trees", type=int, default=200, help="Number of trees for Random Forest (default: 200)")
    args = parser.parse_args()

    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Mode 1: Status Inspection
    if args.status:
        print("=" * 60)
        print("  ACTIVE PRODUCTION MODEL STATUS")
        print("=" * 60)
        status = model_promoter.get_active_model_status(base_dir)
        print(f"Production Ready       : {status['production_ready']}")
        print(f"Checksums File Exists  : {status['checksums_file_exists']}")
        print(f"Artifacts Exist        : {status['artifacts_exist']}")
        print(f"Checksums Match        : {status['checksums_match']}")
        if "active_manifest" in status:
            am = status["active_manifest"]
            print(f"Active Candidate ID    : {am.get('candidate_id')}")
            print(f"Dataset Version        : {am.get('dataset_version')}")
            print(f"Test Accuracy          : {am.get('test_accuracy')}%")
            print(f"Promoted At            : {am.get('promoted_at_utc')}")
        print("\nHashes:")
        for k, v in status.get("hashes", {}).items():
            print(f"  {k:<20}: {v}")
        return

    # Mode 2: Promotion
    if args.promote:
        cand_id = args.promote.strip()
        print("=" * 60)
        print(f"  PROMOTING CANDIDATE: {cand_id}")
        print("=" * 60)
        try:
            res = model_promoter.promote_candidate(cand_id, base_dir=base_dir, operator="cli_train_py")
            print(f"\n[SUCCESS] Candidate {cand_id} promoted to production!")
            print(f"  Backup created: {res['backup_id']}")
            print(f"  Test Accuracy : {res['test_accuracy']}%")
            print(f"  Synchronized checksums in model_checksums.json.")
        except model_promoter.PromotionError as e:
            print(f"\n[PROMOTION REJECTED] {e}")
            sys.exit(1)
        return

    # Mode 3: Rollback
    if args.rollback is not None:
        bk_id = args.rollback.strip() or None
        print("=" * 60)
        print(f"  ROLLING BACK PRODUCTION MODEL (target: {bk_id or 'latest backup'})")
        print("=" * 60)
        try:
            res = model_promoter.rollback_to_backup(bk_id, base_dir=base_dir, operator="cli_train_py")
            print(f"\n[SUCCESS] Rollback complete!")
            print(f"  Restored Backup: {res['restored_backup_id']}")
            print(f"  Restored checksums verified.")
        except model_promoter.RollbackError as e:
            print(f"\n[ROLLBACK ERROR] {e}")
            sys.exit(1)
        return

    # Mode 4: Default — Controlled Candidate Training
    print("=" * 60)
    print("  CONTROLLED RANDOM FOREST CANDIDATE TRAINING")
    print("=" * 60)

    # Resolve or register dataset version
    if args.dataset_version:
        dsv_id = args.dataset_version
        print(f"\n[INFO] Using existing dataset version: {dsv_id}")
    else:
        csv_path = os.path.join(base_dir, args.dataset_csv)
        if not os.path.exists(csv_path):
            print(f"ERROR: Dataset CSV not found: {csv_path}")
            sys.exit(1)
        print(f"\n[INFO] Registering immutable dataset version from {args.dataset_csv}...")
        try:
            d_manifest = dataset_versioning.register_dataset_version(
                csv_path,
                description=f"Registered via train.py from {args.dataset_csv}"
            )
            dsv_id = d_manifest["dataset_version"]
            print(f"[INFO] Dataset Version Registered: {dsv_id}")
            print(f"       Sample Count: {d_manifest['sample_count']}, Features: {d_manifest['feature_count']}")
        except dataset_versioning.DatasetValidationError as e:
            print(f"\n[DATASET VALIDATION ERROR] {e}")
            sys.exit(1)

    # Run Candidate Training & Evaluation
    print(f"\n[INFO] Starting candidate training (seed={args.seed}, trees={args.trees})...")
    config = retraining_pipeline.CandidateTrainingConfig(
        dataset_version=dsv_id,
        random_seed=args.seed,
        n_estimators=args.trees,
    )

    try:
        report = retraining_pipeline.train_and_evaluate_candidate(config, base_dir=base_dir)
    except Exception as e:
        print(f"\n[TRAINING ERROR] {e}")
        sys.exit(1)

    cand_id = report["candidate_id"]
    test_metrics = report["metrics"]["test"]
    val_metrics = report["metrics"]["val"]
    gates_passed = report["gates_passed"]

    print("\n" + "=" * 60)
    print(f"  CANDIDATE TRAINING REPORT: {cand_id}")
    print("=" * 60)
    print(f"  Validation Accuracy : {val_metrics['accuracy']:.2f}%")
    print(f"  Test Accuracy       : {test_metrics['accuracy']:.2f}% (95% CI: {test_metrics['confidence_interval_95']})")
    print(f"  Macro F1 Score      : {test_metrics['macro_f1']:.2f}%")
    print(f"  Weighted F1 Score   : {test_metrics['weighted_f1']:.2f}%")

    if report.get("baseline_test_metrics"):
        base_test = report["baseline_test_metrics"]
        delta = report["gate_results"].get("accuracy_delta_vs_baseline", 0.0)
        print(f"  Baseline Test Acc   : {base_test['accuracy']:.2f}% (Delta: {delta:+.2f}%)")

    print("\n[INFO] Acceptance Gate Results:")
    for gate_name, passed in report["gate_results"].items():
        symbol = "PASS" if passed else "FAIL"
        print(f"        [{symbol}] {gate_name}")

    cand_dir = os.path.join(base_dir, "models", "candidates", cand_id)
    print(f"\n[INFO] Candidate artifacts saved to: {cand_dir}")
    print(f"[NOTICE] Production model remains UNTOUCHED.")

    if gates_passed:
        print(f"\nTo promote this candidate to production, execute:")
        print(f"  python train.py --promote {cand_id}\n")
    else:
        print(f"\n[WARNING] Candidate FAILED evaluation gates and is NOT eligible for promotion.\n")


if __name__ == "__main__":
    main()