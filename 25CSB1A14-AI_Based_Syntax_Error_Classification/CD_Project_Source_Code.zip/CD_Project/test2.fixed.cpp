#include <iostream>
using namespace std;
// int main() {
//     if (5 > 3 {   // ❌ missing )
//         return 1;
//     }
// }

int main() {
    return (5 > 3);  
}