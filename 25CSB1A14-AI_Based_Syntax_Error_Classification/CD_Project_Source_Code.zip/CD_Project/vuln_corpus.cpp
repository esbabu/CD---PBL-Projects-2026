#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <thread>
#include <mutex>
#include <fstream>
#include <atomic>
#include <condition_variable>
#include <chrono>
#include <csignal>
#include <climits>
#include <vector>
#include <string>
#include <random>

// Portability and stub declarations for static analysis
extern "C" {
    char *gets(char *s);
    int syslog(int priority, const char *format, ...);
    int shmget(int key, size_t size, int shmflg);
    int seteuid(uid_t euid);
    void *MD5(const unsigned char *d, size_t n, unsigned char *md);
    void *SHA256(const unsigned char *d, size_t n, unsigned char *md);
    void *RSA_generate_key(int bits, unsigned long e, void *callback, void *cb_arg);
}

// Global variables for race condition and insecure state
int global_shared_counter = 0;
std::mutex mtx;
bool authenticated = false;

void stack_overflow_example(char *user_input) {
    char buffer[16];
    // Vulnerability 1: Unbounded strcpy (Stack Buffer Overflow)
    // EXPECT: CWE-120 line=38
    strcpy(buffer, user_input);
}

void safe_stack_overflow_example(const char *user_input) {
    // EXPECT: none (safe twin)
    char buffer[16];
    strncpy(buffer, user_input, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\0';
}

void unsafe_sprintf_example(char *user_input) {
    char buffer[32];
    // Vulnerability 2: Unsafe sprintf
    // EXPECT: CWE-120 line=52
    sprintf(buffer, "User data: %s", user_input);
}

void safe_sprintf_example(const char *user_input) {
    // EXPECT: none (safe twin)
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "User data: %s", user_input);
}

void unsafe_gets_example() {
    char buffer[64];
    // Vulnerability 3: Use of deprecated/unsafe gets
    // EXPECT: CWE-242 line=65
    gets(buffer);
}

void safe_gets_example() {
    // EXPECT: none (safe twin)
    char buffer[64];
    if (fgets(buffer, sizeof(buffer), stdin) == nullptr) {
        buffer[0] = '\0';
    }
}

void off_by_one_example(char *input, int len) {
    char buffer[10];
    // Vulnerability 4: Off-by-one error
    // EXPECT: CWE-193 line=80
    for (int i = 0; i <= len; i++) {
        buffer[i] = input[i];
    }
}

void safe_off_by_one_example(char *input, int len) {
    // EXPECT: none (safe twin)
    char buffer[10];
    for (int i = 0; i < len && i < 10; i++) {
        buffer[i] = input[i];
    }
}

void unbounded_scanf() {
    char buf[20];
    // Vulnerability 5: Unbounded scanf specifier
    // EXPECT: CWE-120 line=97
    scanf("%s", buf);
}

void safe_unbounded_scanf() {
    // EXPECT: none (safe twin)
    char buf[20];
    scanf("%19s", buf);
}

void bad_memcpy_size(char *src, size_t size) {
    char dest[10];
    // Vulnerability 6: memcpy with hardcoded larger size or untrusted size
    // EXPECT: CWE-120 line=110
    memcpy(dest, src, size);
}

void safe_memcpy_size(char *src, size_t size) {
    // EXPECT: none (safe twin)
    char dest[10];
    if (size <= sizeof(dest)) {
        memcpy(dest, src, size);
    }
}

void strcat_overflow(char *input) {
    char dest[20] = "Hello ";
    // Vulnerability 7: Unsafe strcat
    // EXPECT: CWE-120 line=125
    strcat(dest, input);
}

void safe_strcat_overflow(char *input) {
    // EXPECT: none (safe twin)
    char dest[20] = "Hello ";
    strncat(dest, input, sizeof(dest) - strlen(dest) - 1);
}

void fscanf_overflow() {
    char buf[10];
    // Vulnerability 8: Unbounded fscanf into fixed buffer
    // EXPECT: CWE-120 line=138
    FILE *f = fopen("test.txt", "r");
    if (f) {
        fscanf(f, "%s", buf);
        fclose(f);
    }
}

void safe_fscanf_overflow() {
    // EXPECT: none (safe twin)
    char buf[10];
    FILE *f = fopen("test.txt", "r");
    if (f) {
        fscanf(f, "%9s", buf);
        fclose(f);
    }
}

void snprintf_truncation_misuse(char *input) {
    char buf[5];
    // Vulnerability 9: Misuse of snprintf return value / truncation risk
    // EXPECT: CWE-120 line=159
    int n = snprintf(buf, sizeof(buf), "%s", input);
    buf[n] = '\0';
}

void safe_snprintf_truncation(char *input) {
    // EXPECT: none (safe twin)
    char buf[5];
    int n = snprintf(buf, sizeof(buf), "%s", input);
    if (n >= 0 && (size_t)n < sizeof(buf)) {
        buf[n] = '\0';
    }
}

void wide_char_overflow(wchar_t *input) {
    wchar_t buf[10];
    // Vulnerability 10: Unsafe wcscpy
    // EXPECT: CWE-120 line=176
    wcscpy(buf, input);
}

void safe_wide_char_overflow(wchar_t *input) {
    // EXPECT: none (safe twin)
    wchar_t buf[10];
    wcsncpy(buf, input, 9);
    buf[9] = L'\0';
}

void heap_overflow_example(char *input) {
    char *heap_buf = new char[16];
    // Vulnerability 11: Heap buffer overflow
    // EXPECT: CWE-120 line=190
    strcpy(heap_buf, input);
    delete[] heap_buf;
}

void safe_heap_overflow_example(char *input) {
    // EXPECT: none (safe twin)
    char *heap_buf = new char[16];
    strncpy(heap_buf, input, 15);
    heap_buf[15] = '\0';
    delete[] heap_buf;
}

void use_after_free_example() {
    char *ptr = new char[32];
    delete[] ptr;
    // Vulnerability 12: Use-After-Free
    // EXPECT: CWE-416 line=207
    ptr[0] = 'A';
}

void safe_use_after_free_example() {
    // EXPECT: none (safe twin)
    char *ptr = new char[32];
    ptr[0] = 'A';
    delete[] ptr;
    ptr = nullptr;
}

void double_free_example() {
    char *ptr = new char[32];
    delete[] ptr;
    // Vulnerability 13: Double free
    // EXPECT: CWE-415 line=223
    delete[] ptr;
}

void safe_double_free_example() {
    // EXPECT: none (safe twin)
    char *ptr = new char[32];
    delete[] ptr;
    ptr = nullptr;
}

void memory_leak_example() {
    // Vulnerability 14: Memory leak (allocation without deallocation)
    // EXPECT: CWE-401 line=236
    int *leak = new int[1000];
    leak = nullptr;
}

void safe_memory_leak_example() {
    // EXPECT: none (safe twin)
    int *leak = new int[1000];
    delete[] leak;
    leak = nullptr;
}

void mismatched_free_example() {
    // Vulnerability 15: Mismatched memory management (malloc with delete[])
    // EXPECT: CWE-762 line=250
    char *p = (char*)malloc(10);
    delete[] p;
}

void safe_mismatched_free_example() {
    // EXPECT: none (safe twin)
    char *p = (char*)malloc(10);
    free(p);
}

void null_pointer_dereference(int *ptr) {
    // Vulnerability 16: Potential NULL pointer dereference
    // EXPECT: CWE-476 line=263
    *ptr = 42;
}

void safe_null_pointer_dereference(int *ptr) {
    // EXPECT: none (safe twin)
    if (ptr != nullptr) {
        *ptr = 42;
    }
}

void uninitialized_pointer_read() {
    int *ptr;
    // Vulnerability 17: Uninitialized pointer read/write
    // EXPECT: CWE-457 line=277
    *ptr = 10;
}

void safe_uninitialized_pointer_read() {
    // EXPECT: none (safe twin)
    int val = 0;
    int *ptr = &val;
    *ptr = 10;
}

void free_stack_pointer() {
    int x = 10;
    int *p = &x;
    // Vulnerability 18: Freeing stack memory
    // EXPECT: CWE-590 line=292
    free(p);
}

void safe_free_stack_pointer() {
    // EXPECT: none (safe twin)
    int x = 10;
    int *p = &x;
    (void)p;
}

void integer_overflow_allocation(int count) {
    // Vulnerability 19: Integer overflow leading to heap under-allocation
    // EXPECT: CWE-190 line=305
    int size = count * sizeof(int);
    char *buf = new char[size];
    delete[] buf;
}

void safe_integer_overflow_allocation(int count) {
    // EXPECT: none (safe twin)
    if (count > 0 && count < 1000000) {
        size_t size = (size_t)count * sizeof(int);
        char *buf = new char[size];
        delete[] buf;
    }
}

void dangling_pointer_return(int **out) {
    int local = 5;
    // Vulnerability 20: Returning address of local stack variable
    // EXPECT: CWE-562 line=323
    *out = &local;
}

void safe_dangling_pointer_return(int **out) {
    // EXPECT: none (safe twin)
    *out = new int(5);
}

int integer_overflow_add(int a, int b) {
    // Vulnerability 21: Unchecked signed integer addition overflow
    // EXPECT: CWE-190 line=334
    return a + b;
}

int safe_integer_overflow_add(int a, int b) {
    // EXPECT: none (safe twin)
    if ((b > 0 && a > INT_MAX - b) || (b < 0 && a < INT_MIN - b)) return 0;
    return a + b;
}

unsigned int integer_overflow_mult(unsigned int a, unsigned int b) {
    // Vulnerability 22: Unchecked multiplication overflow
    // EXPECT: CWE-190 line=346
    return a * b;
}

unsigned int safe_integer_overflow_mult(unsigned int a, unsigned int b) {
    // EXPECT: none (safe twin)
    if (a != 0 && b > UINT_MAX / a) return 0;
    return a * b;
}

void signed_unsigned_conversion(int len) {
    char buf[100];
    // Vulnerability 23: Signed to unsigned conversion mismatch
    // EXPECT: CWE-195 line=359
    if (len < 200) {
        memcpy(buf, "test", len);
    }
}

void safe_signed_unsigned_conversion(int len) {
    // EXPECT: none (safe twin)
    char buf[100];
    if (len >= 0 && len < 100) {
        memcpy(buf, "test", (size_t)len);
    }
}

int integer_underflow(int a, int b) {
    // Vulnerability 24: Unchecked subtraction underflow
    // EXPECT: CWE-191 line=375
    return a - b;
}

int safe_integer_underflow(int a, int b) {
    // EXPECT: none (safe twin)
    if ((b < 0 && a > INT_MAX + b) || (b > 0 && a < INT_MIN + b)) return 0;
    return a - b;
}

void division_by_zero(int divisor) {
    // Vulnerability 25: Unchecked division by zero
    // EXPECT: CWE-369 line=387
    int result = 100 / divisor;
    (void)result;
}

void safe_division_by_zero(int divisor) {
    // EXPECT: none (safe twin)
    if (divisor != 0) {
        int result = 100 / divisor;
        (void)result;
    }
}

void modulus_by_zero(int divisor) {
    // Vulnerability 26: Unchecked modulus by zero
    // EXPECT: CWE-369 line=402
    int result = 100 % divisor;
    (void)result;
}

void safe_modulus_by_zero(int divisor) {
    // EXPECT: none (safe twin)
    if (divisor != 0) {
        int result = 100 % divisor;
        (void)result;
    }
}

short narrow_cast(int large_val) {
    // Vulnerability 27: Dangerous implicit narrowing cast
    // EXPECT: CWE-197 line=417
    short s = large_val;
    return s;
}

short safe_narrow_cast(int large_val) {
    // EXPECT: none (safe twin)
    if (large_val >= SHRT_MIN && large_val <= SHRT_MAX) {
        return (short)large_val;
    }
    return 0;
}

size_t negative_to_size_t(int val) {
    // Vulnerability 28: Casting negative signed value to size_t
    // EXPECT: CWE-195 line=432
    return (size_t)val;
}

size_t safe_negative_to_size_t(int val) {
    // EXPECT: none (safe twin)
    if (val >= 0) return (size_t)val;
    return 0;
}

void bitwise_shift_overflow(int val, int shift) {
    // Vulnerability 29: Undefined behavior from out-of-range bitwise shift
    // EXPECT: CWE-1335 line=444
    int res = val << shift;
    (void)res;
}

void safe_bitwise_shift_overflow(int val, int shift) {
    // EXPECT: none (safe twin)
    if (shift >= 0 && shift < 31) {
        int res = val << shift;
        (void)res;
    }
}

void pointer_arithmetic_overflow(char *base, int offset) {
    // Vulnerability 30: Unchecked pointer arithmetic overflow
    // EXPECT: CWE-190 line=459
    char *ptr = base + offset;
    (void)ptr;
}

void safe_pointer_arithmetic_overflow(char *base, int offset) {
    // EXPECT: none (safe twin)
    if (offset >= 0 && offset < 1024) {
        char *ptr = base + offset;
        (void)ptr;
    }
}

void format_string_vulnerability(char *user_input) {
    // Vulnerability 31: Uncontrolled format string in printf
    // EXPECT: CWE-134 line=474
    printf(user_input);
}

void safe_format_string_vulnerability(char *user_input) {
    // EXPECT: none (safe twin)
    printf("%s", user_input);
}

void fprintf_format_string(FILE *f, char *user_input) {
    // Vulnerability 32: Uncontrolled format string in fprintf
    // EXPECT: CWE-134 line=485
    fprintf(f, user_input);
}

void safe_fprintf_format_string(FILE *f, char *user_input) {
    // EXPECT: none (safe twin)
    fprintf(f, "%s", user_input);
}

void syslog_format_string(char *user_input) {
    // Vulnerability 33: Uncontrolled format string in syslog-style logging
    // EXPECT: CWE-134 line=496
    syslog(3, user_input);
}

void safe_syslog_format_string(char *user_input) {
    // EXPECT: none (safe twin)
    syslog(3, "%s", user_input);
}

void snprintf_format_risk(char *user_input) {
    char buf[100];
    // Vulnerability 34: Format string passed as format argument
    // EXPECT: CWE-134 line=508
    snprintf(buf, sizeof(buf), user_input);
}

void safe_snprintf_format_risk(char *user_input) {
    // EXPECT: none (safe twin)
    char buf[100];
    snprintf(buf, sizeof(buf), "%s", user_input);
}

void insecure_temp_file() {
    // Vulnerability 35: Use of insecure temporary file function (tmpnam / mktemp)
    // EXPECT: CWE-377 line=520
    char *filename = tmpnam(nullptr);
    (void)filename;
}

void safe_temp_file() {
    // EXPECT: none (safe twin)
    char template_path[] = "/tmp/secureXXXXXX";
    int fd = mkstemp(template_path);
    if (fd != -1) close(fd);
}

void hardcoded_file_permissions() {
    // Vulnerability 36: Creating files with overly permissive modes (e.g., 0777)
    // EXPECT: CWE-732 line=534
    int fd = open("sensitive.txt", 0100 | 01, 0777);
    if (fd != -1) close(fd);
}

void safe_hardcoded_file_permissions() {
    // EXPECT: none (safe twin)
    int fd = open("sensitive.txt", 0100 | 01, 0600);
    if (fd != -1) close(fd);
}

void path_traversal_example(char *filename) {
    char path[256];
    // Vulnerability 37: Unvalidated path construction leading to path traversal
    // EXPECT: CWE-22 line=548
    snprintf(path, sizeof(path), "/var/app/uploads/%s", filename);
    std::ifstream f(path);
}

void safe_path_traversal_example(char *filename) {
    // EXPECT: none (safe twin)
    char path[256];
    if (strstr(filename, "..") == nullptr && strchr(filename, '/') == nullptr) {
        snprintf(path, sizeof(path), "/var/app/uploads/%s", filename);
        std::ifstream f(path);
    }
}

void arbitrary_file_deletion(char *filename) {
    // Vulnerability 38: Unchecked file deletion of arbitrary user input path
    // EXPECT: CWE-73 line=564
    unlink(filename);
}

void safe_arbitrary_file_deletion(char *filename) {
    // EXPECT: none (safe twin)
    if (filename != nullptr && strstr(filename, "..") == nullptr) {
        unlink(filename);
    }
}

void insecure_file_stream_state() {
    std::ifstream f("nonexistent.txt");
    // Vulnerability 39: Ignoring stream error states before reading
    // EXPECT: CWE-252 line=578
    int val;
    f >> val;
}

void safe_file_stream_state() {
    // EXPECT: none (safe twin)
    std::ifstream f("nonexistent.txt");
    int val;
    if (f.is_open() && (f >> val)) {
        (void)val;
    }
}

void missing_file_closure() {
    // Vulnerability 40: Resource leak due to unclosed file descriptor
    // EXPECT: CWE-775 line=594
    FILE *f = fopen("data.txt", "r");
    if (!f) return;
}

void safe_file_closure() {
    // EXPECT: none (safe twin)
    FILE *f = fopen("data.txt", "r");
    if (!f) return;
    fclose(f);
}

void command_injection_system(char *user_filename) {
    char cmd[512];
    // Vulnerability 41: Command injection via system()
    // EXPECT: CWE-78 line=609
    snprintf(cmd, sizeof(cmd), "cat %s", user_filename);
    system(cmd);
}

void safe_command_system(char *user_filename) {
    // EXPECT: none (safe twin)
    std::ifstream f(user_filename);
    if (f.is_open()) {
        std::cout << f.rdbuf();
    }
}

void command_injection_popen(char *user_input) {
    char cmd[256];
    // Vulnerability 42: Command injection via popen()
    // EXPECT: CWE-78 line=625
    snprintf(cmd, sizeof(cmd), "grep %s data.txt", user_input);
    FILE *p = popen(cmd, "r");
    if (p) pclose(p);
}

void safe_command_popen(char *user_input) {
    // EXPECT: none (safe twin)
    (void)user_input;
    FILE *p = popen("grep -F fixed_term data.txt", "r");
    if (p) pclose(p);
}

void insecure_exec_call(char *arg) {
    // Vulnerability 43: Insecure process execution with untrusted argument
    // EXPECT: CWE-78 line=640
    execl("/bin/sh", "sh", "-c", arg, NULL);
}

void safe_exec_call() {
    // EXPECT: none (safe twin)
    execl("/bin/cat", "cat", "data.txt", NULL);
}

void environment_variable_injection() {
    // Vulnerability 44: Trusting untrusted PATH environment variable
    // EXPECT: CWE-78 line=651
    system("ls");
}

void safe_environment_variable() {
    // EXPECT: none (safe twin)
    system("/bin/ls");
}

void insecure_umask() {
    // Vulnerability 45: Setting overly permissive umask (0000)
    // EXPECT: CWE-276 line=662
    umask(0);
}

void safe_umask() {
    // EXPECT: none (safe twin)
    umask(0027);
}

void race_condition_file_access(char *filename) {
    // Vulnerability 46: TOCTOU (Time-of-Check to Time-of-Use) file access race condition
    // EXPECT: CWE-367 line=673
    if (access(filename, 2) == 0) {
        std::ofstream f(filename, std::ios::app);
        f << "data";
    }
}

void safe_file_access(char *filename) {
    // EXPECT: none (safe twin)
    int fd = open(filename, 0100 | 01, 0600);
    if (fd != -1) {
        close(fd);
    }
}

void insecure_shared_memory() {
    // Vulnerability 47: Insecure permissions on shared memory segment
    // EXPECT: CWE-732 line=690
    int shmid = shmget(1234, 1024, 0777 | 01000);
    (void)shmid;
}

void safe_shared_memory() {
    // EXPECT: none (safe twin)
    int shmid = shmget(1234, 1024, 0600 | 01000);
    (void)shmid;
}

void improper_privilege_drop() {
    // Vulnerability 48: Failing to drop root privileges permanently (setuid vs seteuid error)
    // EXPECT: CWE-273 line=703
    seteuid(getuid());
}

void safe_privilege_drop() {
    // EXPECT: none (safe twin)
    if (setuid(getuid()) != 0) {
        exit(1);
    }
}

void bad_sig_handler(int signum) {
    printf("Signal %d\n", signum);
}
void insecure_signal_handling() {
    // Vulnerability 49: Using unsafe functions inside signal handlers
    // EXPECT: CWE-479 line=719
    signal(2, bad_sig_handler);
}

static volatile sig_atomic_t g_safe_sig_flag = 0;
void good_sig_handler(int signum) {
    g_safe_sig_flag = 1;
}
void safe_signal_handling() {
    // EXPECT: none (safe twin)
    signal(2, good_sig_handler);
}

void background_process_orphan() {
    // Vulnerability 50: Creating zombie processes without reaping via waitpid
    // EXPECT: CWE-400 line=734
    if (fork() == 0) {
        exit(0);
    }
}

void safe_background_process() {
    // EXPECT: none (safe twin)
    pid_t p = fork();
    if (p == 0) {
        exit(0);
    } else if (p > 0) {
        waitpid(p, nullptr, 0);
    }
}

void thread_race_condition() {
    // Vulnerability 51: Data race on global counter without synchronization
    // EXPECT: CWE-362 line=752
    std::thread t1([]() { global_shared_counter++; });
    std::thread t2([]() { global_shared_counter++; });
    t1.join();
    t2.join();
}

void safe_thread_race_condition() {
    // EXPECT: none (safe twin)
    static std::atomic<int> atomic_counter(0);
    std::thread t1([]() { atomic_counter++; });
    std::thread t2([]() { atomic_counter++; });
    t1.join();
    t2.join();
}

void dead_lock_example() {
    static std::mutex m1, m2;
    // Vulnerability 52: Potential deadlock due to inconsistent lock ordering
    // EXPECT: CWE-833 line=771
    std::thread t1([&]() {
        std::lock_guard<std::mutex> l1(m1);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        std::lock_guard<std::mutex> l2(m2);
    });
    std::thread t2([&]() {
        std::lock_guard<std::mutex> l2(m2);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        std::lock_guard<std::mutex> l1(m1);
    });
    t1.join(); t2.join();
}

void safe_dead_lock_example() {
    // EXPECT: none (safe twin)
    static std::mutex m1, m2;
    std::thread t1([&]() {
        std::lock(m1, m2);
        std::lock_guard<std::mutex> l1(m1, std::adopt_lock);
        std::lock_guard<std::mutex> l2(m2, std::adopt_lock);
    });
    std::thread t2([&]() {
        std::lock(m1, m2);
        std::lock_guard<std::mutex> l1(m1, std::adopt_lock);
        std::lock_guard<std::mutex> l2(m2, std::adopt_lock);
    });
    t1.join(); t2.join();
}

void double_lock_mutex() {
    // Vulnerability 53: Attempting recursive locking on non-recursive mutex
    // EXPECT: CWE-667 line=803
    mtx.lock();
    mtx.lock();
    mtx.unlock();
}

void safe_double_lock_mutex() {
    // EXPECT: none (safe twin)
    std::lock_guard<std::mutex> lock(mtx);
}

void unlocked_shared_read() {
    // Vulnerability 54: Reading shared state without holding the mutex lock
    // EXPECT: CWE-362 line=816
    int val = global_shared_counter;
    (void)val;
}

void safe_unlocked_shared_read() {
    // EXPECT: none (safe twin)
    int val;
    {
        std::lock_guard<std::mutex> lock(mtx);
        val = global_shared_counter;
    }
    (void)val;
}

void thread_detach_lifetime_issue() {
    int local_var = 100;
    // Vulnerability 55: Detached thread accessing stack variable of expired scope
    // EXPECT: CWE-416 line=834
    std::thread t([&]() {
        std::cout << local_var << std::endl;
    });
    t.detach();
}

void safe_thread_detach_lifetime() {
    // EXPECT: none (safe twin)
    int local_var = 100;
    std::thread t([local_var]() {
        std::cout << local_var << std::endl;
    });
    t.detach();
}

void atomics_memory_order_misuse() {
    // Vulnerability 56: Inappropriate memory ordering in atomics leading to visibility bugs
    // EXPECT: CWE-662 line=852
    std::atomic<int> flag(0);
    flag.store(1, std::memory_order_relaxed);
}

void safe_atomics_memory_order() {
    // EXPECT: none (safe twin)
    std::atomic<int> flag(0);
    flag.store(1, std::memory_order_release);
}

void spinlock_busy_wait() {
    // Vulnerability 57: Unbounded CPU consumption in busy-wait spinlock
    // EXPECT: CWE-835 line=865
    std::atomic<bool> lock(false);
    while (lock.exchange(true, std::memory_order_acquire)) {
        break;
    }
}

void safe_spinlock_busy_wait() {
    // EXPECT: none (safe twin)
    std::atomic<bool> lock(false);
    while (lock.exchange(true, std::memory_order_acquire)) {
        std::this_thread::yield();
    }
}

void thread_pool_starvation() {
    // Vulnerability 58: Unbounded task queue leading to resource exhaustion
    // EXPECT: none (documentation only)
}

void safe_thread_pool_starvation() {
    // EXPECT: none (safe twin)
}

void condition_variable_spurious_wakeup() {
    // Vulnerability 59: Missing loop check on condition variable predicate (spurious wakeup)
    // EXPECT: CWE-835 line=891
    std::mutex cv_mtx;
    std::condition_variable cv;
    bool ready = false;
    std::unique_lock<std::mutex> lock(cv_mtx);
    if (!ready) {
        cv.wait(lock);
    }
}

void safe_condition_variable() {
    // EXPECT: none (safe twin)
    std::mutex cv_mtx;
    std::condition_variable cv;
    bool ready = false;
    std::unique_lock<std::mutex> lock(cv_mtx);
    cv.wait(lock, [&] { return ready; });
}

void thread_stack_exhaustion() {
    // Vulnerability 60: Deep or infinite recursive spawning in threads
    // EXPECT: none (documentation only)
}

void safe_thread_stack_exhaustion() {
    // EXPECT: none (safe twin)
}

void weak_pseudo_random_number_generator() {
    // Vulnerability 61: Using rand() for security-sensitive tokens
    // EXPECT: CWE-338 line=921
    int token = rand();
    (void)token;
}

void safe_random_generator() {
    // EXPECT: none (safe twin)
    std::random_device rd;
    unsigned int token = rd();
    (void)token;
}

void hardcoded_cryptographic_key() {
    // Vulnerability 62: Hardcoded encryption key in source code
    // EXPECT: CWE-321 line=935
    const char *aes_key = "SuperSecretKey123";
    (void)aes_key;
}

void safe_cryptographic_key() {
    // EXPECT: none (safe twin)
    const char *aes_key = getenv("APP_AES_KEY");
    (void)aes_key;
}

void ECB_mode_encryption() {
    // Vulnerability 63: Using insecure ECB mode for block cipher encryption
    // EXPECT: none (documentation only)
}

void safe_ECB_mode_encryption() {
    // EXPECT: none (safe twin)
}

void weak_hash_algorithm(const char *password) {
    // Vulnerability 64: Using broken cryptographic hash function (MD5/SHA1 for passwords)
    // EXPECT: CWE-328 line=957
    char digest[16];
    MD5((const unsigned char*)password, strlen(password), (unsigned char*)digest);
}

void safe_hash_algorithm(const char *password) {
    // EXPECT: none (safe twin)
    char digest[32];
    SHA256((const unsigned char*)password, strlen(password), (unsigned char*)digest);
}

void predictable_iv_nonce() {
    // Vulnerability 65: Reusing or hardcoding Initialization Vector (IV) / Nonce
    // EXPECT: CWE-329 line=970
    const unsigned char static_iv[16] = "0123456789abcdef";
    (void)static_iv;
}

void safe_iv_nonce() {
    // EXPECT: none (safe twin)
    std::random_device rd;
    unsigned char iv[16];
    for (int i = 0; i < 16; i++) iv[i] = (unsigned char)(rd() & 0xFF);
    (void)iv;
}

void insufficient_key_length() {
    // Vulnerability 66: Using short asymmetric key length (e.g. RSA 512-bit)
    // EXPECT: CWE-326 line=985
    RSA_generate_key(512, 65537, nullptr, nullptr);
}

void safe_key_length() {
    // EXPECT: none (safe twin)
    RSA_generate_key(3072, 65537, nullptr, nullptr);
}

void missing_salt_password_hashing() {
    // Vulnerability 67: Storing passwords hashed without unique per-user salt
    // EXPECT: none (documentation only)
}

void safe_salt_password_hashing() {
    // EXPECT: none (safe twin)
}

void timing_attack_string_comparison(const char *input_secret, const char *real_secret) {
    // Vulnerability 68: Timing side-channel vulnerability in secret comparison
    // EXPECT: CWE-208 line=1005
    bool match = (strcmp(input_secret, real_secret) == 0);
    (void)match;
}

bool safe_constant_time_cmp(const char *a, const char *b, size_t len) {
    unsigned char result = 0;
    for (size_t i = 0; i < len; i++) {
        result |= ((unsigned char)a[i] ^ (unsigned char)b[i]);
    }
    return result == 0;
}
void safe_timing_string_comparison(const char *input_secret, const char *real_secret, size_t len) {
    // EXPECT: none (safe twin)
    bool match = safe_constant_time_cmp(input_secret, real_secret, len);
    (void)match;
}

void insecure_random_seed() {
    // Vulnerability 69: Seeding rand() with predictable static value (e.g., srand(1))
    // EXPECT: CWE-337 line=1025
    srand(1);
}

void safe_random_seed() {
    // EXPECT: none (safe twin)
    std::random_device rd;
    srand(rd());
}

void plaintext_credential_storage(const char *password) {
    // Vulnerability 70: Storing credentials in plaintext configuration
    // EXPECT: CWE-312 line=1037
    std::ofstream cred_file("passwords.txt", std::ios::app);
    cred_file << "password=" << password << std::endl;
}

void safe_credential_storage(const char *password) {
    // EXPECT: none (safe twin)
    (void)password;
    std::ofstream cred_file("passwords.txt", std::ios::app);
    cred_file << "hash=$2b$12$securehashrepresentation" << std::endl;
}
{"timestamp": "2026-11-15T18:04:20.752526+00:00", "agent": "AgenticAttackDetector", "latency_ms": 13.91, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Dangerous command execution function detected in C++ source: system(", "event": "attack_detected", "error_category": "security_violation", "event_id": "evt-b05557c94022", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "blocked"}
{"timestamp": "2026-11-15T18:04:20.793989+00:00", "agent": "AssessmentEngine", "latency_ms": 0.0, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Pre-diagnostic gate blocked by detected agentic attack: Dangerous command execution function detected in C++ source: system(", "event": "gate_blocked", "error_category": "security_violation", "event_id": "evt-b05557c94022", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "pre_diagnostic_gate_blocked"}
{"timestamp": "2026-11-15T18:04:34.058105+00:00", "agent": "AgenticAttackDetector", "latency_ms": 47.84, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Dangerous command execution function detected in C++ source: system(", "event": "attack_detected", "error_category": "security_violation", "event_id": "evt-f7f8e49e0fbb", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "blocked"}
{"timestamp": "2026-11-15T18:04:34.191517+00:00", "agent": "AssessmentEngine", "latency_ms": 0.0, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Pre-diagnostic gate blocked by detected agentic attack: Dangerous command execution function detected in C++ source: system(", "event": "gate_blocked", "error_category": "security_violation", "event_id": "evt-f7f8e49e0fbb", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "pre_diagnostic_gate_blocked"}
{"timestamp": "2026-11-15T18:08:03.590019+00:00", "agent": "AgenticAttackDetector", "latency_ms": 64.56, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Dangerous command execution function detected in C++ source: system(", "event": "attack_detected", "error_category": "security_violation", "event_id": "evt-9e1ea5f2e1c2", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "blocked"}
{"timestamp": "2026-11-15T18:08:03.746355+00:00", "agent": "AssessmentEngine", "latency_ms": 0.0, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Pre-diagnostic gate blocked by detected agentic attack: Dangerous command execution function detected in C++ source: system(", "event": "gate_blocked", "error_category": "security_violation", "event_id": "evt-9e1ea5f2e1c2", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "pre_diagnostic_gate_blocked"}
{"timestamp": "2026-11-15T18:08:17.446173+00:00", "agent": "AgenticAttackDetector", "latency_ms": 66.76, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Dangerous command execution function detected in C++ source: system(", "event": "attack_detected", "error_category": "security_violation", "event_id": "evt-1ac975ec1adc", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "blocked"}
{"timestamp": "2026-11-15T18:08:17.591988+00:00", "agent": "AssessmentEngine", "latency_ms": 0.0, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Pre-diagnostic gate blocked by detected agentic attack: Dangerous command execution function detected in C++ source: system(", "event": "gate_blocked", "error_category": "security_violation", "event_id": "evt-1ac975ec1adc", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "pre_diagnostic_gate_blocked"}
{"timestamp": "2026-11-15T18:10:45.782724+00:00", "agent": "AgenticAttackDetector", "latency_ms": 68.87, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Dangerous command execution function detected in C++ source: system(", "event": "attack_detected", "error_category": "security_violation", "event_id": "evt-24c9122140ac", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "blocked"}
{"timestamp": "2026-11-15T18:10:45.947639+00:00", "agent": "AssessmentEngine", "latency_ms": 0.0, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Pre-diagnostic gate blocked by detected agentic attack: Dangerous command execution function detected in C++ source: system(", "event": "gate_blocked", "error_category": "security_violation", "event_id": "evt-24c9122140ac", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "pre_diagnostic_gate_blocked"}
{"timestamp": "2026-11-15T18:55:46.851823+00:00", "agent": "AgenticAttackDetector", "latency_ms": 15.14, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Dangerous command execution function detected in C++ source: system(", "event": "attack_detected", "error_category": "security_violation", "event_id": "evt-0ba6cfbb4aa7", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "blocked"}
{"timestamp": "2026-11-15T18:55:46.887125+00:00", "agent": "AssessmentEngine", "latency_ms": 0.0, "success": false, "fallback": false, "prompt_tokens": null, "completion_tokens": null, "total_tokens": null, "error": "Pre-diagnostic gate blocked by detected agentic attack: Dangerous command execution function detected in C++ source: system(", "event": "gate_blocked", "error_category": "security_violation", "event_id": "evt-0ba6cfbb4aa7", "attack_category": "command_execution", "severity": "critical", "decision": "BLOCK", "requested_action": "BLOCK", "enforcement_outcome": "pre_diagnostic_gate_blocked"}
