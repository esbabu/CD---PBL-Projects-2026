"""Source localization module for CD_Project.

Determines the authoritative source line and snippet for C++ diagnostics using
actual code and parser evidence, strictly avoiding blind fallbacks to line 1.

Evidence Priority (Goal 1):
1. Explicit source line/range produced by the deterministic lexer/parser/error detector.
2. Token associated with the actual malformed construct.
3. AST node/source span associated with the construct.
4. Compiler diagnostic location, when available.
5. Inferred location from nearby tokens/constructs.
Fallback: Explicitly mark location as uncertain (line=0, uncertain=True), NEVER line 1.
"""

import os
import re
import subprocess
import tempfile
from typing import Any, Dict, List, Optional, Tuple, Union


def get_compiler_diagnostic_location(
    source_code: str,
    filepath: Optional[str] = None,
    timeout_seconds: float = 3.0,
) -> Tuple[Optional[int], Optional[int], Optional[str]]:
    """Runs a C++ compiler in syntax-only mode to extract compiler diagnostic location.
    
    Returns:
        tuple (line, column, error_message) or (None, None, None)
    """
    if not source_code.strip():
        return None, None, None

    from predict import find_cxx_compiler, get_sanitized_compiler_env
    compiler = find_cxx_compiler()
    if not compiler:
        return None, None, None

    tmp_path = None
    target_path = filepath
    try:
        if not target_path or not os.path.exists(target_path):
            with tempfile.NamedTemporaryFile("w", suffix=".cpp", delete=False, encoding="utf-8") as f:
                f.write(source_code)
                tmp_path = f.name
            target_path = tmp_path

        from compiler_sandbox import run_contained_compiler, CompilerSandboxLimits
        proc = run_contained_compiler(
            [compiler, "-std=c++17", "-fsyntax-only", target_path],
            env=get_sanitized_compiler_env(),
            limits=CompilerSandboxLimits(timeout_seconds=timeout_seconds),
        )
        if proc.returncode != 0 and proc.stderr:
            # Pattern: <path>:<line>:<col>: error: <msg>
            m = re.search(r":(\d+):(?:\d+:)?\s*(?:error|fatal error):\s*(.*)", proc.stderr)
            if m:
                line = int(m.group(1))
                msg = m.group(2).strip()
                col_match = re.search(r":\d+:(\d+):\s*(?:error|fatal error):", proc.stderr)
                col = int(col_match.group(1)) if col_match else None
                return line, col, msg
    except Exception:
        pass
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
    return None, None, None


def get_token_construct_location(
    source_code: str,
    tokens: Optional[List[Dict[str, Any]]] = None,
    error_type: Optional[str] = None,
) -> Tuple[Optional[int], Optional[str]]:
    """Inspects the token stream for suspicious or malformed constructs."""
    if not tokens:
        try:
            from lexer import tokenize_source
            tokens = tokenize_source(source_code, clean=True)
        except Exception:
            tokens = []

    if not tokens:
        return None, None

    code_lines = source_code.splitlines()

    # Look for unattached/standalone identifiers inside function bodies
    # Example: int main() { start return 0; } -> 'start' on line 5
    inside_body = 0
    type_keywords = {
        "int", "float", "double", "char", "bool", "void", "long", "short",
        "unsigned", "signed", "string", "auto"
    }
    stmt_keywords = {
        "if", "else", "while", "for", "switch", "case", "default", "return",
        "break", "continue", "goto"
    }

    for idx, tok in enumerate(tokens):
        val = tok.get("token_value", "")
        ttype = tok.get("token_type", "")
        tline = tok.get("line", 0)

        if ttype == "OPEN_BRACE":
            inside_body += 1
        elif ttype == "CLOSE_BRACE":
            inside_body = max(0, inside_body - 1)

        if inside_body > 0 and ttype == "IDENTIFIER":
            prev_tok = tokens[idx - 1] if idx > 0 else None
            next_tok = tokens[idx + 1] if idx + 1 < len(tokens) else None

            # Skip if preceded by a type keyword (valid declaration start like 'int x')
            if prev_tok and prev_tok.get("token_value") in type_keywords:
                continue

            # Skip function names like 'main' (which have OPEN_PAREN next)
            if next_tok and next_tok.get("token_type") == "OPEN_PAREN":
                continue

            # Skip if followed by assignment operator (valid assignment LHS)
            if next_tok and next_tok.get("token_value") == "=":
                continue

            # Check if followed by another statement keyword without semicolon
            if next_tok and (next_tok.get("token_value") in stmt_keywords or next_tok.get("token_value") in type_keywords):
                snippet = code_lines[tline - 1].strip() if 1 <= tline <= len(code_lines) else val
                return tline, snippet

            # Check if this token is on a statement line without semicolon
            if 1 <= tline <= len(code_lines):
                line_str = code_lines[tline - 1].strip()
                if not line_str.endswith(";") and not line_str.endswith("{") and not line_str.endswith("}"):
                    if error_type in ("INVALID_DECLARATION", "MISSING_SEMICOLON", "INVALID_FUNCTION_DECL", "EXTRA_TOKENS", None):
                        return tline, line_str

    return None, None


def resolve_source_location(
    source_code: str,
    error_type: Optional[str] = None,
    parse_errors: Optional[List[str]] = None,
    source_errors: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None,
    tokens: Optional[List[Dict[str, Any]]] = None,
    ast_root: Optional[Any] = None,
    filepath: Optional[str] = None,
    compiler_output: Optional[str] = None,
) -> Tuple[int, str, bool]:
    """Authoritative source error localization honoring Goal 1 priorities.
    
    Priority:
    1. Explicit source line/range produced by the deterministic lexer/parser/error detector.
    2. Token associated with the actual malformed construct.
    3. AST node/source span associated with the construct.
    4. Compiler diagnostic location, when available.
    5. Inferred location from nearby tokens/patterns.
    
    Returns:
        (line, context_snippet, is_uncertain)
        NEVER defaults to line 1 on missing information.
    """
    code_lines = source_code.splitlines() if source_code else []
    if not code_lines:
        return 0, "", True

    def get_line_snippet(ln: int) -> str:
        if 1 <= ln <= len(code_lines):
            return code_lines[ln - 1].strip()
        return ""

    if error_type == "INVALID_CPP_STRUCTURE":
        for idx, line in enumerate(code_lines, 1):
            if line.strip():
                return idx, line.strip(), False
        return 1, "", False

    # Priority 1: Deterministic source_errors / parse_errors with explicit line
    if source_errors:
        if isinstance(source_errors, dict):
            if error_type and error_type in source_errors:
                se = source_errors[error_type]
                if se.get("line", 0) > 0:
                    ln = se["line"]
                    return ln, se.get("context") or get_line_snippet(ln), False
            for et, se in source_errors.items():
                if se.get("line", 0) > 0:
                    ln = se["line"]
                    return ln, se.get("context") or get_line_snippet(ln), False
        elif isinstance(source_errors, list):
            if error_type:
                for se in source_errors:
                    if se.get("type") == error_type and se.get("line", 0) > 0:
                        ln = se["line"]
                        return ln, se.get("context") or get_line_snippet(ln), False
            for se in source_errors:
                if se.get("line", 0) > 0:
                    ln = se["line"]
                    return ln, se.get("context") or get_line_snippet(ln), False

    if parse_errors:
        for pe in parse_errors:
            if error_type and error_type in pe:
                m = re.search(r"line\s+(\d+)", pe)
                if m:
                    ln = int(m.group(1))
                    if 1 <= ln <= len(code_lines):
                        return ln, get_line_snippet(ln), False
        for pe in parse_errors:
            m = re.search(r"line\s+(\d+)", pe)
            if m:
                ln = int(m.group(1))
                if 1 <= ln <= len(code_lines):
                    return ln, get_line_snippet(ln), False

    # Priority 2: Token associated with actual malformed construct
    tok_line, tok_snippet = get_token_construct_location(source_code, tokens=tokens, error_type=error_type)
    if tok_line and 1 <= tok_line <= len(code_lines):
        return tok_line, tok_snippet or get_line_snippet(tok_line), False

    # Priority 3: AST node / source span associated with construct
    if ast_root:
        try:
            candidates = []
            def walk(node):
                if getattr(node, "line", 0) > 0:
                    ntype = getattr(node, "node_type", "")
                    val = getattr(node, "value", "")
                    if "Error" in ntype or val == error_type:
                        candidates.append((node.line, 10))
                    elif error_type == "INVALID_FUNCTION_DECL" and ntype == "FuncDeclNode":
                        candidates.append((node.line, 5))
                    elif ntype in ("ExprStmtNode", "VarDeclNode"):
                        candidates.append((node.line, 3))
                for child in getattr(node, "children", []):
                    walk(child)
            walk(ast_root)
            if candidates:
                candidates.sort(key=lambda x: -x[1])
                best_line = candidates[0][0]
                if 1 <= best_line <= len(code_lines):
                    return best_line, get_line_snippet(best_line), False
        except Exception:
            pass

    # Priority 4: Compiler diagnostic location
    if compiler_output:
        m = re.search(r":(\d+):(?:\d+:)?\s*(?:error|fatal error):", compiler_output)
        if m:
            comp_line = int(m.group(1))
            if 1 <= comp_line <= len(code_lines):
                return comp_line, get_line_snippet(comp_line), False
    else:
        comp_line, _, _ = get_compiler_diagnostic_location(source_code, filepath=filepath)
        if comp_line and 1 <= comp_line <= len(code_lines):
            return comp_line, get_line_snippet(comp_line), False

    # Priority 5: Inferred location from nearby tokens / heuristics
    try:
        from predict import infer_error_line
        inferred_line = infer_error_line(parse_errors or [], source_errors or {}, error_type, code_lines)
        if inferred_line and 1 <= inferred_line <= len(code_lines):
            return inferred_line, get_line_snippet(inferred_line), False
    except Exception:
        pass

    # Never fall back to line 1 merely because no location was found!
    return 0, "", True
