import pandas as pd
from dataclasses import dataclass, field
from typing import List, Any, Tuple, Dict



@dataclass
class ASTNode:
    node_type : str
    value     : str = "" 
    line      : int = 0
    children  : List[Any] = field(default_factory=list)


    def add(self, child):
        if child:
            self.children.append(child)


    def __repr__(self, indent=0):
        pad = "  " * indent
        s   = f"{pad}[{self.node_type}]"
        if self.value:
            s += f"  '{self.value}'"
        if self.line:
            s += f"  (line {self.line})"
        for c in self.children:
            s += "\n" + c.__repr__(indent + 1)
        return s




class Cursor:
    def __init__(self, tokens): 
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset=0):
        i = self.pos + offset
        return self.tokens[i] if i < len(self.tokens) else None

    def consume(self): 
        t = self.tokens[self.pos] if self.pos < len(self.tokens) else None
        self.pos += 1
        return t

    def done(self): 
        return self.pos >= len(self.tokens)

    def is_type(self, *types):
        t = self.peek()
        return t is not None and t["token_type"] in types

    def is_value(self, *vals):
        t = self.peek()
        return t is not None and t["token_value"] in vals


#variable types
TYPE_KW = {"int","float","double","char","bool","void",
           "long","short","unsigned","signed","string","auto"}

class Parser:
    def __init__(self, tokens):
        self.cur    = Cursor(tokens)
        self.errors = []
        self.error_nodes = []

    def err(self, msg):
        t   = self.cur.peek()
        loc = f"line {t['line']}" if t else "EOF"
        self.errors.append(f"[ParseError @ {loc}] {msg}")

    def is_type_kw(self, tok):
        return tok and tok["token_type"] == "KEYWORD" and tok["token_value"] in TYPE_KW

    def is_func_decl(self):
        t0, t1, t2 = self.cur.peek(0), self.cur.peek(1), self.cur.peek(2)
        if not (t0 and t1 and t2): return False
        return (self.is_type_kw(t0) and
                t1["token_type"] == "IDENTIFIER" and
                t2["token_type"] == "OPEN_PAREN")

    def is_var_decl(self):
        t0, t1 = self.cur.peek(0), self.cur.peek(1)
        if not (t0 and t1): return False
        return self.is_type_kw(t0) and t1["token_type"] in ("IDENTIFIER","KEYWORD","OPEN_BRACKET")

    def parse(self):
        root = ASTNode("ProgramNode", line=1)
        while not self.cur.done():
            if self.cur.is_type("HASH"):      self.skip_directive()
            elif self.is_func_decl():         root.add(self.parse_func_decl())
            elif self.is_var_decl():          root.add(self.parse_var_decl())
            else:                             self.cur.consume()
        return root

    #skpis hash lines and defines
    def skip_directive(mytoken):
        ln = mytoken.cur.peek()["line"]
        while not mytoken.cur.done() and mytoken.cur.peek()["line"] == ln:
            mytoken.cur.consume()


    def parse_func_decl(mytoken):
        ret  = mytoken.cur.consume()
        name = mytoken.cur.consume()
        node = ASTNode("FunctionDeclNode",
                       value=f"{ret['token_value']} {name['token_value']}",
                       line=ret["line"])
        if mytoken.cur.is_type("OPEN_PAREN"):
            mytoken.cur.consume()
            depth = 1
            while not mytoken.cur.done() and depth > 0:
                if mytoken.cur.is_type("OPEN_PAREN"):  depth += 1
                if mytoken.cur.is_type("CLOSE_PAREN"): depth -= 1
                mytoken.cur.consume()
        if mytoken.cur.is_type("OPEN_BRACE"):
            node.add(mytoken.parse_compound())
        else:
            mytoken.err(f"Missing '{{' after function — INVALID_FUNCTION_DECL")
            node.add(ASTNode("ErrorNode", value="INVALID_FUNCTION_DECL", line=name["line"]))
        return node


    def parse_compound(mytoken):
        tok  = mytoken.cur.consume()
        node = ASTNode("CompoundStmtNode", value="{}", line=tok["line"])
        while not mytoken.cur.done() and not mytoken.cur.is_type("CLOSE_BRACE"):
            node.add(mytoken.parse_stmt())
        if mytoken.cur.is_type("CLOSE_BRACE"):
            mytoken.cur.consume()
        else:
            mytoken.err("Missing '}' — UNMATCHED_BRACE")
            node.add(ASTNode("ErrorNode", value="UNMATCHED_BRACE", line=tok["line"]))
        return node


    def parse_stmt(mytoken):
        t = mytoken.cur.peek()
        if not t: return None
        ty, val = t["token_type"], t["token_value"]
        if ty == "HASH":                         mytoken.skip_directive(); return None
        if ty == "KEYWORD" and val == "if":      return mytoken.parse_if()
        if ty == "KEYWORD" and val == "else":    return mytoken.parse_else()
        if ty == "KEYWORD" and val == "while":   return mytoken.parse_while()
        if ty == "KEYWORD" and val == "for":     return mytoken.parse_for()
        if ty == "KEYWORD" and val == "return":  return mytoken.parse_return()
        if ty == "OPEN_BRACE":                   return mytoken.parse_compound()
        if mytoken.is_func_decl():                  return mytoken.parse_func_decl()
        if mytoken.is_var_decl():                   return mytoken.parse_var_decl()
        return mytoken.parse_expr_stmt()


    def parse_if(mytoken):
        tok  = mytoken.cur.consume()
        node = ASTNode("IfStmtNode", line=tok["line"])
        if mytoken.cur.is_type("OPEN_PAREN"):
            node.add(mytoken.parse_paren_expr())
        else:
            mytoken.err("Missing '(' after if — INVALID_CONDITIONAL")
            node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
        if mytoken.cur.is_type("OPEN_BRACE"): node.add(mytoken.parse_compound())
        else:                              node.add(mytoken.parse_stmt())
        return node

    def parse_else(mytoken):
        tok  = mytoken.cur.consume()
        node = ASTNode("ElseStmtNode", line=tok["line"])
        if mytoken.cur.is_type("OPEN_BRACE"):   node.add(mytoken.parse_compound())
        elif mytoken.cur.is_value("if"):        node.add(mytoken.parse_if())
        else:                                node.add(mytoken.parse_stmt())
        return node

    def parse_while(mytoken):
        tok  = mytoken.cur.consume()
        node = ASTNode("WhileStmtNode", line=tok["line"])
        if mytoken.cur.is_type("OPEN_PAREN"):
            node.add(mytoken.parse_paren_expr())
        else:
            mytoken.err("Missing '(' after while — INVALID_LOOP")
            node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=tok["line"]))
        if mytoken.cur.is_type("OPEN_BRACE"): node.add(mytoken.parse_compound())
        return node

    def parse_for(mytoken):
        tok  = mytoken.cur.consume()
        node = ASTNode("ForStmtNode", line=tok["line"])
        if mytoken.cur.is_type("OPEN_PAREN"):
            node.add(mytoken.parse_paren_expr())
        else:
            mytoken.err("Missing '(' after for — INVALID_LOOP")
            node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=tok["line"]))
        if mytoken.cur.is_type("OPEN_BRACE"): node.add(mytoken.parse_compound())
        return node

    def parse_return(mytoken):
        tok  = mytoken.cur.consume()
        node = ASTNode("ReturnStmtNode", line=tok["line"])
        while not mytoken.cur.done() and not mytoken.cur.is_type("SEMICOLON","CLOSE_BRACE"):
            t = mytoken.cur.consume()
            node.add(ASTNode("ExprNode", value=t["token_value"], line=t["line"]))
        if mytoken.cur.is_type("SEMICOLON"):
            mytoken.cur.consume()
        else:
            mytoken.err("Missing ';' after return — MISSING_SEMICOLON")
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=tok["line"]))
        return node

  

    def parse_var_decl(mytoken):
        type_tok = mytoken.cur.consume()
        node     = ASTNode("VarDeclNode", value=type_tok["token_value"], line=type_tok["line"])

        if mytoken.cur.is_type("KEYWORD") and mytoken.cur.peek()["token_value"] in TYPE_KW:
            extra = mytoken.cur.consume()
            node.add(ASTNode("ErrorNode", value="INVALID_TYPE", line=extra["line"]))
            mytoken.err(f"Consecutive type keywords — INVALID_TYPE at line {extra['line']}")

        if mytoken.cur.is_type("IDENTIFIER"):
            name_tok   = mytoken.cur.consume()
            node.value += f" {name_tok['token_value']}"

            if mytoken.cur.is_type("OPEN_BRACKET"):
                arr = ASTNode("ArrayDeclNode", value=name_tok["token_value"], line=name_tok["line"])
                mytoken.cur.consume()
                if mytoken.cur.is_type("CLOSE_BRACKET"):
                    mytoken.cur.consume()
                else:
                    mytoken.err("Missing ']' — INVALID_ARRAY_DECL")
                    arr.add(ASTNode("ErrorNode", value="INVALID_ARRAY_DECL", line=name_tok["line"]))
                node.add(arr)

            elif mytoken.cur.is_type("OPERATOR") and mytoken.cur.peek()["token_value"] == "=":
                op   = mytoken.cur.consume()
                asgn = ASTNode("AssignExprNode", value="=", line=op["line"])
                while not mytoken.cur.done() and not mytoken.cur.is_type("SEMICOLON","CLOSE_BRACE"):
                    r = mytoken.cur.consume()
                    asgn.add(ASTNode("ExprNode", value=r["token_value"], line=r["line"]))
                node.add(asgn)

        elif mytoken.cur.is_type("INTEGER","STRING"):
            lit = mytoken.cur.consume()
            node.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=lit["line"]))
            mytoken.err(f"Literal as lvalue — INVALID_ASSIGNMENT at line {lit['line']}")

        if mytoken.cur.is_type("SEMICOLON"):
            mytoken.cur.consume()
        elif not mytoken.cur.is_type("CLOSE_BRACE"):
            ln = mytoken.cur.peek()["line"] if mytoken.cur.peek() else "?"
            mytoken.err(f"Missing ';' — MISSING_SEMICOLON at line {ln}")
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=type_tok["line"]))
        return node


    def parse_expr_stmt(mytoken):
        t    = mytoken.cur.peek()
        node = ASTNode("ExprStmtNode", line=t["line"] if t else 0)

        if mytoken.cur.is_type("INTEGER","STRING"):
            lit = mytoken.cur.consume()
            if mytoken.cur.is_type("OPERATOR") and mytoken.cur.peek()["token_value"] == "=":
                mytoken.cur.consume()
                node.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=lit["line"]))
                mytoken.err(f"Literal lvalue — INVALID_ASSIGNMENT at line {lit['line']}")

        while not mytoken.cur.done() and not mytoken.cur.is_type("SEMICOLON","CLOSE_BRACE","OPEN_BRACE"):
            tok = mytoken.cur.consume()
            node.add(ASTNode("ExprNode", value=tok["token_value"], line=tok["line"]))

        if mytoken.cur.is_type("SEMICOLON"):
            mytoken.cur.consume()
        elif not mytoken.cur.is_type("CLOSE_BRACE","OPEN_BRACE"):
            mytoken.err("Missing ';' — MISSING_SEMICOLON")
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON",
                             line=mytoken.cur.peek()["line"] if mytoken.cur.peek() else 0))
        return node


    def parse_paren_expr(mytoken):
        tok   = mytoken.cur.consume()
        node  = ASTNode("ConditionNode", line=tok["line"])
        depth = 1
        while not mytoken.cur.done() and depth > 0:
            t = mytoken.cur.peek()
            if t["token_type"] == "OPEN_PAREN":  depth += 1
            if t["token_type"] == "CLOSE_PAREN":
                depth -= 1
                if depth == 0:
                    mytoken.cur.consume(); break
            ct = mytoken.cur.consume()
            node.add(ASTNode("ExprNode", value=ct["token_value"], line=ct["line"]))
        if depth != 0:
            mytoken.err("Unmatched '(' — UNMATCHED_PARANTHESES")
            node.add(ASTNode("ErrorNode", value="UNMATCHED_PARANTHESES", line=tok["line"]))
        return node




def build_ast(token_rows):
    """
    token_rows : list of dicts for ONE file from tokens.csv
    returns    : (ASTNode root, list of parse error strings)
    """
    p    = Parser(token_rows)
    root = p.parse()
    return root, p.errors




if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "tokens.csv"
    df   = pd.read_csv(path)

    first = df["file_name"].iloc[0]
    rows  = df[df["file_name"] == first].to_dict("records")

    print(f"\n[FILE]   {first}")
    print(f"[TOKENS] {len(rows)}\n")

    ast, errs = build_ast(rows)
    print("── AST ──")
    print(ast)
    if errs:
        print("\n── PARSE ERRORS ──")
        for e in errs:
            print(" ", e)