import argparse
import datetime
import hashlib
import hmac
import json
import os
import secrets
from typing import Any, Dict, Optional

PKL_FILES = ["model.pkl", "scaler.pkl", "label_encoder.pkl"]
TRUSTED_KEYS_DIR = "trusted_keys"
DEFAULT_KEY_FILENAME = "model_signing.key"
ALGORITHM = "HMAC-SHA256"
MANIFEST_VERSION = "2.0"


def compute_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def get_trusted_signing_key(
    base_dir: Optional[str] = None,
    create_if_missing: bool = True,
    key_filename: str = DEFAULT_KEY_FILENAME,
) -> bytes:
    """
    Retrieves the trusted verification/signing key from an environment variable or
    a separate dedicated trusted key directory outside the models directory.
    If missing and create_if_missing is True, generates a cryptographically secure key.
    """
    # 1. Environment variable override
    env_key = os.environ.get("MODEL_SIGNING_KEY") or os.environ.get("MODEL_VERIFICATION_KEY")
    if env_key:
        return env_key.strip().encode("utf-8")

    # 2. Local trusted key store
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    key_dir = os.path.join(base_dir, TRUSTED_KEYS_DIR)
    key_path = os.path.join(key_dir, key_filename)

    # Also check project root if base_dir was a subdirectory (e.g. models/candidates)
    if not os.path.exists(key_path):
        root_dir = os.path.dirname(os.path.abspath(__file__))
        root_key_path = os.path.join(root_dir, TRUSTED_KEYS_DIR, key_filename)
        if os.path.exists(root_key_path):
            key_path = root_key_path

    if os.path.exists(key_path):
        with open(key_path, "rb") as f:
            key_data = f.read().strip()
            if key_data:
                return key_data

    if not create_if_missing:
        raise FileNotFoundError(
            f"Trusted signing key not found at {key_path}. "
            "Ensure the key is provisioned or set MODEL_SIGNING_KEY environment variable."
        )

    # 3. Secure automatic provisioning in separate trusted directory
    os.makedirs(os.path.dirname(key_path), exist_ok=True)
    generated_key = secrets.token_hex(32).encode("utf-8")
    with open(key_path, "wb") as f:
        f.write(generated_key)
    try:
        # Restrict permissions on POSIX if available
        os.chmod(key_path, 0o600)
    except Exception:
        pass

    return generated_key


def compute_manifest_signature(checksums_dict: Dict[str, Any], key: bytes) -> str:
    """
    Computes a cryptographic HMAC-SHA256 signature over the canonicalized artifact hashes.
    Canonical format sorts the artifacts deterministically:
    label_encoder.pkl:<hash>\nmodel.pkl:<hash>\nscaler.pkl:<hash>
    """
    lines = []
    for filename in sorted(PKL_FILES):
        file_hash = checksums_dict.get(filename, "")
        lines.append(f"{filename}:{file_hash}")
    payload = "\n".join(lines).encode("utf-8")
    return hmac.new(key, payload, hashlib.sha256).hexdigest()


def verify_manifest_signature(checksums_dict: Dict[str, Any], key: bytes) -> bool:
    """
    Verifies that the manifest's cryptographic signature matches the trusted key.
    """
    declared_sig = checksums_dict.get("signature")
    if not declared_sig or not isinstance(declared_sig, str):
        return False
    expected_sig = compute_manifest_signature(checksums_dict, key)
    return hmac.compare_digest(declared_sig.strip().lower(), expected_sig.lower())


def sign_manifest(
    checksums_dict: Dict[str, Any],
    key: Optional[bytes] = None,
    base_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Attaches a cryptographic signature and release metadata to a checksum dictionary.
    """
    if key is None:
        key = get_trusted_signing_key(base_dir=base_dir, create_if_missing=True)

    sig = compute_manifest_signature(checksums_dict, key)
    checksums_dict["manifest_version"] = MANIFEST_VERSION
    checksums_dict["algorithm"] = ALGORITHM
    checksums_dict["signature"] = sig
    checksums_dict["signed_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    return checksums_dict


def make_checksums(
    output_file: str = "model_checksums.json",
    base_dir: Optional[str] = None,
    sign: bool = True,
) -> Dict[str, Any]:
    """
    Computes SHA-256 hashes for all model artifacts, signs the manifest using the
    trusted key in the separate key directory, and persists the authenticated manifest.
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    checksums: Dict[str, Any] = {}
    for filename in PKL_FILES:
        filepath = os.path.join(base_dir, filename)
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Artifact {filename} not found at {filepath}")
        checksums[filename] = compute_sha256(filepath)

    if sign:
        key = get_trusted_signing_key(base_dir=base_dir, create_if_missing=True)
        sign_manifest(checksums, key=key)

    target_path = os.path.join(base_dir, output_file)
    with open(target_path, "w", encoding="utf-8") as f:
        json.dump(checksums, f, indent=2)

    print(f"Wrote authenticated checksums to {target_path}:")
    for k, v in checksums.items():
        print(f"  {k}: {v}")
    return checksums


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate and cryptographically sign model artifact checksums.")
    parser.add_argument("--output", default="model_checksums.json", help="Output JSON path")
    parser.add_argument("--no-sign", action="store_true", help="Generate unsigned checksums (testing only)")
    parser.add_argument("--migrate-legacy", action="store_true", help="Migrate and sign existing legacy unsigned manifest")
    args = parser.parse_args()

    if args.migrate_legacy:
        base = os.path.dirname(os.path.abspath(__file__))
        target = os.path.join(base, args.output)
        if not os.path.exists(target):
            raise FileNotFoundError(f"Legacy manifest not found at {target}")
        with open(target, "r", encoding="utf-8") as f:
            data = json.load(f)
        key = get_trusted_signing_key(base_dir=base, create_if_missing=True)
        sign_manifest(data, key=key)
        with open(target, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"[SUCCESS] Migrated and cryptographically signed legacy manifest: {target}")
    else:
        make_checksums(output_file=args.output, sign=not args.no_sign)

