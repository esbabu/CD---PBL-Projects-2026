import os
import re
import csv
import sys
from collections import defaultdict


CPP_KEYWORDS = {
    "int", "float", "double", "char", "bool", "void", "long", "short",
    "unsigned", "signed", "const", "static", "extern", "register", "volatile",
    "if", "else", "while", "for", "do", "switch", "case", "default",
    "break", "continue", "return", "goto",
    "class", "struct", "union", "enum", "typedef", "namespace", "using",
    "public", "private", "protected", "virtual", "override", "final",
    "new", "delete", "this", "nullptr", "NULL", "true", "false",
    "include", "define", "ifdef", "ifndef", "endif", "pragma",
    "template", "typename", "operator", "sizeof", "typeof",
    "try", "catch", "throw",
    "auto", "inline", "explicit", "friend", "mutable",
}


TOKEN_SPEC = [
    ("HASH",          r"#"),
    ("STRING",        r'"(?:[^"\\\r\n]|\\.)*"?'),    
    ("CHAR",          r"'(?:[^'\\\r\n]|\\.)*'?"),        
    ("FLOAT",         r"\b\d+\.\d*([eE][+-]?\d+)?\b|\b\d*\.\d+([eE][+-]?\d+)?\b"),
    ("INTEGER",       r"\b\d+\b"),
    ("IDENTIFIER",    r"\b[a-zA-Z_][a-zA-Z0-9_]*\b"),
    ("SEMICOLON",     r";"),
    ("OPEN_PAREN",    r"\("),
    ("CLOSE_PAREN",   r"\)"),
    ("OPEN_BRACE",    r"\{"),
    ("CLOSE_BRACE",   r"\}"),
    ("OPEN_BRACKET",  r"\["),
    ("CLOSE_BRACKET", r"\]"),
    ("OPERATOR",      r"[+\-*/%=<>!&|^~?:.,]+"),
    ("NEWLINE",       r"\n"),
    ("WHITESPACE",    r"[ \t\r]+"),
    ("UNKNOWN",       r"."),
]

MASTER_REGEX = re.compile(
    "|".join(f"(?P<{name}>{pattern})" for name, pattern in TOKEN_SPEC)
)


def extract_label(filename):
    """
    Extract class label from filename.
    Handles formats:
        aug_3_INVALID_ASSIGNMENT.cpp   → INVALID_ASSIGNMENT
        var0_51_MISSING_SEMICOLON.cpp  → MISSING_SEMICOLON
        INVALID_ASSIGNMENT_001.cpp     → INVALID_ASSIGNMENT
    """
    name = filename.replace(".cpp", "")
    parts = name.split("_")

   
    label_parts = []
    found = False
    for part in parts:
        if found:
            label_parts.append(part)
        elif part.isupper() and not part.isdigit():
            label_parts.append(part)
            found = True

    if label_parts:
        return "_".join(label_parts)

  
    return name.upper()


def scan_raw_string(code, i):
    """Scan a C++ raw string literal starting at index i (where code[i] == 'R').
    Returns (start_idx, end_idx, is_closed) tuple or None if not a raw string.
    Supports R"(...)" and custom delimiter sequences R"delim(...)delim" up to 16 chars.
    """
    n = len(code)
    if i + 1 >= n or code[i + 1] != '"':
        return None
    paren_idx = code.find('(', i + 2)
    if paren_idx == -1 or paren_idx - (i + 2) > 16:
        return None
    delim = code[i + 2:paren_idx]
    for ch in delim:
        if ch in (' ', '(', ')', '\\', '\t', '\n', '\r'):
            return None
    close_seq = ')' + delim + '"'
    close_idx = code.find(close_seq, paren_idx + 1)
    if close_idx == -1:
        return (i, n, False)  # Unterminated raw string literal
    return (i, close_idx + len(close_seq), True)


def strip_comments(code):
    """Remove // and /* */ comments before tokenizing, while preserving
    comment markers inside double-quoted strings, raw string literals,
    and character literals. Preserves line breaks for multiline comments
    to maintain source line numbering.
    """
    if not code:
        return code

    result = []
    n = len(code)
    i = 0

    while i < n:
        # 1. Raw string literal R"delim(...)delim"
        if code[i] == 'R' and i + 1 < n and code[i + 1] == '"':
            raw_res = scan_raw_string(code, i)
            if raw_res is not None:
                start_i, end_i, is_closed = raw_res
                result.append(code[start_i:end_i])
                i = end_i
                continue

        # 2. Line comment //
        if i + 1 < n and code[i] == '/' and code[i + 1] == '/':
            i += 2
            while i < n and code[i] not in ('\n', '\r'):
                i += 1
            # Real comment text is removed; trailing newline will be handled by outer loop
            continue

        # 3. Block comment /*
        if i + 1 < n and code[i] == '/' and code[i + 1] == '*':
            end_idx = code.find("*/", i + 2)
            if end_idx == -1:
                # Unterminated block comment: leave intact per existing contract
                result.append(code[i:])
                break
            comment_text = code[i:end_idx + 2]
            # Preserve line breaks so line numbers remain aligned
            newlines = [m.group(0) for m in re.finditer(r'\r\n|\r|\n', comment_text)]
            if newlines:
                result.append("".join(newlines))
            i = end_idx + 2
            continue

        # 4. Double-quoted string literal "
        if code[i] == '"':
            result.append('"')
            i += 1
            while i < n:
                ch = code[i]
                if ch == '\\':
                    result.append(ch)
                    i += 1
                    if i < n:
                        result.append(code[i])
                        i += 1
                elif ch == '"':
                    result.append(ch)
                    i += 1
                    break
                elif ch == '\n' or ch == '\r':
                    # Unterminated string literal on this line: stop scanning literal
                    break
                else:
                    result.append(ch)
                    i += 1
            continue

        # 5. Single-quoted character literal '
        if code[i] == "'":
            result.append("'")
            i += 1
            while i < n:
                ch = code[i]
                if ch == '\\':
                    result.append(ch)
                    i += 1
                    if i < n:
                        result.append(code[i])
                        i += 1
                elif ch == "'":
                    result.append(ch)
                    i += 1
                    break
                elif ch == '\n' or ch == '\r':
                    # Unterminated character literal on this line: stop scanning literal
                    break
                else:
                    result.append(ch)
                    i += 1
            continue

        # 6. Normal source code character
        result.append(code[i])
        i += 1

    return "".join(result)


def mask_comments(code):
    """Mask C++ comments with whitespace, preserving string literals, character
    literals, raw strings, newlines, line counts, and exact character column offsets.
    Unterminated block comments are left unmasked so downstream lexical/syntax
    analysis can detect the unterminated block comment according to C++ lexical rules.
    """
    if not code:
        return code

    chars = list(code)
    n = len(code)
    i = 0

    while i < n:
        ch = code[i]

        # 1. Raw string literal
        if ch == 'R' and i + 1 < n and code[i + 1] == '"':
            raw_res = scan_raw_string(code, i)
            if raw_res is not None:
                start_i, end_i, is_closed = raw_res
                i = end_i
                continue

        # 2. Double-quoted string literal
        if ch == '"':
            i += 1
            while i < n:
                if code[i] == '\\' and i + 1 < n:
                    i += 2
                    continue
                if code[i] == '"':
                    i += 1
                    break
                if code[i] in ('\n', '\r'):
                    break
                i += 1
            continue

        # 3. Single-quoted character literal
        if ch == "'":
            i += 1
            while i < n:
                if code[i] == '\\' and i + 1 < n:
                    i += 2
                    continue
                if code[i] == "'":
                    i += 1
                    break
                if code[i] in ('\n', '\r'):
                    break
                i += 1
            continue

        # 4. Line comment //
        if ch == '/' and i + 1 < n and code[i + 1] == '/':
            while i < n and code[i] not in ('\n', '\r'):
                chars[i] = ' '
                i += 1
            continue

        # 5. Block comment /* ... */
        if ch == '/' and i + 1 < n and code[i + 1] == '*':
            end_idx = code.find("*/", i + 2)
            if end_idx == -1:
                # Unterminated block comment: leave intact per C++ lexical rules
                break
            for k in range(i, end_idx + 2):
                if code[k] not in ('\n', '\r'):
                    chars[k] = ' '
            i = end_idx + 2
            continue

        i += 1

    return "".join(chars)


def tokenize_source(code, clean=True):
    """
    Tokenize C++ source code string directly.
    Returns list of dicts with keys:
        token_index, token_type, token_value, line, column
    """
    if clean:
        code = strip_comments(code)

    tokens = []
    token_index = 0
    line = 1
    line_start = 0

    for mo in MASTER_REGEX.finditer(code):
        kind = mo.lastgroup
        value = mo.group()
        col = mo.start() - line_start + 1

        if kind == "NEWLINE":
            line += 1
            line_start = mo.end()
            continue

        if kind == "WHITESPACE":
            continue

        if kind == "IDENTIFIER" and value in CPP_KEYWORDS:
            kind = "KEYWORD"

        tokens.append({
            "token_index": token_index,
            "token_type": kind,
            "token_value": value,
            "line": line,
            "column": col,
        })
        token_index += 1

    return tokens


def tokenize_file(filepath):
    """
    Tokenize a single .cpp file.
    Returns list of dicts with keys:
        token_index, token_type, token_value, line, column
    """
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            code = f.read()
    except Exception as e:
        print(f"  Warning: could not read {filepath}: {e}")
        return []

    return tokenize_source(code, clean=True)


def tokenize_file_clean(filepath):
    """Tokenize with comment stripping."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            code = f.read()
    except Exception as e:
        print(f"  Warning: could not read {filepath}: {e}")
        return []

    return tokenize_source(code, clean=True)


def run_lexer(cpp_folder, output_csv):
    """Process all .cpp files in folder and write tokens.csv."""


    cpp_files = sorted([
        f for f in os.listdir(cpp_folder)
        if f.endswith(".cpp")
    ])

    if not cpp_files:
        print(f"ERROR: No .cpp files found in {cpp_folder}")
        sys.exit(1)

    print(f"Found {len(cpp_files)} .cpp files in '{cpp_folder}'")
    print(f"Output: {output_csv}")
    print("Tokenizing...")


    class_counts = defaultdict(int)
    for fname in cpp_files:
        label = extract_label(fname)
        class_counts[label] += 1

    print(f"\nClass distribution:")
    for cls, count in sorted(class_counts.items()):
        print(f"  {cls}: {count} files")
    print()

    total_tokens = 0
    files_processed = 0
    files_failed = 0

    with open(output_csv, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = [
            "file_name", "label",
            "token_index", "token_type", "token_value",
            "line", "column"
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for fname in cpp_files:
            filepath = os.path.join(cpp_folder, fname)
            label = extract_label(fname)

            tokens = tokenize_file_clean(filepath)

            if not tokens:
                print(f"  Warning: no tokens from {fname}")
                files_failed += 1
                continue

            for tok in tokens:
                writer.writerow({
                    "file_name":    fname,
                    "label":        label,
                    "token_index":  tok["token_index"],
                    "token_type":   tok["token_type"],
                    "token_value":  tok["token_value"],
                    "line":         tok["line"],
                    "column":       tok["column"],
                })

            total_tokens += len(tokens)
            files_processed += 1

            if files_processed % 100 == 0:
                print(f"  Processed {files_processed}/{len(cpp_files)} files...")

    print(f"\n✅ Done!")
    print(f"   Files processed : {files_processed}")
    print(f"   Files failed    : {files_failed}")
    print(f"   Total tokens    : {total_tokens}")
    print(f"   Avg tokens/file : {total_tokens // max(files_processed, 1)}")
    print(f"   Output written  : {output_csv}")
    print(f"\nNext step:")
    print(f"   python3 ast_extractor.py {output_csv} features.csv")



if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 lexer.py <cpp_folder> <output_csv>")
        print("Example: python3 lexer.py ./cpp_files tokens.csv")
        sys.exit(1)

    cpp_folder = sys.argv[1]
    output_csv = sys.argv[2]

    if not os.path.isdir(cpp_folder):
        print(f"ERROR: '{cpp_folder}' is not a valid folder")
        sys.exit(1)

    run_lexer(cpp_folder, output_csv)