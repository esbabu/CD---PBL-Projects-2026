# AI Syntax Diagnostics IDE — User Guide

Welcome to the **AI Syntax Diagnostics IDE**, a desktop environment engineered for C++ developers. This guide walks you through the core capabilities of the IDE.

---

## 1. Installation & First Launch

1. Run `AI Syntax Diagnostics IDE Setup 1.0.0.exe`.
2. Because the application installer is unsigned, Windows SmartScreen will prompt for confirmation. Click **"More info"** and then **"Run anyway"**.
3. The application installs directly into your user profile (`%LOCALAPPDATA%\Programs\AI Syntax Diagnostics IDE`) without prompting for administrator elevation.

---

## 2. Editor & Diagnostics Workflow

### Running Diagnostics
- Type or paste your C++ code into the Monaco editor.
- Press **`Ctrl+Enter`** or click **`▶ Run Diagnostic`** in the toolbar.
- The IDE parses your source code and classifies syntax errors using a local machine learning model and AST parser, enhanced by `g++` when available.

### Problems Panel & Squiggles
- Errors are underlined with **red squiggles** in the editor. Hover over any squiggle to inspect error details.
- The **Problems Panel** at the bottom lists all detected syntax issues categorized by line number, context, and suggested fix.

---

## 3. Repair Proposals & Monaco Diff View

1. In the Problems panel, click **`Propose Fix`** next to any detected error.
2. The IDE computes an automatic repair and opens the **Monaco Diff View** (toggleable between Side-by-Side and Inline).
3. **Verification Badges**:
   - `✅ Compiler Verified` (Green): The proposed fix was compiled and verified clean by the local C++ compiler.
   - `⚠️ Heuristic Verification` (Yellow): Verified via AST heuristics; requires confirmation before applying.
   - `❌ Verification Failed` (Red): Fix failed compilation; disabled from accidental application.
4. Click **`Apply`** to merge the fix into your editor buffer, or **`Reject`** to dismiss. You can always undo changes with `Ctrl+Z`.

---

## 4. In-App Dashboards

- **Performance Dashboard**: Click the **`📊 Perf`** toolbar button to inspect diagnostic latency metrics, model inference duration, and compilation benchmarks rendered via local offline Chart.js.
- **Security Dashboard**: Click the **`🛡️ Security`** toolbar button to review the 15 active security protections and view the real-time attack catalog evaluation matrix.

---

## 5. Settings & Secure Key Storage

Press **`Ctrl+,`** or click **`⚙ Settings`** to configure:
- **General**: Switch between Dark and Light themes, or choose between side-by-side and inline diff presentation.
- **Analysis**: Enable auto-analyze on file edit and customize the debounce interval (300 ms – 5000 ms).
- **Compiler**: View detected compiler details, browse to custom `g++`/`clang++` binaries, or reset to auto-detect.
- **AI**: Configure your Google Gemini API key. Stored encrypted on disk using Windows DPAPI (`safeStorage`). Auto-analyze runs **strictly locally** and never transmits code to cloud APIs.

