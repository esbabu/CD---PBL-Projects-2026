"""
model_promoter.py — Atomic Model Promotion, Backup, and Rollback Engine.

Guarantees:
1. Pre-Promotion Verification: Enforces passed evaluation gates, valid training manifest,
   exact 30-feature schema, exact canonical classes, and verified SHA-256 checksums.
2. Complete Pre-Promotion Backup: Captures full snapshot of current production artifacts
   (model.pkl, scaler.pkl, label_encoder.pkl, model_checksums.json) in models/backups/<backup_id>/.
3. Versioned Immutable Release Directories: Creates immutable releases under models/releases/<release_id>/.
4. Single Atomic Manifest/Pointer Switch: Uses a single os.replace() to atomically update
   models/active_release.json pointer, completely eliminating the multi-file race condition.
5. Consistent Reader Resolution: Ongoing or concurrent predictions resolve the immutable release directory
   once via resolve_active_artifacts_dir() and load all 3 artifacts and checksums from that directory.
6. Checksum Synchronization: Keeps model_checksums.json and pointer metadata in exact synchronization.
7. Verifiable Rollback: Supports deterministic rollback to previous backups with full integrity checks.
8. Persistent Audit Logging: Records all promotion and rollback actions in models/promotion_log.json.
"""

from __future__ import annotations

import os
import sys
import json
import shutil
import datetime
from typing import Dict, List, Optional, Any, Tuple

from dataset_versioning import (
    CANONICAL_FEATURE_NAMES, CANONICAL_CLASSES,
    compute_file_sha256, get_git_revision
)


class PromotionError(Exception):
    """Raised when candidate model fails pre-promotion verification or promotion fails."""
    pass


class RollbackError(Exception):
    """Raised when backup restoration fails or backup integrity check fails."""
    pass


def _append_promotion_log(log_path: str, entry: Dict[str, Any]):
    """Appends an event to the persistent promotion audit log."""
    logs = []
    if os.path.exists(log_path):
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                logs = json.load(f)
                if not isinstance(logs, list):
                    logs = []
        except Exception:
            logs = []

    logs.append(entry)
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=2)


def resolve_active_artifacts_dir(base_dir: Optional[str] = None) -> Tuple[str, Optional[Dict[str, Any]]]:
    """
    Resolves the active model release directory in a single atomic pointer read.

    GUARANTEES:
    - Reads models/active_release.json. If present and points to a valid release directory,
      returns (resolved_release_dir, pointer_info).
    - If promotion occurs concurrently, a prediction process that already resolved
      resolved_release_dir continues reading from that immutable directory without observing
      mixed artifact states.
    - Falls back safely to base_dir if active_release.json is absent (legacy root compatibility).
    """
    root_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(root_dir, "models", "active_release.json"),
        os.path.join(root_dir, "active_release.json"),
    ]
    for ptr_file in candidates:
        if os.path.exists(ptr_file):
            try:
                with open(ptr_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                rel_dir = data.get("release_dir")
                if rel_dir:
                    full_rel_dir = rel_dir if os.path.isabs(rel_dir) else os.path.join(root_dir, rel_dir)
                    if os.path.exists(full_rel_dir):
                        return full_rel_dir, data
            except Exception:
                pass

    return root_dir, None


def get_active_model_status(base_dir: Optional[str] = None) -> Dict[str, Any]:
    """Inspects the active production model artifacts and verifies checksums."""
    root_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    artifacts_dir, release_info = resolve_active_artifacts_dir(root_dir)
    checksum_file = os.path.join(artifacts_dir, "model_checksums.json")
    artifacts = ["model.pkl", "scaler.pkl", "label_encoder.pkl"]

    status = {
        "production_ready": True,
        "artifacts_dir": artifacts_dir,
        "active_release_info": release_info,
        "checksums_file_exists": os.path.exists(checksum_file),
        "artifacts_exist": True,
        "checksums_match": True,
        "hashes": {},
        "expected_hashes": {},
    }

    if not status["checksums_file_exists"]:
        status["production_ready"] = False
        return status

    try:
        with open(checksum_file, "r", encoding="utf-8") as f:
            expected = json.load(f)
        status["expected_hashes"] = expected
    except Exception:
        status["production_ready"] = False
        status["checksums_match"] = False
        return status

    for art in artifacts:
        p = os.path.join(artifacts_dir, art)
        if not os.path.exists(p):
            status["artifacts_exist"] = False
            status["production_ready"] = False
            continue
        h = compute_file_sha256(p)
        status["hashes"][art] = h
        if h != expected.get(art):
            status["checksums_match"] = False
            status["production_ready"] = False

    # Check cryptographic signature
    from make_checksums import verify_manifest_signature, get_trusted_signing_key
    sig = expected.get("signature")
    if sig:
        try:
            key = get_trusted_signing_key(base_dir=root_dir, create_if_missing=False)
            status["signature_valid"] = verify_manifest_signature(expected, key)
            if not status["signature_valid"]:
                status["checksums_match"] = False
                status["production_ready"] = False
        except Exception:
            status["signature_valid"] = False
            status["checksums_match"] = False
            status["production_ready"] = False
    else:
        status["signature_valid"] = False
        allow_legacy = os.environ.get("ALLOW_LEGACY_UNSIGNED_MANIFEST", "").strip().lower() in ("1", "true", "yes")
        if not allow_legacy:
            status["checksums_match"] = False
            status["production_ready"] = False

    return status


def create_production_backup(base_dir: Optional[str] = None) -> str:
    """Creates a timestamped snapshot of current production artifacts."""
    root_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_id = f"backup_{timestamp}"
    backup_dir = os.path.join(root_dir, "models", "backups", backup_id)
    os.makedirs(backup_dir, exist_ok=True)

    artifacts_dir, release_info = resolve_active_artifacts_dir(root_dir)
    artifacts = ["model.pkl", "scaler.pkl", "label_encoder.pkl", "model_checksums.json"]

    copied_files = {}
    for art in artifacts:
        src = os.path.join(artifacts_dir, art)
        if os.path.exists(src):
            dst = os.path.join(backup_dir, art)
            shutil.copy2(src, dst)
            copied_files[art] = compute_file_sha256(dst)

    # Also back up pointer if present
    ptr_file = os.path.join(root_dir, "models", "active_release.json")
    if os.path.exists(ptr_file):
        shutil.copy2(ptr_file, os.path.join(backup_dir, "active_release.json"))

    backup_manifest = {
        "backup_id": backup_id,
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source_artifacts_dir": artifacts_dir,
        "release_info": release_info,
        "files": copied_files,
        "git_revision": get_git_revision(root_dir),
    }

    with open(os.path.join(backup_dir, "backup_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(backup_manifest, f, indent=2)

    return backup_id


def promote_candidate(
    candidate_id: str,
    base_dir: Optional[str] = None,
    force: bool = False,
    operator: str = "automated_pipeline",
) -> Dict[str, Any]:
    """
    Safely and atomically promotes a candidate model to production:
    1. Validates candidate manifest, evaluation gates, and artifacts.
    2. Takes pre-promotion backup of current production files.
    3. Writes files into an immutable release directory: models/releases/<release_id>/.
    4. Performs a single atomic pointer switch (os.replace) on models/active_release.json.
    5. Synchronizes root files for backward compatibility.
    6. Records promotion in audit log.
    """
    root_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    cand_dir = os.path.join(root_dir, "models", "candidates", candidate_id)

    if not os.path.exists(cand_dir):
        raise PromotionError(f"Candidate directory not found: {cand_dir}")

    manifest_path = os.path.join(cand_dir, "training_manifest.json")
    if not os.path.exists(manifest_path):
        raise PromotionError(f"Candidate {candidate_id} is missing training_manifest.json")

    with open(manifest_path, "r", encoding="utf-8") as f:
        cand_manifest = json.load(f)

    # 1. Gate Verification
    if not cand_manifest.get("gates_passed", False) and not force:
        raise PromotionError(
            f"Candidate {candidate_id} failed evaluation gates and cannot be promoted: "
            f"{cand_manifest.get('gate_results')}"
        )

    # Verify candidate artifacts exist and checksums match
    req_artifacts = ["model.pkl", "scaler.pkl", "label_encoder.pkl", "model_checksums.json"]
    for art in req_artifacts:
        p = os.path.join(cand_dir, art)
        if not os.path.exists(p):
            raise PromotionError(f"Candidate {candidate_id} is missing artifact: {art}")

    with open(os.path.join(cand_dir, "model_checksums.json"), "r", encoding="utf-8") as f:
        cand_checksums = json.load(f)

    for art in ["model.pkl", "scaler.pkl", "label_encoder.pkl"]:
        actual_h = compute_file_sha256(os.path.join(cand_dir, art))
        expected_h = cand_checksums.get(art)
        if actual_h != expected_h:
            raise PromotionError(
                f"Candidate artifact {art} checksum mismatch! Expected: {expected_h}, Actual: {actual_h}"
            )

    # Verify candidate manifest cryptographic signature
    from make_checksums import verify_manifest_signature, get_trusted_signing_key
    cand_sig = cand_checksums.get("signature")
    if not cand_sig:
        allow_legacy = os.environ.get("ALLOW_LEGACY_UNSIGNED_MANIFEST", "").strip().lower() in ("1", "true", "yes")
        if not allow_legacy and not force:
            raise PromotionError(f"Candidate {candidate_id} model_checksums.json lacks cryptographic signature.")
    else:
        try:
            key = get_trusted_signing_key(base_dir=root_dir, create_if_missing=False)
            if not verify_manifest_signature(cand_checksums, key) and not force:
                raise PromotionError(f"Candidate {candidate_id} model manifest cryptographic signature verification failed!")
        except Exception as e:
            if not force:
                raise PromotionError(f"Cannot verify candidate signature (missing trusted key): {e}")

    # 2. Create Pre-Promotion Backup
    backup_id = create_production_backup(root_dir)

    # 3. Create Immutable Versioned Release Directory
    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S")
    release_id = f"release_{timestamp}_{cand_manifest.get('split_manifest_hash', '')[:8]}"
    release_dir = os.path.join(root_dir, "models", "releases", release_id)
    os.makedirs(release_dir, exist_ok=True)

    for art in req_artifacts:
        shutil.copy2(os.path.join(cand_dir, art), os.path.join(release_dir, art))

    release_manifest = {
        "release_id": release_id,
        "candidate_id": candidate_id,
        "promoted_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "operator": operator,
        "backup_id": backup_id,
        "dataset_version": cand_manifest.get("dataset_version"),
        "split_hash": cand_manifest.get("split_manifest_hash"),
        "test_accuracy": cand_manifest.get("metrics", {}).get("test", {}).get("accuracy"),
        "checksums": cand_checksums,
    }
    with open(os.path.join(release_dir, "release_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(release_manifest, f, indent=2)

    # 4. Atomic Pointer Switch: Stage active_release.json.tmp and atomic os.replace()
    active_pointer = {
        "active_release_id": release_id,
        "release_dir": os.path.relpath(release_dir, root_dir).replace("\\", "/"),
        "promoted_at_utc": release_manifest["promoted_at_utc"],
        "dataset_version": release_manifest["dataset_version"],
        "checksums": cand_checksums,
    }

    ptr_dir = os.path.join(root_dir, "models")
    os.makedirs(ptr_dir, exist_ok=True)
    ptr_file = os.path.join(ptr_dir, "active_release.json")
    ptr_tmp = os.path.join(ptr_dir, f"active_release.tmp.{os.getpid()}")

    with open(ptr_tmp, "w", encoding="utf-8") as f:
        json.dump(active_pointer, f, indent=2)

    # Single atomic pointer switch
    os.replace(ptr_tmp, ptr_file)

    # 5. Synchronize legacy root files for backward compatibility
    for art in ["model.pkl", "scaler.pkl", "label_encoder.pkl", "model_checksums.json"]:
        shutil.copy2(os.path.join(release_dir, art), os.path.join(root_dir, art))

    for viz in ["confusion_matrix.png", "feature_importance.png"]:
        src_viz = os.path.join(cand_dir, viz)
        if os.path.exists(src_viz):
            shutil.copy2(src_viz, os.path.join(root_dir, viz))

    # 6. Verify post-promotion integrity
    post_status = get_active_model_status(root_dir)
    if not post_status["production_ready"]:
        raise PromotionError(f"Post-promotion integrity verification failed: {post_status}")

    # 7. Log promotion event
    log_path = os.path.join(root_dir, "models", "promotion_log.json")
    log_entry = {
        "event": "promote",
        "release_id": release_id,
        "candidate_id": candidate_id,
        "backup_id": backup_id,
        "operator": operator,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "dataset_version": cand_manifest.get("dataset_version"),
        "test_accuracy": cand_manifest.get("metrics", {}).get("test", {}).get("accuracy"),
        "checksums": cand_checksums,
    }
    _append_promotion_log(log_path, log_entry)

    return {
        "status": "promoted",
        "release_id": release_id,
        "candidate_id": candidate_id,
        "backup_id": backup_id,
        "test_accuracy": cand_manifest.get("metrics", {}).get("test", {}).get("accuracy"),
        "checksums": cand_checksums,
    }


def rollback_to_backup(
    backup_id: Optional[str] = None,
    base_dir: Optional[str] = None,
    operator: str = "automated_rollback",
) -> Dict[str, Any]:
    """
    Restores production artifacts from a validated backup.
    If backup_id is None, automatically restores the latest available backup.
    Switches active_release.json pointer atomically.
    """
    root_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    backups_dir = os.path.join(root_dir, "models", "backups")

    if not os.path.exists(backups_dir):
        raise RollbackError("No backups directory found; cannot perform rollback.")

    available_backups = sorted([
        d for d in os.listdir(backups_dir)
        if os.path.isdir(os.path.join(backups_dir, d)) and d.startswith("backup_")
    ])

    if not available_backups:
        raise RollbackError("No valid backups found in models/backups/")

    target_backup = backup_id or available_backups[-1]
    backup_path = os.path.join(backups_dir, target_backup)

    if not os.path.exists(backup_path):
        raise RollbackError(f"Backup {target_backup} not found at {backup_path}")

    manifest_file = os.path.join(backup_path, "backup_manifest.json")
    if not os.path.exists(manifest_file):
        raise RollbackError(f"Backup {target_backup} is missing backup_manifest.json")

    with open(manifest_file, "r", encoding="utf-8") as f:
        b_manifest = json.load(f)

    expected_files = b_manifest.get("files", {})
    for fname, exp_hash in expected_files.items():
        fp = os.path.join(backup_path, fname)
        if not os.path.exists(fp):
            raise RollbackError(f"Backup {target_backup} is missing file: {fname}")
        actual_h = compute_file_sha256(fp)
        if actual_h != exp_hash:
            raise RollbackError(f"Backup file {fname} corrupted! Expected: {exp_hash}, Got: {actual_h}")

    # Restore pointer atomically
    backup_ptr = os.path.join(backup_path, "active_release.json")
    ptr_dir = os.path.join(root_dir, "models")
    os.makedirs(ptr_dir, exist_ok=True)
    ptr_file = os.path.join(ptr_dir, "active_release.json")
    ptr_tmp = os.path.join(ptr_dir, f"active_release.tmp.{os.getpid()}")

    if os.path.exists(backup_ptr):
        shutil.copy2(backup_ptr, ptr_tmp)
        os.replace(ptr_tmp, ptr_file)
    else:
        # Fallback to pointing to backup_path as release directory
        rel_info = {
            "active_release_id": target_backup,
            "release_dir": os.path.relpath(backup_path, root_dir).replace("\\", "/"),
            "promoted_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "checksums": expected_files,
        }
        with open(ptr_tmp, "w", encoding="utf-8") as f:
            json.dump(rel_info, f, indent=2)
        os.replace(ptr_tmp, ptr_file)

    # Synchronize legacy root files
    for fname in expected_files.keys():
        shutil.copy2(os.path.join(backup_path, fname), os.path.join(root_dir, fname))

    # Verify restored production integrity
    post_status = get_active_model_status(root_dir)
    if not post_status["production_ready"]:
        raise RollbackError(f"Post-rollback integrity verification failed: {post_status}")

    # Log rollback event
    log_path = os.path.join(root_dir, "models", "promotion_log.json")
    log_entry = {
        "event": "rollback",
        "restored_backup_id": target_backup,
        "operator": operator,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "active_checksums": post_status["hashes"],
    }
    _append_promotion_log(log_path, log_entry)

    return {
        "status": "rolled_back",
        "restored_backup_id": target_backup,
        "active_checksums": post_status["hashes"],
    }
