"""
Developer and CI Dependency Consistency and Vulnerability Audit Engine for CD_Project.

Executes reproducible dependency consistency validation and supply-chain vulnerability
auditing against declared pinned requirements in requirements.txt.

Capabilities:
1. Pinned Requirements & Dependency Consistency:
   - Verifies all declared dependencies against installed packages (importlib.metadata).
   - Executes 'pip check' to ensure dependency tree consistency and detect broken requirements.
2. Known Vulnerability Auditing (pip-audit):
   - Audits declared requirements against the Python Packaging Advisory Database (PyPA / OSV).
   - Distinguishes confirmed vulnerabilities (policy violations, exit 1) from infrastructure /
     network / service timeout failures (exit 2).
3. Clear Status Codes:
   - Exit 0: All checks passed (consistent dependency tree, 0 known vulnerabilities).
   - Exit 1: Confirmed Security Policy Violation (known vulnerable dependencies detected).
   - Exit 2: Tool, network, or infrastructure failure (pip-audit missing, network down, OSV API timeout).
   - Exit 3: Dependency inconsistency (broken package requirements or version mismatch).

Usage:
    python audit_dependencies.py
    python audit_dependencies.py --check-consistency-only
    python audit_dependencies.py --requirements requirements.txt --format json
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import re
import subprocess
import sys
from typing import Any, Dict, List, Optional, Tuple


EXIT_SUCCESS = 0
EXIT_VULNERABILITY_FOUND = 1
EXIT_TOOL_OR_NETWORK_ERROR = 2
EXIT_CONSISTENCY_ERROR = 3


def parse_requirements_file(filepath: str) -> List[Tuple[str, str, str]]:
    """
    Parses pinned requirements from a requirements file.
    Returns a list of tuples: (package_name, operator, required_version).
    Handles inline comments, blank lines, and normalizes package names.
    """
    requirements = []
    if not os.path.exists(filepath):
        return requirements

    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            clean_line = line.strip()
            # Strip comments and empty lines
            if not clean_line or clean_line.startswith("#"):
                continue
            # Strip inline comment
            if " #" in clean_line:
                clean_line = clean_line.split(" #", 1)[0].strip()

            # Match standard specification: package==version, package>=version, etc.
            match = re.match(r"^([A-Za-z0-9_\-\.]+)\s*(==|>=|<=|>|<|~=)\s*([A-Za-z0-9_\-\.]+)", clean_line)
            if match:
                pkg_name, op, ver = match.groups()
                requirements.append((pkg_name.lower().replace("_", "-"), op, ver))
            else:
                # Bare package name without version constraint
                bare_match = re.match(r"^([A-Za-z0-9_\-\.]+)", clean_line)
                if bare_match:
                    pkg_name = bare_match.group(1).lower().replace("_", "-")
                    requirements.append((pkg_name, "", ""))

    return requirements


def check_dependency_consistency(
    requirements_file: str = "requirements.txt",
    base_dir: Optional[str] = None,
) -> Tuple[bool, List[str], List[Dict[str, Any]]]:
    """
    Verifies dependency consistency:
    1. Checks if all pinned requirements are installed with matching versions.
    2. Runs 'pip check' to ensure no broken or incompatible dependencies exist in the environment.

    Returns: (is_consistent: bool, errors: List[str], details: List[Dict[str, Any]])
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    req_path = os.path.join(base_dir, requirements_file)

    errors: List[str] = []
    details: List[Dict[str, Any]] = []

    if not os.path.exists(req_path):
        err = f"Requirements file not found at: {req_path}"
        errors.append(err)
        return False, errors, details

    parsed_reqs = parse_requirements_file(req_path)
    if not parsed_reqs:
        err = f"No valid requirement entries found in {req_path}"
        errors.append(err)
        return False, errors, details

    # 1. Pinned package verification via importlib.metadata
    for pkg_name, op, req_ver in parsed_reqs:
        entry: Dict[str, Any] = {
            "package": pkg_name,
            "operator": op,
            "required_version": req_ver,
            "installed_version": None,
            "status": "ok",
        }
        try:
            installed_ver = importlib.metadata.version(pkg_name)
            entry["installed_version"] = installed_ver
            if op == "==" and installed_ver != req_ver:
                entry["status"] = "version_mismatch"
                errors.append(
                    f"Version mismatch for '{pkg_name}': declared {req_ver}, but installed {installed_ver}"
                )
            elif op == ">=" and installed_ver < req_ver:
                entry["status"] = "version_too_low"
                errors.append(
                    f"Version too low for '{pkg_name}': declared >={req_ver}, but installed {installed_ver}"
                )
        except importlib.metadata.PackageNotFoundError:
            entry["status"] = "missing"
            errors.append(f"Declared package '{pkg_name}' is not installed in the current environment")

        details.append(entry)

    # 2. Dependency tree check via 'pip check' (excluded in frozen binary distributions)
    if getattr(sys, "frozen", False):
        details.append({"package": "pip_check", "status": "skipped", "message": "pip check skipped in frozen binary"})
    else:
        try:
            pip_check_res = subprocess.run(
                [sys.executable, "-m", "pip", "check"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=base_dir,
                check=False,
            )
            if pip_check_res.returncode != 0:
                broken_output = pip_check_res.stdout.strip() or pip_check_res.stderr.strip()
                errors.append(f"Broken dependencies detected by 'pip check':\n{broken_output}")
        except Exception as e:
            errors.append(f"Failed to execute 'pip check': {e}")

    is_consistent = len(errors) == 0
    return is_consistent, errors, details


def audit_vulnerabilities(
    requirements_file: str = "requirements.txt",
    base_dir: Optional[str] = None,
    timeout: int = 45,
) -> Tuple[int, Optional[Dict[str, Any]], str, List[Dict[str, Any]]]:
    """
    Audits dependencies for known CVEs using pip-audit against requirements.txt.

    Returns:
        (status_code, raw_json_data, log_message, vulnerabilities_list)
        status_code:
            0: Audit passed, no known vulnerabilities found.
            1: Confirmed vulnerabilities found (policy violation).
            2: Tool failure, missing tool, or network/infrastructure error.
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    req_path = os.path.join(base_dir, requirements_file)

    if not os.path.exists(req_path):
        return (
            EXIT_TOOL_OR_NETWORK_ERROR,
            None,
            f"Requirements file not found at {req_path}",
            [],
        )

    # Verify pip-audit availability
    try:
        import pip_audit  # noqa: F401
    except ImportError:
        msg = (
            "[TOOL ERROR] 'pip-audit' is not installed in the active Python environment.\n"
            "To enable vulnerability auditing, install pip-audit explicitly:\n"
            "    pip install pip-audit\n"
            "Then re-run the audit command:\n"
            f"    {sys.executable} audit_dependencies.py"
        )
        return EXIT_TOOL_OR_NETWORK_ERROR, None, msg, []

    if getattr(sys, "frozen", False):
        return EXIT_TOOL_OR_NETWORK_ERROR, None, "Vulnerability audit via pip_audit is not supported in frozen binary distribution.", []

    cmd = [
        sys.executable,
        "-m",
        "pip_audit",
        "-r",
        req_path,
        "--format",
        "json",
        "--timeout",
        str(timeout),
    ]

    try:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=base_dir,
            timeout=timeout + 30,
            check=False,
        )
    except subprocess.TimeoutExpired:
        msg = (
            f"[NETWORK / INFRASTRUCTURE FAILURE] pip-audit timed out after {timeout} seconds.\n"
            "The vulnerability advisory service (PyPI/OSV) did not respond in time.\n"
            "This indicates a network or service availability issue, NOT a confirmed code vulnerability."
        )
        return EXIT_TOOL_OR_NETWORK_ERROR, None, msg, []
    except Exception as e:
        msg = f"[INFRASTRUCTURE FAILURE] Failed to execute pip-audit subprocess: {e}"
        return EXIT_TOOL_OR_NETWORK_ERROR, None, msg, []

    stdout_raw = res.stdout.strip()
    stderr_raw = res.stderr.strip()

    # Attempt to parse JSON from stdout
    json_data: Optional[Dict[str, Any]] = None
    if stdout_raw:
        # pip-audit outputs JSON, sometimes preceded by progress or status lines
        json_match = re.search(r"\{.*\}", stdout_raw, re.DOTALL)
        if json_match:
            try:
                json_data = json.loads(json_match.group(0))
            except json.JSONDecodeError:
                json_data = None

    vulnerabilities: List[Dict[str, Any]] = []
    if json_data and "dependencies" in json_data:
        for dep in json_data.get("dependencies", []):
            pkg_name = dep.get("name")
            pkg_ver = dep.get("version")
            for vuln in dep.get("vulns", []):
                vulnerabilities.append({
                    "package": pkg_name,
                    "version": pkg_ver,
                    "id": vuln.get("id"),
                    "fix_versions": vuln.get("fix_versions", []),
                    "description": vuln.get("description", "").strip(),
                })

    # Case A: pip-audit exited with 0 (Clean, no vulnerabilities)
    if res.returncode == 0:
        total_scanned = len(json_data.get("dependencies", [])) if json_data else len(parse_requirements_file(req_path))
        msg = f"Audit passed: {total_scanned} dependencies scanned. Zero known vulnerabilities found."
        return EXIT_SUCCESS, json_data, msg, []

    # Case B: Confirmed Vulnerabilities detected
    if len(vulnerabilities) > 0:
        msg = (
            f"[SECURITY POLICY VIOLATION] {len(vulnerabilities)} known vulnerability finding(s) detected "
            f"across declared dependencies in {requirements_file}."
        )
        return EXIT_VULNERABILITY_FOUND, json_data, msg, vulnerabilities

    # Case C: Non-zero exit without confirmed vulnerabilities -> Infrastructure/Network/Tool failure
    error_summary = stderr_raw or stdout_raw or "Unknown tool execution error"
    # Check for known network or service indicators
    is_network_issue = any(
        term in error_summary.lower()
        for term in ("connection", "timeout", "network", "urlerror", "serviceerror", "http error", "getaddrinfo")
    )
    infra_type = "NETWORK / INFRASTRUCTURE FAILURE" if is_network_issue else "TOOL EXECUTION FAILURE"
    msg = (
        f"[{infra_type}] pip-audit failed to complete the audit (exit code {res.returncode}).\n"
        f"Diagnostic details:\n{error_summary}\n\n"
        "Note: This is an environment, network, or advisory service failure, NOT a confirmed code vulnerability."
    )
    return EXIT_TOOL_OR_NETWORK_ERROR, json_data, msg, []


def audit_dependencies(
    requirements_file: str = "requirements.txt",
    check_consistency: bool = True,
    audit_vulns: bool = True,
    output_format: str = "text",
    base_dir: Optional[str] = None,
) -> int:
    """
    Main programmatic orchestrator for dependency auditing and consistency verification.
    Returns standard exit codes:
      0 = Passed
      1 = Confirmed Vulnerabilities (Policy Violation)
      2 = Tool/Network/Infrastructure Error
      3 = Dependency Inconsistency
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    full_report: Dict[str, Any] = {
        "requirements_file": requirements_file,
        "base_dir": base_dir,
        "consistency": None,
        "vulnerabilities": None,
        "overall_status": "UNKNOWN",
        "exit_code": EXIT_SUCCESS,
    }

    # 1. Dependency Consistency Check
    if check_consistency:
        is_consistent, cons_errors, cons_details = check_dependency_consistency(
            requirements_file=requirements_file,
            base_dir=base_dir,
        )
        full_report["consistency"] = {
            "passed": is_consistent,
            "errors": cons_errors,
            "details": cons_details,
        }
        if not is_consistent:
            full_report["overall_status"] = "INCONSISTENT_DEPENDENCIES"
            full_report["exit_code"] = EXIT_CONSISTENCY_ERROR
            if output_format == "json":
                print(json.dumps(full_report, indent=2))
            else:
                print("================================================================================")
                print("[FAILED] DEPENDENCY CONSISTENCY CHECK: INCONSISTENCIES DETECTED")
                print("================================================================================")
                for err in cons_errors:
                    print(f"  - {err}")
                print("\nRemediation:")
                print("  Run 'pip install -r requirements.txt' or resolve conflicting packages.")
                print("================================================================================")
            return EXIT_CONSISTENCY_ERROR
        elif output_format != "json":
            print("================================================================================")
            print("[PASSED] DEPENDENCY CONSISTENCY CHECK: ALL PACKAGES VERIFIED")
            print(f"   All {len(cons_details)} declared requirements in {requirements_file} match installed packages.")
            print("   'pip check' confirmed no broken dependency relationships.")
            print("================================================================================")

    # 2. Known Vulnerabilities Audit
    if audit_vulns:
        code, raw_json, vuln_msg, vulns = audit_vulnerabilities(
            requirements_file=requirements_file,
            base_dir=base_dir,
        )
        full_report["vulnerabilities"] = {
            "exit_code": code,
            "message": vuln_msg,
            "count": len(vulns),
            "findings": vulns,
        }

        if code == EXIT_VULNERABILITY_FOUND:
            full_report["overall_status"] = "VULNERABILITIES_FOUND"
            full_report["exit_code"] = EXIT_VULNERABILITY_FOUND
            if output_format == "json":
                print(json.dumps(full_report, indent=2))
            else:
                print("\n================================================================================")
                print("[SECURITY POLICY VIOLATION] CONFIRMED VULNERABILITIES FOUND")
                print("================================================================================")
                print(vuln_msg)
                print("\nConfirmed Vulnerability Details:")
                for v in vulns:
                    fix_info = ", ".join(v["fix_versions"]) if v["fix_versions"] else "No fix specified"
                    print(f"  * [{v['id']}] {v['package']} (installed: {v['version']})")
                    print(f"    Fixed in:    {fix_info}")
                    if v["description"]:
                        desc_snippet = v["description"].split("\n")[0][:120]
                        print(f"    Description: {desc_snippet}")
                print("\nRemediation Protocol:")
                print("  1. Review each advisory for CVSS severity and applicability to this project.")
                print("  2. Test targeted package upgrade in a virtual environment without blindly updating all packages.")
                print("  3. Run the complete regression test suite: python -m pytest")
                print("  4. Update pinned requirements in requirements.txt after verifying compatibility.")
                print("================================================================================")
            return EXIT_VULNERABILITY_FOUND

        elif code == EXIT_TOOL_OR_NETWORK_ERROR:
            full_report["overall_status"] = "TOOL_OR_NETWORK_FAILURE"
            full_report["exit_code"] = EXIT_TOOL_OR_NETWORK_ERROR
            if output_format == "json":
                print(json.dumps(full_report, indent=2))
            else:
                print("\n================================================================================")
                print("[WARNING] AUDIT INFRASTRUCTURE / NETWORK FAILURE")
                print("================================================================================")
                print(vuln_msg)
                print("================================================================================")
            return EXIT_TOOL_OR_NETWORK_ERROR

        else:
            full_report["overall_status"] = "CLEAN"
            full_report["exit_code"] = EXIT_SUCCESS
            if output_format == "json":
                print(json.dumps(full_report, indent=2))
            else:
                print("\n================================================================================")
                print("[PASSED] SUPPLY-CHAIN SECURITY AUDIT: ZERO KNOWN VULNERABILITIES")
                print(f"   {vuln_msg}")
                print("   Audited against Python Packaging Advisory Database (PyPA / OSV).")
                print("================================================================================")
            return EXIT_SUCCESS

    full_report["overall_status"] = "PASSED_CONSISTENCY_ONLY"
    full_report["exit_code"] = EXIT_SUCCESS
    if output_format == "json":
        print(json.dumps(full_report, indent=2))
    return EXIT_SUCCESS


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Automated Dependency Consistency and Vulnerability Audit for CD_Project",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-r",
        "--requirements",
        default="requirements.txt",
        help="Path to requirements file (default: requirements.txt)",
    )
    parser.add_argument(
        "--check-consistency-only",
        action="store_true",
        help="Run dependency consistency and 'pip check' only; skip network vulnerability lookup.",
    )
    parser.add_argument(
        "--audit-only",
        action="store_true",
        help="Run pip-audit vulnerability scanning only; skip local consistency check.",
    )
    parser.add_argument(
        "-f",
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    args = parser.parse_args()

    check_cons = not args.audit_only
    audit_v = not args.check_consistency_only

    return audit_dependencies(
        requirements_file=args.requirements,
        check_consistency=check_cons,
        audit_vulns=audit_v,
        output_format=args.format,
    )


if __name__ == "__main__":
    sys.exit(main())
