"""Structural Validator for C++ Source Code.

Analyzes token streams and source code prior to specific syntax-error
classification to determine whether input contains recognizable C++ constructs,
valid snippets, malformed constructs, or arbitrary unrecognized text.
"""

from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
import re

import lexer


class StructuralClassification(Enum):
    EMPTY = "EMPTY"
    VALID_PROGRAM_OR_SNIPPET = "VALID_PROGRAM_OR_SNIPPET"
    MALFORMED_CONSTRUCT = "MALFORMED_CONSTRUCT"
    AMBIGUOUS_INCOMPLETE = "AMBIGUOUS_INCOMPLETE"
    UNRECOGNIZED_STRUCTURE = "UNRECOGNIZED_STRUCTURE"


CPP_TYPE_KEYWORDS = {
    "int", "float", "double", "char", "bool", "void", "long", "short",
    "unsigned", "signed", "auto", "string", "size_t", "int8_t", "int16_t",
    "int32_t", "int64_t", "uint8_t", "uint16_t", "uint32_t", "uint64_t"
}

CPP_CONTROL_KEYWORDS = {
    "if", "else", "while", "for", "do", "switch", "case", "default",
    "return", "break", "continue", "goto", "try", "catch", "throw"
}

CPP_DECL_KEYWORDS = {
    "class", "struct", "union", "enum", "namespace", "using", "typedef",
    "template", "typename", "public", "private", "protected", "virtual",
    "override", "final", "const", "static", "extern", "inline", "explicit",
    "friend", "constexpr", "mutable"
}

CPP_PREPROCESSOR_DIRECTIVES = {
    "include", "define", "ifdef", "ifndef", "endif", "pragma", "if", "elif",
    "else", "undef", "line", "error"
}


def scan_delimiters(tokens: List[Dict[str, Any]]) -> Tuple[bool, int, int, int]:
    """Check balance of parentheses, braces, and brackets in the token stream."""
    paren_depth = 0
    brace_depth = 0
    bracket_depth = 0
    balanced = True

    for t in tokens:
        ttype = t.get("token_type")
        if ttype == "OPEN_PAREN":
            paren_depth += 1
        elif ttype == "CLOSE_PAREN":
            paren_depth -= 1
            if paren_depth < 0:
                balanced = False
        elif ttype == "OPEN_BRACE":
            brace_depth += 1
        elif ttype == "CLOSE_BRACE":
            brace_depth -= 1
            if brace_depth < 0:
                balanced = False
        elif ttype == "OPEN_BRACKET":
            bracket_depth += 1
        elif ttype == "CLOSE_BRACKET":
            bracket_depth -= 1
            if bracket_depth < 0:
                balanced = False

    if paren_depth != 0 or brace_depth != 0 or bracket_depth != 0:
        balanced = False

    return balanced, paren_depth, brace_depth, bracket_depth


class StructuralValidationResult:
    def __init__(
        self,
        classification: StructuralClassification,
        confidence: float,
        reason: str,
        is_ambiguous: bool = False,
        primary_construct: Optional[str] = None,
    ):
        self.classification = classification
        self.confidence = confidence
        self.reason = reason
        self.is_ambiguous = is_ambiguous
        self.primary_construct = primary_construct

    def to_dict(self) -> Dict[str, Any]:
        return {
            "classification": self.classification.value,
            "confidence": self.confidence,
            "reason": self.reason,
            "is_ambiguous": self.is_ambiguous,
            "primary_construct": self.primary_construct,
        }


def forms_valid_expression(tokens: List[Dict[str, Any]]) -> bool:
    """Check if token sequence forms a recognizable C++ expression pattern."""
    if not tokens:
        return False

    binary_ops = {
        "+", "-", "*", "/", "%", "==", "!=", "<", ">", "<=", ">=",
        "&&", "||", "&", "|", "^", "=", "+=", "-=", "*=", "/=", "%=",
        "<<", ">>", "->", "."
    }
    postfix_ops = {"++", "--"}
    prefix_ops = {"++", "--", "!", "~", "+", "-", "*", "&"}
    operands = {"IDENTIFIER", "NUMBER", "STRING", "CHAR"}

    has_operand = any(t.get("token_type") in operands for t in tokens)
    if not has_operand:
        return False

    last_tok = tokens[-1]
    if last_tok.get("token_type") == "OPERATOR":
        if last_tok.get("token_value") not in postfix_ops:
            return False

    first_tok = tokens[0]
    if first_tok.get("token_type") == "OPERATOR":
        if first_tok.get("token_value") not in prefix_ops:
            return False

    for i in range(len(tokens) - 1):
        t1 = tokens[i]
        t2 = tokens[i + 1]
        if t1.get("token_type") == "OPERATOR" and t2.get("token_type") == "OPERATOR":
            v1 = t1.get("token_value")
            v2 = t2.get("token_value")
            if v1 in binary_ops and v2 in binary_ops and v2 not in prefix_ops:
                return False
            if v1 in ("%", "/", "^"):
                return False

    for i in range(len(tokens)):
        t = tokens[i]
        if t.get("token_type") == "OPERATOR" and t.get("token_value") in binary_ops:
            if i > 0 and i < len(tokens) - 1:
                prev_t = tokens[i - 1]
                next_t = tokens[i + 1]
                if (prev_t.get("token_type") in operands or prev_t.get("token_type") == "CLOSE_PAREN") and \
                   (next_t.get("token_type") in operands or next_t.get("token_type") == "OPEN_PAREN" or next_t.get("token_value") in prefix_ops):
                    return True
        elif t.get("token_type") == "OPERATOR" and t.get("token_value") in prefix_ops:
            if i < len(tokens) - 1 and tokens[i + 1].get("token_type") in operands:
                return True
        elif t.get("token_type") == "OPERATOR" and t.get("token_value") in postfix_ops:
            if i > 0 and tokens[i - 1].get("token_type") in operands:
                return True

    return False


def validate_cpp_structure(
    tokens: List[Dict[str, Any]],
    source_code: str,
) -> StructuralValidationResult:
    """Analyze token stream and source code to validate structural validity.
    
    Determines whether the token stream contains recognizable C++ constructs:
    - Keywords (type, control flow, declarations)
    - Preprocessor directives (#include, #define)
    - Declarator patterns (functions, classes, variables)
    - Operators forming expressions (=, <<, +, -, etc.)
    - Scope delimiters and groupings ((), {}, [])
    - String / character / numeric literals in valid contexts
    """
    stripped_code = source_code.strip() if source_code else ""
    if not stripped_code or not tokens:
        return StructuralValidationResult(
            classification=StructuralClassification.EMPTY,
            confidence=1.0,
            reason="Source code is empty or whitespace-only.",
        )

    # Filter out comments and whitespace tokens (already done by lexer, but ensure clean list)
    meaningful_tokens = [
        t for t in tokens if t.get("token_type") not in ("WHITESPACE", "NEWLINE")
    ]

    if not meaningful_tokens:
        return StructuralValidationResult(
            classification=StructuralClassification.EMPTY,
            confidence=1.0,
            reason="Source code contains no meaningful tokens.",
        )

    # 1. Lexical checks: Unterminated string or char literals take precedence as lexical errors
    for t in meaningful_tokens:
        ttype = t.get("token_type")
        tval = t.get("token_value", "")
        if ttype == "STRING":
            if len(tval) < 2 or not tval.endswith('"'):
                return StructuralValidationResult(
                    classification=StructuralClassification.MALFORMED_CONSTRUCT,
                    confidence=1.0,
                    reason="Contains unterminated string literal.",
                    primary_construct="STRING_LITERAL",
                )
        elif ttype == "CHAR":
            if len(tval) < 2 or not tval.endswith("'"):
                return StructuralValidationResult(
                    classification=StructuralClassification.MALFORMED_CONSTRUCT,
                    confidence=1.0,
                    reason="Contains unterminated character literal.",
                    primary_construct="CHAR_LITERAL",
                )

    # Check for presence of preprocessor directives
    has_hash = any(t.get("token_type") == "HASH" for t in meaningful_tokens)
    if has_hash:
        for idx, t in enumerate(meaningful_tokens):
            if t.get("token_type") == "HASH":
                if idx + 1 < len(meaningful_tokens):
                    nxt = meaningful_tokens[idx + 1]
                    if nxt.get("token_value") in CPP_PREPROCESSOR_DIRECTIVES or nxt.get("token_type") == "KEYWORD":
                        # Recognizable preprocessor construct exists
                        return StructuralValidationResult(
                            classification=StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
                            confidence=0.95,
                            reason="Contains recognizable preprocessor directive.",
                            primary_construct="PREPROCESSOR",
                        )

    # Count token categories
    keywords = [t for t in meaningful_tokens if t.get("token_type") == "KEYWORD"]
    identifiers = [t for t in meaningful_tokens if t.get("token_type") == "IDENTIFIER"]
    operators = [t for t in meaningful_tokens if t.get("token_type") == "OPERATOR"]
    semicolons = [t for t in meaningful_tokens if t.get("token_type") == "SEMICOLON"]
    delimiters = [
        t for t in meaningful_tokens
        if t.get("token_type") in ("OPEN_PAREN", "CLOSE_PAREN", "OPEN_BRACE", "CLOSE_BRACE", "OPEN_BRACKET", "CLOSE_BRACKET")
    ]
    literals = [
        t for t in meaningful_tokens
        if t.get("token_type") in ("INTEGER", "FLOAT", "STRING", "CHAR")
    ]

    balanced_delims, paren_d, brace_d, bracket_d = scan_delimiters(meaningful_tokens)

    # Check for isolated single keyword without context, e.g. "int"
    if len(meaningful_tokens) == 1:
        tok = meaningful_tokens[0]
        if tok.get("token_type") == "KEYWORD":
            # An isolated keyword like "int", "return", "class"
            return StructuralValidationResult(
                classification=StructuralClassification.UNRECOGNIZED_STRUCTURE,
                confidence=0.90,
                reason=f"Isolated C++ keyword '{tok.get('token_value')}' without statement or declaration context.",
                primary_construct="ISOLATED_KEYWORD",
            )
        else:
            # Single identifier, literal, or symbol like "hfghfdghdjdf", "asdf"
            return StructuralValidationResult(
                classification=StructuralClassification.UNRECOGNIZED_STRUCTURE,
                confidence=0.95,
                reason="Input consists of a single standalone token with no C++ declaration or statement structure.",
                primary_construct="ISOLATED_IDENTIFIER",
            )

    # Check for two bare identifiers with no other tokens, e.g. "foo bar", "x y", "hfghfdghdjd f"
    if len(meaningful_tokens) == 2:
        t0, t1 = meaningful_tokens[0], meaningful_tokens[1]
        if t0.get("token_type") == "IDENTIFIER" and t1.get("token_type") == "IDENTIFIER":
            # Ambiguous: could be typo'd/incomplete declaration with unknown type "Type var" or random words "hello world"
            # If they look like common English words or arbitrary letters without any type context
            return StructuralValidationResult(
                classification=StructuralClassification.AMBIGUOUS_INCOMPLETE,
                confidence=0.40,
                is_ambiguous=True,
                reason="Input consists of two bare identifiers ('" + t0.get('token_value') + " " + t1.get('token_value') + "') without type keywords, operators, or statement punctuation; unrecognized or incomplete declaration.",
                primary_construct="BARE_IDENTIFIER_PAIR",
            )
        if (t0.get("token_type") in ("INTEGER", "FLOAT") and t1.get("token_type") == "IDENTIFIER") or \
           (t0.get("token_type") == "IDENTIFIER" and t1.get("token_type") in ("INTEGER", "FLOAT")):
            # E.g. "123 abc"
            return StructuralValidationResult(
                classification=StructuralClassification.UNRECOGNIZED_STRUCTURE,
                confidence=0.95,
                reason="Literal adjacent to identifier with no operator or expression structure.",
                primary_construct="UNRECOGNIZED_TOKENS",
            )

    # Check if input has completely NO keywords, NO semicolons, NO delimiters, and NO operators
    if not keywords and not semicolons and not delimiters:
        # Check if there are operators that form expressions (e.g. "a + b", "a = b")
        if not operators:
            # Only identifiers and literals with no operators, no semicolons, no delimiters (e.g. "hello world foo bar")
            return StructuralValidationResult(
                classification=StructuralClassification.UNRECOGNIZED_STRUCTURE,
                confidence=0.95,
                reason="Input contains no C++ keywords, operators, statement terminators, or scope delimiters.",
                primary_construct="ARBITRARY_TEXT",
            )

    # Check for recognizable keywords
    has_type_kw = any(t.get("token_value") in CPP_TYPE_KEYWORDS for t in keywords)
    has_ctrl_kw = any(t.get("token_value") in CPP_CONTROL_KEYWORDS for t in keywords)
    has_decl_kw = any(t.get("token_value") in CPP_DECL_KEYWORDS for t in keywords)

    # Check for recognizable function declaration pattern:
    # return_type identifier ( ... ) { ... } OR return_type identifier ( ... ) missing brace
    has_func_pattern = False
    for i in range(len(meaningful_tokens) - 2):
        tok_i = meaningful_tokens[i]
        tok_next = meaningful_tokens[i + 1]
        tok_after = meaningful_tokens[i + 2]
        if (tok_i.get("token_value") in CPP_TYPE_KEYWORDS or tok_i.get("token_type") == "KEYWORD") and \
           tok_next.get("token_type") == "IDENTIFIER" and \
           tok_after.get("token_type") == "OPEN_PAREN":
            has_func_pattern = True
            break
        # Also check for constructor or main without explicit type keyword if any
        if tok_i.get("token_value") == "main" and tok_next.get("token_type") == "OPEN_PAREN":
            has_func_pattern = True
            break

    # Check for recognizable class/struct declaration pattern
    has_class_pattern = any(
        t.get("token_value") in ("class", "struct") and t.get("token_type") == "KEYWORD"
        for t in keywords
    )

    # Check for recognizable control flow header
    has_ctrl_pattern = any(
        t.get("token_value") in ("if", "while", "for", "switch") and t.get("token_type") == "KEYWORD"
        for t in keywords
    )

    # If recognizable constructs exist, check if they are malformed or valid
    if has_func_pattern or has_class_pattern or has_ctrl_pattern or has_type_kw or has_decl_kw or has_ctrl_kw:
        # Check if delimiter balance is broken
        if not balanced_delims:
            return StructuralValidationResult(
                classification=StructuralClassification.MALFORMED_CONSTRUCT,
                confidence=0.90,
                reason="Recognizable C++ construct with unbalanced delimiters.",
                primary_construct="DELIMITER_IMBALANCE",
            )

        # Check for function with missing body brace, e.g.:
        # int main() \n return 0; \n }
        # where function header is present but opening '{' was omitted
        if has_func_pattern:
            return StructuralValidationResult(
                classification=StructuralClassification.MALFORMED_CONSTRUCT if not balanced_delims or not semicolons else StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
                confidence=0.90,
                reason="Contains recognizable function declaration.",
                primary_construct="FUNCTION_DECL",
            )

        # Statements or declarations with semicolons or braces
        if semicolons or any(t.get("token_type") == "OPEN_BRACE" for t in delimiters):
            return StructuralValidationResult(
                classification=StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
                confidence=0.90,
                reason="Contains recognizable C++ statement or declaration structure.",
                primary_construct="STATEMENT_OR_DECL",
            )

        # Keyword present but no semicolons or braces (e.g. malformed declaration "int x = 10")
        if has_type_kw or has_ctrl_kw or has_decl_kw:
            return StructuralValidationResult(
                classification=StructuralClassification.MALFORMED_CONSTRUCT,
                confidence=0.85,
                reason="Contains recognizable C++ keywords in malformed statement context.",
                primary_construct="KEYWORD_STATEMENT",
            )

    # If there are NO C++ keywords, but valid expression/statement syntax exists:
    # E.g.: "x = 10;" or "cout << x;" or "foo();" or "x + y;"
    if semicolons:
        # Check if there are operators or function calls
        has_expr_op = any(
            t.get("token_type") == "OPERATOR" or t.get("token_type") in ("OPEN_PAREN", "OPEN_BRACKET")
            for t in meaningful_tokens
        )
        if has_expr_op:
            return StructuralValidationResult(
                classification=StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
                confidence=0.85,
                reason="Contains valid expression or statement syntax with terminator.",
                primary_construct="EXPRESSION_STATEMENT",
            )

        # Identifiers ending with semicolon e.g. "foo bar;"
        if len(identifiers) >= 2:
            # Could be a custom type declaration snippet e.g. "MyType x;"
            return StructuralValidationResult(
                classification=StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
                confidence=0.75,
                reason="Contains user-defined declaration syntax with terminator.",
                primary_construct="USER_TYPE_DECL",
            )

    # Delimiters without keywords, e.g. balanced block "{ x = 1; }" or unbalanced
    if any(t.get("token_type") in ("OPEN_BRACE", "CLOSE_BRACE") for t in delimiters):
        if not balanced_delims:
            return StructuralValidationResult(
                classification=StructuralClassification.MALFORMED_CONSTRUCT,
                confidence=0.85,
                reason="Contains C++ braces with delimiter imbalance.",
                primary_construct="BRACE_BLOCK",
            )
        return StructuralValidationResult(
            classification=StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
            confidence=0.80,
            reason="Contains C++ compound block structure.",
            primary_construct="BRACE_BLOCK",
        )

    # If only identifiers exist with operators but no semicolons e.g. "a + b"
    if operators and identifiers:
        if forms_valid_expression(meaningful_tokens):
            return StructuralValidationResult(
                classification=StructuralClassification.VALID_PROGRAM_OR_SNIPPET,
                confidence=0.70,
                reason="Contains valid expression syntax.",
                primary_construct="EXPRESSION_SNIPPET",
            )
        else:
            return StructuralValidationResult(
                classification=StructuralClassification.UNRECOGNIZED_STRUCTURE,
                confidence=0.90,
                reason="Token stream contains invalid operator patterns not forming a C++ expression.",
                primary_construct="MALFORMED_EXPRESSION",
            )

    # Fallback: token stream does not resemble any recognized C++ construct
    return StructuralValidationResult(
        classification=StructuralClassification.UNRECOGNIZED_STRUCTURE,
        confidence=0.90,
        reason="Token stream contains no recognizable C++ declaration, statement, expression, or program structure.",
        primary_construct="UNKNOWN",
    )
