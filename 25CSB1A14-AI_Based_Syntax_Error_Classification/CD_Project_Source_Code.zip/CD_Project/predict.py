"""
predict.py - Offline C++ Syntax Error Classifier & Local Diagnostic Utility.

NOTE: This script is an offline ML classification tool designed to be invoked:
1. By server.py as an isolated subprocess ONLY AFTER source code has passed the
   central AssessmentEngine pre-diagnostic security gate.
2. By developers locally for offline syntax error diagnosis and testing.

SECURITY NOTICE: predict.py operates strictly on local offline files. It does not
host web endpoints or accept untrusted network traffic. When self-healing (--self-heal)
is invoked via CLI, execution of binaries is disabled by default (allow_execution=False)
and code should be verified against AssessmentEngine in secure environments.
"""

import sys
import os
import re
import csv
import tempfile
import subprocess
import shutil
import argparse
import joblib
import pandas as pd
import numpy as np
import time
import hashlib
import json
import matplotlib.pyplot as plt
from collections import defaultdict, Counter

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

def safe_print(text=""):
    try:
        print(text)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, 'encoding', None) or 'ascii'
        print(text.encode(enc, errors='replace').decode(enc, errors='replace'))


DIAGNOSTICS = {

    "MISSING_SEMICOLON": {
        "description": "A semicolon ';' is missing at the end of a statement or declaration.",
        "fix": (
            "Check the end of every statement inside your function.\n"
            "  Every variable declaration and expression must end with ';'"
        ),
        "example": (
            "  int x = 5      ← missing semicolon\n"
            "  int x = 5;     ← correct"
        ),
    },

    "UNMATCHED_BRACE": {
        "description": "A curly brace '{' or '}' is missing or mismatched.",
        "fix": (
            "Count your opening '{' and closing '}' braces.\n"
            "  Every function body, if/else block, loop, and class must have\n"
            "  a matching pair of curly braces."
        ),
        "example": (
            "  void foo() {        ← opening brace\n"
            "      int x = 5;      \n"
            "                      ← missing closing brace }\n"
            "  void foo() {        ← correct\n"
            "      int x = 5;\n"
            "  }"
        ),
    },

    "UNMATCHED_PARANTHESES": {
        "description": "A parenthesis '(' or ')' is missing or mismatched.",
        "fix": (
            "Check all your function calls, if/while/for conditions.\n"
            "  Every opening '(' must have a matching closing ')'"
        ),
        "example": (
            "  if (x > 5 {        ← missing closing parenthesis\n"
            "  if (x > 5) {       ← correct"
        ),
    },

    "INVALID_ASSIGNMENT": {
        "description": "An invalid assignment expression was detected. A literal or constant is being used as the left-hand side of an assignment.",
        "fix": (
            "The left side of '=' must always be a variable, not a literal.\n"
            "  Check that you haven't swapped the variable and value."
        ),
        "example": (
            "  5 = x;      ← invalid: literal on left side\n"
            "  x = 5;      ← correct"
        ),
    },

    "INVALID_DECLARATION": {
        "description": "An invalid variable declaration was detected. The variable may have an incorrect type, missing name, or invalid syntax.",
        "fix": (
            "A variable declaration must follow the pattern:\n"
            "  <type> <name>;\n"
            "  or <type> <name> = <value>;\n"
            "  Check for missing variable names or invalid type keywords."
        ),
        "example": (
            "  int ;         ← invalid: missing variable name\n"
            "  int x;        ← correct\n"
            "  int int x;    ← invalid: duplicate type keyword\n"
            "  int x = 5;    ← correct"
        ),
    },

    "INVALID_CONDITIONAL": {
        "description": "An invalid conditional statement was detected. The 'if' statement is missing its condition in parentheses.",
        "fix": (
            "An if statement must always have a condition inside parentheses:\n"
            "  if (<condition>) { ... }\n"
            "  Make sure the opening '(' comes right after 'if'."
        ),
        "example": (
            "  if x > 5 {         ← invalid: missing parentheses\n"
            "  if (x > 5) {       ← correct"
        ),
    },

    "INVALID_LOOP": {
        "description": "An invalid loop was detected. A 'for' or 'while' loop is missing its condition in parentheses.",
        "fix": (
            "A loop must always have its condition inside parentheses:\n"
            "  for (<init>; <cond>; <update>) { ... }\n"
            "  while (<condition>) { ... }\n"
            "  Make sure '(' comes right after 'for' or 'while'."
        ),
        "example": (
            "  for int i=0; i<5; i++ {    ← invalid: missing parentheses\n"
            "  for (int i=0; i<5; i++) {  ← correct"
        ),
    },

    "INVALID_TYPE": {
        "description": "An invalid type declaration was detected. Two type keywords appear consecutively, or an unknown type is used.",
        "fix": (
            "A variable declaration can only have ONE type keyword.\n"
            "  Remove the duplicate type, or check for a typo in the type name."
        ),
        "example": (
            "  int float x;    ← invalid: two types\n"
            "  float x;        ← correct"
        ),
    },

    "INVALID_ARRAY_DECL": {
        "description": "An invalid array declaration was detected. The array brackets '[]' are missing the closing ']'.",
        "fix": (
            "An array declaration must have properly closed brackets:\n"
            "  <type> <name>[<size>];\n"
            "  Make sure every '[' has a matching ']'."
        ),
        "example": (
            "  int arr[5;      ← invalid: missing closing bracket\n"
            "  int arr[5];     ← correct"
        ),
    },

    "INVALID_FUNCTION_DECL": {
        "description": "An invalid function declaration was detected. The function body opening brace '{' is missing, or the function has no return statement.",
        "fix": (
            "A function declaration must have:\n"
            "  1. A return type\n"
            "  2. A function name\n"
            "  3. Parentheses () for parameters\n"
            "  4. A body enclosed in { }\n"
            "  5. A return statement if the return type is not void"
        ),
        "example": (
            "  int foo()           ← invalid: missing body { }\n"
            "  int foo() { }       ← valid structure\n"
            "  int foo() {         ← correct\n"
            "      return 0;\n"
            "  }"
        ),
    },

    "INVALID_CPP_STRUCTURE": {
        "description": "The input does not match a recognizable C++ declaration, statement, expression, or program structure.",
        "fix": (
            "Provide valid C++ code, such as:\n"
            "  1. A complete program: int main() { return 0; }\n"
            "  2. A valid function definition: void func() { }\n"
            "  3. A valid declaration or statement: int x = 0;"
        ),
        "example": (
            "  hfghfdghdjdf        ← invalid: arbitrary text without C++ structure\n"
            "  int x = 10;         ← correct: valid declaration\n"
            "  int main() { }      ← correct: valid function"
        ),
    },

    "EXTRA_TOKENS": {
        "description": "Extra or unexpected tokens were detected in the code. There may be stray characters, duplicate keywords, or misplaced symbols.",
        "fix": (
            "Look for extra symbols, repeated keywords, or characters that\n"
            "  don't belong. Common causes:\n"
            "  - Duplicate semicolons (;;)\n"
            "  - Extra closing braces or brackets\n"
            "  - Stray operators or symbols"
        ),
        "example": (
            "  int x = 5;; extra    ← invalid: extra token after semicolon\n"
            "  int x = 5;           ← correct"
        ),
    },

    "MISPLACED_KEYWORD": {
        "description": "A keyword is used in the wrong place or context. Common causes include 'else' without 'if', keywords in expressions, or control flow keywords where they don't belong.",
        "fix": (
            "Check the context where the keyword is used.\n"
            "  - 'else' must follow an 'if' statement\n"
            "  - Control flow keywords ('if', 'while', 'for') cannot be used in expressions\n"
            "  - Keywords like 'return', 'break', 'continue' must be in appropriate contexts"
        ),
        "example": (
            "  return if (x > 0);     ← invalid: 'if' in return statement\n"
            "  if (x > 0) return 1;   ← correct: proper if statement\n"
            "  \n"
            "  else { ... }           ← invalid: else without if\n"
            "  if (x > 0) { ... }     ← correct: if-then structure\n"
            "  else { ... }"
        ),
    },

    "UNTERMINATED_STRING": {
        "description": "An unterminated string literal was detected. A string is opened with '\"' but never closed.",
        "fix": (
            "Every string literal must start and end with a double quote '\"'.\n"
            "  Check that you haven't accidentally left a string unclosed."
        ),
        "example": (
            '  cout << "hello;      ← invalid: string never closed\n'
            '  cout << "hello";     ← correct'
        ),
    },

    "INVALID_SWITCH": {
        "description": "An invalid switch statement was detected. Switch statements require proper case/default labels and structure.",
        "fix": (
            "Switch statements must follow this structure:\n"
            "  switch (expression) {\n"
            "      case value1:\n"
            "          // code\n"
            "          break;\n"
            "      case value2:\n"
            "          // code\n"
            "          break;\n"
            "      default:\n"
            "          // code\n"
            "  }\n"
            "  Check for missing colons after case/default, or missing opening/closing braces."
        ),
        "example": (
            "  switch (x) {         ← correct structure\n"
            "      case 1:\n"
            "          break;\n"
            "      default:\n"
            "          break;\n"
            "  }\n"
            "  \n"
            "  switch x {           ← invalid: missing parentheses\n"
            "      case 1           ← invalid: missing colon\n"
            "          break;\n"
            "  }"
        ),
    },

    "INVALID_CLASS_DECL": {
        "description": "An invalid class or struct declaration was detected. Class/struct declarations require proper opening and closing braces.",
        "fix": (
            "Class/struct declarations must follow this structure:\n"
            "  class ClassName {\n"
            "  public:\n"
            "      // members\n"
            "  private:\n"
            "      // members\n"
            "  };\n"
            "  Check for missing opening/closing braces or semicolons."
        ),
        "example": (
            "  class MyClass {      ← correct structure\n"
            "  public:\n"
            "      int x;\n"
            "  };\n"
            "  \n"
            "  class MyClass        ← invalid: missing opening brace\n"
            "  public:\n"
            "      int x;\n"
            "  ;"
        ),
    },

    "INVALID_NAMESPACE_DECL": {
        "description": "An invalid namespace declaration was detected. Namespace declarations require proper opening and closing braces.",
        "fix": (
            "Namespace declarations must follow this structure:\n"
            "  namespace MyNamespace {\n"
            "      // declarations\n"
            "  }\n"
            "  Check for missing opening/closing braces."
        ),
        "example": (
            "  namespace MyNS {     ← correct structure\n"
            "      int x;\n"
            "  }\n"
            "  \n"
            "  namespace MyNS       ← invalid: missing opening brace\n"
            "      int x;\n"
            "  "
        ),
    },

    "MULTIPLE_ERRORS": {
        "description": "Multiple syntax errors or cascading compiler errors were detected in the source code.",
        "fix": (
            "Review and resolve errors sequentially starting from the earliest line,\n"
            "  as initial syntax errors can cause cascading parsing failures downstream."
        ),
        "example": (
            "  int x = 5          ← error 1: missing semicolon\n"
            "  if x > 0 {         ← error 2: invalid conditional\n"
            "      int y = 10;;   ← error 3: extra tokens\n"
            "  }"
        ),
    },
}


CPP_KEYWORDS = {
    "int","float","double","char","bool","void","long","short",
    "unsigned","signed","const","static","extern","register","volatile",
    "if","else","while","for","do","switch","case","default",
    "break","continue","return","goto",
    "class","struct","union","enum","typedef","namespace","using",
    "public","private","protected","virtual","override","final",
    "new","delete","this","nullptr","NULL","true","false",
    "include","define","ifdef","ifndef","endif","pragma",
    "template","typename","operator","sizeof","typeof",
    "try","catch","throw","auto","inline","explicit","friend","mutable",
}

TOKEN_SPEC = [
    ("HASH",          r"#"),
    ("STRING",        r'"(?:[^"\\\r\n]|\\.)*"?'),
    ("CHAR",          r"'(?:[^'\\\r\n]|\\.)*'?"),
    ("FLOAT",         r"\b\d+\.\d*([eE][+-]?\d+)?\b|\b\d*\.\d+([eE][+-]?\d+)?\b"),
    ("INTEGER",       r"\b\d+\b"),
    ("IDENTIFIER",    r"\b[a-zA-Z_][a-zA-Z0-9_]*\b"),
    ("SEMICOLON",     r";"),
    ("OPEN_PAREN",    r"\("),
    ("CLOSE_PAREN",   r"\)"),
    ("OPEN_BRACE",    r"\{"),
    ("CLOSE_BRACE",   r"\}"),
    ("OPEN_BRACKET",  r"\["),
    ("CLOSE_BRACKET", r"\]"),
    ("OPERATOR",      r"[+\-*/%=<>!&|^~?:.,]+"),
    ("NEWLINE",       r"\n"),
    ("WHITESPACE",    r"[ \t\r]+"),
    ("UNKNOWN",       r"."),
]

import re as _re
MASTER_REGEX = _re.compile(
    "|".join(f"(?P<{name}>{pattern})" for name, pattern in TOKEN_SPEC)
)

from lexer import strip_comments, mask_comments

def scan_delimiter_stacks(code_lines):
    """
    Scan code lines (excluding comments and string/char literals) for unmatched
    parentheses, braces, and brackets using stacks.
    Returns:
        paren_stack: list of (line_no, line_content) for unclosed '('
        extra_close_parens: list of (line_no, line_content) for extra ')'
        brace_stack: list of (line_no, line_content) for unclosed '{'
        extra_close_braces: list of (line_no, line_content) for extra '}'
        bracket_stack: list of (line_no, line_content) for unclosed '['
        extra_close_brackets: list of (line_no, line_content) for extra ']'
    """
    paren_stack = []
    extra_close_parens = []
    brace_stack = []
    extra_close_braces = []
    bracket_stack = []
    extra_close_brackets = []

    source_code = "".join(code_lines)
    masked_source = mask_comments(source_code)
    masked_lines = masked_source.splitlines(keepends=True)

    for line_no, line in enumerate(code_lines, 1):
        line_clean = masked_lines[line_no - 1] if line_no <= len(masked_lines) else ""
        clean_no_str = re.sub(r'"(?:[^"\\\r\n]|\\.)*"?', '', line_clean)
        clean_no_str = re.sub(r"'(?:[^'\\\r\n]|\\.)*'?", '', clean_no_str)
        line_stripped = line.strip()

        for char in clean_no_str:
            if char == '(':
                paren_stack.append((line_no, line_stripped))
            elif char == ')':
                if paren_stack:
                    paren_stack.pop()
                else:
                    extra_close_parens.append((line_no, line_stripped))
            elif char == '{':
                brace_stack.append((line_no, line_stripped))
            elif char == '}':
                if brace_stack:
                    brace_stack.pop()
                else:
                    extra_close_braces.append((line_no, line_stripped))
            elif char == '[':
                bracket_stack.append((line_no, line_stripped))
            elif char == ']':
                if bracket_stack:
                    bracket_stack.pop()
                else:
                    extra_close_brackets.append((line_no, line_stripped))

    return (paren_stack, extra_close_parens,
            brace_stack, extra_close_braces,
            bracket_stack, extra_close_brackets)


def detect_syntax_errors_in_code(code_lines):
    """Detect syntax errors at the source code level and return error info."""
    errors = {}
    unterminated_string_lines = []
    
    source_code = "".join(code_lines)
    masked_source = mask_comments(source_code)
    masked_lines = masked_source.splitlines(keepends=True)

    for line_no, line in enumerate(code_lines, 1):
        line_clean = masked_lines[line_no - 1] if line_no <= len(masked_lines) else ""
        
        # Check for unterminated strings
        line_has_unterminated_str = False
        if '"' in line_clean:
            str_count = 0
            i = 0
            while i < len(line_clean):
                if line_clean[i] == '"' and (i == 0 or line_clean[i-1] != '\\'):
                    str_count += 1
                i += 1
            if str_count % 2 == 1:
                line_has_unterminated_str = True
                unterminated_string_lines.append(line_no)
                errors['UNTERMINATED_STRING'] = {'line': line_no, 'context': line.strip()}
        
        # Check for missing semicolon at line end (skip if line has an unclosed string or is a preprocessor directive)
        is_preprocessor = bool(re.match(r'^\s*#', line_clean))
        if not line_has_unterminated_str and not is_preprocessor:
            raw_stripped = line_clean.rstrip()
            if raw_stripped and not raw_stripped.endswith(';') and not raw_stripped.endswith('{') and not raw_stripped.endswith('}') and not raw_stripped.endswith(':'):
                stripped_clean = raw_stripped.strip()
                is_control_flow = re.match(r'^\s*(for|while|if|else\s+if)\b', stripped_clean)
                is_func_header = bool(re.search(r'\b[a-zA-Z_]\w*\s*\([^)]*\)\s*$', raw_stripped))
                if not is_control_flow and not is_func_header:
                    if re.search(r'\b(int|float|double|char|bool|void|string|long|short|unsigned|signed|auto)\b.*[^{};]$', raw_stripped) or \
                       re.search(r'(\+=|-=|\*=|/=|%=|<<=|>>=|&=|\^=|\|=|=(?!=)).*[^{};]$', raw_stripped) or \
                       re.search(r'^\s*return\b.*[^{};]$', raw_stripped):
                        if 'MISSING_SEMICOLON' not in errors:
                            errors['MISSING_SEMICOLON'] = {'line': line_no, 'context': line.strip()}

        # Check for malformed preprocessor directives
        if is_preprocessor:
            m_inc = re.match(r'^\s*#\s*include(?:\s+(.*))?$', line_clean)
            if m_inc:
                target = (m_inc.group(1) or "").strip()
                if not target:
                    if 'INVALID_DECLARATION' not in errors:
                        errors['INVALID_DECLARATION'] = {'line': line_no, 'context': line.strip()}
                elif target.startswith('<'):
                    if not target.endswith('>') or target == '<>':
                        if 'INVALID_DECLARATION' not in errors:
                            errors['INVALID_DECLARATION'] = {'line': line_no, 'context': line.strip()}
                elif target.startswith('"'):
                    if not target.endswith('"') or len(target) < 2:
                        pass
                else:
                    if 'INVALID_DECLARATION' not in errors:
                        errors['INVALID_DECLARATION'] = {'line': line_no, 'context': line.strip()}
    
    # Check for mismatched braces/parens using stack-based line tracking
    (p_stack, p_extra, b_stack, b_extra, br_stack, br_extra) = scan_delimiter_stacks(code_lines)
    # Filter out lines that have unterminated strings to avoid corrupted delimiter cascades
    p_stack = [p for p in p_stack if p[0] not in unterminated_string_lines]
    p_extra = [p for p in p_extra if p[0] not in unterminated_string_lines]
    b_stack = [b for b in b_stack if b[0] not in unterminated_string_lines]
    b_extra = [b for b in b_extra if b[0] not in unterminated_string_lines]
    br_stack = [br for br in br_stack if br[0] not in unterminated_string_lines]
    br_extra = [br for br in br_extra if br[0] not in unterminated_string_lines]

    if p_stack:
        errors['UNMATCHED_PARANTHESES'] = {'line': p_stack[-1][0], 'context': p_stack[-1][1]}
    elif p_extra:
        errors['UNMATCHED_PARANTHESES'] = {'line': p_extra[0][0], 'context': p_extra[0][1]}

    if b_stack:
        errors['UNMATCHED_BRACE'] = {'line': b_stack[-1][0], 'context': b_stack[-1][1]}
    elif b_extra:
        errors['UNMATCHED_BRACE'] = {'line': b_extra[0][0], 'context': b_extra[0][1]}

    if br_stack:
        errors['INVALID_ARRAY_DECL'] = {'line': br_stack[-1][0], 'context': br_stack[-1][1]}
    elif br_extra:
        errors['INVALID_ARRAY_DECL'] = {'line': br_extra[0][0], 'context': br_extra[0][1]}
    
    return errors


VALID_TYPE_COMPOUNDS = {
    ("unsigned", "int"),
    ("unsigned", "long"),
    ("unsigned", "short"),
    ("unsigned", "char"),
    ("signed", "int"),
    ("signed", "long"),
    ("signed", "short"),
    ("signed", "char"),
    ("long", "long"),
    ("long", "int"),
    ("long", "double"),
    ("short", "int"),
}

TYPE_KEYWORDS = {
    "int", "float", "double", "char", "bool", "void",
    "long", "short", "unsigned", "signed", "string", "auto"
}


def detect_syntax_errors_in_code_multi(code_lines):
    """Detect all syntax errors at the source code level and return a list of error dicts."""
    errors = []
    unterminated_string_lines = []

    source_code = "".join(code_lines)
    masked_source = mask_comments(source_code)
    masked_lines = masked_source.splitlines(keepends=True)

    for line_no, line in enumerate(code_lines, 1):
        line_clean = masked_lines[line_no - 1] if line_no <= len(masked_lines) else ""
        line_stripped = line_clean.strip()

        # Check for unterminated strings
        line_has_unterminated_str = False
        if '"' in line_clean:
            str_count = 0
            i = 0
            while i < len(line_clean):
                if line_clean[i] == '"' and (i == 0 or line_clean[i-1] != '\\'):
                    str_count += 1
                i += 1
            if str_count % 2 == 1:
                line_has_unterminated_str = True
                unterminated_string_lines.append(line_no)
                errors.append({'type': 'UNTERMINATED_STRING', 'line': line_no, 'context': line.strip()})

        is_preprocessor = bool(re.match(r'^\s*#', line_clean))

        # MISSING_SEMICOLON per line check (skip if line has unclosed string or is preprocessor directive)
        if not line_has_unterminated_str and not is_preprocessor:
            raw_stripped = line_clean.rstrip()
            if raw_stripped and not raw_stripped.endswith(';') and not raw_stripped.endswith('{') and not raw_stripped.endswith('}') and not raw_stripped.endswith(':'):
                is_control_flow = re.match(r'^\s*(for|while|if|else\s+if)\b', line_stripped)
                is_func_header = bool(re.search(r'\b[a-zA-Z_]\w*\s*\([^)]*\)\s*$', raw_stripped))
                if not is_control_flow and not is_func_header:
                    if re.search(r'\b(int|float|double|char|bool|void|string|long|short|unsigned|signed|auto)\b.*[^{};]$', raw_stripped) or \
                       re.search(r'(\+=|-=|\*=|/=|%=|<<=|>>=|&=|\^=|\|=|=(?!=)).*[^{};]$', raw_stripped) or \
                       re.search(r'^\s*return\b.*[^{};]$', raw_stripped):
                        errors.append({'type': 'MISSING_SEMICOLON', 'line': line_no, 'context': line.strip()})

        # Check for malformed preprocessor directives
        if is_preprocessor:
            m_inc = re.match(r'^\s*#\s*include(?:\s+(.*))?$', line_clean)
            if m_inc:
                target = (m_inc.group(1) or "").strip()
                if not target:
                    errors.append({'type': 'INVALID_DECLARATION', 'line': line_no, 'context': line.strip()})
                elif target.startswith('<'):
                    if not target.endswith('>') or target == '<>':
                        errors.append({'type': 'INVALID_DECLARATION', 'line': line_no, 'context': line.strip()})
                elif target.startswith('"'):
                    if not target.endswith('"') or len(target) < 2:
                        pass
                else:
                    errors.append({'type': 'INVALID_DECLARATION', 'line': line_no, 'context': line.strip()})

        # Non-preprocessor statement checks
        if not is_preprocessor:
            # INVALID_LOOP: line starts with for/while with no '(' right after, or misspelled loop keywords
            m_loop_mis = re.search(r'^\s*(whlie|wile|whil|foor|fro)\b', line_clean)
            if m_loop_mis:
                errors.append({'type': 'INVALID_LOOP', 'line': line_no, 'column': m_loop_mis.start(1) + 1, 'context': line.strip()})
            else:
                m_loop = re.search(r'^\s*(for|while)\b(?!\s*\()', line_clean)
                if m_loop:
                    errors.append({'type': 'INVALID_LOOP', 'line': line_no, 'column': m_loop.start(1) + 1, 'context': line.strip()})
                else:
                    m_for_unclosed = re.search(r'^\s*for\s*\([^)]*\{', line_clean)
                    if m_for_unclosed:
                        errors.append({'type': 'INVALID_LOOP', 'line': line_no, 'context': line.strip()})
                    else:
                        m_for_hdr = re.search(r'^\s*for\s*\(([^)]*)\)', line_clean)
                        if m_for_hdr:
                            inner = m_for_hdr.group(1)
                            if ':' not in inner and inner.count(';') < 2:
                                errors.append({'type': 'INVALID_LOOP', 'line': line_no, 'context': line.strip()})

            # INVALID_CONDITIONAL: line starts with if with no '(' right after, or condition is empty / incomplete
            m_cond = re.search(r'^\s*(if|else\s+if)\b(?!\s*\()', line_clean)
            if m_cond:
                errors.append({'type': 'INVALID_CONDITIONAL', 'line': line_no, 'column': m_cond.start(1) + 1, 'context': line.strip()})
            else:
                m_cond_incomplete = re.search(r'\b(?:if|else\s+if)\s*\((?:[^)]*?(?:[><!=]=?|&&|\|\||[+*/%=-])\s*|\s*)\)', line_clean)
                if m_cond_incomplete:
                    errors.append({'type': 'INVALID_CONDITIONAL', 'line': line_no, 'context': line.strip()})

            # INVALID_FUNCTION_DECL: function header missing closing parenthesis before opening brace, or trailing comma in parameter list
            if re.search(r'^\s*(?:[a-zA-Z_]\w*[\s*&]+)+[a-zA-Z_]\w*\s*\([^)]*\{', line_clean) or \
               re.search(r'^\s*(?:[a-zA-Z_]\w*[\s*&]+)+[a-zA-Z_]\w*\s*\([^)]*,\s*\)\s*\{?', line_clean):
                errors.append({'type': 'INVALID_FUNCTION_DECL', 'line': line_no, 'context': line.strip()})

            # INVALID_DECLARATION: declaration missing identifier or identifier starting with digit
            if re.search(r'^\s*(?:int|float|double|char|bool|void|string|long|short|unsigned|signed|auto)\s*;', line_clean) or \
               re.search(r'^\s*(?:int|float|double|char|bool|void|string|long|short|unsigned|signed|auto)\s*=', line_clean) or \
               re.search(r'^\s*(?:int|float|double|char|bool|void|string|long|short|unsigned|signed|auto)\s+\d+\w*\b', line_clean):
                errors.append({'type': 'INVALID_DECLARATION', 'line': line_no, 'context': line.strip()})

            # INVALID_TYPE: two consecutive type keywords, or arithmetic type initialized with string literal
            words = re.findall(r'\b[a-zA-Z_]\w*\b', line_clean)
            for w_idx in range(len(words) - 1):
                w1, w2 = words[w_idx], words[w_idx + 1]
                if w1 in TYPE_KEYWORDS and w2 in TYPE_KEYWORDS:
                    if (w1, w2) not in VALID_TYPE_COMPOUNDS:
                        errors.append({'type': 'INVALID_TYPE', 'line': line_no, 'context': line.strip()})
                        break
            if re.search(r'^\s*(?:int|float|double|long|short|unsigned|signed|bool)\s+[a-zA-Z_]\w*\s*=\s*"', line_clean):
                errors.append({'type': 'INVALID_TYPE', 'line': line_no, 'context': line.strip()})

            # INVALID_ASSIGNMENT: a numeric literal on the left of '=' at statement level, or missing RHS before semicolon
            if re.search(r'(?:^|[;{}])\s*\d+\s*=(?!=)', line_clean) or re.search(r'=(?!=)\s*;', line_clean):
                errors.append({'type': 'INVALID_ASSIGNMENT', 'line': line_no, 'context': line.strip()})

            # INVALID_ARRAY_DECL: '[' opened but ']' missing before ';', or initializer exceeds size
            if re.search(r'\[[^\]]*;', line_clean):
                errors.append({'type': 'INVALID_ARRAY_DECL', 'line': line_no, 'context': line.strip()})
            m_arr = re.search(r'\b[a-zA-Z_]\w*\s*\[\s*(\d+)\s*\]\s*=\s*\{([^}]+)\}', line_clean)
            if m_arr:
                try:
                    arr_cap = int(m_arr.group(1))
                    init_items = [x.strip() for x in m_arr.group(2).split(',') if x.strip()]
                    if len(init_items) > arr_cap:
                        errors.append({'type': 'INVALID_ARRAY_DECL', 'line': line_no, 'context': line.strip()})
                except ValueError:
                    pass

            # EXTRA_TOKENS: ';;' present, consecutive numeric literals in expression, or unexpected trailing tokens after return
            if ';;' in line_clean or re.search(r'\b\d+\s+\d+\b', line_clean) or re.search(r'\breturn\s+(?:\d+|"[^"]*"|[a-zA-Z_]\w*)\s+[a-zA-Z_]\w*\s*;', line_clean):
                errors.append({'type': 'EXTRA_TOKENS', 'line': line_no, 'context': line.strip()})

            # MISPLACED_KEYWORD: 'return if/else/while/for', keyword as variable name, 'else' with no preceding if, or break/continue outside loop
            if re.search(r'\breturn\s+(if|else|while|for)\b', line_clean) or \
               re.search(r'^\s*(?:int|float|double|char|bool|void|string|long|short|unsigned|signed|auto)\s+(?:return|if|else|while|for|switch|case|default|break|continue|goto|class|struct)\b', line_clean):
                errors.append({'type': 'MISPLACED_KEYWORD', 'line': line_no, 'context': line.strip()})
            elif re.search(r'^\s*else\b', line_clean):
                has_valid_prev = False
                for prev_idx in range(line_no - 2, -1, -1):
                    prev_line = re.sub(r'//.*', '', code_lines[prev_idx]).strip()
                    if prev_line:
                        if 'if' in prev_line or '}' in prev_line:
                            has_valid_prev = True
                        break
                if not has_valid_prev:
                    errors.append({'type': 'MISPLACED_KEYWORD', 'line': line_no, 'context': line.strip()})
            elif re.search(r'^\s*(?:break|continue)\s*;', line_clean):
                in_valid_scope = False
                brace_depth = 0
                for prev_idx in range(line_no - 2, -1, -1):
                    pl = masked_lines[prev_idx]
                    brace_depth += pl.count('}') - pl.count('{')
                    if brace_depth > 0:
                        break
                    if re.search(r'\b(for|while|switch)\b', pl):
                        in_valid_scope = True
                        break
                    if re.search(r'\b[a-zA-Z_]\w*\s*\([^)]*\)\s*\{', pl):
                        break
                if not in_valid_scope:
                    errors.append({'type': 'MISPLACED_KEYWORD', 'line': line_no, 'context': line.strip()})

    # Whole-file balance checks (filtering out lines with unterminated strings)
    (p_stack, p_extra, b_stack, b_extra, br_stack, br_extra) = scan_delimiter_stacks(code_lines)
    for un_line, un_ctx in p_stack:
        if un_line not in unterminated_string_lines:
            errors.append({'type': 'UNMATCHED_PARANTHESES', 'line': un_line, 'context': un_ctx})
    for un_line, un_ctx in p_extra:
        if un_line not in unterminated_string_lines:
            errors.append({'type': 'UNMATCHED_PARANTHESES', 'line': un_line, 'context': un_ctx})

    for un_line, un_ctx in b_stack:
        if un_line not in unterminated_string_lines:
            errors.append({'type': 'UNMATCHED_BRACE', 'line': un_line, 'context': un_ctx})
    for un_line, un_ctx in b_extra:
        if un_line not in unterminated_string_lines:
            errors.append({'type': 'UNMATCHED_BRACE', 'line': un_line, 'context': un_ctx})

    for un_line, un_ctx in br_stack:
        if un_line not in unterminated_string_lines:
            errors.append({'type': 'INVALID_ARRAY_DECL', 'line': un_line, 'context': un_ctx})
    for un_line, un_ctx in br_extra:
        if un_line not in unterminated_string_lines:
            errors.append({'type': 'INVALID_ARRAY_DECL', 'line': un_line, 'context': un_ctx})

    return errors


def filter_cascading_errors(all_errors):
    """Filter out cascading secondary errors caused by lexical / root errors."""
    lexical_root_types = {"UNTERMINATED_STRING"}
    lex_lines = {e['line'] for e in all_errors if e['type'] in lexical_root_types and e['line'] > 0}

    if lex_lines:
        min_lex_line = min(lex_lines)
        filtered = []
        for e in all_errors:
            etype = e['type']
            line = e['line']

            # Retain the root lexical error
            if etype in lexical_root_types:
                filtered.append(e)
                continue

            # Parser errors at EOF (line <= 0) are cascades caused by lexical error breaking token stream
            if line <= 0:
                continue

            # Secondary errors on the same line as the lexical error are cascades
            if etype in {"MISSING_SEMICOLON", "INVALID_FUNCTION_DECL", "INVALID_DECLARATION"} and line in lex_lines:
                continue

            # Extra closing brace '}' after an unterminated string is a cascade (broken string scope)
            # but preserve genuine unclosed opening braces ('{' in context)
            if etype in {"UNMATCHED_BRACE"} and line >= min_lex_line:
                ctx = e.get("context", "")
                if ctx.strip() in ("}", "};") or ("}" in ctx and "{" not in ctx):
                    continue

            filtered.append(e)
        all_errors = filtered

    # Suppress secondary unmatched brace after function declaration missing opening brace '{'
    func_lines = {
        e['line'] for e in all_errors
        if e['type'] == 'INVALID_FUNCTION_DECL' and e['line'] > 0
    }
    if func_lines:
        filtered = []
        for e in all_errors:
            if e['type'] == 'UNMATCHED_BRACE':
                if any(0 < e['line'] - f_line <= 5 for f_line in func_lines):
                    ctx = e.get("context", "")
                    if ctx.strip() in ("}", "};") or ("}" in ctx and "{" not in ctx):
                        continue
            filtered.append(e)
        all_errors = filtered

    # Suppress secondary UNMATCHED_PARANTHESES on the same line as an INVALID_FUNCTION_DECL or INVALID_LOOP
    paren_suppress_lines = {
        e['line'] for e in all_errors
        if e.get('type') in {'INVALID_FUNCTION_DECL', 'INVALID_LOOP'} and e.get('line', 0) > 0
    }
    if paren_suppress_lines:
        all_errors = [
            e for e in all_errors
            if not (e.get('type') == 'UNMATCHED_PARANTHESES' and e.get('line', 0) in paren_suppress_lines)
        ]

    # Suppress secondary MISSING_SEMICOLON on the same line as an INVALID_CONDITIONAL, INVALID_LOOP, INVALID_ARRAY_DECL, EXTRA_TOKENS, MISPLACED_KEYWORD, INVALID_FUNCTION_DECL
    non_semi_lines = {
        e['line'] for e in all_errors
        if e.get('type') in {'INVALID_CONDITIONAL', 'INVALID_LOOP', 'INVALID_ARRAY_DECL', 'EXTRA_TOKENS', 'MISPLACED_KEYWORD', 'INVALID_FUNCTION_DECL'} and e.get('line', 0) > 0
    }
    if non_semi_lines:
        all_errors = [
            e for e in all_errors
            if not (e.get('type') == 'MISSING_SEMICOLON' and e.get('line', 0) in non_semi_lines)
        ]

    return all_errors


def collect_all_errors(code_lines, parse_errors, source_errors_multi):
    """Merge AST/parser errors with multi-detector results, deduplicated by (type, line), sorted by line number."""
    all_errors = []
    seen = set()

    # Pre-check genuine delimiter balance in source code
    has_genuine_unmatched_brace = any(
        e['type'] == 'UNMATCHED_BRACE' and e['line'] > 0
        for e in source_errors_multi
    )
    has_genuine_unmatched_paren = any(
        e['type'] == 'UNMATCHED_PARANTHESES' and e['line'] > 0
        for e in source_errors_multi
    )

    for pe in parse_errors:
        etype = None
        for t in [
            "UNTERMINATED_STRING", "MISPLACED_KEYWORD", "INVALID_ASSIGNMENT", "INVALID_CONDITIONAL",
            "INVALID_LOOP", "INVALID_TYPE", "INVALID_ARRAY_DECL",
            "INVALID_FUNCTION_DECL", "INVALID_SWITCH", "INVALID_CLASS_DECL",
            "INVALID_NAMESPACE_DECL", "UNMATCHED_BRACE", "UNMATCHED_PARANTHESES",
            "MISSING_SEMICOLON", "EXTRA_TOKENS", "INVALID_DECLARATION",
            "INVALID_CPP_STRUCTURE"
        ]:
            if t in pe:
                etype = t
                break
        if not etype:
            continue

        # If parser inferred UNMATCHED_BRACE but braces in source are actually balanced,
        # it is a false recovery artifact caused by earlier syntax error reaching EOF.
        if etype == "UNMATCHED_BRACE" and not has_genuine_unmatched_brace:
            continue

        # If parser inferred UNMATCHED_PARANTHESES but parens in source are balanced,
        # it is a false recovery artifact.
        if etype == "UNMATCHED_PARANTHESES" and not has_genuine_unmatched_paren:
            continue

        line_num = -1
        match = re.search(r"line\s+(\d+)", pe)
        if match:
            line_num = int(match.group(1))

        # If parser reports EOF (line_num <= 0) for unmatched paren or brace,
        # translate that parser-level EOF back to the source location where it originated.
        if line_num <= 0:
            if etype == "UNMATCHED_PARANTHESES" and has_genuine_unmatched_paren:
                matched_se = next((se for se in source_errors_multi if se['type'] == 'UNMATCHED_PARANTHESES' and se['line'] > 0), None)
                if matched_se:
                    line_num = matched_se['line']
            elif etype == "UNMATCHED_BRACE" and has_genuine_unmatched_brace:
                matched_se = next((se for se in source_errors_multi if se['type'] == 'UNMATCHED_BRACE' and se['line'] > 0), None)
                if matched_se:
                    line_num = matched_se['line']

        ctx = ""
        if 1 <= line_num <= len(code_lines):
            ctx = code_lines[line_num - 1].strip()
        else:
            ctx = pe

        key = (etype, line_num)
        if key not in seen:
            seen.add(key)
            all_errors.append({'type': etype, 'line': line_num, 'context': ctx})

    for se in source_errors_multi:
        key = (se['type'], se['line'])
        if key not in seen:
            seen.add(key)
            all_errors.append(se)
        else:
            if 'column' in se:
                for entry in all_errors:
                    if entry['type'] == se['type'] and entry['line'] == se['line'] and 'column' not in entry:
                        entry['column'] = se['column']
                        break

    # Filter out cascading secondary errors caused by lexical / root errors
    all_errors = filter_cascading_errors(all_errors)

    # If we have an error with a known line > 0 for a given type, drop any duplicate line <= 0 of that same type
    known_lines = {e['type'] for e in all_errors if e['line'] > 0}
    all_errors = [e for e in all_errors if not (e['line'] <= 0 and e['type'] in known_lines)]

    # Final guarantee: If braces are genuinely balanced in source, purge any remaining UNMATCHED_BRACE
    if not has_genuine_unmatched_brace:
        all_errors = [e for e in all_errors if e['type'] != 'UNMATCHED_BRACE']

    # Final guarantee: If parens are genuinely balanced in source, purge any remaining UNMATCHED_PARANTHESES
    if not has_genuine_unmatched_paren:
        all_errors = [e for e in all_errors if e['type'] != 'UNMATCHED_PARANTHESES']

    def sort_key(e):
        ln = e['line']
        return (0, ln) if ln > 0 else (1, 0)

    all_errors.sort(key=sort_key)
    return all_errors


def predict_multi(filepath, self_heal=False, allow_execution=False):
    """Multi-error predictor: detects all syntax errors, formats a report, and optionally self-heals."""
    start_time = time.time()
    
    if not os.path.exists(filepath):
        print(f"ERROR: File not found: {filepath}")
        sys.exit(1)

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            code_lines = f.readlines()
    except Exception as e:
        print(f"ERROR reading source code: {e}")
        sys.exit(1)

    detection_start = time.time()
    source_code = "".join(code_lines)
    tokens = tokenize(filepath)

    from structural_validator import validate_cpp_structure, StructuralClassification
    struct_res = validate_cpp_structure(tokens, source_code)

    if struct_res.classification == StructuralClassification.EMPTY:
        safe_print("\n  NO SYNTAX ERRORS DETECTED: Code is empty or whitespace-only.")
        import json as _json
        print(f"ERRORS_JSON:[]")
        perf_json = {
            "error_type": "NONE",
            "error_count": 0,
            "error_types": [],
            "confidence": 100.0,
            "detection_time": float(time.time() - start_time),
            "fix_attempted": False,
            "fix_compiled": False,
            "total_time": float(time.time() - start_time),
        }
        print(f"PERF_JSON:{_json.dumps(perf_json)}")
        return

    if struct_res.classification in (StructuralClassification.UNRECOGNIZED_STRUCTURE, StructuralClassification.AMBIGUOUS_INCOMPLETE):
        conf_val = round(struct_res.confidence * 100, 1)
        err_line = 1
        err_ctx = code_lines[0].strip() if code_lines else ""
        for idx, l in enumerate(code_lines, 1):
            if l.strip():
                err_line = idx
                err_ctx = l.strip()
                break

        desc = (
            "The input is unrecognized or incomplete; it does not form a complete C++ declaration, statement, expression, or program structure."
            if struct_res.is_ambiguous else
            "The input does not match a recognizable C++ declaration, statement, expression, or program structure."
        )

        all_errors = [{
            'type': 'INVALID_CPP_STRUCTURE',
            'line': err_line,
            'context': err_ctx,
            'uncertain_location': struct_res.is_ambiguous,
            'confidence': conf_val,
            'description': desc,
        }]

        safe_print("\n  SYNTAX DIAGNOSTICS REPORT (MULTI-ERROR DETECTION):")
        safe_print("  --------------------------------------------------")
        safe_print(f"\n  ERROR #1: INVALID_CPP_STRUCTURE")
        safe_print(f"  Line {err_line}: {err_ctx}")
        safe_print(f"  Description: {desc}")
        safe_print("  Suggested Fix:")
        safe_print("    Provide valid C++ code, such as:")
        safe_print("      1. A complete program: int main() { return 0; }")
        safe_print("      2. A valid function definition: void func() { }")
        safe_print("      3. A valid declaration or statement: int x = 0;")
        safe_print("  Example:\n  hfghfdghdjdf        ← invalid: arbitrary text without C++ structure\n  int x = 10;         ← correct: valid declaration\n  int main() { }      ← correct: valid function")

        safe_print(f"\n  TOTAL: 1 error(s) across 1 categories: INVALID_CPP_STRUCTURE")

        import json as _json
        err_obj = {
            "index": 1,
            "type": "INVALID_CPP_STRUCTURE",
            "line": err_line,
            "context": err_ctx,
            "uncertain_location": struct_res.is_ambiguous,
            "confidence": conf_val,
            "description": desc,
            "fix": "Provide valid C++ code, such as:\n  1. A complete program: int main() { return 0; }\n  2. A valid function definition: void func() { }\n  3. A valid declaration or statement: int x = 0;",
            "example": "  hfghfdghdjdf        ← invalid: arbitrary text without C++ structure\n  int x = 10;         ← correct: valid declaration\n  int main() { }      ← correct: valid function"
        }
        print(f"ERRORS_JSON:{_json.dumps([err_obj])}")
        perf_json = {
            "error_type": "INVALID_CPP_STRUCTURE",
            "error_count": 1,
            "error_types": ["INVALID_CPP_STRUCTURE"],
            "confidence": conf_val,
            "detection_time": float(time.time() - start_time),
            "fix_attempted": False,
            "fix_compiled": False,
            "total_time": float(time.time() - start_time),
        }
        print(f"PERF_JSON:{_json.dumps(perf_json)}")
        return

    ast_root, parse_errors = build_ast(tokens) if tokens else (None, [])
    source_errors_multi = detect_syntax_errors_in_code_multi(code_lines)
    all_errors = collect_all_errors(code_lines, parse_errors, source_errors_multi)
    detection_time = time.time() - detection_start

    # If no syntax errors found by rule/parser detectors, verify whether code is genuinely clean
    if not all_errors:
        compiler = find_cxx_compiler()
        if compiler:
            try:
                from compiler_sandbox import run_contained_compiler, CompilerSandboxLimits
                proc = run_contained_compiler(
                    [compiler, '-std=c++17', '-fsyntax-only', filepath],
                    env=get_sanitized_compiler_env(),
                    limits=CompilerSandboxLimits(timeout_seconds=10.0)
                )
                stderr_errs = [l for l in proc.stderr.splitlines() if "error:" in l or "fatal error:" in l]
                syntax_indicator_words = [
                    "expected ';'", "expected '}'", "expected ')'", "expected ']' ",
                    "expected primary-expression", "missing terminating", "syntax error"
                ]
                has_syntax_error_in_compiler = any(
                    any(si in l.lower() for si in syntax_indicator_words)
                    for l in stderr_errs
                )
                code_stripped_lines = [l.strip() for l in code_lines if l.strip()]
                has_unterminated_line = any(
                    l and not l.startswith(("#", "//", "/*", "*"))
                    and not l.endswith((";", "{", "}", ":", ">", "\\"))
                    and not re.match(r"^\s*(for|while|if|else\s+if|else|switch|case|default|class|struct|enum|namespace)\b", l)
                    for l in code_stripped_lines
                )
                is_purely_semantic = bool(stderr_errs) and not has_syntax_error_in_compiler and not has_unterminated_line and all(
                    "was not declared in this scope" in l or
                    "does not name a type" in l or
                    "does not name a template type" in l or
                    "is not a member of" in l or
                    "has no member named" in l or
                    "not a member of" in l or
                    "no member named" in l or
                    "cannot find" in l or
                    "No such file or directory" in l or
                    "Cannot open include file" in l or
                    "undeclared identifier" in l
                    for l in stderr_errs
                )

                if proc.returncode == 0:
                    safe_print("\n  NO SYNTAX ERRORS DETECTED: Code compiled with zero errors.")
                    import json as _json
                    print(f"ERRORS_JSON:[]")
                    perf_json = {
                        "error_type": "NONE",
                        "error_count": 0,
                        "error_types": [],
                        "confidence": 100.0,
                        "detection_time": float(detection_time),
                        "fix_attempted": False,
                        "fix_compiled": True,
                        "total_time": float(time.time() - start_time),
                    }
                    print(f"PERF_JSON:{_json.dumps(perf_json)}")
                    return
                elif is_purely_semantic and struct_res.classification == StructuralClassification.VALID_PROGRAM_OR_SNIPPET:
                    safe_print("\n  NO SYNTAX ERRORS DETECTED: Code is syntactically valid. Note: Semantic issue(s) detected (unknown identifiers/types).")
                    import json as _json
                    print(f"ERRORS_JSON:[]")
                    perf_json = {
                        "error_type": "NONE",
                        "error_count": 0,
                        "error_types": [],
                        "confidence": 100.0,
                        "detection_time": float(detection_time),
                        "fix_attempted": False,
                        "fix_compiled": False,
                        "total_time": float(time.time() - start_time),
                    }
                    print(f"PERF_JSON:{_json.dumps(perf_json)}")
                    return
            except Exception:
                pass
        else:
            safe_print("\n  NO SYNTAX ERRORS DETECTED: Code parsed with zero errors.")
            import json as _json
            print(f"ERRORS_JSON:[]")
            perf_json = {
                "error_type": "NONE",
                "error_count": 0,
                "error_types": [],
                "confidence": 100.0,
                "detection_time": float(detection_time),
                "fix_attempted": False,
                "fix_compiled": False,
                "total_time": float(time.time() - start_time),
            }
            print(f"PERF_JSON:{_json.dumps(perf_json)}")
            return

        # Fallback to single-label ML predict() if syntax-only check did not pass
        predict(filepath, self_heal=self_heal)
        return

    # Print numbered report
    safe_print("\n  SYNTAX DIAGNOSTICS REPORT (MULTI-ERROR DETECTION):")
    safe_print("  --------------------------------------------------")

    for idx, err in enumerate(all_errors, 1):
        safe_print(f"\n  ERROR #{idx}: {err['type']}")
        if err['line'] > 0:
            safe_print(f"  Line {err['line']}: {err['context']}")
        else:
            safe_print(f"  Context: {err['context']}")
        
        diag = DIAGNOSTICS.get(err['type'], {
            "description": "Unknown error type detected.",
            "fix": "Review your code carefully for syntax issues.",
            "example": ""
        })
        safe_print(f"  Description: {diag['description']}")
        safe_print(f"  Suggested Fix:")
        for fix_line in diag['fix'].split('\n'):
            safe_print(f"    {fix_line}")
        if diag.get("example"):
            safe_print(f"  Example:\n{diag['example']}")

    distinct_types = sorted(list(set(e['type'] for e in all_errors)))
    safe_print(f"\n  TOTAL: {len(all_errors)} error(s) across {len(distinct_types)} categories: {', '.join(distinct_types)}")

    fix_attempted = self_heal
    fix_compiled = False

    if self_heal:
        current_lines = list(code_lines)
        total_changes = []
        for etype in distinct_types:
            first_occ = next(e for e in all_errors if e['type'] == etype)
            single_source = {etype: {'line': first_occ['line'], 'context': first_occ['context']}}
            fixed_lines, changes = apply_autofix(current_lines, etype, [], single_source)
            if changes:
                current_lines = fixed_lines
                total_changes.extend(changes)

        if total_changes:
            print(f"\n  AUTO-FIX CHANGES ({len(total_changes)}):")
            for change in total_changes:
                formatted = change.replace('\n', '\n      ')
                print(f"    - {formatted}")
            fixed_path = os.path.splitext(filepath)[0] + ".fixed.cpp"
            with open(fixed_path, "w", encoding="utf-8", errors="ignore") as f:
                f.writelines(current_lines)
            print(f"\n  Saved repaired file to: {fixed_path}")
            compiled, output, rc, status = compile_and_run_cpp(fixed_path, allow_execution=allow_execution)
            if compiled:
                fix_compiled = True
                print("\n  AUTO-FIX RESULT: compilation succeeded")
                print("  COMPILE/RUN SUCCESS:")
                print(f"    {output}")
            else:
                if status == 'compiler_not_found':
                    print("\n  AUTO-FIX RESULT: compiler not found")
                    print(f"    {output}")
                elif status == 'compile_error':
                    print("\n  AUTO-FIX RESULT: compilation failed (repaired code still contains errors)")
                    print(f"    {output}")
                elif status == 'execution_error':
                    print("\n  AUTO-FIX RESULT: compiler execution failed (runtime/environment error)")
                    print(f"    {output}")
                else:
                    print("\n  AUTO-FIX RESULT: compilation failed")
                    print(f"    {output}")
        else:
            print("\n  AUTO-FIX: No automatic repair could be applied for the detected error type(s).")
    else:
        print("\n  AUTO-FIX: Disabled. Enable 'Attempt auto-fix' (--self-heal) to repair.")

    total_time = time.time() - start_time

    import json as _json
    errors_json_list = []
    for idx, err in enumerate(all_errors, 1):
        diag = DIAGNOSTICS.get(err['type'], {
            "description": "Unknown error type detected.",
            "fix": "Review your code carefully for syntax issues.",
            "example": ""
        })
        errors_json_list.append({
            "index": idx,
            "type": err['type'],
            "line": err['line'],
            "context": err['context'],
            "description": diag.get("description", ""),
            "fix": diag.get("fix", ""),
            "example": diag.get("example", "")
        })
    print(f"ERRORS_JSON:{_json.dumps(errors_json_list)}")

    perf_json = {
        "error_type": all_errors[0]['type'] if all_errors else "NONE",
        "error_count": len(all_errors),
        "error_types": distinct_types,
        "confidence": 95.0,
        "detection_time": float(detection_time),
        "fix_attempted": fix_attempted,
        "fix_compiled": fix_compiled,
        "total_time": float(total_time),
    }
    print(f"PERF_JSON:{_json.dumps(perf_json)}")


def infer_error_line(parse_errors, source_errors, error_type=None, code_lines=None):
    """Infer error line from parse/source errors, or scan code for the error pattern."""
    # First try parse errors
    for error in parse_errors:
        match = re.search(r"line\s+(\d+)", error)
        if match:
            line_num = int(match.group(1))
            # For INVALID_SWITCH with case error, search backward from reported line for actual 'case' line
            if error_type == 'INVALID_SWITCH' and code_lines and 'case' in error.lower():
                for i in range(max(0, line_num-10), min(len(code_lines), line_num+1)):
                    if code_lines[i].lstrip().startswith('case') and ':' not in code_lines[i]:
                        return i + 1
            return line_num
    # Then try source errors
    for error_info in source_errors.values():
        if error_info.get('line', 0) > 0:
            return error_info['line']
    # If no explicit line info, try to find the error by scanning code
    if error_type and code_lines:
        if error_type == 'INVALID_LOOP':
            for i, line in enumerate(code_lines, 1):
                stripped = line.lstrip()
                if (stripped.startswith('for') or stripped.startswith('while')) and '(' not in line:
                    return i
        elif error_type == 'INVALID_CONDITIONAL':
            for i, line in enumerate(code_lines, 1):
                stripped = line.lstrip()
                if stripped.startswith('if') and '(' not in line:
                    return i
        elif error_type == 'MISSING_SEMICOLON':
            for i, line in enumerate(code_lines, 1):
                stripped = line.rstrip()
                if stripped and not stripped.endswith(';') and not stripped.endswith('{') and not stripped.endswith('}'):
                    if re.search(r'\b(int|float|double|char|bool|void|string)\b.*[^{};]$', stripped):
                        return i
        elif error_type == 'INVALID_SWITCH':
            for i, line in enumerate(code_lines, 1):
                stripped = line.lstrip()
                # Look for case without colon
                if stripped.startswith('case') and ':' not in line:
                    return i
                # Look for switch without opening brace
                if stripped.startswith('switch') and '{' not in line and '(' in line:
                    return i
        elif error_type == 'UNMATCHED_PARANTHESES':
            p_stack, p_extra, _, _, _, _ = scan_delimiter_stacks(code_lines)
            if p_stack:
                return p_stack[-1][0]
            elif p_extra:
                return p_extra[0][0]
        elif error_type == 'UNMATCHED_BRACE':
            _, _, b_stack, b_extra, _, _ = scan_delimiter_stacks(code_lines)
            if b_stack:
                return b_stack[-1][0]
            elif b_extra:
                return b_extra[0][0]
    return None


def apply_autofix(code_lines, error_type, parse_errors, source_errors):
    fixed_lines = list(code_lines)
    changes = []
    line_no = infer_error_line(parse_errors, source_errors, error_type, code_lines)
    idx = line_no - 1 if line_no and line_no <= len(fixed_lines) else None

    def replace_line(new_text, reason, index):
        if index is None or index < 0 or index >= len(fixed_lines):
            return
        current = fixed_lines[index].rstrip('\n')
        candidate = new_text.rstrip('\n')
        if current != candidate:
            fixed_lines[index] = candidate + '\n'
            changes.append(f"Line {index+1}: {reason}\n    - {current}\n    + {candidate}")

    def append_line(text, reason):
        fixed_text = text if text.endswith('\n') else text + '\n'
        fixed_lines.append(fixed_text)
        changes.append(f"Appended line: {reason}\n    + {text.rstrip()}")

    def add_missing_brace():
        open_count = sum(line.count('{') for line in fixed_lines)
        close_count = sum(line.count('}') for line in fixed_lines)
        if open_count > close_count:
            append_line('}', 'Added missing closing brace')
        elif close_count > open_count:
            fixed_lines.insert(0, '{\n')
            changes.append('Inserted missing opening brace at top of file')

    def add_missing_paren():
        open_count = sum(line.count('(') for line in fixed_lines)
        close_count = sum(line.count(')') for line in fixed_lines)
        if open_count > close_count:
            # Find the specific line that's missing a closing paren
            for i, line in enumerate(fixed_lines):
                line_open = line.count('(')
                line_close = line.count(')')
                if line_open > line_close and line_open > 0:
                    stripped = line.rstrip('\n')
                    diff = line_open - line_close
                    # Add ) before the { if present
                    if '{' in stripped:
                        idx_brace = stripped.rfind('{')
                        prefix = stripped[:idx_brace].rstrip()
                        new_line = prefix + (')' * diff) + ' ' + stripped[idx_brace:]
                        replace_line(new_line, 'Added missing closing parenthesis before brace', i)
                        return
                    elif not stripped.endswith(')'):
                        replace_line(stripped + (')' * diff), 'Added missing closing parenthesis', i)
                        return
            # Fallback
            append_line(')', 'Added missing closing parenthesis')
        elif close_count > open_count:
            fixed_lines.insert(0, '(\n')
            changes.append('Inserted missing opening parenthesis at top of file')

    if error_type == 'MISSING_SEMICOLON' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if line and not line.rstrip().endswith(';') and not line.rstrip().endswith('{') and not line.rstrip().endswith('}'):
            replace_line(line + ';', 'Added missing semicolon', idx)

    if error_type == 'UNMATCHED_BRACE':
        add_missing_brace()

    if error_type == 'UNMATCHED_PARANTHESES':
        add_missing_paren()

    if error_type == 'UNTERMINATED_STRING' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        # Count unescaped quotes
        quote_count = len(re.findall(r'(?<!\\)"', line))
        if quote_count % 2 == 1:
            stripped = line.rstrip()
            if stripped.endswith(';'):
                new_line = stripped[:-1] + '";'
            else:
                new_line = stripped + '"'
            replace_line(new_line, 'Closed unterminated string literal', idx)

    if error_type == 'INVALID_DECLARATION' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        # Fix identifier starting with digit: int 123number = 50; -> int number123 = 50;
        new_line = re.sub(r'\b(\d+)([a-zA-Z_]\w*)\b', r'\2\1', line)
        if new_line != line:
            replace_line(new_line, "Renamed identifier starting with digits to a valid identifier", idx)

    if error_type == 'INVALID_ASSIGNMENT' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if re.search(r'=\s*;', line):
            new_line = re.sub(r'=\s*;', '= 0;', line)
            replace_line(new_line, "[Assumption] Initialized missing value with placeholder 0", idx)
        elif re.search(r'(?:^|[;{}])\s*(\d+)\s*=\s*([a-zA-Z_]\w*)\s*;', line):
            new_line = re.sub(r'(\d+)\s*=\s*([a-zA-Z_]\w*)', r'\2 = \1', line)
            replace_line(new_line, "Corrected literal assignment target to lvalue", idx)

    if error_type == 'INVALID_CONDITIONAL' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if re.search(r'([><!=]=?|&&|\|\||[+*/%=-])\s*\)', line):
            new_line = re.sub(r'([><!=]=?|&&|\|\||[+*/%=-])\s*\)', r'\1 0)', line)
            replace_line(new_line, "[Assumption] Provided placeholder value 0 for incomplete relational expression in condition", idx)
        elif re.match(r"^\s*if\s+[^\(]", line):
            replace_line(re.sub(r"^(\s*if)\s+(.+?)(\s*\{|$)", lambda m: f"{m.group(1)} ({m.group(2).strip()}){m.group(3)}", line), "Added missing parentheses for if condition", idx)

    if error_type == 'INVALID_LOOP' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        stripped = line.lstrip()
        indent = line[:len(line) - len(stripped)]
        # Strip inline comments before parsing
        code_part = re.sub(r'//.*$', '', stripped).rstrip()
        
        if re.search(r'\bfor\s*\([^)]*;\s*[^)]*;\s*[^)]*\{', line):
            new_line = re.sub(r'(\bfor\s*\([^)]*;\s*[^)]*;\s*[^)]*?)(\s*\{)', r'\1)\2', line)
            replace_line(new_line, "Inserted missing closing parenthesis before loop body", idx)
        elif code_part.startswith('while') and '(' not in code_part:
            # "while x > 0 {" → "while (x > 0) {"
            match = re.match(r"while\s+(.+?)(\s*\{)\s*$", code_part)
            if not match:
                match = re.match(r"while\s+(.+)$", code_part)
            if match:
                condition = match.group(1).strip().rstrip('{').strip()
                has_brace = '{' in code_part
                rest = ' {' if has_brace else ''
                new_line = f"{indent}while ({condition}){rest}"
                replace_line(new_line, "Added missing parentheses for while condition", idx)
        
        elif code_part.startswith('for') and '(' not in code_part:
            # "for int i = 0; i < 5; i++ {" → "for (int i = 0; i < 5; i++) {"
            match = re.match(r"for\s+(.+?)(\s*\{)\s*$", code_part)
            if not match:
                match = re.match(r"for\s+(.+)$", code_part)
            if match:
                condition = match.group(1).strip().rstrip('{').strip()
                has_brace = '{' in code_part
                rest = ' {' if has_brace else ''
                new_line = f"{indent}for ({condition}){rest}"
                replace_line(new_line, "Added missing parentheses for for loop", idx)

    if error_type == 'INVALID_ARRAY_DECL' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if re.search(r'\[\s*\d+\s*=', line):
            new_line = re.sub(r'\[\s*(\d+)\s*=', r'[\1] =', line)
            replace_line(new_line, "Added missing closing bracket ']' in array declaration", idx)
        elif '[' in line and ']' not in line:
            # Fix: int arr[10; → int arr[10];
            # Match pattern: [ ... ; and replace with [ ... ];
            new_line = re.sub(r'\[([^\]]+);', r'[\1];', line)
            if new_line != line:
                replace_line(new_line, "Closed missing array bracket", idx)
            elif line.rstrip().endswith(';'):
                # Fallback: add ] before final ;
                replace_line(line.rstrip()[:-1] + '];', "Closed missing array bracket", idx)
            else:
                # No semicolon, just add ]
                replace_line(line + ']', "Closed missing array bracket", idx)

    if error_type == 'INVALID_FUNCTION_DECL' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if re.search(r',\s*\)', line):
            new_line = re.sub(r',\s*\)', ')', line)
            replace_line(new_line, "Removed trailing comma from function parameter list", idx)
        elif line.rstrip().endswith(')'):
            replace_line(line + ' {', "Added missing function body brace", idx)

    if error_type == 'EXTRA_TOKENS' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if re.search(r'\breturn\s+([^;]+?)\s+[a-zA-Z_]\w*\s*;', line):
            new_line = re.sub(r'(\breturn\s+[^;]+?)\s+[a-zA-Z_]\w*\s*;', r'\1;', line)
            replace_line(new_line, "Removed extra token after return expression", idx)
        elif ';;' in line:
            replace_line(line.replace(';;', ';'), "Removed duplicate semicolon", idx)
        elif '$$' in line or '@@' in line or '##' in line:
            replace_line(re.sub(r"\$\$|@@|##", '', line), "Removed stray extra token", idx)

    if error_type == 'INVALID_TYPE' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        pattern = r"\b(int|float|double|char|long|short|unsigned|signed|bool|void)\s+(int|float|double|char|long|short|unsigned|signed|bool|void)\b"
        def fix_type_kw(m):
            t1, t2 = m.group(1), m.group(2)
            if t1 == 'int' and t2 in ('double', 'float'):
                return t2
            return t1
        replace_line(re.sub(pattern, fix_type_kw, line), "Resolved conflicting type keyword", idx)

    if error_type == 'MISPLACED_KEYWORD' and idx is not None:
        line = fixed_lines[idx].rstrip('\n')
        if re.search(r'\b(int|float|double|char|bool|auto)\s+return\s*=', line):
            new_line = re.sub(r'\breturn\s*=', 'retValue =', line)
            replace_line(new_line, "Renamed reserved keyword 'return' used as variable name to 'retValue'", idx)
        elif re.search(r"\breturn\s+if\s*\(", line):
            replace_line(re.sub(r"\breturn\s+if\s*\(", 'return (', line), "Removed misplaced 'if' after return", idx)
        elif re.search(r"\breturn\s+else\b", line):
            replace_line(re.sub(r"\breturn\s+else\b", 'return', line), "Removed misplaced 'else' after return", idx)

    return fixed_lines, changes


def _is_cxx_compiler_runnable(compiler_path):
    if not compiler_path:
        return False
    try:
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
        proc = subprocess.run(
            [compiler_path, '--version'],
            capture_output=True,
            text=True,
            timeout=2.5,
            creationflags=flags,
            env=get_sanitized_compiler_env()
        )
        return proc.returncode == 0
    except Exception:
        return False


def find_cxx_compiler():
    """
    Locates an available C++ compiler executable (g++, clang++).
    1. Checks CXX or GXX environment variable.
    2. Checks system and registry PATH for g++ or clang++.
    3. Searches common installation paths on Windows (MinGW, TDM-GCC, Dev-Cpp, MSYS2, CodeBlocks, etc.).
    Returns the absolute path to the verified runnable compiler executable, or None if not found.
    Skips any candidate that fails the --version check (such as corrupt or incompatible DLL binaries).
    """
    # 0. On Windows, ensure user/machine registry PATH entries are imported if not present
    if sys.platform == 'win32' or os.name == 'nt':
        try:
            import winreg
            for hkey, subkey in [
                (winreg.HKEY_CURRENT_USER, r'Environment'),
                (winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\Session Manager\Environment')
            ]:
                try:
                    with winreg.OpenKey(hkey, subkey) as k:
                        val, _ = winreg.QueryValueEx(k, 'Path')
                        current_parts = set(os.environ.get('PATH', '').split(os.pathsep))
                        for p in val.split(';'):
                            p_clean = p.strip()
                            if p_clean and os.path.isdir(p_clean) and p_clean not in current_parts:
                                os.environ['PATH'] = p_clean + os.pathsep + os.environ['PATH']
                                current_parts.add(p_clean)
                except Exception:
                    pass
        except Exception:
            pass

    for env_var in ('CXX', 'GXX'):
        val = os.environ.get(env_var)
        if val:
            resolved = shutil.which(val) or (os.path.isfile(val) and val)
            if resolved and _is_cxx_compiler_runnable(resolved):
                return resolved

    for name in ('g++', 'clang++', 'g++.exe', 'clang++.exe'):
        path = shutil.which(name)
        if path and _is_cxx_compiler_runnable(path):
            return path

    if sys.platform == 'win32' or os.name == 'nt':
        system_drive = os.environ.get('SystemDrive', 'C:')
        prog_files = os.environ.get('ProgramFiles', os.path.join(system_drive, 'Program Files'))
        prog_files_x86 = os.environ.get('ProgramFiles(x86)', os.path.join(system_drive, 'Program Files (x86)'))
        local_appdata = os.environ.get('LOCALAPPDATA', '')

        candidates = [
            os.path.join(prog_files_x86, 'Embarcadero', 'Dev-Cpp', 'TDM-GCC-64', 'bin', 'g++.exe'),
            os.path.join(prog_files, 'Embarcadero', 'Dev-Cpp', 'TDM-GCC-64', 'bin', 'g++.exe'),
            os.path.join(prog_files_x86, 'Dev-Cpp', 'MinGW64', 'bin', 'g++.exe'),
            os.path.join(prog_files, 'Dev-Cpp', 'MinGW64', 'bin', 'g++.exe'),
            os.path.join(prog_files_x86, 'CodeBlocks', 'MinGW', 'bin', 'g++.exe'),
            os.path.join(prog_files, 'CodeBlocks', 'MinGW', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'TDM-GCC-64', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'MinGW', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'mingw64', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'msys64', 'ucrt64', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'msys64', 'mingw64', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'msys64', 'clang64', 'bin', 'clang++.exe'),
            os.path.join(system_drive, 'w64devkit', 'bin', 'g++.exe'),
            os.path.join(system_drive, 'Strawberry', 'c', 'bin', 'g++.exe'),
        ]
        if local_appdata:
            candidates.append(os.path.join(local_appdata, 'Programs', 'w64devkit', 'bin', 'g++.exe'))
            # WinGet MinGW packages
            winget_pkgs = os.path.join(local_appdata, 'Microsoft', 'WinGet', 'Packages')
            if os.path.isdir(winget_pkgs):
                for pkg in os.listdir(winget_pkgs):
                    if 'WinLibs' in pkg or 'mingw' in pkg.lower():
                        candidates.append(os.path.join(winget_pkgs, pkg, 'mingw64', 'bin', 'g++.exe'))

        for cand in candidates:
            if os.path.isfile(cand) and _is_cxx_compiler_runnable(cand):
                comp_dir = os.path.dirname(os.path.abspath(cand))
                current_path = os.environ.get('PATH', '')
                if comp_dir not in current_path.split(os.pathsep):
                    os.environ['PATH'] = comp_dir + os.pathsep + current_path
                return cand

    return None


def get_sanitized_compiler_env(base_env=None):
    """
    Constructs a minimal, sanitized environment dictionary for compiler and execution
    subprocesses. Prevents leakage of sensitive API keys and credentials while
    preserving essential system and compiler variables (PATH, SystemRoot, TEMP, etc.).

    Explicitly removes:
      - GEMINI_API_KEY, GOOGLE_API_KEY, GEMINI_MODEL
      - Other sensitive credentials (e.g. *_API_KEY, *_SECRET, *_TOKEN, *_KEY)
    Explicitly preserves:
      - PATH, PATHEXT, SystemRoot, windir, TEMP, TMP, SystemDrive, ProgramFiles, etc.
      - CXX, GXX, CC, CFLAGS, CXXFLAGS, LDFLAGS, INCLUDE, LIB, etc.
    """
    env = dict(os.environ if base_env is None else base_env)

    # Core system and compiler environment variables that must NEVER be stripped
    preserve_vars = {
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "WINDIR",
        "TEMP",
        "TMP",
        "COMSPEC",
        "SYSTEMDRIVE",
        "PROGRAMFILES",
        "PROGRAMFILES(X86)",
        "COMMONPROGRAMFILES",
        "COMMONPROGRAMFILES(X86)",
        "LOCALAPPDATA",
        "APPDATA",
        "USERPROFILE",
        "HOMEDRIVE",
        "HOMEPATH",
        "NUMBER_OF_PROCESSORS",
        "OS",
        "PROCESSOR_ARCHITECTURE",
        "PROCESSOR_IDENTIFIER",
        "PROCESSOR_LEVEL",
        "PROCESSOR_REVISION",
        "CXX",
        "GXX",
        "CC",
        "CFLAGS",
        "CXXFLAGS",
        "LDFLAGS",
        "INCLUDE",
        "LIB",
        "LIBPATH",
        "CPATH",
        "C_INCLUDE_PATH",
        "CPLUS_INCLUDE_PATH",
        "LIBRARY_PATH",
        "LD_LIBRARY_PATH",
    }

    # Explicit sensitive variables that must never be exposed to compiler / execution
    sensitive_exact = {
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
        "GEMINI_MODEL",
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_SESSION_TOKEN",
        "GITHUB_TOKEN",
        "GH_TOKEN",
        "SIGNING_KEY",
        "PRIVATE_KEY",
        "SECRET_KEY",
        "KEY_ID",
        "PASSPHRASE",
        "SSH_AUTH_SOCK",
        "SSH_AGENT_PID",
        "GIT_ASKPASS",
        "GIT_CREDENTIAL_HELPER",
    }

    sensitive_patterns = (
        "API_KEY",
        "SECRET",
        "_TOKEN",
        "PRIVATE_KEY",
        "AUTH_KEY",
        "ACCESS_KEY",
        "SIGNING_KEY",
        "CREDENTIAL",
        "PASSPHRASE",
    )

    keys_to_remove = []
    for k in env.keys():
        k_upper = k.upper()
        if k_upper in preserve_vars:
            continue
        if k_upper in sensitive_exact or any(pat in k_upper for pat in sensitive_patterns):
            keys_to_remove.append(k)

    for k in keys_to_remove:
        env.pop(k, None)

    return env


def compile_and_run_cpp(filepath, allow_execution=False):
    """
    Checks C++ code syntax using g++ -std=c++17 -fsyntax-only without executing user code.

    SECURITY NOTE:
    Execution of user-submitted code is disabled by default to prevent arbitrary
    code execution. Running compiled binaries (allow_execution=True) is UNSAFE
    outside a hardened sandbox and must only be used with trusted input.

    Distinguishes four scenarios:
      - compiler_not_found: compiler executable is not available
      - compile_error: compiler executed, but the C++ code has compilation errors
      - success: syntax verification succeeded
      - execution_error: compiler process encountered an execution issue (timeout, OS error)
    Returns: (compiled: bool, message: str, returncode: int or None, status: str)
    """
    compiler = find_cxx_compiler()
    if not compiler:
        return False, 'g++ not found on system. Please install a C++ compiler (such as MinGW/GCC) or add g++ to PATH.', None, 'compiler_not_found'

    sanitized_env = get_sanitized_compiler_env()
    if os.path.isabs(compiler):
        comp_dir = os.path.dirname(compiler)
        current_path = sanitized_env.get('PATH', '')
        if comp_dir not in current_path.split(os.pathsep):
            sanitized_env['PATH'] = comp_dir + os.pathsep + current_path

    if not allow_execution:
        try:
            from compiler_sandbox import run_contained_compiler, CompilerSandboxLimits, CompilerTimeoutError
            limits = CompilerSandboxLimits(timeout_seconds=30.0)
            compile_proc = run_contained_compiler(
                [compiler, '-std=c++17', '-fsyntax-only', filepath],
                env=sanitized_env,
                limits=limits
            )
        except CompilerTimeoutError:
            return False, 'Syntax verification timed out after 30 seconds.', None, 'execution_error'
        except Exception as e:
            return False, f'Failed to execute compiler ({compiler}): {str(e)}', None, 'execution_error'

        if compile_proc.returncode != 0:
            err_msg = compile_proc.stderr.strip() or compile_proc.stdout.strip() or f'Compiler exited with code {compile_proc.returncode}'
            return False, err_msg, compile_proc.returncode, 'compile_error'

        return True, 'Syntax check passed (verification with -fsyntax-only succeeded).', 0, 'success'

    # UNSAFE path (opt-in only): Compile to binary and execute
    target_dir = os.path.dirname(os.path.abspath(filepath)) or '.'
    with tempfile.TemporaryDirectory(dir=target_dir) as td:
        exe_name = 'a.exe' if (sys.platform == 'win32' or os.name == 'nt') else 'a.out'
        exe_path = os.path.join(td, exe_name)
        try:
            compile_proc = subprocess.run(
                [compiler, '-std=c++17', filepath, '-o', exe_path],
                capture_output=True,
                text=True,
                timeout=30,
                env=sanitized_env
            )
        except subprocess.TimeoutExpired:
            return False, 'Compilation timed out after 30 seconds.', None, 'execution_error'
        except Exception as e:
            return False, f'Failed to execute compiler ({compiler}): {str(e)}', None, 'execution_error'

        if compile_proc.returncode != 0:
            err_msg = compile_proc.stderr.strip() or compile_proc.stdout.strip() or f'Compiler exited with code {compile_proc.returncode}'
            return False, err_msg, compile_proc.returncode, 'compile_error'

        if not os.path.exists(exe_path):
            return False, f'Compiled executable not found at {exe_path}', None, 'execution_error'

        try:
            run_proc = subprocess.run([exe_path], capture_output=True, text=True, timeout=15, env=sanitized_env)
            output = run_proc.stdout.strip()
            if run_proc.stderr.strip():
                output = output + '\n' + run_proc.stderr.strip() if output else run_proc.stderr.strip()
            return True, output if output else 'Program ran successfully with no output.', run_proc.returncode, 'success'
        except subprocess.TimeoutExpired:
            return True, 'Program compiled successfully (execution timed out after 15 seconds).', None, 'success'
        except Exception as e:
            return True, f'Program compiled successfully (runtime notice: {str(e)}).', None, 'success'


def tokenize(filepath):
    """Tokenize a single .cpp file. Returns list of token dicts."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            code = f.read()
    except Exception as e:
        print(f"ERROR reading file: {e}")
        sys.exit(1)

    code = strip_comments(code)
    tokens = []
    token_index = 0
    line = 1
    line_start = 0

    for mo in MASTER_REGEX.finditer(code):
        kind  = mo.lastgroup
        value = mo.group()
        col   = mo.start() - line_start + 1

        if kind == "NEWLINE":
            line += 1
            line_start = mo.end()
            continue
        if kind == "WHITESPACE":
            continue

        if kind == "IDENTIFIER" and value in CPP_KEYWORDS:
            kind = "KEYWORD"

        tokens.append({
            "file_name":    os.path.basename(filepath),
            "label":        "UNKNOWN",
            "token_index":  token_index,
            "token_type":   kind,
            "token_value":  value,
            "line":         line,
            "column":       col,
        })
        token_index += 1

    return tokens


try:
    from cpp_parser import build_ast
except ImportError:
    try:
        from parser import build_ast
    except ImportError:
        print("ERROR: Could not find cpp_parser.py or parser.py")
        print("Make sure cpp_parser.py is in the same folder as predict.py")
        sys.exit(1)

try:
    from ast_features import extract_features
except ImportError:
    print("ERROR: Could not find ast_features.py")
    print("Make sure ast_features.py is in the same folder as predict.py")
    sys.exit(1)


def generate_performance_analysis(performance_data, output_dir="performance_analysis"):
    """Generate comprehensive performance analysis with graphs."""
    os.makedirs(output_dir, exist_ok=True)

    # Extract data
    error_types = list(performance_data['error_counts'].keys())
    error_counts = list(performance_data['error_counts'].values())
    fix_success_rates = [performance_data['fix_success_rates'].get(et, 0) for et in error_types]
    detection_times = list(performance_data['detection_times'])
    confidence_scores = list(performance_data['confidence_scores'])

    # Set up the plotting style
    plt.style.use('default')
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('C++ Syntax Error Classifier Performance Analysis', fontsize=16, fontweight='bold')

    # 1. Error Type Distribution
    axes[0, 0].bar(error_types, error_counts, color='skyblue', alpha=0.8)
    axes[0, 0].set_title('Error Type Distribution', fontweight='bold')
    axes[0, 0].set_xlabel('Error Types')
    axes[0, 0].set_ylabel('Frequency')
    axes[0, 0].tick_params(axis='x', rotation=45)

    # Add value labels on bars
    for i, v in enumerate(error_counts):
        axes[0, 0].text(i, v + 0.1, str(v), ha='center', va='bottom')

    # 2. Fix Success Rates
    bars = axes[0, 1].bar(error_types, fix_success_rates, color='lightgreen', alpha=0.8)
    axes[0, 1].set_title('Auto-Fix Success Rates', fontweight='bold')
    axes[0, 1].set_xlabel('Error Types')
    axes[0, 1].set_ylabel('Success Rate (%)')
    axes[0, 1].set_ylim(0, 100)
    axes[0, 1].tick_params(axis='x', rotation=45)

    # Color bars based on success rate
    for bar, rate in zip(bars, fix_success_rates):
        if rate >= 80:
            bar.set_color('darkgreen')
        elif rate >= 60:
            bar.set_color('orange')
        else:
            bar.set_color('red')

    # Add percentage labels
    for i, v in enumerate(fix_success_rates):
        axes[0, 1].text(i, v + 1, f'{v:.1f}%', ha='center', va='bottom')

    # 3. Detection Time Distribution
    if detection_times:
        axes[1, 0].hist(detection_times, bins=10, color='lightcoral', alpha=0.8, edgecolor='black')
        axes[1, 0].set_title('Detection Time Distribution', fontweight='bold')
        axes[1, 0].set_xlabel('Time (seconds)')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].axvline(np.mean(detection_times), color='red', linestyle='--', linewidth=2,
                          label=f'Mean: {np.mean(detection_times):.3f}s')
        axes[1, 0].legend()

    # 4. Model Confidence Scores
    if confidence_scores:
        axes[1, 1].boxplot(confidence_scores, patch_artist=True,
                          boxprops=dict(facecolor='lightblue', color='blue'),
                          medianprops=dict(color='red', linewidth=2))
        axes[1, 1].set_title('Model Confidence Score Distribution', fontweight='bold')
        axes[1, 1].set_ylabel('Confidence Score')
        axes[1, 1].set_xticks([1], ['ML Model'])
        axes[1, 1].grid(True, alpha=0.3)

        # Add statistics
        if confidence_scores:
            mean_conf = np.mean(confidence_scores)
            median_conf = np.median(confidence_scores)
            axes[1, 1].text(0.5, 0.95, f'Mean: {mean_conf:.3f}\nMedian: {median_conf:.3f}',
                           transform=axes[1, 1].transAxes, ha='center', va='top',
                           bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    plt.tight_layout()
    performance_plot_path = os.path.join(output_dir, 'performance_analysis.png')
    plt.savefig(performance_plot_path, dpi=300, bbox_inches='tight')
    plt.close()

    # Generate detailed metrics report
    report_path = os.path.join(output_dir, 'performance_report.txt')
    with open(report_path, 'w') as f:
        f.write("=" * 60 + "\n")
        f.write("C++ SYNTAX ERROR CLASSIFIER PERFORMANCE REPORT\n")
        f.write("=" * 60 + "\n\n")

        f.write("EXECUTION SUMMARY:\n")
        f.write("-" * 20 + "\n")
        f.write(f"Total execution time: {performance_data['total_time']:.3f} seconds\n")
        f.write(f"Files processed: {performance_data['files_processed']}\n")
        f.write(f"Errors detected: {sum(error_counts)}\n")
        f.write(f"Auto-fixes applied: {performance_data['fixes_applied']}\n")
        f.write(f"Successful compilations: {performance_data['successful_compilations']}\n\n")

        f.write("ERROR TYPE BREAKDOWN:\n")
        f.write("-" * 20 + "\n")
        for error_type, count in performance_data['error_counts'].items():
            success_rate = performance_data['fix_success_rates'].get(error_type, 0)
            f.write(f"{error_type:25} | Count: {count:3} | Fix Success: {success_rate:5.1f}%\n")

        f.write("\nPERFORMANCE METRICS:\n")
        f.write("-" * 20 + "\n")
        if detection_times:
            f.write(f"Average detection time: {np.mean(detection_times):.3f} seconds\n")
            f.write(f"Min detection time: {min(detection_times):.3f} seconds\n")
            f.write(f"Max detection time: {max(detection_times):.3f} seconds\n")

        if confidence_scores:
            f.write(f"Average confidence score: {np.mean(confidence_scores):.3f}\n")
            f.write(f"Median confidence score: {np.median(confidence_scores):.3f}\n")
            f.write(f"Confidence score range: {min(confidence_scores):.3f} - {max(confidence_scores):.3f}\n")

        overall_success_rate = (performance_data['successful_compilations'] / max(performance_data['files_processed'], 1)) * 100
        f.write(f"\nOverall success rate: {overall_success_rate:.1f}%\n")

    print(f"\n📊 PERFORMANCE ANALYSIS GENERATED:")
    print(f"   📈 Charts saved to: {performance_plot_path}")
    print(f"   📋 Report saved to: {report_path}")

    return performance_plot_path, report_path


def verify_model_checksums(base_dir=None, strict_signature=True):
    """
    Verifies SHA-256 hashes of model.pkl, scaler.pkl, and label_encoder.pkl against model_checksums.json.
    Also cryptographically verifies the HMAC-SHA256 signature on model_checksums.json using the
    trusted verification key kept in the separate trusted key store.
    Exits with error code 1 if checksums or signature do not match, or if an unsigned manifest
    is encountered outside an explicit legacy migration path.
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    checksum_file = os.path.join(base_dir, "model_checksums.json")
    if not os.path.exists(checksum_file):
        print(f"SECURITY ERROR: Model checksum file not found at {checksum_file}.")
        print("Run make_checksums.py to generate valid checksums.")
        sys.exit(1)

    try:
        with open(checksum_file, "r", encoding="utf-8") as f:
            checksums = json.load(f)
    except Exception as e:
        print(f"SECURITY ERROR: Failed to parse {checksum_file}: {e}")
        sys.exit(1)

    artifacts = ["model.pkl", "scaler.pkl", "label_encoder.pkl"]
    for filename in artifacts:
        filepath = os.path.join(base_dir, filename)
        if not os.path.exists(filepath):
            print(f"ERROR: {filename} not found at {filepath}.")
            sys.exit(1)

        expected_hash = checksums.get(filename)
        if not expected_hash:
            print(f"SECURITY ERROR: Missing checksum entry for {filename} in {checksum_file}.")
            sys.exit(1)

        h = hashlib.sha256()
        with open(filepath, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
        actual_hash = h.hexdigest()

        if actual_hash != expected_hash:
            print(f"SECURITY ERROR: SHA-256 checksum mismatch for {filename}!")
            print(f"  Expected: {expected_hash}")
            print(f"  Actual:   {actual_hash}")
            print("Model artifact integrity check failed. Deserialization aborted.")
            sys.exit(1)

    # Cryptographic Manifest Authentication
    from make_checksums import get_trusted_signing_key, verify_manifest_signature

    sig = checksums.get("signature")
    if not sig:
        allow_legacy = os.environ.get("ALLOW_LEGACY_UNSIGNED_MANIFEST", "").strip().lower() in ("1", "true", "yes")
        if allow_legacy or not strict_signature:
            print("[SECURITY WARNING] Unsigned model manifest detected. Permitted under explicit legacy migration policy.")
        else:
            print("SECURITY ERROR: Model manifest lacks cryptographic signature.")
            print("Under production security policy, release manifests must possess an authenticated cryptographic signature.")
            print("Run make_checksums.py to sign the manifest or set ALLOW_LEGACY_UNSIGNED_MANIFEST=1 for legacy migration.")
            sys.exit(1)
    else:
        try:
            key = get_trusted_signing_key(base_dir=base_dir, create_if_missing=False)
        except Exception as e:
            print(f"SECURITY ERROR: Trusted verification key not available: {e}")
            print("Cannot authenticate model manifest. Deserialization aborted.")
            sys.exit(1)

        if not verify_manifest_signature(checksums, key):
            print("SECURITY ERROR: Cryptographic signature mismatch on model manifest!")
            print("Model manifest tampering detected. Deserialization aborted.")
            sys.exit(1)



def predict(filepath, self_heal=False, performance_data=None, allow_execution=False):
    if performance_data is None:
        performance_data = {
            'error_counts': Counter(),
            'fix_success_rates': {},
            'detection_times': [],
            'confidence_scores': [],
            'total_time': 0,
            'files_processed': 0,
            'fixes_applied': 0,
            'successful_compilations': 0
        }

    start_time = time.time()
    performance_data['files_processed'] += 1
    if not os.path.exists(filepath):
        print(f"ERROR: File not found: {filepath}")
        sys.exit(1)

    if not filepath.endswith(".cpp"):
        print(f"WARNING: File does not end with .cpp — proceeding anyway.")

    # Read the original source code for syntax error detection
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            code_lines = f.readlines()
    except Exception as e:
        print(f"ERROR reading source code: {e}")
        sys.exit(1)

    base_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        from model_promoter import resolve_active_artifacts_dir
        artifacts_dir, _ = resolve_active_artifacts_dir(base_dir)
    except Exception:
        artifacts_dir = base_dir

    for f in ["model.pkl", "scaler.pkl", "label_encoder.pkl"]:
        p = os.path.join(artifacts_dir, f)
        if not os.path.exists(p):
            print(f"ERROR: {f} not found at {p}. Run train.py first.")
            sys.exit(1)

    # Verify model artifact integrity before deserializing
    verify_model_checksums(artifacts_dir)

    rf = joblib.load(os.path.join(artifacts_dir, "model.pkl"))
    scaler = joblib.load(os.path.join(artifacts_dir, "scaler.pkl"))
    le = joblib.load(os.path.join(artifacts_dir, "label_encoder.pkl"))

    # Detect syntax errors at source code level
    source_errors = detect_syntax_errors_in_code(code_lines)

    # tokenize
    tokens = tokenize(filepath)
    if not tokens:
        print("ERROR: No tokens found in file. Is it empty?")
        sys.exit(1)

    source_code = "".join(code_lines)
    from structural_validator import validate_cpp_structure, StructuralClassification
    struct_res = validate_cpp_structure(tokens, source_code)

    if struct_res.classification == StructuralClassification.EMPTY:
        safe_print("\n  NO SYNTAX ERRORS DETECTED: Code is empty or whitespace-only.")
        import json as _json
        print(f"ERRORS_JSON:[]")
        perf_json = {
            "error_type": "NONE",
            "error_count": 0,
            "error_types": [],
            "confidence": 100.0,
            "detection_time": float(time.time() - start_time),
            "fix_attempted": False,
            "fix_compiled": False,
            "total_time": float(time.time() - start_time),
        }
        print(f"PERF_JSON:{_json.dumps(perf_json)}")
        return

    if struct_res.classification in (StructuralClassification.UNRECOGNIZED_STRUCTURE, StructuralClassification.AMBIGUOUS_INCOMPLETE):
        conf_val = round(struct_res.confidence * 100, 1)
        err_line = 1
        err_ctx = code_lines[0].strip() if code_lines else ""
        for idx, l in enumerate(code_lines, 1):
            if l.strip():
                err_line = idx
                err_ctx = l.strip()
                break

        desc = (
            "The input is unrecognized or incomplete; it does not form a complete C++ declaration, statement, expression, or program structure."
            if struct_res.is_ambiguous else
            "The input does not match a recognizable C++ declaration, statement, expression, or program structure."
        )

        safe_print("\n  SYNTAX DIAGNOSTICS REPORT:")
        safe_print("  --------------------------")
        safe_print(f"\n  ERROR: INVALID_CPP_STRUCTURE")
        safe_print(f"  Line {err_line}: {err_ctx}")
        safe_print(f"  Description: {desc}")
        safe_print("  Suggested Fix:")
        safe_print("    Provide valid C++ code, such as:")
        safe_print("      1. A complete program: int main() { return 0; }")
        safe_print("      2. A valid function definition: void func() { }")
        safe_print("      3. A valid declaration or statement: int x = 0;")
        safe_print("  Example:\n  hfghfdghdjdf        ← invalid: arbitrary text without C++ structure\n  int x = 10;         ← correct: valid declaration\n  int main() { }      ← correct: valid function")

        import json as _json
        err_obj = {
            "index": 1,
            "type": "INVALID_CPP_STRUCTURE",
            "line": err_line,
            "context": err_ctx,
            "uncertain_location": struct_res.is_ambiguous,
            "confidence": conf_val,
            "description": desc,
            "fix": "Provide valid C++ code, such as:\n  1. A complete program: int main() { return 0; }\n  2. A valid function definition: void func() { }\n  3. A valid declaration or statement: int x = 0;",
            "example": "  hfghfdghdjdf        ← invalid: arbitrary text without C++ structure\n  int x = 10;         ← correct: valid declaration\n  int main() { }      ← correct: valid function"
        }
        print(f"ERRORS_JSON:{_json.dumps([err_obj])}")
        perf_json = {
            "error_type": "INVALID_CPP_STRUCTURE",
            "confidence": conf_val,
            "detection_time": float(time.time() - start_time),
            "fix_attempted": False,
            "fix_compiled": False,
            "total_time": float(time.time() - start_time),
        }
        print(f"PERF_JSON:{_json.dumps(perf_json)}")
        return

    # build AST
    ast_root, parse_errors = build_ast(tokens)

    # If no syntax errors found by rule or parser detectors, verify whether code is clean
    if not parse_errors and not source_errors:
        compiler = find_cxx_compiler()
        if compiler:
            try:
                from compiler_sandbox import run_contained_compiler, CompilerSandboxLimits
                proc = run_contained_compiler(
                    [compiler, '-std=c++17', '-fsyntax-only', filepath],
                    env=get_sanitized_compiler_env(),
                    limits=CompilerSandboxLimits(timeout_seconds=10.0)
                )
                stderr_errs = [l for l in proc.stderr.splitlines() if "error:" in l or "fatal error:" in l]
                syntax_indicator_words = [
                    "expected ';'", "expected '}'", "expected ')'", "expected ']' ",
                    "expected primary-expression", "missing terminating", "syntax error"
                ]
                has_syntax_error_in_compiler = any(
                    any(si in l.lower() for si in syntax_indicator_words)
                    for l in stderr_errs
                )
                code_stripped_lines = [l.strip() for l in code_lines if l.strip()]
                has_unterminated_line = any(
                    l and not l.startswith(("#", "//", "/*", "*"))
                    and not l.endswith((";", "{", "}", ":", ">", "\\"))
                    and not re.match(r"^\s*(for|while|if|else\s+if|else|switch|case|default|class|struct|enum|namespace)\b", l)
                    for l in code_stripped_lines
                )
                is_purely_semantic = bool(stderr_errs) and not has_syntax_error_in_compiler and not has_unterminated_line and all(
                    "was not declared in this scope" in l or
                    "does not name a type" in l or
                    "does not name a template type" in l or
                    "is not a member of" in l or
                    "has no member named" in l or
                    "not a member of" in l or
                    "no member named" in l or
                    "cannot find" in l or
                    "No such file or directory" in l or
                    "Cannot open include file" in l or
                    "undeclared identifier" in l
                    for l in stderr_errs
                )

                if proc.returncode == 0:
                    safe_print("\n  NO SYNTAX ERRORS DETECTED: Code compiled with zero errors.")
                    import json as _json
                    print(f"ERRORS_JSON:[]")
                    perf_json = {
                        "error_type": "NONE",
                        "error_count": 0,
                        "error_types": [],
                        "confidence": 100.0,
                        "detection_time": float(time.time() - start_time),
                        "fix_attempted": False,
                        "fix_compiled": True,
                        "total_time": float(time.time() - start_time),
                    }
                    print(f"PERF_JSON:{_json.dumps(perf_json)}")
                    return
                elif is_purely_semantic and struct_res.classification == StructuralClassification.VALID_PROGRAM_OR_SNIPPET:
                    safe_print("\n  NO SYNTAX ERRORS DETECTED: Code is syntactically valid. Note: Semantic issue(s) detected (unknown identifiers/types).")
                    import json as _json
                    print(f"ERRORS_JSON:[]")
                    perf_json = {
                        "error_type": "NONE",
                        "error_count": 0,
                        "error_types": [],
                        "confidence": 100.0,
                        "detection_time": float(time.time() - start_time),
                        "fix_attempted": False,
                        "fix_compiled": False,
                        "total_time": float(time.time() - start_time),
                    }
                    print(f"PERF_JSON:{_json.dumps(perf_json)}")
                    return
            except Exception:
                pass
        else:
            safe_print("\n  NO SYNTAX ERRORS DETECTED: Code parsed with zero errors.")
            import json as _json
            print(f"ERRORS_JSON:[]")
            perf_json = {
                "error_type": "NONE",
                "error_count": 0,
                "error_types": [],
                "confidence": 100.0,
                "detection_time": float(time.time() - start_time),
                "fix_attempted": False,
                "fix_compiled": False,
                "total_time": float(time.time() - start_time),
            }
            print(f"PERF_JSON:{_json.dumps(perf_json)}")
            return

    # extract features
    feats = extract_features(ast_root, parse_errors)

    # get feature order from training
    feature_cols = [
        "num_function_decls","num_var_decls","num_assign_exprs",
        "num_array_decls","num_if_stmts","num_else_stmts",
        "num_while_stmts","num_for_stmts","num_return_stmts",
        "num_compound_stmts","num_expr_stmts","total_nodes",
        "max_depth","avg_depth","num_leaf_nodes",
        "error_invalid_assignment","error_unmatched_brace",
        "error_unmatched_paren","error_missing_semicolon",
        "error_invalid_conditional","error_invalid_loop",
        "error_invalid_type","error_invalid_array",
        "error_invalid_func_decl","total_error_nodes",
        "scope_depth_max","has_orphan_else","func_missing_return",
        "assign_in_condition","nested_func_decl"
    ]

    X = np.array([[feats.get(col, 0) for col in feature_cols]])
    X_scaled = scaler.transform(X)

    # predict
    detection_start = time.time()
    pred_encoded = rf.predict(X_scaled)[0]
    pred_label   = le.inverse_transform([pred_encoded])[0]
    proba        = rf.predict_proba(X_scaled)[0]
    confidence   = proba[pred_encoded] * 100
    detection_time = time.time() - detection_start

    # Track performance data
    performance_data['detection_times'].append(detection_time)
    performance_data['confidence_scores'].append(confidence)

    # Check if parser errors override prediction (parser is most specific)
    parser_error_type = None
    if parse_errors:
        for error in parse_errors:
            # Extract error type from parse error message
            for etype in [
                "UNTERMINATED_STRING", "MISPLACED_KEYWORD", "INVALID_ASSIGNMENT", "INVALID_CONDITIONAL",
                "INVALID_LOOP", "INVALID_TYPE", "INVALID_ARRAY_DECL",
                "INVALID_FUNCTION_DECL", "INVALID_SWITCH", "INVALID_CLASS_DECL",
                "INVALID_NAMESPACE_DECL", "UNMATCHED_BRACE", "UNMATCHED_PARANTHESES",
                "MISSING_SEMICOLON"
            ]:
                if etype in error:
                    # Validate: if parser inferred UNMATCHED_BRACE or UNMATCHED_PARANTHESES, ensure source code actually has it
                    if etype == "UNMATCHED_BRACE" and "UNMATCHED_BRACE" not in source_errors:
                        continue
                    if etype == "UNMATCHED_PARANTHESES" and "UNMATCHED_PARANTHESES" not in source_errors:
                        continue
                    parser_error_type = etype
                    break
            if parser_error_type:
                break
    
    # Priority 1: Lexical / root errors (such as UNTERMINATED_STRING).
    # These occur at the lexical level and cause cascading parser errors (e.g. MISSING_SEMICOLON, UNMATCHED_BRACE).
    # They must take precedence over cascading parser errors.
    lexical_root_errors = ["UNTERMINATED_STRING"]
    has_lexical_root = None
    for lre in lexical_root_errors:
        if lre in source_errors:
            has_lexical_root = lre
            break

    if has_lexical_root:
        pred_label = has_lexical_root
        confidence = 95.0
    elif parser_error_type:
        pred_label = parser_error_type
        confidence = 95.0
    elif source_errors:
        # Source-level heuristics only used when parser didn't find anything specific
        for error_type, error_info in source_errors.items():
            pred_label = error_type
            confidence = 95.0
            break

    # Track error count
    performance_data['error_counts'][pred_label] += 1

    # get diagnostics
    diag = DIAGNOSTICS.get(pred_label, {
        "description": "Unknown error type detected.",
        "fix": "Review your code carefully for syntax issues.",
        "example": ""
    })

    # print output
    print(f"\n  DIAGNOSTIC:")
    print(f"  {diag['description']}")
    
    # Show error location if found
    if pred_label in source_errors:
        error_info = source_errors[pred_label]
        if error_info['line'] > 0:
            print(f"\n  ERROR LOCATION:")
            print(f"  Line {error_info['line']}: {error_info['context']}")
    elif parse_errors:
        # Show first parser error
        print(f"\n  ERROR LOCATION:")
        print(f"  {parse_errors[0]}")
    
    print(f"\n  SUGGESTED FIX:")
    print(f"  {diag['fix']}")
    if diag.get("example"):
        print(f"\n  EXAMPLE:")
        print(f"{diag['example']}")

    # show parse errors if any
    if parse_errors and pred_label not in source_errors:
        print(f"\n  PARSER DETECTED {len(parse_errors)} ISSUE(S):")
        for e in parse_errors[:5]:
            print(f"    {e}")

    fix_compiled = False
    fix_attempted = self_heal

    if self_heal:
        fixed_lines, changes = apply_autofix(code_lines, pred_label, parse_errors, source_errors)
        if changes:
            performance_data['fixes_applied'] += 1
            print(f"\n  AUTO-FIX CHANGES ({len(changes)}):")
            for change in changes:
                formatted = change.replace('\n', '\n      ')
                print(f"    - {formatted}")
            fixed_path = os.path.splitext(filepath)[0] + ".fixed.cpp"
            with open(fixed_path, "w", encoding="utf-8", errors="ignore") as f:
                f.writelines(fixed_lines)
            print(f"\n  Saved repaired file to: {fixed_path}")
            compiled, output, rc, status = compile_and_run_cpp(fixed_path, allow_execution=allow_execution)
            if compiled:
                fix_compiled = True
                performance_data['successful_compilations'] += 1
                print("\n  AUTO-FIX RESULT: compilation succeeded")
                print("  COMPILE/RUN SUCCESS:")
                print(f"    {output}")
                # Update success rate for this error type
                if pred_label in performance_data['fix_success_rates']:
                    performance_data['fix_success_rates'][pred_label] = (
                        performance_data['fix_success_rates'][pred_label] + 100.0
                    ) / 2  # Simple moving average
                else:
                    performance_data['fix_success_rates'][pred_label] = 100.0
            else:
                if status == 'compiler_not_found':
                    print("\n  AUTO-FIX RESULT: compiler not found")
                    print(f"    {output}")
                elif status == 'compile_error':
                    print("\n  AUTO-FIX RESULT: compilation failed (repaired code still contains errors)")
                    print(f"    {output}")
                elif status == 'execution_error':
                    print("\n  AUTO-FIX RESULT: compiler execution failed (runtime/environment error)")
                    print(f"    {output}")
                else:
                    print("\n  AUTO-FIX RESULT: compilation failed")
                    print(f"    {output}")
                # Update success rate for this error type
                if pred_label in performance_data['fix_success_rates']:
                    performance_data['fix_success_rates'][pred_label] = (
                        performance_data['fix_success_rates'][pred_label] + 0.0
                    ) / 2  # Simple moving average
                else:
                    performance_data['fix_success_rates'][pred_label] = 0.0
        else:
            print("\n  AUTO-FIX: No automatic repair could be applied for this error type.")
    else:
        print("\n  AUTO-FIX: Disabled. Enable 'Attempt auto-fix' (--self-heal) to repair.")

    # Record total execution time
    end_time = time.time()
    performance_data['total_time'] = end_time - start_time

    # Emit structured errors and performance JSON for the server to parse
    import json as _json
    from source_locator import resolve_source_location
    resolved_line, resolved_context, is_loc_uncertain = resolve_source_location(
        source_code="".join(code_lines),
        error_type=pred_label,
        parse_errors=parse_errors,
        source_errors=source_errors,
        tokens=tokens,
        ast_root=ast_root,
        filepath=filepath,
    )
    single_error_json = [{
        "index": 1,
        "type": pred_label,
        "line": resolved_line,
        "context": resolved_context,
        "uncertain_location": is_loc_uncertain,
        "description": diag.get("description", ""),
        "fix": diag.get("fix", ""),
        "example": diag.get("example", "")
    }]
    print(f"ERRORS_JSON:{_json.dumps(single_error_json)}")

    perf_json = {
        "error_type": pred_label,
        "confidence": float(confidence),
        "detection_time": float(detection_time),
        "fix_attempted": fix_attempted,
        "fix_compiled": fix_compiled,
        "total_time": float(performance_data['total_time']),
    }
    print(f"PERF_JSON:{_json.dumps(perf_json)}")

    # Generate performance analysis if this is the main execution
    if performance_data['files_processed'] == 1:
        generate_performance_analysis(performance_data)



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Diagnose C++ syntax errors and optionally auto-fix them.')
    parser.add_argument('filepath', help='Path to the C++ source file')
    parser.add_argument('--self-heal', action='store_true', help='Attempt an automatic repair and compile/run the fixed file')
    parser.add_argument('--analyze-performance', action='store_true', help='Generate performance analysis with graphs after execution')
    parser.add_argument('--multi', action='store_true', help='Detect and report multiple syntax errors in one pass')
    parser.add_argument('--allow-exec', action='store_true', help='UNSAFE: Allow execution of compiled binary outside sandbox (default: False)')
    args = parser.parse_args()

    if args.multi:
        predict_multi(args.filepath, self_heal=args.self_heal, allow_execution=args.allow_exec)
        sys.exit(0)

    performance_data = {
        'error_counts': Counter(),
        'fix_success_rates': {},
        'detection_times': [],
        'confidence_scores': [],
        'total_time': 0,
        'files_processed': 0,
        'fixes_applied': 0,
        'successful_compilations': 0
    }

    predict(args.filepath, self_heal=args.self_heal, performance_data=performance_data, allow_execution=args.allow_exec)

    # Generate performance analysis if requested
    if args.analyze_performance:
        generate_performance_analysis(performance_data)
