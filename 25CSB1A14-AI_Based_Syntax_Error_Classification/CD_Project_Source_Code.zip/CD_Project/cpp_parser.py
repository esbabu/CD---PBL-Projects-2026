import pandas as pd
from dataclasses import dataclass, field
from typing import List, Any, Tuple



@dataclass
class ASTNode:
    node_type : str
    value     : str = "" 
    line      : int = 0
    children  : List[Any] = field(default_factory=list)

    def add(self, child):
        if child:
            self.children.append(child)

    def __repr__(self, indent=0):
        pad = "  " * indent
        s   = f"{pad}[{self.node_type}]"
        if self.value:
            s += f"  '{self.value}'"
        if self.line:
            s += f"  (line {self.line})"
        for c in self.children:
            s += "\n" + c.__repr__(indent + 1)
        return s


class Cursor:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset=0):
        i = self.pos + offset
        return self.tokens[i] if i < len(self.tokens) else None

    def consume(self):
        t = self.tokens[self.pos] if self.pos < len(self.tokens) else None
        self.pos += 1
        return t

    def done(self):
        return self.pos >= len(self.tokens)

    def is_type(self, *types):
        t = self.peek()
        if t is None:
            return False
        if "COLON" in types and ((t["token_type"] == "OPERATOR" and t["token_value"] == ":") or t["token_type"] == "COLON"):
            return True
        return t["token_type"] in types

    def is_value(self, *vals):
        t = self.peek()
        return t is not None and t["token_value"] in vals


# Variable types
TYPE_KW = {"int", "float", "double", "char", "bool", "void",
           "long", "short", "unsigned", "signed", "string", "auto"}


class Parser:
    VALID_TYPE_COMPOUNDS = {
        ("unsigned", "int"),
        ("unsigned", "long"),
        ("unsigned", "short"),
        ("unsigned", "char"),
        ("signed", "int"),
        ("signed", "long"),
        ("signed", "short"),
        ("signed", "char"),
        ("long", "long"),
        ("long", "int"),
        ("long", "double"),
        ("short", "int"),
    }

    def __init__(self, tokens):
        self.cur = Cursor(tokens)
        self.errors = []
        self.error_nodes = []
        self.loop_depth = 0
        self.switch_depth = 0

    def err(self, msg, line=None):
        if line is not None and line > 0:
            loc = f"line {line}"
        else:
            t = self.cur.peek()
            loc = f"line {t['line']}" if t else "EOF"
        self.errors.append(f"[ParseError @ {loc}] {msg}")
        return loc

    def is_type_kw(self, tok):
        return tok and ((tok["token_type"] == "KEYWORD" and tok["token_value"] in TYPE_KW) or
                        (tok["token_type"] == "IDENTIFIER" and tok["token_value"] == "string"))

    def is_func_decl(self, in_stmt=False):
        if self.cur.done():
            return False

        t0 = self.cur.peek(0)
        if not t0:
            return False

        ty0, val0 = t0["token_type"], t0["token_value"]
        if ty0 in ("HASH", "SEMICOLON", "OPEN_BRACE", "CLOSE_BRACE", "CLOSE_PAREN",
                   "OPEN_BRACKET", "CLOSE_BRACKET", "INTEGER", "FLOAT", "STRING", "CHAR"):
            return False
        if ty0 == "KEYWORD" and val0 in (
            "if", "else", "while", "for", "do", "switch", "case", "default",
            "return", "break", "continue", "goto", "try", "catch", "throw",
            "class", "struct", "union", "enum", "namespace", "using", "typedef",
            "public", "private", "protected"
        ):
            return False

        # Scan ahead to find '('
        paren_idx = None
        limit = min(len(self.cur.tokens), self.cur.pos + 30)
        for i in range(self.cur.pos, limit):
            tok = self.cur.tokens[i]
            tt, tv = tok["token_type"], tok["token_value"]
            if tt == "OPEN_PAREN":
                paren_idx = i
                break
            if tt in ("SEMICOLON", "OPEN_BRACE", "CLOSE_BRACE", "HASH"):
                return False
            # Only valid declaration operators are allowed before '(': ::, *, &, <, >, ~
            if tt == "OPERATOR" and tv not in ("::", "*", "&", "<", ">", "~"):
                return False
            if tt == "KEYWORD" and tv in (
                "if", "else", "while", "for", "do", "switch", "case", "default",
                "return", "break", "continue", "goto", "class", "struct", "union",
                "enum", "namespace", "using", "typedef"
            ):
                return False

        if paren_idx is None:
            return False

        # Tokens before '(' must end with an identifier (function name)
        pre_tokens = self.cur.tokens[self.cur.pos : paren_idx]
        if not pre_tokens:
            return False

        last_tok = pre_tokens[-1]
        if last_tok["token_type"] != "IDENTIFIER":
            return False

        # If inside a statement block, functions cannot be declared without a return type
        if in_stmt and len(pre_tokens) < 2 and not self.is_type_kw(pre_tokens[0]):
            return False

        # Scan matching ')' from paren_idx
        depth = 0
        close_paren_idx = None
        for p in range(paren_idx, len(self.cur.tokens)):
            tok = self.cur.tokens[p]
            tt = tok["token_type"]
            if tt == "OPEN_PAREN":
                depth += 1
            elif tt == "CLOSE_PAREN":
                depth -= 1
                if depth == 0:
                    close_paren_idx = p
                    break
            elif tt in ("OPEN_BRACE", "SEMICOLON", "CLOSE_BRACE"):
                break

        # Check what follows ')'
        after_p = (close_paren_idx + 1) if close_paren_idx is not None else paren_idx + 1
        while after_p < len(self.cur.tokens) and self.cur.tokens[after_p]["token_value"] in (
            "const", "noexcept", "override", "final", "volatile", "mutable"
        ):
            after_p += 1

        # Check for constructor member initializer list starting with ':' (e.g. Point_3(...) : x(a), y(b) {})
        if after_p < len(self.cur.tokens) and self.cur.tokens[after_p]["token_value"] == ":" and self.cur.tokens[after_p]["token_type"] == "OPERATOR":
            init_p = after_p + 1
            init_depth = 0
            while init_p < len(self.cur.tokens):
                itok = self.cur.tokens[init_p]
                itt = itok["token_type"]
                if itt in ("OPEN_PAREN", "OPEN_BRACE"):
                    if itt == "OPEN_BRACE" and init_depth == 0:
                        after_p = init_p
                        break
                    init_depth += 1
                elif itt in ("CLOSE_PAREN", "CLOSE_BRACE"):
                    init_depth -= 1
                elif itt in ("SEMICOLON", "HASH") and init_depth == 0:
                    after_p = init_p
                    break
                init_p += 1

        if after_p < len(self.cur.tokens):
            next_tok = self.cur.tokens[after_p]
            if next_tok["token_type"] == "OPEN_BRACE":
                return True
            if next_tok["token_type"] == "SEMICOLON":
                if len(pre_tokens) >= 2 or self.is_type_kw(pre_tokens[0]):
                    return True
                return False
            if len(pre_tokens) >= 2 and (
                self.is_type_kw(pre_tokens[0]) or
                pre_tokens[0]["token_value"] in ("unsigned", "signed", "long", "short", "const", "static", "inline", "void", "auto", "std") or
                pre_tokens[0]["token_type"] == "IDENTIFIER"
            ):
                return True

        return False

    def is_var_decl(self):
        t0, t1 = self.cur.peek(0), self.cur.peek(1)
        if not (t0 and t1):
            return False
        if not self.is_type_kw(t0):
            return False
        if t1["token_type"] in ("IDENTIFIER", "KEYWORD", "OPEN_BRACKET", "SEMICOLON", "INTEGER", "FLOAT", "UNKNOWN"):
            return True
        if t1["token_type"] == "OPERATOR" and t1["token_value"] == "=":
            return True
        return False

    def is_class_decl(self):
        t0, t1 = self.cur.peek(0), self.cur.peek(1)
        if not (t0 and t1):
            return False
        return t0["token_type"] == "KEYWORD" and t0["token_value"] in ("class", "struct") and t1["token_type"] == "IDENTIFIER"

    def is_namespace_decl(self):
        t0, t1, t2 = self.cur.peek(0), self.cur.peek(1), self.cur.peek(2)
        if not (t0 and t1):
            return False
        # Avoid "using namespace" declarations
        if t0["token_type"] == "KEYWORD" and t0["token_value"] == "namespace" and t1["token_type"] == "IDENTIFIER":
            # Check if previous token was "using"
            prev_pos = self.cur.pos - 1
            if prev_pos >= 0 and self.cur.tokens[prev_pos]["token_value"] == "using":
                return False
            return True
        return False

    def parse(self):
        root = ASTNode("ProgramNode", line=1)
        while not self.cur.done():
            if self.cur.is_type("HASH"):
                self.parse_directive()
            elif self.is_func_decl():
                root.add(self.parse_func_decl())
            elif self.is_class_decl():
                root.add(self.parse_class_decl())
            elif self.is_namespace_decl():
                root.add(self.parse_namespace_decl())
            elif self.is_var_decl():
                root.add(self.parse_var_decl())
            elif self.cur.is_value("else"):
                t = self.cur.peek()
                self.err(f"Misplaced 'else' at file scope — MISPLACED_KEYWORD at line {t['line']}", line=t["line"])
                root.add(ASTNode("ErrorNode", value="MISPLACED_KEYWORD", line=t["line"]))
                self.cur.consume()
                if self.cur.is_type("OPEN_BRACE"):
                    root.add(self.parse_compound())
            elif self.cur.is_value("return", "break", "continue"):
                t = self.cur.peek()
                self.err(f"Misplaced '{t['token_value']}' at file scope — MISPLACED_KEYWORD at line {t['line']}", line=t["line"])
                root.add(ASTNode("ErrorNode", value="MISPLACED_KEYWORD", line=t["line"]))
                root.add(self.parse_stmt())
            elif self.cur.is_type("OPEN_BRACE"):
                root.add(self.parse_compound())
            elif self.cur.is_value("if", "while", "for", "switch"):
                root.add(self.parse_stmt())
            elif self.cur.is_type("INTEGER", "STRING", "FLOAT"):
                root.add(self.parse_expr_stmt())
            elif self.cur.is_type("UNKNOWN"):
                t = self.cur.consume()
                self.err(f"Unexpected token '{t['token_value']}' — EXTRA_TOKENS at line {t['line']}", line=t["line"])
                root.add(ASTNode("ErrorNode", value="EXTRA_TOKENS", line=t["line"]))
            else:
                self.cur.consume()
        for en in self.error_nodes:
            if en not in root.children:
                root.add(en)
        return root

    def parse_directive(self):
        hash_tok = self.cur.consume()
        ln = hash_tok["line"]
        if self.cur.done() or self.cur.peek()["line"] != ln:
            return  # Empty '#' directive is valid in C++

        dir_tok = self.cur.peek()
        dir_name = dir_tok.get("token_value", "")
        if dir_name == "include":
            self.cur.consume()  # consume 'include'
            include_tokens = []
            while not self.cur.done() and self.cur.peek()["line"] == ln:
                include_tokens.append(self.cur.consume())

            if not include_tokens:
                self.err("Missing header name in #include directive — INVALID_DECLARATION", line=ln)
                err_node = ASTNode("ErrorNode", value="INVALID_DECLARATION", line=ln)
                self.error_nodes.append(err_node)
                return

            if len(include_tokens) == 1 and include_tokens[0]["token_type"] == "STRING":
                s_val = include_tokens[0]["token_value"]
                if s_val.startswith('"') and s_val.endswith('"') and len(s_val) >= 2:
                    return  # Valid quoted include: #include "myheader.h"
                else:
                    self.err("Unterminated string literal in #include — UNTERMINATED_STRING", line=ln)
                    err_node = ASTNode("ErrorNode", value="UNTERMINATED_STRING", line=ln)
                    self.error_nodes.append(err_node)
                    return

            first_val = include_tokens[0]["token_value"]
            last_val = include_tokens[-1]["token_value"]
            if first_val.startswith("<") and last_val.endswith(">"):
                combined = "".join(t["token_value"] for t in include_tokens)
                if combined == "<>":
                    self.err("Empty header name in #include <> — INVALID_DECLARATION", line=ln)
                    err_node = ASTNode("ErrorNode", value="INVALID_DECLARATION", line=ln)
                    self.error_nodes.append(err_node)
                    return
                # Valid angle bracket include: #include <header>
                return

            if first_val.startswith("<") and not last_val.endswith(">"):
                self.err("Missing closing '>' in #include directive — INVALID_DECLARATION", line=ln)
                err_node = ASTNode("ErrorNode", value="INVALID_DECLARATION", line=ln)
                self.error_nodes.append(err_node)
                return

            if include_tokens[0]["token_type"] == "STRING" and not include_tokens[0]["token_value"].endswith('"'):
                self.err("Unterminated string literal in #include — UNTERMINATED_STRING", line=ln)
                err_node = ASTNode("ErrorNode", value="UNTERMINATED_STRING", line=ln)
                self.error_nodes.append(err_node)
                return

            self.err("Malformed #include directive: expected \"FILENAME\" or <FILENAME> — INVALID_DECLARATION", line=ln)
            err_node = ASTNode("ErrorNode", value="INVALID_DECLARATION", line=ln)
            self.error_nodes.append(err_node)
            return

        # Other standard preprocessor directives (#define, #ifdef, #ifndef, #endif, #pragma, etc.)
        while not self.cur.done() and self.cur.peek()["line"] == ln:
            self.cur.consume()

    def skip_directive(self):
        self.parse_directive()

    def parse_func_decl(self):
        header_tokens = []
        while not self.cur.done() and not self.cur.is_type("OPEN_PAREN"):
            header_tokens.append(self.cur.consume())

        if not header_tokens:
            return None

        name_tok = header_tokens[-1]
        ret_tokens = header_tokens[:-1]

        ret_str = ""
        for idx, t in enumerate(ret_tokens):
            val = t["token_value"]
            if idx > 0 and val != "::" and ret_tokens[idx - 1]["token_value"] != "::" and val not in ("*", "&"):
                ret_str += " "
            ret_str += val

        name_val = name_tok["token_value"]
        val_str = f"{ret_str} {name_val}".strip()
        first_tok = header_tokens[0]
        node = ASTNode("FunctionDeclNode", value=val_str, line=first_tok["line"])

        if self.cur.is_type("OPEN_PAREN"):
            paren_tok = self.cur.consume()
            depth = 1
            param_tokens = []
            while not self.cur.done() and depth > 0:
                if self.cur.is_type("OPEN_BRACE", "CLOSE_BRACE", "SEMICOLON"):
                    break
                if self.cur.is_type("OPEN_PAREN"):
                    depth += 1
                if self.cur.is_type("CLOSE_PAREN"):
                    depth -= 1
                    if depth == 0:
                        self.cur.consume()
                        break
                t = self.cur.consume()
                param_tokens.append(t)
            if depth != 0:
                self.err("Missing ')' in function parameter list — INVALID_FUNCTION_DECL", line=paren_tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_FUNCTION_DECL", line=paren_tok["line"]))
            elif param_tokens:
                last_tok = param_tokens[-1]
                if last_tok["token_type"] == "OPERATOR" and last_tok["token_value"] == ",":
                    self.err(f"Trailing comma in parameter list — INVALID_FUNCTION_DECL at line {last_tok['line']}", line=last_tok["line"])
                    node.add(ASTNode("ErrorNode", value="INVALID_FUNCTION_DECL", line=last_tok["line"]))

        while not self.cur.done() and self.cur.peek()["token_value"] in (
            "const", "noexcept", "override", "final", "volatile"
        ):
            self.cur.consume()

        # Consume constructor member initializer list if present (: x(a), y(b))
        if not self.cur.done() and self.cur.is_type("OPERATOR") and self.cur.peek()["token_value"] == ":":
            self.cur.consume()  # consume ':'
            init_depth = 0
            while not self.cur.done():
                t = self.cur.peek()
                if t["token_type"] == "OPEN_PAREN":
                    init_depth += 1
                elif t["token_type"] == "CLOSE_PAREN":
                    init_depth -= 1
                elif t["token_type"] == "OPEN_BRACE" and init_depth == 0:
                    break
                elif t["token_type"] in ("SEMICOLON", "CLOSE_BRACE") and init_depth == 0:
                    break
                self.cur.consume()

        if self.cur.is_type("OPEN_BRACE"):
            node.add(self.parse_compound())
        elif self.cur.is_type("SEMICOLON"):
            self.cur.consume()
        else:
            line = name_tok["line"] if name_tok else first_tok["line"]
            self.err(f"Missing '{{' after function — INVALID_FUNCTION_DECL at line {line}", line=line)
            node.add(ASTNode("ErrorNode", value="INVALID_FUNCTION_DECL", line=line))
        return node

    def parse_class_decl(self):
        kw_tok = self.cur.consume()  # class or struct
        name_tok = self.cur.consume()  # class name
        node = ASTNode("ClassDeclNode",
                       value=f"{kw_tok['token_value']} {name_tok['token_value']}",
                       line=kw_tok["line"])
        
        # Check for inheritance (optional)
        if self.cur.is_type("COLON"):
            self.cur.consume()
            # Parse inheritance list
            while not self.cur.done() and not self.cur.is_type("OPEN_BRACE", "SEMICOLON"):
                self.cur.consume()
        
        if self.cur.is_type("OPEN_BRACE"):
            body_node = self.parse_class_body()
            node.add(body_node)
            if self.cur.is_type("SEMICOLON"):
                self.cur.consume()
            else:
                close_line = body_node.line if body_node else (name_tok["line"] if name_tok else kw_tok["line"])
                self.err(f"Missing ';' after class/struct definition — MISSING_SEMICOLON at line {close_line}", line=close_line)
                node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=close_line))
        else:
            self.err(f"Missing '{{' after class/struct declaration — INVALID_CLASS_DECL")
            node.add(ASTNode("ErrorNode", value="INVALID_CLASS_DECL", line=kw_tok["line"]))
        return node

    def parse_class_body(self):
        tok = self.cur.consume()
        node = ASTNode("ClassBodyNode", value="{}", line=tok["line"])
        while not self.cur.done() and not self.cur.is_type("CLOSE_BRACE"):
            if self.cur.is_type("HASH"):
                self.parse_directive()
            elif self.cur.is_type("KEYWORD") and self.cur.peek()["token_value"] in ("public", "private", "protected"):
                node.add(self.parse_access_specifier())
            elif self.is_func_decl():
                node.add(self.parse_func_decl())
            elif self.is_var_decl():
                node.add(self.parse_var_decl())
            else:
                self.cur.consume()
        if self.cur.is_type("CLOSE_BRACE"):
            close_tok = self.cur.consume()
            node.line = close_tok["line"]
        else:
            self.err("Missing '}' after class body — UNMATCHED_BRACE")
            node.add(ASTNode("ErrorNode", value="UNMATCHED_BRACE", line=tok["line"]))
        return node

    def parse_access_specifier(self):
        tok = self.cur.consume()
        node = ASTNode("AccessSpecifierNode", value=tok["token_value"], line=tok["line"])
        if self.cur.is_type("COLON"):
            self.cur.consume()
        else:
            self.err("Missing ':' after access specifier — MISSING_SEMICOLON")
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=tok["line"]))
        return node

    def parse_namespace_decl(self):
        kw_tok = self.cur.consume()  # namespace
        name_tok = self.cur.consume()  # namespace name
        node = ASTNode("NamespaceDeclNode",
                       value=f"namespace {name_tok['token_value']}",
                       line=kw_tok["line"])
        
        if self.cur.is_type("OPEN_BRACE"):
            node.add(self.parse_namespace_body())
        else:
            self.err(f"Missing '{{' after namespace declaration — INVALID_NAMESPACE_DECL")
            node.add(ASTNode("ErrorNode", value="INVALID_NAMESPACE_DECL", line=kw_tok["line"]))
        return node

    def parse_namespace_body(self):
        tok = self.cur.consume()
        node = ASTNode("NamespaceBodyNode", value="{}", line=tok["line"])
        while not self.cur.done() and not self.cur.is_type("CLOSE_BRACE"):
            if self.cur.is_type("HASH"):
                self.parse_directive()
            elif self.is_func_decl():
                node.add(self.parse_func_decl())
            elif self.is_class_decl():
                node.add(self.parse_class_decl())
            elif self.is_var_decl():
                node.add(self.parse_var_decl())
            else:
                self.cur.consume()
        if self.cur.is_type("CLOSE_BRACE"):
            self.cur.consume()
        else:
            self.err("Missing '}' after namespace body — UNMATCHED_BRACE")
            node.add(ASTNode("ErrorNode", value="UNMATCHED_BRACE", line=tok["line"]))
        return node

    def parse_compound(self, depth=0):
        tok = self.cur.consume()
        line = tok["line"] if tok else 0
        node = ASTNode("CompoundStmtNode", value="{}", line=line)
        if depth > 500:
            self.err("Nesting depth exceeded maximum limit — INVALID_CPP_STRUCTURE", line=line)
            node.add(ASTNode("ErrorNode", value="INVALID_CPP_STRUCTURE", line=line))
            return node
        while not self.cur.done() and not self.cur.is_type("CLOSE_BRACE"):
            node.add(self.parse_stmt(depth=depth + 1))
        if self.cur.is_type("CLOSE_BRACE"):
            self.cur.consume()
        else:
            self.err("Missing '}' — UNMATCHED_BRACE", line=line)
            node.add(ASTNode("ErrorNode", value="UNMATCHED_BRACE", line=line))
        return node

    def parse_stmt(self, depth=0):
        t = self.cur.peek()
        if not t:
            return None
        ty, val = t["token_type"], t["token_value"]
        if ty == "HASH":
            self.skip_directive()
            return None
        if ty == "KEYWORD" and val == "if":
            return self.parse_if(depth=depth)
        if ty == "KEYWORD" and val == "else":
            return self.parse_else(depth=depth)
        if ty == "KEYWORD" and val == "while":
            return self.parse_while(depth=depth)
        if ty == "KEYWORD" and val == "for":
            return self.parse_for(depth=depth)
        if ty == "KEYWORD" and val == "switch":
            return self.parse_switch()
        if ty == "KEYWORD" and val == "case":
            return self.parse_case()
        if ty == "KEYWORD" and val == "default":
            return self.parse_default()
        if ty == "KEYWORD" and val == "return":
            return self.parse_return()
        if ty == "KEYWORD" and val in ("break", "continue"):
            kw_tok = self.cur.consume()
            if val == "break" and self.loop_depth == 0 and self.switch_depth == 0:
                self.err(f"Break statement not within loop or switch — MISPLACED_KEYWORD at line {kw_tok['line']}", line=kw_tok["line"])
                err_node = ASTNode("ErrorNode", value="MISPLACED_KEYWORD", line=kw_tok["line"])
                stmt_node = ASTNode("ExprStmtNode", line=kw_tok["line"])
                stmt_node.add(err_node)
                if self.cur.is_type("SEMICOLON"):
                    self.cur.consume()
                return stmt_node
            elif val == "continue" and self.loop_depth == 0:
                self.err(f"Continue statement not within loop — MISPLACED_KEYWORD at line {kw_tok['line']}", line=kw_tok["line"])
                err_node = ASTNode("ErrorNode", value="MISPLACED_KEYWORD", line=kw_tok["line"])
                stmt_node = ASTNode("ExprStmtNode", line=kw_tok["line"])
                stmt_node.add(err_node)
                if self.cur.is_type("SEMICOLON"):
                    self.cur.consume()
                return stmt_node
            else:
                stmt_node = ASTNode("ExprStmtNode", line=kw_tok["line"])
                stmt_node.add(ASTNode("ExprNode", value=val, line=kw_tok["line"]))
                if self.cur.is_type("SEMICOLON"):
                    self.cur.consume()
                return stmt_node
        if ty == "OPEN_BRACE":
            return self.parse_compound(depth=depth + 1)
        if ty == "IDENTIFIER" and val in ("whlie", "wile", "whil", "foor", "fro"):
            self.err(f"Invalid loop keyword '{val}' — INVALID_LOOP at line {t['line']}", line=t['line'])
            err_node = ASTNode("ErrorNode", value="INVALID_LOOP", line=t['line'])
            self.cur.consume()
            stmt_node = ASTNode("WhileStmtNode", line=t["line"])
            stmt_node.add(err_node)
            if self.cur.is_type("OPEN_PAREN"):
                stmt_node.add(self.parse_paren_expr())
            if self.cur.is_type("OPEN_BRACE"):
                stmt_node.add(self.parse_compound(depth=depth + 1))
            return stmt_node
        if self.is_func_decl(in_stmt=True):
            return self.parse_func_decl()
        if self.is_var_decl():
            return self.parse_var_decl()
        return self.parse_expr_stmt()

    def parse_if(self, depth=0):
        tok = self.cur.consume()
        node = ASTNode("IfStmtNode", line=tok["line"])
        if self.cur.is_type("OPEN_PAREN"):
            cond = self.parse_paren_expr()
            node.add(cond)
            BINARY_OPS = {">", "<", ">=", "<=", "==", "!=", "&&", "||", "+", "-", "*", "/", "%", "=", "&", "|", "^"}
            if not cond.children:
                self.err(f"Empty condition in if statement — INVALID_CONDITIONAL at line {tok['line']}", line=tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
            elif cond.children[-1].value in BINARY_OPS:
                self.err(f"Incomplete condition in if statement — INVALID_CONDITIONAL at line {tok['line']}", line=tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
        else:
            self.err("Missing '(' after if — INVALID_CONDITIONAL", line=tok["line"])
            node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
            while not self.cur.done() and not self.cur.is_type("OPEN_BRACE", "SEMICOLON", "CLOSE_BRACE"):
                self.cur.consume()
        if self.cur.is_type("OPEN_BRACE"):
            node.add(self.parse_compound(depth=depth + 1))
        elif self.cur.is_type("SEMICOLON"):
            self.cur.consume()
        else:
            node.add(self.parse_stmt(depth=depth + 1))
        return node

    def parse_else(self, depth=0):
        tok = self.cur.consume()
        node = ASTNode("ElseStmtNode", line=tok["line"])
        if self.cur.is_type("OPEN_BRACE"):
            node.add(self.parse_compound(depth=depth + 1))
        elif self.cur.is_value("if"):
            node.add(self.parse_if(depth=depth + 1))
        else:
            node.add(self.parse_stmt(depth=depth + 1))
        return node

    def parse_while(self, depth=0):
        tok = self.cur.consume()
        node = ASTNode("WhileStmtNode", line=tok["line"])
        if self.cur.is_type("OPEN_PAREN"):
            cond = self.parse_paren_expr()
            node.add(cond)
            BINARY_OPS = {">", "<", ">=", "<=", "==", "!=", "&&", "||", "+", "-", "*", "/", "%", "=", "&", "|", "^"}
            if not cond.children:
                self.err(f"Empty condition in while loop — INVALID_LOOP at line {tok['line']}", line=tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=tok["line"]))
            elif cond.children[-1].value in BINARY_OPS:
                self.err(f"Incomplete condition in while loop — INVALID_LOOP at line {tok['line']}", line=tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=tok["line"]))
        else:
            self.err("Missing '(' after while — INVALID_LOOP", line=tok["line"])
            node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=tok["line"]))
            while not self.cur.done() and not self.cur.is_type("OPEN_BRACE", "SEMICOLON", "CLOSE_BRACE"):
                self.cur.consume()
        self.loop_depth += 1
        try:
            if self.cur.is_type("OPEN_BRACE"):
                node.add(self.parse_compound(depth=depth + 1))
            elif self.cur.is_type("SEMICOLON"):
                self.cur.consume()
            else:
                node.add(self.parse_stmt(depth=depth + 1))
        finally:
            self.loop_depth -= 1
        return node

    def parse_for(self, depth=0):
        tok = self.cur.consume()
        node = ASTNode("ForStmtNode", line=tok["line"])
        if self.cur.is_type("OPEN_PAREN"):
            paren_tok = self.cur.peek()
            # Inspect tokens inside for (...) to detect malformed header
            k = 1
            p_depth = 1
            semi_count = 0
            has_colon = False
            while True:
                pk = self.cur.peek(k)
                if not pk:
                    break
                if pk["token_type"] == "OPEN_PAREN":
                    p_depth += 1
                elif pk["token_type"] == "CLOSE_PAREN":
                    p_depth -= 1
                    if p_depth == 0:
                        break
                elif pk["token_type"] in ("OPEN_BRACE", "CLOSE_BRACE"):
                    break
                elif p_depth == 1:
                    if pk["token_type"] == "SEMICOLON":
                        semi_count += 1
                    elif pk["token_type"] == "OPERATOR" and pk["token_value"] == ":":
                        has_colon = True
                k += 1
            if p_depth != 0:
                self.err(f"Malformed for loop header (missing ')') — INVALID_LOOP at line {paren_tok['line']}", line=paren_tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=paren_tok["line"]))
                while not self.cur.done() and not self.cur.is_type("OPEN_BRACE", "CLOSE_BRACE"):
                    self.cur.consume()
            elif not has_colon and semi_count < 2:
                self.err(f"Malformed for loop header (expected 2 semicolons) — INVALID_LOOP at line {paren_tok['line']}", line=paren_tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=paren_tok["line"]))
                node.add(self.parse_paren_expr())
            else:
                node.add(self.parse_paren_expr())
        else:
            self.err("Missing '(' after for — INVALID_LOOP", line=tok["line"])
            node.add(ASTNode("ErrorNode", value="INVALID_LOOP", line=tok["line"]))
            has_brace = False
            k = 0
            while k < 200:
                pk = self.cur.peek(k)
                if not pk or pk["token_type"] == "CLOSE_BRACE":
                    break
                if pk["token_type"] == "OPEN_BRACE":
                    has_brace = True
                    break
                k += 1
            if has_brace:
                while not self.cur.done() and not self.cur.is_type("OPEN_BRACE", "CLOSE_BRACE"):
                    self.cur.consume()
            else:
                semi_count = 0
                while not self.cur.done() and not self.cur.is_type("CLOSE_BRACE"):
                    if self.cur.is_type("SEMICOLON"):
                        semi_count += 1
                        self.cur.consume()
                        if semi_count >= 2:
                            break
                    else:
                        self.cur.consume()
        self.loop_depth += 1
        try:
            if self.cur.is_type("OPEN_BRACE"):
                node.add(self.parse_compound(depth=depth + 1))
            elif self.cur.is_type("SEMICOLON"):
                self.cur.consume()
            else:
                node.add(self.parse_stmt(depth=depth + 1))
        finally:
            self.loop_depth -= 1
        return node

    def parse_switch(self):
        tok = self.cur.consume()
        node = ASTNode("SwitchStmtNode", line=tok["line"])
        if self.cur.is_type("OPEN_PAREN"):
            cond = self.parse_paren_expr()
            node.add(cond)
            BINARY_OPS = {">", "<", ">=", "<=", "==", "!=", "&&", "||", "+", "-", "*", "/", "%", "=", "&", "|", "^"}
            if not cond.children:
                self.err(f"Empty expression in switch statement — INVALID_CONDITIONAL at line {tok['line']}", line=tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
            elif cond.children[-1].value in BINARY_OPS:
                self.err(f"Incomplete expression in switch statement — INVALID_CONDITIONAL at line {tok['line']}", line=tok["line"])
                node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
        else:
            self.err("Missing '(' after switch — INVALID_CONDITIONAL")
            node.add(ASTNode("ErrorNode", value="INVALID_CONDITIONAL", line=tok["line"]))
        self.switch_depth += 1
        try:
            if self.cur.is_type("OPEN_BRACE"):
                node.add(self.parse_switch_body())
            else:
                self.err("Missing '{' after switch condition — INVALID_FUNCTION_DECL")
                node.add(ASTNode("ErrorNode", value="INVALID_FUNCTION_DECL", line=tok["line"]))
        finally:
            self.switch_depth -= 1
        return node

    def parse_switch_body(self):
        tok = self.cur.consume()
        node = ASTNode("SwitchBodyNode", value="{}", line=tok["line"])
        while not self.cur.done() and not self.cur.is_type("CLOSE_BRACE"):
            if self.cur.is_type("KEYWORD") and self.cur.peek()["token_value"] in ("case", "default"):
                if self.cur.peek()["token_value"] == "case":
                    node.add(self.parse_case())
                else:
                    node.add(self.parse_default())
            else:
                node.add(self.parse_stmt())
        if self.cur.is_type("CLOSE_BRACE"):
            self.cur.consume()
        else:
            self.err("Missing '}' after switch — UNMATCHED_BRACE")
            node.add(ASTNode("ErrorNode", value="UNMATCHED_BRACE", line=tok["line"]))
        return node

    def parse_case(self):
        tok = self.cur.consume()
        node = ASTNode("CaseStmtNode", line=tok["line"])
        # Parse case value
        while not self.cur.done() and not self.cur.is_type("COLON", "CLOSE_BRACE"):
            t = self.cur.consume()
            node.add(ASTNode("ExprNode", value=t["token_value"], line=t["line"]))
        if self.cur.is_type("COLON"):
            self.cur.consume()
        else:
            self.err("Missing ':' after case — INVALID_SWITCH")
            node.add(ASTNode("ErrorNode", value="INVALID_SWITCH", line=tok["line"]))
        return node

    def parse_default(self):
        tok = self.cur.consume()
        node = ASTNode("DefaultStmtNode", line=tok["line"])
        if self.cur.is_type("COLON"):
            self.cur.consume()
        else:
            self.err("Missing ':' after default — MISSING_SEMICOLON")
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=tok["line"]))
        return node

    def parse_return(self):
        tok = self.cur.consume()
        node = ASTNode("ReturnStmtNode", line=tok["line"])
        
        # Check for misplaced keywords after return
        if self.cur.is_type("KEYWORD") and self.cur.peek()["token_value"] in ("if", "while", "for", "else", "switch", "case", "default", "break", "continue", "goto"):
            kw_tok = self.cur.peek()
            self.err(f"Misplaced keyword '{kw_tok['token_value']}' after return — MISPLACED_KEYWORD", line=kw_tok["line"])
            node.add(ASTNode("ErrorNode", value="MISPLACED_KEYWORD", line=kw_tok["line"]))
        
        expr_tokens = []
        while not self.cur.done() and not self.cur.is_type("SEMICOLON", "CLOSE_BRACE"):
            t = self.cur.consume()
            node.add(ASTNode("ExprNode", value=t["token_value"], line=t["line"]))
            expr_tokens.append(t)

        # Check for unexpected extra tokens in return statement (e.g. return 0 extra;)
        for i in range(len(expr_tokens) - 1):
            t1 = expr_tokens[i]
            t2 = expr_tokens[i + 1]
            if (t1["token_type"] in ("INTEGER", "FLOAT", "STRING", "CHAR") and t2["token_type"] in ("IDENTIFIER", "INTEGER", "FLOAT", "STRING", "CHAR")) or \
               (t1["token_type"] == "IDENTIFIER" and t2["token_type"] in ("IDENTIFIER", "INTEGER", "FLOAT", "STRING", "CHAR")):
                self.err(f"Unexpected token '{t2['token_value']}' after return expression — EXTRA_TOKENS at line {t2['line']}", line=t2["line"])
                node.add(ASTNode("ErrorNode", value="EXTRA_TOKENS", line=t2["line"]))
                break

        if self.cur.is_type("SEMICOLON"):
            self.cur.consume()
        else:
            self.err(f"Missing ';' after return — MISSING_SEMICOLON at line {tok['line']}", line=tok["line"])
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=tok["line"]))
        return node

    def parse_var_decl(self):
        type_tok = self.cur.consume()
        node = ASTNode("VarDeclNode", value=type_tok["token_value"], line=type_tok["line"])

        # Check for consecutive type keywords (INVALID_TYPE)
        if self.cur.is_type("KEYWORD") and self.cur.peek()["token_value"] in TYPE_KW:
            second_kw = self.cur.peek()["token_value"]
            if (type_tok["token_value"], second_kw) in self.VALID_TYPE_COMPOUNDS:
                extra = self.cur.consume()
                node.value += f" {extra['token_value']}"
            else:
                extra = self.cur.consume()
                node.add(ASTNode("ErrorNode", value="INVALID_TYPE", line=extra["line"]))
                self.err(f"Consecutive type keywords — INVALID_TYPE at line {extra['line']}", line=extra["line"])

        if self.cur.is_type("SEMICOLON"):
            # Missing variable name in declaration (e.g. 'int ;')
            self.err(f"Missing variable name in declaration — INVALID_DECLARATION at line {type_tok['line']}", line=type_tok["line"])
            node.add(ASTNode("ErrorNode", value="INVALID_DECLARATION", line=type_tok["line"]))
            self.cur.consume()
            return node

        if self.cur.is_type("OPERATOR") and self.cur.peek()["token_value"] == "=":
            # Missing variable name before assignment (e.g. 'int = 5;')
            self.err(f"Missing variable name in declaration — INVALID_DECLARATION at line {type_tok['line']}", line=type_tok["line"])
            node.add(ASTNode("ErrorNode", value="INVALID_DECLARATION", line=type_tok["line"]))
            self.cur.consume()
            while not self.cur.done() and not self.cur.is_type("SEMICOLON", "CLOSE_BRACE"):
                self.cur.consume()
            if self.cur.is_type("SEMICOLON"):
                self.cur.consume()
            return node

        name_line = type_tok["line"]
        if self.cur.is_type("IDENTIFIER"):
            name_tok = self.cur.consume()
            name_line = name_tok["line"]
            node.value += f" {name_tok['token_value']}"

            arr_size = None
            if self.cur.is_type("OPEN_BRACKET"):
                arr = ASTNode("ArrayDeclNode", value=name_tok["token_value"], line=name_tok["line"])
                self.cur.consume()
                found_close = False
                while not self.cur.done() and not self.cur.is_type("CLOSE_BRACKET", "SEMICOLON", "CLOSE_BRACE"):
                    tok = self.cur.consume()
                    if tok["token_type"] == "INTEGER":
                        try:
                            arr_size = int(tok["token_value"])
                        except ValueError:
                            pass
                if self.cur.is_type("CLOSE_BRACKET"):
                    self.cur.consume()
                    found_close = True
                if not found_close:
                    self.err(f"Missing ']' — INVALID_ARRAY_DECL at line {name_tok['line']}", line=name_tok["line"])
                    arr.add(ASTNode("ErrorNode", value="INVALID_ARRAY_DECL", line=name_tok["line"]))
                node.add(arr)

            if self.cur.is_type("OPERATOR") and self.cur.peek()["token_value"] == "=":
                op = self.cur.consume()
                asgn = ASTNode("AssignExprNode", value="=", line=op["line"])

                # Check if initializing an arithmetic type with a string literal: int percentage = "Excellent";
                if type_tok["token_value"] in ("int", "float", "double", "short", "long", "bool") and self.cur.is_type("STRING"):
                    str_tok = self.cur.peek()
                    self.err(f"Cannot initialize type '{type_tok['token_value']}' with string literal — INVALID_TYPE at line {str_tok['line']}", line=str_tok["line"])
                    node.add(ASTNode("ErrorNode", value="INVALID_TYPE", line=str_tok["line"]))

                if self.cur.is_type("OPEN_BRACE"):
                    # Array initializer list: {10, 20, 30, 40, 50}
                    ob = self.cur.consume()
                    init_items_count = 0
                    prev_item = False
                    while not self.cur.done() and not self.cur.is_type("CLOSE_BRACE", "SEMICOLON"):
                        t = self.cur.peek()
                        if t["token_type"] == "OPERATOR" and t["token_value"] == ",":
                            self.cur.consume()
                            prev_item = False
                        else:
                            self.cur.consume()
                            if not prev_item:
                                init_items_count += 1
                                prev_item = True
                    if self.cur.is_type("CLOSE_BRACE"):
                        self.cur.consume()
                    if arr_size is not None and init_items_count > arr_size:
                        self.err(f"Too many initializers for array of size {arr_size} ({init_items_count} provided) — INVALID_ARRAY_DECL at line {name_line}", line=name_line)
                        node.add(ASTNode("ErrorNode", value="INVALID_ARRAY_DECL", line=name_line))
                elif self.cur.is_type("SEMICOLON"):
                    self.err(f"Expected expression after '=' — INVALID_ASSIGNMENT at line {op['line']}", line=op["line"])
                    asgn.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=op["line"]))
                else:
                    prev_tok = None
                    while not self.cur.done() and not self.cur.is_type("SEMICOLON", "CLOSE_BRACE"):
                        nxt = self.cur.peek()
                        if nxt and nxt["line"] > name_line:
                            nxt_val = nxt.get("token_value", "")
                            nxt_type = nxt.get("token_type", "")
                            if (nxt_type == "KEYWORD" and nxt_val in (
                                "int", "float", "double", "char", "bool", "void", "long", "short",
                                "unsigned", "signed", "auto", "return", "if", "while", "for",
                                "switch", "case", "default", "break", "continue"
                            )) or (nxt_type == "IDENTIFIER" and self.cur.peek(1) and self.cur.peek(1).get("token_value") in ("=", "(", "++", "--", "+=", "-=")):
                                break
                        # Check for extra tokens in expression: int result = 100 200;
                        if prev_tok and prev_tok["token_type"] in ("INTEGER", "FLOAT", "STRING") and nxt["token_type"] in ("INTEGER", "FLOAT", "STRING"):
                            self.err(f"Unexpected token '{nxt['token_value']}' in expression — EXTRA_TOKENS at line {nxt['line']}", line=nxt["line"])
                            node.add(ASTNode("ErrorNode", value="EXTRA_TOKENS", line=nxt["line"]))
                        r = self.cur.consume()
                        prev_tok = r
                        asgn.add(ASTNode("ExprNode", value=r["token_value"], line=r["line"]))
                    if not asgn.children:
                        self.err(f"Expected expression after '=' — INVALID_ASSIGNMENT at line {op['line']}", line=op["line"])
                        asgn.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=op["line"]))
                node.add(asgn)

        elif self.cur.is_type("INTEGER", "FLOAT", "UNKNOWN"):
            bad_id = self.cur.consume()
            self.err(f"Invalid identifier name in declaration — INVALID_DECLARATION at line {bad_id['line']}", line=bad_id["line"])
            node.add(ASTNode("ErrorNode", value="INVALID_DECLARATION", line=bad_id["line"]))
            while not self.cur.done() and not self.cur.is_type("SEMICOLON", "CLOSE_BRACE"):
                self.cur.consume()
            if self.cur.is_type("SEMICOLON"):
                self.cur.consume()
            return node

        elif self.cur.is_type("STRING"):
            lit = self.cur.consume()
            node.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=lit["line"]))
            self.err(f"Literal as lvalue — INVALID_ASSIGNMENT at line {lit['line']}", line=lit["line"])

        elif self.cur.is_type("KEYWORD"):
            kw_tok = self.cur.consume()
            self.err(f"Keyword '{kw_tok['token_value']}' cannot be used as an identifier — MISPLACED_KEYWORD at line {kw_tok['line']}", line=kw_tok["line"])
            node.add(ASTNode("ErrorNode", value="MISPLACED_KEYWORD", line=kw_tok["line"]))
            while not self.cur.done() and not self.cur.is_type("SEMICOLON", "CLOSE_BRACE"):
                self.cur.consume()
            if self.cur.is_type("SEMICOLON"):
                self.cur.consume()
            return node

        # Handle comma-separated declarations (e.g. float x, y, z;)
        while self.cur.is_type("OPERATOR") and self.cur.peek()["token_value"] == ",":
            self.cur.consume()
            if self.cur.is_type("IDENTIFIER"):
                extra_id = self.cur.consume()
                node.value += f", {extra_id['token_value']}"

        if self.cur.is_type("SEMICOLON"):
            self.cur.consume()
        elif not self.cur.is_type("CLOSE_BRACE"):
            self.err(f"Missing ';' — MISSING_SEMICOLON at line {name_line}", line=name_line)
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=name_line))
        return node

    def parse_expr_stmt(self):
        t = self.cur.peek()
        start_line = t["line"] if t else 0
        node = ASTNode("ExprStmtNode", line=start_line)

        if self.cur.is_type("INTEGER", "STRING"):
            lit = self.cur.consume()
            if self.cur.is_type("OPERATOR") and self.cur.peek()["token_value"] == "=":
                self.cur.consume()
                node.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=lit["line"]))
                self.err(f"Literal lvalue — INVALID_ASSIGNMENT at line {lit['line']}", line=lit["line"])

        while not self.cur.done() and not self.cur.is_type("SEMICOLON", "CLOSE_BRACE", "OPEN_BRACE"):
            nxt = self.cur.peek()
            if nxt and start_line and nxt["line"] > start_line:
                nxt_val = nxt.get("token_value", "")
                nxt_type = nxt.get("token_type", "")
                if (nxt_type == "KEYWORD" and nxt_val in (
                    "int", "float", "double", "char", "bool", "void", "long", "short",
                    "unsigned", "signed", "auto", "return", "if", "while", "for",
                    "switch", "case", "default", "break", "continue"
                )):
                    break
            tok = self.cur.consume()
            node.add(ASTNode("ExprNode", value=tok["token_value"], line=tok["line"]))

        if node.children and node.children[-1].value == "=":
            self.err(f"Missing expression after '=' — INVALID_ASSIGNMENT at line {node.children[-1].line}", line=node.children[-1].line)
            node.add(ASTNode("ErrorNode", value="INVALID_ASSIGNMENT", line=node.children[-1].line))

        if self.cur.is_type("SEMICOLON"):
            self.cur.consume()
        elif node.children:
            last_line = node.children[-1].line if node.children else start_line
            self.err(f"Missing ';' — MISSING_SEMICOLON at line {last_line}", line=last_line)
            node.add(ASTNode("ErrorNode", value="MISSING_SEMICOLON", line=last_line))
        return node

    def parse_paren_expr(self):
        tok = self.cur.consume()
        node = ASTNode("ConditionNode", line=tok["line"])
        depth = 1
        while not self.cur.done() and depth > 0:
            t = self.cur.peek()
            if t["token_type"] in ("OPEN_BRACE", "CLOSE_BRACE"):
                break
            if t["token_type"] == "OPEN_PAREN":
                depth += 1
            if t["token_type"] == "CLOSE_PAREN":
                depth -= 1
                if depth == 0:
                    self.cur.consume()
                    break
            ct = self.cur.consume()
            node.add(ASTNode("ExprNode", value=ct["token_value"], line=ct["line"]))
        if depth != 0:
            self.err("Missing ')' / Unmatched '(' — UNMATCHED_PARANTHESES", line=tok["line"])
            node.add(ASTNode("ErrorNode", value="UNMATCHED_PARANTHESES", line=tok["line"]))
        return node


def build_ast(token_rows):
    """
    token_rows : list of dicts for ONE file from tokens.csv
    returns    : (ASTNode root, list of parse error strings)
    """
    p = Parser(token_rows)
    root = p.parse()
    return root, p.errors


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "tokens.csv"
    df = pd.read_csv(path)

    first = df["file_name"].iloc[0]
    rows = df[df["file_name"] == first].to_dict("records")

    print(f"\n[FILE]   {first}")
    print(f"[TOKENS] {len(rows)}\n")

    ast, errs = build_ast(rows)
    print("── AST ──")
    print(ast)
    if errs:
        print("\n── PARSE ERRORS ──")
        for e in errs:
            print(" ", e)
