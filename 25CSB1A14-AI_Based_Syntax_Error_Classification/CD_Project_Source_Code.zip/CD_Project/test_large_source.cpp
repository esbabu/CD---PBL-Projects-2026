// C++ practice file (500 lines) for syntax-error diagnosis
#include <iostream>
#include <string>
#include <vector>

// ---- block 0 ----
int calc_sum_0(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 2;
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

// ---- block 1 ----
bool is_prime_1(int x) {
    if (x < 2) {
        return false;
    }
    for (int d = 2; d * d <= x; ++d) {
        if (x % d == 0) {
            return false;
        }
    }
    return true;
}

// ---- block 2 ----
std::string label_2(int v) {
    std::string s = "Item ";
    s += std::to_string(v * 8);
    if (v > 8) {
        s += " (large)";
    } else {
        s += " (small)";
    }
    return s;
}

// ---- block 3 ----
struct Point_3 {
    int x;
    int y;
    Point_3(int a, int b) : x(a), y(b) {}
    int sum() const { return x + y; }
};

int use_point_3(int a) {
    Point_3 p(a, a + 7);
    return p.sum();
}

// ---- block 4 ----
int vec_max_4(int n) {
    std::vector<int> v;
    for (int k = 0; k < n; ++k) {
        v.push_back((k * 6) % 17);
    }
    int best = 0;
    for (std::size_t k = 0; k < v.size(); ++k) {
        if (v[k] > best) best = v[k];
    }
    return best;
}

// ---- block 5 ----
int count_down_5(int n) {
    int steps = 0;
    while (n > 0) {
        n -= 5;
        ++steps;
    }
    return steps;
}

// ---- block 6 ----
int calc_sum_6(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 4
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

// ---- block 7 ----
bool is_prime_7(int x) {
    if (x < 2) {
        return false;
    }
    for (int d = 2; d * d <= x; ++d) {
        if (x % d == 0 {
            return false;
        }
    }
    return true;
}

// ---- block 8 ----
std::string label_8(int v) {
    std::string s = "Item ";
    s += std::to_string(v * 2);
    if (v > 2) {
        s += " (large);
    } else {
        s += " (small)";
    }
    return s;
}

// ---- block 9 ----
struct Point_9 {
    int x;
    int y;
    Point_9(int a, int b) : x(a), y(b) {}
    int sum() const { return x + y; }
}

int use_point_9(int a) {
    Point_9 p(a, a + 9);
    return p.sum();
}

// ---- block 10 ----
int vec_max_10(int n) {
    std::vector<int> v;
    for (int k = 0; k < n; ++k) {
        v.push_back((k * 8) % 17);
    }
    int best = 0;
    for (std::size_t k = 0; k < v.size(); ++k) {
        if (v[k] > best) best = v[k];
    }
    return best;
}

// ---- block 11 ----
int count_down_11(int n) {
    int steps = 0;
    whlie (n > 0) {
        n -= 7;
        ++steps;
    }
    return steps;
}

// ---- block 12 ----
int calc_sum_12(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 6;
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

// ---- block 13 ----
bool is_prime_13(int x) {
    if (x < 2) {
        return false;
    }
    for (int d = 2; d * d <= x; ++d) {
        if (x % d == 0) {
            return false;
        }
    }
    return true;
}

// ---- block 14 ----
std::string label_14(int v) {
    std::string s = "Item ";
    s += std::to_string(v * 4);
    if (v > 4) {
        s += " (large)";
    } else {
        s += " (small)";
    }
    return s;
}

// ---- block 15 ----
struct Point_15 {
    int x;
    int y;
    Point_15(int a, int b) : x(a), y(b) {}
    int sum() const { return x + y; }
};

int use_point_15(int a) {
    Point_15 p(a, a + 3);
    return p.sum();
}

// ---- block 16 ----
int vec_max_16(int n) {
    std::vector<int> v;
    for (int k = 0; k < n; ++k) {
        v.push_back((k * 2) % 17);
    }
    int best = 0;
    for (std::size_t k = 0; k < v.size(); ++k) {
        if (v[k] > best) best = v[k];
    }
    return best;
}

// ---- block 17 ----
int count_down_17(int n) {
    int steps = 0;
    while (n > 0) {
        n -= 9;
        ++steps;
    }
    return steps;
}

// ---- block 18 ----
int calc_sum_18(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 8;
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

// ---- block 19 ----
bool is_prime_19(int x) {
    if (x < 2) {
        return false;
    }
    for (int d = 2; d * d <= x; ++d) {
        if (x % d == 0) {
            return false;
        }
    }
    return true;
}

// ---- block 20 ----
std::string label_20(int v) {
    std::string s = "Item ";
    s += std::to_string(v * 6);
    if (v > 6) {
        s += " (large)";
    } else {
        s += " (small)";
    }
    return s;
}

// ---- block 21 ----
struct Point_21 {
    int x;
    int y;
    Point_21(int a, int b) : x(a), y(b) {}
    int sum() const { return x + y; }
};

int use_point_21(int a) {
    Point_21 p(a, a + 5);
    return p.sum();
}

// ---- block 22 ----
int vec_max_22(int n) {
    std::vector<int> v;
    for (int k = 0; k < n; ++k) {
        v.push_back((k * 4) % 17);
    }
    int best = 0;
    for (std::size_t k = 0; k < v.size(); ++k) {
        if (v[k] > best) best = v[k];
    }
    return best;
}

// ---- block 23 ----
int count_down_23(int n) {
    int steps = 0;
    while (n > 0) {
        n -= 3;
        ++steps;
    }
    return steps;
}

// ---- block 24 ----
int calc_sum_24(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 2;
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

// ---- block 25 ----
bool is_prime_25(int x) {
    if (x < 2) {
        return false;
    }
    for (int d = 2; d * d <= x; ++d) {
        if (x % d == 0) {
            return false;
        }
    }
    return true;
}

// ---- block 26 ----
std::string label_26(int v) {
    std::string s = "Item ";
    s += std::to_string(v * 8);
    if (v > 8) {
        s += " (large)";
    } else {
        s += " (small)";
    }
    return s;
}

// ---- block 27 ----
struct Point_27 {
    int x;
    int y;
    Point_27(int a, int b) : x(a), y(b) {}
    int sum() const { return x + y; }
};

int use_point_27(int a) {
    Point_27 p(a, a + 7);
    return p.sum();
}

// ---- block 28 ----
int vec_max_28(int n) {
    std::vector<int> v;
    for (int k = 0; k < n; ++k) {
        v.push_back((k * 6) % 17);
    }
    int best = 0;
    for (std::size_t k = 0; k < v.size(); ++k) {
        if (v[k] > best) best = v[k];
    }
    return best;
}

// ---- block 29 ----
int count_down_29(int n) {
    int steps = 0;
    while (n > 0) {
        n -= 5;
        ++steps;
    }
    return steps;
}

// ---- block 30 ----
int calc_sum_30(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 4;
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

// ---- block 31 ----
bool is_prime_31(int x) {
    if (x < 2) {
        return false;
    }
    for (int d = 2; d * d <= x; ++d) {
        if (x % d == 0) {
            return false;
        }
    }
    return true;
}

// ---- block 32 ----
std::string label_32(int v) {
    std::string s = "Item ";
    s += std::to_string(v * 2);
    if (v > 2) {
        s += " (large)";
    } else {
        s += " (small)";
    }
    return s;
}

// ---- block 33 ----
struct Point_33 {
    int x;
    int y;
    Point_33(int a, int b) : x(a), y(b) {}
    int sum() const { return x + y; }
};

int use_point_33(int a) {
    Point_33 p(a, a + 9);
    return p.sum();
}

// ---- block 34 ----
int vec_max_34(int n) {
    std::vector<int> v;
    for (int k = 0; k < n; ++k) {
        v.push_back((k * 8) % 17);
    }
    int best = 0;
    for (std::size_t k = 0; k < v.size(); ++k) {
        if (v[k] > best) best = v[k];
    }
    return best;
}

// ---- block 35 ----
int count_down_35(int n) {
    int steps = 0;
    while (n > 0) {
        n -= 7;
        ++steps;
    }
    return steps;
}

// ---- block 36 ----
int calc_sum_36(int n) {
    int total = 0;
    for (int k = 1; k <= n; ++k) {
        total += k * 6;
    }
    if (total % 2 == 0) {
        total /= 2;
    }
    return total;
}

int main() {
    long long checksum = 0;
    checksum += calc_sum_0(6);
    checksum += is_prime_1(9) ? 1 : 0;
    checksum += (long long)label_2(8).size();
    checksum += use_point_3(3);
    checksum += vec_max_4(10);
    checksum += count_down_5(25);
    checksum += calc_sum_6(6);
    checksum += is_prime_7(3) ? 1 : 0;
    checksum += (long long)label_8(2).size();
    checksum += use_point_9(3);
    checksum += vec_max_10(10);
    checksum += count_down_11(25);
    checksum += calc_sum_12(6);
    checksum += is_prime_13(5) ? 1 : 0;
    checksum += (long long)label_14(4).size();
    checksum += use_point_15(3);
    checksum += vec_max_16(10);
    checksum += count_down_17(25);
    checksum += calc_sum_18(6);
    checksum += is_prime_19(7) ? 1 : 0;
    checksum += (long long)label_20(6).size();
    checksum += use_point_21(3);
    checksum += vec_max_22(10);
    checksum += count_down_23(25);
    checksum += calc_sum_24(6);
    checksum += is_prime_25(9) ? 1 : 0;
    checksum += (long long)label_26(8).size();
    checksum += use_point_27(3);
    checksum += vec_max_28(10);
    checksum += count_down_29(25);
    checksum += calc_sum_30(6);
    checksum += is_prime_31(3) ? 1 : 0;
    checksum += (long long)label_32(2).size();
    checksum += use_point_33(3);
    checksum += vec_max_34(10);
    checksum += count_down_35(25);
    checksum += calc_sum_36(6);
    std::cout << "Checksum: " << checksum << std::endl;
    return 0;
}
// padding
// padding
// padding
