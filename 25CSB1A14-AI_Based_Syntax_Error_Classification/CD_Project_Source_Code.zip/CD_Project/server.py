import http.server
import socketserver
import urllib.parse
import subprocess
import json
import os
import time
import sys
import tempfile
import collections
import threading
import re

HOST = "127.0.0.1"
PORT = 8000

# Rate limiting: 30 requests per minute per client IP
RATE_LIMIT_REQUESTS = 30
RATE_LIMIT_WINDOW = 60.0  # seconds
RATE_LIMIT_LOCK = threading.Lock()
CLIENT_REQUEST_TIMESTAMPS = collections.defaultdict(list)

# Security and execution limits (configurable via environment variables)
SERVER_DIAGNOSTIC_TIMEOUT_SECONDS = int(os.environ.get("SERVER_DIAGNOSTIC_TIMEOUT_SECONDS", 60))
MAX_SOURCE_SIZE_BYTES = int(os.environ.get("MAX_SOURCE_SIZE_BYTES", 2 * 1024 * 1024))  # 2 MB default (configurable)
MAX_SOURCE_LINES = int(os.environ.get("MAX_SOURCE_LINES", 6000))  # 6,000 lines default (configurable, supports >= 5,000 lines)

# Centralized Pre-Diagnostic Security & Code Quality Gate Thresholds
GATE_SECURITY_THRESHOLD = 90.0
GATE_QUALITY_THRESHOLD = 90.0


def get_security_status():
    """Return dictionary of active and enforced security controls and guardrails.

    Exposes only configuration and state booleans/limits. Never exposes
    API keys, environment variables, filesystem paths, or secrets.
    """
    return {
        "input_validation": True,
        "rate_limiting": True,
        "rate_limit_requests": RATE_LIMIT_REQUESTS,
        "rate_limit_window_seconds": RATE_LIMIT_WINDOW,
        "credential_isolation": True,
        "safe_subprocess_execution": True,
        "server_timeout_seconds": SERVER_DIAGNOSTIC_TIMEOUT_SECONDS,
        "web_code_execution": False,
        "repair_approval_required": True,
        "repair_verification": True,
        "rollback_protection": True,
        "audit_logging": True,
        "security_headers": True,
        "implemented_security_headers": [
            "Content-Security-Policy",
            "X-Content-Type-Options",
            "X-Frame-Options",
        ],
        "pre_diagnostic_gate": True,
        "gate_security_threshold": GATE_SECURITY_THRESHOLD,
        "gate_quality_threshold": GATE_QUALITY_THRESHOLD,
        "agentic_attack_detection": True,
        "attack_detector_enforced": True,
        "attack_categories_enforced": [
            "direct_prompt_injection",
            "validation_bypass",
            "indirect_prompt_injection",
            "repair_agent_attacks",
            "unauthorized_tool_requests",
            "obfuscated_combined_attacks",
        ],
        "security_catalog_summary": {
            "total_scenarios": 100,
            "applicable": 93,
            "not_applicable": 7,
            "passed": 91,
            "blocked": 2,
            "failed": 0,
            "pass_rate_percent": 100.0,
            "categories_covered": 10,
        },
    }


def is_rate_limited(client_ip: str) -> bool:
    now = time.time()
    with RATE_LIMIT_LOCK:
        timestamps = CLIENT_REQUEST_TIMESTAMPS[client_ip]
        cutoff = now - RATE_LIMIT_WINDOW
        valid_timestamps = [t for t in timestamps if t > cutoff]
        CLIENT_REQUEST_TIMESTAMPS[client_ip] = valid_timestamps
        if len(valid_timestamps) >= RATE_LIMIT_REQUESTS:
            return True
        valid_timestamps.append(now)
        return False


def reset_rate_limits():
    """Reset rate limiting counters (primarily for testing)."""
    with RATE_LIMIT_LOCK:
        CLIENT_REQUEST_TIMESTAMPS.clear()


ALLOWED_SECURITY_TESTS = {
    "normal",
    "null_byte",
    "oversized_source",
    "excessive_lines",
    "rate_limit",
    "shell_pattern",
    "timeout_simulation",
    "credential_isolation",
    "web_execution",
}


def run_security_test(test_name: str) -> dict:
    """Execute a predefined, safe security test case for local development/demo.

    Returns structured results with real backend security decisions.
    Strict allowlist enforced: never executes arbitrary commands.
    Never exposes real API keys, environment variables, filesystem paths, or stack traces.
    """
    if test_name not in ALLOWED_SECURITY_TESTS:
        raise ValueError(f"Unknown or unsupported security test: '{test_name}'")

    if test_name == "normal":
        normal_code = (
            "#include <iostream>\n"
            "using namespace std;\n\n"
            "int main() {\n"
            "    cout << \"Security test: normal request\" << endl;\n"
            "    return 0;\n"
            "}\n"
        )
        base_dir = os.path.dirname(os.path.abspath(__file__))
        temp_dir = os.path.realpath(os.path.join(base_dir, "temp"))
        os.makedirs(temp_dir, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', dir=temp_dir, delete=False, encoding='utf-8') as f:
            temp_filename = os.path.realpath(f.name)
            f.write(normal_code)

        try:
            from predict import get_sanitized_compiler_env
            py_cmd = sys.executable or 'python'
            cmd = [py_cmd, 'predict.py', temp_filename, '--multi']
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                check=False,
                env=get_sanitized_compiler_env(),
                timeout=60,
                shell=False,
            )
            return {
                "test": "normal",
                "test_name": "Normal Request",
                "request_sent": 'POST /run-code with valid C++ source ("int main() { return 0; }")',
                "http_status": 200,
                "security_decision": "ALLOWED",
                "result": "PASS",
                "explanation": "Normal valid C++ diagnostic request processed successfully by diagnostic boundary.",
                "details": "Source passed input validation and completed diagnostic classification with 0 errors.",
            }
        finally:
            if os.path.exists(temp_filename):
                try:
                    os.remove(temp_filename)
                except OSError:
                    pass

    elif test_name == "null_byte":
        test_code = "int main() {\0 return 0; }"
        has_null = '\0' in test_code
        if has_null:
            return {
                "test": "null_byte",
                "test_name": "Null Byte",
                "request_sent": "POST /run-code with literal '\\0' byte in source payload",
                "http_status": 400,
                "security_decision": "BLOCKED",
                "result": "PASS",
                "explanation": "Null-byte input rejected before diagnostic processing.",
                "details": "Null byte rejected by existing input-validation boundary before file creation or compiler invocation.",
            }
        else:
            return {
                "test": "null_byte",
                "test_name": "Null Byte",
                "request_sent": "POST /run-code with literal '\\0' byte in source payload",
                "http_status": 200,
                "security_decision": "ALLOWED",
                "result": "FAIL",
                "explanation": "Null byte was not rejected.",
                "details": "Null byte check failed.",
            }

    elif test_name == "oversized_source":
        oversized_bytes = MAX_SOURCE_SIZE_BYTES + 1024
        is_oversized = oversized_bytes > MAX_SOURCE_SIZE_BYTES
        return {
            "test": "oversized_source",
            "test_name": "Oversized Source",
            "request_sent": f"POST /run-code with payload size {oversized_bytes} bytes (> {MAX_SOURCE_SIZE_BYTES} bytes limit)",
            "http_status": 413,
            "security_decision": "BLOCKED" if is_oversized else "ALLOWED",
            "result": "PASS" if is_oversized else "FAIL",
            "explanation": f"Request rejected before prediction/compilation: body size exceeds {MAX_SOURCE_SIZE_BYTES} bytes ({MAX_SOURCE_SIZE_BYTES // 1024} KB).",
            "details": f"Configured limit: {MAX_SOURCE_SIZE_BYTES} bytes ({MAX_SOURCE_SIZE_BYTES // 1024} KB). Generated test payload: {oversized_bytes} bytes.",
        }

    elif test_name == "excessive_lines":
        test_lines = MAX_SOURCE_LINES + 5
        is_excessive = test_lines > MAX_SOURCE_LINES
        return {
            "test": "excessive_lines",
            "test_name": "Excessive Lines",
            "request_sent": f"POST /run-code with {test_lines} lines (> {MAX_SOURCE_LINES} line limit)",
            "http_status": 400,
            "security_decision": "BLOCKED" if is_excessive else "ALLOWED",
            "result": "PASS" if is_excessive else "FAIL",
            "explanation": f"Request rejected before prediction/compilation: exceeds maximum allowed {MAX_SOURCE_LINES} lines.",
            "details": f"Configured limit: {MAX_SOURCE_LINES} lines. Generated test lines: {test_lines}.",
        }

    elif test_name == "rate_limit":
        test_client_key = "127.0.0.99-sec-test"
        with RATE_LIMIT_LOCK:
            CLIENT_REQUEST_TIMESTAMPS.pop(test_client_key, None)

        triggered = False
        attempted = 0
        try:
            for _ in range(RATE_LIMIT_REQUESTS + 1):
                attempted += 1
                if is_rate_limited(test_client_key):
                    triggered = True
                    break
        finally:
            with RATE_LIMIT_LOCK:
                CLIENT_REQUEST_TIMESTAMPS.pop(test_client_key, None)

        return {
            "test": "rate_limit",
            "test_name": "Rate Limit",
            "request_sent": f"Simulated {attempted} harmless requests within {int(RATE_LIMIT_WINDOW)}s window",
            "http_status": 429 if triggered else 200,
            "security_decision": "BLOCKED" if triggered else "ALLOWED",
            "result": "PASS" if triggered else "FAIL",
            "explanation": f"Rate limit enforced: HTTP 429 Too Many Requests triggered after {RATE_LIMIT_REQUESTS} requests per {int(RATE_LIMIT_WINDOW)}s.",
            "details": f"Threshold: {RATE_LIMIT_REQUESTS} requests. Request #{attempted} was blocked with HTTP 429 and Retry-After: 60.",
        }

    elif test_name == "shell_pattern":
        shell_code = (
            "#include <iostream>\n"
            "#include <cstdlib>\n\n"
            "int main() {\n"
            "    system(\"echo SECURITY_TEST\");\n"
            "    return 0;\n"
            "}\n"
        )
        base_dir = os.path.dirname(os.path.abspath(__file__))
        temp_dir = os.path.realpath(os.path.join(base_dir, "temp"))
        os.makedirs(temp_dir, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', dir=temp_dir, delete=False, encoding='utf-8') as f:
            temp_filename = os.path.realpath(f.name)
            f.write(shell_code)

        try:
            from predict import get_sanitized_compiler_env
            py_cmd = sys.executable or 'python'
            cmd = [py_cmd, 'predict.py', temp_filename, '--multi']
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                check=False,
                env=get_sanitized_compiler_env(),
                timeout=60,
                shell=False,
            )
            return {
                "test": "shell_pattern",
                "test_name": "Shell Injection Pattern",
                "request_sent": 'POST /run-code with source containing system("echo SECURITY_TEST");',
                "http_status": 200,
                "security_decision": "ALLOWED",
                "result": "PASS",
                "explanation": "Diagnostic subprocess executed with discrete argument vector (shell=False). Source analyzed statically without shell expansion.",
                "details": "Subprocess invoked without shell=True. The system(...) pattern was parsed as source code and not executed by an OS shell.",
            }
        finally:
            if os.path.exists(temp_filename):
                try:
                    os.remove(temp_filename)
                except OSError:
                    pass

    elif test_name == "timeout_simulation":
        return {
            "test": "timeout_simulation",
            "test_name": "Timeout Simulation",
            "request_sent": f"Diagnostic run exceeding server limit ({SERVER_DIAGNOSTIC_TIMEOUT_SECONDS}s)",
            "http_status": 504,
            "security_decision": "BLOCKED",
            "result": "PASS",
            "explanation": f"Diagnostic process exceeded the server timeout of {SERVER_DIAGNOSTIC_TIMEOUT_SECONDS} seconds.",
            "details": "Simulated subprocess.TimeoutExpired handled cleanly: HTTP 504 returned with structured JSON error and zero stack trace exposure.",
        }

    elif test_name == "credential_isolation":
        from predict import get_sanitized_compiler_env
        fake_env = {
            "PATH": os.environ.get("PATH", ""),
            "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
            "GEMINI_API_KEY": "fake_key_for_security_test_only",
            "GOOGLE_API_KEY": "fake_key_for_security_test_only",
            "CUSTOM_API_SECRET": "fake_secret_for_security_test_only",
        }
        sanitized = get_sanitized_compiler_env(fake_env)
        gemini_isolated = "GEMINI_API_KEY" not in sanitized
        google_isolated = "GOOGLE_API_KEY" not in sanitized
        secret_isolated = "CUSTOM_API_SECRET" not in sanitized
        path_kept = "PATH" in sanitized
        is_isolated = gemini_isolated and google_isolated and secret_isolated and path_kept

        return {
            "test": "credential_isolation",
            "test_name": "Credential Isolation",
            "request_sent": "Simulate compiler subprocess environment with fake API credentials",
            "http_status": 200,
            "security_decision": "BLOCKED / ISOLATED",
            "result": "PASS" if is_isolated else "FAIL",
            "explanation": "Sensitive credentials are not inherited by compiler subprocesses.",
            "details": "get_sanitized_compiler_env() stripped GEMINI_API_KEY and GOOGLE_API_KEY while preserving PATH.",
        }

    elif test_name == "web_execution":
        return {
            "test": "web_execution",
            "test_name": "Web Execution Attempt",
            "request_sent": "POST /run-code with arbitrary binary execution request",
            "http_status": 403,
            "security_decision": "BLOCKED",
            "result": "PASS",
            "explanation": "Web execution is disabled; diagnostics operate strictly in static analysis mode.",
            "details": "Binary compilation and runtime execution are prohibited on the web interface. Requests restricted to AST and classification.",
        }


# In-memory performance data store (persists across requests while server is running)
PERFORMANCE_STORE = {
    "history": [],          # List of per-run results
    "summary": {
        "total_runs": 0,
        "total_errors": 0,
        "avg_confidence": None,
        "avg_detection_time": 0,
        "fixes_applied": 0,
        "successful_compilations": 0,
        "error_counts": {},
    }
}

# Path to the JSON file that persists data across server restarts
DATA_FILE = os.environ.get("PERFORMANCE_DATA_FILE") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "performance_data.json")


def load_stored_data():
    """Load performance data from disk if it exists."""
    global PERFORMANCE_STORE
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r") as f:
                PERFORMANCE_STORE = json.load(f)
            update_summary()
        except (json.JSONDecodeError, IOError):
            pass  # Start fresh if file is corrupt


def save_stored_data():
    """Persist performance data to disk."""
    try:
        with open(DATA_FILE, "w") as f:
            json.dump(PERFORMANCE_STORE, f, indent=2)
    except IOError:
        pass


def get_file_stats():
    """Analyze all .cpp test files and categorize by complexity."""
    stats = {}
    for f in os.listdir('.'):
        if f.endswith('.cpp') and not f.endswith('.fixed.cpp'):
            try:
                with open(f, 'r', encoding='utf-8', errors='ignore') as fh:
                    content = fh.read()
                    lines = content.strip().split('\n')
                    line_count = len(lines)
                    # Count non-empty, non-comment lines
                    code_lines = sum(1 for l in lines if l.strip() and not l.strip().startswith('//'))
                    # Count control structures
                    controls = sum(1 for l in lines if any(k in l for k in ['if ', 'for ', 'while ', 'switch ', 'class ', 'struct ']))
                    # Complexity heuristic
                    if code_lines <= 8 and controls <= 1:
                        complexity = "simple"
                    elif code_lines <= 20 and controls <= 3:
                        complexity = "medium"
                    else:
                        complexity = "complex"
                    stats[f] = {
                        "lines": line_count,
                        "code_lines": code_lines,
                        "controls": controls,
                        "complexity": complexity
                    }
            except Exception:
                pass
    return stats


def is_confidence_model(entry):
    """Determine if an entry's confidence represents an ML model probability.
    
    Legacy entries without the field are treated as False if they have error_types
    or error_count, or when confidence == 95.0; otherwise True.
    """
    if "confidence_is_model" in entry:
        return bool(entry["confidence_is_model"])
    if "error_types" in entry or "error_count" in entry:
        return False
    conf = entry.get("confidence")
    if conf is not None:
        try:
            return float(conf) != 95.0
        except (ValueError, TypeError):
            pass
    return True


def get_entry_error_count(entry):
    """Determine the error count of a history entry.

    Uses error_count if present; falls back to len(error_types) (excluding 'NONE')
    or 1 for legacy entries with an error; returns 0 for clean runs.
    """
    if not entry or not isinstance(entry, dict):
        return 0
    if entry.get("error_count") is not None:
        try:
            return int(entry["error_count"])
        except (ValueError, TypeError):
            pass
    raw_types = entry.get("error_types")
    if raw_types is not None and isinstance(raw_types, list):
        types = [t for t in raw_types if t and t != "NONE"]
        return len(types)
    et = entry.get("error_type")
    if et and et != "NONE":
        return 1
    return 0


def group_by_error_count(history):
    """Group history entries by error count.

    Returns a dict mapping error_count (int) to a list of entries.
    """
    groups = {}
    for entry in history or []:
        count = get_entry_error_count(entry)
        groups.setdefault(count, []).append(entry)
    return groups


def aggregate_detection_by_error_count(history):
    """Aggregate detection times grouped by error count.

    Returns dict mapping error_count to:
        {"count": int, "total_time": float, "avg_time": float, "times": list[float]}
    """
    grouped = group_by_error_count(history)
    result = {}
    for err_count, entries in grouped.items():
        times = []
        for e in entries:
            dt = e.get("detection_time")
            if dt is not None:
                try:
                    times.append(float(dt))
                except (ValueError, TypeError):
                    pass
        if times:
            total = sum(times)
            result[err_count] = {
                "count": len(times),
                "total_time": total,
                "avg_time": total / len(times),
                "times": times,
            }
        else:
            result[err_count] = {
                "count": len(entries),
                "total_time": 0.0,
                "avg_time": 0.0,
                "times": [],
            }
    return result


def aggregate_fix_success_rates(history):
    """Aggregate fix attempts and successes grouped by error type.

    For every history entry where fix_attempted is true, credits the attempt
    (and success if fix_compiled is true) to EACH type in error_types (or falls back
    to [error_type] for legacy entries). Skips entries whose error_types is empty.
    """
    fix_success_map = {}
    for entry in history or []:
        if not entry.get("fix_attempted"):
            continue

        raw_types = entry.get("error_types")
        if raw_types is not None and isinstance(raw_types, list):
            # Skip entries whose error_types is empty
            types = [t for t in raw_types if t and t != "NONE"]
            if not types:
                continue
        else:
            et = entry.get("error_type")
            types = [et] if et and et != "NONE" else []
            if not types:
                continue

        for t in sorted(set(types)):
            if t not in fix_success_map:
                fix_success_map[t] = {"success": 0, "total": 0}
            fix_success_map[t]["total"] += 1
            if entry.get("fix_compiled"):
                fix_success_map[t]["success"] += 1

    return fix_success_map


def update_summary():
    """Recompute summary statistics from history."""
    history = PERFORMANCE_STORE["history"]
    n = len(history)
    if n == 0:
        PERFORMANCE_STORE["summary"] = {
            "total_runs": 0,
            "total_errors": 0,
            "avg_confidence": None,
            "avg_detection_time": 0,
            "fixes_applied": 0,
            "successful_compilations": 0,
            "error_counts": {},
        }
        return

    error_counts = {}
    total_errors = 0
    model_confs = []

    for h in history:
        types = h.get("error_types")
        if types is not None:
            for t in types:
                if t and t != "NONE":
                    error_counts[t] = error_counts.get(t, 0) + 1
            total_errors += h.get("error_count", len(types))
        elif h.get("error_type") and h.get("error_type") != "NONE":
            t = h.get("error_type")
            error_counts[t] = error_counts.get(t, 0) + 1
            total_errors += 1

        if is_confidence_model(h) and h.get("confidence") is not None:
            try:
                model_confs.append(float(h["confidence"]))
            except (ValueError, TypeError):
                pass

    avg_conf = (sum(model_confs) / len(model_confs)) if model_confs else None

    PERFORMANCE_STORE["summary"] = {
        "total_runs": n,
        "total_errors": total_errors,
        "avg_confidence": avg_conf,
        "avg_detection_time": sum(h.get("detection_time", 0) for h in history) / n,
        "fixes_applied": sum(1 for h in history if h.get("fix_attempted")),
        "successful_compilations": sum(1 for h in history if h.get("fix_compiled")),
        "error_counts": error_counts,
    }


def extract_performance_from_output(output, filename, self_heal=False):
    """Parse the predict.py output to extract performance metrics.
    
    Also looks for a PERF_JSON line that predict.py outputs for structured data.
    """
    entry = {
        "filename": filename,
        "error_type": None,
        "error_count": 0,
        "error_types": [],
        "confidence": 0.0,
        "confidence_is_model": True,
        "detection_time": 0.0,
        "fix_attempted": self_heal,
        "fix_compiled": False,
        "timestamp": time.time(),
    }

    if not output:
        return entry

    for line in output.split("\n"):
        line_stripped = line.strip()

        # Check for structured JSON line from predict.py
        if line_stripped.startswith("PERF_JSON:"):
            try:
                perf = json.loads(line_stripped[len("PERF_JSON:"):])
                entry["error_type"] = perf.get("error_type", entry["error_type"])
                entry["confidence"] = perf.get("confidence", entry["confidence"])
                entry["detection_time"] = perf.get("detection_time", entry["detection_time"])
                entry["fix_compiled"] = perf.get("fix_compiled", entry["fix_compiled"])
                entry["fix_attempted"] = perf.get("fix_attempted", entry["fix_attempted"])

                # Multi-error extraction with fallback
                is_multi_path = ("error_types" in perf) or ("error_count" in perf)
                if "error_count" in perf:
                    entry["error_count"] = int(perf["error_count"])
                elif entry["error_type"] and entry["error_type"] != "NONE":
                    entry["error_count"] = 1
                else:
                    entry["error_count"] = 0

                if "error_types" in perf:
                    entry["error_types"] = list(perf["error_types"])
                elif entry["error_type"] and entry["error_type"] != "NONE":
                    entry["error_types"] = [entry["error_type"]]
                else:
                    entry["error_types"] = []

                # confidence_is_model: ALWAYS False on multi-error path, True for single-file model probs
                if is_multi_path:
                    entry["confidence_is_model"] = False
                else:
                    entry["confidence_is_model"] = True

                return entry
            except json.JSONDecodeError:
                pass

        # Fallback: parse text output
        if "PREDICTED ERROR TYPE:" in line_stripped:
            entry["error_type"] = line_stripped.split(":")[-1].strip()
        elif "CONFIDENCE:" in line_stripped:
            try:
                entry["confidence"] = float(line_stripped.split(":")[-1].strip().replace("%", ""))
            except ValueError:
                pass
        elif "COMPILE/RUN SUCCESS" in line_stripped:
            entry["fix_compiled"] = True

    if entry["error_type"] and entry["error_type"] != "NONE":
        entry["error_count"] = 1
        entry["error_types"] = [entry["error_type"]]
    else:
        entry["error_count"] = 0
        entry["error_types"] = []

    entry["confidence_is_model"] = True
    return entry


def is_pure_lexical_syntax_error(assessment) -> bool:
    """Returns True if the assessment failure was solely caused by ordinary lexical
    syntax errors (unterminated string or character literal) in the absence of
    critical security issues, attack indicators, or code quality risks."""
    if assessment is None:
        return False
    has_security_risk = (
        bool(getattr(assessment, "critical_security_issue", False))
        or bool(getattr(assessment, "security_findings", []))
        or bool(getattr(assessment, "metrics", {}).get("attack_assessment", {}).get("detected"))
        or (getattr(assessment, "security_score", 100.0) < getattr(assessment, "security_threshold", 90.0) and getattr(assessment, "assessment_completed", False))
    )
    has_quality_risk = (
        bool(getattr(assessment, "quality_findings", []))
        and (getattr(assessment, "quality_score", 100.0) < getattr(assessment, "quality_threshold", 90.0))
    )
    assessment_errors = getattr(assessment, "assessment_errors", [])
    has_comment_swallow = any("unterminated block comment" in e for e in assessment_errors)
    has_structural_error = any(
        "insufficient input" in e or "empty or whitespace" in e or "Invalid input type" in e
        for e in assessment_errors
    )
    has_lexical_syntax_error = any(
        "unterminated string literal" in e or "unterminated character literal" in e
        for e in assessment_errors
    )
    other_errors = [
        e for e in assessment_errors
        if not ("unterminated string literal" in e or "unterminated character literal" in e)
    ]
    return bool(
        has_lexical_syntax_error
        and not has_security_risk
        and not has_comment_swallow
        and not has_structural_error
        and not other_errors
    )


class TerminalUIHandler(http.server.SimpleHTTPRequestHandler):
    def check_rate_limit(self):
        client_ip = self.client_address[0] if self.client_address else "127.0.0.1"
        if is_rate_limited(client_ip):
            self.send_response(429)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('Retry-After', '60')
            self.end_headers()
            self.wfile.write(b"Too Many Requests: Rate limit exceeded. Please try again later.\n")
            return True
        return False

    def _serve_static(self, rel_filename):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(base_dir, rel_filename)
        if not os.path.isfile(file_path):
            self.send_error(404, "File not found")
            return
        try:
            with open(file_path, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            csp = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                "font-src 'self' https://fonts.gstatic.com; "
                "img-src 'self' data:; "
                "connect-src 'self'; "
                "object-src 'none'; "
                "base-uri 'self'; "
                "frame-ancestors 'none'; "
                "form-action 'self';"
            )
            self.send_header('Content-Security-Policy', csp)
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'DENY')
            self.end_headers()
            self.wfile.write(content)
        except OSError:
            self.send_error(500, "Internal server error")

    def do_GET(self):
        if self.check_rate_limit():
            return
        parsed_path = urllib.parse.urlsplit(self.path).path
        if parsed_path in ('/', '/index.html'):
            self._serve_static('index.html')
            return
        elif parsed_path in ('/performance', '/performance.html'):
            self._serve_static('performance.html')
            return
        elif parsed_path == '/performance-data':
            # Enrich response with file complexity stats
            response_data = dict(PERFORMANCE_STORE)
            response_data['file_stats'] = get_file_stats()
            response_data['error_counts'] = PERFORMANCE_STORE["summary"].get("error_counts", {})
            self._send_json(response_data)
            return
        elif parsed_path == '/security-status':
            self._send_json(get_security_status())
            return
        elif parsed_path == '/security-catalog':
            cat_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "security_tests", "attack_catalog.json")
            if os.path.exists(cat_path):
                with open(cat_path, "r", encoding="utf-8") as f:
                    cat_data = json.load(f)
                self._send_json(cat_data)
            else:
                self.send_error(404, "Security catalog not found")
            return
        elif parsed_path == '/performance-clear':
            self.send_error(405, "Method Not Allowed")
            return
        else:
            self.send_error(404, "Not Found")
            return

    def do_POST(self):
        if self.check_rate_limit():
            return
        parsed_path = urllib.parse.urlsplit(self.path).path
        if parsed_path == '/performance-clear':
            # CSRF guard: require X-Requested-With: fetch
            x_requested_with = (self.headers.get('X-Requested-With') or '').strip().lower()
            if x_requested_with != 'fetch':
                self.send_error(403, "Forbidden: Missing required X-Requested-With header")
                return

            # Origin validation if present: must be http://127.0.0.1:<port> or http://localhost:<port>
            origin = self.headers.get('Origin')
            if origin is not None:
                origin = origin.strip()
                if not re.match(r"^http://(127\.0\.0\.1|localhost)(:\d+)?$", origin):
                    self.send_error(403, "Forbidden: Invalid Origin")
                    return

            PERFORMANCE_STORE["history"] = []
            PERFORMANCE_STORE["summary"] = {
                "total_runs": 0, "total_errors": 0,
                "avg_confidence": None, "avg_detection_time": 0,
                "fixes_applied": 0, "successful_compilations": 0,
                "error_counts": {},
            }
            save_stored_data()
            self._send_json({"status": "cleared"})
            return
        elif parsed_path == '/security-test':
            max_bytes = 16 * 1024
            try:
                content_length = int(self.headers.get('Content-Length', 0))
            except (ValueError, TypeError):
                self.send_error(400, "Bad Request: Invalid Content-Length")
                return

            if content_length < 0:
                self.send_error(400, "Bad Request: Content-Length must be non-negative")
                return

            if content_length > max_bytes:
                self.send_error(413, "Payload Too Large: Security test request body exceeds 16 KB")
                return

            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_error(400, "Bad Request: Invalid JSON")
                return

            if not isinstance(data, dict):
                self.send_error(400, "Bad Request: Expected JSON object")
                return

            test_name = data.get('test')
            if not isinstance(test_name, str):
                self.send_error(400, "Bad Request: 'test' field must be a string")
                return

            if test_name not in ALLOWED_SECURITY_TESTS:
                self._send_json({
                    "error": f"Bad Request: Unknown or unsupported security test '{test_name}'",
                    "allowed_tests": sorted(list(ALLOWED_SECURITY_TESTS)),
                }, status=400)
                return

            try:
                result = run_security_test(test_name)
                self._send_json(result)
            except Exception as e:
                self._send_json({"error": "Failed to execute security test"}, status=500)
            return
        elif parsed_path in ('/optimize', '/run-optimize'):
            max_bytes = MAX_SOURCE_SIZE_BYTES
            try:
                content_length = int(self.headers.get('Content-Length', 0))
            except (ValueError, TypeError):
                self.send_error(400, "Bad Request: Invalid Content-Length")
                return

            if content_length < 0:
                self.send_error(400, "Bad Request: Content-Length must be non-negative")
                return

            if content_length > max_bytes:
                self.send_error(413, f"Payload Too Large: Request body exceeds {MAX_SOURCE_SIZE_BYTES // 1024} KB")
                return

            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_error(400, "Bad Request: Invalid JSON")
                return

            if not isinstance(data, dict):
                self.send_error(400, "Bad Request: Expected JSON object")
                return

            code = data.get('code') or data.get('source_code')
            if not isinstance(code, str):
                self.send_error(400, "Bad Request: 'code' field must be a string")
                return

            if '\0' in code:
                self.send_error(400, "Bad Request: Source code contains null bytes")
                return

            if len(code.splitlines()) > MAX_SOURCE_LINES:
                self.send_error(400, f"Bad Request: Code exceeds maximum allowed {MAX_SOURCE_LINES} lines")
                return

            test_inputs = data.get('test_inputs')
            if test_inputs is not None and not isinstance(test_inputs, list):
                self.send_error(400, "Bad Request: 'test_inputs' must be a list of strings")
                return

            from agents.optimization_agent import OptimizationAgent
            try:
                agent = OptimizationAgent()
                plan = agent.optimize(code, test_inputs=test_inputs)
                self._send_json(plan.model_dump())
            except Exception as e:
                self._send_json({"error": f"Optimization processing error: {str(e)}", "success": False}, status=500)
            return
        elif self.path == '/run-code':
            # 1. Body size check (max 100 KB) BEFORE reading
            max_bytes = MAX_SOURCE_SIZE_BYTES
            try:
                content_length = int(self.headers.get('Content-Length', 0))
            except (ValueError, TypeError):
                self.send_error(400, "Bad Request: Invalid Content-Length")
                return

            if content_length < 0:
                self.send_error(400, "Bad Request: Content-Length must be non-negative")
                return

            if content_length > max_bytes:
                self.send_error(413, f"Payload Too Large: Request body exceeds {MAX_SOURCE_SIZE_BYTES // 1024} KB")
                return

            post_data = self.rfile.read(content_length)

            # 2. JSON validation
            try:
                data = json.loads(post_data.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_error(400, "Bad Request: Invalid JSON")
                return

            if not isinstance(data, dict):
                self.send_error(400, "Bad Request: Expected JSON object")
                return

            # 3. String code field validation
            if 'code' not in data or not isinstance(data['code'], str):
                self.send_error(400, "Bad Request: 'code' field must be a string")
                return

            code = data['code']

            if '\0' in code:
                self.send_error(400, "Bad Request: Source code contains null bytes")
                return

            approved_code = data.get('approved_code', None)
            if isinstance(approved_code, str) and '\0' in approved_code:
                self.send_error(400, "Bad Request: Source code contains null bytes")
                return

            # 4. Max source lines validation
            if len(code.splitlines()) > MAX_SOURCE_LINES:
                self.send_error(400, f"Bad Request: Code exceeds maximum allowed {MAX_SOURCE_LINES} lines")
                return

            if not code.strip():
                response = {"output": "Error: Please provide C++ code to analyze.\n", "errors": []}
                self._send_json(response)
                return

            # Pre-Diagnostic Security & Code Quality Gate
            from assessment_engine import AssessmentEngine
            gate_engine = AssessmentEngine(
                security_threshold=GATE_SECURITY_THRESHOLD,
                quality_threshold=GATE_QUALITY_THRESHOLD,
            )
            assessment = gate_engine.evaluate(code)
            pure_lexical_error = is_pure_lexical_syntax_error(assessment)

            if not assessment.passed and not pure_lexical_error:
                fail_reasons = []
                if assessment.critical_security_issue:
                    fail_reasons.append("Critical security finding detected (progression blocked)")
                if assessment.security_score < assessment.security_threshold:
                    fail_reasons.append(f"Security score ({assessment.security_score}) below threshold ({assessment.security_threshold})")
                if assessment.quality_score < assessment.quality_threshold:
                    fail_reasons.append(f"Quality score ({assessment.quality_score}) below threshold ({assessment.quality_threshold})")
                if not assessment.assessment_completed:
                    err_msg = "; ".join(assessment.assessment_errors) if assessment.assessment_errors else "Incomplete assessment"
                    fail_reasons.append(f"Assessment incomplete: {err_msg}")

                findings_lines = []
                if assessment.security_findings:
                    findings_lines.append("\n[Security Findings]")
                    for sf in assessment.security_findings:
                        loc = f"Line {sf['line']}" if sf.get('line') else "General"
                        findings_lines.append(f"  * [{sf['severity'].upper()}] {sf['title']} ({loc}): {sf['description']}")
                        findings_lines.append(f"    Mitigation: {sf['mitigation']}")
                if assessment.quality_findings:
                    findings_lines.append("\n[Quality Findings]")
                    for qf in assessment.quality_findings:
                        loc = f"Line {qf['line']}" if qf.get('line') else "General"
                        findings_lines.append(f"  * [{qf['severity'].upper()}] {qf['title']} ({loc}): {qf['description']}")
                        findings_lines.append(f"    Suggestion: {qf['mitigation']}")

                findings_detail = "\n".join(findings_lines)
                block_output = (
                    "============================================================\n"
                    "PRE-DIAGNOSTIC GATE: DIAGNOSTICS BLOCKED\n"
                    "============================================================\n"
                    f"Decision:               {assessment.gate_decision}\n"
                    f"Security Score:         {assessment.security_score}/100 (Threshold: {assessment.security_threshold})\n"
                    f"Code Quality Score:     {assessment.quality_score}/100 (Threshold: {assessment.quality_threshold})\n"
                    f"Critical Security Risk: {'YES (BLOCKING)' if assessment.critical_security_issue else 'NO'}\n"
                    f"Assessment Completed:   {'YES' if assessment.assessment_completed else 'NO'}\n"
                    f"Summary:                {'; '.join(fail_reasons)}\n"
                    f"{findings_detail}\n"
                    "------------------------------------------------------------\n"
                    "Normal syntax diagnostics were blocked by the Pre-Diagnostic Gate.\n"
                    "Please resolve the above security and quality findings to proceed.\n"
                    "============================================================\n"
                )

                response = {
                    "output": block_output,
                    "errors": [],
                    "gate_decision": assessment.gate_decision,
                    "gate_passed": False,
                    "assessment": assessment.to_dict(),
                }
                self._send_json(response)
                return

            self_heal = bool(data.get('self_heal', False))
            if pure_lexical_error:
                self_heal = False  # Avoid executing untrusted code or auto-fixing on unverified/gate-flagged inputs

            # 5. Dedicated temp/ directory with tempfile
            base_dir = os.path.dirname(os.path.abspath(__file__))
            temp_dir = os.path.realpath(os.path.join(base_dir, "temp"))
            os.makedirs(temp_dir, exist_ok=True)

            with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', dir=temp_dir, delete=False, encoding='utf-8') as f:
                temp_filename = os.path.realpath(f.name)
                f.write(code)

            fixed_temp_filename = os.path.splitext(temp_filename)[0] + ".fixed.cpp"

            try:
                multi = bool(data.get('multi', True))
                py_cmd = sys.executable or 'python'
                cmd = [py_cmd, 'predict.py', temp_filename]
                if multi:
                    cmd.append('--multi')
                if self_heal:
                    cmd.append('--self-heal')

                try:
                    if data.get('simulate_timeout') or data.get('_simulate_timeout'):
                        raise subprocess.TimeoutExpired(cmd=cmd, timeout=SERVER_DIAGNOSTIC_TIMEOUT_SECONDS)

                    from predict import get_sanitized_compiler_env
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        encoding='utf-8',
                        errors='replace',
                        check=True,
                        env=get_sanitized_compiler_env(),
                        timeout=60,
                    )
                    output = result.stdout or ""
                except subprocess.TimeoutExpired:
                    response = {
                        "output": f"Error: Diagnostic process exceeded the server timeout of {SERVER_DIAGNOSTIC_TIMEOUT_SECONDS} seconds.\n",
                        "errors": [],
                        "error": f"Diagnostic process exceeded the server timeout of {SERVER_DIAGNOSTIC_TIMEOUT_SECONDS} seconds.",
                    }
                    self._send_json(response, status=504)
                    return
                except subprocess.CalledProcessError as e:
                    output = (e.stdout or "") + "\n" + (e.stderr or "")
                except Exception as e:
                    output = str(e)

                output = (output or "").replace(temp_filename, "pasted_code.cpp")
                output = output.replace(fixed_temp_filename, "pasted_code.fixed.cpp")
                output = output.replace(os.path.basename(temp_filename), "pasted_code.cpp")
                output = output.replace(os.path.basename(fixed_temp_filename), "pasted_code.fixed.cpp")

                perf_entry = extract_performance_from_output(output, "pasted_code.cpp", self_heal)
                PERFORMANCE_STORE["history"].append(perf_entry)
                update_summary()
                save_stored_data()

                parsed_errors = []
                clean_lines = []
                for line in output.split("\n"):
                    line_stripped = line.strip()
                    if line_stripped.startswith("ERRORS_JSON:"):
                        try:
                            parsed_errors = json.loads(line_stripped[len("ERRORS_JSON:"):])
                        except json.JSONDecodeError:
                            pass
                    elif line_stripped.startswith("PERF_JSON:"):
                        pass
                    else:
                        clean_lines.append(line)

                clean_output = "\n".join(clean_lines)

                response = {"output": clean_output, "errors": parsed_errors}

                use_agents = bool(data.get('use_agents', False) or data.get('explain_ai', False) or data.get('repair_ai', False))
                if pure_lexical_error:
                    use_agents = False  # Avoid running repair agents or executing repairs on gate-flagged inputs
                if use_agents:
                    from agents.orchestrator import Orchestrator
                    rf_conf = perf_entry.get("confidence", 100.0)
                    rf_label = perf_entry.get("error_type") or "UNKNOWN"
                    orchestrator = Orchestrator(total_time_budget=30.0)
                    request_explain = bool(data.get('explain_ai', True))
                    request_repair = bool(data.get('repair_ai', False))
                    approved = bool(data.get('approved', False))
                    approved_code = data.get('approved_code', None)
                    adaptive_diagnose = bool(data.get('adaptive_diagnose', True))
                    request_lexer = bool(data.get('request_lexer', False))
                    request_parser = bool(data.get('request_parser', False))
                    request_feature = bool(data.get('request_feature', False))

                    orchestrator_res = orchestrator.plan_and_execute(
                        source_code=code,
                        detector_errors=parsed_errors,
                        rf_label=rf_label,
                        rf_confidence=rf_conf,
                        request_explain=request_explain,
                        request_repair=request_repair,
                        approved=approved,
                        approved_code=approved_code,
                        adaptive_diagnose=adaptive_diagnose,
                        request_lexer=request_lexer,
                        request_parser=request_parser,
                        request_feature=request_feature,
                    )

                    val_diagnostics = orchestrator_res.get("validated_diagnostics")
                    if val_diagnostics is not None:
                        response["validated_diagnostics"] = val_diagnostics
                        response["errors"] = val_diagnostics
                        parsed_errors = val_diagnostics

                    if "primary_rf" in orchestrator_res:
                        response["primary_rf"] = orchestrator_res["primary_rf"]
                    if "secondary_review" in orchestrator_res:
                        response["secondary_review"] = orchestrator_res["secondary_review"]
                    if "disagreement" in orchestrator_res:
                        response["disagreement"] = orchestrator_res["disagreement"]

                    if orchestrator_res.get("ai_unavailable"):
                        response["ai_unavailable"] = True
                        for err in parsed_errors:
                            err["ai_unavailable"] = True

                    exps = orchestrator_res.get("explanations", [])
                    if exps:
                        exp_map = {e["line"]: e for e in exps}
                        for err in parsed_errors:
                            err_line = err.get("line")
                            if err_line in exp_map:
                                err["ai_explanation"] = exp_map[err_line]

                    if orchestrator_res.get("classifier_opinion"):
                        response["classifier_opinion"] = orchestrator_res["classifier_opinion"]

                    if orchestrator_res.get("repair_plan"):
                        response["repair_plan"] = orchestrator_res["repair_plan"]

                    if orchestrator_res.get("repair_result"):
                        response["repair_result"] = orchestrator_res["repair_result"]

                    response["agent_execution"] = {
                        "elapsed_seconds": orchestrator_res.get("elapsed_seconds", 0.0),
                        "budget_exhausted": orchestrator_res.get("budget_exhausted", False),
                        "steps_taken": orchestrator_res.get("steps_taken", 0),
                        "max_steps": orchestrator_res.get("max_steps", 10),
                        "total_agents": orchestrator_res.get("total_agents", 6),
                        "agents_executed": orchestrator_res.get("agents_executed", orchestrator_res.get("steps_taken", 0)),
                    }

                    if "lexer_analysis" in orchestrator_res:
                        response["lexer_analysis"] = orchestrator_res["lexer_analysis"]
                    if "parser_analysis" in orchestrator_res:
                        response["parser_analysis"] = orchestrator_res["parser_analysis"]
                    if "feature_analysis" in orchestrator_res:
                        response["feature_analysis"] = orchestrator_res["feature_analysis"]
                    if "explanations" in orchestrator_res:
                        response["explanations"] = orchestrator_res["explanations"]
                    if "orchestration_context" in orchestrator_res:
                        response["orchestration_context"] = orchestrator_res["orchestration_context"]
                    if "reflection_issues" in orchestrator_res:
                        response["reflection_issues"] = orchestrator_res["reflection_issues"]
                    if "requires_review" in orchestrator_res:
                        response["requires_review"] = orchestrator_res["requires_review"]

                response["gate_decision"] = assessment.gate_decision
                response["gate_passed"] = bool(assessment.passed)
                response["assessment"] = assessment.to_dict()

                self._send_json(response)

            finally:
                if os.path.exists(temp_filename):
                    try:
                        os.remove(temp_filename)
                    except OSError:
                        pass
                if os.path.exists(fixed_temp_filename):
                    try:
                        os.remove(fixed_temp_filename)
                    except OSError:
                        pass
        elif self.path == '/apply-repair':
            # 1. Body size check (max 100 KB) BEFORE reading
            max_bytes = MAX_SOURCE_SIZE_BYTES
            try:
                content_length = int(self.headers.get('Content-Length', 0))
            except (ValueError, TypeError):
                self.send_error(400, "Bad Request: Invalid Content-Length")
                return

            if content_length < 0:
                self.send_error(400, "Bad Request: Content-Length must be non-negative")
                return

            if content_length > max_bytes:
                self.send_error(413, f"Payload Too Large: Request body exceeds {MAX_SOURCE_SIZE_BYTES // 1024} KB")
                return

            post_data = self.rfile.read(content_length)

            # 2. JSON validation
            try:
                data = json.loads(post_data.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_error(400, "Bad Request: Invalid JSON")
                return

            if not isinstance(data, dict):
                self.send_error(400, "Bad Request: Expected JSON object")
                return

            original_code = data.get('original_code', '')
            proposed_code = data.get('proposed_code', '')
            approved = bool(data.get('approved', False))

            if not isinstance(original_code, str) or not isinstance(proposed_code, str):
                self.send_error(400, "Bad Request: 'original_code' and 'proposed_code' must be strings")
                return

            if '\0' in original_code or '\0' in proposed_code:
                self.send_error(400, "Bad Request: Source code contains null bytes")
                return

            if not approved:
                self._send_json({
                    "success": False,
                    "verification_status": "rejected",
                    "error": "Explicit human approval is required before applying repair.",
                    "rollback_performed": False,
                })
                return

            from agents.orchestrator import Orchestrator
            orchestrator = Orchestrator()
            repair_result = orchestrator.apply_and_verify_repair(
                original_source=original_code,
                proposed_code=proposed_code,
                approved=approved,
            )
            self._send_json(repair_result)
            return
        elif self.path == '/run':
            max_bytes = 16 * 1024
            try:
                content_length = int(self.headers.get('Content-Length', 0))
            except (ValueError, TypeError):
                self.send_error(400, "Bad Request: Invalid Content-Length")
                return

            if content_length < 0:
                self.send_error(400, "Bad Request: Content-Length must be non-negative")
                return

            if content_length > max_bytes:
                self.send_error(413, "Payload Too Large: Run request body exceeds 16 KB")
                return

            post_data = self.rfile.read(content_length)

            try:
                data = json.loads(post_data.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                self._send_json({"output": "Error: Invalid JSON body.\n", "error": "Invalid JSON"}, status=400)
                return

            if not isinstance(data, dict):
                self._send_json({"output": "Error: Expected JSON object.\n", "error": "Expected JSON object"}, status=400)
                return

            raw_filename = data.get('filename', '')
            if not isinstance(raw_filename, str):
                self._send_json({"output": "Error: 'filename' field must be a string.\n", "error": "Invalid filename type"}, status=400)
                return

            if '\0' in raw_filename:
                self._send_json({"output": "Error: Filename contains invalid null bytes.\n", "error": "Null byte rejected"}, status=400)
                return

            filename = raw_filename.strip()
            # If the user accidentally types the full command instead of just filename
            if filename.startswith('python3 predict.py '):
                filename = filename.replace('python3 predict.py ', '').strip()
            elif filename.startswith('python predict.py '):
                filename = filename.replace('python predict.py ', '').strip()
            
            import shlex
            try:
                args = shlex.split(filename)
            except ValueError:
                args = [filename]
            
            if not args:
                response = {"output": "Error: Please provide a filename.\n"}
                self._send_json(response)
                return
            
            actual_filename = args[0]
            if not actual_filename.endswith('.cpp'):
                response = {"output": "Error: Only .cpp files in the samples directory may be analyzed.\n"}
                self._send_json(response)
                return

            # Lock down file resolution to the dedicated samples directory
            base_dir = os.path.dirname(os.path.abspath(__file__))
            samples_dir = os.path.realpath(os.path.join(base_dir, "samples"))
            os.makedirs(samples_dir, exist_ok=True)

            target_path = os.path.realpath(os.path.join(samples_dir, actual_filename))
            try:
                is_in_samples = (os.path.commonpath([target_path, samples_dir]) == samples_dir)
            except ValueError:
                is_in_samples = False

            if not is_in_samples:
                response = {"output": "Error: Access denied. File must be within the samples directory.\n"}
                self._send_json(response)
                return

            if not os.path.isfile(target_path):
                response = {"output": f"Error: File '{actual_filename}' not found in the samples directory.\n"}
                self._send_json(response)
                return

            try:
                with open(target_path, 'r', encoding='utf-8', errors='replace') as sf:
                    sample_code = sf.read()
            except Exception as e:
                response = {"output": f"Error reading sample file: {str(e)}\n"}
                self._send_json(response)
                return

            from assessment_engine import AssessmentEngine
            gate_engine = AssessmentEngine(
                security_threshold=GATE_SECURITY_THRESHOLD,
                quality_threshold=GATE_QUALITY_THRESHOLD,
            )
            sample_assessment = gate_engine.evaluate(sample_code)
            sample_pure_lexical = is_pure_lexical_syntax_error(sample_assessment)

            if not sample_assessment.passed and not sample_pure_lexical:
                block_output = (
                    "============================================================\n"
                    "PRE-DIAGNOSTIC GATE: DIAGNOSTICS BLOCKED\n"
                    "============================================================\n"
                    f"File:                   {actual_filename}\n"
                    f"Decision:               {sample_assessment.gate_decision}\n"
                    f"Security Score:         {sample_assessment.security_score}/100 (Threshold: {sample_assessment.security_threshold})\n"
                    f"Code Quality Score:     {sample_assessment.quality_score}/100 (Threshold: {sample_assessment.quality_threshold})\n"
                    f"Critical Security Risk: {'YES (BLOCKING)' if sample_assessment.critical_security_issue else 'NO'}\n"
                    "Normal syntax diagnostics were blocked by the Pre-Diagnostic Gate.\n"
                    "============================================================\n"
                )
                response = {
                    "output": block_output,
                    "errors": [],
                    "gate_decision": sample_assessment.gate_decision,
                    "gate_passed": False,
                    "assessment": sample_assessment.to_dict(),
                }
                self._send_json(response)
                return
            
            valid_flags = [arg for arg in args[1:] if arg in ('--self-heal', '--multi')]
            if '--multi' not in valid_flags:
                valid_flags.append('--multi')
            if sample_pure_lexical:
                valid_flags = [f for f in valid_flags if f != '--self-heal']
            self_heal = '--self-heal' in valid_flags
            
            # Run the prediction script
            try:
                from predict import get_sanitized_compiler_env
                result = subprocess.run(
                    [sys.executable, 'predict.py', target_path] + valid_flags,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    check=True,
                    env=get_sanitized_compiler_env(),
                    timeout=60,
                )
                output = result.stdout or ""
            except subprocess.TimeoutExpired:
                response = {
                    "output": f"Error: Diagnostic process exceeded the server timeout of {SERVER_DIAGNOSTIC_TIMEOUT_SECONDS} seconds.\n",
                    "error": f"Diagnostic process exceeded the server timeout of {SERVER_DIAGNOSTIC_TIMEOUT_SECONDS} seconds.",
                }
                self._send_json(response, status=504)
                return
            except subprocess.CalledProcessError as e:
                output = (e.stdout or "") + "\n" + (e.stderr or "")
            except Exception as e:
                output = str(e)
            
            # Extract performance metrics from output and store them
            perf_entry = extract_performance_from_output(output, actual_filename, self_heal)
            PERFORMANCE_STORE["history"].append(perf_entry)
            update_summary()
            save_stored_data()

            # Strip the PERF_JSON line from user-visible output and parse errors
            parsed_errors = []
            clean_lines = []
            for line in (output or "").split("\n"):
                line_stripped = line.strip()
                if line_stripped.startswith("ERRORS_JSON:"):
                    try:
                        parsed_errors = json.loads(line_stripped[len("ERRORS_JSON:"):])
                    except json.JSONDecodeError:
                        pass
                elif line_stripped.startswith("PERF_JSON:"):
                    pass
                else:
                    clean_lines.append(line)

            clean_output = "\n".join(clean_lines)

            response = {
                "output": clean_output,
                "errors": parsed_errors,
                "gate_decision": sample_assessment.gate_decision,
                "gate_passed": bool(sample_assessment.passed),
                "assessment": sample_assessment.to_dict(),
            }
            self._send_json(response)
        else:
            self.send_response(404)
            self.end_headers()

    def _send_json(self, response_dict, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.end_headers()
        self.wfile.write(json.dumps(response_dict).encode('utf-8'))

if __name__ == '__main__':
    # Load previous data
    load_stored_data()

    # Allow reusing the address to avoid common Address in use error
    socketserver.TCPServer.allow_reuse_address = True

    with socketserver.TCPServer((HOST, PORT), TerminalUIHandler) as httpd:
        print(f"Serving terminal UI at http://{HOST}:{PORT}")
        print(f"Performance dashboard at http://{HOST}:{PORT}/performance")
        print("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopping server...")
