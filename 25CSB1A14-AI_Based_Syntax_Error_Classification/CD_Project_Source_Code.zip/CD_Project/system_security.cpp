#include <cstdlib>

int main() {
    system("echo SECURITY_TEST");
    return 0;
}