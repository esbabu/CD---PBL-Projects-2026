import sys
import os
import re
import csv
import tempfile
import joblib
import pandas as pd
import numpy as np



DIAGNOSTICS = {

    "MISSING_SEMICOLON": {
        "description": "A semicolon ';' is missing at the end of a statement or declaration.",
        "fix": (
            "Check the end of every statement inside your function.\n"
            "  Every variable declaration and expression must end with ';'"
        ),
        "example": (
            "  int x = 5      ← missing semicolon\n"
            "  int x = 5;     ← correct"
        ),
    },

    "UNMATCHED_BRACE": {
        "description": "A curly brace '{' or '}' is missing or mismatched.",
        "fix": (
            "Count your opening '{' and closing '}' braces.\n"
            "  Every function body, if/else block, loop, and class must have\n"
            "  a matching pair of curly braces."
        ),
        "example": (
            "  void foo() {        ← opening brace\n"
            "      int x = 5;      \n"
            "                      ← missing closing brace }\n"
            "  void foo() {        ← correct\n"
            "      int x = 5;\n"
            "  }"
        ),
    },

    "UNMATCHED_PARANTHESES": {
        "description": "A parenthesis '(' or ')' is missing or mismatched.",
        "fix": (
            "Check all your function calls, if/while/for conditions.\n"
            "  Every opening '(' must have a matching closing ')'"
        ),
        "example": (
            "  if (x > 5 {        ← missing closing parenthesis\n"
            "  if (x > 5) {       ← correct"
        ),
    },

    "INVALID_ASSIGNMENT": {
        "description": "An invalid assignment expression was detected. A literal or constant is being used as the left-hand side of an assignment.",
        "fix": (
            "The left side of '=' must always be a variable, not a literal.\n"
            "  Check that you haven't swapped the variable and value."
        ),
        "example": (
            "  5 = x;      ← invalid: literal on left side\n"
            "  x = 5;      ← correct"
        ),
    },

    "INVALID_DECLARATION": {
        "description": "An invalid variable declaration was detected. The variable may have an incorrect type, missing name, or invalid syntax.",
        "fix": (
            "A variable declaration must follow the pattern:\n"
            "  <type> <name>;\n"
            "  or <type> <name> = <value>;\n"
            "  Check for missing variable names or invalid type keywords."
        ),
        "example": (
            "  int ;         ← invalid: missing variable name\n"
            "  int x;        ← correct\n"
            "  int int x;    ← invalid: duplicate type keyword\n"
            "  int x = 5;    ← correct"
        ),
    },

    "INVALID_CONDITIONAL": {
        "description": "An invalid conditional statement was detected. The 'if' statement is missing its condition in parentheses.",
        "fix": (
            "An if statement must always have a condition inside parentheses:\n"
            "  if (<condition>) { ... }\n"
            "  Make sure the opening '(' comes right after 'if'."
        ),
        "example": (
            "  if x > 5 {         ← invalid: missing parentheses\n"
            "  if (x > 5) {       ← correct"
        ),
    },

    "INVALID_LOOP": {
        "description": "An invalid loop was detected. A 'for' or 'while' loop is missing its condition in parentheses.",
        "fix": (
            "A loop must always have its condition inside parentheses:\n"
            "  for (<init>; <cond>; <update>) { ... }\n"
            "  while (<condition>) { ... }\n"
            "  Make sure '(' comes right after 'for' or 'while'."
        ),
        "example": (
            "  for int i=0; i<5; i++ {    ← invalid: missing parentheses\n"
            "  for (int i=0; i<5; i++) {  ← correct"
        ),
    },

    "INVALID_TYPE": {
        "description": "An invalid type declaration was detected. Two type keywords appear consecutively, or an unknown type is used.",
        "fix": (
            "A variable declaration can only have ONE type keyword.\n"
            "  Remove the duplicate type, or check for a typo in the type name."
        ),
        "example": (
            "  int float x;    ← invalid: two types\n"
            "  float x;        ← correct"
        ),
    },

    "INVALID_ARRAY_DECL": {
        "description": "An invalid array declaration was detected. The array brackets '[]' are missing the closing ']'.",
        "fix": (
            "An array declaration must have properly closed brackets:\n"
            "  <type> <name>[<size>];\n"
            "  Make sure every '[' has a matching ']'."
        ),
        "example": (
            "  int arr[5;      ← invalid: missing closing bracket\n"
            "  int arr[5];     ← correct"
        ),
    },

    "INVALID_FUNCTION_DECL": {
        "description": "An invalid function declaration was detected. The function body opening brace '{' is missing, or the function has no return statement.",
        "fix": (
            "A function declaration must have:\n"
            "  1. A return type\n"
            "  2. A function name\n"
            "  3. Parentheses () for parameters\n"
            "  4. A body enclosed in { }\n"
            "  5. A return statement if the return type is not void"
        ),
        "example": (
            "  int foo()           ← invalid: missing body { }\n"
            "  int foo() { }       ← valid structure\n"
            "  int foo() {         ← correct\n"
            "      return 0;\n"
            "  }"
        ),
    },

    "EXTRA_TOKENS": {
        "description": "Extra or unexpected tokens were detected in the code. There may be stray characters, duplicate keywords, or misplaced symbols.",
        "fix": (
            "Look for extra symbols, repeated keywords, or characters that\n"
            "  don't belong. Common causes:\n"
            "  - Duplicate semicolons (;;)\n"
            "  - Extra closing braces or brackets\n"
            "  - Stray operators or symbols"
        ),
        "example": (
            "  int x = 5;; extra    ← invalid: extra token after semicolon\n"
            "  int x = 5;           ← correct"
        ),
    },

    "MISPLACED_KEYWORD": {
        "description": "A keyword is used in the wrong place. An 'else' without a preceding 'if' is a common cause.",
        "fix": (
            "Check that every 'else' has a matching 'if' before it.\n"
            "  Keywords like 'return', 'break', 'continue' must be\n"
            "  inside the correct block scope."
        ),
        "example": (
            "  else {              ← invalid: else without if\n"
            "  if (x > 0) {\n"
            "      ...\n"
            "  } else {            ← correct\n"
            "      ...\n"
            "  }"
        ),
    },

    "UNTERMINATED_STRING": {
        "description": "An unterminated string literal was detected. A string is opened with '\"' but never closed.",
        "fix": (
            "Every string literal must start and end with a double quote '\"'.\n"
            "  Check that you haven't accidentally left a string unclosed."
        ),
        "example": (
            '  cout << "hello;      ← invalid: string never closed\n'
            '  cout << "hello";     ← correct'
        ),
    },
}



CPP_KEYWORDS = {
    "int","float","double","char","bool","void","long","short",
    "unsigned","signed","const","static","extern","register","volatile",
    "if","else","while","for","do","switch","case","default",
    "break","continue","return","goto",
    "class","struct","union","enum","typedef","namespace","using",
    "public","private","protected","virtual","override","final",
    "new","delete","this","nullptr","NULL","true","false",
    "include","define","ifdef","ifndef","endif","pragma",
    "template","typename","operator","sizeof","typeof",
    "try","catch","throw","auto","inline","explicit","friend","mutable",
}

TOKEN_SPEC = [
    ("HASH",          r"#"),
    ("STRING",        r'"(?:[^"\\]|\\.)*"?'),
    ("CHAR",          r"'(?:[^'\\]|\\.)*'?"),
    ("FLOAT",         r"\b\d+\.\d*([eE][+-]?\d+)?\b|\b\d*\.\d+([eE][+-]?\d+)?\b"),
    ("INTEGER",       r"\b\d+\b"),
    ("IDENTIFIER",    r"\b[a-zA-Z_][a-zA-Z0-9_]*\b"),
    ("SEMICOLON",     r";"),
    ("OPEN_PAREN",    r"\("),
    ("CLOSE_PAREN",   r"\)"),
    ("OPEN_BRACE",    r"\{"),
    ("CLOSE_BRACE",   r"\}"),
    ("OPEN_BRACKET",  r"\["),
    ("CLOSE_BRACKET", r"\]"),
    ("OPERATOR",      r"[+\-*/%=<>!&|^~?:.,]+"),
    ("NEWLINE",       r"\n"),
    ("WHITESPACE",    r"[ \t\r]+"),
    ("UNKNOWN",       r"."),
]

import re as _re
MASTER_REGEX = _re.compile(
    "|".join(f"(?P<{name}>{pattern})" for name, pattern in TOKEN_SPEC)
)

def strip_comments(code):
    code = re.sub(r"//[^\n]*", "", code)
    code = re.sub(r"/\*.*?\*/", "", code, flags=re.DOTALL)
    return code

def tokenize(filepath):
    """Tokenize a single .cpp file. Returns list of token dicts."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            code = f.read()
    except Exception as e:
        print(f"ERROR reading file: {e}")
        sys.exit(1)

    code = strip_comments(code)
    tokens = []
    token_index = 0
    line = 1
    line_start = 0

    for mo in MASTER_REGEX.finditer(code):
        kind  = mo.lastgroup
        value = mo.group()
        col   = mo.start() - line_start + 1

        if kind == "NEWLINE":
            line += 1
            line_start = mo.end()
            continue
        if kind == "WHITESPACE":
            continue

        if kind == "IDENTIFIER" and value in CPP_KEYWORDS:
            kind = "KEYWORD"

        tokens.append({
            "file_name":    os.path.basename(filepath),
            "label":        "UNKNOWN",
            "token_index":  token_index,
            "token_type":   kind,
            "token_value":  value,
            "line":         line,
            "column":       col,
        })
        token_index += 1

    return tokens


try:
    from cpp_parser import build_ast
except ImportError:
    try:
        from parser import build_ast
    except ImportError:
        print("ERROR: Could not find cpp_parser.py or parser.py")
        print("Make sure cpp_parser.py is in the same folder as predict.py")
        sys.exit(1)

try:
    from ast_features import extract_features
except ImportError:
    print("ERROR: Could not find ast_features.py")
    print("Make sure ast_features.py is in the same folder as predict.py")
    sys.exit(1)




def predict(filepath):


    if not os.path.exists(filepath):
        print(f"ERROR: File not found: {filepath}")
        sys.exit(1)

    if not filepath.endswith(".cpp"):
        print(f"WARNING: File does not end with .cpp — proceeding anyway.")


    for f in ["model.pkl", "scaler.pkl", "label_encoder.pkl"]:
        if not os.path.exists(f):
            print(f"ERROR: {f} not found. Run train.py first.")
            sys.exit(1)


    rf = joblib.load("model.pkl")
    scaler = joblib.load("scaler.pkl")
    le = joblib.load("label_encoder.pkl")

    #tokenize
    tokens = tokenize(filepath)
    if not tokens:
        print("ERROR: No tokens found in file. Is it empty?")
        sys.exit(1)

    #build AST
    ast_root, parse_errors = build_ast(tokens)

    #extract features
    feats = extract_features(ast_root, parse_errors)

    #get feature order from training
    feature_cols = [
        "num_function_decls","num_var_decls","num_assign_exprs",
        "num_array_decls","num_if_stmts","num_else_stmts",
        "num_while_stmts","num_for_stmts","num_return_stmts",
        "num_compound_stmts","num_expr_stmts","total_nodes",
        "max_depth","avg_depth","num_leaf_nodes",
        "error_invalid_assignment","error_unmatched_brace",
        "error_unmatched_paren","error_missing_semicolon",
        "error_invalid_conditional","error_invalid_loop",
        "error_invalid_type","error_invalid_array",
        "error_invalid_func_decl","total_error_nodes",
        "scope_depth_max","has_orphan_else","func_missing_return",
        "assign_in_condition","nested_func_decl"
    ]

    X = np.array([[feats.get(col, 0) for col in feature_cols]])
    X_scaled = scaler.transform(X)

    #predict
    pred_encoded = rf.predict(X_scaled)[0]
    pred_label   = le.inverse_transform([pred_encoded])[0]
    proba        = rf.predict_proba(X_scaled)[0]
    confidence   = proba[pred_encoded] * 100

    #get diagnostics
    diag = DIAGNOSTICS.get(pred_label, {
        "description": "Unknown error type detected.",
        "fix": "Review your code carefully for syntax issues.",
        "example": ""
    })

    # ── print output
    #border = "═" * 60
    #print(f"\n{border}")
    #print(f"  C++ SYNTAX ERROR CLASSIFIER")
    #print(f"{border}")
    #print(f"  File       : {os.path.basename(filepath)}")
    #print(f"  Confidence : {confidence:.1f}%")
    #print(f"{border}")
    print(f"\n  DIAGNOSTIC:")
    print(f"  {diag['description']}")
    print(f"\n  SUGGESTED FIX:")
    print(f"  {diag['fix']}")
    if diag.get("example"):
        print(f"\n  EXAMPLE:")
        print(f"{diag['example']}")
    #print(f"\n{border}")

    # ── also show top 3 predictions
    #top3_idx = np.argsort(proba)[::-1][:3]
    #print(f"\n  TOP 3 PREDICTIONS:")
    #for idx in top3_idx:
    #    label = le.inverse_transform([idx])[0]
    #    prob  = proba[idx] * 100
    #    bar   = "█" * int(prob / 5)
    #    print(f"  {label:<30} {prob:5.1f}%  {bar}")
    #print(f"{border}\n")

    # ── show parse errors if any
    if parse_errors:
        print(f"  PARSER DETECTED {len(parse_errors)} ISSUE(S):")
        for e in parse_errors[:5]:
            print(f"    {e}")
        #print(f"{border}\n")




if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 predict.py <your_file.cpp>")
        print("Example: python3 predict.py broken.cpp")
        sys.exit(1)

    predict(sys.argv[1])