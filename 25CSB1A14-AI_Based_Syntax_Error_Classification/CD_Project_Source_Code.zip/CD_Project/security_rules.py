"""
security_rules.py — Comprehensive C++ Static Security Rule Registry & Detection Engine.

Provides deterministic, fast (<500ms for 1000 LOC), static-only security analysis
for C++ source code without compilation or runtime execution.
Covers Memory Safety, Injection, Cryptography, Authentication, Files & Processes,
Concurrency, Network Security, Information Disclosure, and Logic / Undefined Behavior.
"""

from dataclasses import dataclass, field
import re
from typing import List, Dict, Any, Tuple, Optional, Callable, Set

from assessment_engine import Finding, CppLexicalMasker, ZERO_WIDTH_CHARS_PATTERN
from engine.cpp_tokenizer import extract_function_scopes_from_tokens, CppToken
from engine.sink_detector import detect_declarative_sinks
from engine.layer_b_analyzer import detect_scope_and_guard_analysis
from engine.taint_tracker import detect_taint_dataflow_analysis
from engine.cfg_analyzer import detect_cfg_resource_lifecycles
from engine.concurrency_analyzer import detect_concurrency_analysis


@dataclass
class SecurityRule:
    rule_id: str
    title: str
    cwe_id: str
    severity: str  # "critical", "high", "medium", "low", "info"
    category: str
    description: str
    mitigation: str
    confidence: str = "High"  # "High", "Medium", "Low"
    aliases: Tuple[str, ...] = ()

    def matches_cwe(self, target_cwe: str) -> bool:
        """Checks if this rule matches a target CWE identifier or any of its documented aliases."""
        target = target_cwe.upper().strip()
        if self.cwe_id.upper().strip() == target:
            return True
        for a in self.aliases:
            if a.upper().strip() == target:
                return True
        return False


@dataclass
class FunctionScope:
    name: str
    return_type: str
    params_str: str
    start_line: int
    end_line: int
    body_raw: str
    body_masked: str
    full_raw: str
    full_masked: str
    params: List[Tuple[str, str]] = field(default_factory=list)
    tokens: List[Any] = field(default_factory=list)


class AnalysisContext:
    """Pre-processed lexical and syntactic inspection context for static security rules."""

    def __init__(self, raw_source: str, masker: Optional[CppLexicalMasker] = None):
        self.raw_source = raw_source
        self.masker = masker or CppLexicalMasker(raw_source)
        self.masked_source = self.masker.masked_source
        self.lines_raw = raw_source.splitlines()
        self.lines_masked = self.masked_source.splitlines()
        self.comments = self.masker.comments
        self.string_literals = self.masker.string_literals
        self.tokens: List[CppToken] = getattr(self.masker, "tokens", [])
        if not self.tokens and raw_source:
            try:
                from engine.cpp_tokenizer import tokenize_cpp
                self.tokens = tokenize_cpp(raw_source)
            except Exception:
                self.tokens = []
        self.functions: List[FunctionScope] = self._extract_function_scopes()

    def get_raw_line(self, line_num: int) -> str:
        if 1 <= line_num <= len(self.lines_raw):
            return self.lines_raw[line_num - 1].strip()
        return ""

    def get_masked_line(self, line_num: int) -> str:
        if 1 <= line_num <= len(self.lines_masked):
            return self.lines_masked[line_num - 1]
        return ""

    def _extract_function_scopes(self) -> List[FunctionScope]:
        if self.tokens:
            tok_scopes = extract_function_scopes_from_tokens(
                self.tokens, self.raw_source, self.masked_source
            )
            scopes: List[FunctionScope] = []
            for s in tok_scopes:
                scopes.append(FunctionScope(
                    name=s.name,
                    return_type=s.return_type,
                    params_str=s.params_str,
                    start_line=s.start_line,
                    end_line=s.end_line,
                    body_raw=s.body_raw,
                    body_masked=s.body_masked,
                    full_raw=s.full_raw,
                    full_masked=s.full_masked,
                    params=s.params,
                    tokens=s.tokens,
                ))
            return scopes

        func_sig_re = re.compile(
            r'(?:^|[\r\n;{}])\s*'
            r'((?:(?:inline|static|virtual|explicit|constexpr|friend|const|unsigned|signed|struct|class)\s+)*'
            r'[a-zA-Z_][\w:<>,*&\[\]\s]*?\s*[*&]?\s*)'
            r'([a-zA-Z_]\w*)\s*'
            r'\(([^)]*)\)\s*'
            r'(?:const\s*)?'
            r'(?:noexcept(?:\([^)]*\))?\s*)?'
            r'\{',
            re.MULTILINE
        )
        scopes: List[FunctionScope] = []
        n = len(self.masked_source)

        for m in func_sig_re.finditer(self.masked_source):
            ret_type = m.group(1).strip()
            name = m.group(2).strip()
            params_str = m.group(3).strip()
            brace_pos = m.end() - 1  # position of '{'

            # Parse parameter names
            parsed_params: List[Tuple[str, str]] = []
            if params_str:
                for chunk in params_str.split(','):
                    chunk = chunk.strip()
                    if not chunk:
                        continue
                    pm = re.search(r'([a-zA-Z_]\w*)\s*(?:=\s*[^,]+)?$', chunk)
                    if pm:
                        pname = pm.group(1)
                        ptype = chunk[:pm.start()].strip()
                        parsed_params.append((ptype, pname))
                    else:
                        parsed_params.append((chunk, ""))

            depth = 1
            i = brace_pos + 1
            while i < n and depth > 0:
                ch = self.masked_source[i]
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                i += 1

            close_brace_pos = i - 1
            body_masked = self.masked_source[brace_pos + 1 : close_brace_pos]
            body_raw = self.raw_source[brace_pos + 1 : close_brace_pos]
            start_line = self.masked_source.count('\n', 0, m.start(1)) + 1
            end_line = self.masked_source.count('\n', 0, close_brace_pos) + 1

            scopes.append(FunctionScope(
                name=name,
                return_type=ret_type,
                params_str=params_str,
                start_line=start_line,
                end_line=end_line,
                body_raw=body_raw,
                body_masked=body_masked,
                full_raw=self.raw_source[m.start(1):close_brace_pos + 1],
                full_masked=self.masked_source[m.start(1):close_brace_pos + 1],
                params=parsed_params,
            ))
        return scopes


class SecurityRuleRegistry:
    """Registry managing all deterministic security rules and orchestrating detection passes."""

    def __init__(self):
        self._rules: Dict[str, SecurityRule] = {}
        self._detectors: List[Callable[[AnalysisContext], List[Finding]]] = []

    def register(self, rule: SecurityRule) -> None:
        self._rules[rule.rule_id] = rule

    def add_detector(self, detector: Callable[[AnalysisContext], List[Finding]]) -> None:
        self._detectors.append(detector)

    def get_rule(self, rule_id: str) -> Optional[SecurityRule]:
        return self._rules.get(rule_id)

    def get_all_rules(self) -> List[SecurityRule]:
        return list(self._rules.values())

    def analyze(self, raw_source: str, masker: Optional[CppLexicalMasker] = None) -> Tuple[List[Finding], bool]:
        ctx = AnalysisContext(raw_source, masker)
        findings: List[Finding] = []

        for detector in self._detectors:
            try:
                res = detector(ctx)
                if res:
                    findings.extend(res)
            except Exception:
                pass

        # Deduplicate findings by (rule_id, line)
        deduped = self._deduplicate_findings(findings)
        has_critical = any(f.severity == "critical" for f in deduped)
        return deduped, has_critical

    def _deduplicate_findings(self, findings: List[Finding]) -> List[Finding]:
        seen_keys: Dict[Tuple[str, int, int], Finding] = {}
        deduped: List[Finding] = []
        severity_rank = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

        for f in findings:
            col = getattr(f, "column", 1)
            key = (f.rule_id, f.line, col)
            if key not in seen_keys:
                seen_keys[key] = f
                deduped.append(f)
            else:
                existing = seen_keys[key]
                if severity_rank.get(f.severity, 0) > severity_rank.get(existing.severity, 0):
                    deduped.remove(existing)
                    seen_keys[key] = f
                    deduped.append(f)
        return deduped


# Global registry singleton
REGISTRY = SecurityRuleRegistry()


# =============================================================================
# DETECTOR IMPLEMENTATIONS
# =============================================================================

def _find_line_in_context(ctx: AnalysisContext, pattern: re.Pattern, on_masked: bool = True) -> List[Tuple[int, re.Match]]:
    """Helper searching lines and returning (line_number, match) pairs."""
    results = []
    lines = ctx.lines_masked if on_masked else ctx.lines_raw
    for idx, line in enumerate(lines, start=1):
        m = pattern.search(line)
        if m:
            results.append((idx, m))
    return results


# -----------------------------------------------------------------------------
# Section A: Memory Safety Detectors
# -----------------------------------------------------------------------------

def detect_banned_string_apis(ctx: AnalysisContext) -> List[Finding]:
    findings = []
    # 1. alloca() stack allocation risk (retained non-sink check)
    alloca_pat = re.compile(r"\balloca\s*\(")
    rule_alloca = REGISTRY.get_rule("SEC-BUF-005")
    if rule_alloca:
        for idx, _ in _find_line_in_context(ctx, alloca_pat, on_masked=True):
            findings.append(Finding(
                rule_id=rule_alloca.rule_id, title=rule_alloca.title, severity=rule_alloca.severity, line=idx,
                description=rule_alloca.description, mitigation=rule_alloca.mitigation, evidence=ctx.get_raw_line(idx),
            ))

    # 2. cin >> char[] (retained non-sink check)
    cin_re = re.compile(r'\bcin\s*>>\s*([a-zA-Z_]\w*)')
    char_array_decl = re.compile(r'\bchar\s+([a-zA-Z_]\w*)\s*\[\s*\d+\s*\]')
    char_arrays = set()
    for line in ctx.lines_masked:
        for m in char_array_decl.finditer(line):
            char_arrays.add(m.group(1))

    if char_arrays:
        for idx, line in enumerate(ctx.lines_masked, start=1):
            if "setw" in line:
                continue
            for m in cin_re.finditer(line):
                var_name = m.group(1)
                if var_name in char_arrays:
                    rule = REGISTRY.get_rule("SEC-INP-002")
                    if rule:
                        findings.append(Finding(
                            rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                            description=f"Unbounded extraction 'cin >> {var_name}' into fixed-size array risks buffer overflow.",
                            mitigation=rule.mitigation, evidence=ctx.get_raw_line(idx),
                        ))
    return findings


def detect_memory_safety_structural(ctx: AnalysisContext) -> List[Finding]:
    findings = []

    for fn in ctx.functions:
        body = fn.body_masked
        raw_body = fn.body_raw

        # 5. CWE-193: Off-by-one loop boundary on array (e.g. char buf[8]; for (int i = 0; i <= 8; i++) buf[i])
        arr_decl = re.search(r'\b\w+\s+(\w+)\s*\[\s*(\d+)\s*\]', body)
        if arr_decl:
            arr_name = arr_decl.group(1)
            arr_sz = int(arr_decl.group(2))
            loop_obo = re.search(rf'for\s*\([^;]*;\s*([a-zA-Z_]\w*)\s*<=\s*{arr_sz}\b[^)]*\)', body)
            if loop_obo:
                rule = REGISTRY.get_rule("SEC-MEM-005")
                ln = fn.start_line + body[:loop_obo.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Off-by-one boundary '<= {arr_sz}' allows loop to access out-of-bounds element {arr_name}[{arr_sz}].",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 6. CWE-122: Heap overflow via malloc(CONST) followed by memcpy(..., src, VAR)
        malloc_fixed = re.search(r'([a-zA-Z_]\w*)\s*=\s*(?:\([^)]*\)\s*)?malloc\s*\(\s*(\d+)\s*\)', body)
        if malloc_fixed:
            p_var = malloc_fixed.group(1)
            f_size = int(malloc_fixed.group(2))
            memcpy_m = re.search(rf'memcpy\s*\(\s*{p_var}\s*,[^,]+,\s*([a-zA-Z_]\w*)\s*\)', body)
            if memcpy_m:
                v_len = memcpy_m.group(1)
                if not v_len.isdigit():
                    rule = REGISTRY.get_rule("SEC-MEM-006")
                    ln = fn.start_line + body[:memcpy_m.start()].count('\n')
                    if rule:
                        findings.append(Finding(
                            rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                            description=f"Heap buffer of fixed size {f_size} populated by memcpy with variable length '{v_len}', risking heap overflow.",
                            mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                        ))

        # 7. CWE-416: Use after free & 8. CWE-415: Double free
        free_matches = list(re.finditer(r'\bfree\s*\(\s*([a-zA-Z_]\w*)\s*\)', body))
        if free_matches:
            for idx_f, fm in enumerate(free_matches):
                freed_var = fm.group(1)
                after_pos = fm.end()
                rest_body = body[after_pos:]

                # Check double free
                df_match = re.search(rf'\bfree\s*\(\s*{freed_var}\s*\)', rest_body)
                if df_match:
                    rule = REGISTRY.get_rule("SEC-MEM-008")
                    ln = fn.start_line + body[:after_pos + df_match.start()].count('\n')
                    if rule:
                        findings.append(Finding(
                            rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                            description=f"Pointer '{freed_var}' is deallocated a second time without reallocation, causing undefined double-free behavior.",
                            mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                        ))

                # Check use after free (*p, p->, p[...], or use in statement)
                uaf_match = re.search(rf'(?:\*\s*{freed_var}\b|{freed_var}\s*->|{freed_var}\s*\[)', rest_body)
                if uaf_match:
                    rule = REGISTRY.get_rule("SEC-MEM-007")
                    ln = fn.start_line + body[:after_pos + uaf_match.start()].count('\n')
                    if rule:
                        findings.append(Finding(
                            rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                            description=f"Pointer '{freed_var}' is dereferenced after being freed, causing use-after-free corruption.",
                            mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                        ))

        # 9. CWE-401: Heap allocation without assignment or delete (Memory leak)
        leak_match = re.search(r'(?:^|[\r\n;{}])\s*(?:for\s*\([^)]*\)\s*\{?\s*)?new\s+[^;=]+;', body)
        if leak_match:
            rule = REGISTRY.get_rule("SEC-MEM-009")
            ln = fn.start_line + body[:leak_match.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Memory allocated via 'new' is not retained or assigned to any owner, causing an immediate memory leak.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 10. CWE-476: Unchecked null pointer dereference after strchr / strstr
        find_fn = re.search(r'([a-zA-Z_]\w*)\s*=\s*(?:strchr|strrchr|strstr|memchr)\s*\(', body)
        if find_fn:
            ptr_name = find_fn.group(1)
            after_find = body[find_fn.end():]
            deref_m = re.search(rf'(?:\*\s*{ptr_name}\b|{ptr_name}\s*->|{ptr_name}\s*\[)', after_find)
            if deref_m and not re.search(rf'if\s*\(\s*(?:!{ptr_name}|{ptr_name}\s*==\s*(?:nullptr|NULL|0)|{ptr_name}\b)', after_find[:deref_m.start()]):
                rule = REGISTRY.get_rule("SEC-MEM-010")
                ln = fn.start_line + body[:find_fn.end() + deref_m.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Result of lookup '{ptr_name}' is dereferenced without verifying if the pointer is null.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 11. CWE-457: Return uninitialized local variable
        uninit_m = re.search(r'(?:int|char|short|long|float|double|bool)\s+([a-zA-Z_]\w*)\s*;\s*return\s+\1\s*;', body)
        if uninit_m:
            var_name = uninit_m.group(1)
            rule = REGISTRY.get_rule("SEC-MEM-011")
            ln = fn.start_line + body[:uninit_m.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description=f"Local variable '{var_name}' is returned uninitialized, exposing indeterminate stack contents.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 12. CWE-562: Return pointer to stack variable
        ret_ptr_m = re.search(r'(\w+)\s+([a-zA-Z_]\w*)\s*\[\s*\d+\s*\][^;]*;\s*return\s+(?:&?\2)\s*;', body)
        if ret_ptr_m and '*' in fn.return_type:
            arr_name = ret_ptr_m.group(2)
            rule = REGISTRY.get_rule("SEC-MEM-012")
            ln = fn.start_line + body[:ret_ptr_m.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description=f"Function returns pointer or address to stack-allocated local array '{arr_name}' which expires on return.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 13. CWE-190: Integer overflow in allocation size (count * sizeof)
        malloc_mul = re.search(r'malloc\s*\(\s*([a-zA-Z_]\w*)\s*\*\s*sizeof', body)
        if malloc_mul:
            var_count = malloc_mul.group(1)
            rule = REGISTRY.get_rule("SEC-MEM-013")
            ln = fn.start_line + body[:malloc_mul.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description=f"Multiplication '{var_count} * sizeof(...)' in malloc size argument can overflow integer bounds leading to undersized allocation.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 14. CWE-195: Signed / unsigned conversion (handled in Layer B: detect_scope_and_guard_analysis)

        # 15. CWE-129: Unchecked array index parameter
        arr_idx_m = re.search(r'(\w+)\s*\[\s*([a-zA-Z_]\w*)\s*\]', body)
        if arr_idx_m and fn.params:
            idx_v = arr_idx_m.group(2)
            arr_v = arr_idx_m.group(1)
            # check if idx_v is a parameter and signed int
            if any(idx_v == p[1] and 'int' in p[0] for p in fn.params):
                if not re.search(rf'if\s*\([^)]*{idx_v}\s*>=', body):
                    rule = REGISTRY.get_rule("SEC-MEM-015")
                    ln = fn.start_line + body[:arr_idx_m.start()].count('\n')
                    if rule:
                        findings.append(Finding(
                            rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                            description=f"Signed parameter index '{idx_v}' used in '{arr_v}[{idx_v}]' without non-negative and upper-bound checks.",
                            mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                        ))

        # 16. CWE-125: Loop out of bounds access (for i <= n)
        loop_oob = re.search(r'for\s*\([^;]*;\s*([a-zA-Z_]\w*)\s*<=\s*([a-zA-Z_]\w*)\s*;[^)]*\)\s*[^;]*\[\s*\1\s*\]', body)
        if loop_oob:
            rule = REGISTRY.get_rule("SEC-MEM-016")
            ln = fn.start_line + body[:loop_oob.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Loop uses '<=' with container/buffer size, reading one element past the buffer boundary.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 18. CWE-762: Mismatched new[] / delete
        new_arr = re.search(r'([a-zA-Z_]\w*)\s*=\s*new\s+\w+\s*\[[^\]]+\]', body)
        if new_arr:
            ptr_v = new_arr.group(1)
            del_scalar = re.search(rf'delete\s+{ptr_v}\s*;', body)
            if del_scalar:
                rule = REGISTRY.get_rule("SEC-MEM-018")
                ln = fn.start_line + body[:del_scalar.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Array allocated with 'new[]' must be deallocated with 'delete[]', not scalar 'delete {ptr_v}'.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 19. CWE-416: Return dangling reference to local temporary
        if '&' in fn.return_type and not 'void' in fn.return_type:
            ret_local = re.search(r'(?:std::string|string|int|float|double|\w+)\s+([a-zA-Z_]\w*)\s*=\s*[^;]+;\s*return\s+\1\s*;', body)
            if ret_local:
                l_name = ret_local.group(1)
                rule = REGISTRY.get_rule("SEC-MEM-019")
                ln = fn.start_line + body[:ret_local.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Function returning reference binds to local temporary variable '{l_name}', creating a dangling reference.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 20. CWE-416: Iterator invalidation
        iter_loop = re.search(r'for\s*\([^;]*\b([a-zA-Z_]\w*)\.begin\(\)[^;]*;\s*[^)]*\)\s*\{?[^}]*\b\1\.(?:push_back|emplace_back|insert|erase)\s*\(', body)
        if iter_loop:
            rule = REGISTRY.get_rule("SEC-MEM-020")
            ln = fn.start_line + body[:iter_loop.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Container modified inside loop iterating with its own iterators, invalidating active iterators.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 21. CWE-125: vector::operator[] without bounds check
        if any('vector' in p[0] for p in fn.params):
            v_param = [p[1] for p in fn.params if 'vector' in p[0]][0]
            v_idx = re.search(rf'return\s+{v_param}\s*\[\s*([a-zA-Z_]\w*)\s*\]', body)
            if v_idx and not re.search(r'\bif\s*\(|\.size\(\)|\.empty\(\)', body):
                rule = REGISTRY.get_rule("SEC-MEM-021")
                ln = fn.start_line + body[:v_idx.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Direct vector indexing '{v_param}[i]' performs no bounds checking. Use '{v_param}.at(i)' or size validation.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 22. CWE-170: strncpy without null termination (handled in Layer B: detect_scope_and_guard_analysis)

        # 24. CWE-1285: Variable Length Array (VLA)
        vla_m = re.search(r'\b(?:char|int|short|long|float|double|unsigned\s+\w+)\s+([a-zA-Z_]\w*)\s*\[\s*([a-zA-Z_]\w*)\s*\]', body)
        if vla_m:
            v_sz = vla_m.group(2)
            if any(v_sz == p[1] for p in fn.params):
                rule = REGISTRY.get_rule("SEC-MEM-024")
                ln = fn.start_line + body[:vla_m.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Variable Length Array (VLA) allocated with runtime parameter '{v_sz}', risking stack overflow crashes.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 25. CWE-197: Integer truncation (handled in Layer B: detect_scope_and_guard_analysis)

    return findings


# -----------------------------------------------------------------------------
# Section B: Injection & Output Detectors
# -----------------------------------------------------------------------------

def detect_command_and_process_injection(ctx: AnalysisContext) -> List[Finding]:
    """Delegated to Declarative Sink DB (engine/security_sinks.json)."""
    return []


def detect_injection_and_output_structural(ctx: AnalysisContext) -> List[Finding]:
    findings = []

    for fn in ctx.functions:
        body = fn.body_masked
        raw_body = fn.body_raw

        # 28. CWE-89: SQL Injection via query string concatenation
        sql_kw = re.search(r'(?:SELECT|INSERT|UPDATE|DELETE|DROP|FROM|WHERE)\b', raw_body, re.IGNORECASE)
        if sql_kw and ('"' in raw_body and '+' in raw_body):
            if re.search(r'\+\s*[a-zA-Z_]\w*', body) and re.search(r'(?:db_exec|query|execute|mysql_query|sqlite3_exec)\b', body):
                rule = REGISTRY.get_rule("SEC-INJ-001")
                ln = fn.start_line + raw_body[:sql_kw.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description="SQL statement constructed via unescaped string concatenation, creating SQL injection vulnerabilities.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 29. CWE-22: Path traversal in file open via string concatenation
        if re.search(r'fopen\s*\(\s*(?:\([^)]*\)\s*)?(?:[^\)]*\+\s*[a-zA-Z_]\w*)', body):
            rule = REGISTRY.get_rule("SEC-PATH-004")
            fopen_m = re.search(r'fopen\s*\(', body)
            ln = fn.start_line + body[:fopen_m.start()].count('\n') if fopen_m else fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="File path constructed via string concatenation without canonicalization, permitting directory traversal.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 31. CWE-90: LDAP filter injection
        if (re.search(r'["\']\s*\([&|]', raw_body) or re.search(r'["\'][^"\']*\buid=', raw_body)) and '+' in body:
            rule = REGISTRY.get_rule("SEC-INJ-002")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="LDAP search filter constructed via string concatenation without escaping special characters.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 32. CWE-79: Reflected XSS in HTML output
        if re.search(r'<\s*(?:html|body|script|div|span|p)\b', raw_body, re.IGNORECASE) and '+' in body:
            rule = REGISTRY.get_rule("SEC-INJ-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Unencoded user parameter embedded directly into HTML response string, allowing Cross-Site Scripting (XSS).",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 33. CWE-117: Log injection
        if re.search(r'fprintf\s*\(\s*stderr\s*,\s*"[^"]+%s[^"]*"', raw_body) and not re.search(r'fprintf\s*\(\s*stderr\s*,\s*"%s"\s*,', raw_body) and any(p[1] for p in fn.params):
            rule = REGISTRY.get_rule("SEC-INJ-004")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Untrusted user input written directly to log output stream without stripping carriage return/line feed characters.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 34. CWE-113: HTTP response splitting / CRLF injection
        if ('HTTP/1.1' in raw_body or 'HTTP/1.0' in raw_body or r'\r\n' in raw_body) and '+' in body:
            rule = REGISTRY.get_rule("SEC-NET-001")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="HTTP status/headers concatenated with user parameters, exposing HTTP response splitting / CRLF injection.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 35. CWE-134: syslog with non-literal format string
        syslog_m = re.search(r'syslog\s*\(\s*[^,]+,\s*([^,;)]+)\s*\)', body)
        if syslog_m:
            fmt_arg = syslog_m.group(1).strip()
            if fmt_arg:
                rule = REGISTRY.get_rule("SEC-FMT-002")
                ln = fn.start_line + body[:syslog_m.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description="syslog() invoked with variable format argument, enabling uncontrolled format string execution.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 37. CWE-611: XXE entity processing
        if '<!ENTITY' in raw_body:
            rule = REGISTRY.get_rule("SEC-INJ-005")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="XML processing detects external entity declaration '<!ENTITY' without disabling DTD / external entities.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 38. CWE-1333: Regular expression / recursive backtracking exponential complexity
        if re.search(r"p\[1\]\s*==\s*'\*'", raw_body) and re.search(rf'{fn.name}\s*\(', body):
            rule = REGISTRY.get_rule("SEC-LOG-001")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Catastrophic recursive backtracking matcher exhibits exponential O(2^N) runtime on adversarial input.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 39. CWE-502: Unsafe deserialization into struct holding function pointer
        if 'memcpy' in body and re.search(r'\.\w+\s*\(', body):
            # Check if any struct in source has function pointer
            if re.search(r'\(\s*\*\s*\w+\s*\)\s*\(', ctx.masked_source):
                rule = REGISTRY.get_rule("SEC-MEM-026")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description="Unsafe memory deserialization into structure containing function pointers allows arbitrary control flow hijacking.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 40. CWE-1336 / CWE-134: snprintf with non-literal format string
        snprint_m = re.search(r'snprintf\s*\(\s*[^,]+,\s*[^,]+,\s*([a-zA-Z_]\w*(?:\.c_str\(\))?)\s*,', body)
        if snprint_m:
            fmt_v = snprint_m.group(1).strip()
            rule = REGISTRY.get_rule("SEC-FMT-003")
            ln = fn.start_line + body[:snprint_m.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description=f"snprintf() called with non-literal user template format string '{fmt_v}', allowing template injection.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

    # Existing printf/fprintf non-literal format string checker
    fmt_regex = re.compile(r"\b(printf|fprintf|vprintf|vfprintf)\s*\(\s*([^,;)]+)\s*\)")
    for idx, line in enumerate(ctx.lines_masked, start=1):
        m = fmt_regex.search(line)
        if m:
            first_arg = m.group(2).strip()
            if first_arg and not first_arg.startswith('"'):
                rule = REGISTRY.get_rule("SEC-FMT-001")
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                        description=rule.description, mitigation=rule.mitigation, evidence=ctx.get_raw_line(idx),
                    ))

    return findings


# -----------------------------------------------------------------------------
# Section C: Crypto & Authentication Detectors
# -----------------------------------------------------------------------------

def detect_crypto_and_auth_structural(ctx: AnalysisContext) -> List[Finding]:
    findings = []

    # 42. CWE-798: sk_live_ token or high entropy API key
    sk_token_re = re.compile(r'"(sk_live_[a-zA-Z0-9_]+|ghp_[a-zA-Z0-9]+|xoxb-[a-zA-Z0-9-]+)"')
    for idx, raw_line in enumerate(ctx.lines_raw, start=1):
        m = sk_token_re.search(raw_line)
        if m:
            rule = REGISTRY.get_rule("SEC-AUTH-002")
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                    description="Hardcoded live production secret / API token literal detected in source code.",
                    mitigation=rule.mitigation, evidence=f'{m.group(1)[:12]}***',
                ))

    # 50. CWE-329: Static / Zero IV
    iv_re = re.compile(r'\b(?:const\s+)?unsigned\s+char\s+(?:IV|iv|Iv)\s*\[\s*\d+\s*\]\s*=\s*\{')
    for idx, line in enumerate(ctx.lines_masked, start=1):
        if iv_re.search(line):
            rule = REGISTRY.get_rule("SEC-CRY-007")
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                    description="Static or zero-filled initialization vector (IV) reduces cryptographic security against replay attacks.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(idx),
                ))

    # 59. CWE-321: Hardcoded cryptographic key (e.g. AES_KEY[] = "0123456789abcdef")
    aes_key_re = re.compile(r'(?:AES_KEY|KEY|SECRET|DES_KEY)\s*\[\s*\]\s*=\s*"([^"]+)"', re.IGNORECASE)
    for idx, raw_line in enumerate(ctx.lines_raw, start=1):
        m = aes_key_re.search(raw_line)
        if m and len(m.group(1)) in (16, 24, 32):
            rule = REGISTRY.get_rule("SEC-CRY-009")
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                    description="Hardcoded symmetric encryption key literal detected in source text.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(idx),
                ))

    # 60. CWE-261: Base64 alphabet table used as protection/encryption
    b64_table_re = re.compile(r'"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789\+/"')
    for idx, raw_line in enumerate(ctx.lines_raw, start=1):
        if b64_table_re.search(raw_line):
            rule = REGISTRY.get_rule("SEC-CRY-010")
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                    description="Base64 encoding table used in custom transform function. Encoding does not provide cryptographic confidentiality.",
                    mitigation=rule.mitigation, evidence="Base64 translation table lookup",
                ))

    for fn in ctx.functions:
        body = fn.body_masked
        raw_body = fn.body_raw

        # 41. CWE-798: Hardcoded password comparison
        pwd_cmp = re.search(r'==\s*"([a-zA-Z0-9!@#$%^&*_-]{4,})"', raw_body)
        if pwd_cmp and any(p[1] in ('p', 'pw', 'pass', 'password') for p in fn.params):
            val = pwd_cmp.group(1)
            rule = REGISTRY.get_rule("SEC-AUTH-001")
            ln = fn.start_line + raw_body[:pwd_cmp.start()].count('\n')
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description=f"Direct equality comparison against hardcoded plaintext credential literal '***'.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 43 & 49. CWE-328 & CWE-759: Weak hash (MD5) & Unsalted hash
        if 'md5' in body.lower() and any(p[1] in ('pw', 'pass', 'password') for p in fn.params):
            rule328 = REGISTRY.get_rule("SEC-CRY-001")
            rule759 = REGISTRY.get_rule("SEC-CRY-006")
            ln = fn.start_line
            if rule328:
                findings.append(Finding(
                    rule_id=rule328.rule_id, title=rule328.title, severity=rule328.severity, line=ln,
                    description="Obsolete cryptographically broken hash function (MD5) used for sensitive authentication data.",
                    mitigation=rule328.mitigation, evidence=ctx.get_raw_line(ln),
                ))
            if rule759:
                findings.append(Finding(
                    rule_id=rule759.rule_id, title=rule759.title, severity=rule759.severity, line=ln,
                    description="Password hashed without unique salt, leaving hash vulnerable to rainbow table lookups.",
                    mitigation=rule759.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 44. CWE-338: Insecure PRNG rand()
        if re.search(r'\brand\s*\(\s*\)', body):
            rule = REGISTRY.get_rule("SEC-CRY-002")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Insecure pseudo-random number generator rand() used for security-critical value generation.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 45. CWE-337: Predictable PRNG seed srand(time(nullptr))
        if re.search(r'\bsrand\s*\(\s*time\s*\(', body):
            rule = REGISTRY.get_rule("SEC-CRY-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="PRNG seeded with current timestamp time(), allowing attackers to predict future sequences.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 46. CWE-327: Home-grown XOR encryption
        if re.search(r'\^=\s*(?:0x[0-9a-fA-F]+|\d+)', body):
            rule = REGISTRY.get_rule("SEC-CRY-004")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Home-grown byte-wise XOR transform provides zero cryptographic confidentiality.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 47. CWE-208: Observable timing side channel in comparison (strcmp == 0)
        if re.search(r'strcmp\s*\([^)]*\)\s*==\s*0', body):
            rule = REGISTRY.get_rule("SEC-CRY-005")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Byte-by-byte non-constant-time comparison strcmp() leaks secret length and content through timing discrepancies.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 48. CWE-256: Plaintext password storage
        if ('users.txt' in raw_body or 'passwords.txt' in raw_body) and any(p[1] in ('p', 'pw', 'pass') for p in fn.params):
            rule = REGISTRY.get_rule("SEC-AUTH-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Sensitive user password variable stored in unencrypted plaintext on disk.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 51. CWE-377: Insecure predictable temporary file path (/tmp/app_session.tmp)
        if re.search(r'"/tmp/[^"]+\.tmp"', raw_body):
            rule = REGISTRY.get_rule("SEC-FIL-001")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Static predictable temporary file path in shared /tmp directory risks symlink and collision attacks.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 52. CWE-326: Inadequate key length (e.g. return 40;)
        if re.search(r'return\s+(?:40|56|512|1024)\s*;', body):
            rule = REGISTRY.get_rule("SEC-CRY-008")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Inadequate cryptographic key length returned (< 2048-bit RSA or < 128-bit symmetric).",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 53. CWE-295: Disabled TLS certificate verification
        if re.search(r'\{\s*false\s*,\s*false\s*\}', body) or re.search(r'verify_peer\s*=\s*false', body):
            rule = REGISTRY.get_rule("SEC-NET-002")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="TLS certificate peer and hostname verification disabled, exposing connections to Man-in-the-Middle attacks.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 54. CWE-1392: Default credentials {"admin", "admin"}
        if re.search(r'\{\s*"admin"\s*,\s*"admin"\s*\}', raw_body):
            rule = REGISTRY.get_rule("SEC-AUTH-004")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Default hardcoded administrative credentials {'admin', 'admin'} embedded in application.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 55. CWE-532: Password written to log
        if re.search(r'fprintf\s*\(\s*stderr\s*,', body) and re.search(r'pass\s*=', raw_body):
            rule = REGISTRY.get_rule("SEC-INF-001")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Sensitive user password formatted and printed into standard error log stream.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 56. CWE-306: Missing authentication on administrative function
        if fn.params and any(p[1] in ('cmd', 'command') for p in fn.params) and 'system' in body:
            rule = REGISTRY.get_rule("SEC-AUTH-005")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Privileged administrative command function executes without validating caller authentication or authorization.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 57. CWE-330: Sequential session identifier
        if re.search(r'static\s+int\s+id\s*=\s*\d+\s*;\s*return\s*\+\+id\s*;', body):
            rule = REGISTRY.get_rule("SEC-AUTH-006")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Sequential session/token generation yields predictable session identifiers subject to hijacking.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 58. CWE-697: Comparing C-string pointers instead of contents
        if re.search(r'return\s+([a-zA-Z_]\w*)\s*==\s*([a-zA-Z_]\w*)\s*;', body):
            m_ptrs = re.search(r'return\s+([a-zA-Z_]\w*)\s*==\s*([a-zA-Z_]\w*)\s*;', body)
            p1, p2 = m_ptrs.group(1), m_ptrs.group(2)
            if any('char*' in p[0] for p in fn.params if p[1] == p1) and any('char*' in p[0] for p in fn.params if p[1] == p2):
                rule = REGISTRY.get_rule("SEC-LOG-002")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"C-strings '{p1}' and '{p2}' compared using pointer equality '=='. Use strcmp() or std::string_view.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

    return findings


# -----------------------------------------------------------------------------
# Section D: Files, Processes & Concurrency Detectors
# -----------------------------------------------------------------------------

def detect_files_and_concurrency_structural(ctx: AnalysisContext) -> List[Finding]:
    findings = []

    for fn in ctx.functions:
        body = fn.body_masked
        raw_body = fn.body_raw

        # 61. CWE-367: TOCTOU race (access followed by open)
        acc_m = re.search(r'\baccess\s*\(\s*(\w+)\s*,[^)]*\)', body)
        if acc_m:
            path_var = acc_m.group(1)
            if re.search(rf'\bopen\s*\(\s*{re.escape(path_var)}\s*,', body):
                rule = REGISTRY.get_rule("SEC-FIL-002")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description="Time-of-check to time-of-use (TOCTOU) race condition: access() check is checked before open().",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 62. CWE-732: World-writable file creation mode 0777
        if re.search(r'\bopen\s*\([^)]*,\s*0777\s*\)', body):
            rule = REGISTRY.get_rule("SEC-FIL-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="File created with overly permissive world-writable permissions mask 0777.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 63. CWE-59: Symlink following write in /tmp without O_EXCL
        if re.search(r'open\s*\(\s*"/tmp/', raw_body) and 'O_CREAT' in body and not 'O_EXCL' in body:
            rule = REGISTRY.get_rule("SEC-FIL-004")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="File creation in shared temporary directory /tmp without O_EXCL risks symlink following attacks.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 64. CWE-276: Permissive umask(0)
        if re.search(r'\bumask\s*\(\s*0\s*\)', body):
            rule = REGISTRY.get_rule("SEC-FIL-005")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="umask(0) removes all default file creation security restrictions.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 65. CWE-73: External control of file path in fopen
        fopen_param = re.search(r'fopen\s*\(\s*([a-zA-Z_]\w*)\s*,\s*"[wa]"', raw_body)
        if fopen_param:
            p_arg = fopen_param.group(1)
            if any(p_arg == p[1] for p in fn.params):
                rule = REGISTRY.get_rule("SEC-FIL-006")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Untrusted parameter '{p_arg}' controls target file path in fopen() without directory restriction.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 66. CWE-252: Unchecked return value of read / write
        if re.search(r'(?:^|[\r\n;{}])\s*(?:read|write)\s*\([^)]*\)\s*;', body):
            rule = REGISTRY.get_rule("SEC-LOG-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Return value of read() or write() is discarded, ignoring partial writes or transfer errors.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 67. CWE-775: File descriptor leak in loop
        if re.search(r'for\s*\([^)]*\)[^}]*\bopen\s*\(', body) and not 'close' in body:
            rule = REGISTRY.get_rule("SEC-FIL-007")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="File descriptors opened inside a loop without close(), leaking operating system resources.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 68. CWE-362: Data race on shared global in thread lambdas
        if 'std::thread' in body and re.search(r'g_\w+\+\+', body) and not 'mutex' in body:
            rule = REGISTRY.get_rule("SEC-CON-001")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Data race: shared global counter mutated inside concurrent thread lambdas without synchronization.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 70. CWE-250: Undropped privileges
        if 'setuid(0)' in body or 'setuid( 0 )' in body:
            rule = REGISTRY.get_rule("SEC-FIL-008")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Elevated root privileges acquired via setuid(0) are never dropped before downstream execution.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 71. CWE-243: chroot without chdir
        if 'chroot' in body and not 'chdir' in body:
            rule = REGISTRY.get_rule("SEC-FIL-009")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="chroot() invoked without accompanying chdir(\"/\"), allowing jailbreak via relative path lookups.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 72. CWE-400: Unbounded byte-by-byte file read
        if re.search(r'while\s*\([^)]*fread\s*\(&\w+,\s*1,\s*1', body):
            rule = REGISTRY.get_rule("SEC-FIL-010")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Unbounded byte-by-byte fread() loop accumulates entire file into memory without a size ceiling.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 73. CWE-23: Zip-slip archive path extraction
        if ('"./out/"' in raw_body or "'./out/'" in raw_body) and '+' in body:
            rule = REGISTRY.get_rule("SEC-PATH-005")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Archive entry path concatenated into destination output path without validating against '../' directory traversal.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 74. CWE-377: tmpnam race
        if re.search(r'\btmpnam\s*\(', body):
            rule = REGISTRY.get_rule("SEC-FIL-011")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="tmpnam() is vulnerable to race conditions between filename generation and file opening. Use mkstemp().",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 75. CWE-532 / CWE-732: Sensitive log file world-readable
        if 'audit.log' in raw_body and '0644' in body:
            rule = REGISTRY.get_rule("SEC-INF-002")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Security audit log created with world-readable permissions 0644, exposing audit trails.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

    # 69. CWE-479: Signal handler calling async-signal-unsafe functions
    for idx, raw_line in enumerate(ctx.lines_raw, start=1):
        if 'signal(' in raw_line and 'SIG' in raw_line:
            sig_m = re.search(r'signal\s*\(\s*[^,]+,\s*([a-zA-Z_]\w*)\s*\)', raw_line)
            if sig_m:
                h_name = sig_m.group(1)
                # Find handler function in parsed functions
                h_fn = next((f for f in ctx.functions if f.name == h_name), None)
                if h_fn and re.search(r'\b(printf|fprintf|malloc|free|puts)\b', h_fn.body_masked):
                    rule = REGISTRY.get_rule("SEC-CON-002")
                    if rule:
                        findings.append(Finding(
                            rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                            description=f"Signal handler '{h_name}' executes async-signal-unsafe functions (printf/malloc/free).",
                            mitigation=rule.mitigation, evidence=raw_line.strip(),
                        ))

    return findings


# -----------------------------------------------------------------------------
# Section E: Network Security Detectors
# -----------------------------------------------------------------------------

def detect_network_structural(ctx: AnalysisContext) -> List[Finding]:
    findings = []

    # 89. CWE-942: Wildcard CORS with credentials
    cors_wc = re.compile(r'Access-Control-Allow-Origin:\s*\*')
    cors_cred = re.compile(r'Access-Control-Allow-Credentials:\s*true')
    for idx, raw_line in enumerate(ctx.lines_raw, start=1):
        if cors_wc.search(raw_line) and cors_cred.search(raw_line):
            rule = REGISTRY.get_rule("SEC-NET-013")
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                    description="CORS configuration pairs wildcard origin '*' with 'Access-Control-Allow-Credentials: true'.",
                    mitigation=rule.mitigation, evidence=raw_line.strip(),
                ))

    for fn in ctx.functions:
        body = fn.body_masked
        raw_body = fn.body_raw

        # 76. CWE-1327: Binding socket to all interfaces (INADDR_ANY)
        if 'INADDR_ANY' in body and 'bind' in body:
            rule = REGISTRY.get_rule("SEC-NET-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Socket bound to INADDR_ANY (0.0.0.0), exposing network service across all external network interfaces.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 77. CWE-400: Slowloris denial of service via loop recv without timeout
        if re.search(r'while\s*\([^)]*recv\s*\([^)]*\)\s*>\s*0\)', body) and not 'SO_RCVTIMEO' in body:
            rule = REGISTRY.get_rule("SEC-NET-004")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Infinite socket receive loop lacks a SO_RCVTIMEO socket timeout, exposing daemon to Slowloris resource exhaustion.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 78. CWE-120: recv length exceeds destination buffer
        recv_buf_m = re.search(r'char\s+([a-zA-Z_]\w*)\s*\[\s*(\d+)\s*\][^;]*;[^}]*recv\s*\([^,]+,\s*\1\s*,\s*(\d+)', body)
        if recv_buf_m:
            b_sz = int(recv_buf_m.group(2))
            r_sz = int(recv_buf_m.group(3))
            if r_sz > b_sz:
                rule = REGISTRY.get_rule("SEC-NET-005")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"recv() buffer length {r_sz} exceeds target buffer capacity {b_sz}, causing remote buffer overflow.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 79. CWE-130: Trusting client length field
        recv_len_m = re.search(r'recv\s*\([^,]+,\s*&([a-zA-Z_]\w*)\s*,', body)
        if recv_len_m:
            len_var = recv_len_m.group(1)
            if re.search(rf'recv\s*\([^,]+,[^,]+,\s*{re.escape(len_var)}\s*,', body):
                rule = REGISTRY.get_rule("SEC-NET-006")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description="Unvalidated message length read from network socket is used as transfer size for subsequent read.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 80. CWE-319: Cleartext transmission of sensitive credentials
        if re.search(r'(?:send|send_all|write)\s*\([^,]+,\s*(?:pw|password|pass|secret)\b', body):
            rule = REGISTRY.get_rule("SEC-NET-007")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Sensitive user credentials transmitted in unencrypted cleartext over socket connection.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 81. CWE-918: SSRF via curl command
        if ('"curl ' in raw_body or "'curl " in raw_body) and 'system' in body:
            rule = REGISTRY.get_rule("SEC-NET-008")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="User-supplied URL passed directly into curl command, enabling Server-Side Request Forgery (SSRF).",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 82. CWE-770: Allocation driven by client parameter without cap
        if re.search(r'vector<\w+>\s+\w+\s*\(\s*([a-zA-Z_]\w*)\s*\)', body):
            v_cap = re.search(r'vector<\w+>\s+\w+\s*\(\s*([a-zA-Z_]\w*)\s*\)', body).group(1)
            if any(v_cap == p[1] for p in fn.params):
                rule = REGISTRY.get_rule("SEC-NET-009")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Container sized directly by external parameter '{v_cap}' without maximum memory cap.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 83. CWE-307: No limit on authentication attempts
        if any(p[1] in ('p', 'pw', 'pass') for p in fn.params) and re.search(r'return\s+p\s*==', raw_body) and not re.search(r'fail|attempt|delay|count', body):
            rule = REGISTRY.get_rule("SEC-AUTH-007")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Authentication check performs no attempt counting, throttling, or account lockout safeguards.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 84. CWE-362: Obsolete resolver gethostbyname
        if re.search(r'\bgethostbyname\s*\(', body):
            rule = REGISTRY.get_rule("SEC-NET-010")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="gethostbyname() returns pointer to static thread-unsafe storage. Use getaddrinfo().",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 85. CWE-362: strtok non-reentrant state
        if re.search(r'\bstrtok\s*\(', body):
            rule = REGISTRY.get_rule("SEC-CON-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="strtok() stores parser position in global static state, leading to race conditions in concurrent code.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 86. CWE-252: inet_addr return value unchecked
        if re.search(r'\binet_addr\s*\(', body) and not re.search(r'INADDR_NONE', body):
            rule = REGISTRY.get_rule("SEC-NET-011")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="inet_addr() return value is unchecked for INADDR_NONE failure code (-1). Use inet_pton().",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 87. CWE-601: Open redirect via Location header
        if ('Location:' in raw_body or 'Location: ' in raw_body) and '+' in body:
            rule = REGISTRY.get_rule("SEC-NET-012")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="HTTP 302 redirect Location header concatenated with user parameter, allowing open redirection.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 88. CWE-209: Verbose error message leaking internals
        if 'error' in raw_body.lower() and re.search(r'(?:/srv/|/var/|/home/|\.cpp:\d+)', raw_body):
            rule = REGISTRY.get_rule("SEC-INF-003")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Detailed database error response exposes internal server filesystem paths and source lines.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 90. CWE-912: Hidden backdoor username check
        if ('debug_master' in raw_body or 'master_admin' in raw_body or 'backdoor' in raw_body) and '==' in raw_body:
            rule = REGISTRY.get_rule("SEC-AUTH-008")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Hardcoded backdoor account credential ('debug_master') bypasses standard authentication checks.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

    return findings


# -----------------------------------------------------------------------------
# Section F: Logic, UB & Misc Detectors
# -----------------------------------------------------------------------------

def detect_logic_and_misc_structural(ctx: AnalysisContext) -> List[Finding]:
    findings = []

    # 91. CWE-833: Deadlock lock order inversion between lock_guards across functions
    lock_sequences: Dict[str, Tuple[int, List[str]]] = {}
    for fn in ctx.functions:
        guards = list(re.finditer(r'std::lock_guard<[^>]+>\s+\w+\s*\(\s*([a-zA-Z_]\w*)\s*\)', fn.body_masked))
        if len(guards) >= 2:
            order = [g.group(1) for g in guards]
            lock_sequences[fn.name] = (fn.start_line, order)

    # Check for pair with inverted lock order
    fn_names = list(lock_sequences.keys())
    for i in range(len(fn_names)):
        for j in range(i + 1, len(fn_names)):
            f1, (l1, o1) = fn_names[i], lock_sequences[fn_names[i]]
            f2, (l2, o2) = fn_names[j], lock_sequences[fn_names[j]]
            if len(o1) == 2 and len(o2) == 2 and o1[0] == o2[1] and o1[1] == o2[0]:
                rule = REGISTRY.get_rule("SEC-CON-004")
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=l1,
                        description=f"Deadlock hazard: lock acquisition order ({', '.join(o1)}) in '{f1}' is inverted in '{f2}' ({', '.join(o2)}).",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(l1),
                    ))
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=l2,
                        description=f"Deadlock hazard: lock acquisition order ({', '.join(o2)}) in '{f2}' is inverted in '{f1}' ({', '.join(o1)}).",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(l2),
                    ))

    # Also check within the same function if it spawns concurrent threads/lambdas with inverted order
    for fn in ctx.functions:
        if "std::lock(" in fn.body_masked or "scoped_lock" in fn.body_masked:
            continue
        lambda_blocks = re.findall(r'\[.*?\]\s*\([^\)]*\)\s*\{([^}]+)\}', fn.body_masked)
        if len(lambda_blocks) >= 2:
            inner_orders = []
            for b in lambda_blocks:
                g_match = list(re.finditer(r'std::lock_guard<[^>]+>\s+\w+\s*\(\s*([a-zA-Z_]\w*)\s*\)', b))
                if len(g_match) >= 2:
                    inner_orders.append([m.group(1) for m in g_match])
            if len(inner_orders) >= 2:
                for i in range(len(inner_orders)):
                    for j in range(i + 1, len(inner_orders)):
                        o1, o2 = inner_orders[i], inner_orders[j]
                        if len(o1) == 2 and len(o2) == 2 and o1[0] == o2[1] and o1[1] == o2[0]:
                            rule = REGISTRY.get_rule("SEC-CON-004")
                            if rule:
                                findings.append(Finding(
                                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=fn.start_line,
                                    description=f"Deadlock hazard: inverted lock acquisition order ({', '.join(o1)}) vs ({', '.join(o2)}) across concurrent threads in '{fn.name}'.",
                                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(fn.start_line),
                                ))

    # 97. CWE-1108: Mutable global security flag (g_is_admin = true)
    for idx, line in enumerate(ctx.lines_masked, start=1):
        if re.search(r'\b(?:g_)?(?:is_)?(?:admin|authenticated|authorized)\s*=\s*true\b', line):
            rule = REGISTRY.get_rule("SEC-AUTH-009")
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=idx,
                    description="Mutable global authorization flag modified at runtime, allowing unauthorized elevation.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(idx),
                ))

    for fn in ctx.functions:
        body = fn.body_masked
        raw_body = fn.body_raw

        # 92. CWE-674: Uncontrolled recursion without base case
        if re.search(rf'(?<![.\->])\b{re.escape(fn.name)}\s*\(', body) and not re.search(r'\bif\s*\(|\?', body):
            rule = REGISTRY.get_rule("SEC-LOG-004")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description=f"Function '{fn.name}' calls itself recursively without an 'if' terminating base case, causing stack exhaustion.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 93. CWE-369: Division by zero (handled in Layer B: detect_scope_and_guard_analysis)
        # 94. CWE-1335: Shift by uncontrolled count (handled in Layer B: detect_scope_and_guard_analysis)
        # 95. CWE-190: Signed integer overflow (handled in Layer B: detect_scope_and_guard_analysis)

        # 96. CWE-20 / CWE-129: atoi result used as array index
        atoi_m = re.search(r'([a-zA-Z_]\w*)\s*=\s*atoi\s*\(', body)
        if atoi_m:
            idx_var = atoi_m.group(1)
            if re.search(rf'\[\s*{re.escape(idx_var)}\s*\]', body):
                rule = REGISTRY.get_rule("SEC-INP-006")
                ln = fn.start_line + body[:atoi_m.start()].count('\n')
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"Integer '{idx_var}' parsed via atoi() is used as array index without range check.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 98. CWE-14: Dead-store elimination on cryptographic secret memset
        memset_m = re.search(r'memset\s*\(\s*([a-zA-Z_]\w*)\s*,\s*0,\s*sizeof\s*\(?\s*([a-zA-Z_]\w*)\s*\)?\s*\)', body)
        if memset_m:
            var1, var2 = memset_m.group(1), memset_m.group(2)
            if var1 == var2:
                rule = REGISTRY.get_rule("SEC-CRY-011")
                ln = fn.start_line
                if rule:
                    findings.append(Finding(
                        rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                        description=f"memset() clearing sensitive buffer '{var1}' right before function exit is vulnerable to dead store elimination.",
                        mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                    ))

        # 99. CWE-562: Returning pointer to static local buffer
        if re.search(r'static\s+char\s+([a-zA-Z_]\w*)\s*\[\s*\d+\s*\][^;]*;\s*[^}]*\breturn\s+\1\s*;', body):
            rule = REGISTRY.get_rule("SEC-CON-005")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Function returns pointer to shared static buffer, causing race conditions in multi-threaded environments.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

        # 100. CWE-657: Security decision made on client-controlled cookie string
        if re.search(r'\.find\s*\(\s*"role=admin"\s*\)', raw_body):
            rule = REGISTRY.get_rule("SEC-AUTH-010")
            ln = fn.start_line
            if rule:
                findings.append(Finding(
                    rule_id=rule.rule_id, title=rule.title, severity=rule.severity, line=ln,
                    description="Security/authorization decision based on client-controlled cookie substring 'role=admin'.",
                    mitigation=rule.mitigation, evidence=ctx.get_raw_line(ln),
                ))

    return findings


# =============================================================================
# REGISTER ALL RULES
# =============================================================================

def _init_registry():
    rules = [
        # Section A: Memory Safety (1-25)
        SecurityRule("SEC-BUF-001", "Prohibited gets() Buffer Overflow", "CWE-242", "critical", "Buffer & Memory Safety",
                     "gets() provides no mechanism to restrict input length, presenting a severe buffer overflow risk.",
                     "Replace with std::getline(std::cin, str) or fgets().", "High", ("CWE-120",)),
        SecurityRule("SEC-BUF-002", "strcpy() Buffer Overflow", "CWE-120", "high", "Buffer & Memory Safety",
                     "strcpy() copies memory without destination bounds verification.",
                     "Use std::string or bounded strncpy()/snprintf().", "High", ("CWE-121", "CWE-119")),
        SecurityRule("SEC-BUF-003", "strcat() Buffer Overflow", "CWE-120", "high", "Buffer & Memory Safety",
                     "strcat() concatenates strings without destination buffer boundary verification.",
                     "Use std::string += or strncat().", "High", ("CWE-121", "CWE-119")),
        SecurityRule("SEC-BUF-004", "sprintf() Buffer Overflow", "CWE-120", "high", "Buffer & Memory Safety",
                     "sprintf() writes formatted output without boundary enforcement.",
                     "Use snprintf() or std::ostringstream.", "High", ("CWE-121", "CWE-119")),
        SecurityRule("SEC-INP-001", "Unbounded scanf('%s') Input", "CWE-120", "high", "Input Validation",
                     "scanf() with '%s' format specifier extracts input without a maximum field width limit.",
                     "Specify field width, e.g. scanf('%63s', buf), or use std::cin >> std::string.", "High", ("CWE-121",)),
        SecurityRule("SEC-INP-002", "Unbounded cin >> char[] Input", "CWE-120", "high", "Input Validation",
                     "Direct extraction 'cin >> buf' into raw fixed-size char array without std::setw() risks overflow.",
                     "Use std::cin >> std::setw(sizeof(buf)) buf; or std::string.", "High", ("CWE-120",)),
        SecurityRule("SEC-MEM-005", "Off-by-One Array Boundary Access", "CWE-193", "high", "Buffer & Memory Safety",
                     "Loop condition '<=' with array size reads or writes one element beyond allocated buffer.",
                     "Use '<' strictly with array size, or use range-based for loops.", "High", ("CWE-125", "CWE-119")),
        SecurityRule("SEC-MEM-006", "Heap Buffer Overflow in memcpy", "CWE-122", "critical", "Buffer & Memory Safety",
                     "memcpy length is attacker-controlled and can exceed fixed-size heap allocation.",
                     "Verify transfer size against allocated buffer capacity before memcpy.", "High", ("CWE-119", "CWE-120")),
        SecurityRule("SEC-MEM-007", "Use-After-Free Memory Access", "CWE-416", "critical", "Buffer & Memory Safety",
                     "Pointer is dereferenced after memory was deallocated by free().",
                     "Set pointer to nullptr immediately after free, or use std::unique_ptr / std::shared_ptr.", "High"),
        SecurityRule("SEC-MEM-008", "Double-Free Memory Corruption", "CWE-415", "critical", "Buffer & Memory Safety",
                     "Memory block is freed multiple times, corrupting allocator state.",
                     "Avoid manual memory management; use RAII smart pointers.", "High"),
        SecurityRule("SEC-MEM-009", "Unmanaged Heap Allocation (Memory Leak)", "CWE-401", "medium", "Buffer & Memory Safety",
                     "new allocation discarded without assignment to an owner or deallocation.",
                     "Use std::make_unique or std::make_shared.", "High"),
        SecurityRule("SEC-MEM-010", "Unchecked Null Pointer Dereference", "CWE-476", "high", "Buffer & Memory Safety",
                     "Pointer returned by lookup function dereferenced without null check.",
                     "Check if pointer is non-null before dereferencing.", "High"),
        SecurityRule("SEC-MEM-011", "Return of Uninitialized Local Variable", "CWE-457", "high", "Buffer & Memory Safety",
                     "Uninitialized local variable returned, leaking indeterminate stack contents.",
                     "Initialize all local variables upon declaration.", "High"),
        SecurityRule("SEC-MEM-012", "Return of Pointer to Stack Variable", "CWE-562", "critical", "Buffer & Memory Safety",
                     "Function returns pointer or address to stack-allocated local array.",
                     "Allocate buffer dynamically or return container by value.", "High"),
        SecurityRule("SEC-MEM-013", "Integer Overflow in Allocation Size", "CWE-190", "high", "Buffer & Memory Safety",
                     "Multiplication in malloc argument can overflow integer bounds.",
                     "Check multiplication against SIZE_MAX or use std::vector with size.", "High"),
        SecurityRule("SEC-MEM-014", "Signed to Unsigned Conversion in Memory Transfer", "CWE-195", "high", "Buffer & Memory Safety",
                     "Signed integer cast to size_t wraps negative values to enormous sizes in memcpy.",
                     "Verify that signed lengths are non-negative before conversion.", "High"),
        SecurityRule("SEC-MEM-015", "Negative or Unchecked Array Index Access", "CWE-129", "high", "Buffer & Memory Safety",
                     "Array indexed with parameter without verifying lower and upper boundaries.",
                     "Validate 0 <= index < size before accessing array.", "High"),
        SecurityRule("SEC-MEM-016", "Out-of-Bounds Buffer Read in Loop", "CWE-125", "high", "Buffer & Memory Safety",
                     "Loop indexing arr[i] with i <= n reads beyond buffer bounds.",
                     "Ensure loop termination condition is i < n.", "High"),
        SecurityRule("SEC-FMT-001", "Uncontrolled Format String in printf", "CWE-134", "high", "Format String",
                     "Format function called with non-literal format argument.",
                     "Always supply static format string literal, e.g. printf(\"%s\", var).", "High"),
        SecurityRule("SEC-MEM-018", "Mismatched Array new[] and Scalar delete", "CWE-762", "high", "Buffer & Memory Safety",
                     "Array allocated with new[] must be deallocated with delete[].",
                     "Use delete[] for array allocations, or prefer std::vector.", "High"),
        SecurityRule("SEC-MEM-019", "Dangling Reference to Local Temporary", "CWE-416", "high", "Buffer & Memory Safety",
                     "Function returns reference to stack-allocated temporary.",
                     "Return by value instead of by reference.", "High"),
        SecurityRule("SEC-MEM-020", "Iterator Invalidation during Container Modification", "CWE-416", "high", "Buffer & Memory Safety",
                     "Modifying container inside loop invalidates active iterators.",
                     "Use return value of erase(), index-based iteration, or std::erase_if.", "High"),
        SecurityRule("SEC-MEM-021", "Unchecked Vector Subscript Access", "CWE-125", "medium", "Buffer & Memory Safety",
                     "Direct vector operator[] does not perform bounds checking.",
                     "Use vector.at(i) or verify index against vector.size().", "Medium"),
        SecurityRule("SEC-MEM-022", "Missing Null-Terminator in strncpy", "CWE-170", "high", "Buffer & Memory Safety",
                     "strncpy does not null-terminate destination buffer if source length equals size.",
                     "Explicitly set buf[sizeof(buf)-1] = '\\0' or use std::string.", "High"),
        SecurityRule("SEC-BUF-005", "alloca() Stack Exhaustion Risk", "CWE-770", "high", "Buffer & Memory Safety",
                     "alloca() allocates stack memory without overflow verification.",
                     "Use standard heap allocation or std::vector.", "High"),
        SecurityRule("SEC-MEM-024", "Variable Length Array (VLA) Sized by Parameter", "CWE-1285", "high", "Buffer & Memory Safety",
                     "VLA sized by runtime parameter risks stack exhaustion crashes.",
                     "Use std::vector or std::array with compile-time constant bounds.", "High", ("CWE-770", "CWE-120")),
        SecurityRule("SEC-MEM-025", "Integer Truncation before Allocation", "CWE-197", "high", "Buffer & Memory Safety",
                     "Narrow integer truncation before malloc allocates undersized buffer.",
                     "Use size_t consistently for buffer lengths.", "High"),

        # Section B: Injection & Output Handling (26-40)
        SecurityRule("SEC-CMD-001", "system() Command Injection", "CWE-78", "critical", "Command Execution",
                     "Direct invocation of system() executes arbitrary shell commands.",
                     "Avoid system shells. Use native library APIs or isolated execution with arguments.", "High"),
        SecurityRule("SEC-CMD-002", "popen() Command Injection", "CWE-78", "critical", "Command Execution",
                     "popen() spawns a shell process to execute commands, exposing command injection.",
                     "Replace popen() with controlled inter-process communication.", "High"),
        SecurityRule("SEC-INJ-001", "SQL Injection via Query Concatenation", "CWE-89", "critical", "Command Execution",
                     "SQL query constructed using unescaped string concatenation.",
                     "Use parameterized prepared statements.", "High"),
        SecurityRule("SEC-PATH-004", "Path Traversal via Dynamic Path Concatenation", "CWE-22", "high", "Path Traversal & File Access",
                     "File opened using dynamic path concatenation without validation.",
                     "Canonicalize path and verify it remains within expected root directory.", "High"),
        SecurityRule("SEC-CMD-003", "Low-Level Process Replacement via exec*", "CWE-78", "critical", "Command Execution",
                     "Direct unverified process execution via exec* family can allow binary replacement.",
                     "Constrain executable paths using absolute paths and fixed allowlists.", "High"),
        SecurityRule("SEC-INJ-002", "LDAP Filter Injection", "CWE-90", "high", "Input Validation",
                     "LDAP filter built from unescaped user string concatenation.",
                     "Escape LDAP special characters according to RFC 4515.", "High"),
        SecurityRule("SEC-INJ-003", "Reflected Cross-Site Scripting (XSS)", "CWE-79", "high", "Input Validation",
                     "Unsanitized parameter concatenated into HTML output.",
                     "HTML-encode all dynamic values before rendering into HTML context.", "High"),
        SecurityRule("SEC-INJ-004", "Log Injection / Carriage Return Injection", "CWE-117", "medium", "Information Disclosure",
                     "User string written to log stream without sanitizing newline characters.",
                     "Sanitize CRLF and control characters before writing to log streams.", "Medium"),
        SecurityRule("SEC-NET-001", "HTTP Response Splitting / CRLF Injection", "CWE-113", "high", "Network",
                     "User string concatenated into HTTP headers containing CRLF sequences.",
                     "Validate that header values do not contain carriage return or line feed bytes.", "High"),
        SecurityRule("SEC-FMT-002", "Format String Vulnerability in syslog", "CWE-134", "high", "Format String",
                     "syslog() called with non-literal format argument.",
                     "Supply literal format string, e.g. syslog(priority, \"%s\", msg).", "High"),
        SecurityRule("SEC-INJ-005", "XML External Entity (XXE) Injection", "CWE-611", "high", "Input Validation",
                     "XML parser permits external entity resolution (<!ENTITY).",
                     "Disable DTD processing and external entity resolution in XML parser configuration.", "Medium"),
        SecurityRule("SEC-LOG-001", "Catastrophic Regex Backtracking", "CWE-1333", "medium", "Logic & Undefined Behavior",
                     "Recursive matcher with nested quantifiers exhibits exponential complexity.",
                     "Use linear-time DFA-based matching engines (e.g. RE2).", "High", ("CWE-400",)),
        SecurityRule("SEC-MEM-026", "Unsafe Struct Deserialization with Function Pointers", "CWE-502", "critical", "Buffer & Memory Safety",
                     "Raw memory deserialized into struct containing callable function pointers.",
                     "Do not serialize function pointers or raw executable addresses.", "High"),
        SecurityRule("SEC-FMT-003", "Template / Format String Injection in snprintf", "CWE-1336", "high", "Format String",
                     "snprintf() called with user-supplied format string.",
                     "Always use static string literals for snprintf format argument.", "High", ("CWE-134",)),

        # Section C: Crypto & Authentication (41-60)
        SecurityRule("SEC-AUTH-001", "Hardcoded Plaintext Password Comparison", "CWE-798", "critical", "Authentication & Secrets",
                     "Direct string equality check against hardcoded credential literal.",
                     "Verify salted cryptographic password hashes, never compare plaintext credentials.", "High"),
        SecurityRule("SEC-AUTH-002", "Hardcoded API Token / Secret Literal", "CWE-798", "critical", "Authentication & Secrets",
                     "High-entropy API token literal embedded in source text.",
                     "Store secrets in environment variables or secure key vaults.", "High"),
        SecurityRule("SEC-CRY-001", "Cryptographically Broken Hash (MD5)", "CWE-328", "medium", "Cryptography",
                     "MD5 hash algorithm suffers from collision and preimage vulnerabilities.",
                     "Use SHA-256, SHA-3, or Argon2/bcrypt for passwords.", "High"),
        SecurityRule("SEC-CRY-002", "Insecure Pseudo-Random Number Generator", "CWE-338", "medium", "Cryptography",
                     "rand() is statistically predictable and unsuitable for security tokens.",
                     "Use cryptographically secure RNGs (std::random_device, BCryptGenRandom, /dev/urandom).", "High"),
        SecurityRule("SEC-CRY-003", "Predictable PRNG Seed (time)", "CWE-337", "medium", "Cryptography",
                     "PRNG seeded with current timestamp time(), allowing attackers to predict random values.",
                     "Seed PRNG with hardware cryptographic entropy.", "High"),
        SecurityRule("SEC-CRY-004", "Broken Custom Encryption (XOR Cipher)", "CWE-327", "high", "Cryptography",
                     "Byte-wise XOR transform provides zero cryptographic confidentiality.",
                     "Use standard authenticated encryption (AES-256-GCM or ChaCha20-Poly1305).", "High"),
        SecurityRule("SEC-CRY-005", "Observable Timing Discrepancy in Comparison", "CWE-208", "medium", "Cryptography",
                     "Non-constant-time comparison strcmp() leaks secret data via timing side channels.",
                     "Use constant-time memory comparison functions (e.g. CRYPTO_memcmp).", "Medium"),
        SecurityRule("SEC-AUTH-003", "Plaintext Password Storage to File", "CWE-256", "high", "Authentication & Secrets",
                     "User password written to file in unencrypted plaintext.",
                     "Hash passwords with slow salted algorithms before persistence.", "High"),
        SecurityRule("SEC-CRY-006", "Password Hash without Salt", "CWE-759", "high", "Cryptography",
                     "Password hashed without unique salt, enabling rainbow table lookups.",
                     "Use salted password hashing algorithms (Argon2id, bcrypt).", "High"),
        SecurityRule("SEC-CRY-007", "Static or Zero Initialization Vector (IV)", "CWE-329", "high", "Cryptography",
                     "Hardcoded or zero-filled IV reused across encryption calls.",
                     "Generate unique, cryptographically random IVs for every encryption operation.", "High"),
        SecurityRule("SEC-FIL-001", "Predictable Temporary File in /tmp", "CWE-377", "medium", "File & Process",
                     "Hardcoded path in shared /tmp directory vulnerable to symlink and hijack attacks.",
                     "Use mkstemp() or secure temporary directory generation.", "High"),
        SecurityRule("SEC-CRY-008", "Inadequate Cryptographic Key Length", "CWE-326", "high", "Cryptography",
                     "Cryptographic key length is below minimum security thresholds (< 2048-bit RSA, < 128-bit symmetric).",
                     "Use at least 2048-bit RSA or 256-bit elliptic curves.", "High"),
        SecurityRule("SEC-NET-002", "Disabled TLS Certificate Verification", "CWE-295", "critical", "Cryptography",
                     "Peer or hostname certificate verification disabled in TLS configuration.",
                     "Enable strict TLS peer and hostname certificate verification.", "High"),
        SecurityRule("SEC-AUTH-004", "Default Hardcoded Credentials", "CWE-1392", "high", "Authentication & Secrets",
                     "Default administrative credentials embedded in source code.",
                     "Require unique initial configuration; avoid shipping default credentials.", "High", ("CWE-798",)),
        SecurityRule("SEC-INF-001", "Password Logged to Output Stream", "CWE-532", "high", "Information Disclosure",
                     "Sensitive credential variable printed into log output stream.",
                     "Redact all authentication credentials before logging.", "High"),
        SecurityRule("SEC-AUTH-005", "Unauthenticated Administrative Function Execution", "CWE-306", "critical", "Authentication & Secrets",
                     "Administrative command execution callable without authentication checks.",
                     "Enforce authentication and role-based access control before executing commands.", "High", ("CWE-78",)),
        SecurityRule("SEC-AUTH-006", "Predictable Sequential Session Identifier", "CWE-330", "medium", "Authentication & Secrets",
                     "Sequential session/token generation produces easily guessed identifiers.",
                     "Generate cryptographically random 128-bit or 256-bit session identifiers.", "High"),
        SecurityRule("SEC-LOG-002", "Pointer Equality Comparison on C-Strings", "CWE-697", "medium", "Logic & Undefined Behavior",
                     "C-strings compared using pointer equality '==' instead of content comparison.",
                     "Compare string contents using strcmp() == 0 or std::string_view.", "High", ("CWE-595",)),
        SecurityRule("SEC-CRY-009", "Hardcoded Symmetric Cryptographic Key", "CWE-321", "high", "Cryptography",
                     "Hardcoded symmetric key literal found in source text.",
                     "Store cryptographic keys in hardware security modules or secure key management vaults.", "High", ("CWE-798",)),
        SecurityRule("SEC-CRY-010", "Encoding Used in Place of Encryption", "CWE-261", "medium", "Cryptography",
                     "Base64 table lookup used as protection. Encoding does not provide confidentiality.",
                     "Use approved cryptographic encryption standards.", "Medium", ("CWE-327",)),

        # Section D: Files, Processes & Concurrency (61-75)
        SecurityRule("SEC-FIL-002", "TOCTOU Race Condition in File Check", "CWE-367", "high", "File & Process",
                     "access() check followed by open() creates a time-of-check to time-of-use race.",
                     "Open file directly with appropriate flags (e.g. O_EXCL, O_CREAT) and handle open errors.", "High"),
        SecurityRule("SEC-FIL-003", "World-Writable File Creation Permissions", "CWE-732", "high", "File & Process",
                     "File created with world-writable permission mode 0777.",
                     "Restrict permissions to owner only (e.g. 0600 or 0700).", "High"),
        SecurityRule("SEC-FIL-004", "Insecure File Creation in /tmp without O_EXCL", "CWE-59", "high", "File & Process",
                     "open() in shared directory /tmp without O_EXCL risks symlink following.",
                     "Specify O_CREAT | O_EXCL or use mkstemp().", "High"),
        SecurityRule("SEC-FIL-005", "Permissive umask(0) Configuration", "CWE-276", "medium", "File & Process",
                     "umask(0) leaves created files world-writable.",
                     "Set restrictive umask such as umask(0077) or umask(0027).", "High"),
        SecurityRule("SEC-FIL-006", "External Control of File Path in fopen", "CWE-73", "high", "File & Process",
                     "File path directly taken from parameter without directory validation.",
                     "Sanitize and validate paths against an approved base directory.", "High"),
        SecurityRule("SEC-LOG-003", "Ignored Return Value in Security/IO Operations", "CWE-252", "medium", "Logic & Undefined Behavior",
                     "Return value of read() or write() is discarded without checking for errors.",
                     "Check return values of I/O functions and handle errors or short transfers.", "High"),
        SecurityRule("SEC-FIL-007", "File Descriptor Resource Leak in Loop", "CWE-775", "high", "File & Process",
                     "Files opened repeatedly inside a loop without close(), leaking descriptors.",
                     "Ensure every open file descriptor is closed in all paths, or use RAII file wrappers.", "High", ("CWE-400",)),
        SecurityRule("SEC-CON-001", "Data Race on Shared Variable across Threads", "CWE-362", "high", "Concurrency",
                     "Shared global modified across concurrent threads without mutex synchronization.",
                     "Synchronize access using std::mutex or use std::atomic.", "High"),
        SecurityRule("SEC-CON-002", "Async-Signal-Unsafe Functions in Signal Handler", "CWE-479", "high", "Concurrency",
                     "Signal handler calls non-reentrant functions (printf, malloc, free).",
                     "Only invoke async-signal-safe functions (write, _exit) or set volatile sig_atomic_t flags.", "High"),
        SecurityRule("SEC-FIL-008", "Execution with Undropped Root Privileges", "CWE-250", "high", "File & Process",
                     "Root privileges gained via setuid(0) are never dropped before command execution.",
                     "Drop privileges permanently or temporarily before executing external commands.", "High", ("CWE-78",)),
        SecurityRule("SEC-FIL-009", "chroot() without chdir('/')", "CWE-243", "high", "File & Process",
                     "chroot() invoked without changing working directory to root.",
                     "Call chdir(\"/\") immediately after successful chroot().", "High"),
        SecurityRule("SEC-FIL-010", "Uncontrolled File Consumption into Memory", "CWE-400", "medium", "File & Process",
                     "Byte-by-byte file reading loop accumulates stream into memory without a maximum size cap.",
                     "Enforce strict maximum transfer limits on memory buffers.", "High"),
        SecurityRule("SEC-PATH-005", "Zip-Slip Archive Path Traversal", "CWE-23", "high", "Path Traversal & File Access",
                     "Archive entry extraction path constructed without validating against '../'.",
                     "Verify canonical extraction path resides within target destination directory.", "High", ("CWE-22",)),
        SecurityRule("SEC-FIL-011", "Insecure Temporary File Creation via tmpnam()", "CWE-377", "high", "File & Process",
                     "tmpnam() creates a race condition between name generation and file open.",
                     "Use mkstemp() or std::filesystem::temp_directory_path().", "High"),
        SecurityRule("SEC-INF-002", "World-Readable Security Log Permissions", "CWE-532", "medium", "Information Disclosure",
                     "Security audit log opened with world-readable permissions (0644).",
                     "Restrict security log file permissions to 0600.", "High", ("CWE-732",)),

        # Section E: Network Security (76-90)
        SecurityRule("SEC-NET-003", "Socket Bound to All Interfaces (INADDR_ANY)", "CWE-1327", "medium", "Network",
                     "Socket bound to INADDR_ANY exposes service on all local and external interfaces.",
                     "Bind to specific local address (e.g. 127.0.0.1) unless external access is required.", "High"),
        SecurityRule("SEC-NET-004", "Missing Socket Receive Timeout (Slowloris)", "CWE-400", "medium", "Network",
                     "Receive loop lacks socket timeouts, allowing slow connections to exhaust threads.",
                     "Set SO_RCVTIMEO with setsockopt() or use non-blocking event loops.", "High"),
        SecurityRule("SEC-NET-005", "Network Socket recv() Buffer Overflow", "CWE-120", "critical", "Buffer & Memory Safety",
                     "recv() requested length exceeds destination buffer size.",
                     "Ensure recv size parameter does not exceed sizeof(buffer).", "High"),
        SecurityRule("SEC-NET-006", "Trusting Client-Supplied Packet Length", "CWE-130", "high", "Network",
                     "Message length read from client used as transfer size without validation.",
                     "Validate all network packet length fields against maximum allowed packet size.", "High", ("CWE-120",)),
        SecurityRule("SEC-NET-007", "Cleartext Transmission of Sensitive Credentials", "CWE-319", "high", "Network",
                     "User password variable transmitted over unencrypted socket stream.",
                     "Use TLS/SSL encryption (OpenSSL, TLS sockets) for sensitive network traffic.", "High"),
        SecurityRule("SEC-NET-008", "Server-Side Request Forgery via curl", "CWE-918", "critical", "Network",
                     "Unvalidated user URL fed directly into curl command.",
                     "Validate URLs against strict domain allowlists and block internal IP addresses.", "High", ("CWE-78",)),
        SecurityRule("SEC-NET-009", "Unbounded Container Sizing from Parameter", "CWE-770", "medium", "Buffer & Memory Safety",
                     "Container sized directly by external parameter without maximum capacity check.",
                     "Enforce reasonable upper limit before allocating container elements.", "High", ("CWE-400",)),
        SecurityRule("SEC-AUTH-007", "Authentication Function Lacks Rate Limiting", "CWE-307", "medium", "Authentication & Secrets",
                     "Authentication function has no attempt tracking, lockout, or rate limiting.",
                     "Enforce exponential backoff or account lockout after repeated failed attempts.", "Medium"),
        SecurityRule("SEC-NET-010", "Obsolete Non-Thread-Safe Hostname Resolver", "CWE-362", "medium", "Network",
                     "gethostbyname() returns pointer to static non-reentrant memory.",
                     "Replace with reentrant getaddrinfo().", "High", ("CWE-676",)),
        SecurityRule("SEC-CON-003", "Non-Reentrant String Tokenizer (strtok)", "CWE-362", "medium", "Concurrency",
                     "strtok() relies on shared static state, causing race conditions in multi-threaded code.",
                     "Use strtok_r() or std::string_view tokenization.", "High", ("CWE-676",)),
        SecurityRule("SEC-NET-011", "Unchecked Network Address Return Value", "CWE-252", "medium", "Network",
                     "inet_addr() return value unchecked for INADDR_NONE failure code.",
                     "Verify inet_addr() != INADDR_NONE or use inet_pton().", "High"),
        SecurityRule("SEC-NET-012", "Open URL Redirection via Location Header", "CWE-601", "medium", "Network",
                     "HTTP 302 redirect Location header concatenated with user parameter.",
                     "Validate destination redirect URLs against an approved allowlist.", "High"),
        SecurityRule("SEC-INF-003", "Internal Error Message Information Disclosure", "CWE-209", "medium", "Information Disclosure",
                     "Error responses expose internal server filesystem paths and query details.",
                     "Log detailed errors internally and return sanitized generic error messages.", "High"),
        SecurityRule("SEC-NET-013", "Permissive CORS Wildcard with Credentials", "CWE-942", "high", "Network",
                     "Access-Control-Allow-Origin: * paired with Access-Control-Allow-Credentials: true.",
                     "Specify explicit allowed origins rather than wildcard '*' when credentials are permitted.", "High"),
        SecurityRule("SEC-AUTH-008", "Hardcoded Backdoor Account Access", "CWE-912", "critical", "Authentication & Secrets",
                     "Hardcoded administrative backdoor username ('debug_master') bypasses authentication.",
                     "Remove all hidden administrative backdoor logic.", "High"),

        # Section F: Logic, UB & Misc (91-100)
        SecurityRule("SEC-CON-004", "Deadlock Hazard from Inverted Lock Order", "CWE-833", "high", "Concurrency",
                     "Mutex lock acquisition order is inverted between concurrent functions.",
                     "Acquire multiple mutexes simultaneously using std::lock() or std::scoped_lock.", "High"),
        SecurityRule("SEC-LOG-004", "Uncontrolled Infinite Recursion", "CWE-674", "high", "Logic & Undefined Behavior",
                     "Function calls itself recursively without an 'if' base condition, exhausting the call stack.",
                     "Ensure every recursive function contains a guaranteed terminating base case.", "High"),
        SecurityRule("SEC-LOG-005", "Division by Unchecked Denominator", "CWE-369", "high", "Logic & Undefined Behavior",
                     "Integer division performed on parameter without checking if divisor is zero.",
                     "Validate that denominator is non-zero before performing division.", "High"),
        SecurityRule("SEC-LOG-006", "Bitwise Shift Count Exceeds Integer Width", "CWE-1335", "medium", "Logic & Undefined Behavior",
                     "Bitwise shift '<< n' produces undefined behavior if n >= bit width or negative.",
                     "Validate shift count is in range [0, sizeof(type)*8 - 1].", "High"),
        SecurityRule("SEC-LOG-007", "Signed Integer Arithmetic Overflow", "CWE-190", "low", "Logic & Undefined Behavior",
                     "Signed integer addition produces undefined behavior on overflow.",
                     "Check for arithmetic overflow or use compiler intrinsics (__builtin_add_overflow).", "Medium"),
        SecurityRule("SEC-INP-006", "Unchecked atoi() Result Used as Array Subscript", "CWE-20", "high", "Input Validation",
                     "atoi() result used as array subscript without bounds validation.",
                     "Use strtol() with error checking and validate bounds before indexing.", "High", ("CWE-129",)),
        SecurityRule("SEC-AUTH-009", "Mutable Global Authorization Security Flag", "CWE-1108", "high", "Authentication & Secrets",
                     "Security/admin state stored in mutable global variable modified directly.",
                     "Encapsulate authorization state in session context objects.", "Medium"),
        SecurityRule("SEC-CRY-011", "Dead-Store Elimination on Cryptographic Key", "CWE-14", "high", "Cryptography",
                     "memset() clearing sensitive key right before function return is optimized away by compilers.",
                     "Use secure zeroing functions (explicit_bzero, SecureZeroMemory).", "High"),
        SecurityRule("SEC-CON-005", "Return of Pointer to Static Local Buffer", "CWE-562", "medium", "Concurrency",
                     "Function returns pointer to shared static local buffer, causing multi-thread races.",
                     "Return by value or take a caller-allocated output buffer.", "High", ("CWE-676",)),
        SecurityRule("SEC-AUTH-010", "Security Decision Based on Client-Controlled Cookie", "CWE-657", "high", "Authentication & Secrets",
                     "Security decision trusts client-controlled cookie string 'role=admin'.",
                     "Use signed session tokens (HMAC/JWT) validated server-side.", "Medium", ("CWE-807",)),

        # Legacy / Compatibility Rules
        SecurityRule("SEC-CMD-004", "Windows Process / Shell Execution", "CWE-78", "critical", "Command Execution",
                     "Direct execution of Windows executables via process APIs.",
                     "Use restricted process spawning with absolute paths.", "High"),
        SecurityRule("SEC-PATH-001", "Relative Path Traversal (../)", "CWE-22", "high", "Path Traversal & File Access",
                     "Relative path traversal sequence '../' in path specification.",
                     "Canonicalize and sanitize paths.", "High"),
        SecurityRule("SEC-PATH-002", "Sensitive System File Access", "CWE-200", "high", "Path Traversal & File Access",
                     "Reference to sensitive operating system security file.",
                     "Do not access OS-level credential files directly.", "High"),
        SecurityRule("SEC-PATH-003", "Hardcoded System32 Path Access", "CWE-22", "medium", "Path Traversal & File Access",
                     "Direct reference to Windows System32 directory.",
                     "Use environment variables or standard system APIs.", "High"),
        SecurityRule("SEC-CRED-001", "Hardcoded Credential / Secret in Source", "CWE-798", "medium", "Authentication & Secrets",
                     "Hardcoded authentication credential or secret detected in source text.",
                     "Store credentials in environment variables or a dedicated secret vault.", "High"),
        SecurityRule("SEC-SIG-001", "Signal Handler Calls Async-Signal-Unsafe Function", "CWE-479", "high", "Concurrency & Asynchronous Safety",
                     "Invoking non-reentrant or async-signal-unsafe functions inside a signal handler leads to deadlocks or memory corruption.",
                     "Only invoke async-signal-safe functions (write, _exit) or set a volatile sig_atomic_t flag.", "High"),
    ]

    for r in rules:
        REGISTRY.register(r)

    REGISTRY.add_detector(detect_declarative_sinks)
    REGISTRY.add_detector(detect_scope_and_guard_analysis)
    REGISTRY.add_detector(detect_taint_dataflow_analysis)
    REGISTRY.add_detector(detect_cfg_resource_lifecycles)
    REGISTRY.add_detector(detect_concurrency_analysis)
    REGISTRY.add_detector(detect_banned_string_apis)
    REGISTRY.add_detector(detect_memory_safety_structural)
    REGISTRY.add_detector(detect_injection_and_output_structural)
    REGISTRY.add_detector(detect_crypto_and_auth_structural)
    REGISTRY.add_detector(detect_files_and_concurrency_structural)
    REGISTRY.add_detector(detect_network_structural)
    REGISTRY.add_detector(detect_logic_and_misc_structural)


_init_registry()
