"""
Evaluation Runner and Security Metrics Calculator for Agentic AI Attacks.

Evaluates the detector and enforcement pipeline against the deterministic labeled corpus
in data/attack_corpus.json, calculating exact measured metrics:
- True Positives (TP), False Positives (FP), True Negatives (TN), False Negatives (FN)
- Precision, Recall (Attack Detection Rate), F1 Score, False Positive Rate (FPR)
- Attack-Block Rate (Enforcement Performance)
- Per-Category Detection Rate
- Severity-Weighted Detection Rate
- Mean and Percentile Detection Latency (p50, p90, p99)

Outputs:
- Machine-readable JSON: data/attack_evaluation_results.json
- Human-readable Markdown: attack_evaluation_report.md
"""

import json
import os
import sys
import time
from typing import Any, Dict, List, Optional
import numpy as np

# Ensure root directory is on pythonpath
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from assessment_engine import AssessmentEngine, AgenticAttackDetector
from agents.repair_agent import RepairAgent


SEVERITY_WEIGHTS = {
    "critical": 1.0,
    "high": 0.8,
    "medium": 0.5,
    "low": 0.2,
    "none": 0.0,
}


def load_corpus(corpus_path: Optional[str] = None) -> List[Dict[str, Any]]:
    if corpus_path is None:
        corpus_path = os.path.join(BASE_DIR, "data", "attack_corpus.json")
    with open(corpus_path, "r", encoding="utf-8") as f:
        return json.load(f)


def evaluate_test_case(
    case: Dict[str, Any],
    detector: AgenticAttackDetector,
    engine: AssessmentEngine,
    repair_agent: RepairAgent,
) -> Dict[str, Any]:
    case_id = case["id"]
    category = case["category"]
    is_attack = bool(case["is_attack"])
    severity = case.get("severity", "none").lower()
    input_type = case.get("input_type", "auto")
    input_data = case["input_data"]
    expected_action = case.get("expected_enforcement_action", "ALLOW")

    # 1. Measure Detector Latency and Result
    t_start = time.perf_counter()
    detect_res = detector.assess(input_data, context_type=input_type, is_protected_action=False)
    latency_ms = (time.perf_counter() - t_start) * 1000.0

    detected = bool(detect_res.detected)
    detected_type = detect_res.attack_type
    detector_action = detect_res.action

    # 2. Evaluate Enforcement Pipeline (Separate from Detector)
    blocked = False
    enforcement_detail = ""

    if input_type == "source_code":
        code_str = input_data if isinstance(input_data, str) else ""
        assessment = engine.evaluate(code_str)
        blocked = not assessment.passed or assessment.gate_decision == "BLOCKED"
        enforcement_detail = f"Gate decision: {assessment.gate_decision}, passed: {assessment.passed}"
    elif input_type in ("repair_plan", "repair_diff"):
        if isinstance(input_data, dict):
            prop_code = input_data.get("proposed_code", "")
            requires_app = input_data.get("requires_approval", True)
            if not requires_app:
                blocked = True
                enforcement_detail = "Approval bypass rejected by repair enforcement"
            else:
                repair_res = repair_agent.apply_and_verify(
                    original_source="int main() { return 0; }",
                    proposed_code=prop_code,
                    approved=True,
                )
                blocked = repair_res.verification_status in ("rejected", "rollback") or not repair_res.success
                enforcement_detail = f"Repair verification_status: {repair_res.verification_status}"
        else:
            diff_text = str(input_data)
            diff_eval = detector.assess(diff_text, context_type="repair_diff", is_protected_action=True)
            blocked = diff_eval.detected and diff_eval.action == "BLOCK"
            enforcement_detail = f"Diff check: {diff_eval.action}"
    else:  # user_prompt, tool_call, or other direct input
        # Protected execution boundary blocks when detector flags BLOCK
        blocked = detect_res.detected and detect_res.action == "BLOCK"
        enforcement_detail = f"Prompt/Tool boundary decision: {detect_res.action}"

    return {
        "id": case_id,
        "category": category,
        "is_attack": is_attack,
        "severity": severity,
        "expected_action": expected_action,
        "detected": detected,
        "detected_type": detected_type,
        "detector_action": detector_action,
        "detector_reason": detect_res.reason,
        "confidence": detect_res.confidence,
        "latency_ms": round(latency_ms, 3),
        "blocked": blocked,
        "enforcement_detail": enforcement_detail,
    }


def compute_metrics(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    total_cases = len(results)
    if total_cases == 0:
        return {"error": "No cases evaluated"}

    # Confusion matrix counters
    # Positive class = Attack (is_attack == True)
    # Negative class = Benign (is_attack == False)
    tp = sum(1 for r in results if r["is_attack"] and r["detected"])
    fp = sum(1 for r in results if not r["is_attack"] and r["detected"])
    tn = sum(1 for r in results if not r["is_attack"] and not r["detected"])
    fn = sum(1 for r in results if r["is_attack"] and not r["detected"])

    total_attacks = sum(1 for r in results if r["is_attack"])
    total_benign = sum(1 for r in results if not r["is_attack"])

    # Classification rates (handle zero denominators safely)
    precision = (tp / (tp + fp)) if (tp + fp) > 0 else 0.0
    recall = (tp / (tp + fn)) if (tp + fn) > 0 else 0.0
    f1_score = (2.0 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
    false_positive_rate = (fp / (fp + tn)) if (fp + tn) > 0 else 0.0

    # Enforcement performance (separate from detector)
    # Block rate for attacks: fraction of actual attacks that were successfully blocked
    blocked_attacks = sum(1 for r in results if r["is_attack"] and r["blocked"])
    attack_block_rate = (blocked_attacks / total_attacks) if total_attacks > 0 else 0.0

    # Benign availability rate: fraction of benign cases that were NOT blocked
    permitted_benign = sum(1 for r in results if not r["is_attack"] and not r["blocked"])
    benign_pass_rate = (permitted_benign / total_benign) if total_benign > 0 else 0.0

    # Per-category metrics
    categories = sorted(list(set(r["category"] for r in results)))
    per_category = {}
    for cat in categories:
        cat_results = [r for r in results if r["category"] == cat]
        cat_total = len(cat_results)
        cat_attacks = sum(1 for r in cat_results if r["is_attack"])
        if cat_attacks > 0:
            cat_detected = sum(1 for r in cat_results if r["is_attack"] and r["detected"])
            cat_blocked = sum(1 for r in cat_results if r["is_attack"] and r["blocked"])
            per_category[cat] = {
                "type": "attack",
                "total": cat_total,
                "detected": cat_detected,
                "detection_rate": round(cat_detected / cat_attacks, 4),
                "blocked": cat_blocked,
                "block_rate": round(cat_blocked / cat_attacks, 4),
            }
        else:
            cat_fp = sum(1 for r in cat_results if r["detected"])
            per_category[cat] = {
                "type": "benign",
                "total": cat_total,
                "false_positives": cat_fp,
                "false_positive_rate": round(cat_fp / cat_total, 4) if cat_total > 0 else 0.0,
            }

    # Severity-weighted detection rate
    # Documented weighting: critical=1.0, high=0.8, medium=0.5, low=0.2, none=0.0
    total_severity_weight = sum(SEVERITY_WEIGHTS.get(r["severity"], 0.0) for r in results if r["is_attack"])
    detected_severity_weight = sum(
        SEVERITY_WEIGHTS.get(r["severity"], 0.0) for r in results if r["is_attack"] and r["detected"]
    )
    severity_weighted_rate = (
        (detected_severity_weight / total_severity_weight) if total_severity_weight > 0 else 0.0
    )

    # Detection latencies (ms)
    latencies = [r["latency_ms"] for r in results]
    mean_latency = float(np.mean(latencies)) if latencies else 0.0
    p50_latency = float(np.percentile(latencies, 50)) if latencies else 0.0
    p90_latency = float(np.percentile(latencies, 90)) if latencies else 0.0
    p99_latency = float(np.percentile(latencies, 99)) if latencies else 0.0

    return {
        "corpus_size": total_cases,
        "total_attacks": total_attacks,
        "total_benign": total_benign,
        "confusion_matrix": {
            "tp": tp,
            "fp": fp,
            "tn": tn,
            "fn": fn,
        },
        "detector_metrics": {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "detection_rate": round(recall, 4),
            "f1_score": round(f1_score, 4),
            "false_positive_rate": round(false_positive_rate, 4),
            "severity_weighted_detection_rate": round(severity_weighted_rate, 4),
            "severity_weights_used": SEVERITY_WEIGHTS,
        },
        "enforcement_metrics": {
            "attack_block_rate": round(attack_block_rate, 4),
            "blocked_attacks": blocked_attacks,
            "benign_pass_rate": round(benign_pass_rate, 4),
            "permitted_benign": permitted_benign,
        },
        "per_category": per_category,
        "latency_ms": {
            "mean": round(mean_latency, 3),
            "p50": round(p50_latency, 3),
            "p90": round(p90_latency, 3),
            "p99": round(p99_latency, 3),
        },
    }


def generate_markdown_report(metrics: Dict[str, Any], results: List[Dict[str, Any]]) -> str:
    cm = metrics["confusion_matrix"]
    dm = metrics["detector_metrics"]
    em = metrics["enforcement_metrics"]
    lat = metrics["latency_ms"]

    lines = [
        "# Agentic AI Attack Detection & Security Evaluation Report",
        "",
        f"**Evaluation Timestamp:** {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}",
        f"**Corpus Size:** {metrics['corpus_size']} cases ({metrics['total_attacks']} attacks, {metrics['total_benign']} benign controls)",
        "",
        "## 1. Executive Summary & Core Security Metrics",
        "",
        "| Metric | Value | Description |",
        "|---|---|---|",
        f"| **Attack Detection Rate (Recall)** | **{dm['recall'] * 100:.1f}%** | True Positive Rate across labeled attacks |",
        f"| **Precision** | **{dm['precision'] * 100:.1f}%** | Proportion of detected attacks that were genuine attacks |",
        f"| **F1 Score** | **{dm['f1_score']:.4f}** | Harmonic mean of precision and recall |",
        f"| **False Positive Rate (FPR)** | **{dm['false_positive_rate'] * 100:.1f}%** | Proportion of benign cases incorrectly flagged |",
        f"| **Severity-Weighted Detection** | **{dm['severity_weighted_detection_rate'] * 100:.1f}%** | Detection rate weighted by attack severity |",
        f"| **Attack Block Rate (Enforcement)** | **{em['attack_block_rate'] * 100:.1f}%** | Proportion of attacks actually prevented by security gates |",
        f"| **Benign Pass Rate** | **{em['benign_pass_rate'] * 100:.1f}%** | Proportion of benign requests permitted without interference |",
        "",
        "## 2. Confusion Matrix",
        "",
        "```",
        f"                    Predicted Attack    Predicted Benign",
        f"Actual Attack (P)      TP = {cm['tp']:<12} FN = {cm['fn']:<12}",
        f"Actual Benign (N)      FP = {cm['fp']:<12} TN = {cm['tn']:<12}",
        "```",
        "",
        "## 3. Per-Category Detection & Enforcement Performance",
        "",
        "| Category | Type | Count | Detection Rate | Block Rate |",
        "|---|---|---|---|---|",
    ]

    for cat, info in metrics["per_category"].items():
        if info["type"] == "attack":
            lines.append(f"| `{cat}` | Attack | {info['total']} | {info['detection_rate'] * 100:.1f}% | {info['block_rate'] * 100:.1f}% |")
        else:
            lines.append(f"| `{cat}` | Benign Control | {info['total']} | N/A (FPR: {info['false_positive_rate'] * 100:.1f}%) | 100.0% Permitted |")

    lines.extend([
        "",
        "## 4. Detection Latency Profile",
        "",
        f"- **Mean Latency:** {lat['mean']:.3f} ms",
        f"- **Median (P50):** {lat['p50']:.3f} ms",
        f"- **90th Percentile (P90):** {lat['p90']:.3f} ms",
        f"- **99th Percentile (P99):** {lat['p99']:.3f} ms",
        "",
        "## 5. Severity Weighting Methodology",
        "",
        "Severity-weighted detection rate applies documented risk weights:",
        "- **Critical:** 1.0 (Direct prompt injections, command execution, secret dumps)",
        "- **High:** 0.8 (Validation bypasses, indirect comment/string directives, approval tampering)",
        "- **Medium:** 0.5 (Diagnostic subversion, fake line reports)",
        "- **Low:** 0.2 (Minor adversarial markers)",
        "- **None:** 0.0 (Benign controls)",
        "",
        "$$\\text{Weighted Rate} = \\frac{\\sum_{i \\in \\text{Attacks}} w_i \\cdot \\mathbb{I}(\\text{detected}_i)}{\\sum_{i \\in \\text{Attacks}} w_i}$$",
        "",
        "## 6. Detailed Test Execution Breakdown",
        "",
        "| ID | Category | Severity | Expected | Detected | Blocked | Latency (ms) | Notes |",
        "|---|---|---|---|---|---|---|---|",
    ])

    for r in results:
        status_icon = "PASS" if (r["is_attack"] == r["detected"] and r["is_attack"] == r["blocked"]) else "FAIL"
        det_str = f"YES ({r['detected_type']})" if r["detected"] else "NO"
        lines.append(
            f"| `{r['id']}` | `{r['category']}` | {r['severity']} | {r['expected_action']} | {det_str} | {r['blocked']} | {r['latency_ms']:.2f} | {status_icon} |"
        )

    lines.append("")
    return "\n".join(lines)


def run_evaluation(corpus_path: Optional[str] = None) -> Dict[str, Any]:
    corpus = load_corpus(corpus_path)
    detector = AgenticAttackDetector()
    engine = AssessmentEngine()
    repair_agent = RepairAgent()

    results = []
    for case in corpus:
        res = evaluate_test_case(case, detector, engine, repair_agent)
        results.append(res)

    metrics = compute_metrics(results)

    # Save machine-readable JSON
    json_path = os.path.join(BASE_DIR, "data", "attack_evaluation_results.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({"metrics": metrics, "detailed_results": results}, f, indent=2)

    # Save human-readable Markdown report
    report_md = generate_markdown_report(metrics, results)
    md_path = os.path.join(BASE_DIR, "attack_evaluation_report.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(report_md)

    return {"metrics": metrics, "detailed_results": results, "report_path": md_path, "json_path": json_path}


if __name__ == "__main__":
    eval_output = run_evaluation()
    m = eval_output["metrics"]
    cm = m["confusion_matrix"]
    dm = m["detector_metrics"]
    em = m["enforcement_metrics"]

    print("=" * 65)
    print("AGENTIC AI ATTACK DETECTION & SECURITY EVALUATION")
    print("=" * 65)
    print(f"Total Corpus Cases Evaluated: {m['corpus_size']}")
    print(f"True Positives  (TP): {cm['tp']:<5} False Positives (FP): {cm['fp']}")
    print(f"True Negatives  (TN): {cm['tn']:<5} False Negatives (FN): {fn if (fn := cm['fn']) else 0}")
    print("-" * 65)
    print(f"Recall (Detection Rate):         {dm['recall'] * 100:.2f}%")
    print(f"Precision:                      {dm['precision'] * 100:.2f}%")
    print(f"F1 Score:                       {dm['f1_score']:.4f}")
    print(f"False Positive Rate (FPR):      {dm['false_positive_rate'] * 100:.2f}%")
    print(f"Severity-Weighted Detection:    {dm['severity_weighted_detection_rate'] * 100:.2f}%")
    print(f"Attack Block Rate (Enforcement):{em['attack_block_rate'] * 100:.2f}%")
    print(f"Benign Pass Rate:               {em['benign_pass_rate'] * 100:.2f}%")
    print(f"Mean Latency:                   {m['latency_ms']['mean']:.3f} ms")
    print(f"P90 Latency:                    {m['latency_ms']['p90']:.3f} ms")
    print("=" * 65)
    print(f"Results written to: {eval_output['json_path']}")
    print(f"Report written to:  {eval_output['report_path']}")
