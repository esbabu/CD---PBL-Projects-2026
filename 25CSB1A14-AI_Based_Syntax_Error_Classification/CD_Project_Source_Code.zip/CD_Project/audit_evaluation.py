"""
Independent Audit Evaluation Runner for Agentic AI Attack Detection.

Evaluates:
1. Original Corpus (40 cases)
2. New Benign Corpus (20 cases)
3. New Unseen Attacks Corpus (24 cases)

Measures:
- Metrics computed directly from individual outcomes (TP, FP, TN, FN, Precision, Recall, F1, FPR, Block Rate)
- Repeated latency measurements (N=10 runs per case):
  * Detector-only latency
  * End-to-end enforcement latency
- Output saved to data/independent_audit_results.json
"""

import json
import os
import sys
import time
from typing import Any, Dict, List, Tuple
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from assessment_engine import AssessmentEngine, AgenticAttackDetector
from agents.repair_agent import RepairAgent
from evaluate_attacks import compute_metrics, SEVERITY_WEIGHTS


def run_benchmark_on_dataset(
    corpus_file: str,
    iterations: int = 10,
) -> Dict[str, Any]:
    with open(corpus_file, "r", encoding="utf-8") as f:
        cases = json.load(f)

    detector = AgenticAttackDetector()
    engine = AssessmentEngine()
    repair_agent = RepairAgent()

    case_evaluations = []
    detector_latencies_all = []
    enforcement_latencies_all = []

    for case in cases:
        input_data = case["input_data"]
        input_type = case.get("input_type", "auto")
        is_attack = bool(case["is_attack"])

        # Repeat latency measurements
        det_times = []
        enf_times = []

        last_detect_res = None
        last_blocked = False
        last_enf_detail = ""

        for _ in range(iterations):
            # 1. Detector-only latency
            t0 = time.perf_counter()
            detect_res = detector.assess(input_data, context_type=input_type, is_protected_action=False)
            t_det = (time.perf_counter() - t0) * 1000.0
            det_times.append(t_det)
            last_detect_res = detect_res

            # 2. End-to-end enforcement latency
            t1 = time.perf_counter()
            blocked = False
            enf_detail = ""

            if input_type == "source_code":
                code_str = input_data if isinstance(input_data, str) else ""
                assessment = engine.evaluate(code_str)
                blocked = not assessment.passed or assessment.gate_decision == "BLOCKED"
                enf_detail = f"Gate: {assessment.gate_decision}"
            elif input_type in ("repair_plan", "repair_diff"):
                if isinstance(input_data, dict):
                    prop_code = input_data.get("proposed_code", "")
                    requires_app = input_data.get("requires_approval", True)
                    if not requires_app:
                        blocked = True
                        enf_detail = "Approval bypass rejected"
                    else:
                        repair_res = repair_agent.apply_and_verify(
                            original_source="int main() { return 0; }",
                            proposed_code=prop_code,
                            approved=True,
                        )
                        blocked = repair_res.verification_status in ("rejected", "rollback") or not repair_res.success
                        enf_detail = f"Repair: {repair_res.verification_status}"
                else:
                    diff_text = str(input_data)
                    diff_eval = detector.assess(diff_text, context_type="repair_diff", is_protected_action=True)
                    blocked = diff_eval.detected and diff_eval.action == "BLOCK"
                    enf_detail = f"Diff: {diff_eval.action}"
            else:
                blocked = detect_res.detected and detect_res.action == "BLOCK"
                enf_detail = f"Boundary: {detect_res.action}"

            t_enf = (time.perf_counter() - t1) * 1000.0
            enf_times.append(t_enf)
            last_blocked = blocked
            last_enf_detail = enf_detail

        avg_det_ms = float(np.mean(det_times))
        avg_enf_ms = float(np.mean(enf_times))
        detector_latencies_all.extend(det_times)
        enforcement_latencies_all.extend(enf_times)

        case_evaluations.append({
            "id": case["id"],
            "category": case["category"],
            "is_attack": is_attack,
            "severity": case.get("severity", "none").lower(),
            "detected": bool(last_detect_res.detected),
            "detected_type": last_detect_res.attack_type,
            "blocked": last_blocked,
            "detector_latency_ms": round(avg_det_ms, 3),
            "latency_ms": round(avg_det_ms, 3),
            "enforcement_latency_ms": round(avg_enf_ms, 3),
            "enforcement_detail": last_enf_detail,
        })

    # Metric calculations
    base_metrics = compute_metrics(case_evaluations)

    latency_stats = {
        "sample_size_measurements": len(detector_latencies_all),
        "iterations_per_case": iterations,
        "detector_only_ms": {
            "mean": round(float(np.mean(detector_latencies_all)), 4),
            "p50": round(float(np.percentile(detector_latencies_all, 50)), 4),
            "p90": round(float(np.percentile(detector_latencies_all, 90)), 4),
            "p99": round(float(np.percentile(detector_latencies_all, 99)), 4),
        },
        "enforcement_end_to_end_ms": {
            "mean": round(float(np.mean(enforcement_latencies_all)), 4),
            "p50": round(float(np.percentile(enforcement_latencies_all, 50)), 4),
            "p90": round(float(np.percentile(enforcement_latencies_all, 90)), 4),
            "p99": round(float(np.percentile(enforcement_latencies_all, 99)), 4),
        },
    }

    return {
        "dataset_file": os.path.basename(corpus_file),
        "metrics": base_metrics,
        "latency_stats": latency_stats,
        "case_evaluations": case_evaluations,
    }


def main():
    original_path = os.path.join(BASE_DIR, "data", "attack_corpus.json")
    benign_path = os.path.join(BASE_DIR, "data", "audit_benign_corpus.json")
    unseen_path = os.path.join(BASE_DIR, "data", "audit_unseen_attacks.json")

    print("[*] Running audit evaluation on Original Corpus...")
    res_orig = run_benchmark_on_dataset(original_path, iterations=10)

    print("[*] Running audit evaluation on New Benign Corpus...")
    res_benign = run_benchmark_on_dataset(benign_path, iterations=10)

    print("[*] Running audit evaluation on New Unseen Attacks Corpus...")
    res_unseen = run_benchmark_on_dataset(unseen_path, iterations=10)

    audit_summary = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        "original_benchmark": res_orig,
        "new_benign_evaluation": res_benign,
        "new_unseen_attacks_evaluation": res_unseen,
    }

    out_file = os.path.join(BASE_DIR, "data", "independent_audit_results.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(audit_summary, f, indent=2)

    print(f"\n[+] Audit results successfully written to: {out_file}\n")
    return audit_summary


if __name__ == "__main__":
    main()
