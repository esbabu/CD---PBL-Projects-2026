import unittest
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from dependency_scanner import scan_dependencies, parse_requirements_txt, parse_package_json, _version_less_than

class TestDependencyScanner(unittest.TestCase):
    def test_version_comparison(self):
        self.assertTrue(_version_less_than("2.20.0", "2.31.0"))
        self.assertTrue(_version_less_than("1.26.4", "1.26.5"))
        self.assertFalse(_version_less_than("3.1.4", "3.1.3"))
        self.assertFalse(_version_less_than("4.2.8", "4.2.8"))

    def test_scan_vulnerable_requirements(self):
        reqs = """
        requests==2.20.0
        urllib3==1.24.2
        jinja2==3.0.0
        pyyaml==5.3
        certifi>=2024.1.1
        """
        res = scan_dependencies(reqs, "requirements.txt")
        self.assertTrue(res["success"])
        self.assertEqual(res["total_dependencies"], 5)
        self.assertGreater(res["vulnerable_count"], 0)
        self.assertGreater(res["total_cves"], 0)
        cves = [v["cve"] for v in res["vulnerabilities"]]
        self.assertIn("CVE-2023-32681", cves)
        self.assertIn("CVE-2020-14343", cves)
        self.assertIn("requests", res["recommended_upgrades"])

    def test_scan_clean_requirements(self):
        reqs = """
        requests>=2.32.0
        urllib3>=2.0.0
        flask>=3.0.0
        """
        res = scan_dependencies(reqs, "requirements.txt")
        self.assertTrue(res["success"])
        self.assertEqual(res["total_cves"], 0)
        self.assertEqual(res["status"], "CLEAN")

    def test_scan_package_json(self):
        pkg_json = """
        {
            "name": "my-app",
            "dependencies": {
                "lodash": "^4.17.15",
                "axios": "0.21.0"
            }
        }
        """
        res = scan_dependencies(pkg_json, "package.json")
        self.assertTrue(res["success"])
        self.assertEqual(res["total_dependencies"], 2)
        self.assertGreater(res["total_cves"], 0)
        cves = [v["cve"] for v in res["vulnerabilities"]]
        self.assertIn("CVE-2021-23337", cves)
        self.assertIn("CVE-2023-45857", cves)

if __name__ == "__main__":
    unittest.main()
