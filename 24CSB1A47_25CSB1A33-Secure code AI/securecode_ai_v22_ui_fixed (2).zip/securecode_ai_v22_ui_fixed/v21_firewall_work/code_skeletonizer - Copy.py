"""Code Skeletonizer for SecureCode AI.

Safely scrubs sensitive data (string literals, secrets, credentials, docstrings,
and comments) from source code before transmitting it to AI chat endpoints.
Generates an AST-based or lexical skeleton preserving syntax and control-flow
logic without leaking proprietary literals or confidential strings.
"""
from __future__ import annotations
import ast
import re
from typing import Optional

try:
    from secret_scanner import SECRET_RULES
except ImportError:
    SECRET_RULES = []


class PythonSkeletonTransformer(ast.NodeTransformer):
    """AST transformer that removes docstrings and replaces literals with placeholders."""

    def visit_Constant(self, node: ast.Constant) -> ast.AST:
        if isinstance(node.value, str):
            return ast.Constant(value="<STRING>")
        elif isinstance(node.value, (int, float)):
            return ast.Constant(value=0)
        return node

    def visit_Expr(self, node: ast.Expr) -> Optional[ast.AST]:
        # Drop bare string expressions (docstrings)
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            return None
        return self.generic_visit(node)


def _ast_skeletonize_python(source: str) -> Optional[str]:
    """Parse Python source into an AST, scrub literals and docstrings, and unparse."""
    try:
        tree = ast.parse(source)
        scrubbed = PythonSkeletonTransformer().visit(tree)
        ast.fix_missing_locations(scrubbed)
        return ast.unparse(scrubbed)
    except Exception:
        return None


# Single-pass regex for strings and comments across JS, Java, C, C++, and Python fallback
_LEXICAL_PATTERN = re.compile(
    r'(?P<comment_block>/\*[\s\S]*?\*/)'
    r'|(?P<comment_line>//[^\r\n]*)'
    r'|(?P<comment_py>#[^\r\n]*)'
    r'|(?P<d_quote>"(?:[^"\\]|\\.)*")'
    r'|(?P<s_quote>\'(?:[^\'\\]|\\.)*\')'
    r'|(?P<b_quote>`(?:[^`\\]|\\.)*`)'
)


def _lexical_skeletonize(source: str) -> str:
    """Scrub comments and string literals using single-pass lexical scanning."""
    def replacer(match: re.Match) -> str:
        if match.group('comment_block') or match.group('comment_line') or match.group('comment_py'):
            return ""
        if match.group('d_quote') or match.group('s_quote') or match.group('b_quote'):
            return '"<STRING>"'
        return match.group(0)

    scrubbed = _LEXICAL_PATTERN.sub(replacer, source)
    # Mask numbers with 0
    scrubbed = re.sub(r'\b\d+(\.\d+)?\b', '0', scrubbed)
    # Collapse multiple blank lines
    scrubbed = re.sub(r'\n{3,}', '\n\n', scrubbed)
    return scrubbed.strip()


def _redact_known_secrets(text: str) -> str:
    """Run known secret signatures to catch any non-quoted secrets/keys."""
    if not text or not SECRET_RULES:
        return text
    redacted = text
    for rule in SECRET_RULES:
        pattern = rule.get("pattern")
        if pattern:
            redacted = pattern.sub("[REDACTED_SECRET]", redacted)
    return redacted


def skeletonize_code(code: str, filename: str = "source.py") -> str:
    """Generate a sanitized code skeleton safe for transmission to AI.

    Preserves:
      - Function signatures, classes, parameters
      - Control flow (if/else, loops, exception handling)
      - Variable references and call graphs
      - Syntax structure needed for security reasoning

    Removes/Masks:
      - Hardcoded string literals (passwords, tokens, API keys, URLs, SQL)
      - Numeric constants
      - Comments and docstrings
      - High-entropy secrets and credentials
    """
    if not isinstance(code, str) or not code.strip():
        return ""

    filename_lower = (filename or "").lower()

    # 1. Try Python AST skeletonization if it's a Python file
    if filename_lower.endswith(".py"):
        ast_result = _ast_skeletonize_python(code)
        if ast_result is not None:
            return _redact_known_secrets(ast_result)

    # 2. Use lexical skeletonizer for JS, Java, C/C++, or Python syntax errors
    lexical_result = _lexical_skeletonize(code)
    return _redact_known_secrets(lexical_result)
