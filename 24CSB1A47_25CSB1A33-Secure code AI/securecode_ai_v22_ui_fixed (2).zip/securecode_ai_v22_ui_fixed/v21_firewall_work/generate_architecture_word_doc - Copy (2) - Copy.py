import os
import zipfile

def generate_architecture_word_doc():
    filename = "v21_firewall_work/SECURECODE_AI_PROJECT_ARCHITECTURE.docx"

    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    doc_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    styles = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>
        <w:sz w:val="22"/>
        <w:color w:val="2D3748"/>
      </w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:rPr>
      <w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI"/>
      <w:b/>
      <w:sz w:val="44"/>
      <w:color w:val="1A365D"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Subtitle">
    <w:name w:val="Subtitle"/>
    <w:rPr>
      <w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI"/>
      <w:i/>
      <w:sz w:val="24"/>
      <w:color w:val="4A5568"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:rPr>
      <w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI"/>
      <w:b/>
      <w:sz w:val="32"/>
      <w:color w:val="2B6CB0"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:rPr>
      <w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI"/>
      <w:b/>
      <w:sz w:val="26"/>
      <w:color w:val="2D3748"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading3">
    <w:name w:val="heading 3"/>
    <w:rPr>
      <w:rFonts w:ascii="Segoe UI" w:hAnsi="Segoe UI"/>
      <w:b/>
      <w:sz w:val="22"/>
      <w:color w:val="4A5568"/>
    </w:rPr>
  </w:style>
</w:styles>"""

    # Helper function to generate table box
    def make_box(title, subtitle, bullets, bg_color="EDF2F7", border_color="CBD5E0", title_color="1A365D"):
        bullet_xml = ""
        for b in bullets:
            bullet_xml += f"""
            <w:p>
              <w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="60"/></w:pPr>
              <w:r><w:rPr><w:b/><w:color w:val="{title_color}"/></w:rPr><w:t>• </w:t></w:r>
              <w:r><w:t>{b}</w:t></w:r>
            </w:p>"""
        return f"""
        <w:tbl>
          <w:tblPr>
            <w:tblW w:w="9600" w:type="dxa"/>
            <w:tblBorders>
              <w:top w:val="single" w:sz="12" w:space="0" w:color="{border_color}"/>
              <w:left w:val="single" w:sz="24" w:space="0" w:color="{border_color}"/>
              <w:bottom w:val="single" w:sz="12" w:space="0" w:color="{border_color}"/>
              <w:right w:val="single" w:sz="12" w:space="0" w:color="{border_color}"/>
            </w:tblBorders>
            <w:tblCellMar>
              <w:top w:w="160" w:type="dxa"/>
              <w:left w:w="240" w:type="dxa"/>
              <w:bottom w:w="160" w:type="dxa"/>
              <w:right w:w="240" w:type="dxa"/>
            </w:tblCellMar>
          </w:tblPr>
          <w:tr>
            <w:tc>
              <w:tcPr>
                <w:tcW w:w="9600" w:type="dxa"/>
                <w:shd w:val="clear" w:color="auto" w:fill="{bg_color}"/>
              </w:tcPr>
              <w:p>
                <w:pPr><w:spacing w:after="40"/></w:pPr>
                <w:r><w:rPr><w:b/><w:color w:val="{title_color}"/><w:sz w:val="24"/></w:rPr><w:t>{title}</w:t></w:r>
              </w:p>
              <w:p>
                <w:pPr><w:spacing w:after="100"/></w:pPr>
                <w:r><w:rPr><w:i/><w:color w:val="718096"/><w:sz w:val="20"/></w:rPr><w:t>{subtitle}</w:t></w:r>
              </w:p>
              {bullet_xml}
            </w:tc>
          </w:tr>
        </w:tbl>
        <w:p><w:pPr><w:spacing w:after="120"/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="718096"/></w:rPr><w:t>↓</w:t></w:r></w:p>
        """

    def make_heading(text, level=1):
        style = f"Heading{level}"
        return f"""
        <w:p>
          <w:pPr><w:pStyle w:val="{style}"/><w:spacing w:before="280" w:after="140"/></w:pPr>
          <w:r><w:t>{text}</w:t></w:r>
        </w:p>"""

    def make_para(text):
        return f"""
        <w:p>
          <w:pPr><w:spacing w:after="140"/><w:line w:line="276" w:lineRule="auto"/></w:pPr>
          <w:r><w:t>{text}</w:t></w:r>
        </w:p>"""

    body = []
    # Title
    body.append("""
    <w:p>
      <w:pPr><w:pStyle w:val="Title"/><w:jc w:val="center"/><w:spacing w:after="100"/></w:pPr>
      <w:r><w:t>SecureCode AI: System Architecture &amp; Methodology</w:t></w:r>
    </w:p>
    <w:p>
      <w:pPr><w:pStyle w:val="Subtitle"/><w:jc w:val="center"/><w:spacing w:after="300"/></w:pPr>
      <w:r><w:t>A Hybrid Multi-Agent Platform for Static Vulnerability Detection &amp; Verified Automated Repair</w:t></w:r>
    </w:p>
    """)

    # Section 1
    body.append(make_heading("1. Proposed Architecture (Top-to-Bottom Flow)", 1))
    body.append(make_para("The proposed architecture of SecureCode AI completely replaces legacy, single-model architectures with a resilient, multi-tiered multi-agent orchestration pipeline. The end-to-end execution flow is structured top-to-bottom as follows:"))

    # Flow Cards
    body.append(make_box(
        "User Source Code &amp; Project Input (.py, .js, .java, .c, .cpp, manifests, ZIP)",
        "Entry Point: Single files, directory trees, Git clones, or compressed archives",
        [
            "Multi-language support spanning Python, JavaScript, Java, C, and C++.",
            "Software Composition Analysis (SCA) inputs: requirements.txt, package.json, pom.xml.",
            "Project Explorer tree indexing with selective multi-file scanning."
        ],
        bg_color="EBF8FF", border_color="3182CE", title_color="2B6CB0"
    ))

    body.append(make_box(
        "Step 1 &amp; 2: Local Deterministic Core &amp; AST Analyzers (agents/local_non_llm_agents.py)",
        "Tier 1: 100% Offline, Deterministic, 0% Token Cost, Sub-15ms Execution",
        [
            "FileScannerAgent &amp; ProjectGraph: Indexes directories, builds import graphs, excludes build noise (.git, node_modules, __pycache__).",
            "SyntaxCheckerAgent: AST validation using Python native ast.parse and language-specific grammar parsers.",
            "PatternDetectionAgent: Two-pass static taint analysis matching 15+ vulnerability classes (SQLi, XSS, Command Injection, Path Traversal, Insecure Deserialization).",
            "SecretScanner (Shannon Entropy H &gt; 4.2 + 15 Regexes): Detects exposed AWS, Stripe, Google API keys and private tokens.",
            "DependencyAnalysisAgent: Evaluates package manifests against offline CVE/CVSS advisories."
        ],
        bg_color="E6FFFA", border_color="319795", title_color="234E52"
    ))

    body.append(make_box(
        "Step 3: AI Firewall &amp; Code Privacy Boundary (ai_firewall.py, code_skeletonizer.py)",
        "Data Protection &amp; Defense-in-Depth Layer",
        [
            "Deterministic Prompt Guardrails: Detects and blocks role overrides, prompt theft, secret exfiltration, and tool abuse before model invocation.",
            "AST Code Skeletonizer: Transforms source code into structural skeletons, replacing string literals with '<STRING>', numbers with 0, and stripping docstrings/secrets.",
            "Untrusted Source Isolation: Flags source comments and prompt-injection patterns as untrusted data, preventing source-embedded jailbreaks.",
            "Response Schema Validator: Enforces strict JSON shape compliance on all model outputs."
        ],
        bg_color="FFF5F5", border_color="E53E3E", title_color="9B2C2C"
    ))

    body.append(make_box(
        "Step 4: Master Orchestrator &amp; Intelligent Task Routing (master_orchestrator.py, intelligent_task_router.py)",
        "Coordination, Concurrency, and Policy Execution",
        [
            "Master Orchestrator Agent: Central coordinator managing thread-pool concurrency (ThreadPoolExecutor), execution history, and inter-agent handoffs.",
            "Intelligent Task Router: Dispatches tasks across 3 operational modes (AUTO, LOCAL_ONLY, ONLINE_ONLY).",
            "Tier 2 Local SLM (Ollama / Qwen 2.5 Coder 3B): Executes private offline explanations, bug detection, and CWE error classification.",
            "Tier 3 Online Cloud AI (Groq / Gemini Flash Lite / Llama 3.3 70B): Handles deep multi-step reasoning, cross-file data flows, and complex patch synthesis.",
            "Resilient Degradation: Automatically falls back to local execution if cloud models face timeouts or quota limits."
        ],
        bg_color="FAF5FF", border_color="805AD5", title_color="553C9A"
    ))

    body.append(make_box(
        "Step 5: Closed-Loop Self-Healing &amp; AST Verification Loop (verification_agent.py, difflib)",
        "Iterative Automated Program Repair Engine (Max 3 Rounds)",
        [
            "ComplexRepairAgent: Synthesizes surgical, unified diff patches preserving coding style and surrounding logic.",
            "VerificationAgent (AST Gatekeeper): Re-compiles candidate patches into fresh AST trees and re-runs deterministic security rules.",
            "Automated Rejection: Patches introducing syntax errors or failing to eliminate the targeted vulnerability are automatically rejected.",
            "Unified Diff Generator: Computes clean line-by-line diff opcodes (insert, delete, replace)."
        ],
        bg_color="FFFAF0", border_color="DD6B20", title_color="7B341E"
    ))

    body.append(f"""
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9600" w:type="dxa"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="16" w:space="0" w:color="2B6CB0"/>
          <w:left w:val="single" w:sz="24" w:space="0" w:color="2B6CB0"/>
          <w:bottom w:val="single" w:sz="16" w:space="0" w:color="2B6CB0"/>
          <w:right w:val="single" w:sz="16" w:space="0" w:color="2B6CB0"/>
        </w:tblBorders>
        <w:tblCellMar>
          <w:top w:w="180" w:type="dxa"/>
          <w:left w:w="240" w:type="dxa"/>
          <w:bottom w:w="180" w:type="dxa"/>
          <w:right w:w="240" w:type="dxa"/>
        </w:tblCellMar>
      </w:tblPr>
      <w:tr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="9600" w:type="dxa"/>
            <w:shd w:val="clear" w:color="auto" w:fill="EDF2F7"/>
          </w:tcPr>
          <w:p>
            <w:pPr><w:spacing w:after="60"/></w:pPr>
            <w:r><w:rPr><w:b/><w:color w:val="1A365D"/><w:sz w:val="24"/></w:rPr><w:t>Final Output: Interactive Security Workbench (frontend/index.html, app.js)</w:t></w:r>
          </w:p>
          <w:p>
            <w:pPr><w:spacing w:after="80"/></w:pPr>
            <w:r><w:rPr><w:i/><w:color w:val="4A5568"/><w:sz w:val="20"/></w:rPr><w:t>Developer-Centric Security Environment</w:t></w:r>
          </w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>0–100 Project Security Scorecard with categorized severity distributions (Critical, High, Medium, Low).</w:t></w:r></w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Side-by-Side Visual Split Diff Editor with synchronized line scrolling, one-click patch application, and instant rollback.</w:t></w:r></w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Real-time Multi-Agent Activity Dashboard streaming live execution logs, agent handoffs, and execution latencies in ms.</w:t></w:r></w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Project-Aware Interactive AI Chat with Server-Sent Events (SSE) streaming and prompt firewall enforcement.</w:t></w:r></w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Exportable structured audits in JSON and publication-quality printable PDF formats.</w:t></w:r></w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
    <w:p><w:pPr><w:spacing w:after="240"/></w:pPr></w:p>
    """)

    # Section 2
    body.append(make_heading("2. High-Level Compiler & Static Analysis Pipeline", 1))
    body.append(make_para("This section details the deterministic static compiler pass architecture that powers Tier 1 of SecureCode AI. The pipeline transforms raw source text into validated security verdicts through five discrete compiler passes:"))

    body.append(make_box(
        "PYTHON SOURCE CODE (.py file / source text)",
        "Raw Input Layer",
        [
            "Ingests arbitrary Python source text or files.",
            "Bounded UTF-8 memory buffer preventing denial-of-service."
        ],
        bg_color="EDF2F7", border_color="4A5568", title_color="2D3748"
    ))

    body.append(make_box(
        "PythonASTBridge (python_ast_bridge.py)",
        "Language Normalization Layer",
        [
            "Invokes Python's native ast.parse to construct a concrete Abstract Syntax Tree.",
            "Normalizes AST nodes into a unified project representation compatible with multi-language visitors.",
            "Captures syntax errors and provides precise 1-based line and column offsets."
        ],
        bg_color="EDF2F7", border_color="4A5568", title_color="2D3748"
    ))

    body.append(make_box(
        "ASTTraverser (ast_traverser.py)",
        "Two-Pass Analysis Controller",
        [
            "Orchestrates recursive visitor traversal across AST nodes.",
            "Tracks variable scopes, function definitions, assignments, and calls.",
            "Coordinates execution between InputDetectionModule and RuleEngineModule."
        ],
        bg_color="EDF2F7", border_color="4A5568", title_color="2D3748"
    ))

    body.append(make_box(
        "Pass 1 — InputDetectionModule (module1_input_detection.py)",
        "Source Identification & SymbolTable Population",
        [
            "Identifies untrusted user input origins (request.args, request.form, sys.argv, input()).",
            "Tags variables in the SymbolTable with taint states.",
            "Recognizes sanitization routines (escape(), int(), parameterization) and marks tainted symbols as sanitized."
        ],
        bg_color="EDF2F7", border_color="4A5568", title_color="2D3748"
    ))

    body.append(make_box(
        "Pass 2 — RuleEngineModule (module2_rule_engine.py)",
        "Sink Matching & Taint-Flow Verification",
        [
            "Evaluates dangerous function calls (cursor.execute, os.system, eval, pickle.loads).",
            "Correlates arguments with SymbolTable taint records to prove unsanitized taint flows.",
            "Evaluates ORM query construction and raw SQL string concatenations."
        ],
        bg_color="EDF2F7", border_color="4A5568", title_color="2D3748"
    ))

    body.append(make_box(
        "WarningDecisionLogic (module3_warning_logic.py)",
        "Confidence Scoring, Sanitization Filtering & Severity Assessment",
        [
            "Computes confidence scores (0.0 to 1.0) based on taint propagation certainty.",
            "Filters out false positives when valid sanitizers are verified.",
            "Maps findings to standard severities (CRITICAL, HIGH, MEDIUM, LOW) and CWE IDs."
        ],
        bg_color="EDF2F7", border_color="4A5568", title_color="2D3748"
    ))

    body.append(f"""
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9600" w:type="dxa"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="16" w:space="0" w:color="2B6CB0"/>
          <w:left w:val="single" w:sz="24" w:space="0" w:color="2B6CB0"/>
          <w:bottom w:val="single" w:sz="16" w:space="0" w:color="2B6CB0"/>
          <w:right w:val="single" w:sz="16" w:space="0" w:color="2B6CB0"/>
        </w:tblBorders>
        <w:tblCellMar>
          <w:top w:w="160" w:type="dxa"/>
          <w:left w:w="240" w:type="dxa"/>
          <w:bottom w:w="160" w:type="dxa"/>
          <w:right w:w="240" w:type="dxa"/>
        </w:tblCellMar>
      </w:tblPr>
      <w:tr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="9600" w:type="dxa"/>
            <w:shd w:val="clear" w:color="auto" w:fill="EDF2F7"/>
          </w:tcPr>
          <w:p>
            <w:pPr><w:spacing w:after="40"/></w:pPr>
            <w:r><w:rPr><w:b/><w:color w:val="1A365D"/><w:sz w:val="24"/></w:rPr><w:t>OUTPUT: Structured Findings &amp; Multi-Format Reports</w:t></w:r>
          </w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Human-readable text diagnostic reports with line evidence and explanation.</w:t></w:r></w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Structured JSON schema payload for CI/CD integrations and frontend consumption.</w:t></w:r></w:p>
          <w:p><w:pPr><w:ind w:left="320" w:hanging="180"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="2B6CB0"/></w:rPr><w:t>• </w:t></w:r><w:r><w:t>Direct feed into the Self-Healing Pipeline for automated patch generation.</w:t></w:r></w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
    <w:p><w:pPr><w:spacing w:after="240"/></w:pPr></w:p>
    """)

    # Section 3: Comparative Analysis Table
    body.append(make_heading("3. Comparative Architecture Analysis: Seniors vs. SecureCode AI", 1))
    body.append(make_para("The following table contrasts the baseline architecture (Seniors' Project) against the proposed SecureCode AI architecture, highlighting the key engineering innovations and security enhancements:"))

    body.append("""
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9600" w:type="dxa"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="8" w:space="0" w:color="CBD5E0"/>
          <w:left w:val="single" w:sz="8" w:space="0" w:color="CBD5E0"/>
          <w:bottom w:val="single" w:sz="8" w:space="0" w:color="CBD5E0"/>
          <w:right w:val="single" w:sz="8" w:space="0" w:color="CBD5E0"/>
          <w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
          <w:insideV w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
        </w:tblBorders>
      </w:tblPr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="2B6CB0"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Dimension</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="4A5568"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Seniors' Architecture</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="2B6CB0"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Proposed SecureCode AI</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Analysis Core</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Semgrep CLI + generic regex fallback</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Native two-pass AST taint engine + 15 SAST rules + Shannon entropy</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Code Truncation</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Hardcoded 450-character limit (code[:450])</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Full multi-file workspace indexing (max 65 KB AI context, up to 10 files)</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>AI / Model Tier</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>CodeT5-base (220M params), 1 unverified sentence</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>16 Agents across 3 Tiers (Local Non-LLM, Ollama SLM, Cloud LLM)</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Security Boundary</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>None (Raw code passed to model)</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>AI Firewall prompt guardrails + AST code skeletonizer &amp; secret masking</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Automated Repair</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>No repair capability</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>11-Step Self-Healing Pipeline with unified diff synthesis &amp; AST verification</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Execution Modes</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Single static execution</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>AUTO, LOCAL_ONLY (100% offline air-gapped), and ONLINE_ONLY</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>User Interface</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Basic Streamlit gauge and alert cards</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>VS Code-style workbench, AST viewer, split diff editor, real-time agent dashboard</w:t></w:r></w:p></w:tc>
      </w:tr>
    </w:tbl>
    <w:p><w:pPr><w:spacing w:after="240"/></w:pPr></w:p>
    """)

    # Close body
    body_xml = ['<w:body>'] + body + ['</w:body>']
    doc_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  {''.join(body_xml)}
</w:document>"""

    with zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', content_types)
        z.writestr('_rels/.rels', rels)
        z.writestr('word/_rels/document.xml.rels', doc_rels)
        z.writestr('word/styles.xml', styles)
        z.writestr('word/document.xml', doc_xml)

    print(f"Successfully generated Word Document: {filename}")

if __name__ == "__main__":
    generate_architecture_word_doc()
