# SecureCode AI: A Lightweight Hybrid Multi-Agent System for Real-Time Static Vulnerability Detection and Verified Automated Code Repair

---

## Abstract

### [General Introduction of the domain and title]
Software development is fundamentally an iterative loop of coding, compiling, testing, and debugging. For decades, compilers and linters have enforced syntax rules and type safety. However, their output is notoriously terse and cryptic, often leaving developers guessing about the real cause of a failure. In the past two to three years, developers have increasingly turned to cloud-based Large Language Models (LLMs) like ChatGPT, Claude, and GitHub Copilot to translate confusing compiler messages and track down security issues.

### [Challenges of the Domain]
While these large models are undeniably helpful for generic code generation, using them as automated security reviewers introduces serious practical problems. First, cloud LLMs require a persistent internet connection and send proprietary source code to third-party servers, which violates enterprise privacy policies and intellectual property agreements. Second, general-purpose LLMs have no direct awareness of the code's Abstract Syntax Tree (AST) or symbol tables. Because they guess token sequences rather than analyzing compiler state, they frequently hallucinate non-existent variables, miscalculate line numbers, and suggest patches that either fail to compile or introduce new vulnerabilities like unparameterized SQL queries, unsafe system calls, or buffer overflows. Finally, sending entire repositories or routine syntax checks to commercial cloud APIs adds noticeable latency and quickly becomes expensive.

### [Proposed Work]
In this paper, we present **SecureCode AI**, a production-ready security analysis and automated code repair platform designed to run in both offline and hybrid setups. Instead of relying on a single cloud LLM, the system uses a hierarchical multi-agent architecture managed by a central **Master Orchestrator** and an **Intelligent Task Router**. Users can select between three execution modes: **Auto**, **Local Only (100% offline and air-gapped)**, and **Online Only**. 

The platform divides analysis duties among **16 specialized agents** arranged in three tiers:
1. **Six local deterministic agents** that handle file scanning, AST syntax validation, manifest dependency checks, and rule-based pattern matching across 15+ vulnerability classes (such as SQL injection, XSS, command injection, path traversal, and hardcoded keys via Shannon entropy) in under 15 milliseconds without requiring internet access or GPU hardware.
2. **Five local AI agents** running on top of Ollama (using the Qwen 2.5 Coder 3B model) that provide private, on-device explanations, logic bug diagnosis, and simple fixes.
3. **Five cloud AI agents** (leveraging Gemini Flash Lite and Groq Llama 3.3 70B) dedicated to complex tasks such as tracing data flows across multiple files, analyzing overall project architecture, and generating multi-file patches.

These agents feed into an **11-step self-healing repair pipeline**. Whenever a patch is proposed, an automated AST verification agent inspects the modified code to ensure that it compiles cleanly and genuinely eliminates the vulnerability before the change is presented to the developer.

### [Experimental Results & Discussion]
We evaluated SecureCode AI on a benchmark of 850 multi-language programs (written in Python, JavaScript, Java, C, and C++) containing both synthetic vulnerabilities and real-world CVEs. The local deterministic scanner processed source files in an average of 11.8 ms per file. On a mid-range laptop equipped with an RTX 3060 GPU, local Ollama inference completed in 1.45 seconds per query (and 3.8 seconds on CPU). Across our benchmark, the system achieved a **96.8% classification accuracy**, an **F1-score of 0.939**, and a **91.5% success rate** in generating valid, working patches. In a trial evaluation with 250 software developers and computer science students, the platform received an **82% helpfulness rating**, with participants highlighting the side-by-side diff view and offline availability as significant improvements over conventional linters. Testing on SecureCode AI's own codebase verified **zero self-vulnerabilities** and a **100% pass rate across all 37 regression tests**.

---

## Index Terms
**Static Application Security Testing (SAST), Abstract Syntax Tree (AST), Multi-Agent Systems, Automated Program Repair, Local Language Models, Taint Analysis, Secure Coding, Ollama, Qwen 2.5 Coder.**

---

## I. INTRODUCTION

### General Introduction of Domain: Purpose, Usage, and Advantages
Writing software has always been an iterative cycle: developers write code, invoke the compiler or interpreter, inspect errors, and revise their logic [1], [2]. Compilers like GCC, Clang, and language runtimes for Python and Java act as strict gatekeepers. They verify syntax and type compatibility before generating machine binaries or bytecode [3]. In safety-critical and enterprise software, this basic verification is paired with Static Application Security Testing (SAST) tools to uncover vulnerabilities like SQL injection, buffer overflows, and unsafe deserialization long before code reaches staging or production environments. Catching security bugs during development saves tremendous engineering effort and shields organizations from costly production breaches.

### Challenges
Despite their importance, traditional compiler and static analysis diagnostics remain notoriously difficult to interpret. Tools like GCC or PyLint produce outputs shaped by internal parser states rather than developer problem-solving workflows. Messages like `"segmentation fault (core dumped)"`, `"dereferencing pointer to incomplete type"`, or `"tainted source reaches sink at line 42"` tell a programmer that something broke, but rarely clarify *why* or *how* to fix it safely. As a result, developers spend valuable hours searching verbatim error strings on Stack Overflow or trial-and-error patching without understanding the root flaw. Linters often compound the problem by spewing dozens of minor stylistic warnings alongside critical security flaws, causing alert fatigue.

### Motivation from Existing Challenges
This diagnostic barrier is especially frustrating for beginners, students, and agile teams under tight deadlines. When learners cannot quickly connect an error message to their actual code mistake, their momentum stalls. An effective development environment should provide clear, immediate, and trustworthy feedback: it should point out the exact line causing trouble, explain the risk in straightforward terms, and suggest a clean, working solution.

### Significant Challenges and Research Gaps
Over the past two years, developers have turned to generative cloud LLMs like ChatGPT and GitHub Copilot as informal debugging tutors. While these tools can summarize code fluently, relying solely on commercial cloud LLMs for software security exposes four critical flaws:
1. **Data Privacy and Exposure:** Sending code to third-party cloud APIs violates strict corporate security policies, NDAs, and regulatory standards (such as GDPR and HIPAA). Many organizations explicitly prohibit transmitting their internal codebases outside their firewalls.
2. **Lack of Structural Grounding:** Cloud LLMs analyze code as raw text tokens. They do not parse the code into an Abstract Syntax Tree (AST) or build symbol tables. Consequently, they frequently hallucinate non-existent imports, mistake variable scopes, and quote incorrect line numbers.
3. **Generation of Insecure Code:** General-purpose LLMs are trained on massive public web corpora that contain outdated and insecure code. Multiple recent studies show that LLMs routinely suggest vulnerable fixes, such as replacing one raw SQL string with another concatenated query, or substituting `strcpy` with equally unsafe pointer manipulation.
4. **Latency and Operational Costs:** Calling a remote 70-billion-parameter cloud model for routine syntax errors or small linter checks introduces noticeable round-trip latency and incurs unnecessary API subscription costs.

### Problem Statement
What is missing is a practical, structure-aware system that combines the speed and rigor of compiler-level static analysis with the reasoning capabilities of localized and hybrid AI models—delivering fast, private, and verified security analysis without hallucinations or data leaks.

### Our Contribution / Objectives
To address these shortcomings, we built SecureCode AI. Our primary contributions are:
1. **A Working Hybrid Multi-Agent Architecture:** A multi-agent framework led by a Master Orchestrator and an Intelligent Task Router managing 16 specialized agents across three operational tiers (Local Deterministic, Local Ollama SLM, and Online Cloud AI).
2. **Fast, Air-Gapped Static Analysis:** A zero-cost local scanning engine using Python AST traversal, multi-language regex fallback rules, and Shannon entropy calculations to detect 15+ vulnerability categories, credential leaks, and outdated manifest dependencies in milliseconds.
3. **Closed-Loop Self-Healing Pipeline:** An 11-step repair workflow where every AI-generated patch must pass an automated AST verification check. Patches that break syntax or fail to remove the target vulnerability are automatically rejected or sent back for re-generation.
4. **Flexible Execution Modes:** Runtime policies allowing developers to toggle between `Auto`, `Local Only` (100% offline on-device Ollama execution), and `Online Only`.
5. **Developer-Friendly UI:** A full VS Code-style workspace explorer, syntax-highlighted code editor with a bottom scrollbar, an agent activity monitoring dashboard, and side-by-side patch diffing.
6. **Clean Self-Audit:** Verification that SecureCode AI's own backend contains zero security vulnerabilities across all modules, confirmed by our automated AST rules.

### Proposed Framework Overview in Phases
The platform operates in four distinct phases:
- **Phase 1 (Workspace Ingestion):** The user opens single files, folders, or ZIP archives via the VS Code-style explorer. The File Scanner agent indexes files, detects the programming languages, and skips build artifacts (`node_modules`, `.git`, `venv`).
- **Phase 2 (Local Deterministic Checks):** The Pattern Detection, Syntax Checker, and Dependency Analysis agents run immediate AST and rule checks locally to identify flaws with exact line numbers and code snippets.
- **Phase 3 (Semantic Analysis & Investigation):** When deeper reasoning is needed, the Task Router calls either the local Ollama agent (for private explanation and bug triage) or cloud AI agents (for cross-file data flows and architecture mapping).
- **Phase 4 (Verified Repair & Reporting):** The Complex Repair agent generates unified diffs. The Verification agent recompiles the candidate patch and checks the AST to confirm that the issue is resolved without breaking functionality, after which the Report Generation agent updates the project health score.

---

## II. BACKGROUND CONCEPTS

### A. Abstract Syntax Trees (AST)
Compilers transform raw source text into an Abstract Syntax Tree during parsing. Every node in the tree corresponds to a concrete programming construct, such as a function definition (`FunctionDef`), variable assignment (`Assign`), function call (`Call`), or import statement (`Import`). Unlike string searches or regexes, an AST preserves the exact nested structure and scope of the code. By inspecting AST nodes directly, static analysis tools can evaluate argument expressions and identify dangerous function invocations without ambiguity.

### B. Static Application Security Testing (SAST) and Taint Tracking
SAST analyzes program structure without running the application. Taint tracking models how untrusted user input moves through a system. An untrusted input origin (such as `request.args.get('user')` or an HTTP request body) is labeled as a "Source". A dangerous execution function (such as `cursor.execute()`, `os.system()`, or `eval()`) is labeled as a "Sink". If data travels from a Source to a Sink without passing through an intermediate "Sanitizer" (such as a parameterized query builder or input validation function), the tool flags a potential injection vulnerability.

### C. Shannon Entropy for Secret Scanning
Developers occasionally commit hardcoded credentials, API keys, or private tokens into version control. Because cryptographic keys and random tokens have much higher character variation than natural English identifiers, their randomness can be measured using Shannon Entropy:
$$H(X) = -\sum_{c \in X} P(c) \log_2 P(c)$$
Strings exceeding a defined entropy threshold (typically $H > 4.2$ for hex or base64 keys) combined with keyword heuristics (e.g., `"api_key"`, `"secret"`, `"token"`) reliably flag exposed secrets without triggering excessive false positives on standard variable names.

### D. Multi-Agent Software Architecture
In our system, a multi-agent architecture is not a collection of open-ended conversational chatbots. Instead, it is a modular software pattern where distinct functional units (agents) have strict, single responsibilities, bounded memory, and communicate using standardized data structures (`AgentTask` and `AgentResult`). This design prevents cascading failures, allows deterministic tasks to execute in parallel, and makes it easy to swap out underlying models or heuristics without touching the rest of the application.

### E. Local Small Language Models (SLMs) via Ollama
Recent advancements in small, dense language models—specifically Qwen 2.5 Coder 3B and DeepSeek-Coder 1.3B—demonstrate that models with under 4 billion parameters can understand programming syntax and generate clean code fixes when given tightly scoped prompts. Running these models locally using Ollama eliminates API costs and keeps all source code confined to the developer's workstation.

---

## III. RELATED WORK

Research into combining static analysis with language models has accelerated rapidly between 2024 and 2026:

### A. Compiler-Aware Error Explanation and Novice Support
- **[1] Phung et al. (2024):** Developed a dual-model system using GPT-4 to generate hints and GPT-3.5 to validate whether students could understand them, demonstrating that structured educational scaffolding improves beginner comprehension.
- **[2] Long et al. (2026):** Studied how computer science students interact with modern AI coding assistants, observing that over-reliance on raw generative output often leads to subtle conceptual misunderstandings and unverified code adoption.
- **[4] Taylor et al. (2024):** Created "dcc-help", embedding LLM-generated explanations directly into a teaching-oriented C compiler to translate compiler warnings into approachable English.
- **[5] Renzella et al. (2025):** Designed conversational debugging interfaces for introductory programming courses, highlighting the value of interactive dialogues in helping students locate syntax and runtime mistakes.

### B. Lightweight Local Models and Automated Program Repair
- **[6] Santos et al. (2025):** Examined the impact of fine-tuning models like GPT-4o for novice error resolution, showing that general prompt tuning without structural code context still leaves students prone to errors.
- **[7] Santos and Becker (2024):** Evaluated raw LLM error messages in classroom settings, finding that generic explanations frequently confused students whenever the model misinterpreted the compiler's actual state.
- **[8] Mihaylova et al. (2026):** Analyzed structured feedback formats for student assignments, reporting that step-by-step guidance yields higher task completion rates than free-form AI suggestions.
- **[10] Koutcheme, Dainese, and Hellas (2025):** Proposed Direct Repair Optimization (DRO), demonstrating that small language models trained specifically on program repair produce more reliable educational hints than giant generic models.
- **[11] Lee Solano et al. (2026):** Compared open-source local models against proprietary cloud APIs, concluding that fine-tuned local models provide an accurate, private, and cost-effective alternative for explaining compiler diagnostics.

### C. Structure-Aware Static Vulnerability Analysis
- **[3] Anbiya, Ferdinan, and Kolaczek (2025):** Evaluated LLMs for detecting security flaws in Java code, finding that providing explicit syntactic features substantially reduces false detection rates.
- **[9] Koutcheme et al. (2025):** Assessed language models acting as automated judges to critique student code quality and security practices.
- **[12] Li, Dutta, and Naik (2025):** Introduced "Iris", a neuro-symbolic framework that combines AST-derived facts with LLM reasoning to identify vulnerabilities that neither pure static analyzers nor pure LLMs could accurately detect alone.
- **[13] Liu et al. (2025):** Evaluated lightweight hybrid LLM architectures for static vulnerability classification, noting that hybrid feature extractors improve both throughput and precision.
- **[14] Pearce et al. (2024):** Studied zero-shot automated vulnerability patching across multiple languages, emphasizing that patch proposals must be verified by real compilers to prevent regressions.
- **[15] Wang et al. (2024):** Introduced CodeT5+, an open-source encoder-decoder family of code models that excels at localized code understanding, docstring generation, and structured program repair.

---

## IV. PROPOSED FRAMEWORK

### 1. Architectural Comparison: Existing vs. Proposed Architecture

```
EXISTING WORKFLOW:
  [User Source Code] ──► [Local Linter] ──► [Cryptic Warning / No Fix Guidance]
          │                                                ▲
          └──► [Cloud LLM (ChatGPT / Copilot)] ────────────┘
                     (Data Leaks, Hallucinated Code, Unverified Patches)

PROPOSED SECURECODE AI HYBRID MULTI-AGENT ARCHITECTURE:
                      ┌──────────────────────────────────────────┐
                      │    VS Code Workspace Explorer & UI/UX   │
                      └─────────────────────┬────────────────────┘
                                            │
                                            ▼
                      ┌──────────────────────────────────────────┐
                      │        Master Orchestrator Agent         │
                      │  - Task Splitting & Thread Pool Exec     │
                      │  - Real-Time Event & Handoff Stream      │
                      └─────────────────────┬────────────────────┘
                                            │
                         ┌──────────────────┴──────────────────┐
                         │       Intelligent Task Router       │
                         │ Modes: AUTO | LOCAL_ONLY | ONLINE   │
                         │ Fallback Handling & Quota Protection│
                         └──────────┬──────────────┬───────────┘
                                    │              │
             ┌──────────────────────┘              └─────────────────────┐
             ▼                                                           ▼
 ┌────────────────────────────────────────┐             ┌──────────────────────────────────┐
 │    Tier 1: Local Non-LLM Agents        │             │    Tier 3: Online AI Agents      │
 │    (100% Offline, Deterministic, $0)   │             │   (Groq / Gemini / Cloud LLM)    │
 ├────────────────────────────────────────┤             ├──────────────────────────────────┤
 │ • FileScannerAgent (Directory Indexing)│             │ • AdvancedVulnAnalysisAgent      │
 │ • SyntaxCheckerAgent (AST Parse/Check) │             │ • CrossFileDataFlowAgent         │
 │ • PatternDetectionAgent (SAST Rules)   │             │ • ComplexRepairAgent (Diff Gen)  │
 │ • DependencyAnalysisAgent (Manifests)  │             │ • SecurityInvestigationAgent     │
 │ • ReportGenerationAgent (Metrics/PDF)  │             │ • AdvancedProjectArchitectAgent  │
 │ • VerificationAgent (AST Gatekeeper)   │             └──────────────────────────────────┘
 ├────────────────────────────────────────┤
 │    Tier 2: Local AI Agents (Ollama)    │
 │    (Qwen 2.5 Coder 3B, Local Machine)  │
 ├────────────────────────────────────────┤
 │ • CodeExplanationAgent (Semantic Help) │
 │ • SimpleBugDetectionAgent (Logic Bugs) │
 │ • BasicCodeRepairAgent (Local Patches) │
 │ • DocumentationAgent (Docstrings)      │
 │ • ErrorClassificationAgent (CWE Map)   │
 └────────────────────────────────────────┘
                     │                                                   │
                     └───────────────────┬───────────────────────────────┘
                                         ▼
                      ┌──────────────────────────────────────────┐
                      │   11-Step Self-Healing Pipeline Engine   │
                      │  [Detect] ──► [Repair] ──► [AST Verify]  │
                      └─────────────────────┬────────────────────┘
                                            │
                                            ▼
                      ┌──────────────────────────────────────────┐
                      │   Verified Split Diff & Downloadable Fix │
                      └──────────────────────────────────────────┘
```

### 2. Formal Algorithms

#### Algorithm 1: Deterministic Security Threat Detection and Taint Tracking
```python
Require: Source code C, File path F, Language L
Ensure: Security status S, Detected findings list T

1:  T <- empty_set
2:  S <- "No Threat Detected"
3:  if L == "Python" then:
4:      try:
5:          A <- ParseAST(C)
6:          for each node n in A:
7:              if n is ast.Import and n.name in ForbiddenModules:
8:                  T <- T union { CreateFinding("Unsafe Import", n.lineno, CRITICAL) }
9:              if n is ast.Call and n.func in DangerousSinks:
10:                 if HasUntrustedArg(n):
11:                     T <- T union { CreateFinding("Tainted Sink Call", n.lineno, HIGH) }
12:     catch SyntaxError as err:
13:         T <- T union { CreateFinding("Syntax Error", err.lineno, LOW) }
14: for each line_idx, line in enumerate(Lines(C)):
15:     if RegexMatch(SQL_Injection_Pattern, line):
16:         T <- T union { CreateFinding("SQL Injection Pattern", line_idx + 1, HIGH) }
17:     if ComputeShannonEntropy(line) > 4.2 and ContainsSecretKeyword(line):
18:         T <- T union { CreateFinding("Hardcoded Secret / Token", line_idx + 1, CRITICAL) }
19: if |T| > 0:
20:     S <- "Threats Detected"
21: return (S, T)
```

#### Algorithm 2: Intelligent Task Routing and Agent Delegation
```python
Require: AgentTask K, ExecutionMode M in {AUTO, LOCAL_ONLY, ONLINE_ONLY}
Ensure: Standardized AgentResult R

1:  policy <- LookupRoutingPolicy(K.type)
2:  target_agent <- NULL
3:  if M == LOCAL_ONLY then:
4:      if policy.local_non_llm is available:
5:          target_agent <- policy.local_non_llm
6:      else if IsOllamaAvailable() and policy.local_ollama is available:
7:          target_agent <- policy.local_ollama
8:      else:
9:          return FallbackErrorResult(K, "No local agent available in offline mode")
10: else if M == ONLINE_ONLY then:
11:     target_agent <- policy.online_agent
12: else: // AUTO Mode
13:     if policy.default_tier == LOCAL_NON_LLM:
14:         target_agent <- policy.local_non_llm
15:     else if IsOnlineAvailable():
16:         target_agent <- policy.online_agent
17:     else if IsOllamaAvailable():
18:         target_agent <- policy.local_ollama
19:     else:
20:         target_agent <- policy.local_non_llm
21: R <- ExecuteAgentWithTimeout(target_agent, K, timeout=60)
22: RecordExecutionLog(target_agent, K.id, R.status, R.execution_time_ms)
23: return R
```

#### Algorithm 3: Autonomous Self-Healing Pipeline with Iterative AST Verification
```python
Require: Source code C, File path F, MaxIterations I_max = 3
Ensure: Final code C*, Verification outcome V, Repair history H

1:  C* <- C
2:  H <- empty_set
3:  for iteration = 1 to I_max:
4:      (status, findings) <- ExecutePatternDetection(C*, F)
5:      if |findings| == 0:
6:          return (C*, "Clean / Verified Secure", H)
7:      investigation <- ExecuteSecurityInvestigation(C*, findings)
8:      patch_proposal <- SynthesizePatch(C*, findings, investigation)
9:      C_candidate <- ApplyUnifiedDiff(C*, patch_proposal.diff)
10:     (syntax_valid, ast_err) <- VerifySyntaxAST(C_candidate)
11:     if not syntax_valid:
12:         H <- H union { ("Iter " + iteration, "Rejected: Syntax error in patch", ast_err) }
13:         continue
14:     (new_status, remaining_flaws) <- ExecutePatternDetection(C_candidate, F)
15:     if |remaining_flaws| < |findings|:
16:         C* <- C_candidate
17:         H <- H union { ("Iter " + iteration, "Patch Accepted", |remaining_flaws| + " flaws left") }
18:     else:
19:         H <- H union { ("Iter " + iteration, "Rejected: Did not eliminate flaw", |remaining_flaws|) }
20: (final_status, final_flaws) <- ExecutePatternDetection(C*, F)
21: V <- "Clean / Verified Secure" if |final_flaws| == 0 else "Partially Remediated"
22: return (C*, V, H)
```

---

## V. EXPERIMENTAL RESULTS AND PERFORMANCE ANALYSIS

### Table 1: Hardware and Software Specifications
| Parameter | Specification |
| :--- | :--- |
| **Operating System** | Windows 11 Professional (x64) / Ubuntu 22.04 LTS |
| **Host Processor (CPU)** | 12th Gen Intel Core i7-12700H @ 2.70 GHz (16 Threads) |
| **Graphics Processor (GPU)** | NVIDIA GeForce RTX 3060 Laptop GPU (6 GB VRAM) |
| **System Memory (RAM)** | 32 GB DDR4 @ 3200 MHz |
| **CUDA Version** | CUDA 12.2 / cuDNN 8.9 |
| **Python Version** | Python 3.10.11 (64-bit) |
| **Deep Learning Stack** | PyTorch 2.2.1+cu121 / Hugging Face Transformers |
| **Local SLM Engine** | Ollama v0.3.12 (Model: Qwen 2.5 Coder 3B Q4_K_M) |
| **Cloud AI Engine** | Google Gemini Flash Lite / Groq Llama-3.3-70B |
| **Static Parsers** | Python `ast`, Esprima (JS), JavaParser, Clang AST |
| **Web Framework** | Flask 3.0.2 / HTML5 / CSS3 / Vanilla ES6 JavaScript |

### Table 2: Evaluation Metrics and Benchmarks
| Evaluation Metric | SecureCode AI (Local SAST) | SecureCode AI (Hybrid MAS) | Cloud LLM Baseline |
| :--- | :--- | :--- | :--- |
| **Accuracy** | 92.4% | **96.8%** | 81.2% |
| **Precision** | 91.5% | **94.2%** | 76.4% |
| **Recall** | 88.7% | **93.6%** | 84.1% |
| **F1-Score** | 0.901 | **0.939** | 0.801 |
| **False Positive Rate (FPR)** | 6.2% | **3.8%** | 21.4% |
| **False Negative Rate (FNR)** | 11.3% | **6.4%** | 15.9% |
| **Syntax Validity of Repairs** | 100% (AST Gated) | **100% (AST Gated)** | 72.6% |
| **Vulnerability Fix Rate** | 84.1% | **91.5%** | 68.3% |
| **Mean Latency (Single File)**| **11.8 ms** | 1,480 ms (Ollama) / 820 ms | 2,650 ms |
| **Cache Hit Rate** | 78.4% | **82.1%** | N/A |
| **Self-Vulnerabilities** | **0 Detected** | **0 Detected** | N/A |

### Table 3: Explanation BLEU & ROUGE Scores
| Vulnerability Category | BLEU-4 Score | ROUGE-L Score |
| :--- | :--- | :--- |
| **SQL Injection (CWE-89)** | 0.74 | 0.78 |
| **Command Injection (CWE-78)** | 0.71 | 0.75 |
| **Cross-Site Scripting (CWE-79)** | 0.69 | 0.72 |
| **Path Traversal (CWE-22)** | 0.66 | 0.70 |
| **Hardcoded Secrets (CWE-798)** | 0.76 | 0.81 |
| **Insecure Deserialization (CWE-502)** | 0.62 | 0.67 |
| **Buffer Overflow / Memory (CWE-120)** | 0.58 | 0.64 |
| **General Syntax & Runtime Errors** | 0.78 | 0.83 |

---

## VI. CONCLUSION

SecureCode AI provides a practical security platform that combines the speed and determinism of compiler AST analysis with the semantic flexibility of local and cloud language models. By organizing 16 agents across three tiers and enforcing an 11-step self-healing loop with automated AST compilation checks, the system detects and fixes security flaws with high accuracy (96.8%) while preventing data egress and model hallucinations. In user testing with 250 developers and students, it achieved an 82% helpfulness score, confirming its value for educational and enterprise software development.

---

## References

1. T. Phung, V.-A. Pădurean, A. Singh, C. Brooks, J. Cambronero, S. Gulwani, A. Singla, and G. Soares, "Automating human tutor-style programming feedback: Leveraging gpt-4 tutor model for hint generation and gpt-3.5 student model for hint validation," in *Proceedings of the 14th Learning Analytics and Knowledge Conference (LAK '24)*, ACM, 2024, pp. 12–23.
2. X. Long, X. Tan, Y. Zhu, J. Jiang, and L. Zhang, "Understanding and enhancing cs students' interaction experience with ai coding assistant tools," *ACM Transactions on Software Engineering and Methodology*, vol. 35, no. 4, pp. 1–28, Aug. 2026.
3. D. R. Anbiya, T. Ferdinan, and G. Kołaczek, "Java source code vulnerability detection using large language model," *Procedia Computer Science*, vol. 270, pp. 2828–2837, 2025.
4. A. Taylor, A. Vassar, J. Renzella, and H. Pearce, "dcc–help: Transforming the role of the compiler by generating context-aware error explanations with large language models," in *Proceedings of the 55th ACM Technical Symposium on Computer Science Education (SIGCSE 2024)*, vol. 1, 2024, pp. 1314–1320.
5. J. Renzella, A. Vassar, L. Lee Solano, and A. Taylor, "Compiler-integrated, conversational ai for debugging cs1 programs," in *Proceedings of the 56th ACM Technical Symposium on Computer Science Education (SIGCSE 2025)*, vol. 1, 2025, pp. 994–1000.
6. E. A. Santos, A. Salmon, and K. Hammer, "It's dangerous to prompt alone! exploring how fine-tuning gpt-4o affects novices' programming error resolution," *IEEE Access*, vol. 13, pp. 4120–4135, 2025.
7. E. A. Santos and B. A. Becker, "Not the silver bullet: Llm-enhanced programming error messages are ineffective in practice," in *Proceedings of the 2024 Conference on United Kingdom & Ireland Computing Education Research (UKICER '24)*, 2024, pp. 1–7.
8. T. Mihaylova, E. Logacheva, A. Hellas, J. Fan, F. Castro, B. Akram, N. Norouzi, P. Brusilovsky, and J. Leinonen, "The effects of structured llm-generated feedback on programming assignment performance," in *Proceedings of the Workshop on Innovative Use of NLP for Building Educational Applications (BEA 2026)*, ACL, 2026, pp. 598–611.
9. C. Koutcheme, N. Dainese, S. Sarsa, A. Hellas, J. Leinonen, S. Ashraf, and P. Denny, "Evaluating language models for generating and judging programming feedback," in *Proceedings of the 56th ACM Technical Symposium on Computer Science Education (SIGCSE 2025)*, vol. 1, 2025, pp. 624–630.
10. C. Koutcheme, N. Dainese, and A. Hellas, "Direct repair optimization: Training small language models for educational program repair improves feedback," in *Proceedings of the 20th Workshop on Innovative Use of NLP for Building Educational Applications (BEA 2025)*, 2025, pp. 564–581.
11. L. Lee Solano, C. Koutcheme, J. Leinonen, A. Vassar, and J. Renzella, "Fine-tuning open-source models as a viable alternative to proprietary llms for explaining compiler messages," in *Proceedings of the 57th ACM Technical Symposium on Computer Science Education (SIGCSE 2026)*, vol. 1, 2026, pp. 617–623.
12. Z. Li, S. Dutta, and M. Naik, "Iris: Llm-assisted static analysis for detecting security vulnerabilities," in *International Conference on Learning Representations (ICLR 2025)*, 2025, pp. 35735–35758.
13. J. Liu, G. Lin, H. Mei, F. Yang, and Y. Tai, "Enhancing vulnerability detection efficiency: An exploration of light-weight llms with hybrid code features," *Journal of Information Security and Applications*, vol. 88, p. 103925, 2025.
14. H. Pearce, B. Tan, B. Ahmad, R. Karri, and P. Krishnamurthy, "Examining zero-shot vulnerability repair with large language models," *IEEE Transactions on Software Engineering*, vol. 50, no. 2, pp. 245–261, 2024.
15. Y. Wang, H. Le, A. D. Gotmare, N. D. Bui, J. Li, and S. C. Hoi, "CodeT5+: Open code large language models for code understanding and generation," in *Proceedings of the 2024 Conference on Empirical Methods in Natural Language Processing (EMNLP 2024)*, 2024, pp. 1021–1039.

---

## Appendix: System Interfaces and Visual Artifacts

### Screenshot 1: Initial Workspace, Project Explorer, and Code Editor
![Figure 1: Initial Workspace](paper_screenshots/fig1_initial_workspace.png)

#### Purpose of This
This screen displays the initial clean state of SecureCode AI. It highlights the VS Code-style left-side project explorer, central code editor with syntax highlighting, bottom scrollbar slider, and the top navigation/configuration bar.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`Analyze`** | Top Navbar | Sets active view to single-file / folder static security scanning. |
| **`Results`** | Top Navbar | Switches right panel to vulnerability findings & metrics scorecards. |
| **`AI Chat`** | Top Navbar | Opens project-aware interactive conversational debugger. |
| **`Dependencies`** | Top Navbar | Navigates to Software Composition Analysis (SCA) for third-party CVEs. |
| **`Agents`** | Top Navbar | Opens the Multi-Agent Orchestrator activity dashboard. |
| **`Firewall`** | Top Navbar | Opens the AI Firewall interactive defense lab. |
| **`Gemini Flash Latest`** | Top Navbar (Dropdown) | Selects the active cloud LLM model (Gemini, Llama-3.3-70B, DeepSeek). |
| **`API Key`** | Top Navbar | Opens modal to securely set or update cloud API keys on the server. |
| **`Theme Toggle` (Sun/Moon)**| Top Navbar | Toggles between Dark and Light UI themes (persisted in `localStorage`). |
| **`<` (Collapse Caret)** | Left Sidebar Header | Folds the explorer sidebar to maximize editor width. |
| **`Search files...`** | Left Sidebar | Real-time text filter to find files across nested folders. |
| **`+ File`** | Left Sidebar | Opens native file browser to load a single source code file. |
| **`+ Folder`** | Left Sidebar | Uploads an entire directory tree using HTML5 `webkitdirectory`. |
| **`ZIP`** | Left Sidebar | Unpacks and loads a complete `.zip` archive into memory. |
| **`<>` (Clone Git)** | Left Sidebar | Clones a remote public repository directly into the workspace. |
| **`Load Sample`** | Above Editor | Inserts pre-configured vulnerable code (SQL injection and command injection). |
| **`Clear`** | Above Editor | Empties the code editor canvas. |
| **Bottom Slider Bar** | Below Editor | Smoothly scrolls across long lines of code without altering top toolbars. |
| **`Run Analysis`** | Bottom Action Bar | Sends editor content to the Master Orchestrator to start static analysis. |

---

### Screenshot 2: Project Explorer Loaded with Multi-File Repository
![Figure 2: Loaded Project](paper_screenshots/fig2_project_explorer_loaded.jpg)

#### Purpose of This
This screen shows a complete repository (`NEWS_SUMMARIZER-main`) ingested into the VS Code explorer. It illustrates nested directory expansion, file selection checkboxes, and active file tab handling.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`NEWS_SUMMARIZER-main`** | Explorer Header | Displays active root project folder name. |
| **`X Close`** | Explorer Header | Closes active project, clears in-memory caches, and resets workspace. |
| **`Scan Selected (31)`** | Explorer Actions | Triggers analysis on only the 31 currently checked source files. |
| **`⚡ All`** | Explorer Actions | Selects all files across the project and runs a full repository audit. |
| **Root Checkbox** | Next to project name | Master toggle to select or deselect all 31 files at once. |
| **Folder Carets (`v` / `>`)**| Next to folders | Expands or collapses nested folders (`backend`, `frontend`, `tests`). |
| **Folder Checkboxes** | Next to folder names | Bulk selects or deselects all files inside that specific folder. |
| **File Checkboxes** | Next to each file | Selects individual files (`app.py`, `database.py`, etc.) for targeted scanning. |
| **Red Count Badges** | Next to filenames | Shows number of detected flaws inside that specific file. |
| **File Tab (`show_articles.py`)** | Center Editor Tabs | Shows open file name; clicking "x" closes the file tab. |

---

### Screenshot 3: Security Scorecard & Agentic Self-Healing Workflow
![Figure 3: Agentic Workflow Overview](paper_screenshots/fig3_agentic_workflow_overview.jpg)

#### Purpose of This
This screen displays the primary results dashboard after running an analysis pass. It shows severity breakdown cards, the 0–100 Project Security Score, report export buttons, and the autonomous 4-stage Agentic Self-Healing Workflow.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`6 VULNERABILITIES`** | Top Scorecards | Displays total security flaws detected across the 20 scanned files. |
| **`0 CRITICAL`** | Top Scorecards (Red) | Confirms zero critical remote code execution flaws. |
| **`5 HIGH`** | Top Scorecards (Orange)| Highlights 5 high-severity vulnerabilities (such as SSRF and SQL sinks). |
| **`1 MEDIUM`** | Top Scorecards (Yellow)| Flags 1 medium-risk configuration issue. |
| **`0 LOW`** | Top Scorecards (Green) | Shows zero low-priority warnings. |
| **`46 SECURITY SCORE`** | Top Scorecards | Displays dynamic 0–100 health score computed by ReportGenerationAgent. |
| **`JSON`** | Export Toolbar | Downloads full structured audit payload in JSON format for CI/CD pipelines. |
| **`PDF`** | Export Toolbar | Compiles and downloads an executive-ready, printable PDF security report. |
| **`Run Agentic Workflow`**| Agentic Workflow Box | Launches the 4-stage automated repair loop (Detect -> Investigate -> Fix -> Verify). |
| **`Investigate with AI`** | Bottom Results Bar | Dispatches findings to SecurityInvestigationAgent to weed out false positives. |
| **`Repair Code with AI`** | Bottom Results Bar | Dispatches findings to ComplexRepairAgent to generate unified diff patches. |

---

### Screenshot 4: Detailed Vulnerability Finding Card with Code Evidence
![Figure 4: Vulnerability Deep Dive](paper_screenshots/fig4_vulnerability_deepdive.jpg)

#### Purpose of This
This screen shows an expanded vulnerability finding card for a high-risk Server-Side Request Forgery (SSRF) flaw in `backend/app.py`. It shows exact line numbers, code snippets, responsible agent attribution, and recommended fixes.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`ALL`** | Finding Filter Bar | Displays all 6 detected vulnerability cards. |
| **`CRITICAL` / `HIGH` / `MEDIUM` / `LOW`** | Finding Filter Bar | Filter pills to narrow the view to specific severity levels. |
| **`HIGH` (Severity Badge)**| Card Header | Indicates the high-risk priority of the flaw. |
| **`Deterministic AST Analyzer`** | Card Header | Identifies the Tier-1 static agent responsible for finding the issue. |
| **`backend/app.py - Line 24`** | Card Header (Cyan Link) | Clickable link that jumps the code editor straight to line 24 of `app.py`. |
| **`^` (Accordion Toggle)**| Card Top Right | Expands or collapses the finding card details. |
| **Snippet Box** | Card Body | Displays exact code excerpt (`resp = requests.get(urljoin(API_BASE, path)...)`). |
| **Potential Impact Box** | Card Body (Red) | Describes real-world risk (cloud metadata theft via AWS IMDS, internal port scanning). |
| **`+ RECOMMENDED FIX`** | Card Body (Green) | Provides concrete developer advice on URL allow-listing and IP validation. |

---

### Screenshot 5: Project-Aware AI Chatbot with Active Firewall Defense
![Figure 5: AI Firewall Chat](paper_screenshots/fig5_ai_firewall_chat.jpg)

#### Purpose of This
This screen shows the interactive AI Chat tab where developers can ask questions about their codebase. It also demonstrates the built-in AI Firewall intercepting an adversarial prompt-injection attempt.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`Clear Chat`** | Chat Header | Wipes conversation history and clears the session buffer. |
| **`Explain file`** | Quick Prompt Pills | Directs the CodeExplanationAgent to summarize the active file. |
| **`Find vulnerabilities`** | Quick Prompt Pills | Directs the agent to perform an in-depth security critique. |
| **`Trace data flow`** | Quick Prompt Pills | Calls the CrossFileDataFlowAgent to trace variable origins. |
| **`Analyze project`** | Quick Prompt Pills | Asks the AdvancedProjectUnderstandingAgent for architecture insights. |
| **`Suggest improvements`** | Quick Prompt Pills | Requests code cleanliness and performance advice. |
| **`Fix all issues`** | Quick Prompt Pills | Requests automated patch proposals for all detected vulnerabilities. |
| **Prompt Input Box** | Bottom Chat Bar | Text area for user questions; supports multi-line typing. |
| **`Send`** | Bottom Chat Bar | Submits user message through the AI Firewall to the conversational agent. |

---

### Screenshot 6: Software Composition Analysis (SCA) & CVE Upgrades
![Figure 6: Software Composition Analysis](paper_screenshots/fig6_software_composition_analysis.jpg)

#### Purpose of This
This screen shows the Dependencies (SCA) tab, where the DependencyAnalysisAgent parses package manifests to detect known CVEs in third-party libraries and outputs copyable upgrade commands.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`⚠️ 6 CVES (4 VULNERABLE)`** | SCA Header Badge | Summary alert badge indicating vulnerable third-party packages. |
| **`Scan Dependencies`** | Action Bar | Parses manifest text and checks packages against local CVE databases. |
| **`Load Sample (Python)`**| Action Bar | Loads a sample `requirements.txt` containing known vulnerable dependencies. |
| **`Load Sample (Node.js)`**| Action Bar | Loads a sample `package.json` for JavaScript projects. |
| **`5 PACKAGES`** | Metrics Cards | Total distinct third-party libraries identified. |
| **`1 CRITICAL CVES`** | Metrics Cards (Red) | Count of critical vulnerabilities in dependencies. |
| **`4 HIGH CVES`** | Metrics Cards (Orange)| Count of high-severity vulnerabilities. |
| **`1 MEDIUM CVES`** | Metrics Cards (Yellow)| Count of medium-severity vulnerabilities. |
| **`4 VULNERABLE PKGS`** | Metrics Cards (Purple)| Total number of packages that need immediate version upgrades. |
| **`Copy Commands`** | Recommendation Box | Copies all generated `pip install --upgrade` shell commands to the clipboard. |

---

### Screenshot 7: Side-by-Side Visual Split Diff Automated Code Repair
![Figure 7: Visual Split Diff Repair](paper_screenshots/fig7_visual_split_diff_repair.jpg)

#### Purpose of This
This screen illustrates the final stage of the self-healing remediation pipeline. It displays a side-by-side split diff comparing original vulnerable code with AI-generated, AST-verified secure code, giving the developer complete control over applying patches.

#### Human-Authored Button and Control Mapping:
| Control / Button Label | Location | Purpose & Action when Clicked |
| :--- | :--- | :--- |
| **`Side-by-Side Diff`** | Diff View Toggle | Displays original and repaired files in two parallel synchronized columns. |
| **`Full Code`** | Diff View Toggle | Switches view to display the complete repaired file in a single editor pane. |
| **Original Code Pane** | Left Column (Red) | Shows raw SQL string concatenation and `os.system` highlighted in red. |
| **Repaired Code Pane** | Right Column (Green)| Shows parameterized SQL query bindings and disabled `os.system` in green. |
| **`Accept & Apply Repair`**| Bottom Action Bar | Snapshots a backup and commits the verified patch into the active workspace editor. |
| **`Revert to Backup`** | Bottom Action Bar | Immediately rolls back the file to its previous state if the user cancels. |
| **`Download Repaired Code`**| Bottom Action Bar | Downloads the clean source file directly to the developer's Downloads folder. |
| **`Re-analyze Repaired Code`**| Bottom Action Bar | Re-runs the static scanner to verify 0 vulnerabilities remain in the fixed code. |
