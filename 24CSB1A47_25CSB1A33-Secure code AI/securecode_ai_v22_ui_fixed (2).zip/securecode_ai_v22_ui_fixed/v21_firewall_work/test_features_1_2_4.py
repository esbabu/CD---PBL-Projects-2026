import unittest
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from app import app, _analyze_source
from secret_scanner import scan_secrets
from dependency_scanner import scan_dependencies

class TestFeatures124AndZeroVulnerabilities(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_feature_1_secret_scanning(self):
        # Scan code with embedded secrets
        code = '''
import os
AWS_ACCESS = "AKIA1234567890ABCDEF"
STRIPE_KEY = "sk_live_1234567890abcdef12345678"
def connect():
    pass
'''
        res = _analyze_source(code, "config.py")
        self.assertTrue(res["success"])
        vulns = res.get("vulnerabilities", [])
        secret_findings = [v for v in vulns if v.get("category") == "Hard-coded Secret"]
        self.assertGreaterEqual(len(secret_findings), 2)
        rules = [v.get("rule_violated") for v in secret_findings]
        self.assertIn("SEC-AWS-KEY", rules)
        self.assertIn("SEC-STRIPE-KEY", rules)
        # Ensure secret is masked
        for sf in secret_findings:
            self.assertIn("*", sf.get("evidence", ""))

    def test_feature_2_dependency_scanning_endpoint(self):
        reqs = "requests==2.20.0\nurllib3==1.24.2\nflask==2.0.0"
        res = self.client.post('/scan-dependencies', json={
            "content": reqs,
            "filename": "requirements.txt"
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["manifest_type"], "Python (requirements.txt)")
        self.assertGreater(data["total_cves"], 0)
        self.assertIn("requests", data["recommended_upgrades"])
        self.assertGreater(len(data["upgrade_commands"]), 0)

    def test_feature_2_scan_manifest_via_analyze(self):
        # Directly analyze requirements.txt
        reqs = "requests==2.20.0\njinja2==3.0.0"
        res = _analyze_source(reqs, "requirements.txt")
        self.assertTrue(res["success"])
        self.assertIn("sca_report", res)
        self.assertGreater(res["summary"]["total_vulnerabilities"], 0)

    def test_self_security_production_code_is_clean(self):
        # Check production modules: app.py, groq_agent.py, broad_security_analyzer.py, etc.
        prod_files = [
            "ai_firewall.py", "app.py", "ast_traverser.py", "broad_security_analyzer.py",
            "demo_programs.py", "dependency_scanner.py", "groq_agent.py", "main.py",
            "module1_input_detection.py", "module2_rule_engine.py", "module3_warning_logic.py",
            "multilang_security_analyzer.py", "ollama_agent.py", "project_graph.py",
            "python_ast_bridge.py", "secret_scanner.py", "unified_types.py"
        ]
        base_dir = os.path.dirname(__file__)
        for fname in prod_files:
            fpath = os.path.join(base_dir, fname)
            if not os.path.exists(fpath):
                continue
            with open(fpath, "r", encoding="utf-8") as f:
                src = f.read()
            res = _analyze_source(src, fname)
            vulns = res.get("vulnerabilities", [])
            self.assertEqual(len(vulns), 0, f"Production file {fname} has unexpected vulnerabilities: {vulns}")

if __name__ == "__main__":
    unittest.main()
