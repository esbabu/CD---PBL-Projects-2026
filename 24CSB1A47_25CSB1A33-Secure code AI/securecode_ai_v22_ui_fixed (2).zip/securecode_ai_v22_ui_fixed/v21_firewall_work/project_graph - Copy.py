"""Best-effort, non-executing cross-file relationship analysis for SecureCode.

Builds import/call relationships, detects unused functions, identifies broken local imports,
classifies project architecture (frontend, backend, database, security/auth, utility),
and reports candidate source-to-sink paths for review.
"""
import os
import re
from collections import defaultdict

SOURCE_PATTERNS = re.compile(
    r"\b(request\.(?:args|form|values|json|data|query_params)|req\.(?:body|query|params)|"
    r"input\s*\(|getParameter\s*\(|Scanner\s*\(|process\.argv|argv\s*\[|"
    r"getenv\s*\()", re.I)
SINK_PATTERNS = re.compile(
    r"\b(execute\s*\(|exec\s*\(|eval\s*\(|system\s*\(|popen\s*\(|"
    r"Runtime\.getRuntime\s*\(|innerHTML\s*=|writeFile(?:Sync)?\s*\(|open\s*\()", re.I)

IMPORT_PATTERNS = [
    re.compile(r"^\s*from\s+([\w.]+)\s+import\s+(.+)", re.M),
    re.compile(r"^\s*import\s+([\w., *]+)", re.M),
    re.compile(r"\b(?:import|require\s*\()\s*[\"']([^\"']+)[\"']", re.M),
    re.compile(r"^\s*#include\s*[<\"]([^>\"]+)[>\"]", re.M),
]
DEF_PATTERNS = [
    re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(", re.M),
    re.compile(r"^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(", re.M),
    re.compile(r"^\s*(?:public|private|protected|static|final|\s)+[\w<>\[\],.?]+\s+(\w+)\s*\([^;]*\)\s*(?:\{|throws|$)", re.M),
    re.compile(r"^\s*(?:[\w:*&<>]+\s+)+([A-Za-z_]\w*)\s*\([^;]*\)\s*(?:\{|$)", re.M),
]

# Architecture classification heuristics
BACKEND_HINTS = re.compile(
    r"(@\w+\.route\b|\bexpress\s*\(|\bapp\.(?:get|post|put|delete|patch|use)\s*\(|"
    r"@(?:Rest)?Controller\b|@(?:Get|Post|Put|Delete)Mapping\b|urlpatterns\s*=|\bhttp\.createServer\b|"
    r"\bFastAPI\s*\(|\bAPIRouter\s*\(|\bFlask\s*\()", re.I)
DATABASE_HINTS = re.compile(
    r"(\bSELECT\s+.+\s+FROM\b|\bINSERT\s+INTO\b|\bUPDATE\s+.+\s+SET\b|\bDELETE\s+FROM\b|"
    r"\b(?:sqlite3|psycopg2|pymysql|mysql\.connector|cx_Oracle|sqlalchemy|prisma|mongoose)\b|"
    r"\bmodels\.Model\b|\bcreate_engine\b|\bcursor\.(?:execute|fetchall)\b|\bEntityManager\b|"
    r"\bCrudRepository\b|\bJpaRepository\b|\bDbContext\b)", re.I)
FRONTEND_HINTS = re.compile(
    r"(<!DOCTYPE\s+html|<html\b|document\.getElementById|addEventListener|"
    r"import\s+React\b|from\s+['\"]react['\"]|className\s*=|vue|angular|svelte|"
    r"render_template\s*\(|res\.render\s*\()", re.I)
SECURITY_HINTS = re.compile(
    r"(\bjwt\b|\bbcrypt\b|\bhashlib\b|\bpasslib\b|\bsecrets\b|\bcrypto\b|"
    r"\bauthenticate\b|\blogin_required\b|\bOAuth\b|\bApiKey\b|\bhash_password\b|"
    r"\bverify_password\b|\btoken_hex\b|\bHMAC\b)", re.I)


def _module_candidates(import_name, current_path, known_paths):
    token = import_name.replace('\\', '/').strip()
    if token.startswith('.'):
        base = os.path.normpath(os.path.join(os.path.dirname(current_path), token))
    else:
        base = token.replace('.', '/')
    candidates = {base, base + '.py', base + '.js', base + '.jsx', base + '.mjs', base + '.cjs', base + '.java', base + '.h', base + '.hpp', base + '.c', base + '.cpp'}
    found = []
    for path in known_paths:
        norm = path.replace('\\', '/')
        stem = os.path.splitext(norm)[0]
        if norm in candidates or stem == base or stem.endswith('/' + base) or any(norm.endswith('/' + c) for c in candidates):
            found.append(norm)
    return sorted(set(found))


def _classify_file(path: str, source: str) -> str:
    """Classify a file into an architectural tier."""
    ext = os.path.splitext(path.lower())[1]
    if ext in {'.html', '.htm', '.jsx', '.tsx', '.vue', '.svelte', '.css'}:
        return 'frontend'
    if SECURITY_HINTS.search(source):
        return 'security_auth'
    if BACKEND_HINTS.search(source):
        return 'backend'
    if DATABASE_HINTS.search(source):
        return 'database'
    if FRONTEND_HINTS.search(source):
        return 'frontend'
    return 'utility'


def analyze_project_graph(file_sources):
    """file_sources: {relative_path: source}; returns imports, symbols, calls, architecture and heuristic flows."""
    paths = sorted(file_sources)
    imports = []
    broken_imports = []
    functions = defaultdict(list)
    source_files = []
    sink_files = []
    source_lines = {}
    sink_lines = {}
    architecture = {}

    for path, source in file_sources.items():
        architecture[path] = _classify_file(path, source)
        found_imports = set()
        for pattern in IMPORT_PATTERNS:
            for match in pattern.finditer(source):
                raw = match.group(1).strip()
                names = [x.strip() for x in raw.split(',') if x.strip()]
                for name in names:
                    resolved = _module_candidates(name, path, paths)
                    if resolved:
                        for target in resolved:
                            if target != path:
                                found_imports.add(target)
                    else:
                        # Check if this looks like a broken local import (e.g. relative import ./ or ../)
                        if name.startswith('.') or name.startswith('./') or name.startswith('../'):
                            broken_imports.append({
                                'file': path,
                                'import': name,
                                'reason': f'Local target module "{name}" not found in project files.'
                            })

        for target in sorted(found_imports):
            imports.append({'from': path, 'to': target, 'type': 'import'})

        defined = set()
        for pattern in DEF_PATTERNS:
            defined.update(pattern.findall(source))
        for name in sorted(defined):
            # Skip dunder/internal methods
            if not name.startswith('__'):
                functions[name].append(path)

        src = [i for i, line in enumerate(source.splitlines(), 1) if SOURCE_PATTERNS.search(line)]
        snk = [i for i, line in enumerate(source.splitlines(), 1) if SINK_PATTERNS.search(line)]
        if src:
            source_files.append(path); source_lines[path] = src
        if snk:
            sink_files.append(path); sink_lines[path] = snk

    import_targets = defaultdict(set)
    for edge in imports:
        import_targets[edge['from']].add(edge['to'])

    call_edges = []
    called_functions = set()

    def _is_called_in(fn_name: str, src: str) -> bool:
        # Strip function definition line so a definition is not counted as a call
        stripped = re.sub(r'^\s*(?:async\s+)?(?:def|function)\s+' + re.escape(fn_name) + r'\s*\(', '', src, flags=re.M)
        stripped = re.sub(r'^\s*(?:public|private|protected|static|final|\s)+[\w<>\[\],.?]+\s+' + re.escape(fn_name) + r'\s*\(', '', stripped, flags=re.M)
        return bool(re.search(r'(?<![.\w])' + re.escape(fn_name) + r'\s*\(', stripped))

    for caller, source in file_sources.items():
        for name, owners in functions.items():
            if _is_called_in(name, source):
                called_functions.add(name)
                if caller in owners:
                    continue
                valid_owners = [owner for owner in owners if owner in import_targets[caller]]
                if valid_owners:
                    for owner in valid_owners:
                        call_edges.append({'from': caller, 'to': owner, 'function': name, 'type': 'call'})

    # Identify unused functions (defined in project, but never called in any file)
    unused_functions = []
    for name, owners in functions.items():
        if name not in called_functions:
            # Exclude standard framework entrypoints / test functions
            if name not in {'main', 'init', 'setup', 'index', 'run', 'handler', 'test'} and not name.startswith('test_'):
                for owner in owners:
                    unused_functions.append({'name': name, 'file': owner})

    flows = []
    call_pairs = {(e['from'], e['to']) for e in call_edges}
    for source_path in source_files:
        connected = set(import_targets[source_path])
        connected.update(dst for src, dst in call_pairs if src == source_path)
        for sink_path in sink_files:
            if sink_path == source_path or sink_path in connected:
                flows.append({
                    'source_file': source_path,
                    'source_lines': source_lines[source_path][:8],
                    'sink_file': sink_path,
                    'sink_lines': sink_lines[sink_path][:8],
                    'confidence': 'low' if sink_path != source_path else 'medium',
                    'note': 'Heuristic source/sink relationship; inspect actual variable flow before treating as a vulnerability.'
                })

    # Architectural tier summary
    tier_counts = defaultdict(int)
    for tier in architecture.values():
        tier_counts[tier] += 1

    return {
        'imports': imports,
        'call_edges': sorted(call_edges, key=lambda e: (e['from'], e['to'], e['function'])),
        'functions': [{'name': name, 'files': sorted(set(owners))} for name, owners in sorted(functions.items())],
        'dataflow_candidates': flows,
        'broken_imports': broken_imports[:20],
        'unused_functions': unused_functions[:30],
        'architecture': architecture,
        'architecture_summary': dict(tier_counts),
        'graph_summary': {
            'files_indexed': len(paths),
            'import_edges': len(imports),
            'cross_file_call_edges': len(call_edges),
            'source_files': len(source_files),
            'sink_files': len(sink_files),
            'dataflow_candidates': len(flows),
            'unused_functions_count': len(unused_functions),
            'broken_imports_count': len(broken_imports),
        },
        'limitations': 'Import, call and data-flow relationships are heuristic and language-agnostic. Dynamic imports, aliases, macros, overloads, reflection and precise variable-level propagation may be missed.'
    }
