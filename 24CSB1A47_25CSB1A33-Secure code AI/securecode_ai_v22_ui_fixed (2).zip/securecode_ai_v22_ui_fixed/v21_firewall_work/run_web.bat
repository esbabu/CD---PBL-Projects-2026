@echo off
echo ============================================
echo   SecureCode AI — Intelligent Security Platform
echo ============================================
echo.

cd /d "%~dp0"

REM Free port 5000 if a previous instance is still running
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :5000 ^| findstr LISTENING') do (
    echo [*] Closing previous instance on port 5000 (PID %%a)...
    taskkill /F /PID %%a >nul 2>&1
)

REM If .env exists in current directory or parent, it will be loaded automatically by Python
if exist ".env" (
    echo [*] Loaded configuration from .env
) else if exist "..\.env" (
    echo [*] Loaded configuration from parent .env
)

echo [*] Starting SecureCode AI on http://localhost:5000
echo [*] Press Ctrl+C to stop the server.
echo.

python app.py
pause
