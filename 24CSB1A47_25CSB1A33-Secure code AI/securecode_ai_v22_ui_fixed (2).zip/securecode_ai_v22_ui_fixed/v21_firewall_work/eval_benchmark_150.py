import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from broad_security_analyzer import analyze_source as analyze_py
from multilang_security_analyzer import analyze_source as analyze_multi
from secret_scanner import scan_secrets

BASE_DIR = os.path.join(os.path.dirname(__file__), "benchmark_150_dataset")

tp, fp, tn, fn = 0, 0, 0, 0

print("Evaluating 150 Benchmark Test Cases with SecureCode AI Analyzer...\n")

for i in range(1, 151):
    matched_files = [f for f in os.listdir(BASE_DIR) if f.startswith(f"tc_{i:03d}_")]
    if not matched_files:
        continue
    fname = matched_files[0]
    fpath = os.path.join(BASE_DIR, fname)
    is_vuln_expected = (i <= 130)

    with open(fpath, "r", encoding="utf-8") as f:
        code = f.read()

    findings = []
    if fname.endswith(".py"):
        findings.extend(analyze_py(code, fname))
        findings.extend(scan_secrets(code, fname))
    elif fname.endswith((".js", ".java", ".c")):
        lang = "JavaScript" if fname.endswith(".js") else ("Java" if fname.endswith(".java") else "C")
        findings.extend(analyze_multi(code, fname, language=lang))
        findings.extend(scan_secrets(code, fname))

    has_detected = len(findings) > 0

    if is_vuln_expected:
        if has_detected:
            tp += 1
        else:
            fn += 1
            print(f"[-] False Negative (Missed): {fname}")
    else:
        if has_detected:
            fp += 1
            print(f"[!] False Positive (False Alarm): {fname} -> {[x.get('category') for x in findings]}")
        else:
            tn += 1

total = tp + fp + tn + fn
accuracy = (tp + tn) / total * 100
precision = tp / (tp + fp) * 100 if (tp + fp) else 0
recall = tp / (tp + fn) * 100 if (tp + fn) else 0
f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) else 0

print("\n" + "=" * 60)
print(f"EVALUATION RESULTS ACROSS {total} FILES:")
print("=" * 60)
print(f"True Positives (Vulnerabilities Correctly Detected): {tp} / 130")
print(f"True Negatives (Clean Files Correctly Passed):       {tn} / 20")
print(f"False Positives (Clean Files Incorrectly Flagged):   {fp} / 20")
print(f"False Negatives (Vulnerable Files Missed):           {fn} / 130")
print("-" * 60)
print(f"Accuracy:  {accuracy:.2f}%")
print(f"Precision: {precision:.2f}%")
print(f"Recall:    {recall:.2f}%")
print(f"F1-Score:  {f1/100:.3f}")
print("=" * 60)
