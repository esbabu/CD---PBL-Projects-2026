"""Regression tests for the broad security pass."""
import os
import sys
import unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from broad_security_analyzer import analyze_source
from python_ast_bridge import PythonASTBridge
from unified_types import SymbolTable
from module1_input_detection import InputDetectionModule
from module2_rule_engine import RuleEngineModule
from module3_warning_logic import WarningDecisionLogic
from ast_traverser import ASTTraverser

VULNERABLE = r'''
from flask import request, Flask, render_template_string
import subprocess, os, pickle, requests, jwt, hashlib, tempfile, yaml
app = Flask(__name__)
@app.route("/search")
def search():
    q = request.args.get("q")
    query = "SELECT * FROM users WHERE name = '" + q + "'"
    cursor.execute(query)
    os.system("grep " + q)
    subprocess.run("ping " + q, shell=True)
    return q
def bad(data):
    eval(data)
    pickle.loads(data)
    requests.get("http://internal/" + data)
    render_template_string("<h1>" + data + "</h1>")
    hashlib.md5(data.encode())
    tempfile.mktemp()
    jwt.decode(data, "secret", options={"verify_signature": False})
    yaml.load(data)
    return data
PASSWORD = "SuperSecretPassword123"
app.run(debug=True)
requests.get("https://example.com", verify=False)
'''

SAFE = r'''
from flask import Flask, request
import subprocess, sqlite3, yaml, secrets
app = Flask(__name__)
@app.route("/search")
def search():
    user_id = request.args.get("id")
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    subprocess.run(["grep", "--", "fixed-value"], shell=False)
    token = secrets.token_urlsafe(32)
    return {"token": token}
def parse(data):
    return yaml.safe_load(data)
'''

class BroadSecurityTests(unittest.TestCase):
    def test_broad_categories(self):
        findings = analyze_source(VULNERABLE, "vulnerable.py")
        categories = {f["category"] for f in findings}
        expected = {
            "SQL Injection", "Command Injection", "Code Injection",
            "Unsafe Deserialization", "SSRF", "Cross-Site Scripting",
            "Weak Cryptography", "Insecure File Handling",
            "Authentication / JWT", "Secrets",
            "Security Misconfiguration", "Transport Security",
        }
        self.assertTrue(expected.issubset(categories), (expected - categories, categories))

    def test_safe_examples(self):
        findings = analyze_source(SAFE, "safe.py")
        bad_categories = {
            f["category"] for f in findings
            if f["category"] in {"SQL Injection", "Command Injection", "Unsafe Deserialization"}
        }
        self.assertEqual(bad_categories, set(), findings)

    def test_additional_filesystem_crypto_and_config_patterns(self):
        source = '''
import os, random, tempfile, zipfile
from Crypto.Cipher import AES
from flask_cors import CORS

def more(user_path, token):
    open("/tmp/" + user_path, "w")
    os.remove(user_path)
    tempfile.mktemp()
    random.choice(["token", token])
    AES.new(b"1234567890123456", AES.MODE_ECB)

CORS(app, origins="*")
zipfile.ZipFile("x.zip").extractall("/tmp/out")
'''
        findings = analyze_source(source, "more.py")
        categories = {f["category"] for f in findings}
        self.assertIn("Path Traversal", categories)
        self.assertIn("Insecure File Handling", categories)
        self.assertIn("Weak Cryptography", categories)
        self.assertIn("Security Misconfiguration", categories)
        self.assertIn("Weak Randomness", categories)

    def test_original_pipeline_still_detects_sql(self):
        source = 'user = input("id: ")\nquery = "SELECT * FROM users WHERE id = " + user\ncursor.execute(query)\n'
        root = PythonASTBridge().parse_source(source, "<test>")
        symbols = SymbolTable()
        detector = InputDetectionModule(symbols)
        engine = RuleEngineModule(symbols)
        warnings = WarningDecisionLogic(symbols)
        stats = ASTTraverser(detector, engine, warnings, symbols).analyze(root)
        self.assertEqual(stats["vulnerabilities"], 1)
        self.assertEqual(warnings.warnings[0].vulnerability_id, "SQLI-0001")

if __name__ == "__main__":
    unittest.main(verbosity=2)
