import os
import zipfile

def create_docx(filename: str, title: str, sections: list):
    """
    Creates a valid Microsoft Word (.docx) file with proper OpenXML formatting,
    including headings, bullet points, tables, and callout boxes.
    """
    # OpenXML boilerplate
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    doc_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    styles = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>
        <w:sz w:val="22"/>
        <w:color w:val="2D3748"/>
      </w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:rPr>
      <w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>
      <w:b/>
      <w:sz w:val="44"/>
      <w:color w:val="1A365D"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:rPr>
      <w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>
      <w:b/>
      <w:sz w:val="32"/>
      <w:color w:val="2B6CB0"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:rPr>
      <w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>
      <w:b/>
      <w:sz w:val="26"/>
      <w:color w:val="2D3748"/>
    </w:rPr>
  </w:style>
</w:styles>"""

    # Build document body
    body_xml = ['<w:body>']
    
    # Title
    body_xml.append(f"""
    <w:p>
      <w:pPr><w:pStyle w:val="Title"/><w:jc w:val="center"/><w:spacing w:after="300"/></w:pPr>
      <w:r><w:t>{title}</w:t></w:r>
    </w:p>
    """)

    for sec in sections:
        sec_type = sec.get("type", "paragraph")
        if sec_type == "h1":
            body_xml.append(f"""
            <w:p>
              <w:pPr><w:pStyle w:val="Heading1"/><w:spacing w:before="360" w:after="160"/></w:pPr>
              <w:r><w:t>{sec['text']}</w:t></w:r>
            </w:p>""")
        elif sec_type == "h2":
            body_xml.append(f"""
            <w:p>
              <w:pPr><w:pStyle w:val="Heading2"/><w:spacing w:before="240" w:after="120"/></w:pPr>
              <w:r><w:t>{sec['text']}</w:t></w:r>
            </w:p>""")
        elif sec_type == "p":
            body_xml.append(f"""
            <w:p>
              <w:pPr><w:spacing w:after="140"/><w:line w:line="276" w:lineRule="auto"/></w:pPr>
              <w:r><w:t>{sec['text']}</w:t></w:r>
            </w:p>""")
        elif sec_type == "bullet":
            body_xml.append(f"""
            <w:p>
              <w:pPr><w:ind w:left="400" w:hanging="200"/><w:spacing w:after="80"/></w:pPr>
              <w:r><w:rPr><w:b/></w:rPr><w:t>• </w:t></w:r>
              <w:r><w:t>{sec['text']}</w:t></w:r>
            </w:p>""")
        elif sec_type == "box":
            bg_color = sec.get("color", "EDF2F7")
            border_color = sec.get("border", "CBD5E0")
            body_xml.append(f"""
            <w:tbl>
              <w:tblPr>
                <w:tblW w:w="9600" w:type="dxa"/>
                <w:tblBorders>
                  <w:top w:val="single" w:sz="12" w:space="0" w:color="{border_color}"/>
                  <w:left w:val="single" w:sz="18" w:space="0" w:color="{border_color}"/>
                  <w:bottom w:val="single" w:sz="12" w:space="0" w:color="{border_color}"/>
                  <w:right w:val="single" w:sz="12" w:space="0" w:color="{border_color}"/>
                </w:tblBorders>
                <w:tblCellMar>
                  <w:top w:w="160" w:type="dxa"/>
                  <w:left w:w="240" w:type="dxa"/>
                  <w:bottom w:w="160" w:type="dxa"/>
                  <w:right w:w="240" w:type="dxa"/>
                </w:tblCellMar>
              </w:tblPr>
              <w:tr>
                <w:tc>
                  <w:tcPr>
                    <w:tcW w:w="9600" w:type="dxa"/>
                    <w:shd w:val="clear" w:color="auto" w:fill="{bg_color}"/>
                  </w:tcPr>
                  <w:p>
                    <w:pPr><w:spacing w:after="80"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:color w:val="1A365D"/><w:sz w:val="24"/></w:rPr><w:t>{sec.get('title', '')}</w:t></w:r>
                  </w:p>
                  <w:p>
                    <w:pPr><w:spacing w:after="0"/></w:pPr>
                    <w:r><w:t>{sec.get('body', '')}</w:t></w:r>
                  </w:p>
                </w:tc>
              </w:tr>
            </w:tbl>
            <w:p><w:pPr><w:spacing w:after="160"/></w:pPr></w:p>
            """)

    body_xml.append('</w:body>')
    doc_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  {''.join(body_xml)}
</w:document>"""

    with zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', content_types)
        z.writestr('_rels/.rels', rels)
        z.writestr('word/_rels/document.xml.rels', doc_rels)
        z.writestr('word/styles.xml', styles)
        z.writestr('word/document.xml', doc_xml)

    print(f"Created Word Document successfully: {filename}")

if __name__ == "__main__":
    create_docx("v21_firewall_work/test_gen.docx", "Test Doc", [{"type": "p", "text": "Testing"}])
