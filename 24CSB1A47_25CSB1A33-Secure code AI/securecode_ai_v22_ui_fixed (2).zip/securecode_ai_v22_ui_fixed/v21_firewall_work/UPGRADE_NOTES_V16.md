# SecureCode AI V16 — Local Ollama integration

- Added `ollama_agent.py` for a local Ollama chat call plus a second evidence-verification pass.
- Added `/ollama-status` and `/ai-investigate` Flask endpoints.
- Added the UI action “Investigate with Local AI”, status indicator, and separate AI finding panel.
- Default model is `qwen2.5-coder:3b`; model and local API endpoint can be configured with environment variables.
- Preserved the existing deterministic analysis pipeline, folder/ZIP/GitHub scans, project graph, and existing frontend workspace.
- AI results are advisory and do not modify source code.
- Current limitation: the AI action accepts a single source file, not a whole project.

## V17 — AI repair proposals with change explanations

- Added `POST /ai-repair`, backed by the configured local Ollama model.
- AI proposes a complete repaired source file; the server never executes it or overwrites the original.
- The application computes actual added/removed/modified line ranges with Python `difflib.SequenceMatcher` rather than trusting AI-supplied line numbers.
- A second model call explains each bounded change group with reason, security benefit, and vulnerability addressed.
- Added UI controls to inspect the diff and full repaired code, download the proposal, and re-run static analysis against it.
- The validation result is advisory: disappearance of a finding does not prove the program is secure. Review changes and run appropriate tests.
- Repair currently operates on one source file at a time. Project-wide and multi-file coordinated repair are not implemented.
- Requires Ollama reachable at the configured local endpoint and the configured model installed (default `qwen2.5-coder:3b`).
