import os
import json

BASE_DIR = os.path.join(os.path.dirname(__file__), "benchmark_150_dataset")
os.makedirs(BASE_DIR, exist_ok=True)

testcases = []

def add_tc(idx, filename, lang, cwe, cat, is_vuln, desc, code):
    testcases.append({
        "id": idx,
        "filename": filename,
        "language": lang,
        "cwe_id": cwe,
        "category": cat,
        "is_vulnerable": is_vuln,
        "description": desc,
        "code": code.strip()
    })

# ─────────────────────────────────────────────────────────────────────────────
# 1. SQL INJECTION (CWE-89) - 10 Test Cases (tc_001 to tc_010)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(1, "tc_001_cwe89_sqli_raw_concat.py", "Python", "CWE-89", "SQL Injection", True,
       "Raw string concatenation in SQLite cursor.execute",
"""from flask import request
import sqlite3

def get_user():
    user = request.args.get('user')
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE name = '" + user + "'"
    cursor.execute(query)
    return cursor.fetchall()
""")

add_tc(2, "tc_002_cwe89_sqli_fstring.py", "Python", "CWE-89", "SQL Injection", True,
       "F-string interpolation inside SQL query execution",
"""from flask import request
import sqlite3

def delete_user():
    uid = request.form.get('uid')
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM accounts WHERE id = {uid}")
    conn.commit()
""")

add_tc(3, "tc_003_cwe89_sqli_percent_format.py", "Python", "CWE-89", "SQL Injection", True,
       "Percent formatting with untrusted user input in SQL statement",
"""import MySQLdb
from flask import request

def search_products():
    term = request.args.get('search')
    db = MySQLdb.connect(host="localhost", user="root", db="shop")
    c = db.cursor()
    c.execute("SELECT * FROM items WHERE title LIKE '%%%s%%'" % term)
    return c.fetchall()
""")

add_tc(4, "tc_004_cwe89_sqli_format_method.py", "Python", "CWE-89", "SQL Injection", True,
       "str.format() used to build dynamic SQL query string",
"""import sqlite3
from flask import request

def get_orders():
    order_id = request.args.get('order_id')
    conn = sqlite3.connect('store.db')
    q = "SELECT * FROM orders WHERE id = '{}'".format(order_id)
    return conn.cursor().execute(q).fetchall()
""")

add_tc(5, "tc_005_cwe89_sqli_orm_raw.py", "Python", "CWE-89", "SQL Injection", True,
       "Raw SQL fragment passed to ORM raw query helper",
"""from flask import request
from django.db import connection

def filter_by_role():
    role = request.args.get('role')
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM user_roles WHERE role_name = '" + role + "'")
        return cursor.fetchall()
""")

add_tc(6, "tc_006_cwe89_sqli_second_order.py", "Python", "CWE-89", "SQL Injection", True,
       "Query concatenation with variable retrieved from untrusted request headers",
"""import sqlite3
from flask import request

def log_session():
    auth_header = request.headers.get('X-User-ID')
    conn = sqlite3.connect('audit.db')
    conn.cursor().execute("INSERT INTO audit_log (user_id) VALUES ('" + auth_header + "')")
    conn.commit()
""")

add_tc(7, "tc_007_cwe89_sqli_node_pg.js", "JavaScript", "CWE-89", "SQL Injection", True,
       "Node.js pg client raw query concatenation",
"""const express = require('express');
const { Client } = require('pg');
const app = express();

app.get('/user', async (req, res) => {
    const client = new Client();
    await client.connect();
    const query = "SELECT * FROM profiles WHERE username = '" + req.query.username + "'";
    const result = await client.query(query);
    res.json(result.rows);
});
""")

add_tc(8, "tc_008_cwe89_sqli_node_mysql.js", "JavaScript", "CWE-89", "SQL Injection", True,
       "Template literal interpolation in Node mysql query",
"""const mysql = require('mysql2');
function fetchAccount(accountId, db) {
    db.query(`SELECT * FROM bank_accounts WHERE acc_num = ${accountId}`, (err, rows) => {
        console.log(rows);
    });
}
""")

add_tc(9, "tc_009_cwe89_sqli_java_jdbc.java", "Java", "CWE-89", "SQL Injection", True,
       "Java JDBC Statement concatenation without PreparedStatement",
"""import java.sql.*;
import javax.servlet.http.*;

public class UserSearchServlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws Exception {
        String name = req.getParameter("name");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "");
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE name = '" + name + "'");
    }
}
""")

add_tc(10, "tc_010_cwe89_sqli_c_sqlite.c", "C", "CWE-89", "SQL Injection", True,
       "C sprintf building SQL query passed to sqlite3_exec",
"""#include <stdio.h>
#include <sqlite3.h>

void lookup_user(sqlite3 *db, const char *untrusted_input) {
    char sql[512];
    sprintf(sql, "SELECT * FROM users WHERE user='%s';", untrusted_input);
    sqlite3_exec(db, sql, NULL, NULL, NULL);
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# 2. OS COMMAND INJECTION (CWE-78) - 10 Test Cases (tc_011 to tc_020)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(11, "tc_011_cwe78_cmdinj_os_system.py", "Python", "CWE-78", "Command Injection", True,
       "os.system called with untrusted query parameter",
"""import os
from flask import request

def ping_host():
    ip = request.args.get('ip')
    os.system("ping -c 1 " + ip)
""")

add_tc(12, "tc_012_cwe78_cmdinj_popen_shell_true.py", "Python", "CWE-78", "Command Injection", True,
       "subprocess.Popen with shell=True and concatenated command string",
"""import subprocess
from flask import request

def view_logs():
    filename = request.args.get('filename')
    cmd = f"cat /var/log/app/{filename}"
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    return proc.communicate()[0]
""")

add_tc(13, "tc_013_cwe78_cmdinj_subprocess_call.py", "Python", "CWE-78", "Command Injection", True,
       "subprocess.call with shell=True and user input",
"""import subprocess
from flask import request

def nslookup_service():
    domain = request.form.get('domain')
    subprocess.call("nslookup " + domain, shell=True)
""")

add_tc(14, "tc_014_cwe78_cmdinj_os_popen.py", "Python", "CWE-78", "Command Injection", True,
       "os.popen with concatenated shell command string",
"""import os
from flask import request

def list_directory():
    path = request.args.get('path')
    stream = os.popen(f"ls -la {path}")
    return stream.read()
""")

add_tc(15, "tc_015_cwe78_cmdinj_subprocess_check_output.py", "Python", "CWE-78", "Command Injection", True,
       "subprocess.check_output with formatted command line",
"""import subprocess
from flask import request

def convert_pdf():
    doc = request.args.get('doc')
    subprocess.check_output(f"soffice --headless --convert-to pdf {doc}", shell=True)
""")

add_tc(16, "tc_016_cwe78_cmdinj_node_exec.js", "JavaScript", "CWE-78", "Command Injection", True,
       "Node.js child_process.exec with untrusted argument",
"""const { exec } = require('child_process');
const express = require('express');
const app = express();

app.post('/compress', (req, res) => {
    const file = req.body.filepath;
    exec("gzip " + file, (err, stdout) => {
        res.send("Compressed");
    });
});
""")

add_tc(17, "tc_017_cwe78_cmdinj_node_execSync.js", "JavaScript", "CWE-78", "Command Injection", True,
       "Node child_process.execSync with template literal command",
"""const { execSync } = require('child_process');

function runBackup(target) {
    execSync(`tar -czf backup.tar.gz ${target}`);
}
""")

add_tc(18, "tc_018_cwe78_cmdinj_java_runtime.java", "Java", "CWE-78", "Command Injection", True,
       "Java Runtime.getRuntime().exec with command concatenation",
"""import java.io.*;

public class DiagnosticService {
    public void pingHost(String untrustedIp) throws Exception {
        Runtime.getRuntime().exec("ping -c 2 " + untrustedIp);
    }
}
""")

add_tc(19, "tc_019_cwe78_cmdinj_java_processbuilder.java", "Java", "CWE-78", "Command Injection", True,
       "Java ProcessBuilder invoking sh -c with concatenated argument",
"""public class ShellExecutor {
    public void executeCommand(String userParam) throws Exception {
        ProcessBuilder pb = new ProcessBuilder("sh", "-c", "echo " + userParam);
        pb.start();
    }
}
""")

add_tc(20, "tc_020_cwe78_cmdinj_c_system.c", "C", "CWE-78", "Command Injection", True,
       "C system() function called with formatted buffer",
"""#include <stdlib.h>
#include <stdio.h>

void delete_cache_file(const char *filename) {
    char cmd[256];
    sprintf(cmd, "rm -f /tmp/cache/%s", filename);
    system(cmd);
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# 3. CODE INJECTION & DYNAMIC EVAL (CWE-94) - 8 Test Cases (tc_021 to tc_028)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(21, "tc_021_cwe94_eval_untrusted.py", "Python", "CWE-94", "Code Injection", True,
       "eval() executed directly on user input",
"""from flask import request

def calculate():
    expression = request.args.get('expr')
    return str(eval(expression))
""")

add_tc(22, "tc_022_cwe94_exec_untrusted.py", "Python", "CWE-94", "Code Injection", True,
       "exec() running untrusted Python script dynamically",
"""from flask import request

def run_script():
    user_code = request.form.get('code')
    exec(user_code)
""")

add_tc(23, "tc_023_cwe94_eval_in_dict_comprehension.py", "Python", "CWE-94", "Code Injection", True,
       "Dynamic eval inside dictionary transformation loop",
"""from flask import request

def parse_config():
    raw_dict = request.json.get('filters', {})
    parsed = {k: eval(v) for k, v in raw_dict.items()}
    return parsed
""")

add_tc(24, "tc_024_cwe94_node_eval.js", "JavaScript", "CWE-94", "Code Injection", True,
       "Node.js eval() evaluating untrusted formula",
"""function computeFormula(userFormula) {
    return eval(userFormula);
}
""")

add_tc(25, "tc_025_cwe94_node_function_constructor.js", "JavaScript", "CWE-94", "Code Injection", True,
       "JavaScript new Function constructor from user string",
"""function createDynamicAction(actionBody) {
    const fn = new Function('req', 'res', actionBody);
    return fn;
}
""")

add_tc(26, "tc_026_cwe94_node_settimeout_code.js", "JavaScript", "CWE-94", "Code Injection", True,
       "setTimeout called with string code execution",
"""function scheduleAction(untrustedCode) {
    setTimeout(untrustedCode, 1000);
}
""")

add_tc(27, "tc_027_cwe94_java_scriptengine.java", "Java", "CWE-94", "Code Injection", True,
       "Java ScriptEngineManager evaluating untrusted script string",
"""import javax.script.*;

public class FormulaEngine {
    public Object evaluate(String formula) throws Exception {
        ScriptEngineManager mgr = new ScriptEngineManager();
        ScriptEngine engine = mgr.getEngineByName("JavaScript");
        return engine.eval(formula);
    }
}
""")

add_tc(28, "tc_028_cwe94_python_ast_literal_abuse.py", "Python", "CWE-94", "Code Injection", True,
       "compile() and exec() invoked on untrusted code buffer",
"""from flask import request

def dynamic_runner():
    payload = request.data.decode('utf-8')
    compiled = compile(payload, '<string>', 'exec')
    exec(compiled)
""")

# ─────────────────────────────────────────────────────────────────────────────
# 4. CROSS-SITE SCRIPTING (CWE-79) - 10 Test Cases (tc_029 to tc_038)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(29, "tc_029_cwe79_xss_render_template_string.py", "Python", "CWE-79", "Cross-Site Scripting", True,
       "Flask render_template_string with unescaped variable insertion",
"""from flask import request, render_template_string

def welcome_page():
    name = request.args.get('name', 'Guest')
    template = f"<h1>Welcome, {name}!</h1>"
    return render_template_string(template)
""")

add_tc(30, "tc_030_cwe79_xss_markupsafe_markup.py", "Python", "CWE-79", "Cross-Site Scripting", True,
       "markupsafe.Markup explicitly wrapping tainted user parameter",
"""from flask import request
from markupsafe import Markup

def render_comment():
    comment = request.form.get('comment')
    safe_comment = Markup(comment)
    return f"<div class='comment'>{safe_comment}</div>"
""")

add_tc(31, "tc_031_cwe79_xss_flask_markup.py", "Python", "CWE-79", "Cross-Site Scripting", True,
       "flask.Markup disabling HTML autoescaping on untrusted bio",
"""from flask import request, Markup

def profile_bio():
    bio = request.args.get('bio')
    return Markup("<p>" + bio + "</p>")
""")

add_tc(32, "tc_032_cwe79_xss_reflected_response.py", "Python", "CWE-79", "Cross-Site Scripting", True,
       "Direct reflected HTTP response without escaping",
"""from flask import request, Response

def echo_endpoint():
    text = request.args.get('msg', '')
    return Response("<div>User Message: " + text + "</div>", mimetype='text/html')
""")

add_tc(33, "tc_033_cwe79_xss_node_res_send.js", "JavaScript", "CWE-79", "Cross-Site Scripting", True,
       "Express res.send returning unescaped HTML content",
"""const express = require('express');
const app = express();

app.get('/search', (req, res) => {
    const term = req.query.q;
    res.send("<h2>Search results for: " + term + "</h2>");
});
""")

add_tc(34, "tc_034_cwe79_xss_node_innerhtml.js", "JavaScript", "CWE-79", "Cross-Site Scripting", True,
       "DOM-based XSS assigning location.hash to element.innerHTML",
"""function displayHashGreeting() {
    const hash = window.location.hash.substring(1);
    document.getElementById('greeting').innerHTML = "Welcome " + hash;
}
""")

add_tc(35, "tc_035_cwe79_xss_node_document_write.js", "JavaScript", "CWE-79", "Cross-Site Scripting", True,
       "document.write reflecting URL search parameters",
"""function outputParams() {
    const params = new URLSearchParams(window.location.search);
    document.write("<p>Query: " + params.get('q') + "</p>");
}
""")

add_tc(36, "tc_036_cwe79_xss_java_servlet_out.java", "Java", "CWE-79", "Cross-Site Scripting", True,
       "Java Servlet writing raw unescaped input to response writer",
"""import java.io.*;
import javax.servlet.http.*;

public class HelloServlet extends HttpServlet {
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String user = req.getParameter("user");
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<h1>Hello " + user + "</h1>");
    }
}
""")

add_tc(37, "tc_037_cwe79_xss_react_dangerously_set.js", "JavaScript", "CWE-79", "Cross-Site Scripting", True,
       "React dangerouslySetInnerHTML receiving unsanitized API property",
"""function Article({ content }) {
    return <div dangerouslySetInnerHTML={{ __html: content }} />;
}
""")

add_tc(38, "tc_038_cwe79_xss_template_raw_filter.py", "Python", "CWE-79", "Cross-Site Scripting", True,
       "Flask Jinja2 string rendering with explicit raw HTML output",
"""from flask import request, render_template_string

def show_notification():
    msg = request.args.get('alert')
    return render_template_string("<span>{{ msg | safe }}</span>", msg=msg)
""")

# ─────────────────────────────────────────────────────────────────────────────
# 5. PATH TRAVERSAL (CWE-22) - 10 Test Cases (tc_039 to tc_048)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(39, "tc_039_cwe22_path_traversal_open.py", "Python", "CWE-22", "Path Traversal", True,
       "open() reading arbitrary file with unsanitized filename",
"""from flask import request

def download_file():
    filename = request.args.get('file')
    with open('/var/www/uploads/' + filename, 'rb') as f:
        return f.read()
""")

add_tc(40, "tc_040_cwe22_path_traversal_shutil.py", "Python", "CWE-22", "Path Traversal", True,
       "shutil.copy moving untrusted source path",
"""import shutil
from flask import request

def move_user_file():
    src = request.args.get('source')
    shutil.copy(src, '/backup/storage/')
""")

add_tc(41, "tc_041_cwe22_path_traversal_os_remove.py", "Python", "CWE-22", "Path Traversal", True,
       "os.remove deleting file path provided in query parameter",
"""import os
from flask import request

def delete_report():
    doc = request.args.get('doc')
    os.remove('/data/reports/' + doc)
""")

add_tc(42, "tc_042_cwe22_path_traversal_zip_extractall.py", "Python", "CWE-22", "Path Traversal", True,
       "zipfile.extractall vulnerable to Zip Slip path traversal",
"""import zipfile

def unpack_archive(uploaded_zip):
    with zipfile.ZipFile(uploaded_zip, 'r') as zf:
        zf.extractall('/var/www/app/extracted/')
""")

add_tc(43, "tc_043_cwe22_path_traversal_tar_extractall.py", "Python", "CWE-22", "Path Traversal", True,
       "tarfile.extractall unpacking archive with untrusted member names",
"""import tarfile

def extract_tar(archive_path):
    with tarfile.open(archive_path) as tar:
        tar.extractall(path="/srv/data/")
""")

add_tc(44, "tc_044_cwe22_path_traversal_pathlib.py", "Python", "CWE-22", "Path Traversal", True,
       "pathlib.Path constructed from untrusted request argument",
"""from pathlib import Path
from flask import request

def read_text():
    user_file = request.args.get('path')
    p = Path("/app/static") / user_file
    return p.read_text()
""")

add_tc(45, "tc_045_cwe22_path_traversal_node_fs.js", "JavaScript", "CWE-22", "Path Traversal", True,
       "Node fs.readFile accessing unverified file path",
"""const fs = require('fs');
const path = require('path');

function getDocument(req, res) {
    const filename = req.query.file;
    fs.readFile(path.join('/public/docs', filename), (err, data) => {
        res.send(data);
    });
}
""")

add_tc(46, "tc_046_cwe22_path_traversal_node_unlink.js", "JavaScript", "CWE-22", "Path Traversal", True,
       "Node fs.unlinkSync deleting unvalidated parameter file",
"""const fs = require('fs');

function purgeFile(userPath) {
    fs.unlinkSync('/tmp/user_uploads/' + userPath);
}
""")

add_tc(47, "tc_047_cwe22_path_traversal_java_file.java", "Java", "CWE-22", "Path Traversal", True,
       "Java new File(parent, child) without canonical path verification",
"""import java.io.*;

public class FileDownloader {
    public FileInputStream getFile(String userFile) throws Exception {
        File f = new File("/safe/directory/", userFile);
        return new FileInputStream(f);
    }
}
""")

add_tc(48, "tc_048_cwe22_path_traversal_c_fopen.c", "C", "CWE-22", "Path Traversal", True,
       "C fopen opening concatenated path buffer with directory traversal",
"""#include <stdio.h>

FILE* open_log(const char *log_name) {
    char filepath[256];
    sprintf(filepath, "/var/log/%s", log_name);
    return fopen(filepath, "r");
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# 6. HARDCODED SECRETS & KEYS (CWE-798) - 15 Test Cases (tc_049 to tc_063)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(49, "tc_049_cwe798_aws_access_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Exposed AWS Access Key ID",
"""# Production AWS credentials
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
AWS_REGION = "us-east-1"
""")

add_tc(50, "tc_050_cwe798_stripe_live_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Hardcoded Stripe live secret API key",
"""import stripe

stripe.api_key = "sk_live_51Abcdefghijklmnopqrstuvwxy12345678"
""")

add_tc(51, "tc_051_cwe798_google_api_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Hardcoded Google / Gemini Cloud API key",
"""GEMINI_API_KEY = "AIzaSyD-1234567890abcdefghijklmnopqrstuv"
def fetch_model():
    pass
""")

add_tc(52, "tc_052_cwe798_github_token.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Exposed GitHub Personal Access Token",
"""GITHUB_TOKEN = "ghp_1234567890abcdefghijklmnopqrstuvwxyzAB"
""")

add_tc(53, "tc_053_cwe798_slack_webhook.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Exposed Slack Incoming Webhook URL",
"""SLACK_WEBHOOK = "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"
""")

add_tc(54, "tc_054_cwe798_openai_secret_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Exposed OpenAI API key string",
"""OPENAI_API_KEY = "sk-proj-1234567890abcdefghijklmnopqrstuvwxyz1234567890abcdefgh"
""")

add_tc(55, "tc_055_cwe798_groq_api_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Exposed Groq Cloud AI API key",
"""GROQ_KEY = "gsk_1234567890abcdefghijklmnopqrstuvwxyz1234567890abcdefghijkl"
""")

add_tc(56, "tc_056_cwe798_rsa_private_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Hardcoded RSA private key header block",
"""SERVER_PRIVATE_KEY = '''-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0Y1+examplekey1234567890abcdefghijklmnopqrstuvwx
-----END RSA PRIVATE KEY-----'''
""")

add_tc(57, "tc_057_cwe798_postgres_db_url.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "High-entropy database URI containing embedded password",
"""DATABASE_URL = "postgres://admin:Sup3rS3cr3tP@ssw0rd!@prod-db.internal:5432/main"
""")

add_tc(58, "tc_058_cwe798_high_entropy_secret.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Arbitrary high-entropy API token matching Shannon entropy > 4.2",
"""AUTH_SHARED_SECRET = "8fA7bC9dE2fG1hI3jK5lM7nO9pQ2rS4tU6vW"
""")

add_tc(59, "tc_059_cwe798_node_aws_key.js", "JavaScript", "CWE-798", "Hardcoded Secret", True,
       "Node.js AWS credential assignment",
"""const AWS = require('aws-sdk');
AWS.config.update({
    accessKeyId: "AKIA1111222233334444",
    secretAccessKey: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
});
""")

add_tc(60, "tc_060_cwe798_node_jwt_secret.js", "JavaScript", "CWE-798", "Hardcoded Secret", True,
       "Hardcoded JWT signing secret string in Express",
"""const jwt = require('jsonwebtoken');
const JWT_SECRET = "my_super_secret_production_signing_key_98765";
""")

add_tc(61, "tc_061_cwe798_java_db_password.java", "Java", "CWE-798", "Hardcoded Secret", True,
       "Java static database password string",
"""public class DatabaseConfig {
    public static final String DB_USER = "sa";
    public static final String DB_PASS = "SecretMasterPassword2026!";
}
""")

add_tc(62, "tc_062_cwe798_c_hardcoded_apikey.c", "C", "CWE-798", "Hardcoded Secret", True,
       "C string literal API key header",
"""#include <stdio.h>

const char *API_TOKEN = "sk-live-99887766554433221100aabbccddeeff";
void init_auth() {}
""")

add_tc(63, "tc_063_cwe798_flask_secret_key.py", "Python", "CWE-798", "Hardcoded Secret", True,
       "Flask app.secret_key hardcoded string",
"""from flask import Flask

app = Flask(__name__)
app.secret_key = "production_hardcoded_flask_session_secret_key_123"
""")

# ─────────────────────────────────────────────────────────────────────────────
# 7. UNSAFE DESERIALIZATION (CWE-502) - 8 Test Cases (tc_064 to tc_071)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(64, "tc_064_cwe502_pickle_loads.py", "Python", "CWE-502", "Unsafe Deserialization", True,
       "pickle.loads() deserializing untrusted HTTP request payload",
"""import pickle
from flask import request

def handle_session():
    cookie = request.cookies.get('session_data')
    return pickle.loads(cookie.encode())
""")

add_tc(65, "tc_065_cwe502_yaml_load_unsafe.py", "Python", "CWE-502", "Unsafe Deserialization", True,
       "yaml.load without SafeLoader allowing arbitrary object creation",
"""import yaml
from flask import request

def parse_yaml_config():
    raw_yaml = request.data
    return yaml.load(raw_yaml, Loader=yaml.Loader)
""")

add_tc(66, "tc_066_cwe502__pickle_load.py", "Python", "CWE-502", "Unsafe Deserialization", True,
       "_pickle.load loading object stream from network socket",
"""import _pickle
def process_data(sock):
    return _pickle.load(sock.makefile('rb'))
""")

add_tc(67, "tc_067_cwe502_shelve_open.py", "Python", "CWE-502", "Unsafe Deserialization", True,
       "shelve.open on untrusted user data file",
"""import shelve
def read_user_cache(path):
    with shelve.open(path) as db:
        return db.get('data')
""")

add_tc(68, "tc_068_cwe502_node_serialize.js", "JavaScript", "CWE-502", "Unsafe Deserialization", True,
       "node-serialize unserialize() executing serialized function",
"""const serialize = require('node-serialize');

function parseUserPayload(req, res) {
    const obj = serialize.unserialize(req.cookies.profile);
    res.json(obj);
}
""")

add_tc(69, "tc_069_cwe502_java_objectinputstream.java", "Java", "CWE-502", "Unsafe Deserialization", True,
       "Java ObjectInputStream.readObject() on untrusted network stream",
"""import java.io.*;

public class Deserializer {
    public Object readData(InputStream in) throws Exception {
        ObjectInputStream ois = new ObjectInputStream(in);
        return ois.readObject();
    }
}
""")

add_tc(70, "tc_070_cwe502_dill_loads.py", "Python", "CWE-502", "Unsafe Deserialization", True,
       "dill.loads unpacking arbitrary serialized Python closures",
"""import dill
from flask import request

def run_task():
    payload = request.data
    func = dill.loads(payload)
    return func()
""")

add_tc(71, "tc_071_cwe502_jsonpickle_decode.py", "Python", "CWE-502", "Unsafe Deserialization", True,
       "jsonpickle.decode instantiating arbitrary classes from JSON",
"""import jsonpickle
from flask import request

def restore_state():
    data = request.args.get('state')
    return jsonpickle.decode(data)
""")

# ─────────────────────────────────────────────────────────────────────────────
# 8. SERVER-SIDE REQUEST FORGERY (SSRF) (CWE-918) - 8 Test Cases (tc_072 to tc_079)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(72, "tc_072_cwe918_ssrf_requests_get.py", "Python", "CWE-918", "SSRF", True,
       "requests.get fetching arbitrary URL supplied by client",
"""import requests
from flask import request

def fetch_avatar():
    url = request.args.get('url')
    resp = requests.get(url, timeout=5)
    return resp.content
""")

add_tc(73, "tc_073_cwe918_ssrf_urllib_urlopen.py", "Python", "CWE-918", "SSRF", True,
       "urllib.request.urlopen accessing unvalidated destination",
"""import urllib.request
from flask import request

def proxy_endpoint():
    target = request.args.get('target')
    return urllib.request.urlopen(target).read()
""")

add_tc(74, "tc_074_cwe918_ssrf_httpx_get.py", "Python", "CWE-918", "SSRF", True,
       "httpx.get making outbound request to internal metadata endpoints",
"""import httpx
from flask import request

def check_site():
    site = request.form.get('site')
    return httpx.get(site).text
""")

add_tc(75, "tc_075_cwe918_ssrf_requests_post.py", "Python", "CWE-918", "SSRF", True,
       "requests.post forwarding webhook data to user-provided callback",
"""import requests
from flask import request

def trigger_webhook():
    callback = request.json.get('callback_url')
    requests.post(callback, json={"status": "ok"})
""")

add_tc(76, "tc_076_cwe918_ssrf_node_axios.js", "JavaScript", "CWE-918", "SSRF", True,
       "Node axios.get requesting unvalidated URL parameter",
"""const axios = require('axios');

async function importFeed(req, res) {
    const feedUrl = req.query.url;
    const response = await axios.get(feedUrl);
    res.send(response.data);
}
""")

add_tc(77, "tc_077_cwe918_ssrf_node_fetch.js", "JavaScript", "CWE-918", "SSRF", True,
       "Node fetch() executing outbound request to client URL",
"""async function fetchWebhook(req, res) {
    const endpoint = req.body.endpoint;
    const result = await fetch(endpoint);
    res.json(await result.json());
}
""")

add_tc(78, "tc_078_cwe918_ssrf_java_url_openstream.java", "Java", "CWE-918", "SSRF", True,
       "Java URL.openStream reading from untrusted destination",
"""import java.net.*;
import java.io.*;

public class WebhookForwarder {
    public InputStream forward(String targetUrl) throws Exception {
        URL url = new URL(targetUrl);
        return url.openStream();
    }
}
""")

add_tc(79, "tc_079_cwe918_ssrf_urllib3_pool.py", "Python", "CWE-918", "SSRF", True,
       "urllib3 PoolManager request to arbitrary remote host",
"""import urllib3
from flask import request

def ping_service():
    dest = request.args.get('dest')
    http = urllib3.PoolManager()
    return http.request('GET', dest).data
""")

# ─────────────────────────────────────────────────────────────────────────────
# 9. SERVER-SIDE TEMPLATE INJECTION (SSTI) (CWE-1336) - 7 Test Cases (tc_080 to tc_086)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(80, "tc_080_cwe1336_ssti_jinja2_env.py", "Python", "CWE-1336", "SSTI", True,
       "jinja2.Environment.from_string compiling template from user string",
"""import jinja2
from flask import request

def render_greeting():
    name = request.args.get('name')
    template = jinja2.Environment().from_string("Hello " + name)
    return template.render()
""")

add_tc(81, "tc_081_cwe1336_ssti_jinja2_template.py", "Python", "CWE-1336", "SSTI", True,
       "jinja2.Template constructed directly from user request body",
"""from jinja2 import Template
from flask import request

def format_email():
    body = request.form.get('body')
    t = Template(body)
    return t.render()
""")

add_tc(82, "tc_082_cwe1336_ssti_mako_template.py", "Python", "CWE-1336", "SSTI", True,
       "mako.template.Template receiving untrusted user template",
"""from mako.template import Template
from flask import request

def generate_report():
    user_template = request.args.get('tpl')
    return Template(user_template).render()
""")

add_tc(83, "tc_083_cwe1336_ssti_tornado_template.py", "Python", "CWE-1336", "SSTI", True,
       "tornado.template.Template with dynamic format string",
"""import tornado.template
from flask import request

def dynamic_view():
    tpl_str = request.args.get('view')
    t = tornado.template.Template(tpl_str)
    return t.generate()
""")

add_tc(84, "tc_084_cwe1336_ssti_chevron_mustache.py", "Python", "CWE-1336", "SSTI", True,
       "chevron mustache renderer with user-supplied template string",
"""import chevron
from flask import request

def render_mustache():
    tpl = request.args.get('template')
    return chevron.render(tpl, {'data': 123})
""")

add_tc(85, "tc_085_cwe1336_ssti_django_engine.py", "Python", "CWE-1336", "SSTI", True,
       "django.template.engines['django'].from_string with raw string input",
"""from django.template import engines
from flask import request

def django_render():
    raw_str = request.args.get('t')
    django_engine = engines['django']
    template = django_engine.from_string(raw_str)
    return template.render()
""")

add_tc(86, "tc_086_cwe1336_ssti_bottle_template.py", "Python", "CWE-1336", "SSTI", True,
       "bottle template function executing dynamic user template",
"""import bottle
from flask import request

def bottle_view():
    raw_tpl = request.args.get('layout')
    return bottle.template(raw_tpl, name="Admin")
""")

# ─────────────────────────────────────────────────────────────────────────────
# 10. BROKEN CRYPTOGRAPHY & HASHES (CWE-327) - 8 Test Cases (tc_087 to tc_094)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(87, "tc_087_cwe327_hashlib_md5.py", "Python", "CWE-327", "Broken Cryptography", True,
       "MD5 used for password hashing",
"""import hashlib

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()
""")

add_tc(88, "tc_088_cwe327_hashlib_sha1.py", "Python", "CWE-327", "Broken Cryptography", True,
       "SHA1 used for signature generation",
"""import hashlib

def generate_signature(data):
    return hashlib.sha1(data).hexdigest()
""")

add_tc(89, "tc_089_cwe327_hashlib_new_md5.py", "Python", "CWE-327", "Broken Cryptography", True,
       "hashlib.new('md5') used dynamically",
"""import hashlib

def create_checksum(data):
    h = hashlib.new('md5')
    h.update(data)
    return h.hexdigest()
""")

add_tc(90, "tc_090_cwe327_cryptodome_des.py", "Python", "CWE-327", "Broken Cryptography", True,
       "Legacy DES block cipher used for encryption",
"""from Crypto.Cipher import DES

def encrypt_block(key, data):
    cipher = DES.new(key, DES.MODE_ECB)
    return cipher.encrypt(data)
""")

add_tc(91, "tc_091_cwe327_node_crypto_md5.js", "JavaScript", "CWE-327", "Broken Cryptography", True,
       "Node.js crypto.createHash('md5') for password hash",
"""const crypto = require('crypto');

function hashUserSecret(secret) {
    return crypto.createHash('md5').update(secret).digest('hex');
}
""")

add_tc(92, "tc_092_cwe327_node_crypto_sha1.js", "JavaScript", "CWE-327", "Broken Cryptography", True,
       "Node.js crypto.createHash('sha1') for integrity verification",
"""const crypto = require('crypto');

function signPayload(payload) {
    return crypto.createHash('sha1').update(payload).digest('hex');
}
""")

add_tc(93, "tc_093_cwe327_java_md5.java", "Java", "CWE-327", "Broken Cryptography", True,
       "Java MessageDigest.getInstance('MD5')",
"""import java.security.MessageDigest;

public class Hasher {
    public byte[] hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        return md.digest(password.getBytes());
    }
}
""")

add_tc(94, "tc_094_cwe327_c_openssl_md5.c", "C", "CWE-327", "Broken Cryptography", True,
       "OpenSSL MD5_Init/Update/Final used in C code",
"""#include <openssl/md5.h>

void compute_md5(const unsigned char *data, size_t len, unsigned char *out) {
    MD5(data, len, out);
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# 11. INSECURE ENCRYPTION / ECB MODE (CWE-326) - 7 Test Cases (tc_095 to tc_101)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(95, "tc_095_cwe326_aes_ecb_mode.py", "Python", "CWE-326", "Weak Encryption", True,
       "AES configured in ECB mode revealing structural block patterns",
"""from Crypto.Cipher import AES

def encrypt_data(key, plaintext):
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.encrypt(plaintext)
""")

add_tc(96, "tc_096_cwe326_cryptography_ecb.py", "Python", "CWE-326", "Weak Encryption", True,
       "cryptography.hazmat modes.ECB used for AES",
"""from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

def build_cipher(key):
    return Cipher(algorithms.AES(key), modes.ECB())
""")

add_tc(97, "tc_097_cwe326_short_rsa_key.py", "Python", "CWE-326", "Weak Encryption", True,
       "RSA key generated with insecure 512-bit key size",
"""from Crypto.PublicKey import RSA

def generate_key():
    return RSA.generate(512)
""")

add_tc(98, "tc_098_cwe326_node_crypto_ecb.js", "JavaScript", "CWE-326", "Weak Encryption", True,
       "Node crypto.createCipheriv using aes-128-ecb",
"""const crypto = require('crypto');

function encrypt(text, key) {
    const cipher = crypto.createCipheriv('aes-128-ecb', key, null);
    return cipher.update(text, 'utf8', 'hex') + cipher.final('hex');
}
""")

add_tc(99, "tc_099_cwe326_java_aes_ecb.java", "Java", "CWE-326", "Weak Encryption", True,
       "Java Cipher.getInstance('AES/ECB/PKCS5Padding')",
"""import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Encryptor {
    public byte[] encrypt(byte[] key, byte[] data) throws Exception {
        Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"));
        return c.doFinal(data);
    }
}
""")

add_tc(100, "tc_100_cwe326_blowfish_cipher.py", "Python", "CWE-326", "Weak Encryption", True,
       "Blowfish 64-bit block cipher used for encryption",
"""from Crypto.Cipher import Blowfish

def encrypt_bf(key, data):
    cipher = Blowfish.new(key, Blowfish.MODE_ECB)
    return cipher.encrypt(data)
""")

add_tc(101, "tc_101_cwe326_rc4_cipher.py", "Python", "CWE-326", "Weak Encryption", True,
       "ARC4 / RC4 insecure stream cipher initialized",
"""from Crypto.Cipher import ARC4

def stream_encrypt(key, data):
    return ARC4.new(key).encrypt(data)
""")

# ─────────────────────────────────────────────────────────────────────────────
# 12. AUTHENTICATION & JWT BYPASS (CWE-347) - 7 Test Cases (tc_102 to tc_108)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(102, "tc_102_cwe347_jwt_verify_signature_false.py", "Python", "CWE-347", "JWT Bypass", True,
       "jwt.decode with verify_signature=False allowing token forgery",
"""import jwt
from flask import request

def authenticate():
    token = request.headers.get('Authorization').split(' ')[1]
    payload = jwt.decode(token, options={"verify_signature": False})
    return payload
""")

add_tc(103, "tc_103_cwe347_jwt_algorithm_none.py", "Python", "CWE-347", "JWT Bypass", True,
       "JWT allowing algorithm 'none'",
"""import jwt

def decode_token(token):
    return jwt.decode(token, key="", algorithms=["none"])
""")

add_tc(104, "tc_104_cwe347_node_jwt_ignore_expiration.js", "JavaScript", "CWE-347", "JWT Bypass", True,
       "jsonwebtoken verify with ignoreExpiration=true",
"""const jwt = require('jsonwebtoken');

function checkAuth(token, secret) {
    return jwt.verify(token, secret, { ignoreExpiration: true });
}
""")

add_tc(105, "tc_105_cwe347_node_jwt_no_verify.js", "JavaScript", "CWE-347", "JWT Bypass", True,
       "jsonwebtoken decode() called instead of verify()",
"""const jwt = require('jsonwebtoken');

function getUserFromToken(token) {
    return jwt.decode(token); // Decodes without verifying signature
}
""")

add_tc(106, "tc_106_cwe347_java_jwt_no_signature.java", "Java", "CWE-347", "JWT Bypass", True,
       "Java JJWT parsing claims without signing key",
"""import io.jsonwebtoken.*;

public class TokenParser {
    public Claims parse(String jwt) {
        return Jwts.parser().parseClaimsJwt(jwt).getBody();
    }
}
""")

add_tc(107, "tc_107_cwe347_jwt_weak_hmac_secret.py", "Python", "CWE-347", "JWT Bypass", True,
       "JWT signed with trivial 4-character secret",
"""import jwt

def issue_token(user_id):
    return jwt.encode({"sub": user_id}, "1234", algorithm="HS256")
""")

add_tc(108, "tc_108_cwe347_jwt_no_audience_check.py", "Python", "CWE-347", "JWT Bypass", True,
       "JWT decoding explicitly skipping audience validation",
"""import jwt

def verify_token(token, secret):
    return jwt.decode(token, secret, algorithms=["HS256"], options={"verify_aud": False})
""")

# ─────────────────────────────────────────────────────────────────────────────
# 13. INSECURE TRANSPORT & TLS DISABLED (CWE-295) - 7 Test Cases (tc_109 to tc_115)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(109, "tc_109_cwe295_requests_verify_false.py", "Python", "CWE-295", "TLS Verification Disabled", True,
       "requests.get with verify=False disabling SSL verification",
"""import requests

def fetch_data():
    return requests.get("https://internal-api.service/data", verify=False).json()
""")

add_tc(110, "tc_110_cwe295_httpx_verify_false.py", "Python", "CWE-295", "TLS Verification Disabled", True,
       "httpx.Client initialized with verify=False",
"""import httpx

client = httpx.Client(verify=False)
def sync_orders():
    return client.get("https://orders.service/list")
""")

add_tc(111, "tc_111_cwe295_urllib3_cert_none.py", "Python", "CWE-295", "TLS Verification Disabled", True,
       "urllib3 PoolManager configured with cert_reqs='CERT_NONE'",
"""import urllib3

http = urllib3.PoolManager(cert_reqs='CERT_NONE')
def query():
    return http.request('GET', 'https://self-signed.service')
""")

add_tc(112, "tc_112_cwe295_ssl_unverified_context.py", "Python", "CWE-295", "TLS Verification Disabled", True,
       "ssl._create_unverified_context used for HTTPS connection",
"""import ssl
import urllib.request

def fetch_unverified(url):
    ctx = ssl._create_unverified_context()
    return urllib.request.urlopen(url, context=ctx).read()
""")

add_tc(113, "tc_113_cwe295_node_reject_unauthorized.js", "JavaScript", "CWE-295", "TLS Verification Disabled", True,
       "Node.js https.Agent rejectUnauthorized=false",
"""const https = require('https');
const axios = require('axios');

const agent = new https.Agent({ rejectUnauthorized: false });
axios.get('https://backend.service', { httpsAgent: agent });
""")

add_tc(114, "tc_114_cwe295_java_trust_all_certs.java", "Java", "CWE-295", "TLS Verification Disabled", True,
       "Java TrustManager accepting all certificates blindly",
"""import javax.net.ssl.*;
import java.security.cert.X509Certificate;

public class InsecureSSL {
    public static void disableCertChecking() throws Exception {
        TrustManager[] trustAll = new TrustManager[] {
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return null; }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }
        };
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAll, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    }
}
""")

add_tc(115, "tc_115_cwe295_c_curl_insecure.c", "C", "CWE-295", "TLS Verification Disabled", True,
       "libcurl CURLOPT_SSL_VERIFYPEER set to 0L",
"""#include <curl/curl.h>

void download(CURL *curl, const char *url) {
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_perform(curl);
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# 14. INSECURE TEMP FILES & RACE CONDITIONS (CWE-377) - 5 Test Cases (tc_116 to tc_120)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(116, "tc_116_cwe377_tempfile_mktemp.py", "Python", "CWE-377", "Insecure File Handling", True,
       "tempfile.mktemp creates race conditions and symlink attacks",
"""import tempfile

def create_scratch():
    path = tempfile.mktemp()
    with open(path, 'w') as f:
        f.write("temporary data")
    return path
""")

add_tc(117, "tc_117_cwe377_c_tmpnam.c", "C", "CWE-377", "Insecure File Handling", True,
       "C tmpnam function vulnerable to file collision race condition",
"""#include <stdio.h>

void make_temp() {
    char name[L_tmpnam];
    tmpnam(name);
    FILE *f = fopen(name, "w");
    fclose(f);
}
""")

add_tc(118, "tc_118_cwe377_hardcoded_tmp_path.py", "Python", "CWE-377", "Insecure File Handling", True,
       "Predictable hardcoded temporary path in /tmp",
"""def store_session(session_id, data):
    with open(f"/tmp/sess_{session_id}.txt", "w") as f:
        f.write(data)
""")

add_tc(119, "tc_119_cwe377_c_mktemp.c", "C", "CWE-377", "Insecure File Handling", True,
       "C mktemp() vulnerable function called",
"""#include <stdlib.h>

void make_buffer() {
    char tpl[] = "/tmp/scratchXXXXXX";
    mktemp(tpl);
}
""")

add_tc(120, "tc_120_cwe377_os_tempnam.py", "Python", "CWE-377", "Insecure File Handling", True,
       "os.tempnam called to create temporary file name",
"""import os

def create_temp():
    return os.tempnam("/tmp", "prefix")
""")

# ─────────────────────────────────────────────────────────────────────────────
# 15. XML SECURITY / XXE (CWE-611) - 4 Test Cases (tc_121 to tc_124)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(121, "tc_121_cwe611_xxe_lxml_resolve.py", "Python", "CWE-611", "XML Security", True,
       "lxml.etree.XMLParser with resolve_entities=True",
"""from lxml import etree
from flask import request

def parse_xml():
    xml_data = request.data
    parser = etree.XMLParser(resolve_entities=True)
    return etree.fromstring(xml_data, parser=parser)
""")

add_tc(122, "tc_122_cwe611_xxe_xml_etree.py", "Python", "CWE-611", "XML Security", True,
       "xml.etree.ElementTree.fromstring parsing untrusted XML document",
"""import xml.etree.ElementTree as ET
from flask import request

def parse_order():
    return ET.fromstring(request.data)
""")

add_tc(123, "tc_123_cwe611_xxe_java_sax.java", "Java", "CWE-611", "XML Security", True,
       "Java SAXParserFactory parsing XML without disabling DTDs",
"""import javax.xml.parsers.SAXParserFactory;
import java.io.InputStream;

public class XMLService {
    public void parse(InputStream in) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.newSAXParser().parse(in, new org.xml.sax.helpers.DefaultHandler());
    }
}
""")

add_tc(124, "tc_124_cwe611_xxe_minidom.py", "Python", "CWE-611", "XML Security", True,
       "xml.dom.minidom.parseString on user payload",
"""from xml.dom import minidom
from flask import request

def parse_svg():
    return minidom.parseString(request.data)
""")

# ─────────────────────────────────────────────────────────────────────────────
# 16. MEMORY SAFETY IN C/C++ (CWE-120) - 3 Test Cases (tc_125 to tc_127)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(125, "tc_125_cwe120_buffer_overflow_strcpy.c", "C", "CWE-120", "Memory Safety", True,
       "strcpy into fixed-size stack buffer without bounds checking",
"""#include <string.h>

void copy_user_name(const char *input) {
    char buffer[64];
    strcpy(buffer, input);
}
""")

add_tc(126, "tc_126_cwe120_buffer_overflow_gets.c", "C", "CWE-120", "Memory Safety", True,
       "gets() reading unbounded input directly into stack buffer",
"""#include <stdio.h>

void read_line() {
    char buf[128];
    gets(buf);
}
""")

add_tc(127, "tc_127_cwe120_buffer_overflow_sprintf.c", "C", "CWE-120", "Memory Safety", True,
       "sprintf without length bound into stack buffer",
"""#include <stdio.h>

void format_greeting(const char *name) {
    char out[100];
    sprintf(out, "Hello there, valued user: %s!", name);
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# 17. MISCONFIGURATION & WEAK RANDOM (CWE-489, 942, 338) - 3 Test Cases (tc_128 to tc_130)
# ─────────────────────────────────────────────────────────────────────────────
add_tc(128, "tc_128_cwe489_flask_debug_true.py", "Python", "CWE-489", "Security Misconfiguration", True,
       "Flask application running in production with debug=True",
"""from flask import Flask

app = Flask(__name__)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
""")

add_tc(129, "tc_129_cwe942_cors_wildcard.py", "Python", "CWE-942", "Security Misconfiguration", True,
       "CORS configured with wildcard origin allowing all external domains",
"""from flask import Flask, make_response

app = Flask(__name__)

@app.after_request
def add_cors(resp):
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp
""")

add_tc(130, "tc_130_cwe338_weak_random_token.py", "Python", "CWE-338", "Weak Randomness", True,
       "random.randint used for password reset token generation",
"""import random

def generate_reset_token():
    return str(random.randint(100000, 999999))
""")


# ─────────────────────────────────────────────────────────────────────────────
# 18. BENIGN / FALSE POSITIVE VALIDATION SUITE (tc_131 to tc_150) - 20 CLEAN FILES
# ─────────────────────────────────────────────────────────────────────────────
add_tc(131, "tc_131_benign_sqli_parameterized_tuple.py", "Python", "CWE-89", "Safe SQL Parameterization", False,
       "Parameterized query using SQLite tuple parameter binding (Clean)",
"""import sqlite3
from flask import request

def get_profile():
    user = request.args.get('user')
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE name = ?", (user,))
    return cursor.fetchall()
""")

add_tc(132, "tc_132_benign_sqli_static_lookup.py", "Python", "CWE-89", "Safe Static SQL Query", False,
       "Static parameterized query with fixed internal table lookups (Clean)",
"""import sqlite3

def get_system_health():
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    cursor.execute("SELECT status, count(*) FROM service_metrics GROUP BY status")
    return cursor.fetchall()
""")

add_tc(133, "tc_133_benign_cmdinj_static_list.py", "Python", "CWE-78", "Safe Process Execution", False,
       "subprocess.run with fixed list argument and shell=False (Clean)",
"""import subprocess

def run_system_diagnostic():
    res = subprocess.run(["uptime"], shell=False, capture_output=True, text=True, check=True)
    return res.stdout
""")

add_tc(134, "tc_134_benign_cmdinj_hardcoded_args.py", "Python", "CWE-78", "Safe Command Arguments", False,
       "subprocess.check_call with hardcoded static system arguments (Clean)",
"""import subprocess

def check_nginx():
    return subprocess.check_call(["systemctl", "is-active", "nginx"])
""")

add_tc(135, "tc_135_benign_xss_html_escape.py", "Python", "CWE-79", "Safe HTML Escaping", False,
       "html.escape sanitizes input before inserting into HTML (Clean)",
"""import html
from flask import request

def show_comment():
    comment = request.args.get('c', '')
    safe_html = html.escape(comment)
    return f"<div>{safe_html}</div>"
""")

add_tc(136, "tc_136_benign_path_traversal_abspath_check.py", "Python", "CWE-22", "Safe Path Verification", False,
       "Path verification ensures resolved path stays inside base directory (Clean)",
"""import os
from flask import request, abort

BASE_DIR = "/var/www/uploads"

def read_upload():
    filename = request.args.get('file', '')
    resolved = os.path.abspath(os.path.join(BASE_DIR, filename))
    if not resolved.startswith(BASE_DIR):
        abort(403)
    with open(resolved, 'r') as f:
        return f.read()
""")

add_tc(137, "tc_137_benign_path_traversal_secure_filename.py", "Python", "CWE-22", "Safe Werkzeug Filename", False,
       "werkzeug.utils.secure_filename strips directory traversal sequences (Clean)",
"""from werkzeug.utils import secure_filename
import os

def save_avatar(uploaded_file):
    name = secure_filename(uploaded_file.filename)
    path = os.path.join("/uploads", name)
    uploaded_file.save(path)
""")

add_tc(138, "tc_138_benign_secrets_env_var.py", "Python", "CWE-798", "Safe Env Credential", False,
       "Credentials safely loaded from os.getenv (Clean)",
"""import os

DATABASE_PASSWORD = os.getenv("DB_PASS")
API_KEY = os.getenv("EXTERNAL_SERVICE_KEY")
""")

add_tc(139, "tc_139_benign_deserialization_json.py", "Python", "CWE-502", "Safe JSON Deserialization", False,
       "json.loads parses data without executing code (Clean)",
"""import json
from flask import request

def process_payload():
    data = json.loads(request.data)
    return {"status": "received", "keys": list(data.keys())}
""")

add_tc(140, "tc_140_benign_ssrf_fixed_endpoint.py", "Python", "CWE-918", "Safe Fixed Endpoint", False,
       "Outbound requests strictly fixed to internal static API endpoint (Clean)",
"""import requests

METRICS_ENDPOINT = "https://metrics.internal.service/health"

def fetch_telemetry():
    return requests.get(METRICS_ENDPOINT, timeout=5).json()
""")

add_tc(141, "tc_141_benign_crypto_bcrypt_hash.py", "Python", "CWE-327", "Safe Modern Password Hash", False,
       "Password hashing using modern salted bcrypt algorithm (Clean)",
"""import bcrypt

def hash_pw(password: str) -> bytes:
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password.encode('utf-8'), salt)
""")

add_tc(142, "tc_142_benign_crypto_aes_gcm.py", "Python", "CWE-326", "Safe Authenticated Encryption", False,
       "AES configured in authenticated GCM mode with random nonce (Clean)",
"""from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes

def encrypt_gcm(key: bytes, data: bytes):
    nonce = get_random_bytes(12)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(data)
    return nonce + tag + ciphertext
""")

add_tc(143, "tc_143_benign_jwt_signature_verified.py", "Python", "CWE-347", "Safe JWT Signature Check", False,
       "JWT token decoded with mandatory signature verification and algorithm (Clean)",
"""import jwt
import os

SECRET_KEY = os.getenv("JWT_SECRET", "default_secret")

def verify_token(token: str):
    return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
""")

add_tc(144, "tc_144_benign_tls_verify_enabled.py", "Python", "CWE-295", "Safe TLS Verification", False,
       "requests.get with TLS certificate verification enabled (Clean)",
"""import requests

def fetch_telemetry():
    return requests.get("https://telemetry.service.internal", verify=True, timeout=10).json()
""")

add_tc(145, "tc_145_benign_tempfile_named_temporary.py", "Python", "CWE-377", "Safe Temporary File", False,
       "tempfile.NamedTemporaryFile creates race-free temporary file (Clean)",
"""import tempfile

def create_scratch():
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tf:
        tf.write("scratch data")
        return tf.name
""")

add_tc(146, "tc_146_benign_xml_defusedxml.py", "Python", "CWE-611", "Safe Defused XML", False,
       "defusedxml safely parses XML without entity expansion (Clean)",
"""import defusedxml.ElementTree as ET
from flask import request

def parse_xml_safely():
    return ET.fromstring(request.data)
""")

add_tc(147, "tc_147_benign_random_secrets_module.py", "Python", "CWE-338", "Safe Cryptographic Random", False,
       "secrets.token_hex generates cryptographically secure reset token (Clean)",
"""import secrets

def generate_secure_token():
    return secrets.token_hex(32)
""")

add_tc(148, "tc_148_benign_c_memory_snprintf.c", "C", "CWE-120", "Safe Bounded Buffer Copy", False,
       "snprintf with explicit buffer size prevents buffer overflow (Clean)",
"""#include <stdio.h>

void safe_format(const char *name) {
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "Hello, %s", name);
}
""")

add_tc(149, "tc_149_benign_node_pg_parameterized.js", "JavaScript", "CWE-89", "Safe Node Parameterization", False,
       "Node pg client using $1 parameterized placeholder (Clean)",
"""const { Client } = require('pg');

async function getUser(client, username) {
    const res = await client.query('SELECT * FROM users WHERE name = $1', [username]);
    return res.rows;
}
""")

add_tc(150, "tc_150_benign_java_prepared_statement.java", "Java", "CWE-89", "Safe Java PreparedStatement", False,
       "Java PreparedStatement with setString binding (Clean)",
"""import java.sql.*;

public class SafeSearch {
    public ResultSet search(Connection conn, String user) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE name = ?");
        ps.setString(1, user);
        return ps.executeQuery();
    }
}
""")

# ─────────────────────────────────────────────────────────────────────────────
# Write all 150 files to disk
# ─────────────────────────────────────────────────────────────────────────────
for tc in testcases:
    fpath = os.path.join(BASE_DIR, tc["filename"])
    with open(fpath, "w", encoding="utf-8") as f:
        f.write(tc["code"])

# Write manifest.json
manifest_path = os.path.join(BASE_DIR, "manifest.json")
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(testcases, f, indent=2)

# Write README.md summary
readme_path = os.path.join(BASE_DIR, "README.md")
with open(readme_path, "w", encoding="utf-8") as f:
    f.write("# SecureCode AI Benchmark Dataset (150 Test Cases)\n\n")
    f.write("A structured benchmark evaluation suite for Static Application Security Testing (SAST).\n\n")
    f.write("- **Total Testcases:** 150\n")
    f.write("- **Vulnerable Files (Files 001–130):** 130 files covering 17 distinct CWE vulnerability classes.\n")
    f.write("- **Benign / Clean Files (Files 131–150):** 20 files for false-positive rate evaluation.\n\n")
    f.write("## Test Cases Summary Table\n\n")
    f.write("| ID | File Name | Language | CWE ID | Category | Expected Verdict | Description |\n")
    f.write("|---|---|---|---|---|---|---|\n")
    for tc in testcases:
        verdict = "⚠️ VULNERABLE" if tc["is_vulnerable"] else "✅ CLEAN (SAFE)"
        f.write(f"| {tc['id']:03d} | `{tc['filename']}` | {tc['language']} | {tc['cwe_id']} | {tc['category']} | {verdict} | {tc['description']} |\n")

print(f"Successfully generated {len(testcases)} testcases in {BASE_DIR}")
