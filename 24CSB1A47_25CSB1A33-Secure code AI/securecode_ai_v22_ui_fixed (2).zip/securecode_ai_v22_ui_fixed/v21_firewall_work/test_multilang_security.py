import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from multilang_security_analyzer import analyze_source

CASES = {
    "sample.js": ("const {exec}=require('child_process'); exec(req.query.cmd); db.query('SELECT * FROM x WHERE id=' + req.query.id);", {"COMMAND-INJECTION", "SQL-INJECTION"}),
    "sample.java": ('class X { void x(String user) { Statement s=c.createStatement(); s.executeQuery("SELECT * FROM u WHERE n=" + user); Runtime.getRuntime().exec(user); } }', {"COMMAND-INJECTION", "SQL-INJECTION"}),
    "sample.c": ('#include <string.h>\n#include <stdlib.h>\nvoid x(char *input){ char b[8]; strcpy(b,input); system(input); }', {"COMMAND-INJECTION", "MEMORY-SAFETY"}),
    "sample.cpp": ('#include <cstring>\n#include <cstdlib>\nvoid x(const char* input){ char b[8]; strcpy(b,input); system(input); }', {"COMMAND-INJECTION", "MEMORY-SAFETY"}),
}

for filename, (source, expected) in CASES.items():
    found = {x["category"] for x in analyze_source(source, filename)}
    missing = expected - found
    assert not missing, f"{filename}: missing {missing}; found {found}"

print("4/4 multi-language regression tests passed")

# Extended coverage regression checks
EXTENDED_CASES = {
    "ssrf.js": ('const url=req.query.url; fetch(url);', 'SSRF'),
    "xss.js": ('const html=req.query.html; document.body.innerHTML=html;', 'XSS'),
    "path.js": ('const file=req.query.file; fs.readFile(file, cb);', 'PATH-TRAVERSAL'),
    "weak-random.js": ('const token = Math.random();', 'WEAK-RANDOMNESS'),
    "xxe.java": ('DocumentBuilderFactory.newInstance();', 'XXE-RISK'),
    "weak-random.java": ('new Random();', 'WEAK-RANDOMNESS'),
    "memory.c": ('char *x; strcpy(x, input);', 'MEMORY-SAFETY'),
}
for filename, (source, expected_category) in EXTENDED_CASES.items():
    found = {x["category"] for x in analyze_source(source, filename)}
    assert expected_category in found, f"{filename}: missing {expected_category}; found {found}"
print("7/7 extended coverage regression checks passed")
