"""
Flask API backend for SecureCode AI — Multi-Language Security Analyzer
Powered by Groq Cloud AI (replaces local Ollama).
"""

import sys
import os
import json
import tempfile
import io
import zipfile
import traceback
import re
import urllib.request
import urllib.error
from urllib.parse import urlparse, quote
from flask import Flask, request, jsonify, send_from_directory, Response, stream_with_context

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from unified_types import SymbolTable
from module1_input_detection import InputDetectionModule
from module2_rule_engine import RuleEngineModule
from module3_warning_logic import WarningDecisionLogic
from ast_traverser import ASTTraverser
from python_ast_bridge import PythonASTBridge
from broad_security_analyzer import analyze_source as analyze_python_source
from multilang_security_analyzer import analyze_source as analyze_multilang_source, language_for, detect_language
from project_graph import analyze_project_graph
from secret_scanner import scan_secrets
from dependency_scanner import scan_dependencies
from groq_agent import (
    investigate as groq_investigate,
    repair_code as groq_repair_code,
    auto_repair_loop as groq_auto_repair_loop,
    chat_about_code as groq_chat,
    chat_stream as groq_chat_stream,
    check_api_status as groq_check_status,
    save_api_key as groq_save_api_key,
    get_available_models as groq_get_available_models,
    SUPPORTED_MODELS,
    GEMINI_MODELS,
    XAI_MODELS,
    GroqAIError,
)
from ai_firewall import demo_cases as ai_firewall_demo_cases, inspect_chat as ai_firewall_inspect_chat
from agents import MasterOrchestrator

orchestrator = MasterOrchestrator.get_instance()

app = Flask(__name__, static_folder='frontend', static_url_path='')
app.config['MAX_CONTENT_LENGTH'] = 55 * 1024 * 1024  # ZIP upload limit + multipart overhead
PROJECT_MAX_FILES = 150
PROJECT_MAX_SOURCE_BYTES = 10 * 1024 * 1024

# Restrict cross-origin access by default.
_cors_origins = [x.strip() for x in os.getenv('SECURECODE_CORS_ORIGINS', '').split(',') if x.strip()]
if _cors_origins:
    from flask_cors import CORS
    CORS(app, origins=_cors_origins)

# In-memory project context cache (per-session via simple dict; for server restarts use Redis)
_project_cache = {}  # filename -> {files: {path: source}, analysis: data}


def _merge_findings(legacy: list, broad: list) -> list:
    """Merge the original SQL/ORM findings with the supplemental broad pass."""
    merged = list(legacy)
    legacy_keys = {
        ("SQL Injection" if str(v.get("id", "")).startswith("SQLI-") else
         "ORM Injection" if str(v.get("id", "")).startswith("ORMI-") else "",
         v.get("line"), v.get("sink"))
        for v in legacy
    }
    for finding in broad:
        if finding.get("category") == "SQL Injection":
            key = ("SQL Injection", finding.get("line"), finding.get("sink"))
            if key in legacy_keys:
                continue
        merged.append(finding)

    for v in merged:
        if "category" not in v:
            v["category"] = "SQL Injection" if str(v.get("id", "")).startswith("SQLI-") else ("ORM Injection" if str(v.get("id", "")).startswith("ORMI-") else "Security")
        if "impact" not in v:
            v["impact"] = "Unauthorized database access, exfiltration of sensitive records, data tampering, and potential database server compromise."

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    merged.sort(key=lambda x: (x.get("line", 0), severity_order.get(x.get("severity", "LOW"), 9), x.get("id", "")))
    return merged


def analyze_file(filepath: str) -> dict:
    """Run the original compiler/taint pipeline plus the broad security pass."""
    safe_path = os.path.abspath(filepath)
    if not os.path.isfile(safe_path):
        raise FileNotFoundError(f"File not found: {filepath}")
    with open(safe_path, "r", encoding="utf-8") as f:
        source = f.read()

    bridge = PythonASTBridge()
    ast_root = bridge.parse_source(source, filename=safe_path)

    symbol_table = SymbolTable()
    input_detector = InputDetectionModule(symbol_table)
    rule_engine = RuleEngineModule(symbol_table)
    warning_logic = WarningDecisionLogic(symbol_table)

    traverser = ASTTraverser(input_detector, rule_engine, warning_logic, symbol_table)
    stats = traverser.analyze(ast_root)

    symbol_snapshot = {
        var: state.value if hasattr(state, 'value') else str(state)
        for var, state in symbol_table.get_all_variables().items()
    }

    report_json = json.loads(warning_logic.generate_json_report())
    legacy_findings = report_json["vulnerabilities"]

    broad_findings = analyze_python_source(source, filepath)
    vulnerabilities = _merge_findings(legacy_findings, broad_findings)

    counts = {level: sum(1 for v in vulnerabilities if v.get("severity") == level)
              for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW")}
    categories = {}
    for v in vulnerabilities:
        category = v.get("category", "SQL / ORM Injection")
        categories[category] = categories.get(category, 0) + 1

    summary = {
        "total_vulnerabilities": len(vulnerabilities),
        "critical_severity": counts["CRITICAL"],
        "high_severity": counts["HIGH"],
        "medium_severity": counts["MEDIUM"],
        "low_severity": counts["LOW"],
        "filtered": report_json["summary"].get("filtered", 0),
        "categories": categories,
    }

    stats = dict(stats)
    stats["broad_findings"] = len(broad_findings)
    stats["total_findings"] = len(vulnerabilities)
    stats["categories"] = categories

    return {
        "success": True,
        "filename": os.path.basename(filepath),
        "summary": summary,
        "vulnerabilities": vulnerabilities,
        "symbol_table": symbol_snapshot,
        "stats": stats,
    }


@app.route('/')
def index():
    return send_from_directory('frontend', 'index.html')


def _analyze_source(source: str, filename: str) -> dict:
    """Analyze source text for Python, JavaScript, Java, C, C++, credentials, and dependency manifests."""
    if not isinstance(source, str) or not source.strip():
        raise ValueError("No source code was provided")
    if len(source.encode("utf-8")) > 2 * 1024 * 1024:
        raise ValueError("Source code is too large (maximum 2 MB)")

    base_name = os.path.basename(filename or "").lower()
    if base_name in {"requirements.txt", "package.json", "pipfile", "package-lock.json"}:
        sca = scan_dependencies(source, filename)
        vulns = []
        for v in sca.get("vulnerabilities", []):
            vulns.append({
                "id": v["cve"],
                "severity": v["severity"],
                "line": 1,
                "category": "Vulnerable Dependency",
                "rule_violated": "SCA-" + v["cve"],
                "variable": v["package"],
                "sink": "dependency_manifest",
                "construction": "vulnerable_package",
                "description": f"{v['title']} in {v['package']}=={v['installed_version']} (Fixed in {v['fixed_version']}). {v['description']}",
                "suggested_fix": f"Upgrade {v['package']} to version {v['fixed_version']} or higher.",
                "confidence": 0.98,
                "evidence": v["manifest_line"],
                "impact": f"Known CVE with CVSS {v['cvss']}. Advisory: {v['advisory_url']}",
                "language": sca["manifest_type"]
            })
        counts = sca.get("severity_summary", {})
        result = {
            "success": True,
            "filename": os.path.basename(filename),
            "language": sca["manifest_type"],
            "summary": {
                "total_vulnerabilities": len(vulns),
                "critical_severity": counts.get("CRITICAL", 0),
                "high_severity": counts.get("HIGH", 0),
                "medium_severity": counts.get("MEDIUM", 0),
                "low_severity": counts.get("LOW", 0),
                "filtered": 0,
                "categories": {"Vulnerable Dependency": len(vulns)}
            },
            "vulnerabilities": vulns,
            "symbol_table": {},
            "stats": {"language": sca["manifest_type"], "total_findings": len(vulns)},
            "sca_report": sca,
        }
        result["filename"] = filename or "requirements.txt"
        result["language"] = sca["manifest_type"]
        result["language_detection"] = {"language": sca["manifest_type"], "confidence": 1.0, "method": "manifest"}
        result["source_code"] = source
        _project_cache['latest'] = {
            'file_sources': {result["filename"]: source},
            'findings': result.get('vulnerabilities', []),
            'project_graph': {},
            'files': [{'file': result["filename"], 'findings': len(vulns)}]
        }
        return result

    language, detection_confidence, detection_method = detect_language(source, filename)
    if language == "Python":
        with tempfile.NamedTemporaryFile(suffix='.py', delete=False, mode='w', encoding='utf-8') as tmp:
            tmp.write(source)
            tmp_path = tmp.name
        try:
            result = analyze_file(tmp_path)
        finally:
            try: os.unlink(tmp_path)
            except OSError: pass
    elif language in {"JavaScript", "Java", "C", "C++"}:
        findings = analyze_multilang_source(source, filename, language=language)
        counts = {level: sum(1 for v in findings if v.get("severity") == level) for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW")}
        categories = {}
        for v in findings:
            categories[v.get("category", "Security")] = categories.get(v.get("category", "Security"), 0) + 1
        result = {
            "success": True, "filename": os.path.basename(filename), "language": language,
            "summary": {"total_vulnerabilities": len(findings), "critical_severity": counts["CRITICAL"], "high_severity": counts["HIGH"], "medium_severity": counts["MEDIUM"], "low_severity": counts["LOW"], "filtered": 0, "categories": categories},
            "vulnerabilities": findings, "symbol_table": {},
            "stats": {"language": language, "total_findings": len(findings), "broad_findings": len(findings), "categories": categories}
        }
    else:
        raise ValueError("Unsupported language. Use .py, .js/.jsx/.mjs, .java, .c/.h, or .cpp/.cc/.cxx/.hpp files.")

    # Secret & Hard-coded Credential Scanning (Feature 1)
    secret_findings = scan_secrets(source, filename)
    if secret_findings:
        existing_vulns = result.get("vulnerabilities", [])
        existing_keys = {(v.get("line"), v.get("category")) for v in existing_vulns}
        for sf in secret_findings:
            if (sf.get("line"), sf.get("category")) not in existing_keys:
                existing_vulns.append(sf)

        severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        existing_vulns.sort(key=lambda x: (x.get("line", 0), severity_order.get(x.get("severity", "LOW"), 9), x.get("id", "")))
        result["vulnerabilities"] = existing_vulns

        result["summary"]["critical_severity"] = sum(1 for v in existing_vulns if v.get("severity") == "CRITICAL")
        result["summary"]["high_severity"] = sum(1 for v in existing_vulns if v.get("severity") == "HIGH")
        result["summary"]["medium_severity"] = sum(1 for v in existing_vulns if v.get("severity") == "MEDIUM")
        result["summary"]["low_severity"] = sum(1 for v in existing_vulns if v.get("severity") == "LOW")
        result["summary"]["total_vulnerabilities"] = len(existing_vulns)
        cats = {}
        for v in existing_vulns:
            c = v.get("category", "Security")
            cats[c] = cats.get(c, 0) + 1
        result["summary"]["categories"] = cats

    result["filename"] = filename or "source.txt"
    result["language"] = language
    result["language_detection"] = {"language": language, "confidence": detection_confidence, "method": detection_method}
    result["source_code"] = source

    # Cache active file context for AI assistant
    _project_cache['latest'] = {
        'file_sources': {result["filename"]: source},
        'findings': result.get('vulnerabilities', []),
        'project_graph': {},
        'files': [{'file': result["filename"], 'findings': len(result.get('vulnerabilities', []))}]
    }

    orchestrator.log_activity(
        agent_name="PatternDetectionAgent",
        task_type="pattern_scan",
        mode="LOCAL_STATIC",
        status="COMPLETED",
        execution_time_ms=0.0,
        model="Broad Security & Secret Rule Engine",
        findings_count=len(result.get("vulnerabilities", [])),
        handoff="ReportGenerationAgent",
        details={"filename": filename}
    )
    return result


def _safe_relative_name(name: str) -> str:
    name = (name or '').replace('\\', '/')
    parts = [p for p in name.split('/') if p not in ('', '.')]
    if any(p == '..' for p in parts) or name.startswith('/'):
        raise ValueError('Invalid project file path')
    return '/'.join(parts) or 'source'


def _analyze_project(files) -> dict:
    """Analyze a browser-uploaded project folder without executing project code."""
    if not files:
        raise ValueError('No project files were provided')
    if len(files) > PROJECT_MAX_FILES:
        raise ValueError(f'Too many files. Maximum is {PROJECT_MAX_FILES}.')

    supported = set('.py .js .jsx .mjs .cjs .java .c .h .cc .cpp .cxx .hpp .hh'.split())
    manifest_names = {'requirements.txt', 'package.json'}
    results = []
    all_findings = []
    errors = []
    file_sources = {}
    total_bytes = 0

    ignored_dirs = {'node_modules', '.git', '.venv', 'venv', '__pycache__', 'build', 'dist', 'target', '.idea'}

    for uploaded in files:
        rel = _safe_relative_name(uploaded.filename)
        parts = rel.split('/')
        if any(part in ignored_dirs for part in parts[:-1]):
            continue
        ext = os.path.splitext(rel.lower())[1]
        base_name = os.path.basename(rel).lower()
        if ext not in supported and base_name not in manifest_names:
            continue
        raw = uploaded.read()
        total_bytes += len(raw)
        if total_bytes > PROJECT_MAX_SOURCE_BYTES:
            raise ValueError(f'Project source exceeds {PROJECT_MAX_SOURCE_BYTES // (1024*1024)} MB.')
        try:
            source = raw.decode('utf-8')
        except UnicodeDecodeError:
            errors.append({'file': rel, 'error': 'Not valid UTF-8 source text'})
            continue
        file_sources[rel] = source
        try:
            result = _analyze_source(source, rel)
            file_findings = []
            for finding in result.get('vulnerabilities', []):
                item = dict(finding)
                item['file'] = rel
                file_findings.append(item)
                all_findings.append(item)
            results.append({
                'file': rel,
                'language': result.get('language', language_for(rel)),
                'language_detection': result.get('language_detection', {'language': result.get('language', 'Unknown'), 'confidence': 0.0, 'method': 'unknown'}),
                'lines': len(source.splitlines()),
                'findings': len(file_findings),
                'vulnerabilities': file_findings,
            })
        except Exception as exc:
            errors.append({'file': rel, 'error': str(exc)})

    severity_order = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3, 'INFO': 4}
    all_findings.sort(key=lambda x: (x.get('file',''), x.get('line',0), severity_order.get(x.get('severity','LOW'), 9)))
    counts = {level: sum(1 for v in all_findings if v.get('severity') == level)
              for level in ('CRITICAL','HIGH','MEDIUM','LOW')}
    categories = {}
    languages = {}
    for r in results:
        languages[r['language']] = languages.get(r['language'], 0) + 1
    for v in all_findings:
        c = v.get('category', 'Security')
        categories[c] = categories.get(c, 0) + 1

    project_graph = analyze_project_graph(file_sources)

    # Cache complete project context for AI assistant
    _project_cache['latest'] = {
        'file_sources': file_sources,
        'project_graph': project_graph,
        'findings': all_findings,
        'files': results,
    }

    orchestrator.log_activity(
        agent_name="FileScannerAgent",
        task_type="scan_files",
        mode="LOCAL_STATIC",
        status="COMPLETED",
        execution_time_ms=0.0,
        model="Deterministic File System Walker",
        findings_count=len(all_findings),
        handoff="PatternDetectionAgent",
        details={"files_scanned": len(file_sources)}
    )

    return {
        'success': True,
        'project': True,
        'filename': 'uploaded-project',
        'summary': {
            'total_vulnerabilities': len(all_findings),
            'critical_severity': counts['CRITICAL'],
            'high_severity': counts['HIGH'],
            'medium_severity': counts['MEDIUM'],
            'low_severity': counts['LOW'],
            'filtered': 0,
            'categories': categories,
        },
        'vulnerabilities': all_findings,
        'symbol_table': {},
        'stats': {
            'files_analyzed': len(results),
            'files_with_findings': sum(1 for r in results if r['findings']),
            'languages': languages,
            'language_detection': {lang: count for lang, count in languages.items()},
            'categories': categories,
            'project_source_mb': round(total_bytes / (1024 * 1024), 3),
            'skipped_or_failed_files': len(errors),
        },
        'files': results,
        'errors': errors,
        'project_graph': project_graph,
        'file_sources': file_sources,  # for AI context
    }


def _analyze_project_zip(uploaded_zip):
    """Safely analyze a ZIP project archive without executing project code."""
    raw = uploaded_zip.read()
    if len(raw) > 20 * 1024 * 1024:
        raise ValueError('Project ZIP exceeds the 20 MB upload limit.')
    class MemoryUpload:
        def __init__(self, name, data):
            self.filename = name
            self._data = data
        def read(self):
            return self._data
    files = []
    total_uncompressed = 0
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if len(z.infolist()) > PROJECT_MAX_FILES:
            raise ValueError(f'Too many files in ZIP. Maximum is {PROJECT_MAX_FILES}.')
        for info in z.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace('\\', '/')
            if info.file_size > 2 * 1024 * 1024:
                continue
            total_uncompressed += info.file_size
            if total_uncompressed > PROJECT_MAX_SOURCE_BYTES:
                raise ValueError(f'Project source exceeds {PROJECT_MAX_SOURCE_BYTES // (1024*1024)} MB.')
            files.append(MemoryUpload(name, z.read(info)))
    return _analyze_project(files)


GITHUB_MAX_FILES = 100
GITHUB_MAX_BYTES = 8 * 1024 * 1024
GITHUB_SUPPORTED = {'.py', '.js', '.jsx', '.mjs', '.cjs', '.java', '.c', '.h', '.cc', '.cpp', '.cxx', '.hpp', '.hh'}
GITHUB_IGNORED_DIRS = {'node_modules', '.git', '.venv', 'venv', '__pycache__', 'build', 'dist', 'target', '.idea', 'vendor'}


def _github_json(url):
    headers = {'User-Agent': 'SecureCode-AI-Static-Analyzer', 'Accept': 'application/vnd.github+json'}
    token = os.getenv('GITHUB_TOKEN', '').strip()
    if token:
        headers['Authorization'] = 'Bearer ' + token
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=15) as response:
        if response.status != 200:
            raise ValueError('GitHub returned HTTP ' + str(response.status))
        data = response.read(5 * 1024 * 1024 + 1)
    if len(data) > 5 * 1024 * 1024:
        raise ValueError('GitHub metadata response is too large.')
    return json.loads(data.decode('utf-8'))


def _analyze_github_repository(repo_url, branch=None):
    """Fetch a bounded set of source files from a GitHub repository without cloning or executing it."""
    parsed = urlparse((repo_url or '').strip())
    if parsed.scheme != 'https' or parsed.hostname not in {'github.com', 'www.github.com'}:
        raise ValueError('Use a valid public GitHub repository URL (https://github.com/owner/repository).')
    parts = [p for p in parsed.path.strip('/').split('/') if p]
    if len(parts) < 2 or parts[0] in {'.', '..'} or parts[1] in {'.', '..'}:
        raise ValueError('Repository URL must include an owner and repository name.')
    owner, repo = parts[0], parts[1].removesuffix('.git')
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', owner) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', repo):
        raise ValueError('Invalid GitHub owner or repository name.')
    if not branch and len(parts) >= 4 and parts[2] == 'tree':
        branch = parts[3]
    api_base = f'https://api.github.com/repos/{quote(owner)}/{quote(repo)}'
    repo_info = _github_json(api_base)
    if repo_info.get('private') and not os.getenv('GITHUB_TOKEN', '').strip():
        raise ValueError('Private repositories require a configured GITHUB_TOKEN with repository read access.')
    branch = branch or repo_info.get('default_branch') or 'main'
    tree_url = api_base + '/git/trees/' + quote(branch, safe='') + '?recursive=1'
    tree = _github_json(tree_url)
    if tree.get('truncated'):
        raise ValueError('GitHub repository tree is too large. Try a smaller repository or a subproject URL.')
    selected = []
    for item in tree.get('tree', []):
        if item.get('type') != 'blob':
            continue
        path = item.get('path', '').replace('\\', '/')
        if not path or any(part in GITHUB_IGNORED_DIRS for part in path.split('/')[:-1]):
            continue
        if os.path.splitext(path.lower())[1] not in GITHUB_SUPPORTED:
            continue
        if item.get('size', 0) > 2 * 1024 * 1024:
            continue
        selected.append(path)
    if not selected:
        raise ValueError('No supported source files were found in this repository/branch.')
    selected = selected[:GITHUB_MAX_FILES]
    files = []
    total = 0
    class MemoryUpload:
        def __init__(self, filename, data):
            self.filename, self._data = filename, data
        def read(self):
            return self._data
    for path in selected:
        raw_url = f'https://raw.githubusercontent.com/{quote(owner)}/{quote(repo)}/{quote(branch, safe="")}/' + '/'.join(quote(part, safe='') for part in path.split('/'))
        raw_headers = {'User-Agent': 'SecureCode-AI-Static-Analyzer'}
        token = os.getenv('GITHUB_TOKEN', '').strip()
        if token:
            raw_headers['Authorization'] = 'Bearer ' + token
        req = urllib.request.Request(raw_url, headers=raw_headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
        except (urllib.error.URLError, urllib.error.HTTPError):
            continue
        if len(raw) > 2 * 1024 * 1024:
            continue
        total += len(raw)
        if total > GITHUB_MAX_BYTES:
            break
        files.append(MemoryUpload(path, raw))
    if not files:
        raise ValueError('Could not retrieve supported source files from GitHub. Check repository visibility and branch name.')
    result = _analyze_project(files)
    result['filename'] = f'{owner}/{repo}@{branch}'
    result['repository'] = {'provider': 'GitHub', 'owner': owner, 'name': repo, 'branch': branch, 'files_selected': len(files), 'source_bytes': total}
    result['stats']['repository_files_selected'] = len(files)
    result['stats']['repository_branch'] = branch
    return result


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/analyze-repository', methods=['POST'])
def analyze_repository():
    try:
        payload = request.get_json(silent=True) or {}
        repo_url = payload.get('url', '')
        branch = payload.get('branch') or None
        return jsonify(_analyze_github_repository(repo_url, branch))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            message = 'Repository or branch not found, or the repository is private.'
        elif exc.code == 403:
            message = 'GitHub API rate limit or access restriction. Configure GITHUB_TOKEN for higher limits/private repository access.'
        else:
            message = f'GitHub request failed with HTTP {exc.code}.'
        return jsonify({'success': False, 'error': message}), 400
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 400


@app.route('/analyze', methods=['POST'])
def analyze():
    """Analyze pasted source or an uploaded supported source file."""
    try:
        if request.is_json:
            payload = request.get_json(silent=True) or {}
            return jsonify(_analyze_source(payload.get("code", ""), payload.get("filename", "pasted_code.py")))

        project_files = request.files.getlist('files')
        if project_files:
            return jsonify(_analyze_project(project_files))

        if 'project_zip' in request.files:
            uploaded_zip = request.files['project_zip']
            if uploaded_zip.filename.lower().endswith('.zip'):
                return jsonify(_analyze_project_zip(uploaded_zip))

        if 'file' not in request.files:
            return jsonify({"success": False, "error": "Provide source code, upload a file, or upload a project folder"}), 400
        uploaded = request.files['file']
        if uploaded.filename == '':
            return jsonify({"success": False, "error": "Empty filename"}), 400
        source = uploaded.read().decode('utf-8')
        return jsonify(_analyze_source(source, uploaded.filename))
    except UnicodeDecodeError:
        return jsonify({"success": False, "error": "The uploaded file is not valid UTF-8 source code"}), 400
    except SyntaxError as e:
        return jsonify({"success": False, "error": f"Python syntax error at line {getattr(e, 'lineno', '?')}: {e.msg}"}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/inspect-zip', methods=['POST'])
def inspect_zip():
    """Inspect a ZIP file without running full analysis, returning file tree and sources."""
    try:
        if 'project_zip' not in request.files:
            return jsonify({'success': False, 'error': 'No project_zip file provided'}), 400
        uploaded_zip = request.files['project_zip']
        raw = uploaded_zip.read()
        if len(raw) > 50 * 1024 * 1024:
            return jsonify({'success': False, 'error': 'Project ZIP exceeds 50 MB limit.'}), 400
        entries = []
        file_sources = {}
        ignored_dirs = {'node_modules', '.git', '.venv', 'venv', '__pycache__', 'build', 'dist', 'target', '.idea'}
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = _safe_relative_name(info.filename)
                parts = name.split('/')
                if any(p in ignored_dirs for p in parts[:-1]):
                    continue
                if info.file_size > 2 * 1024 * 1024:
                    continue
                try:
                    content = z.read(info).decode('utf-8', errors='replace')
                    file_sources[name] = content
                    entries.append({'path': name, 'size': info.file_size})
                except Exception:
                    pass
        return jsonify({
            'success': True,
            'filename': os.path.basename(uploaded_zip.filename),
            'files': entries,
            'file_sources': file_sources
        })
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 400


@app.route('/scan-dependencies', methods=['POST'])
def scan_dependencies_route():
    """Software Composition Analysis endpoint for requirements.txt and package.json."""
    try:
        content = ""
        filename = "requirements.txt"
        if request.is_json:
            payload = request.get_json(silent=True) or {}
            content = payload.get("content", "")
            filename = payload.get("filename", "requirements.txt")
        elif 'file' in request.files:
            uploaded = request.files['file']
            filename = uploaded.filename
            content = uploaded.read().decode('utf-8', errors='replace')
        elif 'content' in request.form:
            content = request.form['content']
            filename = request.form.get('filename', 'requirements.txt')

        if not content:
            return jsonify({'success': False, 'error': 'No dependency manifest content provided'}), 400

        res = scan_dependencies(content, filename)
        return jsonify(res)
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 400


@app.route('/groq-status', methods=['GET'])
def groq_status():
    """Report Groq API availability without exposing the key."""
    try:
        status = groq_check_status()
        return jsonify({'success': True, **status})
    except Exception as exc:
        return jsonify({'success': True, 'available': False, 'error': str(exc), 'supported_models': SUPPORTED_MODELS})


@app.route('/groq-models', methods=['GET'])
def groq_models():
    """Return the list of supported Groq models."""
    models = groq_get_available_models()
    return jsonify({'success': True, 'models': models, 'current': os.getenv('GROQ_MODEL', models[0]['id'] if models else 'llama-3.3-70b-versatile')})


@app.route('/groq-set-model', methods=['POST'])
def groq_set_model():
    """Allow the frontend to change the active model for the current server session."""
    payload = request.get_json(silent=True) or {}
    model_id = payload.get('model', '').strip()
    valid_ids = {m['id'] for m in (SUPPORTED_MODELS + GEMINI_MODELS + XAI_MODELS)}
    if model_id not in valid_ids:
        return jsonify({'success': False, 'error': f'Unknown model: {model_id}'}), 400
    os.environ['GROQ_MODEL'] = model_id
    return jsonify({'success': True, 'model': model_id})


@app.route('/groq-set-key', methods=['POST'])
def groq_set_key():
    """Allow the frontend to save and verify an API key without manual terminal commands."""
    payload = request.get_json(silent=True) or {}
    key = payload.get('api_key', '').strip()
    if not key:
        return jsonify({'success': False, 'error': 'API key cannot be empty.'}), 400
    try:
        persist = bool(payload.get('persist', True))
        status = groq_save_api_key(key, persist_to_env=persist)
        return jsonify({'success': True, 'status': status})
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 500


@app.route('/ai-investigate', methods=['POST'])
def ai_investigate():
    """Run a bounded Groq AI verification pass on a single source file."""
    try:
        payload = request.get_json(silent=True) or {}
        code = payload.get('code', '')
        filename = payload.get('filename', 'source.py')
        findings = payload.get('findings', [])
        graph_context = payload.get('graph_context', {})
        if not isinstance(findings, list):
            findings = []
        if not isinstance(graph_context, dict):
            graph_context = {}
        return jsonify(groq_investigate(code, filename, findings, graph_context))
    except GroqAIError as exc:
        return jsonify({'success': False, 'error': str(exc)}), 503
    except Exception:
        app.logger.exception('AI investigation failed')
        return jsonify({'success': False, 'error': 'AI investigation failed. Check server logs for details.'}), 500


@app.route('/ai-chat', methods=['POST'])
def ai_chat():
    """Chat with the Groq model about the current source and scanner findings."""
    try:
        payload = request.get_json(silent=True) or {}
        cached_proj = _project_cache.get('latest', {})
        project_files = payload.get('project_files') or cached_proj.get('file_sources', None)
        findings = payload.get('findings')
        if findings is None:
            findings = cached_proj.get('findings', [])
        return jsonify(groq_chat(
            payload.get('message', ''),
            payload.get('code', ''),
            payload.get('filename', 'source'),
            findings,
            project_files,
        ))
    except GroqAIError as exc:
        return jsonify({'success': False, 'error': str(exc)}), 503
    except Exception:
        app.logger.exception('AI chat failed')
        return jsonify({'success': False, 'error': 'AI chat failed. Check server logs for details.'}), 500


@app.route('/ai-chat/stream', methods=['POST'])
def ai_chat_stream():
    """Server-Sent Events streaming endpoint for AI chat."""
    try:
        payload = request.get_json(silent=True) or {}
        message = payload.get('message', '')
        code = payload.get('code', '')
        filename = payload.get('filename', 'source')
        cached_proj = _project_cache.get('latest', {})
        findings = payload.get('findings')
        if findings is None:
            findings = cached_proj.get('findings', [])
        project_files = payload.get('project_files') or cached_proj.get('file_sources', None)

        def generate():
            try:
                for chunk in groq_chat_stream(message, code, filename, findings, project_files):
                    yield chunk
            except Exception as exc:
                import json as _json
                yield f"data: {_json.dumps({'error': str(exc)})}\n\n"

        return Response(
            stream_with_context(generate()),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive',
            }
        )
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 500


@app.route('/ai-auto-repair-loop', methods=['POST'])
def ai_auto_repair_loop():
    """Autonomous iterative repair & validation loop (up to max_iterations, capped at 3)."""
    try:
        payload = request.get_json(silent=True) or {}
        code = payload.get('code', '')
        filename = payload.get('filename', 'source.py')
        findings = payload.get('findings', None)
        max_iterations = int(payload.get('max_iterations', 3))

        result = groq_auto_repair_loop(
            code=code,
            filename=filename,
            findings=findings,
            max_iterations=max_iterations,
            analyze_fn=_analyze_source
        )
        if result.get('success') and result.get('repaired_code'):
            try:
                final_analysis = _analyze_source(result['repaired_code'], filename)
                _project_cache['latest'] = {
                    'file_sources': {filename: result['repaired_code']},
                    'findings': final_analysis.get('vulnerabilities', []),
                    'project_graph': {},
                    'files': [{'file': filename, 'findings': len(final_analysis.get('vulnerabilities', []))}]
                }
                result['validation_data'] = final_analysis
            except Exception:
                pass
        return jsonify(result)
    except GroqAIError as exc:
        return jsonify({'success': False, 'error': str(exc)}), 503
    except Exception:
        app.logger.exception('AI auto-repair loop failed')
        return jsonify({'success': False, 'error': 'AI auto-repair loop failed. Check server logs.'}), 500


@app.route('/ai-repair', methods=['POST'])
def ai_repair():
    """Generate proposed repair. If auto_loop is requested, executes iterative repair & re-check."""
    try:
        payload = request.get_json(silent=True) or {}
        code = payload.get('code', '')
        filename = payload.get('filename', 'source.py')
        findings = payload.get('findings', [])
        auto_loop = bool(payload.get('auto_loop', True))
        max_iterations = int(payload.get('max_iterations', 3))

        if not isinstance(findings, list):
            findings = []

        if auto_loop:
            return ai_auto_repair_loop()
        return jsonify(groq_repair_code(code, filename, findings))
    except GroqAIError as exc:
        return jsonify({'success': False, 'error': str(exc)}), 503
    except Exception:
        app.logger.exception('AI repair failed')
        return jsonify({'success': False, 'error': 'AI repair failed. Check server logs for details.'}), 500


@app.route('/export-report', methods=['POST'])
def export_report():
    """Export scan results as structured JSON (PDF export is frontend-side)."""
    try:
        payload = request.get_json(silent=True) or {}
        analysis_data = payload.get('analysis', {})
        fmt = payload.get('format', 'json').lower()

        if fmt == 'json':
            report = {
                'report_type': 'SecureCode AI Security Report',
                'generated_at': __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
                'filename': analysis_data.get('filename', 'unknown'),
                'summary': analysis_data.get('summary', {}),
                'vulnerabilities': analysis_data.get('vulnerabilities', []),
                'stats': analysis_data.get('stats', {}),
                'files': analysis_data.get('files', []),
            }
            response = Response(
                json.dumps(report, indent=2, ensure_ascii=False),
                mimetype='application/json',
                headers={'Content-Disposition': 'attachment; filename="securecode-report.json"'}
            )
            return response
        else:
            return jsonify({'success': False, 'error': 'Only JSON format is supported server-side. Use PDF export in the browser.'}), 400
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 500


@app.route('/ai-firewall/status', methods=['GET'])
def ai_firewall_status():
    return jsonify({'success': True, 'enabled': True, 'layers': ['chat prompt screening', 'untrusted source isolation', 'AI response schema validation', 'bounded input sizes', 'no source-code execution', 'code skeletonization & credential redaction']})


@app.route('/ai-firewall/demo', methods=['GET'])
def ai_firewall_demo():
    """Run deterministic, harmless prompt-injection and guardrail test cases."""
    results = ai_firewall_demo_cases()
    return jsonify({'success': True, 'results': results, 'passed': sum(1 for item in results if item['passed']), 'total': len(results), 'note': 'These are deterministic firewall simulations; they do not call the AI model and do not prove resistance to every attack.'})


@app.route('/ai-firewall/check', methods=['POST'])
def ai_firewall_check():
    payload = request.get_json(silent=True) or {}
    message = payload.get('message', '')
    return jsonify({'success': True, 'verdict': ai_firewall_inspect_chat(message)})


# ─── Multi-Agent Architecture API Endpoints ─────────────────────────────────
@app.route('/api/agents', methods=['GET'])
def get_agents():
    """Return all registered agents, their execution modes, and availability."""
    return jsonify({
        "success": True,
        "routing_mode": orchestrator.router.mode,
        "agents": orchestrator.get_agent_status_list()
    })


@app.route('/api/agent-activity', methods=['GET'])
def get_agent_activity():
    """Return real-time activity log of orchestrator executions and handoffs."""
    return jsonify({
        "success": True,
        "routing_mode": orchestrator.router.mode,
        "activities": orchestrator.activity_logs
    })


@app.route('/api/config/routing', methods=['GET', 'POST'])
def config_routing():
    """Get or update multi-agent routing configuration (AUTO, LOCAL_ONLY, ONLINE_ONLY)."""
    if request.method == 'POST':
        payload = request.get_json(silent=True) or {}
        new_mode = payload.get('mode', 'AUTO').upper()
        if new_mode in ('AUTO', 'LOCAL_ONLY', 'ONLINE_ONLY'):
            orchestrator.set_routing_mode(new_mode)
            return jsonify({"success": True, "mode": orchestrator.router.mode})
        return jsonify({"success": False, "error": "Invalid mode. Choose AUTO, LOCAL_ONLY, or ONLINE_ONLY."}), 400

    online_avail = orchestrator.registered_agents["AdvancedVulnerabilityAnalysisAgent"].is_available()
    local_ai_avail = orchestrator.registered_agents["CodeExplanationAgent"].is_available()
    return jsonify({
        "success": True,
        "mode": orchestrator.router.mode,
        "online_available": online_avail,
        "local_ai_available": local_ai_avail,
    })


@app.route('/api/orchestrate', methods=['POST'])
def orchestrate_task():
    """Execute a task through the Master Orchestrator (e.g. self-healing, full analysis)."""
    payload = request.get_json(silent=True) or {}
    action = payload.get("action", "analyze")
    code = payload.get("code", "")
    filename = payload.get("filename", "source.py")

    if action == "self_healing":
        target_vuln = payload.get("target_vuln")
        res = orchestrator.run_self_healing_pipeline(code, filename, target_vuln=target_vuln)
        return jsonify(res)
    elif action == "explain":
        res = orchestrator.execute_task("explain", code=code, filename=filename)
        return jsonify(res.to_dict())
    elif action == "verify":
        original_code = payload.get("original_code", "")
        res = orchestrator.execute_task("verify_repair", code=code, filename=filename, context={"original_code": original_code})
        return jsonify(res.to_dict())
    else:
        res = orchestrator.execute_task("pattern_scan", code=code, filename=filename)
        return jsonify(res.to_dict())


if __name__ == '__main__':
    print("\n[*] SecureCode AI — Groq-Powered Security Analyzer")
    print("[*] Open http://localhost:5000 in your browser")
    key = os.getenv("GROQ_API_KEY", "").strip()
    if not key:
        print("\n[!] WARNING: GROQ_API_KEY not set. AI features will not work.")
        print("[!] Set it with:  set GROQ_API_KEY=your_key_here  (Windows)")
        print("[!] Get a free key at: https://console.groq.com/keys\n")
    else:
        print(f"[*] Groq API key configured. Model: {os.getenv('GROQ_MODEL', 'llama-3.3-70b-versatile')}\n")
    app.run(debug=False, port=5000)
