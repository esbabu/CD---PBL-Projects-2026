# SecureCode AI v21 — Selective Agent Workflow + UI Refresh

## What's new
- Added a visible **Investigate → Repair → Validate** workflow card with step-by-step status.
- Added **Run Agentic Workflow**, which coordinates the existing local AI investigation, repair proposal, and static re-analysis steps in sequence.
- Each step stops the workflow if it fails and reports the current stage. The original source is not automatically overwritten.
- Added responsive step cards, active/completed/error states, and a cleaner review panel style.
- Existing deterministic scanner remains the baseline; the UI clearly describes AI repair as a proposal, not a guarantee.

## Limits
- AI steps require a running local Ollama service and the configured model.
- This workflow currently applies to a single analyzed source file, not an entire repository.
- Static re-analysis is not proof of exploitability or proof that repaired code is secure. Review proposed changes before using them.

## Validation performed
- Python syntax compilation and JavaScript syntax check passed.
- Live Flask/Ollama end-to-end workflow was not run in this environment.

## v22 — AI Firewall + Attack Simulation Lab
- Added `ai_firewall.py`, a deterministic guard layer for direct chat prompts, untrusted source indicators, input bounds, and basic AI response shape validation.
- Direct chat requests matching instruction override, hidden-prompt extraction, secret-exfiltration, safety-bypass, or privileged-tool-execution patterns are blocked before calling Ollama.
- Prompt-injection-like text inside submitted source is flagged and passed as untrusted source data; it is not treated as an instruction and does not prevent static analysis.
- Investigation, chat, and repair calls check source size before passing context to Ollama. AI outputs are schema-checked before use.
- Added `/ai-firewall/status`, `/ai-firewall/demo`, and `/ai-firewall/check` endpoints.
- Added an **AI Firewall & Attack Simulation Lab** to the UI. Its seven harmless cases demonstrate BLOCK, FLAG, and ALLOW behavior without calling the model.
- Added `tests/test_ai_firewall.py` for deterministic unit tests.

### Important security limits
This is a lightweight pattern-based firewall and defense-in-depth layer, not a complete prompt-injection solution. Attackers can rephrase or obfuscate prompts beyond fixed signatures. The UI's PASS results only mean these known test cases behaved as expected. Keep model/tool permissions restricted, never execute uploaded code, protect the Flask service with authentication/CSRF/rate limits when exposed beyond localhost, and review model-generated repairs.
