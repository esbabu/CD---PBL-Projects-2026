# SQL / ORM Injection Detection System

A static analysis tool that detects **SQL injection** and **ORM injection** vulnerabilities in Python source code using taint tracking and AST traversal. Built as part of a Compiler Design course (Week 11).

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [How It Works](#how-it-works)
- [Usage](#usage)
- [Sample Programs](#sample-programs)
- [Vulnerability IDs and Severity](#vulnerability-ids-and-severity)
- [Supported Sinks](#supported-sinks)
- [Supported Taint Sources & Sanitizers](#supported-taint-sources--sanitizers)
- [Output](#output)
- [Limitations](#limitations)

---

## Overview

This tool performs **static taint analysis** on Python code to detect injection vulnerabilities. It:

1. Parses a Python `.py` file (or uses built-in demo ASTs) into a unified AST representation.
2. Tracks which variables are *tainted* (originating from user input).
3. Flags tainted data that flows into SQL or ORM query sinks — without being sanitized or parameterized.

No code is executed; this is purely **compile-time / static analysis**.

---

## Features

- **SQL Injection Detection** — catches `cursor.execute(query)` with tainted query strings built via concatenation or format strings
- **ORM Injection Detection** — extends coverage to Django ORM, SQLAlchemy, and Peewee ORM methods
- **Taint Propagation** — taint flows through assignments, binary expressions, and function calls
- **Sanitization Awareness** — variables passed through sanitizers (e.g. `sanitize()`, `bindparam()`) are marked safe
- **Parameterized Query Recognition** — detects safe patterns like `cursor.execute(query, (param,))` and skips them
- **Dual Report Formats** — human-readable text report and structured JSON report
-  **Real File Analysis** — parses actual `.py` files via Python's built-in `ast` module
-  **Severity Classification** — `HIGH` for string concatenation, `MEDIUM` for other patterns
-  **False Positive Filtering** — suppresses low-confidence or sanitized findings

---

## Architecture

The system follows a **3-module pipeline** controlled by an AST Traverser:

```
Python Source File
        │
        ▼
 PythonASTBridge          ← Parses .py → custom AST nodes (unified_types)
        │
        ▼
   ASTTraverser           ← Orchestrates two-pass analysis
   ┌────┴────┐
   │  Pass 1 │  InputDetectionModule   ← Labels taint sources in SymbolTable
   │  Pass 2 │  RuleEngineModule       ← Checks SQL / ORM sinks for tainted args
   └────┬────┘
        │
        ▼
 WarningDecisionLogic     ← Filters false positives, generates reports
```

---

## Project Structure

```
endpoitnweek6_new/
│
├── main.py                    # Entry point — demo mode or file analysis mode
├── unified_types.py           # Shared AST node types, SymbolTable, TaintState, VulnerabilityEvent
│
├── module1_input_detection.py # Pass 1: detects taint sources; updates SymbolTable
├── module2_rule_engine.py     # Pass 2: applies SQL and ORM injection detection rules
├── module3_warning_logic.py   # Post-processing: filters events, generates reports
│
├── ast_traverser.py           # Orchestrator: runs Pass 1 → Pass 2 over the AST
├── python_ast_bridge.py       # Translates Python's built-in ast → unified_types nodes
│
├── demo_programs.py           # Hand-crafted ASTs for built-in demo cases
│
├── sample_target.py           # Sample vulnerable Python file (for file-mode testing)
├── sample_safe.py             # Sample safe Python file
├── sample_mixed.py            # Sample file with both safe and vulnerable patterns
│
└── users.db                   # SQLite database (used by sample programs)
```

---

## How It Works

### 1. Taint Analysis (Pass 1 — `InputDetectionModule`)

Variables assigned from known **taint sources** (e.g. `input()`, `request.getParameter()`) are marked `TAINTED` in the `SymbolTable`.

Variables assigned from **sanitization functions** (e.g. `sanitize()`, `bindparam()`) are marked `SANITIZED`.

Taint propagates through expressions:
- If *either side* of a binary expression (`a + b`) is tainted, the result is tainted.
- If a function call has *any* tainted argument, the call's result is tainted (conservative).

### 2. Sink Detection (Pass 2 — `RuleEngineModule`)

The traverser visits every `FunctionCall` node. If it is a known SQL or ORM **sink**, the rule engine:
1. Checks whether any argument is tainted.
2. Checks whether the call uses **parameterized queries** (safe pattern — skipped).
3. Classifies how the tainted data reaches the sink (`string_concatenation`, `format_string`, `direct_variable`, or ORM-specific types).
4. Creates a `VulnerabilityEvent` with an ID, severity, description, and suggested fix.

### 3. Reporting (`WarningDecisionLogic`)

Detected vulnerabilities are filtered (low confidence or sanitized findings are suppressed) and then emitted as:
- **Text report** — human-readable summary with rule violated and fix suggestion.
- **JSON report** — structured output suitable for tooling integration.

---

## Usage

### Prerequisites

- Python 3.8 or higher
- No third-party packages required (uses only the standard library)

### Run Built-in Demo Cases

```bash
python main.py
```

Runs four hand-crafted demo programs to illustrate detection:
1. Vulnerable — String Concatenation
2. Vulnerable — Format String
3. Safe — Parameterized Query
4. Safe — Sanitized Input

### Analyse a Real Python File

```bash
python main.py <path/to/file.py>
```

Example:
```bash
python main.py sample_mixed.py
```

### Help

```bash
python main.py --help
```

---

## Sample Programs

| File | Description |
|------|-------------|
| `sample_target.py` | Minimal vulnerable snippet for quick testing |
| `sample_safe.py` | Safe parameterized query example |
| `sample_mixed.py` | Mixed file with both vulnerable and safe patterns |

---

## Vulnerability IDs and Severity

| Prefix | Type | Severity |
|--------|------|----------|
| `SQLI-XXXX` | Raw SQL injection | `HIGH` (concat) / `MEDIUM` (format/direct) |
| `ORMI-XXXX` | ORM injection | `HIGH` (`.raw()`, `text()`) / `MEDIUM` (`.filter()`, `.where()`, etc.) |

---

## Supported Sinks

### SQL Sinks
| Method | Example |
|--------|---------|
| `execute` | `cursor.execute(query)` |
| `executeQuery` | `db.executeQuery(query)` |
| `executeUpdate` | `db.executeUpdate(query)` |
| `query` | `db.query(query)` |
| `exec` | `conn.exec(query)` |

### ORM Sinks
| Method | Framework | Risk |
|--------|-----------|------|
| `raw` | Django ORM | HIGH |
| `text` | SQLAlchemy | HIGH |
| `filter` | Django ORM | MEDIUM |
| `where` | SQLAlchemy / Peewee | MEDIUM |
| `get` | Django ORM | MEDIUM |
| `select` | SQLAlchemy / Peewee | MEDIUM |
| `having` | ORM general | MEDIUM |
| `order_by` | ORM general | MEDIUM |

---

## Supported Taint Sources & Sanitizers

### Taint Sources (mark variable as `TAINTED`)
- `input()`, `raw_input()`
- `request.getParameter()`, `getQueryString()`, `getHeader()`, `getCookie()`
- `readLine()`, `nextLine()`, `Scanner.nextLine()`

### Sanitization Functions (mark variable as `SANITIZED`)
- `sanitize()`, `escapeSql()`, `prepareStatement()`
- `bindparam()`, `literal()`, `func()` *(SQLAlchemy safe wrappers)*

---

## Output

### Text Report (sample)
```
======================================================================
SQL / ORM INJECTION VULNERABILITY REPORT
======================================================================

Total Vulnerabilities Found: 1
High Severity: 1
Medium Severity: 0
Events Filtered: 0

[1] SQLI-0001 - HIGH SEVERITY
    Line: 3
    Function: execute
    Variable: query
    Sink: cursor.execute
    Rule Violated: SQL-CONCAT: Tainted data in string concatenation
    Construction: string_concatenation
    Description: Tainted data flows into SQL sink via string concatenation. ...
    Suggested Fix: Use parameterized queries with placeholders (?, :param) ...
```

### JSON Report (sample)
```json
{
  "summary": {
    "total_vulnerabilities": 1,
    "high_severity": 1,
    "medium_severity": 0,
    "filtered": 0
  },
  "vulnerabilities": [
    {
      "id": "SQLI-0001",
      "severity": "HIGH",
      "line": 3,
      "variable": "query",
      "sink": "cursor.execute",
      "rule_violated": "SQL-CONCAT: Tainted data in string concatenation",
      "construction": "string_concatenation",
      "description": "...",
      "suggested_fix": "Use parameterized queries with placeholders (?, :param) ..."
    }
  ]
}
```

---

## Limitations

- **Single-file analysis only** — does not cross module/import boundaries.
- **No inter-procedural analysis** — taint does not propagate across function calls into separate function definitions.
- **Conservative f-string handling** — f-strings are treated as a single tainted identifier (`__fstring__`) rather than being decomposed.
- **No loop/branch sensitivity** — taint state inside conditionals or loops is not separately tracked per branch.
- **Limited expression support** — complex expression types (list comprehensions, lambdas, ternaries) are silently skipped.

---

## Course Context

This project was developed over multiple weeks as part of a **Compiler Design** course, building progressively toward a full static analysis pipeline:

- **Week 6 Base**: Core SQL injection detection with taint tracking.
- **Week 11 Extension**: Added ORM injection detection, `PythonASTBridge` for real Python file parsing, and unified type integration between components.
