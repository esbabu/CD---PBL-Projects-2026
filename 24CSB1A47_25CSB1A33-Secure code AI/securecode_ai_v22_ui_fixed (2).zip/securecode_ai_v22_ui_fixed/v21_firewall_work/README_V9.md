# SecureCode v9 – Multi-Language Security Analyzer

SecureCode is a compiler-inspired static security analyzer. The original Python AST/taint/rule pipeline is retained and supplemented with language-aware security analysis for JavaScript, Java, C and C++.

The analyzer now covers multiple security categories including injection, command execution, XSS, SSRF, path/file risks, secrets, weak cryptography/randomness, unsafe deserialization, TLS configuration, dangerous APIs, and memory-safety indicators.

The design remains modular so stronger parsers, a common Security IR, interprocedural analysis and agentic verification/repair can be added later without replacing the core analysis pipeline.
