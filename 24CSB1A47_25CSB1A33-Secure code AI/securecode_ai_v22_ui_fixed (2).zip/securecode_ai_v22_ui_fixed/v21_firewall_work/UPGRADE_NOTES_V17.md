# SecureCode AI V17 — Repair + Explain

- New `POST /ai-repair` route for local Ollama-generated source repairs.
- Programmatic diff-derived line ranges; AI does not determine the authoritative line numbers.
- AI explanations per change: reason, security benefit, and vulnerability addressed.
- Frontend shows each before/after change, the full proposed repaired source, download action, and static re-analysis action.
- Original file is not overwritten; repaired source is not executed.
- Single-file workflow only. Ollama/model required. Human review and tests remain necessary.
