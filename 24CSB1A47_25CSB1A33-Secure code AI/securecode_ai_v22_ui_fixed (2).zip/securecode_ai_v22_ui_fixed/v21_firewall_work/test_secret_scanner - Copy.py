import unittest
import os
import sys

# Ensure v21_firewall_work is in path
sys.path.insert(0, os.path.dirname(__file__))

from secret_scanner import scan_secrets, mask_secret, shannon_entropy

class TestSecretScanner(unittest.TestCase):
    def test_aws_key_detection(self):
        code = 'AWS_KEY = "AKIA1234567890ABCDEF"'
        findings = scan_secrets(code)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["rule_violated"], "SEC-AWS-KEY")
        self.assertEqual(findings[0]["severity"], "CRITICAL")
        self.assertTrue("AKIA" in findings[0]["evidence"])
        self.assertTrue("*" in findings[0]["evidence"])

    def test_stripe_key_detection(self):
        code = 'stripe.api_key = "sk_live_51Abcdefghijklmnopqrstuvwx"'
        findings = scan_secrets(code)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["rule_violated"], "SEC-STRIPE-KEY")

    def test_google_key_detection(self):
        code = 'GEMINI_KEY = "AQ.Ab8RN6KuZISR_Nei_IBAzE5byVRXd18zxjejYVMCpvOa_F9pPw"'
        findings = scan_secrets(code)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["rule_violated"], "SEC-GOOGLE-KEY")
        self.assertNotIn("VRXd18zxjej", findings[0]["evidence"]) # Masked

    def test_github_token_detection(self):
        code = 'GITHUB_TOKEN = "ghp_1234567890abcdefghijklmnopqrstuvwxyz"'
        findings = scan_secrets(code)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["rule_violated"], "SEC-GITHUB-TOKEN")

    def test_private_key_detection(self):
        code = '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0...\n-----END RSA PRIVATE KEY-----'
        findings = scan_secrets(code)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["rule_violated"], "SEC-PRIVATE-KEY")

    def test_entropy_and_masking(self):
        secret = "sk_live_1234567890abcdef12345678"
        masked = mask_secret(secret)
        self.assertTrue(masked.startswith("sk_l"))
        self.assertTrue("*" in masked)
        self.assertTrue(masked.endswith("5678"))

if __name__ == "__main__":
    unittest.main()
