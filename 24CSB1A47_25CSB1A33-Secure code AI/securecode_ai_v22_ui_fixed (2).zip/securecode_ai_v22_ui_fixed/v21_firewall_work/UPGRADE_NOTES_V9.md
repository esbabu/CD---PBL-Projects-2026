# SecureCode v9 – Extended Security Detection

This release extends the existing compiler/static-analysis project without removing the original Python AST/taint/rule pipeline.

## Detection expansion

### Shared taint/source-to-sink engine
- request/query/body/header/cookie sources
- process/environment/console input sources
- variable-to-variable propagation
- common sanitizers
- source → assignment → sink evidence

### JavaScript
- SQL injection / dynamic SQL
- command injection
- XSS / unsafe HTML sinks
- SSRF / unsafe HTTP requests
- path traversal / filesystem sinks
- dynamic code execution (`eval`, `new Function`)
- weak randomness (`Math.random`)
- unsafe deserialization indicators
- prototype-pollution indicators
- open redirect indicators
- weak hashes
- TLS verification bypass
- sensitive logging / secret exposure
- dangerous Node modules

### Java
- SQL injection / dynamic SQL
- command injection
- SSRF
- filesystem/path sinks
- unsafe deserialization
- XXE-risk XML parser configuration
- weak hashes and legacy ciphers
- weak randomness (`Random` vs `SecureRandom`)
- TLS verification bypass
- open redirect indicators
- sensitive logging / secret exposure

### C / C++
- command injection
- SQL API sinks
- path/file operation sinks
- unsafe string APIs and format strings
- unbounded `scanf %s`
- weak randomness
- weak hashes
- permissive file permissions
- memory-safety review indicators
- input/argv/cin/scanf/fgets/recv/read taint sources

### Python
The original Python AST/TOC/static-analysis pipeline remains intact, including the existing broad Python security analyzer.

## Validation performed
- Existing multi-language regression suite: 4/4 passed.
- Extended coverage checks: 7/7 passed.
- Existing broad Python security tests: 4/4 passed.
- Exact JavaScript SQL-injection example: detected as HIGH SQL-INJECTION.
- Java SQL-injection and command-injection examples: detected.

## Scope note
The non-Python language frontends are intentionally lightweight static analysis rather than full compiler-grade parsers/type systems. Findings should therefore be treated as security indicators with confidence, not as formal proofs of exploitability.
