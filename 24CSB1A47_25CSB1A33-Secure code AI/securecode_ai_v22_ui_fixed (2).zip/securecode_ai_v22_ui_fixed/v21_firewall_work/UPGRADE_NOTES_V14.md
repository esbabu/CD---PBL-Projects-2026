# SecureCode V14 — VS Code-style workspace

## UI changes
- Left-hand project explorer lists uploaded folder files.
- Code editor moved into the left workspace pane.
- Analysis results occupy a separate right pane with its own scrolling.
- Added a draggable divider to resize editor and results panes (keyboard ArrowLeft/ArrowRight supported when the divider is focused).
- Added quick actions for opening a file, folder, or ZIP, plus explorer collapse.
- Responsive stacked layout for narrow screens.

## Preserved features
- Multi-language static analysis for Python, JavaScript, Java, C, and C++.
- Folder and ZIP project scans.
- GitHub repository analysis and project relationship graph.
- Existing vulnerability findings, severity filters, symbol table, and statistics.

## Notes
- Unsupported files from selected folders are shown in the explorer but are not scanned.
- For folder projects, edits made in the editor are sent with the next project analysis. ZIP and remote repository source files are listed after analysis; to edit those sources, extract/clone the project or upload its folder.
