# Broad Security Upgrade — no Agentic AI

This version starts from the original seniors' project and **keeps the existing
compiler-style SQL/ORM pipeline intact**. The upgrade adds a separate,
read-only Python AST security pass (`broad_security_analyzer.py`).

## What remains unchanged

The original flow is still present:

Python source -> PythonASTBridge -> custom AST -> ASTTraverser ->
Input/Taint Detection -> SQL/ORM Rule Engine -> Warning Logic

The existing SQL/ORM IDs and reports are preserved.

## What was added

The supplemental pass covers common Python security weaknesses including:

- SQL injection missed by the legacy custom AST (including Flask request data,
  f-strings, concatenation and direct tainted expressions)
- Command/shell injection
- Dynamic code execution (`eval`, `exec`, `compile`)
- Server-side template injection
- Reflected XSS indicators
- SSRF-style tainted outbound URLs
- Path traversal / tainted filesystem paths
- Unsafe deserialization (`pickle`, `dill`, `marshal`, unsafe YAML)
- Hard-coded secrets
- Weak cryptographic hashes (MD5/SHA-1)
- AES-ECB
- Insecure randomness in security-sensitive contexts
- TLS certificate verification disabled
- JWT signature verification disabled
- Insecure temporary-file creation (`tempfile.mktemp`)
- Archive extraction path-traversal risk
- Flask debug mode
- Wildcard CORS
- Basic XML parser hardening warning

The detector uses lightweight taint propagation and reports severity,
confidence, category, evidence line, and remediation advice.

## Important scope

This is a broad static analyzer, not a proof that a program is secure.
Static analysis can miss vulnerabilities that depend on runtime state, external
services, framework configuration, or cross-file data flow. Some patterns are
reported as suspicious indicators rather than certain vulnerabilities.

## Run from source

Install dependencies:

    python -m pip install -r requirements.txt

CLI:

    python main.py sample_target.py

Web UI:

    python app.py

Then open:

    http://127.0.0.1:5000

Regression tests:

    python test_broad_security.py

## Web response

The API returns `success`, a combined summary, categories, severity counts,
the original symbol table, and findings from both analysis layers.

## Web UI Code Workspace

The web interface now supports three equivalent workflows without changing the analysis engine:

1. Write Python directly in the built-in editor.
2. Copy/paste Python into the editor.
3. Upload a `.py` file; the browser reads it into the editor so the user can view and review the uploaded source before pressing **Run Analysis**.

The backend `/analyze` endpoint accepts both JSON source (`{"code": ..., "filename": ...}`) and the original multipart file upload format for compatibility.


## Multi-language support

The web analyzer now accepts Python, JavaScript, Java, C and C++ source. Python continues to use the existing Python AST/compiler pipeline plus the broad Python AST pass. JavaScript, Java, C and C++ use language-aware lexical/pattern checks for common security sinks such as SQL injection, command injection, XSS, SSRF indicators, unsafe deserialization, weak cryptography, secrets, and C/C++ memory-safety APIs. These non-Python checks are intentionally presented as static indicators rather than a complete parser or proof of exploitability.

Supported extensions: `.py`, `.js`, `.jsx`, `.mjs`, `.cjs`, `.java`, `.c`, `.h`, `.cc`, `.cpp`, `.cxx`, `.hpp`.

The editor has a language selector, language-specific sample programs, and automatic language detection when a file is loaded.
