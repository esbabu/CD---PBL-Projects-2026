"""Software Composition Analysis (SCA) & Dependency Vulnerability Scanner.

Scans Python requirements.txt and Node.js package.json files for known CVEs,
insecure package versions, and recommends upgraded versions.
"""

from __future__ import annotations
import json
import re
import urllib.request
import urllib.error
from typing import Dict, List, Any, Optional, Tuple


def _parse_version_tuple(v_str: str) -> Tuple[int, ...]:
    """Parse a semantic version string into a numeric tuple for comparison."""
    # Strip non-numeric suffixes like -rc1, .post2
    clean = re.sub(r"[^0-9.]", "", v_str.strip().split("-")[0].split("+")[0])
    parts = []
    for p in clean.split("."):
        if p.isdigit():
            parts.append(int(p))
    return tuple(parts) if parts else (0,)


def _version_less_than(v1: str, v2: str) -> bool:
    """Return True if v1 < v2."""
    t1 = _parse_version_tuple(v1)
    t2 = _parse_version_tuple(v2)
    # Pad shorter tuple with zeros
    max_len = max(len(t1), len(t2))
    p1 = t1 + (0,) * (max_len - len(t1))
    p2 = t2 + (0,) * (max_len - len(t2))
    return p1 < p2


# Curated, authoritative advisory database of high-impact ecosystem vulnerabilities
KNOWN_ADVISORIES: Dict[str, Dict[str, List[Dict[str, Any]]]] = {
    "PyPI": {
        "requests": [
            {
                "cve": "CVE-2023-32681",
                "severity": "MEDIUM",
                "cvss": 6.1,
                "fixed_in": "2.31.0",
                "title": "Proxy-Authorization Header Leak to HTTPS Destination",
                "desc": "Requests leaks sensitive Proxy-Authorization headers to destination servers when following redirects.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-32681"
            },
            {
                "cve": "CVE-2018-18074",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "2.20.0",
                "title": "HTTP Session Authentication Leak On Redirect",
                "desc": "Requests forwards Authorization headers to HTTPS redirected hosts even if host changes.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2018-18074"
            }
        ],
        "urllib3": [
            {
                "cve": "CVE-2023-45803",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "1.26.18",
                "title": "Request Body / Header Leakage on Cross-Origin Redirect",
                "desc": "urllib3 fails to strip Cookie and Authorization headers on cross-origin redirects.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-45803"
            },
            {
                "cve": "CVE-2021-33503",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "1.26.5",
                "title": "Catastrophic ReDoS in URL Authority Parsing",
                "desc": "Specially crafted URLs can cause exponential regex backtracking leading to Denial of Service.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2021-33503"
            }
        ],
        "jinja2": [
            {
                "cve": "CVE-2024-22195",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "3.1.3",
                "title": "Server-Side Template Injection via xmlattr Filter",
                "desc": "xmlattr filter allows injection of arbitrary HTML/script attributes due to improper key escaping.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2024-22195"
            },
            {
                "cve": "CVE-2024-34064",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "3.1.4",
                "title": "Template Sandbox Escape via Crafted Keys",
                "desc": "Sandbox escape in xmlattr key evaluation allows execution of arbitrary Python objects.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2024-34064"
            }
        ],
        "flask": [
            {
                "cve": "CVE-2023-30861",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "2.2.5",
                "title": "Session Cookie Leaking via Public Cache",
                "desc": "Responses with Vary: Cookie may be cached by intermediate proxies, exposing user session cookies.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-30861"
            }
        ],
        "django": [
            {
                "cve": "CVE-2023-46695",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "4.2.8",
                "title": "Denial of Service in UsernameField Validation",
                "desc": "Excessive regex processing in UsernameField allows remote denial of service via long input strings.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-46695"
            },
            {
                "cve": "CVE-2022-34265",
                "severity": "HIGH",
                "cvss": 8.8,
                "fixed_in": "4.0.6",
                "title": "SQL Injection in Trunc() and Extract() Database Functions",
                "desc": "Trunc() and Extract() database functions are vulnerable to SQL injection via unvalidated lookup arguments.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2022-34265"
            }
        ],
        "pyyaml": [
            {
                "cve": "CVE-2020-14343",
                "severity": "CRITICAL",
                "cvss": 9.8,
                "fixed_in": "5.4",
                "title": "Arbitrary Code Execution via FullLoader",
                "desc": "PyYAML FullLoader allows arbitrary code execution during deserialization of crafted YAML documents.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2020-14343"
            }
        ],
        "cryptography": [
            {
                "cve": "CVE-2023-49083",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "41.0.6",
                "title": "NULL Pointer Dereference in PKCS7 Parsing",
                "desc": "Calling load_pem_pkcs7_certificates with empty certificate payload crashes the Python process.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-49083"
            }
        ],
        "werkzeug": [
            {
                "cve": "CVE-2023-46136",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "2.3.8",
                "title": "High Resource Consumption in Multipart Parser",
                "desc": "Malformed multipart/form-data payload with excessive boundaries causes high CPU/RAM usage.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-46136"
            }
        ],
        "aiohttp": [
            {
                "cve": "CVE-2024-23334",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "3.9.2",
                "title": "Directory Traversal in Static File Serving",
                "desc": "Static file router allows path traversal when follow_symlinks is enabled on Windows/Linux.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2024-23334"
            }
        ],
        "pillow": [
            {
                "cve": "CVE-2023-44271",
                "severity": "HIGH",
                "cvss": 7.5,
                "fixed_in": "10.0.1",
                "title": "Uncontrolled Memory Allocation in Text Rendering",
                "desc": "ImageFont.truetype can allocate arbitrary memory when handling crafted font bounding boxes.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-44271"
            }
        ]
    },
    "npm": {
        "lodash": [
            {
                "cve": "CVE-2021-23337",
                "severity": "HIGH",
                "cvss": 7.2,
                "fixed_in": "4.17.21",
                "title": "Command Injection in template Function",
                "desc": "Crafted template imports allow execution of arbitrary JavaScript code inside the node process.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2021-23337"
            },
            {
                "cve": "CVE-2020-8203",
                "severity": "HIGH",
                "cvss": 7.4,
                "fixed_in": "4.17.19",
                "title": "Prototype Pollution via zipObjectDeep",
                "desc": "zipObjectDeep allows modification of Object.prototype through crafted nested property names.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2020-8203"
            }
        ],
        "axios": [
            {
                "cve": "CVE-2023-45857",
                "severity": "MEDIUM",
                "cvss": 6.5,
                "fixed_in": "1.6.0",
                "title": "Cross-Origin XSRF-TOKEN and Authorization Header Leak",
                "desc": "Axios forwards sensitive XSRF-TOKEN and Bearer tokens to external hosts during redirect chains.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2023-45857"
            }
        ],
        "express": [
            {
                "cve": "CVE-2024-29041",
                "severity": "MEDIUM",
                "cvss": 6.5,
                "fixed_in": "4.19.2",
                "title": "Open Redirect via Malformed Request URL",
                "desc": "encodeUrl allows open redirects to external untrusted origins via crafted URLs.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2024-29041"
            }
        ],
        "jsonwebtoken": [
            {
                "cve": "CVE-2022-23529",
                "severity": "CRITICAL",
                "cvss": 9.8,
                "fixed_in": "9.0.0",
                "title": "Arbitrary Code Execution via Crafted Key Object",
                "desc": "Passing an untrusted secretOrPublicKey object can trigger remote code execution via toString.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2022-23529"
            }
        ],
        "minimist": [
            {
                "cve": "CVE-2021-44906",
                "severity": "CRITICAL",
                "cvss": 9.8,
                "fixed_in": "1.2.6",
                "title": "Prototype Pollution in CLI Argument Parsing",
                "desc": "minimist parses --__proto__ properties into Object.prototype leading to remote privilege escalation.",
                "advisory": "https://nvd.nist.gov/vuln/detail/CVE-2021-44906"
            }
        ]
    }
}


def parse_requirements_txt(content: str) -> List[Dict[str, str]]:
    """Parse pip requirements.txt format into package and version specifiers."""
    packages = []
    lines = content.splitlines()
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        # Split on common requirement specifiers: ==, >=, <=, ~=, <, >
        match = re.match(r"^([a-zA-Z0-9_\-\.]+)\s*([<>=~]+)\s*([0-9a-zA-Z\.\-]+)", line)
        if match:
            pkg_name = match.group(1).lower().replace("_", "-")
            op = match.group(2)
            version = match.group(3)
            packages.append({"name": pkg_name, "operator": op, "version": version, "raw": line})
        else:
            # Bare package without version
            pkg_match = re.match(r"^([a-zA-Z0-9_\-\.]+)", line)
            if pkg_match:
                pkg_name = pkg_match.group(1).lower().replace("_", "-")
                packages.append({"name": pkg_name, "operator": "", "version": "*", "raw": line})
    return packages


def parse_package_json(content: str) -> List[Dict[str, str]]:
    """Parse npm package.json dependencies and devDependencies."""
    packages = []
    try:
        data = json.loads(content)
    except Exception:
        return packages

    for dep_key in ("dependencies", "devDependencies", "peerDependencies"):
        deps = data.get(dep_key, {})
        if isinstance(deps, dict):
            for pkg_name, ver_spec in deps.items():
                if isinstance(ver_spec, str):
                    clean_ver = re.sub(r"^[\^~>=<]+", "", ver_spec.strip())
                    packages.append({
                        "name": pkg_name.lower(),
                        "operator": ver_spec[:2] if ver_spec.startswith(("^", "~", ">=", "<=")) else "",
                        "version": clean_ver,
                        "raw": f'"{pkg_name}": "{ver_spec}"',
                        "scope": dep_key
                    })
    return packages


def scan_dependencies(content: str, filename: str = "requirements.txt") -> Dict[str, Any]:
    """Perform Software Composition Analysis (SCA) on dependency manifests."""
    is_npm = filename.lower().endswith("package.json") or "dependencies" in content and "{" in content
    ecosystem = "npm" if is_npm else "PyPI"

    if is_npm:
        parsed_packages = parse_package_json(content)
        manifest_type = "npm (package.json)"
    else:
        parsed_packages = parse_requirements_txt(content)
        manifest_type = "Python (requirements.txt)"

    advisories_db = KNOWN_ADVISORIES.get(ecosystem, {})

    vulnerabilities = []
    healthy = []
    recommended_upgrades = {}
    vulnerable_packages = set()

    for pkg in parsed_packages:
        name = pkg["name"]
        version = pkg["version"]
        matched_cves = advisories_db.get(name, [])

        pkg_has_vuln = False
        for adv in matched_cves:
            fixed_in = adv["fixed_in"]
            # If specified version is lower than the fixed_in version:
            if version != "*" and _version_less_than(version, fixed_in):
                pkg_has_vuln = True
                vulnerable_packages.add(name)
                # Store highest recommended version
                current_rec = recommended_upgrades.get(name, fixed_in)
                if _version_less_than(current_rec, fixed_in):
                    recommended_upgrades[name] = fixed_in
                else:
                    recommended_upgrades[name] = current_rec

                vulnerabilities.append({
                    "package": name,
                    "installed_version": version,
                    "fixed_version": fixed_in,
                    "cve": adv["cve"],
                    "severity": adv["severity"],
                    "cvss": adv["cvss"],
                    "title": adv["title"],
                    "description": adv["desc"],
                    "advisory_url": adv["advisory"],
                    "manifest_line": pkg["raw"],
                    "ecosystem": ecosystem
                })

        if not pkg_has_vuln:
            healthy.append({"package": name, "version": version, "raw": pkg["raw"]})

    # Severity counts
    counts = {
        "CRITICAL": sum(1 for v in vulnerabilities if v["severity"] == "CRITICAL"),
        "HIGH": sum(1 for v in vulnerabilities if v["severity"] == "HIGH"),
        "MEDIUM": sum(1 for v in vulnerabilities if v["severity"] == "MEDIUM"),
        "LOW": sum(1 for v in vulnerabilities if v["severity"] == "LOW"),
    }

    # Generate patch / upgrade recommendations
    upgrade_instructions = []
    for pkg_name, target_ver in recommended_upgrades.items():
        if ecosystem == "PyPI":
            upgrade_instructions.append(f"pip install --upgrade '{pkg_name}>={target_ver}'")
        else:
            upgrade_instructions.append(f"npm install {pkg_name}@{target_ver}")

    return {
        "success": True,
        "manifest_type": manifest_type,
        "filename": filename,
        "total_dependencies": len(parsed_packages),
        "vulnerable_count": len(vulnerable_packages),
        "total_cves": len(vulnerabilities),
        "severity_summary": counts,
        "vulnerabilities": vulnerabilities,
        "healthy_dependencies": healthy,
        "recommended_upgrades": recommended_upgrades,
        "upgrade_commands": upgrade_instructions,
        "status": "VULNERABLE" if vulnerabilities else "CLEAN"
    }
