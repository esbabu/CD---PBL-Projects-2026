"""Secret & Hardcoded Credential Scanner for SecureCode AI.

Detects exposed API keys, private keys, authentication tokens, and high-entropy
secrets in source code and configuration files.
"""

from __future__ import annotations
import math
import re
from typing import List, Dict, Any


def shannon_entropy(data: str) -> float:
    """Calculate the Shannon entropy of a string."""
    if not data:
        return 0.0
    entropy = 0.0
    length = len(data)
    for x in set(data):
        p_x = float(data.count(x)) / length
        if p_x > 0:
            entropy += - p_x * math.log2(p_x)
    return entropy


def mask_secret(secret: str) -> str:
    """Mask a sensitive secret string for safe display."""
    secret = secret.strip().strip("'\"")
    if len(secret) <= 8:
        return "*" * len(secret)
    prefix_len = min(4, len(secret) // 4)
    suffix_len = min(4, len(secret) // 4)
    middle_len = len(secret) - prefix_len - suffix_len
    return f"{secret[:prefix_len]}{'*' * middle_len}{secret[-suffix_len:]}"


SECRET_RULES = [
    {
        "id": "SEC-AWS-KEY",
        "name": "AWS Access Key ID",
        "pattern": re.compile(r"\b(AKIA[0-9A-Z]{16})\b"),
        "severity": "CRITICAL",
        "confidence": 0.99,
        "description": "Hard-coded AWS Access Key ID detected.",
        "fix": "Remove the AWS key immediately, rotate it in AWS IAM, and load credentials from IAM roles or environment variables.",
        "impact": "Exposes full or scoped AWS cloud infrastructure to unauthorized API calls, data exfiltration, or resource creation.",
    },
    {
        "id": "SEC-STRIPE-KEY",
        "name": "Stripe Live API Key",
        "pattern": re.compile(r"\b(sk_live_[0-9a-zA-Z]{24,34})\b"),
        "severity": "CRITICAL",
        "confidence": 0.99,
        "description": "Hard-coded Stripe live secret key detected.",
        "fix": "Rotate this key immediately in the Stripe dashboard and store live keys in secure environment variables or vault.",
        "impact": "Grants unrestricted access to process charges, view customer payment data, and modify financial settings.",
    },
    {
        "id": "SEC-STRIPE-TEST",
        "name": "Stripe Test API Key",
        "pattern": re.compile(r"\b(sk_test_[0-9a-zA-Z]{24,34})\b"),
        "severity": "MEDIUM",
        "confidence": 0.95,
        "description": "Hard-coded Stripe test key detected.",
        "fix": "Store test keys in environment configuration files and keep source code free of credentials.",
        "impact": "Allows unauthorized access to sandbox payment environments and customer test data.",
    },
    {
        "id": "SEC-GOOGLE-KEY",
        "name": "Google / Gemini API Key",
        "pattern": re.compile(r"\b(AIza[0-9A-Za-z\-_]{35}|AQ\.[0-9A-Za-z\-_]{40,})\b"),
        "severity": "CRITICAL",
        "confidence": 0.98,
        "description": "Hard-coded Google Cloud or Gemini API key detected.",
        "fix": "Revoke and regenerate the key in Google Cloud Console / AI Studio, and pass via GEMINI_API_KEY environment variable.",
        "impact": "Allows unauthorized consumption of Google Cloud / Gemini AI quota and potential access to linked cloud resources.",
    },
    {
        "id": "SEC-GITHUB-TOKEN",
        "name": "GitHub Personal Access Token",
        "pattern": re.compile(r"\b(gh[pous]_[0-9a-zA-Z]{36}|github_pat_[0-9a-zA-Z_]{82})\b"),
        "severity": "CRITICAL",
        "confidence": 0.99,
        "description": "Hard-coded GitHub authentication token detected.",
        "fix": "Revoke the token immediately on GitHub, audit repository access logs, and use GitHub Actions secrets or environment variables.",
        "impact": "Enables unauthorized git operations, repository cloning, release tampering, or organization access.",
    },
    {
        "id": "SEC-SLACK-TOKEN",
        "name": "Slack Token / Webhook",
        "pattern": re.compile(r"\b(xox[baprs]-[0-9a-zA-Z]{10,48}|https://hooks\.slack\.com/services/T[0-9A-Z]+/B[0-9A-Z]+/[0-9a-zA-Z]+)\b"),
        "severity": "HIGH",
        "confidence": 0.97,
        "description": "Hard-coded Slack bot/user token or incoming webhook detected.",
        "fix": "Regenerate the Slack token/webhook in the Slack API dashboard and store in environment variables.",
        "impact": "Allows eavesdropping on Slack channels, posting messages as a bot, or exfiltrating workspace communications.",
    },
    {
        "id": "SEC-OPENAI-KEY",
        "name": "OpenAI API Key",
        "pattern": re.compile(r"\b(sk-[a-zA-Z0-9]{48,51}|sk-proj-[a-zA-Z0-9\-_]{48,})\b"),
        "severity": "CRITICAL",
        "confidence": 0.98,
        "description": "Hard-coded OpenAI secret API key detected.",
        "fix": "Revoke the key on OpenAI platform dashboard and supply it dynamically via OPENAI_API_KEY.",
        "impact": "Allows unauthorized API usage and exhaustion of paid LLM credits or fine-tuned model access.",
    },
    {
        "id": "SEC-GROQ-KEY",
        "name": "Groq Cloud API Key",
        "pattern": re.compile(r"\b(gsk_[0-9a-zA-Z]{50,60})\b"),
        "severity": "CRITICAL",
        "confidence": 0.99,
        "description": "Hard-coded Groq Cloud API key detected.",
        "fix": "Revoke the key in Groq console and store in GROQ_API_KEY environment variable.",
        "impact": "Enables unauthorized inference queries and consumption of Groq Cloud tier limits.",
    },
    {
        "id": "SEC-PRIVATE-KEY",
        "name": "Private Cryptographic Key",
        "pattern": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----"),
        "severity": "CRITICAL",
        "confidence": 0.99,
        "description": "Embedded private cryptographic key block detected.",
        "fix": "Remove private key from source control immediately, re-generate keypairs, and inject certificates/keys through a secrets manager or TLS agent.",
        "impact": "Total compromise of encrypted communications, SSH server authentication, or digital signatures signed by this key.",
    },
]

# Pattern for credential assignments e.g. password = "...", secret_key = "..."
ASSIGNMENT_SECRET_PATTERN = re.compile(
    r"""(?i)(?:^|[\s,;])(password|passwd|secret|api_key|apikey|auth_token|access_token|private_key|client_secret)\s*[:=]\s*["']([^"'\r\n]{12,})["']"""
)


def scan_secrets(content: str, filename: str = "") -> List[Dict[str, Any]]:
    """Scan file content for hard-coded credentials, private keys, and high-entropy secrets."""
    findings: List[Dict[str, Any]] = []
    if not content or not isinstance(content, str):
        return findings

    lines = content.splitlines()
    seen_keys = set()
    counter = 0

    # 1. Match known high-confidence token signatures
    for line_idx, line in enumerate(lines, 1):
        # Ignore comments indicating mock/test or placeholders
        line_clean = line.strip()
        if any(ph in line_clean.lower() for ph in ("example", "your_api_key", "placeholder", "fake_", "dummy_", "<your-", "xxx")):
            continue

        for rule in SECRET_RULES:
            match = rule["pattern"].search(line)
            if match:
                raw_secret = match.group(0)
                masked = mask_secret(raw_secret)
                dedup_key = (line_idx, rule["id"])
                if dedup_key in seen_keys:
                    continue
                seen_keys.add(dedup_key)
                counter += 1

                findings.append({
                    "id": f"SECRET-{counter:03d}",
                    "severity": rule["severity"],
                    "line": line_idx,
                    "category": "Hard-coded Secret",
                    "rule_violated": rule["id"],
                    "variable": rule["name"],
                    "sink": "source_code",
                    "construction": "hardcoded_credential",
                    "description": f"{rule['description']} Value: {masked}",
                    "suggested_fix": rule["fix"],
                    "confidence": rule["confidence"],
                    "evidence": line_clean[:120].replace(raw_secret, masked),
                    "impact": rule["impact"],
                    "language": "Config/Source",
                })

        # 2. Check generic credential assignments with high Shannon entropy
        assign_match = ASSIGNMENT_SECRET_PATTERN.search(line)
        if assign_match:
            var_name = assign_match.group(1)
            raw_val = assign_match.group(2)
            # Skip common test/mock values or short tokens
            if any(ph in raw_val.lower() for ph in ("example", "test", "password", "1234", "admin", "secret")):
                continue
            entropy = shannon_entropy(raw_val)
            # High entropy (above 3.6 for alphanumeric random strings)
            if entropy >= 3.6 and len(raw_val) >= 16:
                dedup_key = (line_idx, "SEC-GENERIC-SECRET")
                if dedup_key not in seen_keys:
                    seen_keys.add(dedup_key)
                    counter += 1
                    masked = mask_secret(raw_val)
                    findings.append({
                        "id": f"SECRET-{counter:03d}",
                        "severity": "HIGH",
                        "line": line_idx,
                        "category": "Hard-coded Secret",
                        "rule_violated": "SEC-HIGH-ENTROPY-SECRET",
                        "variable": var_name,
                        "sink": "assignment",
                        "construction": "high_entropy_secret",
                        "description": f"High-entropy secret assignment detected for '{var_name}' (entropy: {entropy:.2f}). Value: {masked}",
                        "suggested_fix": "Store credentials in an environment variable or secure vault instead of committing them in source.",
                        "confidence": 0.88,
                        "evidence": line_clean[:120].replace(raw_val, masked),
                        "impact": "Exposes sensitive credentials or access tokens in revision control history.",
                        "language": "Config/Source",
                    })

    return findings
