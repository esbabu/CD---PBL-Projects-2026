"""
Broad Python Security Analyzer
------------------------------
A supplemental AST-based pass for the existing compiler/taint pipeline.

It intentionally does NOT replace the original SQL/ORM passes.  It adds
independent, source-level checks for common Python/Flask/Django security
weaknesses and uses lightweight taint propagation to reduce false positives.

The analyzer is conservative: it reports suspicious patterns with confidence
and evidence rather than claiming to prove every vulnerability.
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Set, Tuple

# CWE lookup table (100 entries)
try:
    from cwe_mapping import CWE_MAP
except ImportError:
    CWE_MAP = {}

# Maps each internal rule_violated code to its authoritative CWE ID
_RULE_TO_CWE: Dict[str, str] = {
    "SQL-TAINT-SINK":        "CWE-89",
    "CMD-TAINT-SINK":        "CWE-78",
    "CMD-SHELL-API":         "CWE-78",
    "CMD-SHELL-TRUE":        "CWE-78",
    "CODE-TAINT-EXEC":       "CWE-94",
    "DYNAMIC-EXEC":          "CWE-94",
    "UNSAFE-DESERIALIZATION":"CWE-502",
    "SSRF-TAINT-URL":        "CWE-918",
    "SSTI-TAINT":            "CWE-94",
    "XSS-TRUST-HTML":        "CWE-79",
    "REFLECTED-INPUT":       "CWE-79",
    "JWT-NO-SIGNATURE":      "CWE-347",
    "TLS-VERIFY-DISABLED":   "CWE-295",
    "WEAK-RANDOM":           "CWE-338",
    "INSECURE-TEMP":         "CWE-377",
    "PATH-TAINT-SINK":       "CWE-22",
    "ARCHIVE-TRAVERSAL":     "CWE-22",
    "DEBUG-ENABLED":         "CWE-215",
    "CORS-WILDCARD":         "CWE-942",
    "HARDCODED-SECRET":      "CWE-798",
    "RISKY-NETWORK-LIB":     "CWE-311",
    "XML-SECURITY":          "CWE-611",
    "WEAK-HASH":             "CWE-328",
    "ECB-MODE":              "CWE-327",
}


@dataclass
class SecurityFinding:
    id: str
    severity: str
    line: int
    variable: str
    sink: str
    rule_violated: str
    construction: str
    description: str
    suggested_fix: str
    confidence: float = 0.90
    category: str = "Security"
    evidence: str = ""
    impact: str = ""
    cwe_id: str = "CWE-0"
    cwe_description: str = "Unknown"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["cwe_id"] = self.cwe_id
        d["cwe_description"] = self.cwe_description
        return d


class BroadSecurityAnalyzer:
    """Supplementary broad security checks over Python's real AST."""

    SOURCE_CALLS = {
        "input", "getenv", "os.getenv", "os.environ.get",
        "parse_qs", "parse_qsl", "urlparse",
        "get_parameter", "getParameter",
    }
    REQUEST_ROOTS = {"request", "req"}
    REQUEST_ATTRS = {
        "args", "form", "values", "headers", "cookies", "json",
        "data", "files", "query_params", "GET", "POST", "FILES",
        "COOKIES", "META", "body",
    }
    SANITIZER_CALLS = {
        "escape", "html.escape", "markupsafe.escape", "Markup",
        "shlex.quote", "quote", "urlencode",
        "os.path.abspath", "os.path.realpath", "os.path.normpath", "os.path.basename",
        "secure_filename", "werkzeug.utils.secure_filename",
        "_safe_relative_name", "safe_join",
        "jsonify", "flask.jsonify", "json.dumps",
        "_validate_api_url", "_validate_local_url", "validate_url",
    }

    SQL_METHODS = {
        "execute", "executemany", "executescript", "raw",
        "execute_sql", "execute_query",
    }
    COMMAND_FUNCS = {
        "system", "popen", "run", "call", "check_call",
        "check_output", "Popen",
    }
    DESERIALIZERS = {
        "pickle.load", "pickle.loads", "dill.load", "dill.loads",
        "marshal.load", "marshal.loads", "shelve.open",
        "yaml.load", "yaml.unsafe_load", "yaml.full_load",
    }

    def __init__(self, source: str, filename: str = "<string>"):
        self.source = source
        self.filename = filename
        self.lines = source.splitlines()
        self.tree = ast.parse(source, filename=filename)
        self.findings: List[SecurityFinding] = []
        self._counter = 0
        self.tainted: Set[str] = set()
        self.sanitized: Set[str] = set()
        self.assignments: Dict[str, ast.AST] = {}
        self._walk_assignments()

    # ---------- public API ----------

    def analyze(self) -> List[dict]:
        self._infer_taint()
        self._scan()
        return [f.to_dict() for f in self._deduplicate()]

    # ---------- AST helpers ----------

    @staticmethod
    def _name(node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            base = BroadSecurityAnalyzer._name(node.value)
            return f"{base}.{node.attr}" if base else node.attr
        if isinstance(node, ast.Call):
            return BroadSecurityAnalyzer._name(node.func)
        return ""

    @staticmethod
    def _method(node: ast.Call) -> str:
        return BroadSecurityAnalyzer._name(node.func)

    def _source_text(self, node: ast.AST) -> str:
        try:
            return ast.get_source_segment(self.source, node) or ""
        except Exception:
            return ""

    def _line_text(self, line: int) -> str:
        return self.lines[line - 1].strip() if 1 <= line <= len(self.lines) else ""

    def _is_request_source(self, node: ast.AST) -> bool:
        if isinstance(node, ast.Subscript):
            root = node.value
            if isinstance(root, ast.Attribute):
                return (
                    isinstance(root.value, ast.Name)
                    and root.value.id in self.REQUEST_ROOTS
                    and root.attr in self.REQUEST_ATTRS
                )
        if isinstance(node, ast.Attribute):
            return (
                isinstance(node.value, ast.Name)
                and node.value.id in self.REQUEST_ROOTS
                and node.attr in self.REQUEST_ATTRS
            )
        if isinstance(node, ast.Call):
            name = self._method(node)
            if name in {"request.args.get", "request.form.get",
                        "request.values.get", "request.headers.get",
                        "request.cookies.get", "request.json.get",
                        "request.get_json", "request.get_data",
                        "request.form.getlist", "request.args.getlist"}:
                return True
        return False

    def _is_source(self, node: ast.AST) -> bool:
        if self._is_request_source(node):
            return True
        if isinstance(node, ast.Call):
            name = self._method(node)
            if name in self.SOURCE_CALLS:
                return True
            if name.endswith(".getenv") or name == "os.environ.get":
                return True
            if name.endswith("parse_args"):
                return True
        if isinstance(node, ast.Subscript):
            # Environment/argv/configuration-derived values.
            base = self._name(node.value)
            if base in {"os.environ", "sys.argv", "request.args",
                        "request.form", "request.values", "request.headers",
                        "request.cookies", "request.json", "request.data",
                        "request.GET", "request.POST", "request.COOKIES",
                        "request.META"}:
                return True
        return False

    def _is_sanitizer(self, node: ast.AST) -> bool:
        if isinstance(node, ast.Call):
            name = self._method(node)
            return name in self.SANITIZER_CALLS
        return False

    def _expr_tainted(self, node: ast.AST) -> bool:
        if node is None:
            return False
        if self._is_source(node):
            return True
        if isinstance(node, ast.Name):
            return node.id in self.tainted
        if isinstance(node, ast.JoinedStr):
            return any(self._expr_tainted(v.value) for v in node.values
                       if isinstance(v, ast.FormattedValue))
        if isinstance(node, ast.BinOp):
            return self._expr_tainted(node.left) or self._expr_tainted(node.right)
        if isinstance(node, ast.BoolOp):
            return any(self._expr_tainted(v) for v in node.values)
        if isinstance(node, ast.Compare):
            return self._expr_tainted(node.left) or any(self._expr_tainted(v) for v in node.comparators)
        if isinstance(node, ast.UnaryOp):
            return self._expr_tainted(node.operand)
        if isinstance(node, ast.IfExp):
            return self._expr_tainted(node.body) or self._expr_tainted(node.orelse)
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            return any(self._expr_tainted(v) for v in node.elts)
        if isinstance(node, ast.Dict):
            return any(self._expr_tainted(k) or self._expr_tainted(v)
                       for k, v in zip(node.keys, node.values) if k is not None)
        if isinstance(node, ast.Subscript):
            return self._is_source(node) or self._expr_tainted(node.value) or self._expr_tainted(node.slice)
        if isinstance(node, ast.Call):
            # Sanitizers deliberately break the simple taint flow.
            if self._is_sanitizer(node):
                return False
            return any(self._expr_tainted(a) for a in node.args) or any(
                self._expr_tainted(k.value) for k in node.keywords
            )
        if isinstance(node, ast.Attribute):
            return self._expr_tainted(node.value)
        return False

    def _walk_assignments(self):
        for n in ast.walk(self.tree):
            if isinstance(n, ast.Assign):
                for target in n.targets:
                    if isinstance(target, ast.Name):
                        self.assignments[target.id] = n.value
            elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
                self.assignments[n.target.id] = n.value

    def _infer_taint(self):
        # Treat externally supplied function parameters as tainted by default.
        # This is a common static-analysis assumption: callers may pass data
        # originating outside the current function/module.
        for node in ast.walk(self.tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for arg in list(node.args.args) + list(node.args.kwonlyargs):
                    self.tainted.add(arg.arg)
                if node.args.vararg:
                    self.tainted.add(node.args.vararg.arg)
                if node.args.kwarg:
                    self.tainted.add(node.args.kwarg.arg)

        # A small fixed-point pass catches chains such as:
        # x=request.args.get(...); y=x; z=f"{y}"; sink(z)
        for _ in range(max(2, len(self.assignments) + 1)):
            changed = False
            for name, expr in self.assignments.items():
                if self._is_sanitizer(expr):
                    if name in self.tainted:
                        self.tainted.remove(name)
                        changed = True
                    self.sanitized.add(name)
                    continue
                if self._expr_tainted(expr) and name not in self.tainted:
                    self.tainted.add(name)
                    changed = True
            if not changed:
                break

    # ---------- finding creation ----------

    DEFAULT_IMPACTS = {
        "SQL Injection": "Unauthorized database access, exfiltration of sensitive records, modification/deletion of data, and potential database server compromise.",
        "Command Injection": "Execution of arbitrary host operating system commands with application privileges, potential full server takeover.",
        "Code Injection": "Arbitrary Python code execution inside the process runtime, complete control over application memory, variables, and execution flow.",
        "Cross-Site Scripting": "Execution of malicious scripts in the victim's browser, session hijacking, cookie theft, and unauthorized user actions.",
        "Server-Side Template Injection": "Arbitrary code execution via server-side template engine evaluation, environment variable exposure, and server compromise.",
        "Path Traversal": "Unauthorized access to sensitive system files, source code disclosure, or arbitrary file overwrite.",
        "Hard-coded Secret": "Permanent credential exposure in source control, enabling unauthorized access to associated cloud APIs, databases, or third-party services.",
        "Unsafe Deserialization": "Arbitrary object instantiation and remote code execution during payload deserialization.",
        "SSRF": "Outbound network requests to internal services, cloud metadata services (e.g. AWS IMDS), port scanning, and perimeter firewall bypass.",
        "Authentication / JWT": "Authentication bypass, identity forgery, token manipulation, and unauthorized privilege escalation.",
        "Transport Security": "Machine-in-the-Middle (MitM) attacks, unencrypted traffic interception, and credential eavesdropping.",
        "Security Misconfiguration": "Exposure of detailed internal stack traces, debug interfaces, or overly permissive cross-origin access.",
        "Weak Randomness": "Predictable security tokens, session identifiers, or nonces, enabling brute-forcing and session hijacking.",
        "Insecure File Handling": "Race conditions in temporary file creation, symlink exploitation, or file collision vulnerabilities.",
    }

    def _add(self, severity: str, node: ast.AST, rule: str, category: str,
             sink: str, description: str, fix: str, variable: str = "",
             construction: str = "pattern", confidence: float = .90,
             impact: str = ""):
        self._counter += 1
        line = getattr(node, "lineno", 1)
        evidence = self._line_text(line)
        resolved_impact = impact or self.DEFAULT_IMPACTS.get(
            category, "Potential compromise of system confidentiality, integrity, or availability."
        )
        cwe_id = _RULE_TO_CWE.get(rule, "CWE-0")
        cwe_desc = CWE_MAP.get(cwe_id, "Unknown")
        self.findings.append(SecurityFinding(
            id=f"SEC-{self._counter:04d}",
            severity=severity,
            line=line,
            variable=variable or "unknown",
            sink=sink,
            rule_violated=rule,
            construction=construction,
            description=description,
            suggested_fix=fix,
            confidence=confidence,
            category=category,
            evidence=evidence[:500],
            impact=resolved_impact,
            cwe_id=cwe_id,
            cwe_description=cwe_desc,
        ))

    def _scan(self):
        for n in ast.walk(self.tree):
            if isinstance(n, ast.Call):
                self._scan_call(n)
            elif isinstance(n, ast.Assign):
                self._scan_assignment(n)
            elif isinstance(n, ast.FunctionDef):
                self._scan_function(n)
            elif isinstance(n, ast.AsyncFunctionDef):
                self._scan_function(n)
            elif isinstance(n, ast.Import):
                self._scan_import(n)
            elif isinstance(n, ast.ImportFrom):
                self._scan_import_from(n)

        self._scan_literals()

    # ---------- categories ----------

    def _scan_call(self, n: ast.Call):
        name = self._method(n)
        lname = name.lower()
        args_tainted = any(self._expr_tainted(a) for a in n.args)
        kw_tainted = any(self._expr_tainted(k.value) for k in n.keywords)

        # SQL beyond the legacy detector: direct tainted expressions and f-strings.
        if name.split(".")[-1] in self.SQL_METHODS and n.args:
            q = n.args[0]
            if self._expr_tainted(q) and not self._has_sql_parameters(n):
                self._add(
                    "HIGH", n, "SQL-TAINT-SINK", "SQL Injection", name,
                    "Tainted input reaches a SQL execution/raw-query sink without visible parameter binding.",
                    "Use parameterized queries/placeholders and pass values separately.",
                    variable=self._first_tainted_name(q), construction=self._construction(q),
                    confidence=.96)

        # Command injection.
        if name in {"os.system", "os.popen"}:
            if args_tainted:
                self._add("HIGH", n, "CMD-TAINT-SINK", "Command Injection", name,
                          "User-controlled data reaches a shell command API.",
                          "Avoid shell commands; use a fixed executable with an argument list. If a shell is unavoidable, strictly validate allowed values.",
                          variable=self._first_tainted_name_from_args(n), construction="shell_command", confidence=.97)
            else:
                self._add("MEDIUM", n, "CMD-SHELL-API", "Command Injection", name,
                          "A shell command API is used; shell parsing makes injection easier to introduce.",
                          "Prefer subprocess.run([...], shell=False) with a fixed executable.",
                          construction="shell_command", confidence=.82)

        if name in {"subprocess.run", "subprocess.call", "subprocess.check_call",
                    "subprocess.check_output", "subprocess.Popen"}:
            shell_true = any(k.arg == "shell" and isinstance(k.value, ast.Constant)
                             and k.value.value is True for k in n.keywords)
            if args_tainted or kw_tainted:
                self._add("HIGH" if shell_true else "MEDIUM", n,
                          "CMD-TAINT-SINK", "Command Injection", name,
                          "Potentially untrusted data reaches a process-launch API.",
                          "Pass a list of fixed arguments with shell=False and validate user-controlled arguments.",
                          variable=self._first_tainted_name_from_args(n),
                          construction="subprocess_shell" if shell_true else "subprocess_args",
                          confidence=.96 if shell_true else .86)
            elif shell_true:
                self._add("HIGH", n, "CMD-SHELL-TRUE", "Command Injection", name,
                          "shell=True enables shell metacharacter interpretation.",
                          "Use shell=False and an argument list where possible.",
                          construction="shell=True", confidence=.90)

        # Dynamic code execution.
        if name in {"eval", "exec", "compile"}:
            if args_tainted:
                self._add("CRITICAL" if name in {"eval","exec"} else "HIGH", n,
                          "CODE-TAINT-EXEC", "Code Injection", name,
                          "Potentially untrusted data reaches dynamic Python code execution.",
                          "Remove dynamic execution; use a constrained parser or explicit dispatch table.",
                          variable=self._first_tainted_name_from_args(n), construction="dynamic_execution", confidence=.98)
            else:
                self._add("HIGH", n, "DYNAMIC-EXEC", "Code Injection", name,
                          f"{name}() executes dynamically supplied Python code.",
                          "Avoid dynamic execution; replace it with explicit, non-code data structures.",
                          construction="dynamic_execution", confidence=.93)

        # Unsafe deserialization.
        if name in self.DESERIALIZERS:
            safe_yaml_loader = any(
                k.arg == "Loader" and isinstance(k.value, ast.Attribute) and k.value.attr in {"SafeLoader", "CSafeLoader"}
                for k in n.keywords
            )
            unsafe = (
                name.startswith(("pickle.", "dill.", "marshal.", "shelve."))
                or name in {"yaml.load", "yaml.unsafe_load"}
            )
            if name == "yaml.load" and safe_yaml_loader:
                unsafe = False
            if unsafe:
                self._add("HIGH", n, "UNSAFE-DESERIALIZATION", "Unsafe Deserialization", name,
                          "A deserialization API can instantiate or execute attacker-controlled object data.",
                          "Use a safe data-only format such as JSON, or use an explicitly safe YAML loader.",
                          construction="deserialization", confidence=.96)

        # requests/urllib URL built from tainted input -> SSRF.
        if (name in {"requests.get","requests.post","requests.put","requests.delete",
                     "requests.request","urllib.request.urlopen","httpx.get","httpx.post"}):
            if self._is_url_target_tainted(n):
                self._add("HIGH", n, "SSRF-TAINT-URL", "SSRF", name,
                          "Potentially untrusted data reaches an outbound HTTP request destination URL.",
                          "Allow-list destinations, parse and validate the hostname/IP, and block private/link-local address ranges.",
                          variable=self._first_tainted_name_from_args(n), construction="tainted_url", confidence=.91)

        # Template/XSS sinks.
        if name in {"flask.render_template_string", "jinja2.Template",
                    "jinja2.Environment.from_string"} and args_tainted:
            self._add("HIGH", n, "SSTI-TAINT", "Server-Side Template Injection", name,
                      "Untrusted input is used as a template string.",
                      "Keep templates static; pass untrusted values as template data instead of template source.",
                      variable=self._first_tainted_name_from_args(n), construction="template_string", confidence=.96)

        if name in {"markupsafe.Markup", "flask.Markup"} and args_tainted:
            self._add("HIGH", n, "XSS-TRUST-HTML", "Cross-Site Scripting", name,
                      "Untrusted data is explicitly marked as trusted HTML.",
                      "Escape untrusted output and avoid marking user input as safe HTML.",
                      variable=self._first_tainted_name_from_args(n), construction="trusted_html", confidence=.95)

        # JWT verification bypass.
        if name in {"jwt.decode", "jose.jwt.decode"}:
            for kw in n.keywords:
                if kw.arg == "options" and isinstance(kw.value, ast.Dict):
                    for k, v in zip(kw.value.keys, kw.value.values):
                        if isinstance(k, ast.Constant) and k.value == "verify_signature" and isinstance(v, ast.Constant) and v.value is False:
                            self._add("HIGH", n, "JWT-NO-SIGNATURE", "Authentication / JWT", name,
                                      "JWT signature verification is explicitly disabled.",
                                      "Require signature verification and restrict accepted algorithms.",
                                      construction="verify_signature=False", confidence=.99)

        # TLS certificate verification disabled.
        if any(k.arg == "verify" and isinstance(k.value, ast.Constant) and k.value.value is False for k in n.keywords):
            if name.startswith(("requests.", "httpx.", "urllib3.")):
                self._add("HIGH", n, "TLS-VERIFY-DISABLED", "Transport Security", name,
                          "TLS certificate verification is disabled for an outbound request.",
                          "Keep certificate verification enabled; configure a trusted CA bundle if necessary.",
                          construction="verify=False", confidence=.99)

        # Insecure randomness for security-sensitive-looking tokens.
        if name.startswith("random.") and any(tok in self._source_text(n).lower() for tok in
                                               ("token", "password", "secret", "session", "key", "otp")):
            self._add("MEDIUM", n, "WEAK-RANDOM", "Weak Randomness", name,
                      "The non-cryptographic random module is used in a security-sensitive context.",
                      "Use secrets.token_urlsafe(), secrets.token_hex(), or secrets.randbelow().",
                      construction="non_crypto_random", confidence=.86)

        # tempfile.mktemp is inherently unsafe.
        if name == "tempfile.mktemp":
            self._add("HIGH", n, "INSECURE-TEMP", "Insecure File Handling", name,
                      "mktemp() creates a race condition between choosing a path and opening the file.",
                      "Use tempfile.NamedTemporaryFile() or TemporaryDirectory().",
                      construction="tempfile_race", confidence=.99)

        # Path traversal / unsafe filesystem paths.
        if name == "open" and n.args and self._expr_tainted(n.args[0]):
            self._add("HIGH", n, "PATH-TAINT-SINK", "Path Traversal", name,
                      "Potentially untrusted input reaches a filesystem open path.",
                      "Resolve paths against a fixed base directory and enforce that the resolved path remains inside it; prefer allow-lists.",
                      variable=self._first_tainted_name(n.args[0]), construction="tainted_path", confidence=.90)
        if name in {"os.remove", "os.unlink", "os.rename", "shutil.copy", "shutil.move",
                    "pathlib.Path", "Path"} and any(self._expr_tainted(a) for a in n.args):
            self._add("HIGH", n, "PATH-TAINT-SINK", "Path Traversal", name,
                      "Potentially untrusted input reaches a filesystem path operation.",
                      "Validate path components, reject traversal sequences, and enforce a trusted base directory.",
                      variable=self._first_tainted_name_from_args(n), construction="tainted_path", confidence=.86)

        # Dangerous archive extraction.
        if name in {"zipfile.ZipFile.extractall", "tarfile.TarFile.extractall"}:
            self._add("HIGH", n, "ARCHIVE-TRAVERSAL", "Path Traversal", name,
                      "Archive extraction can write files outside the intended directory when archive member paths are not validated.",
                      "Validate each archive member path before extraction or use a safe extraction routine.",
                      construction="archive_extractall", confidence=.90)

        # Flask/Django insecure configuration.
        if name == "flask.Flask.run" or name.endswith(".run"):
            for k in n.keywords:
                if k.arg == "debug" and isinstance(k.value, ast.Constant) and k.value.value is True:
                    self._add("HIGH", n, "DEBUG-ENABLED", "Security Misconfiguration", name,
                              "The application is configured to run with debug mode enabled.",
                              "Disable debug mode in production and use a production WSGI server.",
                              construction="debug=True", confidence=.99)

        if name in {"flask_cors.CORS", "flask_cors.cross_origin", "CORS", "cross_origin"}:
            if any(isinstance(a, ast.Constant) and a.value == "*" for a in n.args) or any(
                k.arg in {"origins", "origin"} and isinstance(k.value, ast.Constant) and k.value.value == "*"
                for k in n.keywords
            ):
                self._add("MEDIUM", n, "CORS-WILDCARD", "Security Misconfiguration", name,
                          "CORS is configured with a wildcard origin.",
                          "Allow-list the specific trusted origins instead of '*'.",
                          construction="cors_wildcard", confidence=.91)

    def _scan_assignment(self, n: ast.Assign):
        # Hard-coded secrets in suspicious variable names.
        for target in n.targets:
            if isinstance(target, ast.Name):
                name = target.id.lower()
                if any(k in name for k in ("password", "passwd", "secret", "api_key",
                                           "apikey", "access_token", "auth_token", "private_key")):
                    if isinstance(n.value, ast.Constant) and isinstance(n.value.value, str):
                        value = n.value.value
                        if len(value) >= 8 and not self._looks_placeholder(value):
                            self._add("HIGH", n, "HARDCODED-SECRET", "Secrets",
                                      target.id,
                                      "A credential-like value is hard-coded in source code.",
                                      "Move secrets to environment variables or a secret manager and rotate exposed credentials.",
                                      variable=target.id, construction="hardcoded_secret", confidence=.94)

    def _is_json_response(self, node: ast.AST) -> bool:
        """Return True if node represents a structured JSON/dict/list response (not raw HTML)."""
        if node is None:
            return False
        if isinstance(node, ast.Call):
            m = self._method(node)
            if m in {"jsonify", "flask.jsonify", "json.dumps", "dumps"}:
                return True
            if m in {"Response", "flask.Response"}:
                for kw in node.keywords:
                    if kw.arg in {"mimetype", "content_type"} and isinstance(kw.value, ast.Constant):
                        if "json" in str(kw.value.value).lower():
                            return True
        if isinstance(node, (ast.Dict, ast.List, ast.Tuple)):
            return True
        return False

    def _is_url_target_tainted(self, node: ast.Call) -> bool:
        """Check if destination URL is tainted in an HTTP request call (SSRF check)."""
        url_expr = None
        for kw in node.keywords:
            if kw.arg == "url":
                url_expr = kw.value
                break
        if url_expr is None and node.args:
            url_expr = node.args[0]

        if url_expr is None:
            return False

        if isinstance(url_expr, ast.Call) and self._method(url_expr).endswith("Request"):
            if url_expr.args:
                return self._expr_tainted(url_expr.args[0])
            for kw in url_expr.keywords:
                if kw.arg == "url":
                    return self._expr_tainted(kw.value)
            return False

        if isinstance(url_expr, ast.Name) and url_expr.id in self.assignments:
            assigned = self.assignments[url_expr.id]
            if isinstance(assigned, ast.Call) and self._method(assigned).endswith("Request"):
                if assigned.args:
                    return self._expr_tainted(assigned.args[0])
                for kw in assigned.keywords:
                    if kw.arg == "url":
                        return self._expr_tainted(kw.value)
                return False

        return self._expr_tainted(url_expr)

    def _scan_function(self, n: ast.FunctionDef | ast.AsyncFunctionDef):
        # Flask route functions returning raw user input: likely reflected XSS.
        decorators = [self._name(d) if not isinstance(d, ast.Call) else self._name(d.func) for d in n.decorator_list]
        is_route = any(d in {"app.route", "route", "router.get", "router.post"} for d in decorators)
        if is_route:
            for node in ast.walk(n):
                if isinstance(node, ast.Return) and node.value is not None:
                    if self._is_json_response(node.value):
                        continue
                    if self._expr_tainted(node.value):
                        self._add("MEDIUM", node, "REFLECTED-INPUT", "Cross-Site Scripting",
                                  n.name,
                                  "A web route returns data that is derived from a request source without an obvious output-encoding step.",
                                  "Escape HTML output or return structured JSON; avoid reflecting untrusted HTML.",
                                  variable=self._first_tainted_name(node.value), construction="reflected_response",
                                  confidence=.78)

    def _scan_import(self, n: ast.Import):
        for alias in n.names:
            if alias.name in {"telnetlib", "ftplib"}:
                self._add("MEDIUM", n, "RISKY-NETWORK-LIB", "Network Security", alias.name,
                          "A legacy network protocol library is imported; verify that transport security and authentication are appropriate.",
                          "Prefer modern TLS-protected protocols and authenticated connections.",
                          construction="risky_import", confidence=.68)

    def _scan_import_from(self, n: ast.ImportFrom):
        if n.module == "xml.etree.ElementTree":
            for alias in n.names:
                if alias.name in {"parse", "fromstring", "XMLParser"}:
                    self._add("MEDIUM", n, "XML-SECURITY", "XML Security", n.module,
                              "XML parsing is used; untrusted XML should be parsed with defenses against entity expansion/XXE-style attacks.",
                              "Use a hardened XML parser such as defusedxml for untrusted XML.",
                              construction="xml_parser", confidence=.72)

    def _scan_literals(self):
        # Weak hashes and insecure crypto primitives, including hashlib.md5/sha1.
        for n in ast.walk(self.tree):
            if isinstance(n, ast.Call):
                name = self._method(n)
                if name in {"hashlib.md5", "hashlib.sha1", "md5", "sha1"}:
                    self._add("MEDIUM", n, "WEAK-HASH", "Weak Cryptography", name,
                              "MD5/SHA-1 is used; these are unsuitable for password hashing and collision-resistant security uses.",
                              "Use a password KDF such as Argon2/bcrypt/scrypt for passwords, or SHA-256+ for non-password integrity where appropriate.",
                              construction="weak_hash", confidence=.97)
                if name.endswith(".new") and n.args and isinstance(n.args[0], ast.Constant) and n.args[0].value in {"md5","sha1"}:
                    self._add("MEDIUM", n, "WEAK-HASH", "Weak Cryptography", name,
                              "A weak hash algorithm is selected dynamically.",
                              "Use a modern cryptographic hash/KDF appropriate to the purpose.",
                              construction="weak_hash", confidence=.94)
                if name in {"Crypto.Cipher.AES.new", "AES.new"}:
                    ecb = any(isinstance(a, ast.Attribute) and a.attr == "MODE_ECB" for a in n.args[1:])
                    ecb = ecb or any(
                        kw.arg == "mode" and isinstance(kw.value, ast.Attribute) and kw.value.attr == "MODE_ECB"
                        for kw in n.keywords
                    )
                    if ecb:
                        self._add("HIGH", n, "ECB-MODE", "Weak Cryptography", name,
                                  "AES-ECB reveals block patterns and is generally unsafe for structured data encryption.",
                                  "Use an authenticated encryption mode such as AES-GCM.",
                                  construction="ecb_mode", confidence=.96)

    # ---------- SQL helpers ----------

    def _has_sql_parameters(self, n: ast.Call) -> bool:
        # execute(query, params), execute(sql, params=...), SQLAlchemy bind params.
        return len(n.args) >= 2 or any(k.arg in {"params", "parameters", "bindings"}
                                      for k in n.keywords)

    def _construction(self, node: ast.AST) -> str:
        if isinstance(node, ast.JoinedStr):
            return "f_string"
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mod)):
            return "string_construction"
        if isinstance(node, ast.Call):
            return "function_result"
        return "tainted_expression"

    def _first_tainted_name(self, node: ast.AST) -> str:
        if isinstance(node, ast.Name) and node.id in self.tainted:
            return node.id
        if self._is_request_source(node):
            return self._source_text(node)[:80]
        for child in ast.iter_child_nodes(node):
            value = self._first_tainted_name(child)
            if value:
                return value
        return "unknown"

    def _first_tainted_name_from_args(self, n: ast.Call) -> str:
        for a in n.args:
            value = self._first_tainted_name(a)
            if value != "unknown":
                return value
        for k in n.keywords:
            value = self._first_tainted_name(k.value)
            if value != "unknown":
                return value
        return "unknown"

    def _looks_placeholder(self, value: str) -> bool:
        low = value.lower().strip()
        return low in {"password", "your_password", "changeme", "change_me",
                       "secret", "your_secret", "api_key", "your_api_key",
                       "example", "test", "dummy", "placeholder"} or "example.com" in low

    def _deduplicate(self) -> List[SecurityFinding]:
        # Same category/line/sink can be produced by overlapping AST patterns.
        seen = set()
        result = []
        for f in sorted(self.findings, key=lambda x: (x.line, x.id)):
            key = (f.category, f.line, f.sink, f.rule_violated)
            if key in seen:
                continue
            seen.add(key)
            result.append(f)
        return result


def analyze_source(source: str, filename: str = "<string>") -> List[dict]:
    return BroadSecurityAnalyzer(source, filename).analyze()


def analyze_file(filepath: str) -> List[dict]:
    safe_path = os.path.abspath(filepath)
    if not os.path.isfile(safe_path):
        raise FileNotFoundError(f"File not found: {filepath}")
    with open(safe_path, "r", encoding="utf-8") as f:
        return analyze_source(f.read(), safe_path)
