import io
import os
import sys
import unittest
import zipfile

# Ensure import paths work
sys.path.insert(0, os.path.dirname(__file__))
from app import app

class TestExplorerAPI(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()

    def test_inspect_zip_valid(self):
        # Create a mock zip with nested folders and ignored directory
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('myproject/src/main.py', 'print("hello world")\n')
            z.writestr('myproject/src/utils/helpers.py', 'def add(a, b):\n    return a + b\n')
            z.writestr('myproject/node_modules/bad.js', 'console.log("should be ignored");')
            z.writestr('myproject/.git/HEAD', 'ref: refs/heads/main')
        buf.seek(0)

        response = self.app.post('/inspect-zip', data={
            'project_zip': (buf, 'myproject.zip')
        }, content_type='multipart/form-data')

        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data.get('success'))
        paths = [f['path'] for f in data.get('files', [])]
        self.assertIn('myproject/src/main.py', paths)
        self.assertIn('myproject/src/utils/helpers.py', paths)
        # Ensure ignored dirs were filtered out
        self.assertNotIn('myproject/node_modules/bad.js', paths)
        self.assertNotIn('myproject/.git/HEAD', paths)
        # Check source contents
        sources = data.get('file_sources', {})
        self.assertIn('myproject/src/main.py', sources)
        self.assertEqual(sources['myproject/src/main.py'], 'print("hello world")\n')

    def test_inspect_zip_missing_file(self):
        response = self.app.post('/inspect-zip', data={}, content_type='multipart/form-data')
        self.assertEqual(response.status_code, 400)
        data = response.get_json()
        self.assertFalse(data.get('success'))

    def test_analyze_multi_files(self):
        # Test analyzing multiple selective files
        file1 = (io.BytesIO(b'import os\ncmd = input()\nos.system(cmd)\n'), 'app.py')
        file2 = (io.BytesIO(b'def add(a, b):\n    return a + b\n'), 'utils.py')
        response = self.app.post('/analyze', data={
            'files': [file1, file2]
        }, content_type='multipart/form-data')

        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data.get('success'))
        self.assertTrue(data.get('project'))
        self.assertIn('file_sources', data)
        self.assertIn('vulnerabilities', data)
        # Check that os.system vulnerability was found in app.py
        vulns = data.get('vulnerabilities', [])
        app_vulns = [v for v in vulns if v.get('file') == 'app.py']
        self.assertTrue(len(app_vulns) > 0)

if __name__ == '__main__':
    unittest.main()
