import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from ai_firewall import demo_cases, inspect_chat, inspect_source
from broad_security_analyzer import BroadSecurityAnalyzer

print("=" * 65)
print("1. RUNNING AI FIREWALL DETERMINISTIC ATTACK SUITE")
print("=" * 65)
results = demo_cases()
all_passed = True
for r in results:
    status = "PASSED" if r["passed"] else "FAILED"
    if not r["passed"]:
        all_passed = False
    print(f"[{status}] {r['name']:<30} Expected: {r['expected']:<6} Got: {r['actual']:<6}")

print("\n" + "=" * 65)
print("2. TESTING BOUNDARY LIMITS (DoS & OVERFLOW CHECKS)")
print("=" * 65)
# Check 8000+ char chat overflow
overflow_msg = "A" * 8005
chat_res = inspect_chat(overflow_msg)
print(f"Chat Message > 8000 chars blocked: {not chat_res['allowed']} ({chat_res['reason']})")

# Check 65KB+ source code overflow
overflow_code = "x = 1\n" * 20000 # > 100 KB
source_res = inspect_source(overflow_code)
print(f"Source Code > 65KB blocked:       {not source_res['allowed']} ({source_res['reason']})")

print("\n" + "=" * 65)
print("3. RUNNING SELF-SECURITY AUDIT ON PROJECT'S OWN BACKEND")
print("=" * 65)
py_files = [f for f in os.listdir(os.path.dirname(__file__)) if f.endswith(".py") and not f.startswith("test_")]
self_vulns = 0
for f in sorted(py_files):
    fpath = os.path.join(os.path.dirname(__file__), f)
    with open(fpath, "r", encoding="utf-8") as fp:
        findings = BroadSecurityAnalyzer(fp.read(), f).analyze()
        if findings:
            self_vulns += len(findings)
            print(f"[!] {f}: {len(findings)} issues found")
        else:
            print(f"[OK] {f:<30} 0 vulnerabilities")

print("-" * 65)
print(f"Self-Audit Complete: {self_vulns} vulnerabilities found in backend core.")
print("=" * 65)
