"""Multi-language static security analysis for JavaScript, Java, C and C++.

The analyzer keeps the project dependency-light but is more semantic than the
original regex-only checks.  It performs lightweight source/sink taint tracking,
assignment propagation, sanitizer awareness, language-specific sink checks and
then applies targeted lexical rules for issues that do not require taint flow.
It is intentionally a static analyzer, not a full compiler/parser.
"""
from __future__ import annotations
import os
import re
from dataclasses import dataclass, asdict
from typing import List, Dict, Set, Tuple

# CWE lookup table (100 entries)
try:
    from cwe_mapping import CWE_MAP
except ImportError:
    CWE_MAP = {}

# Maps each rule_violated / category code used in this analyzer to a CWE ID
_RULE_TO_CWE: Dict[str, str] = {
    "TAINTED-SQL-SINK":       "CWE-89",
    "SQL-INJECTION":          "CWE-89",
    "DYNAMIC-SQL":            "CWE-89",
    "TAINTED-COMMAND-SINK":   "CWE-78",
    "COMMAND-INJECTION":      "CWE-78",
    "TAINTED-HTML-SINK":      "CWE-79",
    "XSS":                    "CWE-79",
    "TAINTED-URL-SINK":       "CWE-918",
    "SSRF":                   "CWE-918",
    "TAINTED-FILE-SINK":      "CWE-22",
    "PATH-TRAVERSAL":         "CWE-22",
    "CODE-INJECTION":         "CWE-94",
    "UNSAFE-DESERIALIZATION": "CWE-502",
    "WEAK-CRYPTO":            "CWE-327",
    "WEAK-RANDOMNESS":        "CWE-338",
    "SECRET-EXPOSURE":        "CWE-798",
    "HARDCODED-CREDENTIAL":   "CWE-798",
    "TLS-BYPASS":             "CWE-295",
    "OPEN-REDIRECT":          "CWE-601",
    "PROTOTYPE-POLLUTION":    "CWE-915",
    "HARDCODED-SECRET":       "CWE-798",
    "DANGEROUS-API":          "CWE-676",
    "XXE-RISK":               "CWE-611",
    "MEMORY-SAFETY":          "CWE-120",
    "FORMAT-STRING":          "CWE-134",
    "FILE-PERMISSIONS":       "CWE-732",
    "MEMORY-MANAGEMENT":      "CWE-401",
    "DENIAL-OF-SERVICE":      "CWE-400",
}

LANG_EXT = {
    '.py': 'Python', '.pyw': 'Python',
    '.js': 'JavaScript', '.jsx': 'JavaScript', '.mjs': 'JavaScript', '.cjs': 'JavaScript',
    '.java': 'Java',
    '.c': 'C', '.h': 'C', '.cc': 'C++', '.cpp': 'C++', '.cxx': 'C++', '.hpp': 'C++', '.hh': 'C++',
}

@dataclass
class Finding:
    id: str
    severity: str
    line: int
    variable: str
    sink: str
    rule_violated: str
    construction: str
    description: str
    suggested_fix: str
    confidence: float
    category: str
    evidence: str
    language: str
    impact: str = ""
    cwe_id: str = "CWE-0"
    cwe_description: str = "Unknown"


def language_for(filename: str) -> str:
    return LANG_EXT.get(os.path.splitext(filename.lower())[1], 'Unknown')


def detect_language(source: str, filename: str = '') -> tuple[str, float, str]:
    """Detect language using extension first, then source syntax heuristics.

    The extension is treated as strong evidence; content detection is used for
    pasted/extensionless code and as a consistency check for known extensions.
    Returns (language, confidence, method).
    """
    ext_lang = language_for(filename)
    text = source or ''
    scores = {
        'Python': 0.0, 'JavaScript': 0.0, 'Java': 0.0, 'C': 0.0, 'C++': 0.0
    }
    # Strong filename evidence.
    if ext_lang in scores:
        scores[ext_lang] += 8.0

    patterns = {
        'Python': [
            (r'^\s*(?:from|import)\s+[A-Za-z_]', 2.5),
            (r'^\s*def\s+\w+\s*\(', 2.5),
            (r'^\s*class\s+\w+.*:', 1.5),
            (r'\b(?:elif|None|True|False|async|await)\b', 1.0),
            (r'\bprint\s*\(', 0.7),
        ],
        'JavaScript': [
            (r'\b(?:const|let|var)\s+[A-Za-z_$]', 2.0),
            (r'=>', 2.0),
            (r'\b(?:require|module\.exports|import)\s*', 1.5),
            (r'\bconsole\.(?:log|error|warn)\s*\(', 1.2),
            (r'\b(?:async|await)\b', 0.8),
        ],
        'Java': [
            (r'^\s*package\s+[A-Za-z_][\w.]*\s*;', 3.0),
            (r'^\s*import\s+[A-Za-z_][\w.]*\s*;', 2.0),
            (r'\bpublic\s+class\s+\w+', 3.0),
            (r'\bSystem\.out\.(?:println|print)\s*\(', 1.5),
            (r'\b(?:String|Integer|Boolean|ArrayList|HashMap)\s+[A-Za-z_]\w*', 0.8),
        ],
        'C++': [
            (r'#\s*include\s*<iostream>', 3.0),
            (r'\bstd::', 2.5),
            (r'\b(?:cout|cin)\s*(?:<<|>>)', 2.0),
            (r'\bnamespace\s+\w+', 1.5),
            (r'\b(?:vector|string|unordered_map)\s*<', 1.2),
        ],
        'C': [
            (r'#\s*include\s*<(?:stdio|stdlib|string|unistd)\.h>', 2.5),
            (r'\b(?:printf|scanf|malloc|free|memcpy|strcpy)\s*\(', 1.5),
            (r'\bint\s+main\s*\(', 1.8),
            (r'\b(?:char|size_t|FILE)\s*\*', 0.8),
        ],
    }
    for lang, pats in patterns.items():
        for pat, weight in pats:
            if re.search(pat, text, re.M):
                scores[lang] += weight

    # Resolve common C/C++ overlap explicitly.
    if scores['C++'] > 0 and re.search(r'#\s*include\s*<(?:iostream|vector|string|map|unordered_map)', text):
        scores['C++'] += 2.0
    if scores['C'] > 0 and re.search(r'#\s*include\s*<(?:stdio|stdlib|string|unistd)\.h>', text):
        scores['C'] += 1.0

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    best, best_score = ranked[0]
    second_score = ranked[1][1]
    if best_score <= 0:
        return (ext_lang if ext_lang != 'Unknown' else 'Unknown', 0.45 if ext_lang != 'Unknown' else 0.0,
                'file extension' if ext_lang != 'Unknown' else 'undetected')

    # Confidence combines evidence strength and margin over the runner-up.
    confidence = min(0.99, 0.55 + min(best_score, 10.0) / 20.0 + min(max(best_score-second_score, 0), 5.0) / 20.0)
    if ext_lang == best and ext_lang != 'Unknown':
        confidence = min(0.99, confidence + 0.10)
        method = 'file extension + source syntax'
    elif ext_lang == 'Unknown':
        method = 'source syntax'
    else:
        method = 'source syntax (extension inconsistent)'
    return best, round(confidence, 2), method


def _snippet(lines: list[str], line: int) -> str:
    return lines[line - 1].strip()[:240] if 0 < line <= len(lines) else ''


def _names(expr: str) -> Set[str]:
    return set(re.findall(r'\b[A-Za-z_$][A-Za-z0-9_$]*\b', expr))


def _strip_comments(lines: list[str], lang: str) -> list[str]:
    out = []
    in_block = False
    for line in lines:
        s = line
        if in_block:
            end = s.find('*/')
            if end < 0:
                out.append('')
                continue
            s = s[end + 2:]
            in_block = False
        while True:
            start = s.find('/*')
            if start < 0:
                break
            end = s.find('*/', start + 2)
            if end < 0:
                s = s[:start]
                in_block = True
                break
            s = s[:start] + s[end + 2:]
        # Keep strings intact; only remove obvious // comments after code.
        s = re.sub(r'(?<!:)//.*$', '', s)
        if lang in {'C', 'C++'}:
            s = re.sub(r'(?<!:)#\s*include.*$', lambda m: m.group(0), s)
        out.append(s)
    return out


def _assignment_targets(line: str, lang: str) -> list[str]:
    # Handles declarations and ordinary assignments. Avoid treating ==, <= etc. as assignments.
    targets = []
    if lang == 'JavaScript':
        pats = [r'\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=']
    elif lang == 'Java':
        pats = [r'\b(?:final\s+)?[A-Za-z_$][\w$<>?,.\[\]]*\s+([A-Za-z_$][\w$]*)\s*=']
    else:
        pats = [r'\b(?:const\s+)?[A-Za-z_$][\w:$<>*&\[\]]*\s+([A-Za-z_$][\w$]*)\s*=']
    pats.append(r'^\s*([A-Za-z_$][\w$]*)\s*=')
    for p in pats:
        for m in re.finditer(p, line):
            targets.append(m.group(1))
    return list(dict.fromkeys(targets))


def _rhs(line: str, target: str) -> str:
    m = re.search(r'\b' + re.escape(target) + r'\s*=\s*(.*)', line)
    return m.group(1) if m else ''


def _profiles(lang: str):
    """Language-specific source/sanitizer/sink vocabulary.

    These are intentionally framework-aware heuristics. They feed the common
    taint engine; they are not a replacement for a full parser/type system.
    """
    if lang == 'JavaScript':
        return {
            'sources': [
                r'\breq\.(?:query|body|params|headers|cookies|files)\b',
                r'\brequest\.(?:query|body|params|headers|cookies|files)\b',
                r'\bctx\.(?:request|query|params|headers|cookies)\b',
                r'\b(?:location\.(?:search|hash|href)|URLSearchParams\b)',
                r'\bprocess\.(?:argv|env)\b',
                r'\b(?:window\.|document\.)?(?:location|URLSearchParams)\b',
                r'\b(?:cookies|headers|query|params|body)\[[^\]]+\]',
            ],
            'sanitizers': [
                r'\b(?:validator\.|escapeHtml|sanitizeHtml|DOMPurify\.sanitize|encodeURIComponent|encodeURI)\s*\(',
                r'\b(?:parseInt|parseFloat|Number|Boolean)\s*\(',
            ],
            'sql_sinks': [
                r'\b(?:db|connection|conn|pool|client|sequelize|knex)\.(?:query|execute|run|raw)\s*\(',
                r'\b(?:mysql|mysql2|pg|sqlite3)\.(?:query|execute|run)\s*\(',
            ],
            'command_sinks': [
                r'\b(?:child_process\.)?(?:exec|execSync)\s*\(',
                r'\b(?:child_process\.)?(?:spawn|spawnSync|execFile|execFileSync)\s*\(',
            ],
            'xss_sinks': [
                r'\b(?:innerHTML|outerHTML|insertAdjacentHTML)\s*=',
                r'\bdocument\.write\s*\(',
                r'\b(?:setTimeout|setInterval)\s*\(\s*[^,]+(?:["\']|`)',
            ],
            'ssrf_sinks': [
                r'\b(?:fetch|axios\.(?:get|post|put|delete|request)|http\.(?:get|request)|https\.(?:get|request))\s*\(',
                r'\b(?:got|request|superagent)\.(?:get|post|put|delete|request)\s*\(',
            ],
            'file_sinks': [
                r'\bfs\.(?:readFile|readFileSync|writeFile|writeFileSync|appendFile|appendFileSync|open|openSync|unlink|unlinkSync)\s*\(',
            ],
            'deserialization_sinks': [
                r'\b(?:deserialize|unserialize|deserializeUser|load|parse)\s*\(',
            ],
        }
    if lang == 'Java':
        return {
            'sources': [
                r'\b(?:request|req|httpServletRequest)\.getParameter\s*\(',
                r'\b(?:request|req|httpServletRequest)\.getHeader\s*\(',
                r'\b(?:request|req|httpServletRequest)\.getCookies\s*\(',
                r'\bSystem\.getenv\s*\(',
                r'\bSystem\.getProperty\s*\(',
                r'\bScanner\s+\w+\s*=\s*new\s+Scanner\s*\(',
                r'\b[A-Za-z_$][\w$]*\.next(?:Line|Int|Long|Double|Float|Short|Byte|Boolean)\s*\(',
            ],
            'sanitizers': [
                r'\b(?:ESAPI\.|Encode\.|HtmlUtils\.|StringEscapeUtils\.)',
                r'\b(?:validate|sanitize|escape)[A-Za-z_$]*\s*\(',
            ],
            'sql_sinks': [
                r'\b(?:statement|stmt|st|entityManager|jdbcTemplate|template|query)\.(?:executeQuery|executeUpdate|execute|query|update)\s*\(',
                r'\b(?:createQuery|createNativeQuery)\s*\(',
            ],
            'command_sinks': [
                r'\bRuntime\.getRuntime\(\)\.exec\s*\(',
                r'\bnew\s+ProcessBuilder\s*\(',
            ],
            'ssrf_sinks': [
                r'\bnew\s+URL\s*\(',
                r'\b(?:HttpClient|HttpURLConnection|RestTemplate|WebClient)\b[^;]*(?:execute|send|exchange|retrieve)\s*\(',
            ],
            'file_sinks': [
                r'\bnew\s+(?:File|FileInputStream|FileOutputStream|FileReader|FileWriter)\s*\(',
                r'\bFiles\.(?:read|write|newInputStream|newOutputStream|delete)\s*\(',
            ],
        }
    return {
        'sources': [
            r'\b(?:argv|argc)\b',
            r'\b(?:getenv|gets|fgets|scanf|sscanf|recv|read|cin)\s*\(',
            r'\bstd::cin\b',
        ],
        'sanitizers': [r'\b(?:validate|sanitize|escape|checked|bounded)[A-Za-z_$]*\s*\('],
        'sql_sinks': [r'\b(?:sqlite3_exec|mysql_query|PQexec|SQLExecDirect)\s*\('],
        'command_sinks': [
            r'\b(?:system|popen|_popen)\s*\(',
            r'\b(?:execlp|execvp|execl|execv|CreateProcessA|CreateProcessW)\s*\(',
        ],
        'file_sinks': [r'\b(?:fopen|open|ifstream|ofstream)\s*\('],
    }


def _taint_analysis(source: str, lang: str) -> tuple[Dict[str, Set[int]], Set[Tuple[int, str]]]:
    lines = _strip_comments(source.splitlines(), lang)
    profile = _profiles(lang)
    taint: Dict[str, Set[int]] = {}
    sanitized: Set[str] = set()

    # Explicit input statements and common function parameters are also treated
    # as taint entry points. This is especially useful for C/C++ where input often
    # arrives through argv/cin/scanf/fgets rather than a request object.
    for i, line in enumerate(lines, 1):
        if lang in {'C', 'C++'}:
            for m in re.finditer(r'\bcin\s*>>\s*([A-Za-z_$][\w$]*)', line):
                taint.setdefault(m.group(1), set()).add(i)
            for m in re.finditer(r'\b(?:scanf|sscanf|fgets|recv|read)\s*\([^,]+,\s*(?:&)?([A-Za-z_$][\w$]*)', line):
                taint.setdefault(m.group(1), set()).add(i)
        if lang == 'Java':
            for m in re.finditer(r'\b(?:public|private|protected)?\s*(?:static\s+)?[A-Za-z_$][\w$<>?,.\[\]]*\s+\w+\s*\(([^)]*)\)', line):
                for param in m.group(1).split(','):
                    pm = re.search(r'([A-Za-z_$][\w$]*)\s*$', param.strip())
                    if pm:
                        taint.setdefault(pm.group(1), set()).add(i)
        if lang == 'Java':
            # Scanner-backed console input is untrusted for security analysis.
            m = re.search(r'\bScanner\s+([A-Za-z_$][\w$]*)\s*=\s*new\s+Scanner\s*\(', line)
            if m:
                # Record the scanner object; its next* calls are handled below.
                taint.setdefault(m.group(1), set()).add(i)
            m = re.search(r'\b([A-Za-z_$][\w$]*)\.next(?:Line|Int|Long|Double|Float|Short|Byte|Boolean)\s*\(\)', line)
            if m:
                # If the receiver is a known Scanner object, taint the assignment target later.
                taint.setdefault('__scanner__' + m.group(1), set()).add(i)
        if lang in {'C', 'C++'}:
            for m in re.finditer(r'\b[A-Za-z_$][\w:$<>*&\[\]]*\s+[A-Za-z_$][\w$]*\s*\(([^)]*)\)', line):
                for param in m.group(1).split(','):
                    pm = re.search(r'([A-Za-z_$][\w$]*)\s*$', param.strip())
                    if pm and pm.group(1) not in {'void'}:
                        taint.setdefault(pm.group(1), set()).add(i)

    # Fixed-point propagation across assignments. This handles common multi-line
    # source -> variable -> variable -> sink flows without requiring a full parser.
    for _ in range(max(4, min(12, len(lines) + 1))):
        changed = False
        for i, line in enumerate(lines, 1):
            is_source = any(re.search(p, line, re.I) for p in profile['sources'])
            is_sanitized = any(re.search(p, line, re.I) for p in profile['sanitizers'])
            for target in _assignment_targets(line, lang):
                rhs = _rhs(line, target)
                names = _names(rhs)
                new_taint = set()
                if is_source:
                    new_taint.add(i)
                # Scanner.next*() is a source when the receiver was created as a Scanner.
                if lang == 'Java':
                    for scanner_name in re.findall(r'\b([A-Za-z_$][\w$]*)\.next(?:Line|Int|Long|Double|Float|Short|Byte|Boolean)\s*\(\)', line):
                        if '__scanner__' + scanner_name in taint:
                            new_taint.add(i)
                for name in names:
                    if name in taint and name not in sanitized:
                        new_taint |= taint[name]
                if is_sanitized:
                    sanitized.add(target)
                    new_taint.clear()
                if new_taint - taint.get(target, set()):
                    taint.setdefault(target, set()).update(new_taint)
                    changed = True
        if not changed:
            break

    flows: Set[Tuple[int, str]] = set()
    for i, line in enumerate(lines, 1):
        for sink_kind, pats in profile.items():
            if not sink_kind.endswith('_sinks'):
                continue
            for p in pats:
                m = re.search(p, line, re.I)
                if not m:
                    continue
                call = line[m.start():]
                names = _names(call)
                tainted_names = [n for n in names if n in taint and n not in sanitized]
                if tainted_names:
                    for n in tainted_names:
                        for src_line in sorted(taint[n]):
                            flows.add((i, f'{n}:{src_line}:{sink_kind}'))
                # Direct source-to-sink on the same line.
                if any(re.search(sp, line, re.I) for sp in profile['sources']):
                    flows.add((i, f'direct-source:{sink_kind}'))
    return taint, flows


def analyze_source(source: str, filename: str, language: str | None = None) -> List[dict]:
    # The web UI may provide pasted/extensionless source. In that case use the
    # same syntax detector as the API instead of silently returning no findings.
    lang = language or language_for(filename)
    if lang == 'Unknown':
        lang, _, _ = detect_language(source, filename)
    if lang == 'Unknown':
        return []
    lines = source.splitlines()
    findings: list[Finding] = []
    counter = 0
    seen = set()

    DEFAULT_IMPACTS = {
        'SQL Injection': 'Unauthorized database access, exfiltration of sensitive records, data tampering, and potential database takeover.',
        'Command Injection': 'Arbitrary system command execution under application privileges, potential full host compromise.',
        'Cross-Site Scripting': 'Malicious script execution in victim browsers, session hijacking, credential theft, and unauthorized user actions.',
        'Path Traversal': 'Unauthorized reading of server files, configuration disclosure, or arbitrary file overwrite.',
        'Hard-coded Secret': 'Leak of credentials and keys in source control, allowing unauthorized API and cloud resource access.',
        'Weak Randomness': 'Predictable tokens or identifiers enabling authentication bypass and session hijacking.',
        'Memory Safety': 'Buffer overflow, memory corruption, crash or arbitrary code execution in native binaries.',
        'Insecure Configuration': 'Unintended feature exposure or weak security controls leading to unauthorized access.',
    }

    def add(sev, rule, category, sink, desc, fix, line, confidence=.86, variable='untrusted_input', construction='pattern', impact=''):
        nonlocal counter
        key = (line, category, rule, sink)
        if key in seen:
            return
        seen.add(key)
        counter += 1
        resolved_impact = impact or DEFAULT_IMPACTS.get(category, 'Potential compromise of system confidentiality, integrity, or availability.')
        cwe_id = _RULE_TO_CWE.get(rule, _RULE_TO_CWE.get(category, "CWE-0"))
        cwe_desc = CWE_MAP.get(cwe_id, "Unknown")
        findings.append(Finding(
            id=f'{lang[:2].upper()}-{counter:03d}', severity=sev, line=line,
            variable=variable, sink=sink, rule_violated=rule, construction=construction,
            description=desc, suggested_fix=fix, confidence=confidence, category=category,
            evidence=_snippet(lines, line), language=lang, impact=resolved_impact,
            cwe_id=cwe_id, cwe_description=cwe_desc))

    profile = _profiles(lang)
    taint, flows = _taint_analysis(source, lang)

    # High-confidence source-to-sink findings.
    for sink_line, flow in sorted(flows):
        if 'sql_sinks' in flow:
            add('HIGH', 'TAINTED-SQL-SINK', 'SQL-INJECTION', 'SQL Injection',
                'Untrusted data is propagated into a database execution API.',
                'Use parameterized queries / prepared statements and bind values separately.',
                sink_line, .98, flow.split(':')[0], 'source → assignment → SQL sink')
        elif 'command_sinks' in flow:
            add('CRITICAL', 'TAINTED-COMMAND-SINK', 'COMMAND-INJECTION', 'Command Injection',
                'Untrusted data reaches a process or shell execution API.',
                'Avoid shell interpretation; use fixed executables and validated argument arrays.',
                sink_line, .98, flow.split(':')[0], 'source → assignment → command sink')
        elif 'xss_sinks' in flow:
            add('HIGH', 'TAINTED-HTML-SINK', 'XSS', 'Cross-Site Scripting',
                'Untrusted data reaches an HTML-writing sink.',
                'Prefer text/content APIs or a trusted HTML sanitizer with contextual encoding.',
                sink_line, .96, flow.split(':')[0], 'source → assignment → HTML sink')
        elif 'ssrf_sinks' in flow:
            add('HIGH', 'TAINTED-URL-SINK', 'SSRF', 'SSRF',
                'Untrusted data reaches a server-side HTTP/URL request sink.',
                'Allow-list schemes/hosts and block private, loopback and link-local destinations.',
                sink_line, .95, flow.split(':')[0], 'source → assignment → HTTP sink')
        elif 'file_sinks' in flow:
            add('HIGH', 'TAINTED-FILE-SINK', 'PATH-TRAVERSAL', 'File Operation',
                'Untrusted data reaches a file/path operation.',
                'Canonicalize paths, constrain them to an allowed directory and reject traversal segments.',
                sink_line, .94, flow.split(':')[0], 'source → assignment → file sink')

    # Language-specific structural / API rules that do not require taint.
    if lang == 'JavaScript':
        rules = [
            (r'\beval\s*\(', 'CRITICAL','CODE-INJECTION','eval()', 'Dynamic code execution can execute attacker-controlled JavaScript.','Avoid eval; use explicit parsing or dispatch.',.99),
            (r'\bnew\s+Function\s*\(', 'CRITICAL','CODE-INJECTION','new Function()', 'Dynamic function construction can execute attacker-controlled code.','Avoid dynamic function construction.',.98),
            (r'\bchild_process\.(?:exec|execSync)\s*\(', 'CRITICAL','COMMAND-INJECTION','child_process.exec', 'Shell execution is dangerous when command text is dynamic.','Prefer execFile/spawn with fixed arguments and validate inputs.',.93),
            (r'\b(?:innerHTML|outerHTML)\s*=', 'HIGH','XSS','HTML sink', 'Assigning untrusted HTML can enable XSS.','Use textContent or a trusted sanitizer.',.82),
            (r'\bdocument\.write\s*\(', 'HIGH','XSS','document.write', 'Writing dynamic HTML into the document can enable XSS.','Avoid document.write and use safe DOM APIs.',.90),
            (r'\b(?:deserialize|unserialize)\s*\(', 'HIGH','UNSAFE-DESERIALIZATION','deserialization', 'Unsafe deserialization can create unexpected objects or code paths.','Use safe data formats and strict schemas.',.84),
            (r'\b(?:md5|sha1)\s*\(', 'MEDIUM','WEAK-CRYPTO','weak hash', 'Legacy hashes are unsuitable for many security uses.','Use a modern hash/KDF appropriate to the purpose.',.94),
            (r'console\.(?:log|debug|info|warn|error)\s*\([^\n]*(?:password|passwd|secret|token|api[_-]?key)', 'MEDIUM','SECRET-EXPOSURE','logging', 'Sensitive authentication material appears in logs.','Redact credentials and sensitive authentication material.',.93),
            (r'\b(?:http|https)\.request\s*\([^\n]*(?:rejectUnauthorized\s*:\s*false)', 'HIGH','TLS-BYPASS','TLS verification', 'TLS certificate verification is disabled.','Use normal certificate and hostname verification.',.99),
        ]
    elif lang == 'Java':
        rules = [
            (r'\bnew\s+(?:ObjectInputStream|XMLDecoder)\s*\(', 'HIGH','UNSAFE-DESERIALIZATION','deserialization', 'Native Java/XML deserialization can expose dangerous object construction paths.','Use safe formats and strict schemas.',.95),
            (r'MessageDigest\.getInstance\s*\(\s*"(?:MD5|SHA-1)"', 'MEDIUM','WEAK-CRYPTO','weak hash', 'MD5/SHA-1 are unsuitable for many security uses.','Use SHA-256+ or a password KDF where appropriate.',.97),
            (r'Cipher\.getInstance\s*\(\s*"AES/ECB', 'MEDIUM','WEAK-CRYPTO','AES/ECB', 'ECB mode leaks patterns and is generally inappropriate for secure encryption.','Use an authenticated mode such as AES-GCM.',.97),
            (r'logger?\.(?:debug|info|warn|error)\s*\([^\n]*(?:password|passwd|secret|token|api[_-]?key)', 'MEDIUM','SECRET-EXPOSURE','logging', 'Sensitive authentication material appears in logs.','Redact credentials before logging.',.94),
            (r'checkServerTrusted\s*\([^\{]*\{\s*\}', 'HIGH','TLS-BYPASS','TrustManager', 'An empty certificate-trust callback can disable TLS verification.','Use the platform trust store and normal certificate validation.',.99),
            (r'HostnameVerifier\s*[^=]*=\s*\([^)]*\)\s*->\s*true', 'HIGH','TLS-BYPASS','HostnameVerifier', 'Always-true hostname verification disables a core TLS check.','Use the default hostname verifier.',.99),
        ]
    else:
        rules = [
            (r'\b(?:sprintf|vsprintf|strcpy|strcat|gets)\s*\(', 'HIGH','MEMORY-SAFETY','unsafe C API', 'Legacy C string APIs can cause buffer overflow or memory corruption.','Use bounded APIs and explicit length checks; prefer safer C++ abstractions.',.97),
            (r'\bscanf\s*\([^\n]*%s', 'HIGH','MEMORY-SAFETY','scanf %s', 'Unbounded %s input can overflow the destination buffer.','Use a field width and validate the destination size.',.98),
            (r'\b(?:printf|fprintf|syslog)\s*\(\s*[A-Za-z_$][\w$]*\s*[,)]', 'HIGH','FORMAT-STRING','format string', 'A variable is used as a printf-style format string.','Keep format strings constant and pass data as arguments.',.95),
            (r'\b(?:rand|srand)\s*\(', 'LOW','WEAK-RANDOMNESS','rand()', 'The standard PRNG is not suitable for security tokens.','Use an operating-system cryptographic random source.',.95),
            (r'\b(?:MD5|SHA1|EVP_md5|EVP_sha1)\s*\(', 'MEDIUM','WEAK-CRYPTO','weak hash', 'MD5/SHA-1 are unsuitable for many security uses.','Use a modern cryptographic hash/KDF appropriate to the task.',.94),
            (r'\b(?:chmod|fchmod)\s*\([^\n]*0?777\b', 'HIGH','FILE-PERMISSIONS','world-writable permissions', 'World-writable file permissions can permit unauthorized modification.','Use least-privilege permissions.',.97),
        ]

    # Additional broad security rules. These are intentionally separate from
    # taint findings so the analyzer can still flag dangerous APIs when source
    # provenance is unavailable.
    if lang == 'JavaScript':
        rules += [
            (r'\b(?:Math\.random)\s*\(', 'MEDIUM','WEAK-RANDOMNESS','Math.random()', 'Math.random() is not appropriate for security-sensitive tokens or secrets.','Use crypto.randomBytes/crypto.randomUUID or Web Crypto randomness.',.97),
            (r'\b(?:res|response)\.redirect\s*\([^\n]*(?:req\.|request\.|query|params|body)', 'HIGH','OPEN-REDIRECT','redirect', 'A redirect destination appears to depend on request data.','Allow-list destinations and reject arbitrary external URLs.',.90),
            (r'\b(?:Object\.assign|Object\.merge|merge)\s*\([^\n]*\b(?:req|request|body|query|params)\b', 'HIGH','PROTOTYPE-POLLUTION','object merge', 'Request-controlled objects are merged into another object; prototype-pollution risk depends on the merge implementation.','Use a safe merge implementation and reject __proto__/constructor/prototype keys.',.84),
            (r'\b(?:jwt\.sign|jsonwebtoken\.sign)\s*\([^\n]*["\'][^"\']{3,}["\']', 'MEDIUM','HARDCODED-SECRET','JWT signing', 'A literal value appears to be used as a JWT signing secret.','Load signing keys from protected secret configuration.',.88),
            (r'\b(?:require\(["\'](?:child_process|vm)["\']\))', 'MEDIUM','DANGEROUS-API','dangerous module', 'A module exposing process or dynamic-code execution capabilities is imported.','Use only the minimum required capability and validate all external input.',.78),
        ]
    elif lang == 'Java':
        rules += [
            (r'\bnew\s+(?:Random|java\.util\.Random)\s*\(', 'MEDIUM','WEAK-RANDOMNESS','java.util.Random', 'java.util.Random is not a cryptographic random source.','Use SecureRandom for security-sensitive values.',.97),
            (r'\b(?:DocumentBuilderFactory|SAXParserFactory)\s*\.newInstance\s*\(\)', 'MEDIUM','XXE-RISK','XML parser', 'XML parser configuration is security-sensitive and may permit external entity processing if not hardened.','Disable external entities/DTDs and enable secure XML processing features.',.84),
            (r'\b(?:sendRedirect|setHeader)\s*\([^\n]*(?:request|getParameter|getHeader)', 'HIGH','OPEN-REDIRECT','redirect', 'A response redirect/header appears to depend on request data.','Allow-list destinations and reject arbitrary external URLs.',.90),
            (r'\b(?:logger|log|System\.out)\.(?:debug|info|warn|error|println)\s*\([^\n]*(?:password|passwd|secret|token|api[_-]?key)', 'MEDIUM','SECRET-EXPOSURE','logging', 'Sensitive authentication material appears in output/logging.', 'Redact secrets before logging.',.94),
            (r'\b(?:Cipher\.getInstance)\s*\(\s*"(?:DES|3DES|DESede)', 'HIGH','WEAK-CRYPTO','weak cipher', 'Legacy DES-family encryption is unsuitable for modern secure encryption.', 'Use an authenticated modern cipher such as AES-GCM.',.98),
        ]
    else:
        rules += [
            (r'\b(?:memcpy|memmove|strncpy|strncat)\s*\([^\n]*\b(?:sizeof\s*\([^)]*\)|[A-Za-z_$][\w$]*)', 'MEDIUM','MEMORY-SAFETY','memory copy', 'Memory-copy operations require correct destination sizing and bounds checks.', 'Validate lengths before copying and prefer safer abstractions.',.72),
            (r'\b(?:free|delete|delete\[\])\s*\([^\n]*\b([A-Za-z_$][\w$]*)\b', 'LOW','MEMORY-MANAGEMENT','deallocation', 'Manual memory management requires correct ownership and lifetime handling.', 'Review ownership, lifetime and repeated deallocation paths.',.70),
            (r'\b(?:assert|abort)\s*\([^\n]*\b(?:input|user|request|argv)\b', 'MEDIUM','DENIAL-OF-SERVICE','assert/abort', 'Externally influenced assertions can terminate a process unexpectedly.', 'Handle invalid input with normal validation/error paths.',.82),
            (r'\b(?:umask|chmod|fchmod)\s*\([^\n]*(?:0?777|0?666)\b', 'HIGH','FILE-PERMISSIONS','permissive permissions', 'Overly permissive filesystem permissions can expose or modify sensitive files.', 'Apply least-privilege permissions.',.96),
        ]

    for pat, sev, cat, sink, desc, fix, conf in rules:
        for i, line in enumerate(_strip_comments(lines, lang), 1):
            if re.search(pat, line, re.I):
                add(sev, cat, cat, sink, desc, fix, i, conf, '—', 'API / structural rule')

    # Stronger SQL construction checks: only flag dynamic SQL, not every execute call.
    sql_words = r'(?:SELECT|INSERT|UPDATE|DELETE|MERGE|DROP|ALTER)'
    for i, line in enumerate(lines, 1):
        if re.search(sql_words, line, re.I) and re.search(r'(?:\+|\$\{|String\.format|sprintf|std::format|format\s*\()', line):
            # If the same line is a parameterized query with placeholders, do not flag it.
            if re.search(r'\?|\$\d+|:\w+', line) and not re.search(r'(?:\+|\$\{|String\.format)', line):
                continue
            add('HIGH', 'DYNAMIC-SQL', 'SQL-INJECTION', 'Dynamic SQL',
                'SQL text is assembled dynamically; this becomes dangerous when values originate from untrusted input.',
                'Use prepared statements / bound parameters instead of string-built SQL.', i, .91, 'dynamic SQL', 'string concatenation / interpolation')

    # Extended credential detection: typed declarations, config properties,
    # constructor/method arguments, and multiline Java JDBC connection calls.
    cred_pat = re.compile(r'\b(?:password|passwd|secret|api[_-]?key|auth[_-]?token|access[_-]?token|private[_-]?key|client[_-]?secret)\b\s*(?:=|:)\s*["\'][^"\'\n]{4,}["\']', re.I)
    typed_cred_pat = re.compile(r'\b(?:String|CharSequence|char\s*\[\])\s+(?:password|passwd|secret|api[_-]?key|auth[_-]?token|access[_-]?token|private[_-]?key|client[_-]?secret)\s*=\s*["\'][^"\'\n]{4,}["\']', re.I)
    seen_cred = set()
    for i, line in enumerate(lines, 1):
        if cred_pat.search(line) or typed_cred_pat.search(line):
            seen_cred.add(i)
            add('HIGH', 'HARDCODED-CREDENTIAL', 'SECRET-EXPOSURE', 'Credential Literal',
                'A credential-like value is hard-coded in source.',
                'Move secrets to a protected secret store or environment configuration.', i, .96, 'credential', 'literal assignment')

    # Java JDBC commonly supplies credentials as positional literals rather than
    # password = "...". Inspect a bounded DriverManager.getConnection call.
    if lang == 'Java':
        for m in re.finditer(r'DriverManager\.getConnection\s*\((.{0,500})\)', source, re.I | re.S):
            block = m.group(1)
            if re.search(r'"(?:root|admin|sa|user)"\s*,\s*"[^"\n]{4,}"', block, re.I):
                line_no = source[:m.start()].count('\n') + 1
                if line_no not in seen_cred:
                    add('HIGH', 'HARDCODED-CREDENTIAL', 'SECRET-EXPOSURE', 'JDBC Credential',
                        'A database connection contains hard-coded credential material.',
                        'Load database credentials from protected environment/secret configuration.', line_no, .94, 'credential', 'DriverManager.getConnection literal credentials')

    # Hard-coded credential literals. Avoid flagging variable names alone.
    for i, line in enumerate(lines, 1):
        if re.search(r'\b(?:password|passwd|secret|api[_-]?key|auth[_-]?token|private[_-]?key)\b\s*[:=]\s*["\'][^"\']{4,}["\']', line, re.I):
            add('HIGH', 'HARDCODED-CREDENTIAL', 'SECRET-EXPOSURE', 'Credential Literal',
                'A credential-like value is hard-coded in source.',
                'Move secrets to a protected secret store or environment configuration.', i, .96, 'credential', 'literal assignment')

    # Prefer the semantic source-to-sink finding when a lexical rule would
    # otherwise report the same underlying issue twice. Keep lexical findings
    # when there is no proven taint path.
    semantic = {(f.category, f.line) for f in findings if f.construction == 'source → assignment → SQL sink' or f.construction == 'source → assignment → command sink' or f.construction == 'source → assignment → HTML sink' or f.construction == 'source → assignment → HTTP sink' or f.construction == 'source → assignment → file sink'}
    filtered = []
    for f in findings:
        if f.category == 'SQL-INJECTION' and f.construction == 'string concatenation / interpolation' and any(cat == 'SQL-INJECTION' for cat, _ in semantic):
            continue
        if f.category == 'COMMAND-INJECTION' and f.construction == 'API / structural rule' and ('COMMAND-INJECTION', f.line) in semantic:
            continue
        if f.category == 'XSS' and f.construction == 'API / structural rule' and ('XSS', f.line) in semantic:
            continue
        filtered.append(f)
    return [asdict(f) for f in filtered]