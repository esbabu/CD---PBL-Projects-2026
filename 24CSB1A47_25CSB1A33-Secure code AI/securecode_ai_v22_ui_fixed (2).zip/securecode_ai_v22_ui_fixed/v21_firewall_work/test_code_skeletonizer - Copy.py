import unittest
from code_skeletonizer import skeletonize_code

class TestCodeSkeletonizer(unittest.TestCase):
    def test_python_ast_skeleton(self):
        code = '''"""Module docstring that is secret"""
AWS_KEY = "AKIA1234567890ABCDEF"
PORT = 8080

def authenticate(user_token):
    # Verify token
    if user_token == "super_secret_token_123":
        return True
    return False
'''
        skeleton = skeletonize_code(code, "auth.py")
        self.assertNotIn("Module docstring", skeleton)
        self.assertNotIn("AKIA1234567890ABCDEF", skeleton)
        self.assertNotIn("super_secret_token_123", skeleton)
        self.assertNotIn("Verify token", skeleton)
        self.assertNotIn("8080", skeleton)
        # Control structure and signatures are preserved
        self.assertIn("def authenticate(user_token):", skeleton)
        self.assertIn("if user_token ==", skeleton)
        self.assertIn("<STRING>", skeleton)

    def test_javascript_skeleton(self):
        code = '''// Auth handler
const stripeKey = "sk_live_1234567890abcdef12345678";
function query(req, res) {
    /* Multi line comment */
    const sql = "SELECT * FROM users WHERE id = " + req.id;
    db.run(sql);
}
'''
        skeleton = skeletonize_code(code, "handler.js")
        self.assertNotIn("sk_live_", skeleton)
        self.assertNotIn("Multi line comment", skeleton)
        self.assertNotIn("Auth handler", skeleton)
        self.assertNotIn("SELECT * FROM users", skeleton)
        self.assertIn("function query(req, res)", skeleton)
        self.assertIn("<STRING>", skeleton)
        self.assertIn("db.run(sql)", skeleton)

    def test_empty_and_none(self):
        self.assertEqual(skeletonize_code(""), "")
        self.assertEqual(skeletonize_code(None), "")
        self.assertEqual(skeletonize_code("   "), "")

if __name__ == "__main__":
    unittest.main()
