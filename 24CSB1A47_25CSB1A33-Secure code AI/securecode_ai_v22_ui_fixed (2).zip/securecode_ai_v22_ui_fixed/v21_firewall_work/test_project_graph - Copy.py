import unittest
from project_graph import analyze_project_graph


class ProjectGraphTests(unittest.TestCase):
    def test_cross_file_import_and_call_edges(self):
        files = {
            'app.py': 'from db_layer import run_query\nuser = input("name")\nrun_query(user)\n',
            'db_layer.py': 'def run_query(value):\n    cursor.execute("SELECT " + value)\n',
        }
        result = analyze_project_graph(files)
        self.assertTrue(any(e['from'] == 'app.py' and e['to'] == 'db_layer.py' for e in result['imports']))
        self.assertTrue(any(e['function'] == 'run_query' and e['from'] == 'app.py' and e['to'] == 'db_layer.py' for e in result['call_edges']))
        self.assertGreaterEqual(len(result['dataflow_candidates']), 1)

    def test_no_false_cross_file_edges_without_import(self):
        files = {
            'main.py': 'def main():\n    return 1\n',
            'other.py': 'def unrelated():\n    return 2\n',
        }
        result = analyze_project_graph(files)
        self.assertEqual(result['imports'], [])
        self.assertEqual(result['call_edges'], [])


if __name__ == '__main__':
    unittest.main()
