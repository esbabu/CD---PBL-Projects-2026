"""Comprehensive Test Suite for Hybrid Multi-Agent Architecture (Section 12).

Tests:
1. Local Non-LLM agents offline (FileScanner, SyntaxChecker, PatternDetection, DependencyAnalysis, ReportGeneration, Verification)
2. Ollama availability and graceful offline fallback
3. Online AI agents (when credentials present)
4. IntelligentTaskRouter in AUTO, LOCAL_ONLY, ONLINE_ONLY modes
5. Online-to-Local fallback mechanism
6. Cross-file data flow detection
7. Repair and verification pipeline
8. Self-healing pipeline
9. Agent activity tracking & execution logging
10. Backwards compatibility with existing endpoints
"""
import io
import os
import sys
import unittest
import zipfile

# Ensure path is set
sys.path.insert(0, os.path.dirname(__file__))

from agents import (
    MasterOrchestrator,
    IntelligentTaskRouter,
    AgentTask,
    AgentStatus,
    ExecutionMode,
    FileScannerAgent,
    SyntaxCheckerAgent,
    PatternDetectionAgent,
    DependencyAnalysisAgent,
    ReportGenerationAgent,
    VerificationAgent,
    CodeExplanationAgent,
    AdvancedVulnerabilityAnalysisAgent,
    CrossFileDataFlowAgent,
    ComplexRepairAgent,
)
from app import app


class TestMultiAgentSystem(unittest.TestCase):
    def setUp(self):
        self.orchestrator = MasterOrchestrator.get_instance()
        self.app = app.test_client()

    def test_01_local_non_llm_agents_offline(self):
        """Test all 6 local non-LLM agents function without internet or keys."""
        # 1. File Scanner
        scanner = FileScannerAgent()
        self.assertTrue(scanner.is_available())
        task_scan = AgentTask(
            task_type="scan_files",
            filename="myproject",
            context={
                "file_sources": {
                    "app.py": "print('hello')",
                    "requirements.txt": "flask==1.1.2\n",
                    "node_modules/bad.js": "ignored",
                }
            }
        )
        res_scan = scanner.run(task_scan)
        self.assertEqual(res_scan.status, AgentStatus.COMPLETED)
        self.assertIn("app.py", res_scan.affected_files)
        self.assertNotIn("node_modules/bad.js", res_scan.affected_files)

        # 2. Syntax Checker - Valid code
        syntax_checker = SyntaxCheckerAgent()
        res_syntax_ok = syntax_checker.run(AgentTask(task_type="syntax", code="x = 10\ny = 20\n", filename="test.py"))
        self.assertEqual(res_syntax_ok.status, AgentStatus.COMPLETED)
        self.assertEqual(len(res_syntax_ok.findings), 0)

        # Syntax Checker - Broken code
        res_syntax_bad = syntax_checker.run(AgentTask(task_type="syntax", code="def broken(\n", filename="test.py"))
        self.assertEqual(res_syntax_bad.status, AgentStatus.FAILED)
        self.assertTrue(len(res_syntax_bad.findings) > 0)

        # 3. Pattern Detection Agent
        pattern_agent = PatternDetectionAgent()
        vuln_code = (
            "import os\n"
            "from flask import request\n"
            "cmd = request.args.get('cmd')\n"
            "os.system(cmd)\n"
        )
        res_pat = pattern_agent.run(AgentTask(task_type="pattern_scan", code=vuln_code, filename="test.py"))
        self.assertEqual(res_pat.status, AgentStatus.COMPLETED)
        self.assertTrue(len(res_pat.findings) > 0)

        # 4. Dependency Analysis Agent
        dep_agent = DependencyAnalysisAgent()
        req_content = "urllib3==1.25.8\nrequests==2.19.0\n"
        res_dep = dep_agent.run(AgentTask(task_type="dependency_scan", context={"file_sources": {"requirements.txt": req_content}}))
        self.assertEqual(res_dep.status, AgentStatus.COMPLETED)
        self.assertTrue(len(res_dep.findings) > 0)

        # 5. Report Generation Agent
        rep_agent = ReportGenerationAgent()
        res_rep = rep_agent.run(AgentTask(task_type="report_generate", context={"findings": res_pat.findings}))
        self.assertEqual(res_rep.status, AgentStatus.COMPLETED)
        self.assertIn("security_score", res_rep.data.get("summary", {}))

        # 6. Verification Agent - Passing fix
        verifier = VerificationAgent()
        safe_code = "def safe(): return 42\n"
        res_ver_ok = verifier.run(AgentTask(
            task_type="verify_repair",
            code=safe_code,
            filename="test.py",
            context={"original_code": vuln_code}
        ))
        self.assertEqual(res_ver_ok.status, AgentStatus.COMPLETED)
        self.assertTrue(res_ver_ok.data.get("verified"))

        # Verification Agent - Broken syntax in repair
        res_ver_bad = verifier.run(AgentTask(
            task_type="verify_repair",
            code="def broken(\n",
            filename="test.py",
            context={"original_code": vuln_code}
        ))
        self.assertEqual(res_ver_bad.status, AgentStatus.FAILED)
        self.assertFalse(res_ver_bad.data.get("verified"))

    def test_02_task_router_policies_and_modes(self):
        """Test IntelligentTaskRouter under AUTO, LOCAL_ONLY, and ONLINE_ONLY."""
        router_auto = IntelligentTaskRouter(mode="AUTO")
        task_static = AgentTask(task_type="pattern_scan", code="x = 1")
        agent_s, _, reason_s = router_auto.get_routing_decision(task_static)
        self.assertEqual(agent_s.name, "PatternDetectionAgent")
        self.assertEqual(agent_s.execution_mode, ExecutionMode.LOCAL_STATIC)

        # In LOCAL_ONLY mode, everything routes to local
        router_local = IntelligentTaskRouter(mode="LOCAL_ONLY")
        task_complex = AgentTask(task_type="investigate", code="x = 1")
        agent_l, _, reason_l = router_local.get_routing_decision(task_complex)
        self.assertEqual(agent_l.execution_mode, ExecutionMode.LOCAL_STATIC)
        self.assertIn("LOCAL_ONLY", reason_l)

    def test_03_fallback_mechanism(self):
        """Test graceful fallback when online service is unavailable."""
        router = IntelligentTaskRouter(mode="LOCAL_ONLY")
        task = AgentTask(task_type="repair", code="def test(): pass\n", filename="test.py")
        res = router.route_and_execute(task)
        # Even if online AI is not used, local execution succeeds without crashing
        self.assertIn(res.status, (AgentStatus.COMPLETED, AgentStatus.SKIPPED))

    def test_04_master_orchestrator_project_analysis(self):
        """Test full project analysis run by Master Orchestrator."""
        files = {
            "main.py": (
                "import os\n"
                "from flask import request\n"
                "cmd = request.args.get('cmd')\n"
                "os.system(cmd)\n"
            ),
            "utils.py": "def add(a, b): return a + b\n",
            "requirements.txt": "urllib3==1.25.8\n"
        }
        res = self.orchestrator.run_full_project_analysis(files, project_title="test_proj")
        self.assertTrue(res.get("success"))
        self.assertTrue(res.get("project"))
        self.assertTrue(len(res.get("vulnerabilities", [])) >= 2)  # os.system + urllib3 CVE
        self.assertIn("summary", res)

    def test_05_self_healing_pipeline(self):
        """Test the 11-step self-healing pipeline."""
        vuln_code = "import os\ndef run(cmd):\n    os.system(cmd)\n"
        res = self.orchestrator.run_self_healing_pipeline(vuln_code, "run.py")
        self.assertTrue(res.get("success"))
        self.assertIn("verified", res)
        self.assertIn("repaired_code", res)

    def test_06_flask_agent_endpoints(self):
        """Test Flask REST API endpoints for agent status, routing, and activities."""
        # 1. GET /api/agents
        r_agents = self.app.get('/api/agents')
        self.assertEqual(r_agents.status_code, 200)
        d_agents = r_agents.get_json()
        self.assertTrue(d_agents.get("success"))
        self.assertEqual(len(d_agents.get("agents", [])), 16)

        # 2. GET & POST /api/config/routing
        r_cfg = self.app.get('/api/config/routing')
        self.assertEqual(r_cfg.status_code, 200)
        self.assertTrue(r_cfg.get_json().get("success"))

        r_set = self.app.post('/api/config/routing', json={"mode": "AUTO"})
        self.assertEqual(r_set.status_code, 200)
        self.assertEqual(r_set.get_json().get("mode"), "AUTO")

        # 3. GET /api/agent-activity
        r_act = self.app.get('/api/agent-activity')
        self.assertEqual(r_act.status_code, 200)
        self.assertTrue(isinstance(r_act.get_json().get("activities"), list))

        # 4. POST /api/orchestrate
        r_orch = self.app.post('/api/orchestrate', json={"action": "verify", "code": "x = 10\n", "filename": "t.py"})
        self.assertEqual(r_orch.status_code, 200)
        self.assertTrue(r_orch.get_json().get("data", {}).get("verified"))

    def test_07_existing_routes_preserved(self):
        """Ensure all existing features and routes remain functional."""
        # /analyze with single code
        r_an = self.app.post('/analyze', json={"code": "x = 10\n", "filename": "clean.py"})
        self.assertEqual(r_an.status_code, 200)
        self.assertTrue(r_an.get_json().get("success"))

        # /scan-dependencies
        r_dep = self.app.post('/scan-dependencies', json={"content": "urllib3==1.25.8", "filename": "requirements.txt"})
        self.assertEqual(r_dep.status_code, 200)
        self.assertTrue(r_dep.get_json().get("success"))

        # /groq-status
        r_st = self.app.get('/groq-status')
        self.assertEqual(r_st.status_code, 200)


if __name__ == '__main__':
    unittest.main()
