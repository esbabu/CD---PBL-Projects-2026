# SecureCode AI — Hybrid Local + Online Multi-Agent Security Analysis Platform

SecureCode AI is an enterprise-grade, agentic AI security analysis and self-healing automatic remediation platform. It pairs deterministic compiler-level static analysis with a multi-tiered multi-agent orchestration architecture featuring **16 specialized agents** spanning local offline non-LLM tools, local Ollama models (Qwen 2.5 Coder), and high-reasoning online AI (Gemini / Groq).

---

## Architecture Overview

```
                      ┌─────────────────────────────────────────┐
                      │       User / Frontend / API Clients     │
                      └────────────────────┬────────────────────┘
                                           │
                                           ▼
                      ┌─────────────────────────────────────────┐
                      │        Master Orchestrator Agent        │
                      │  - Task Decomposition & Coordination    │
                      │  - Execution History & Event Streaming  │
                      └────────────────────┬────────────────────┘
                                           │
                        ┌──────────────────┴──────────────────┐
                        │      Intelligent Task Router        │
                        │ Modes: AUTO | LOCAL_ONLY | ONLINE   │
                        │ Policy Routing & Dynamic Fallbacks  │
                        └───────┬──────────────┬──────────────┘
                                │              │
            ┌───────────────────┘              └──────────────────┐
            ▼                                                     ▼
┌───────────────────────────┐                         ┌───────────────────────────┐
│     Local Execution       │                         │     Online AI Execution   │
│  (100% Offline, Zero Key) │                         │    (Groq / Gemini / xAI)  │
├───────────────────────────┤                         ├───────────────────────────┤
│ • FileScannerAgent        │                         │ • AdvancedVulnerability   │
│ • SyntaxCheckerAgent      │                         │   AnalysisAgent           │
│ • PatternDetectionAgent   │                         │ • CrossFileDataFlowAgent  │
│ • DependencyAnalysisAgent │                         │ • ComplexRepairAgent      │
│ • ReportGenerationAgent   │                         │ • SecurityInvestigation   │
│ • VerificationAgent       │                         │   Agent                   │
├───────────────────────────┤                         │ • AdvancedProject         │
│ Local Ollama AI Agents    │                         │   UnderstandingAgent      │
│ • CodeExplanationAgent    │                         └───────────────────────────┘
│ • SimpleBugDetectionAgent │
│ • BasicCodeRepairAgent    │
│ • DocumentationAgent      │
│ • ErrorClassificationAgent│
└───────────────────────────┘
```

---

## The 16 Specialized Agents

### 1. Local Non-LLM Agents (100% Offline & Deterministic)
*Require zero network access, zero API keys, zero token cost.*
- **FileScannerAgent (`local_file_scanner`)**: Scans uploaded folders/ZIPs, builds file maps, classifies languages, and filters excluded directories (`node_modules`, `.git`, `venv`, etc.).
- **SyntaxCheckerAgent (`local_syntax_checker`)**: Validates AST/syntax integrity across Python, JS, Java, C, and C++ with exact file paths and error line numbers.
- **PatternDetectionAgent (`local_pattern_detector`)**: High-throughput rule engine detecting SQL injection, XSS, command injection, path traversal, hardcoded secrets, and unsafe deserialization with code evidence.
- **DependencyAnalysisAgent (`local_dependency_analyzer`)**: Parses package manifests (`requirements.txt`, `package.json`, `pom.xml`, etc.) and correlates against offline local vulnerability signatures.
- **ReportGenerationAgent (`local_report_generator`)**: Compiles structured security audits, vulnerability metrics, and JSON/PDF report exports.
- **VerificationAgent (`local_verification_agent`)**: Re-analyzes patched code against original AST trees to ensure vulnerabilities are genuinely resolved without regressions or syntax breaks.

### 2. Local AI Agents (Ollama / Qwen 2.5 Coder)
*Private local reasoning on user workstation with automatic availability checking.*
- **CodeExplanationAgent (`ollama_code_explainer`)**: Generates line-by-line contextual explanations of complex routines.
- **SimpleBugDetectionAgent (`ollama_bug_detector`)**: Uncovers off-by-one errors, null dereferences, resource leaks, and unhandled edge cases.
- **BasicCodeRepairAgent (`ollama_code_repairer`)**: Formulates fast, localized code fixes for minor security or logic bugs.
- **DocumentationAgent (`ollama_doc_generator`)**: Synthesizes clean docstrings, security callouts, and usage documentation.
- **ErrorClassificationAgent (`ollama_error_classifier`)**: Categorizes exceptions, warnings, and compiler errors into standard CWE/OWASP categories.

### 3. Online Cloud AI Agents (Groq / Gemini / xAI)
*Deep reasoning, multi-file correlation, and synthesis for sophisticated security tasks.*
- **AdvancedVulnerabilityAnalysisAgent (`online_vuln_analyst`)**: Multi-step chain-of-thought investigation of complex logic flaws, race conditions, and business logic defects.
- **CrossFileDataFlowAgent (`online_cross_file_flow`)**: Traces tainted input across architectural boundaries, function calls, and multi-file import graphs.
- **ComplexRepairAgent (`online_complex_repairer`)**: Synthesizes surgical, multi-hunk unified patches preserving surrounding application behavior.
- **SecurityInvestigationAgent (`online_security_investigator`)**: Correlates evidence across files, discriminates true threats from false positives, and identifies root causes.
- **AdvancedProjectUnderstandingAgent (`online_project_architect`)**: Constructs top-down architectural mental models and dependency graphs across microservices and packages.

---

## Intelligent Task Routing

The system provides 3 configurable routing modes:
1. **⚡ Auto (Recommended)**: Runs deterministic scanning, syntax validation, and dependency parsing locally at zero cost. Automatically escalates deep reasoning, cross-file flows, and complex patch synthesis to online LLMs.
2. **💻 Local Only**: 100% air-gapped mode. Never issues outbound network calls or API requests. LLM tasks utilize local Ollama if available or fall back gracefully to local heuristic agents.
3. **☁ Online Only**: Prioritizes cloud LLM reasoning across all analysis and synthesis tasks.

### Resilient Fallback Hierarchy
If an online model encounters network timeouts, rate limits, or quota exhaustion:
1. The Task Router detects the failure instantly.
2. The task automatically degrades to Local Ollama (if running) or Local Deterministic agents.
3. Zero crashes or dropped user requests; execution logs record the handoff event transparently.

---

## Self-Healing Remediation Pipeline

When requested, SecureCode AI executes an 11-step end-to-end self-healing cycle:
1. **Source Ingestion**: `FileScannerAgent` indexes selected files and builds project map.
2. **Detection**: `PatternDetectionAgent` executes static checks and flags vulnerable candidate lines.
3. **Syntax Validation**: `SyntaxCheckerAgent` validates AST state.
4. **Classification**: `ErrorClassificationAgent` maps issues to CWE IDs and severity tiers.
5. **Investigation**: `SecurityInvestigationAgent` or `AdvancedVulnerabilityAnalysisAgent` correlates root cause.
6. **Patch Proposal**: `ComplexRepairAgent` generates contextual code patches.
7. **Split Diff Presentation**: Side-by-side unified diff displayed in the UI for user review.
8. **User Approval / Gate**: User confirms applying the patch or requests adjustments.
9. **Automated Application**: Secure restore point is snapshotted before the patch is committed.
10. **Syntax & Regression Verification**: `VerificationAgent` runs syntax checks and verifies the fix actually resolved the issue.
11. **Final Audit & Reporting**: `ReportGenerationAgent` updates the project security score and audit log.

---

## Agent Activity Dashboard

The web UI includes a real-time **🤖 Agent Activity** dashboard:
- **Routing Mode Switcher**: Switch between `Auto`, `Local Only`, and `Online Only` with a single click.
- **Status Metrics**: Real-time counter of Active (Blue), Completed (Green), Waiting (Yellow), and Failed (Red) agent tasks.
- **Registered Agents Grid**: Live cards for all 16 agents showing provider, execution mode, capabilities, and readiness status.
- **Live Activity Stream**: Real-time feed of task execution IDs, responsible agents, target files, execution times (ms), and agent handoffs.
- **Interactive Details Drawer**: Click any activity entry to inspect the full standardized `AgentResult` JSON payload, code evidence, and recommendations.

---

## REST API Endpoints

- `GET /api/agents`: Returns all 16 registered agents and their availability.
- `GET /api/agent-activity`: Streams or retrieves the latest task execution history and handoffs.
- `GET /api/config/routing`: Retrieves current routing mode (`auto`, `local_only`, `online_only`).
- `POST /api/config/routing`: Updates the routing mode dynamically (`{"mode": "auto" | "local_only" | "online_only"}`).
- `POST /api/orchestrate`: Dispatches high-level workflows to the Master Orchestrator (`self_healing_pipeline`, `explain_file`, `verify_fix`).
- `POST /api/analyze`: Unified source analysis passing through Orchestrator logging and multi-agent pipeline.
- `POST /api/analyze-project`: VS Code explorer folder/ZIP scan using `FileScannerAgent` and multi-file analysis.

---

## Getting Started

### 1. Requirements
- Python 3.10+
- (Optional for Online AI) Groq API key or Gemini API key.
- (Optional for Local LLM) Ollama with `qwen2.5-coder:3b` installed.

### 2. Installation
```bash
cd v21_firewall_work
pip install -r requirements.txt
```

### 3. Configure API Key
Create or edit `.env` in `v21_firewall_work/`:
```ini
GROQ_API_KEY=your_gemini_or_groq_api_key_here
GROQ_MODEL=gemini-flash-lite-latest
```

### 4. Run the Application
```bash
python app.py
```
Or run `run_web.bat` on Windows.

Open your browser to:
`http://localhost:5000`

---

## Verification & Testing

Run the complete test suite including the multi-agent test harness:
```bash
python -m unittest discover -s . -p "test_*.py"
```
Output:
```
Ran 37 tests in 5.342s
OK
```

Self-Security Scan of all agent modules:
```bash
python -c "from broad_security_analyzer import BroadSecurityAnalyzer; import glob; ..."
# Result: 0 Vulnerabilities across all agent modules.
```
