import unittest
import json
import os
from app import app
from broad_security_analyzer import analyze_source as analyze_python_source
from multilang_security_analyzer import analyze_source as analyze_multilang_source
from project_graph import analyze_project_graph


class TestGroqIntegrationAndUpgrade(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_groq_status_endpoint(self):
        res = self.client.get('/groq-status')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data.get('success'))
        self.assertIn('available', data)
        self.assertIn('supported_models', data)
        self.assertIsInstance(data['supported_models'], list)

    def test_groq_models_endpoint(self):
        res = self.client.get('/groq-models')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data.get('success'))
        self.assertGreater(len(data.get('models', [])), 0)

    def test_groq_set_model(self):
        models_res = self.client.get('/groq-models')
        available_models = [m['id'] for m in models_res.get_json().get('models', [])]
        self.assertGreater(len(available_models), 0)
        target_model = available_models[0]

        # Valid model
        res = self.client.post('/groq-set-model', json={'model': target_model})
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.get_json().get('model'), target_model)
        self.assertEqual(os.getenv('GROQ_MODEL'), target_model)

        # Invalid model
        res = self.client.post('/groq-set-model', json={'model': 'non-existent-model'})
        self.assertEqual(res.status_code, 400)

    def test_groq_set_key(self):
        orig_key = os.getenv('GROQ_API_KEY')
        orig_gemini_key = os.getenv('GEMINI_API_KEY')
        orig_provider = os.getenv('AI_PROVIDER')
        try:
            # Empty key returns 400
            res = self.client.post('/groq-set-key', json={'api_key': ''})
            self.assertEqual(res.status_code, 400)
            self.assertFalse(res.get_json().get('success'))

            # Setting key succeeds and returns masked status
            res = self.client.post('/groq-set-key', json={'api_key': 'gsk_testdummy1234567890abcdef', 'persist': False})
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertTrue(data.get('success'))
            self.assertIn('status', data)
            self.assertEqual(data['status'].get('masked_key'), 'gsk_...cdef')
        finally:
            if orig_key is not None:
                os.environ['GROQ_API_KEY'] = orig_key
            if orig_gemini_key is not None:
                os.environ['GEMINI_API_KEY'] = orig_gemini_key
            if orig_provider is not None:
                os.environ['AI_PROVIDER'] = orig_provider

    def test_finding_impact_fields(self):
        # Python analyzer findings have impact
        py_code = "import os; os.system(input('cmd: '))"
        findings = analyze_python_source(py_code, 'test.py')
        self.assertGreater(len(findings), 0)
        for f in findings:
            self.assertIn('impact', f)
            self.assertIsInstance(f['impact'], str)
            self.assertGreater(len(f['impact']), 5)

        # JS analyzer findings have impact
        js_code = "const { exec } = require('child_process'); exec(req.query.cmd);"
        js_findings = analyze_multilang_source(js_code, 'test.js', language='JavaScript')
        self.assertGreater(len(js_findings), 0)
        for f in js_findings:
            self.assertIn('impact', f)
            self.assertIsInstance(f['impact'], str)
            self.assertGreater(len(f['impact']), 5)

    def test_project_graph_architecture_and_unused_functions(self):
        files = {
            'routes.py': '@app.route("/run")\ndef handler():\n    return run_query(request.args.get("q"))\n',
            'db.py': 'def run_query(sql):\n    cursor.execute(sql)\ndef dead_code():\n    return 42\n',
            'client.js': 'document.getElementById("btn").addEventListener("click", () => fetch("/run"));\n'
        }
        graph = analyze_project_graph(files)
        self.assertIn('architecture_summary', graph)
        self.assertIn('architecture', graph)
        self.assertIn('unused_functions', graph)
        self.assertTrue(any(u['name'] == 'dead_code' for u in graph['unused_functions']))

    def test_export_report_endpoint(self):
        res = self.client.post('/export-report', json={
            'format': 'json',
            'analysis': {
                'filename': 'demo.py',
                'summary': {'total_vulnerabilities': 1},
                'vulnerabilities': [{'id': 'TEST-01', 'severity': 'HIGH', 'line': 5}]
            }
        })
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.headers.get('Content-Type'), 'application/json')
        data = res.get_json()
        self.assertEqual(data.get('report_type'), 'SecureCode AI Security Report')
        self.assertEqual(data.get('filename'), 'demo.py')


if __name__ == '__main__':
    unittest.main()
