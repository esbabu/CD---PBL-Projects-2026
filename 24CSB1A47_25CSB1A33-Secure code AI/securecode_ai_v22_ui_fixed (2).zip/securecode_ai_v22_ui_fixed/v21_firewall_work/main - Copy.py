"""
Main - SQL Injection Detector
Usage:
    python main.py                    # run built-in Python demo cases
    python main.py <source-file>      # analyse Python, JavaScript, Java, C or C++
"""

import sys
import os

from unified_types import *
from module1_input_detection import InputDetectionModule
from module2_rule_engine import RuleEngineModule
from module3_warning_logic import WarningDecisionLogic
from ast_traverser import ASTTraverser
from python_ast_bridge import PythonASTBridge
from broad_security_analyzer import analyze_file as broad_analyze_file
from multilang_security_analyzer import analyze_source as multilang_analyze_source, language_for

import demo_programs


def run_demo(title, ast_root):
    print("\n" + "="*80)
    print(f"DEMO CASE: {title}")
    print("="*80)

    symbol_table = SymbolTable()

    input_detector = InputDetectionModule(symbol_table)
    rule_engine    = RuleEngineModule(symbol_table)
    warning_logic  = WarningDecisionLogic(symbol_table)

    traverser = ASTTraverser(
        input_detector,
        rule_engine,
        warning_logic,
        symbol_table
    )

    print("\n>> Running Analysis...\n")

    stats = traverser.analyze(ast_root)

    print("\n>> Symbol Table State:")
    for var, state in symbol_table.get_all_variables().items():
        print(f"   {var} -> {state}")

    print("\n>> Detailed Vulnerability Report:")
    print(warning_logic.generate_text_report())

    print("\n>> JSON Report:")
    print(warning_logic.generate_json_report())

    print("\n>> Statistics:")
    for key, value in stats.items():
        print(f"   {key}: {value}")

    print("\n" + "="*80 + "\n")
    return warning_logic.warnings


def run_file_mode(filepath):
    safe_path = os.path.abspath(filepath)
    if not os.path.isfile(safe_path):
        print(f"[ERROR] File not found: {filepath}")
        sys.exit(1)

    language = language_for(safe_path)
    print(f"\n[*] Analysing file: {safe_path} ({language})\n")

    if language != "Python":
        with open(safe_path, "r", encoding="utf-8") as f:
            source = f.read()
        findings = multilang_analyze_source(source, safe_path)
        print("="*80)
        print(f"MULTI-LANGUAGE SECURITY ANALYSIS — {language}")
        print("="*80)
        print(f"Findings: {len(findings)}")
        for finding in findings:
            print(f"\n[{finding['severity']}] {finding['category']} — {finding['rule_violated']}")
            print(f"  Line: {finding['line']} | Sink: {finding['sink']} | Confidence: {finding['confidence']:.0%}")
            print(f"  {finding['description']}")
            print(f"  Fix: {finding['suggested_fix']}")
        print("="*80)
        return

    bridge = PythonASTBridge()
    ast_root = bridge.parse_file(filepath)
    title = f"File: {os.path.basename(filepath)}"
    legacy_warnings = run_demo(title, ast_root)
    broad_findings = broad_analyze_file(filepath)
    legacy_keys = {(v.line_number, v.sink_type) for v in legacy_warnings}
    supplemental = [f for f in broad_findings if not (f.get("category") == "SQL Injection" and (f.get("line"), f.get("sink")) in legacy_keys)]
    print("\n" + "="*80)
    print("SUPPLEMENTAL BROAD PYTHON SECURITY ANALYSIS")
    print("="*80)
    print(f"Additional findings: {len(supplemental)}")
    for finding in supplemental:
        print(f"\n[{finding['severity']}] {finding['category']} — {finding['rule_violated']}")
        print(f"  Line: {finding['line']} | Sink: {finding['sink']} | Confidence: {finding['confidence']:.0%}")
        print(f"  {finding['description']}")
        print(f"  Fix: {finding['suggested_fix']}")
    print("="*80)


def run_demo_mode():
    demos = [
        demo_programs.vulnerable_concat_program(),
        demo_programs.vulnerable_format_program(),
        demo_programs.safe_parameterized_program(),
        demo_programs.safe_sanitized_program(),
    ]
    for title, ast in demos:
        run_demo(title, ast)
    print("\n[DONE] Demonstration Complete.\n")


if __name__ == "__main__":

    print("""
+------------------------------------------------------------------------------+
|         WEEK 6 - SQL INJECTION DETECTION SYSTEM                              |
+------------------------------------------------------------------------------+
""")

    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg in ("--help", "-h"):
            print("Usage:")
            print("  python main.py               # run built-in demo cases")
            print("  python main.py <source-file> # analyse Python, JavaScript, Java, C or C++")
        else:
            run_file_mode(arg)
    else:
        run_demo_mode()
