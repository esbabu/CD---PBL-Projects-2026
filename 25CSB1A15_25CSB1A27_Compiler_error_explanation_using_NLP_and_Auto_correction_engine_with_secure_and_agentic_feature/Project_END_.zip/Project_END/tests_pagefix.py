"""tests_pagefix.py – Unit tests for live page route error handling, deterministic and AI fixes, multi-bug cascade, and UTF-8 encoding integrity.
Zero real LLM calls (AI path mocked).
"""

import os
import sys
import json
import unittest
from unittest.mock import patch

from app import app
from nlp_explainer import NLPExplainer, _run_in_sandbox


class TestPageFix(unittest.TestCase):
    def setUp(self):
        from app import _ANALYZE_CACHE, _ANALYZE_CACHE_LOCK
        with _ANALYZE_CACHE_LOCK:
            _ANALYZE_CACHE.clear()
        self.env_patcher = patch.dict(os.environ, {"LLM_DISABLED": "1", "AUTOFIX_AI": "0"})
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)
        self.client = app.test_client()

    def test_case_a1_name_error_fixed(self):
        code = 'message = "hello"\nprint(mesage)'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertEqual(data.get("explanation_source"), "rule")
        self.assertIn("print(message)", data.get("fixed_code"))
        self.assertEqual(data.get("fix_status"), "applied")

    def test_case_a2_syntax_colon_fixed(self):
        code = 'def greet(name)\n    print("Hi", name)\ngreet("Sam")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertEqual(data.get("explanation_source"), "rule")
        self.assertIn("def greet(name):", data.get("fixed_code"))
        self.assertEqual(data.get("fix_status"), "applied")

    def test_case_a3_type_error_str_concat_fixed(self):
        code = 'print("Total: " + 5)'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertEqual(data.get("fix_source"), "deterministic")
        self.assertEqual(data.get("fixed_code").strip(), 'print("Total: " + str(5))')
        self.assertEqual(data.get("fix_status"), "applied")

    def test_case_a4_attribute_error_list_append_fixed(self):
        code = 'nums = [3, 1, 2]\nnums.apend(4)'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertEqual(data.get("fix_source"), "deterministic")
        self.assertIn("nums.append(4)", data.get("fixed_code"))
        self.assertEqual(data.get("fix_status"), "applied")

    def test_case_b4_module_not_found_stdlib_typo_fixed(self):
        code = 'import jsno\nprint("ok")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertEqual(data.get("fix_source"), "deterministic")
        self.assertIn("import json", data.get("fixed_code"))
        self.assertEqual(data.get("fix_status"), "applied")

    def test_unfixable_deterministic_cases_return_unchanged_with_no_fixer(self):
        unfixable_cases = {
            "A5": ('import math\nprint(math.sqrt(-1))', "ValueError"),
            "B5": ('import some_missing_package', "ModuleNotFoundError")
        }
        for name, (code, expected_err) in unfixable_cases.items():
            resp = self.client.post('/api/analyze', json={'code': code})
            self.assertEqual(resp.status_code, 200, f"Case {name} failed status")
            data = resp.get_json()
            self.assertEqual(data.get("status"), "error_intercepted", f"Case {name} status")
            self.assertEqual(data.get("fixed_code"), code, f"Case {name} fixed_code modified")
            self.assertTrue("stopped at line" in data.get("fix_status"), f"Case {name} fix_status")
            self.assertEqual(data.get("fix_source"), "none", f"Case {name} fix_source")
            if name == "B5":
                self.assertIn("import some_missing_package", data.get("fixed_code"))

    def test_multi_bug_snippet_cascade(self):
        # A3 (TypeError) + A6 (TypeError int iterable) both repaired across loop rounds
        code = 'print("Total: " + 5)\nfor x in 100:\n    print(x)'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertIn("str(5)", data.get("fixed_code"))
        self.assertIn("range(100)", data.get("fixed_code"))
        self.assertEqual(data.get("fix_status"), "applied")

    def test_empty_and_valid_code_do_not_crash(self):
        # Empty code -> HTTP 400
        resp_empty = self.client.post('/api/analyze', json={'code': ''})
        self.assertEqual(resp_empty.status_code, 400)

        # Whitespace code -> HTTP 400
        resp_space = self.client.post('/api/analyze', json={'code': '   \n  '})
        self.assertEqual(resp_space.status_code, 400)

        # Valid code -> HTTP 200 success
        valid_code = 'x = 10\ny = 20\nprint(x + y)'
        resp_valid = self.client.post('/api/analyze', json={'code': valid_code})
        self.assertEqual(resp_valid.status_code, 200)
        data_valid = resp_valid.get_json()
        self.assertEqual(data_valid.get("status"), "success")
        self.assertEqual(data_valid.get("fix_status"), "already_clean")

    def test_utf8_encoding_integrity(self):
        # Unicode characters in print
        code = 'print("héllo ✓ 日本")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("héllo ✓ 日本", data.get("raw_text", ""))
        self.assertIn("héllo ✓ 日本", data.get("message", ""))

        # Ensure no double-encoded artifacts like 'Ã' or 'âœ'
        for field, value in data.items():
            if isinstance(value, str):
                self.assertNotIn("hÃ©llo", value, f"Double-encoded artifact in {field}")
                self.assertNotIn("âœ", value, f"Double-encoded artifact in {field}")

        # Syntax error with non-ASCII characters
        syntax_code = 'print("héllo ✓")\nx = [1, 2, 3'
        resp_syn = self.client.post('/api/analyze', json={'code': syntax_code})
        self.assertEqual(resp_syn.status_code, 200)
        data_syn = resp_syn.get_json()
        self.assertEqual(data_syn.get("status"), "error_intercepted")
        self.assertIn("héllo ✓", data_syn.get("fixed_code", ""))

    def test_ai_autofix_mocked_success(self):
        code = "def recurse(a, b):\n    return recurse(a - 1, b)\nprint(recurse(2, 3))"
        patch_text = "Replace line 2 with:\n    if a <= 0: return b\n    return recurse(a - 1, b)"
        
        with patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "fake-key", "MULTI_ERROR": "0"}), \
             patch("llm_calls.call_gemini", return_value=(patch_text, None, False)):
            resp = self.client.post('/api/analyze', json={'code': code})
            self.assertEqual(resp.status_code, 200)
            data = resp.get_json()
            self.assertEqual(data.get("fix_source"), "ai")
            self.assertEqual(data.get("fix_status"), "applied")
            self.assertIn("if a <= 0: return b", data.get("fixed_code"))

    def test_ai_autofix_mocked_deletion_rejection(self):
        code = "def recurse(a, b):\n    return recurse(a - 1, b)\nprint(recurse(2, 3))"
        # Patch that just deletes the failing line
        delete_patch = "Replace line 2 with:\n    pass"
        
        with patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "fake-key", "MULTI_ERROR": "0"}), \
             patch("llm_calls.call_gemini", return_value=(delete_patch, None, False)), \
             patch("llm_calls.call_groq", return_value=(None, "rejected", False)):
            resp = self.client.post('/api/analyze', json={'code': code})
            self.assertEqual(resp.status_code, 200)
            data = resp.get_json()
            self.assertEqual(data.get("fixed_code"), code)
            self.assertTrue("rejected" in data.get("fix_status") or "stopped at line" in data.get("fix_status"))

    def test_ai_autofix_mocked_still_raises_rejection(self):
        code = "def recurse(a, b):\n    return recurse(a - 1, b)\nprint(recurse(2, 3))"
        # Patch that does not fix the RecursionError
        bad_patch = "Replace line 2 with:\n    return recurse(a, b)"
        
        with patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0"}), \
             patch("llm_calls.call_gemini", return_value=(bad_patch, None, False)), \
             patch("llm_calls.call_groq", return_value=(None, "rejected", False)):
            resp = self.client.post('/api/analyze', json={'code': code})
            self.assertEqual(resp.status_code, 200)
            data = resp.get_json()
            self.assertEqual(data.get("fixed_code"), code)
            self.assertTrue("rejected" in data.get("fix_status") or "stopped at line" in data.get("fix_status"))


if __name__ == "__main__":
    unittest.main()
