"""Unit tests verifying light mode default, collapsed sidebar default, and welcome popup guide."""
import os
import unittest
from bs4 import BeautifulSoup


class TestUIThemeAndWelcomeGuide(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(cls.html_path, "r", encoding="utf-8") as f:
            cls.html_content = f.read()
        cls.soup = BeautifulSoup(cls.html_content, "html.parser")

    def test_sidebar_defaults_to_collapsed_in_html(self):
        """Sidebar markup must have class 'collapsed' by default."""
        sidebar = self.soup.find("aside", id="sidebar")
        self.assertIsNotNone(sidebar, "Sidebar <aside id='sidebar'> must exist")
        classes = sidebar.get("class", [])
        self.assertIn("collapsed", classes, "Sidebar must have class 'collapsed' by default")

    def test_sidebar_toggle_button_and_pulse_animation(self):
        """Hamburger button must have proper title and pulse animation CSS exists."""
        btn_toggle = self.soup.find("button", id="btn-toggle-sidebar")
        self.assertIsNotNone(btn_toggle)
        self.assertIn("☰", btn_toggle.text)
        self.assertIn("pulse-hamburger", self.html_content)
        self.assertIn(".pulse-highlight", self.html_content)

    def test_welcome_modal_structure_and_messaging(self):
        """Welcome modal must exist, explain sidebar collapsed status, and prompt hamburger button."""
        modal = self.soup.find("div", id="w3_modal_welcome")
        self.assertIsNotNone(modal, "#w3_modal_welcome must exist in DOM")
        modal_text = modal.get_text()
        self.assertIn("Sidebar Collapsed by Default", modal_text)
        self.assertIn("☰", modal_text)

    def test_navbar_welcome_guide_button(self):
        """Navbar must include quick-access help/guide button for reopening modal."""
        btn_guide = self.soup.find("button", id="btn-welcome-guide")
        self.assertIsNotNone(btn_guide, "#btn-welcome-guide must exist in top navbar")
        self.assertIn("w3_open_modal('w3_modal_welcome')", btn_guide.get("onclick", ""))

    def test_theme_defaults_to_light_mode_in_script(self):
        """Theme script must default to light mode unless 'dark' is explicitly saved."""
        self.assertIn("if (savedTheme === 'dark') {", self.html_content)
        self.assertIn("applyTheme(true);", self.html_content)
        self.assertIn("applyTheme(false);", self.html_content)

    def test_welcome_modal_js_handlers_exist(self):
        """JS handlers for welcome modal must be defined."""
        self.assertIn("function openSidebarFromWelcome()", self.html_content)
        self.assertIn("function closeWelcomeModal()", self.html_content)
        self.assertIn("function initWelcomeModal()", self.html_content)
        self.assertIn("initWelcomeModal();", self.html_content)


if __name__ == "__main__":
    unittest.main()
