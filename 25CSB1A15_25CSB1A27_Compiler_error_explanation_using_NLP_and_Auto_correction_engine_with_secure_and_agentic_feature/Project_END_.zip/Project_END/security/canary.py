"""security/canary.py - Honeypot & Canary Token Defense System for IntelliFix.

Implements decoy canary tokens (environment variables and filesystem traps)
in the sandbox runner. Any attempt by executed code or untrusted scripts to
probe, read, or exfiltrate these honeypots triggers an immediate lockdown,
records a high-priority violation, and logs to the cryptographic audit ledger.
"""

import os
import re
from typing import Any, Dict, List, Optional, Tuple

CANARY_SIGNATURE_PREFIX = "canary_live_tok_"

# Known honeypot environment variables and their decoy token signatures
DEFAULT_CANARY_ENV_VARS: Dict[str, str] = {
    "AWS_SECRET_ACCESS_KEY": f"{CANARY_SIGNATURE_PREFIX}aws_wJalrXUtnFEMI_K7MDENG_bPxRfiCYEXAMPLEKEY",
    "DATABASE_ADMIN_PASSWORD": f"{CANARY_SIGNATURE_PREFIX}db_Adm1n_S3cur1ty_P@ss_9918",
    "OPENAI_API_SECRET_KEY": f"{CANARY_SIGNATURE_PREFIX}sk-live-sec-4819aa28bb91cc7721",
    "INTELLIFIX_CANARY_TOKEN": f"{CANARY_SIGNATURE_PREFIX}root_master_token_x99a007"
}

# Known decoy files injected into sandbox working directories
CANARY_FILES: Dict[str, str] = {
    ".env.canary": (
        "# IntelliFix System Configuration (CONFIDENTIAL)\n"
        f"CANARY_SECRET_DEPLOY_KEY={CANARY_SIGNATURE_PREFIX}deploy_vault_sec_4102\n"
        f"PROD_DB_URL=postgresql://admin:{CANARY_SIGNATURE_PREFIX}db_vault_8109@internal.db:5432/main\n"
    ),
    ".aws_credentials": (
        "[default]\n"
        f"aws_access_key_id = AKIA_CANARY_DEMO_ID\n"
        f"aws_secret_access_key = {CANARY_SIGNATURE_PREFIX}aws_decoy_sec_7718\n"
    ),
    "secrets_canary.json": (
        "{\n"
        f'  "jwt_secret": "{CANARY_SIGNATURE_PREFIX}jwt_super_secret_5510",\n'
        f'  "master_admin_token": "{CANARY_SIGNATURE_PREFIX}admin_tok_9912"\n'
        "}\n"
    )
}

CANARY_FILE_NAMES = tuple(CANARY_FILES.keys())


def is_canary_env_var(var_name: str) -> bool:
    """Check if an environment variable name corresponds to a canary honeypot."""
    if not isinstance(var_name, str):
        return False
    return var_name.upper() in DEFAULT_CANARY_ENV_VARS


def is_canary_file(path_str: str) -> bool:
    """Check if a file path points to a designated canary honeypot file."""
    if not isinstance(path_str, str) or not path_str:
        return False
    base = os.path.basename(path_str.replace("\\", "/")).lower()
    return any(base == c.lower() or base.endswith(c.lower()) for c in CANARY_FILE_NAMES) or "canary" in base


def setup_sandbox_canaries(sandbox_dir: str, env_dict: Dict[str, str]) -> Dict[str, Any]:
    """
    Injects canary environment variables and creates decoy honeypot files
    in the sandbox working directory.

    Returns:
        Dict describing the active canaries for tripwire verification.
    """
    active_canaries: Dict[str, Any] = {
        "env_vars": dict(DEFAULT_CANARY_ENV_VARS),
        "files": [],
        "tokens": set(DEFAULT_CANARY_ENV_VARS.values())
    }

    # 1. Inject canary variables into execution environment
    for k, v in DEFAULT_CANARY_ENV_VARS.items():
        env_dict[k] = v

    # 2. Write decoy canary bait files into sandbox directory
    if sandbox_dir and os.path.isdir(sandbox_dir):
        for fname, content in CANARY_FILES.items():
            fpath = os.path.join(sandbox_dir, fname)
            try:
                with open(fpath, "w", encoding="utf-8") as f:
                    f.write(content)
                active_canaries["files"].append(fname)
                # Extract any tokens embedded in file content
                for token in re.findall(rf"{CANARY_SIGNATURE_PREFIX}[A-Za-z0-9_\-]+", content):
                    active_canaries["tokens"].add(token)
            except Exception:
                pass

    return active_canaries


def detect_canary_leak(text: str, custom_tokens: Optional[set] = None) -> Optional[Dict[str, Any]]:
    """
    Scans a string (stdout, stderr, code diff, or logs) to determine if
    any canary token value was read or exfiltrated.
    """
    if not text or not isinstance(text, str):
        return None

    # Fast pattern match for the canary prefix
    match = re.search(rf"{CANARY_SIGNATURE_PREFIX}[A-Za-z0-9_\-\.\/]+", text)
    if match:
        token = match.group(0)
        return {
            "triggered": True,
            "token": token,
            "category": "CANARY_TOKEN_LEAK",
            "detail": f"Canary honeypot token detected in output/text: {token[:24]}..."
        }

    # Match explicit tokens if provided
    if custom_tokens:
        for t in custom_tokens:
            if t in text:
                return {
                    "triggered": True,
                    "token": t,
                    "category": "CANARY_TOKEN_LEAK",
                    "detail": f"Registered canary token detected: {t[:24]}..."
                }

    return None


def trigger_canary_alert(
    event_type: str,
    detail: str,
    evidence: Optional[Any] = None,
    attack_id: Optional[str] = None,
    log_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Emits an unmaskable high-priority alert and writes an immutable
    event to the Cryptographic Audit Ledger.
    """
    from security import audit_log

    action_attempted = f"CANARY_HONEYPOT_BREACH: {event_type} - {detail}"
    evidence_payload = [detail]
    if evidence:
        evidence_payload.append(str(evidence))

    entry = audit_log.log_event(
        channel="sandbox_canary",
        decision="BLOCK",
        risk_score=100,
        action_attempted=action_attempted,
        category="CANARY_TRIPWIRE",
        attack_id=attack_id,
        evidence=evidence_payload,
        log_path=log_path
    )

    return entry
