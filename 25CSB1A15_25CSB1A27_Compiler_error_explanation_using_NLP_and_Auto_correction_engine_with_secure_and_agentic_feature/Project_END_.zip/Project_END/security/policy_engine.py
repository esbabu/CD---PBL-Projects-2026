"""security/policy_engine.py - Authoritative Security Policy Engine.

Enforces execution policies loaded from security/policy.json.
Provides:
- is_allowed(action: str) -> Tuple[bool, str]
- verify_integrity(manifest_path: Optional[str] = None) -> Tuple[bool, str]
- read-only access (no write APIs)

Design Constraints (Pre-Flight Override 6):
- Scoped to Shield initialization (called lazily when shield.py or agent.py needs it).
- NEVER executed at import time or inside the Flask app factory.
- If policy or security files are tampered, refuses to arm and fails closed safely
  without breaking non-agent web server routes.
"""

import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Tuple

_SECURITY_DIR = os.path.dirname(os.path.abspath(__file__))
_POLICY_PATH = os.path.join(_SECURITY_DIR, "policy.json")
_MANIFEST_PATH = os.path.join(_SECURITY_DIR, "shield_manifest.json")


def compute_file_sha256(path: str) -> str:
    """Compute SHA-256 hexadecimal digest for a file."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found for hashing: {path}")
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


class PolicyEngine:
    """Read-only security policy engine verifying cryptographic integrity."""

    def __init__(self, policy_path: Optional[str] = None, manifest_path: Optional[str] = None):
        self._policy_path = policy_path or _POLICY_PATH
        self._manifest_path = manifest_path or _MANIFEST_PATH
        self._policy: Optional[Dict[str, Any]] = None
        self._initialized: bool = False
        self._arm_error: Optional[str] = None

    def initialize(self) -> Tuple[bool, str]:
        """Verify file integrity and load policy. Scoped strictly to Shield usage."""
        # 1. Verify file integrity against manifest
        ok, reason = self.verify_integrity()
        if not ok:
            self._initialized = False
            self._arm_error = f"Policy engine refused to arm: {reason}"
            return False, self._arm_error

        # 2. Load and validate policy json
        try:
            with open(self._policy_path, "r", encoding="utf-8") as f:
                self._policy = json.load(f)
        except Exception as e:
            self._initialized = False
            self._arm_error = f"Policy engine failed to parse policy: {e}"
            return False, self._arm_error

        self._initialized = True
        self._arm_error = None
        return True, "Policy engine armed successfully."

    @property
    def is_armed(self) -> bool:
        """Returns True if the engine has been verified and armed."""
        return self._initialized and self._policy is not None

    @property
    def arm_error(self) -> Optional[str]:
        """Returns reason if arming failed."""
        return self._arm_error

    def verify_integrity(self, manifest_path: Optional[str] = None) -> Tuple[bool, str]:
        """
        Verify that policy.json and all tracked security modules match manifest hashes.
        Refuses to run if any hash mismatches or manifest is missing.
        """
        mf_path = manifest_path or self._manifest_path
        if not os.path.exists(mf_path):
            return False, f"Shield manifest missing at {mf_path}"

        try:
            with open(mf_path, "r", encoding="utf-8") as f:
                manifest_data = json.load(f)
        except Exception as e:
            return False, f"Shield manifest corrupted or invalid JSON: {e}"

        tracked_files = manifest_data.get("files", {})
        if not tracked_files:
            return False, "Shield manifest contains no tracked files"

        # Check each tracked file
        for rel_name, expected_hash in tracked_files.items():
            full_path = os.path.join(_SECURITY_DIR, rel_name)
            if not os.path.exists(full_path):
                return False, f"Tracked security file missing: {rel_name}"
            try:
                curr_hash = compute_file_sha256(full_path)
            except Exception as e:
                return False, f"Error hashing {rel_name}: {e}"

            if curr_hash.lower() != expected_hash.lower():
                return False, f"Integrity check failed: {rel_name} hash mismatch ({curr_hash[:12]} != {expected_hash[:12]})"

        return True, "Integrity verified against shield manifest."

    def is_allowed(self, action: str) -> Tuple[bool, str]:
        """
        Check if an action is allowed by active policy.
        Returns (allowed: bool, reason: str).
        If policy engine is not armed, fails closed (returns False, 'shield unavailable').
        """
        if not self._initialized:
            # Lazy initialize if needed
            ok, msg = self.initialize()
            if not ok:
                return False, f"Shield unavailable: {self._arm_error}"

        if not self._policy:
            return False, "Shield unavailable: policy not loaded"

        rules = self._policy.get("rules", {})

        action_norm = action.strip().lower()

        # Map common action signatures to policy rules
        action_mapping = {
            "skip_scan": "no_scan_bypass",
            "disable_scan": "no_scan_bypass",
            "bypass_validation": "no_scan_bypass",
            "mark_vulnerable_safe": "no_scan_bypass",
            "read_env": "healed_code_containment",
            "read_personal_data": "healed_code_containment",
            "network_egress": "healed_code_containment",
            "network_exfiltration": "healed_code_containment",
            "write_outside_workspace": "healed_code_containment",
            "unapproved_patch": "human_approval_required",
            "auto_approve": "human_approval_required",
            "unallowed_tool": "allowlisted_tools_only",
            "tool_call_invalid": "allowlisted_tools_only",
            "edit_policy": "policy_files_immutable",
            "delete_policy": "policy_files_immutable",
            "modify_security_file": "policy_files_immutable",
            "runtime_policy_write": "policy_runtime_readonly"
        }

        rule_key = action_mapping.get(action_norm, action_norm)

        if rule_key in rules:
            rule = rules[rule_key]
            r_action = rule.get("action", "deny")
            if r_action == "deny":
                return False, f"Action '{action}' is denied by policy rule '{rule.get('id', rule_key)}': {rule.get('description')}"
            elif r_action == "require_approval":
                return False, f"Action '{action}' requires explicit human approval under rule '{rule.get('id', rule_key)}'"

        return True, f"Action '{action}' permitted under security policy."

    def get_policy(self) -> Dict[str, Any]:
        """Return a copy of the active policy data."""
        if not self._policy:
            self.initialize()
        return dict(self._policy or {})


# Module-level instance accessed lazily by shield.py
_GLOBAL_POLICY_ENGINE: Optional[PolicyEngine] = None


def get_policy_engine() -> PolicyEngine:
    """Return the global PolicyEngine instance (instantiated lazily)."""
    global _GLOBAL_POLICY_ENGINE
    if _GLOBAL_POLICY_ENGINE is None:
        _GLOBAL_POLICY_ENGINE = PolicyEngine()
    return _GLOBAL_POLICY_ENGINE


def is_allowed(action: str) -> Tuple[bool, str]:
    """Convenience functional interface."""
    return get_policy_engine().is_allowed(action)
