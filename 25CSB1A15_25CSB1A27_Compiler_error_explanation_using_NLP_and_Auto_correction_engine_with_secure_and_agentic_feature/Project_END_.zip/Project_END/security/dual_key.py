"""security/dual_key.py - Dual-Key / Four-Eyes Cryptographic Authorization.

Implements the Banking "Four-Eyes Principle" / Two-Person Rule for critical AI actions:
To execute a Tier-1 Critical Action (such as applying code patches or modifying protected
resources), the action requires TWO independent, cryptographically distinct keys:

Key A (Safety Auditor Key):
- Minted ONLY when an independent automated security audit confirms the proposal
  is free of static vulnerabilities, canary leaks, and out-of-scope AST blast-radius mutations.

Key B (Operator Authorization Key):
- Minted when an authenticated human operator explicitly authorizes the proposal.

Both keys must target the exact same proposal ID and code hash, be within their valid
TTL window, and satisfy HMAC-SHA256 signature verification before any write occurs.
"""

import hashlib
import hmac
import json
import os
import secrets
import time
from typing import Any, Dict, List, Optional, Tuple

def _load_or_create_secret(env_var: str, default_name: str) -> bytes:
    env_val = os.environ.get(env_var)
    if env_val:
        return env_val.encode("utf-8")
    sec_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")
    os.makedirs(sec_dir, exist_ok=True)
    sec_file = os.path.join(sec_dir, f".{default_name}.secret")
    if os.path.exists(sec_file):
        try:
            with open(sec_file, "rb") as f:
                data = f.read().strip()
                if data:
                    return data
        except Exception:
            pass
    new_sec = secrets.token_hex(32).encode("utf-8")
    try:
        with open(sec_file, "wb") as f:
            f.write(new_sec)
    except Exception:
        pass
    return new_sec

AUDITOR_SECRET = _load_or_create_secret("DUAL_KEY_AUDITOR_SECRET", "dual_key_auditor")
OPERATOR_SECRET = _load_or_create_secret("DUAL_KEY_OPERATOR_SECRET", "dual_key_operator")
_REDEEMED_KEYS: set = set()
_REDEEMED_KEYS_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results", ".redeemed_keys.json"
)

def _load_redeemed_keys() -> set:
    keys = set()
    if os.path.exists(_REDEEMED_KEYS_FILE):
        try:
            with open(_REDEEMED_KEYS_FILE, "r", encoding="utf-8") as f:
                keys.update(json.load(f))
        except Exception:
            pass
    return keys

def _record_redeemed_keys(keys_to_add: List[str]) -> None:
    current = _load_redeemed_keys()
    current.update(keys_to_add)
    try:
        os.makedirs(os.path.dirname(_REDEEMED_KEYS_FILE), exist_ok=True)
        with open(_REDEEMED_KEYS_FILE, "w", encoding="utf-8") as f:
            json.dump(list(current), f)
    except Exception:
        pass

DEFAULT_KEY_TTL = 900.0  # 15 minutes


def _compute_code_hash(code_str: str) -> str:
    """Computes deterministic SHA-256 hash of code content."""
    return hashlib.sha256(code_str.encode("utf-8")).hexdigest()


def generate_auditor_key(
    proposal_id: str,
    original_code: str,
    fixed_code: str,
    error_line: Optional[int] = None,
    ttl: float = DEFAULT_KEY_TTL
) -> Tuple[bool, Optional[str], Dict[str, Any]]:
    """
    Key A: Safety Auditor Agent Key.
    Executes an independent security audit across:
    1. Static Scanner (security_analyzer.scan_gate)
    2. Code Guard & AST Blast Radius (security.code_guard)
    3. Honeypot & Canary leak detection (security.canary)

    Returns:
        (is_granted: bool, key_a_token: Optional[str], audit_report: dict)
    """
    audit_report: Dict[str, Any] = {
        "proposal_id": proposal_id,
        "static_scan_passed": False,
        "blast_radius_passed": False,
        "canary_passed": False,
        "findings": []
    }

    # 1. Static Security Scan
    try:
        import security_analyzer
        scan_res = security_analyzer.scan_gate(fixed_code)
        if not scan_res.get("allowed", True):
            audit_report["findings"].append(f"Static scanner violation: {scan_res.get('message')}")
            return False, None, audit_report
        audit_report["static_scan_passed"] = True
    except Exception as e:
        audit_report["findings"].append(f"Static scanner error: {e}")
        return False, None, audit_report

    # 2. Code Guard & AST Blast-Radius Locality Check
    try:
        from security import code_guard
        guard_res = code_guard.inspect_healed_code(original_code, fixed_code, error_line=error_line)
        if not guard_res.get("allowed", True):
            for ev in guard_res.get("evidence", []):
                audit_report["findings"].append(f"Code guard rejection: {ev}")
            return False, None, audit_report
        audit_report["blast_radius_passed"] = True
    except Exception as e:
        audit_report["findings"].append(f"Code guard error: {e}")
        return False, None, audit_report

    # 3. Canary Honeypot Check
    try:
        from security import canary
        leak = canary.detect_canary_leak(fixed_code)
        if leak:
            audit_report["findings"].append(f"Canary honeypot breach detected: {leak.get('detail')}")
            return False, None, audit_report
        audit_report["canary_passed"] = True
    except Exception:
        pass

    # All safety audits passed: Mint Key A
    code_hash = _compute_code_hash(fixed_code)
    now = time.time()
    expires_at = now + ttl

    payload = f"KEY_A:{proposal_id}:{code_hash}:{int(expires_at)}"
    sig = hmac.new(AUDITOR_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    key_a = f"{payload}:{sig}"

    audit_report["key_a"] = key_a
    audit_report["expires_at"] = expires_at
    return True, key_a, audit_report


def generate_operator_key(
    proposal_id: str,
    fixed_code: str,
    operator_id: str = "human_operator",
    ttl: float = DEFAULT_KEY_TTL
) -> str:
    """
    Key B: Human Operator Authorization Key.
    Mints an authorized operator token affirming human review.
    """
    code_hash = _compute_code_hash(fixed_code)
    now = time.time()
    expires_at = now + ttl

    payload = f"KEY_B:{proposal_id}:{code_hash}:{operator_id}:{int(expires_at)}"
    sig = hmac.new(OPERATOR_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload}:{sig}"


def verify_key_a(key_a: str, proposal_id: str, fixed_code: str) -> Tuple[bool, str]:
    """Cryptographically verifies Key A (Safety Auditor Key)."""
    if not isinstance(key_a, str) or not key_a.startswith("KEY_A:"):
        return False, "Invalid Key A format."

    parts = key_a.split(":")
    if len(parts) != 5:
        return False, "Malformed Key A structure."

    _, k_prop_id, k_code_hash, k_expires_str, k_sig = parts
    if k_prop_id != proposal_id:
        return False, f"Key A proposal mismatch: key targets {k_prop_id}, expected {proposal_id}."

    expected_code_hash = _compute_code_hash(fixed_code)
    if k_code_hash != expected_code_hash:
        return False, "Key A code hash mismatch: fixed code content has been altered."

    try:
        expires_at = float(k_expires_str)
        if time.time() > expires_at:
            return False, "Key A (Safety Auditor Key) has expired."
    except ValueError:
        return False, "Invalid timestamp in Key A."

    payload = f"KEY_A:{k_prop_id}:{k_code_hash}:{k_expires_str}"
    expected_sig = hmac.new(AUDITOR_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(k_sig, expected_sig):
        return False, "Key A cryptographic signature verification failed (forged or tampered key)."

    return True, "Key A (Safety Auditor Key) is valid and authentic."


def verify_key_b(key_b: str, proposal_id: str, fixed_code: str) -> Tuple[bool, str]:
    """Cryptographically verifies Key B (Operator Key)."""
    if not isinstance(key_b, str) or not key_b.startswith("KEY_B:"):
        return False, "Invalid Key B format."

    parts = key_b.split(":")
    if len(parts) != 6:
        return False, "Malformed Key B structure."

    _, k_prop_id, k_code_hash, k_op_id, k_expires_str, k_sig = parts
    if k_prop_id != proposal_id:
        return False, f"Key B proposal mismatch: key targets {k_prop_id}, expected {proposal_id}."

    expected_code_hash = _compute_code_hash(fixed_code)
    if k_code_hash != expected_code_hash:
        return False, "Key B code hash mismatch: fixed code content has been altered."

    try:
        expires_at = float(k_expires_str)
        if time.time() > expires_at:
            return False, "Key B (Operator Key) has expired."
    except ValueError:
        return False, "Invalid timestamp in Key B."

    payload = f"KEY_B:{k_prop_id}:{k_code_hash}:{k_op_id}:{k_expires_str}"
    expected_sig = hmac.new(OPERATOR_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(k_sig, expected_sig):
        return False, "Key B cryptographic signature verification failed (forged or tampered key)."

    return True, f"Key B (Operator Key for '{k_op_id}') is valid and authentic."


def verify_dual_key_authorization(
    proposal_id: str,
    fixed_code: str,
    key_a: str,
    key_b: str,
    log_audit: bool = True
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    """
    Enforces the Banking Four-Eyes Rule:
    Requires BOTH Key A and Key B to turn simultaneously.
    If either is missing, invalid, or mismatched, authorization is refused.

    Returns:
        (is_authorized: bool, message: str, clearance_voucher: Optional[dict])
    """
    # 0. Check replay prevention (in-memory + persistent cache)
    redeemed = _REDEEMED_KEYS | _load_redeemed_keys()
    if key_a in redeemed or key_b in redeemed:
        if log_audit:
            _log_refusal(proposal_id, "KEY_REPLAY_ATTEMPT", "Key has already been redeemed.")
        return False, "Dual-Key Refused: One or both authorization keys have already been redeemed (replay prevented).", None

    # 1. Verify Key A (Auditor)
    ok_a, msg_a = verify_key_a(key_a, proposal_id, fixed_code)
    if not ok_a:
        if log_audit:
            _log_refusal(proposal_id, "KEY_A_INVALID", msg_a)
        return False, f"Dual-Key Refused: {msg_a}", None

    # 2. Verify Key B (Operator)
    ok_b, msg_b = verify_key_b(key_b, proposal_id, fixed_code)
    if not ok_b:
        if log_audit:
            _log_refusal(proposal_id, "KEY_B_INVALID", msg_b)
        return False, f"Dual-Key Refused: {msg_b}", None

    # 3. Mint Clearance Voucher
    now = time.time()
    voucher_nonce = secrets.token_hex(16)
    code_hash = _compute_code_hash(fixed_code)

    _REDEEMED_KEYS.add(key_a)
    _REDEEMED_KEYS.add(key_b)
    _record_redeemed_keys([key_a, key_b])

    clearance_voucher = {
        "status": "DUAL_KEY_AUTHORIZED",
        "proposal_id": proposal_id,
        "code_hash": code_hash,
        "voucher_nonce": voucher_nonce,
        "issued_at": now,
        "key_a_summary": "Safety Auditor Attestation Valid",
        "key_b_summary": msg_b
    }

    if log_audit:
        try:
            from security import audit_log
            audit_log.log_event(
                channel="dual_key_vault",
                decision="ALLOW",
                risk_score=0,
                action_attempted=f"dual_key_clearance:{proposal_id}",
                category="DUAL_KEY_AUTHORIZATION",
                evidence=[voucher_nonce, code_hash]
            )
        except Exception:
            pass

    return True, "Dual-Key Clearance Granted: Both Safety Auditor and Human Operator keys validated.", clearance_voucher


def _log_refusal(proposal_id: str, violation_type: str, reason: str) -> None:
    """Logs failed dual-key authorization attempts to the audit ledger."""
    try:
        from security import audit_log
        audit_log.log_event(
            channel="dual_key_vault",
            decision="BLOCK",
            risk_score=80,
            action_attempted=f"dual_key_refusal:{proposal_id}",
            category="DUAL_KEY_VIOLATION",
            evidence=[violation_type, reason]
        )
    except Exception:
        pass
