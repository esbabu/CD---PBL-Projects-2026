"""security/audit_log.py - Cryptographic Append-Only Audit Log.

Maintains an immutable, hash-chained ledger in results/security_log.jsonl.
Each entry records:
- timestamp
- attack_id (if simulated, else None)
- channel (input, tool, healed_code, output)
- category (AT-xx, or security category)
- risk_score
- decision (ALLOW, WARN, BLOCK, REDACT)
- evidence (redacted)
- action_attempted
- prev_hash
- hash: SHA-256(prev_hash + canonical_json(entry_payload))

Integrity verification:
- verify_log(log_path) recomputes the hash chain line-by-line and detects
  any edited, deleted, or inserted lines.
"""

import datetime
import hashlib
import json
import os
import threading
from typing import Any, Dict, List, Optional, Tuple

_ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_RESULTS_DIR = os.path.join(_ROOT_DIR, "results")
_LOG_PATH = os.path.join(_RESULTS_DIR, "security_log.jsonl")

GENESIS_HASH = "0" * 64
import time

_LOG_LOCK = threading.Lock()


class _CrossProcessLock:
    """Atomic cross-process file lock preventing multi-worker hash chain desynchronization."""
    def __init__(self, lock_path: str, timeout: float = 5.0):
        self.lock_path = lock_path
        self.timeout = timeout
        self.fd = None

    def __enter__(self):
        start = time.time()
        while time.time() - start < self.timeout:
            try:
                self.fd = os.open(self.lock_path, os.O_CREAT | os.O_EXCL | os.O_RDWR)
                return self
            except FileExistsError:
                try:
                    if time.time() - os.path.getmtime(self.lock_path) > 10.0:
                        try:
                            os.remove(self.lock_path)
                            continue
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.01)
        if self.fd is None:
            raise TimeoutError(f"Cross-process audit lock acquisition timed out after {self.timeout}s: {self.lock_path}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.fd is not None:
            try:
                os.close(self.fd)
            except Exception:
                pass
            self.fd = None
            try:
                if os.path.exists(self.lock_path):
                    os.remove(self.lock_path)
            except Exception:
                pass


def _canonical_json(data: Dict[str, Any]) -> str:
    """Format dictionary into canonical deterministic JSON without whitespace."""
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _compute_entry_hash(prev_hash: str, payload: Dict[str, Any]) -> str:
    """Computes SHA-256 of prev_hash concatenated with canonical json of entry payload."""
    serialized = _canonical_json(payload)
    to_hash = (prev_hash + serialized).encode("utf-8")
    return hashlib.sha256(to_hash).hexdigest()


def get_last_hash(log_path: Optional[str] = None) -> str:
    """Reads the last hash in the audit log, or GENESIS_HASH if empty/missing."""
    p = log_path or _LOG_PATH
    if not os.path.exists(p):
        return GENESIS_HASH

    last_line = ""
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    last_line = line
    except Exception:
        return GENESIS_HASH

    if not last_line:
        return GENESIS_HASH

    try:
        entry = json.loads(last_line)
        return entry.get("hash", GENESIS_HASH)
    except Exception:
        return GENESIS_HASH


def log_event(
    channel: str,
    decision: str,
    risk_score: int,
    action_attempted: str,
    category: Optional[str] = None,
    attack_id: Optional[str] = None,
    evidence: Optional[Any] = None,
    log_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Appends a new hash-chained security event to the audit log.
    Thread-safe and append-only.
    """
    p = log_path or _LOG_PATH
    os.makedirs(os.path.dirname(p), exist_ok=True)

    from security.output_guard import redact_output

    # Ensure evidence is redacted
    redacted_evidence = []
    if isinstance(evidence, list):
        for item in evidence:
            r_str, _ = redact_output(str(item))
            redacted_evidence.append(r_str)
    elif evidence:
        r_str, _ = redact_output(str(evidence))
        redacted_evidence = [r_str]

    # Timestamp in ISO format UTC
    now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()

    lock_file = p + ".lock"
    with _LOG_LOCK, _CrossProcessLock(lock_file):
        prev_hash = get_last_hash(p)

        payload = {
            "timestamp": now_iso,
            "attack_id": attack_id,
            "channel": channel,
            "category": category or "GENERIC",
            "risk_score": int(risk_score),
            "decision": decision,
            "evidence": redacted_evidence,
            "action_attempted": str(action_attempted),
            "prev_hash": prev_hash
        }

        entry_hash = _compute_entry_hash(prev_hash, payload)

        full_entry = dict(payload)
        full_entry["hash"] = entry_hash

        line_json = _canonical_json(full_entry)
        with open(p, "a", encoding="utf-8") as f:
            f.write(line_json + "\n")

    return full_entry


def verify_log(log_path: Optional[str] = None) -> Tuple[bool, Optional[int], Optional[str]]:
    """
    Verifies cryptographic hash chain integrity of the audit log.

    Returns:
        (is_valid: bool, tampered_line: Optional[int], reason: Optional[str])
    """
    p = log_path or _LOG_PATH
    if not os.path.exists(p):
        return True, None, "Log file does not exist (empty valid state)."

    expected_prev = GENESIS_HASH

    with open(p, "r", encoding="utf-8") as f:
        lines = f.readlines()

    if not lines:
        return True, None, "Log file is empty (valid)."

    for idx, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line:
            continue

        try:
            entry = json.loads(line)
        except json.JSONDecodeError as e:
            return False, idx, f"JSON decode error at line {idx}: {e}"

        if "hash" not in entry or "prev_hash" not in entry:
            return False, idx, f"Missing hash or prev_hash at line {idx}"

        entry_hash = entry["hash"]
        actual_prev = entry["prev_hash"]

        if actual_prev != expected_prev:
            return False, idx, f"Hash chain broken at line {idx}: prev_hash {actual_prev[:12]} != expected {expected_prev[:12]}"

        # Recompute entry payload hash
        payload = {k: v for k, v in entry.items() if k != "hash"}
        recomputed_hash = _compute_entry_hash(actual_prev, payload)

        if recomputed_hash != entry_hash:
            return False, idx, f"Tampered entry at line {idx}: recomputed hash {recomputed_hash[:12]} != recorded hash {entry_hash[:12]}"

        expected_prev = entry_hash

    return True, None, f"Audit log verified cleanly across {len(lines)} entries."


def compute_merkle_root(log_path: Optional[str] = None) -> Tuple[str, int]:
    """
    Computes the Merkle Tree root hash of all entries in the audit log.
    If the log is empty or nonexistent, returns (GENESIS_HASH, 0).

    Returns:
        (merkle_root_hex: str, total_leaves: int)
    """
    p = log_path or _LOG_PATH
    if not os.path.exists(p):
        return GENESIS_HASH, 0

    hashes: List[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if "hash" in entry:
                    hashes.append(entry["hash"])
            except Exception:
                continue

    if not hashes:
        return GENESIS_HASH, 0

    total_leaves = len(hashes)
    current_level = hashes

    while len(current_level) > 1:
        next_level = []
        for i in range(0, len(current_level), 2):
            left = current_level[i]
            right = current_level[i + 1] if i + 1 < len(current_level) else left
            combined = hashlib.sha256((left + right).encode("utf-8")).hexdigest()
            next_level.append(combined)
        current_level = next_level

    return current_level[0], total_leaves


def generate_merkle_proof(entry_index: int, log_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Generates an O(log N) Merkle audit proof for the entry at `entry_index` (0-based).
    Returns proof path, leaf_hash, and expected root.
    """
    p = log_path or _LOG_PATH
    if not os.path.exists(p):
        raise FileNotFoundError(f"Audit log not found: {p}")

    leaves: List[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entry = json.loads(line)
                    if "hash" in entry:
                        leaves.append(entry["hash"])
                except Exception:
                    pass

    if not leaves:
        raise ValueError("Audit log is empty.")

    if entry_index < 0 or entry_index >= len(leaves):
        raise IndexError(f"Leaf index {entry_index} out of range [0, {len(leaves) - 1}]")

    target_hash = leaves[entry_index]
    proof: List[Dict[str, str]] = []

    current_idx = entry_index
    current_level = leaves

    while len(current_level) > 1:
        next_level = []
        is_right = (current_idx % 2 == 1)
        sibling_idx = current_idx - 1 if is_right else current_idx + 1

        if sibling_idx < len(current_level):
            sibling_hash = current_level[sibling_idx]
        else:
            sibling_hash = current_level[current_idx]

        proof.append({
            "position": "left" if is_right else "right",
            "hash": sibling_hash
        })

        for i in range(0, len(current_level), 2):
            l = current_level[i]
            r = current_level[i + 1] if i + 1 < len(current_level) else l
            combined = hashlib.sha256((l + r).encode("utf-8")).hexdigest()
            next_level.append(combined)

        current_idx //= 2
        current_level = next_level

    return {
        "entry_index": entry_index,
        "leaf_hash": target_hash,
        "proof": proof,
        "merkle_root": current_level[0],
        "total_entries": len(leaves)
    }


def verify_merkle_proof(leaf_hash: str, proof: List[Dict[str, str]], expected_root: str) -> bool:
    """
    Verifies a Merkle proof path against the expected root hash.
    """
    current_hash = leaf_hash
    for step in proof:
        pos = step.get("position", "right")
        sibling = step.get("hash", "")
        if pos == "left":
            combined = (sibling + current_hash).encode("utf-8")
        else:
            combined = (current_hash + sibling).encode("utf-8")
        current_hash = hashlib.sha256(combined).hexdigest()

    return current_hash == expected_root


def log_canary_event(
    canary_type: str,
    token_detail: str,
    action: str = "Attempted unauthorized access to honeypot trap",
    evidence: Optional[Any] = None,
    log_path: Optional[str] = None
) -> Dict[str, Any]:
    """Convenience helper to record canary honeypot tripwire breaches in the ledger."""
    return log_event(
        channel="canary_trap",
        decision="BLOCK",
        risk_score=100,
        action_attempted=f"{canary_type}: {action}",
        category="CANARY_TRIPWIRE",
        evidence=[token_detail, str(evidence or "")],
        log_path=log_path
    )

