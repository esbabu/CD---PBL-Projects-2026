"""security/policy_loader.py – Policy loader and integrity verification for IntelliFix.

Design Constraints:
1. Pure utility functions only: NO import-time side effects (no files created, no network calls, no subprocesses).
2. Schema validation with informative, human-readable error messages on failure.
3. Cryptographic integrity checking against security/policy.sha256.

Note on Threat Model:
Storing an integrity hash in an adjacent file (security/policy.sha256) protects against
accidental modification, inadvertent developer edits, and naive tool modifications.
It does NOT prevent a root/admin-level attacker who can simultaneously modify both files.
As a best-effort defense-in-depth measure on Windows workstations, the file may be marked
read-only via 'attrib +R'.
"""

import hashlib
import json
import os
from typing import Any, Dict, Optional, Tuple

_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_DEFAULT_POLICY_PATH = os.path.join(_CURRENT_DIR, "policy.json")
_DEFAULT_HASH_PATH = os.path.join(_CURRENT_DIR, "policy.sha256")

_REQUIRED_POLICY_KEYS = ["policy_version", "created_date", "description", "rules", "risk"]
_REQUIRED_RULE_FIELDS = ["id", "action", "description"]
_VALID_ACTIONS = {"deny", "require_approval"}


class PolicyValidationError(ValueError):
    """Raised when the security policy file is missing required fields or has an invalid schema."""
    pass


def policy_hash(policy_path: Optional[str] = None) -> str:
    """Calculates the SHA-256 hexadecimal digest of the raw policy file contents."""
    path = policy_path or _DEFAULT_POLICY_PATH
    if not os.path.exists(path):
        raise FileNotFoundError(f"Policy file not found: {path}")
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def load_policy(policy_path: Optional[str] = None) -> Dict[str, Any]:
    """Loads and validates the machine-readable security policy file.

    Returns:
        dict: The validated policy configuration dictionary.

    Raises:
        FileNotFoundError: If the policy file does not exist.
        PolicyValidationError: If the policy fails JSON parsing or schema validation.
    """
    path = policy_path or _DEFAULT_POLICY_PATH
    if not os.path.exists(path):
        raise FileNotFoundError(f"Policy file does not exist at {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise PolicyValidationError(f"Policy file contains invalid JSON: {e}") from e

    if not isinstance(data, dict):
        raise PolicyValidationError("Policy root element must be a JSON object (dictionary)")

    # 1. Validate top-level keys
    for req_key in _REQUIRED_POLICY_KEYS:
        if req_key not in data:
            raise PolicyValidationError(f"Missing required policy root key: '{req_key}'")

    if not isinstance(data["rules"], dict):
        raise PolicyValidationError("'rules' key in policy must be a dictionary of named rules")

    if len(data["rules"]) == 0:
        raise PolicyValidationError("'rules' dictionary cannot be empty")

    # 2. Validate individual rule definitions
    for rule_name, rule_def in data["rules"].items():
        if not isinstance(rule_def, dict):
            raise PolicyValidationError(f"Rule '{rule_name}' must be an object")
        for fld in _REQUIRED_RULE_FIELDS:
            if fld not in rule_def:
                raise PolicyValidationError(f"Rule '{rule_name}' is missing required field '{fld}'")
        action = rule_def.get("action")
        if action not in _VALID_ACTIONS:
            raise PolicyValidationError(
                f"Rule '{rule_name}' has invalid action '{action}'. Valid actions: {_VALID_ACTIONS}"
            )

    # 3. Validate risk section
    risk_sec = data["risk"]
    if not isinstance(risk_sec, dict):
        raise PolicyValidationError("'risk' section must be a dictionary")
    if "thresholds" not in risk_sec or not isinstance(risk_sec["thresholds"], dict):
        raise PolicyValidationError("'risk.thresholds' must be a dictionary")
    if "weights" not in risk_sec or not isinstance(risk_sec["weights"], dict):
        raise PolicyValidationError("'risk.weights' must be a dictionary")

    return data


def verify_integrity(
    expected_hash: Optional[str] = None,
    policy_path: Optional[str] = None
) -> Tuple[bool, str]:
    """Verifies that the policy file matches its expected SHA-256 hash.

    Args:
        expected_hash: Optional expected SHA-256 string. If None, reads from security/policy.sha256.
        policy_path: Optional path to the policy file.

    Returns:
        (bool, str): (True, "Integrity verified") on match, or (False, failure_reason).
    """
    path = policy_path or _DEFAULT_POLICY_PATH
    if not os.path.exists(path):
        return False, f"Policy file not found: {path}"

    if expected_hash is None:
        hash_file = os.path.join(os.path.dirname(path), "policy.sha256")
        if not os.path.exists(hash_file):
            return False, f"Integrity hash file not found: {hash_file}"
        try:
            with open(hash_file, "r", encoding="utf-8") as f:
                expected_hash = f.read().strip()
        except Exception as e:
            return False, f"Could not read hash file: {e}"

    expected_hash = expected_hash.strip().lower()

    try:
        current_hash = policy_hash(path).strip().lower()
    except Exception as e:
        return False, f"Error hashing policy file: {e}"

    if current_hash != expected_hash:
        return False, f"Hash mismatch: computed {current_hash} != expected {expected_hash}"

    return True, f"Integrity verified (SHA-256: {current_hash})"
