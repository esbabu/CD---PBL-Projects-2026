"""security/output_guard.py - Leak Prevention & Sensitive Data Redaction.

Redacts fake secrets and personal-data patterns from agent outputs, logs,
and user-facing messages:
- API keys (Gemini, Groq, AWS, OpenAI, fake keys)
- Email addresses
- Phone numbers
- Credit card numbers / SSNs
- Canary tokens and values from lab_data/fake_personal_info.txt
"""

import os
import re
from typing import Any, Dict, List, Optional, Tuple

_CANARY_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "lab_data",
    "fake_personal_info.txt"
)

# Core redaction patterns
REDACTION_RULES = [
    # API Keys
    ("GEMINI_KEY", re.compile(r"AIza[A-Za-z0-9_\-]{20,}"), "[REDACTED_GEMINI_KEY]"),
    ("GROQ_KEY", re.compile(r"gsk_[A-Za-z0-9]{20,}"), "[REDACTED_GROQ_KEY]"),
    ("AWS_KEY", re.compile(r"AKIA[0-9A-Z]{16}"), "[REDACTED_AWS_KEY]"),
    ("GENERIC_API_KEY", re.compile(r"sk-[A-Za-z0-9_\-]{20,}"), "[REDACTED_API_KEY]"),
    ("FAKE_CANARY_KEY", re.compile(r"FAKE-KEY-[A-Za-z0-9_\-]+"), "[REDACTED_API_KEY]"),
    # Credit Card Numbers (16 digits separated by dashes or spaces)
    ("CREDIT_CARD", re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"), "[REDACTED_CARD]"),
    # US Social Security Numbers
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[REDACTED_SSN]"),
    # Phone numbers
    ("PHONE", re.compile(r"\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"), "[REDACTED_PHONE]"),
    # Email addresses
    ("EMAIL", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"), "[REDACTED_EMAIL]"),
    # Canary markers
    ("CANARY_MARKER", re.compile(r"CANARY_RECORD_(?:START|END)"), "[REDACTED_CANARY_MARKER]"),
]


def _get_canary_literals() -> List[Tuple[str, str]]:
    """Dynamically read literal secrets from canary file for exact matching."""
    literals: List[Tuple[str, str]] = []
    if os.path.exists(_CANARY_FILE):
        try:
            with open(_CANARY_FILE, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("CANARY_RECORD"):
                        continue
                    if ":" in line:
                        k, v = line.split(":", 1)
                        val = v.strip()
                        if len(val) >= 4:
                            literals.append((val, f"[REDACTED_{k.strip().upper()}]"))
        except Exception:
            pass
    return literals


def redact_output(text: Any) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Scans text for sensitive patterns and canary data, replacing them with redaction tokens.

    Returns:
        (redacted_text: str, redacted_items: List[Dict[str, Any]])
    """
    if not isinstance(text, str):
        text = str(text)

    redacted = text
    redacted_items: List[Dict[str, Any]] = []

    # 1. Regex-based pattern redaction
    for label, pattern, replacement in REDACTION_RULES:
        for match in pattern.finditer(redacted):
            matched_val = match.group(0)
            redacted_items.append({
                "type": label,
                "matched": matched_val[:4] + "..." if len(matched_val) > 8 else "[REDACTED]",
                "replacement": replacement
            })
        redacted = pattern.sub(replacement, redacted)

    # 2. Canary literal exact redaction
    for val, replacement in _get_canary_literals():
        if val in redacted:
            redacted_items.append({
                "type": "CANARY_DATA",
                "matched": val[:4] + "...",
                "replacement": replacement
            })
            redacted = redacted.replace(val, replacement)

    return redacted, redacted_items


def sanitize_dict(data: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Recursively redacts sensitive patterns in a dictionary."""
    sanitized: Dict[str, Any] = {}
    all_redacted: List[Dict[str, Any]] = []

    for k, v in data.items():
        if isinstance(v, str):
            r_val, items = redact_output(v)
            sanitized[k] = r_val
            all_redacted.extend(items)
        elif isinstance(v, dict):
            s_dict, items = sanitize_dict(v)
            sanitized[k] = s_dict
            all_redacted.extend(items)
        elif isinstance(v, list):
            s_list = []
            for item in v:
                if isinstance(item, str):
                    r_item, items = redact_output(item)
                    s_list.append(r_item)
                    all_redacted.extend(items)
                elif isinstance(item, dict):
                    s_item, items = sanitize_dict(item)
                    s_list.append(s_item)
                    all_redacted.extend(items)
                else:
                    s_list.append(item)
            sanitized[k] = s_list
        else:
            sanitized[k] = v

    return sanitized, all_redacted
