"""security/make_manifest.py - Generates Authoritative Cryptographic Shield Manifest.

Scans security/*.py and security/policy.json, computing SHA-256 digests
and writing security/shield_manifest.json.
"""

import hashlib
import json
import os
import sys

_SECURITY_DIR = os.path.dirname(os.path.abspath(__file__))
_MANIFEST_PATH = os.path.join(_SECURITY_DIR, "shield_manifest.json")

TRACKED_FILES = [
    "policy.json",
    "policy_engine.py",
    "tool_guard.py",
    "code_guard.py",
    "output_guard.py",
    "shield.py",
    "risk_engine.py",
    "audit_log.py",
    "input_guard.py",
    "policy_loader.py",
    "canary.py",
    "blast_radius.py",
    "dual_key.py"
]


def sha256_file(path: str) -> str:
    """Computes the SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def generate_manifest() -> str:
    """Builds and writes security/shield_manifest.json."""
    manifest_data = {
        "version": "1.0.0",
        "description": "Cryptographic manifest of authoritative IntelliFix Shield components",
        "files": {}
    }

    for filename in TRACKED_FILES:
        full_path = os.path.join(_SECURITY_DIR, filename)
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"Tracked security file not found: {full_path}")
        h = sha256_file(full_path)
        manifest_data["files"][filename] = h

    # Write manifest formatted with indentation for readability
    with open(_MANIFEST_PATH, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f, indent=2, sort_keys=True)

    print(f"Shield manifest generated at: {_MANIFEST_PATH}")
    for k, v in manifest_data["files"].items():
        print(f"  {k:20} -> {v}")

    return _MANIFEST_PATH


if __name__ == "__main__":
    generate_manifest()
