"""security/threat_catalog.py - Formal Taxonomy of AI, Agent, Compiler, Sandbox, Backend, Data/Privacy, Supply Chain, Patch/Transformation, UI, Monitoring/Observability, and Architectural/Advanced Vulnerabilities.

Provides authoritative definitions and mitigation mappings for 99 threats across 11 pillars:
1. AI Vulnerabilities (AI-01 through AI-10)
2. Agent Vulnerabilities (AG-01 through AG-10)
3. Compiler & Code Vulnerabilities (CC-01 through CC-10)
4. Sandbox Vulnerabilities (SB-01 through SB-10)
5. Backend Vulnerabilities (BE-01 through BE-10)
6. Data & Privacy Vulnerabilities (DP-01 through DP-08)
7. Supply Chain Vulnerabilities (SC-01 through SC-07)
8. Patch & Transformation Vulnerabilities (PT-01 through PT-10)
9. User Interface Vulnerabilities (UI-01 through UI-06)
10. Monitoring & Observability Vulnerabilities (MO-01 through MO-08)
11. Architectural & Advanced Vulnerabilities (AD-01 through AD-10)
"""

from typing import Any, Dict, List, Optional

AI_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "AI-01": {
        "id": "AI-01",
        "name": "Prompt Injection",
        "description": "Malicious instructions manipulate the AI agent.",
        "risk_level": "CRITICAL",
        "channel": "user_instruction",
        "gate": "Gate 1 (Input Guard)",
        "defense_module": "security.input_guard",
        "mitigation": "Pattern-based risk scoring, policy override detection, fail-closed blocking.",
        "status": "DEFENDED"
    },
    "AI-02": {
        "id": "AI-02",
        "name": "Indirect Prompt Injection",
        "description": "Malicious instructions hidden in source-code comments or docstrings.",
        "risk_level": "CRITICAL",
        "channel": "code_content",
        "gate": "Gate 1 (Input Guard)",
        "defense_module": "security.input_guard",
        "mitigation": "Multi-channel AST extraction isolating raw comments and docstrings for independent scanning.",
        "status": "DEFENDED"
    },
    "AI-03": {
        "id": "AI-03",
        "name": "System Prompt Leakage",
        "description": "Attacker extracts hidden system instructions.",
        "risk_level": "HIGH",
        "channel": "user_instruction / output",
        "gate": "Gate 1 (Input Guard) & Gate 4 (Output Guard)",
        "defense_module": "security.output_guard",
        "mitigation": "Input guard flags prompt extraction queries; output guard redacts leaked system framing.",
        "status": "DEFENDED"
    },
    "AI-04": {
        "id": "AI-04",
        "name": "Jailbreaking",
        "description": "Attacker bypasses the AI's safety restrictions.",
        "risk_level": "HIGH",
        "channel": "user_instruction",
        "gate": "Gate 1 (Input Guard)",
        "defense_module": "security.input_guard",
        "mitigation": "Detection of hypothetical framing, persona roleplay, DAN-style jailbreaks.",
        "status": "DEFENDED"
    },
    "AI-05": {
        "id": "AI-05",
        "name": "Instruction Override",
        "description": "User input overrides trusted developer instructions.",
        "risk_level": "HIGH",
        "channel": "user_instruction",
        "gate": "Gate 1 (Input Guard)",
        "defense_module": "llm_explainer",
        "mitigation": "Immutable system prompt framing, code delimiter sanitization (<<<CODE>>>), and static scan gating.",
        "status": "DEFENDED"
    },
    "AI-06": {
        "id": "AI-06",
        "name": "Context Manipulation",
        "description": "Attacker fills the context window with misleading information.",
        "risk_level": "MEDIUM",
        "channel": "code_content / error_text",
        "gate": "Gate 1 (Input Guard) & Server Perimeter",
        "defense_module": "app.py / error_extractor",
        "mitigation": "Strict payload size caps (200 KB MAX_CONTENT_LENGTH), traceback length bounding, sanitized summaries.",
        "status": "DEFENDED"
    },
    "AI-07": {
        "id": "AI-07",
        "name": "Hallucinated Fixes",
        "description": "AI generates incorrect or unsafe code repairs.",
        "risk_level": "HIGH",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard / sandbox_runner",
        "mitigation": "Pre-execution static AST scan_gate, AST blast radius containment, isolated subprocess sandbox verification.",
        "status": "DEFENDED"
    },
    "AI-08": {
        "id": "AI-08",
        "name": "Model Denial of Service",
        "description": "Huge inputs consume excessive tokens and resources.",
        "risk_level": "HIGH",
        "channel": "user_instruction / code_content",
        "gate": "Server Perimeter & Automata Engines",
        "defense_module": "app.py / automaton_engine / pda_engine",
        "mitigation": "Max payload limits, DFA state limits (256 states), PDA step limits (500 steps), agent timeout (40s).",
        "status": "DEFENDED"
    },
    "AI-09": {
        "id": "AI-09",
        "name": "Training Data Poisoning",
        "description": "Malicious training examples influence model behavior.",
        "risk_level": "MEDIUM",
        "channel": "model_pipeline",
        "gate": "Deterministic Fallback",
        "defense_module": "multi_error / offline_guide",
        "mitigation": "Zero online fine-tuning on user code; deterministic rule-based repair engine fallback independent of LLMs.",
        "status": "DEFENDED"
    },
    "AI-10": {
        "id": "AI-10",
        "name": "Output Manipulation",
        "description": "Attacker forces the AI to generate malicious code.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard) & Gate 4 (Output Guard)",
        "defense_module": "security.code_guard / security_analyzer",
        "mitigation": "AST taint analysis, AST module allowlists (rejects sockets, os.system), credential entropy redaction.",
        "status": "DEFENDED"
    }
}

AGENT_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "AG-01": {
        "id": "AG-01",
        "name": "Unauthorized Tool Invocation",
        "description": "Agent executes tools without permission.",
        "risk_level": "CRITICAL",
        "channel": "tool",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "security.tool_guard",
        "mitigation": "Strict immutable allowlist of exactly 4 tools (run_code, scan_security, read_file, apply_patch).",
        "status": "DEFENDED"
    },
    "AG-02": {
        "id": "AG-02",
        "name": "Tool Argument Injection",
        "description": "Malicious arguments manipulate tool execution.",
        "risk_level": "HIGH",
        "channel": "tool",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "agent_tools / security.tool_guard",
        "mitigation": "Strict argument schema validation, type checks, forbidden parameter detection (skip_scan, force).",
        "status": "DEFENDED"
    },
    "AG-03": {
        "id": "AG-03",
        "name": "Privilege Escalation",
        "description": "Agent gains permissions beyond its intended role.",
        "risk_level": "CRITICAL",
        "channel": "tool / execution",
        "gate": "Gate 2 & Sandbox Runner",
        "defense_module": "sandbox_runner / security.policy_engine",
        "mitigation": "Subprocess execution with dropped privileges, environment scrubbing, read-only policy engine.",
        "status": "DEFENDED"
    },
    "AG-04": {
        "id": "AG-04",
        "name": "Unauthorized File Access",
        "description": "Agent reads files outside the project workspace.",
        "risk_level": "HIGH",
        "channel": "tool (read_file) / api",
        "gate": "Gate 2 (Tool Guard) & Server Perimeter",
        "defense_module": "security.tool_guard / app.py",
        "mitigation": "Path confinement within WORKSPACE_ROOT, rejection of '..', ADS colons, absolute paths, symlinks, and device names.",
        "status": "DEFENDED"
    },
    "AG-05": {
        "id": "AG-05",
        "name": "Unauthorized File Modification",
        "description": "Agent modifies important system files.",
        "risk_level": "CRITICAL",
        "channel": "tool (apply_patch) / write",
        "gate": "Gate 2 (Tool Guard) & Proposal Engine",
        "defense_module": "agent_proposals / app.py / intellifix.py",
        "mitigation": "In-memory proposal only (never writes to disk directly), target enforced to _fixed.py, PROTECTED_FILES blacklist.",
        "status": "DEFENDED"
    },
    "AG-06": {
        "id": "AG-06",
        "name": "Agent Loop Exploitation",
        "description": "Agent gets stuck in repeated execution loops.",
        "risk_level": "MEDIUM",
        "channel": "agent_execution",
        "gate": "Orchestrator Controls",
        "defense_module": "agent.py / agent_memory.py",
        "mitigation": "Hard attempt clamping (1..5), wall-clock budget (40s AGENT_MAX_SECONDS), step log cap (200 steps), state deduplication.",
        "status": "DEFENDED"
    },
    "AG-07": {
        "id": "AG-07",
        "name": "Memory Poisoning",
        "description": "Malicious information gets stored in agent memory.",
        "risk_level": "HIGH",
        "channel": "agent_memory",
        "gate": "Memory Bounds & Redaction",
        "defense_module": "agent_memory.py / agent.py",
        "mitigation": "Bounded memory buffers, code body redaction from step logs, API key sanitization (_sanitize_summary).",
        "status": "DEFENDED"
    },
    "AG-08": {
        "id": "AG-08",
        "name": "Approval Bypass",
        "description": "Agent performs dangerous actions without human approval.",
        "risk_level": "CRITICAL",
        "channel": "tool (apply_patch)",
        "gate": "Gate 2 (Dual-Key Vault)",
        "defense_module": "security.dual_key",
        "mitigation": "Banking 'Four-Eyes Principle' requiring concurrent Key A (Safety Auditor) and Key B (Human Operator) HMAC-SHA256 signatures.",
        "status": "DEFENDED"
    },
    "AG-09": {
        "id": "AG-09",
        "name": "Goal Hijacking",
        "description": "Attacker redirects the agent away from its original objective.",
        "risk_level": "HIGH",
        "channel": "user_instruction",
        "gate": "Gate 1 (Input Guard) & Agent Prompt",
        "defense_module": "agent.py / security.input_guard",
        "mitigation": "Hardcoded immutable objective ('diagnose and repair compiler errors'), instruction post-filtering, refusal of off-task goals.",
        "status": "DEFENDED"
    },
    "AG-10": {
        "id": "AG-10",
        "name": "Multi-step Attack Chaining",
        "description": "Several harmless-looking actions combine into a dangerous action.",
        "risk_level": "CRITICAL",
        "channel": "workflow",
        "gate": "Multi-Gate Orchestrator & Audit Chain",
        "defense_module": "security.shield / security.audit_log",
        "mitigation": "Pre-execution scanning at every tool transition, hash-chained tamper-evident logging, mandatory human approval before disk commit.",
        "status": "DEFENDED"
    }
}

COMPILER_CODE_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "CC-01": {
        "id": "CC-01",
        "name": "Malicious Code Injection",
        "description": "Harmful code gets introduced during repair.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard / security_analyzer",
        "mitigation": "Static AST scan gating inspecting every proposed patch for malicious payloads prior to disk commit.",
        "status": "DEFENDED"
    },
    "CC-02": {
        "id": "CC-02",
        "name": "Code Comment Injection",
        "description": "Hidden instructions inside comments manipulate the AI.",
        "risk_level": "CRITICAL",
        "channel": "code_content",
        "gate": "Gate 1 (Input Guard)",
        "defense_module": "security.input_guard",
        "mitigation": "Channel-isolated comment and docstring AST extraction running targeted adversarial regex scanners.",
        "status": "DEFENDED"
    },
    "CC-03": {
        "id": "CC-03",
        "name": "Parser Exploitation",
        "description": "Crafted syntax crashes or confuses the parser.",
        "risk_level": "HIGH",
        "channel": "code_content",
        "gate": "Parsing & Grammar Engine",
        "defense_module": "automaton_engine / pda_engine / safe_ast",
        "mitigation": "Safe parsing boundaries with recursion depth limits, error-recovery states, and fail-closed syntax validators.",
        "status": "DEFENDED"
    },
    "CC-04": {
        "id": "CC-04",
        "name": "Lexer/Tokenizer Exploitation",
        "description": "Special character sequences trigger unexpected behavior.",
        "risk_level": "HIGH",
        "channel": "code_content",
        "gate": "Lexer & Tokenizer Engine",
        "defense_module": "tokenizer.py / dfa.py",
        "mitigation": "Strict alphabet verification, Unicode NFKC normalization, homoglyph detection, and null-byte rejection.",
        "status": "DEFENDED"
    },
    "CC-05": {
        "id": "CC-05",
        "name": "Malicious Dependency Injection",
        "description": "Unsafe packages enter the repaired project.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "AST Import visitor allowlisting standard math/utility libraries while strictly blocking untrusted package imports.",
        "status": "DEFENDED"
    },
    "CC-06": {
        "id": "CC-06",
        "name": "Arbitrary Code Execution",
        "description": "Compiled or repaired code executes unintended commands.",
        "risk_level": "CRITICAL",
        "channel": "healed_code / execution",
        "gate": "Gate 3 (Code Guard) & Sandbox Runner",
        "defense_module": "security.code_guard / sandbox_runner",
        "mitigation": "AST blocks execution primitives (eval, exec, __import__); runner executes non-interactive subprocesses without shell.",
        "status": "DEFENDED"
    },
    "CC-07": {
        "id": "CC-07",
        "name": "Path Traversal",
        "description": "Code accesses files outside the permitted directory.",
        "risk_level": "HIGH",
        "channel": "tool / filename / healed_code",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "security.tool_guard / app.py",
        "mitigation": "Canonical root path resolution, rejection of '..', colons, leading slashes, and Windows Alternate Data Streams.",
        "status": "DEFENDED"
    },
    "CC-08": {
        "id": "CC-08",
        "name": "Insecure Deserialization",
        "description": "Malicious serialized input triggers unsafe behavior.",
        "risk_level": "HIGH",
        "channel": "code_content / healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "AST node visitor bans pickle, marshal, shelve, and yaml.load; enforces schema-validated JSON deserialization.",
        "status": "DEFENDED"
    },
    "CC-09": {
        "id": "CC-09",
        "name": "Unsafe Auto-correction",
        "description": "Fixes introduce vulnerabilities into previously safe code.",
        "risk_level": "HIGH",
        "channel": "healed_code",
        "gate": "Gate 3 (AST Blast Radius)",
        "defense_module": "security.code_guard / agent_proposals",
        "mitigation": "Strict Blast Radius containment bounding line/byte expansion, isolated diff verification, and mandatory human sign-off.",
        "status": "DEFENDED"
    },
    "CC-10": {
        "id": "CC-10",
        "name": "Syntax/AST Manipulation",
        "description": "Malformed structures bypass validation or produce unsafe transformations.",
        "risk_level": "HIGH",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard / safe_ast",
        "mitigation": "Double-pass AST validation compiling and round-trip verifying AST nodes prior to code emit.",
        "status": "DEFENDED"
    }
}

SANDBOX_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "SB-01": {
        "id": "SB-01",
        "name": "Sandbox Escape",
        "description": "Malicious code escapes the execution environment.",
        "risk_level": "CRITICAL",
        "channel": "execution",
        "gate": "Sandbox Runner & OS Isolation",
        "defense_module": "sandbox_runner / win_job",
        "mitigation": "Windows Job Objects containment, restricted token execution, no administrative privileges, audit hooks.",
        "status": "DEFENDED"
    },
    "SB-02": {
        "id": "SB-02",
        "name": "Command Injection",
        "description": "Attacker executes unauthorized shell commands.",
        "risk_level": "CRITICAL",
        "channel": "execution / healed_code",
        "gate": "Gate 3 (Code Guard) & Sandbox Runner",
        "defense_module": "security.code_guard / sandbox_runner",
        "mitigation": "AST blocks shell invocation calls (os.system, subprocess.Popen); execution runner enforces shell=False and array args.",
        "status": "DEFENDED"
    },
    "SB-03": {
        "id": "SB-03",
        "name": "File System Escape",
        "description": "Program accesses host files.",
        "risk_level": "CRITICAL",
        "channel": "execution / tool",
        "gate": "Gate 2 & Sandbox Runner",
        "defense_module": "security.tool_guard / sandbox_runner",
        "mitigation": "Strict ephemeral working directory jail, path canonicalization, and rejection of absolute host drives (C:\\, /etc).",
        "status": "DEFENDED"
    },
    "SB-04": {
        "id": "SB-04",
        "name": "Network Access Abuse",
        "description": "Program communicates with external servers.",
        "risk_level": "CRITICAL",
        "channel": "execution / healed_code",
        "gate": "Gate 3 (Code Guard) & Sandbox Runner",
        "defense_module": "security.code_guard / sandbox_runner",
        "mitigation": "AST import blocking for socket, urllib, requests; Python audit hook trapping socket connect events.",
        "status": "DEFENDED"
    },
    "SB-05": {
        "id": "SB-05",
        "name": "Resource Exhaustion",
        "description": "Infinite loops consume CPU or memory.",
        "risk_level": "HIGH",
        "channel": "execution",
        "gate": "Sandbox Runner & OS Isolation",
        "defense_module": "sandbox_runner / win_job",
        "mitigation": "Windows Job Object hard memory limit (512 MB), CPU rate limits, strict 5.0-second execution wall-clock timeout.",
        "status": "DEFENDED"
    },
    "SB-06": {
        "id": "SB-06",
        "name": "Fork Bomb",
        "description": "Program creates excessive processes.",
        "risk_level": "CRITICAL",
        "channel": "execution",
        "gate": "Sandbox Runner & OS Isolation",
        "defense_module": "sandbox_runner / win_job",
        "mitigation": "Windows Job Object active process cap (JOB_OBJECT_LIMIT_ACTIVE_PROCESS), blocking process proliferation.",
        "status": "DEFENDED"
    },
    "SB-07": {
        "id": "SB-07",
        "name": "Environment Variable Leakage",
        "description": "Secrets are exposed through environment variables.",
        "risk_level": "HIGH",
        "channel": "execution / output",
        "gate": "Sandbox Runner & Gate 4 (Output Guard)",
        "defense_module": "sandbox_runner / security.output_guard",
        "mitigation": "Subprocess environment scrubbing stripping API keys and secrets; Output Guard Shannon entropy redacting live tokens.",
        "status": "DEFENDED"
    },
    "SB-08": {
        "id": "SB-08",
        "name": "Temporary File Abuse",
        "description": "Malicious files interfere with other executions.",
        "risk_level": "HIGH",
        "channel": "execution",
        "gate": "Sandbox Runner",
        "defense_module": "sandbox_runner",
        "mitigation": "Randomized ephemeral execution directories (mkdtemp) isolated per run with deterministic cleanup in finally blocks.",
        "status": "DEFENDED"
    },
    "SB-09": {
        "id": "SB-09",
        "name": "Process Isolation Failure",
        "description": "One execution affects another execution.",
        "risk_level": "HIGH",
        "channel": "execution",
        "gate": "Sandbox Runner",
        "defense_module": "sandbox_runner",
        "mitigation": "Clean independent OS child process per execution with dedicated memory space and zero shared mutable state.",
        "status": "DEFENDED"
    },
    "SB-10": {
        "id": "SB-10",
        "name": "Timeout Bypass",
        "description": "Malicious code avoids or overwhelms execution limits.",
        "risk_level": "HIGH",
        "channel": "execution",
        "gate": "Sandbox Runner & OS Isolation",
        "defense_module": "sandbox_runner / win_job",
        "mitigation": "Asynchronous OS-level process.kill() and TerminateJobObject forcing termination regardless of Python signal masking.",
        "status": "DEFENDED"
    }
}

BACKEND_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "BE-01": {
        "id": "BE-01",
        "name": "SQL Injection",
        "description": "Attacker manipulates database queries.",
        "risk_level": "CRITICAL",
        "channel": "api / database",
        "gate": "Server Perimeter & AST Guard",
        "defense_module": "app.py / security.code_guard",
        "mitigation": "No raw SQL string interpolation; parameterized ORM/SQLite queries enforced and AST blocks raw sqlite3 concatenation.",
        "status": "DEFENDED"
    },
    "BE-02": {
        "id": "BE-02",
        "name": "API Authentication Bypass",
        "description": "Unauthorized users access protected APIs.",
        "risk_level": "CRITICAL",
        "channel": "api",
        "gate": "Gate 2 (Dual-Key Vault)",
        "defense_module": "security.dual_key / app.py",
        "mitigation": "Four-Eyes Dual-Key HMAC-SHA256 signature validation and token-gated API endpoints.",
        "status": "DEFENDED"
    },
    "BE-03": {
        "id": "BE-03",
        "name": "Broken Access Control",
        "description": "Users access another user's projects.",
        "risk_level": "HIGH",
        "channel": "api / workspace",
        "gate": "Gate 2 (Tool Guard) & Server Perimeter",
        "defense_module": "app.py / agent_proposals",
        "mitigation": "Per-session workspace isolation, path validation strictly scoping operations to authorized directory trees.",
        "status": "DEFENDED"
    },
    "BE-04": {
        "id": "BE-04",
        "name": "API Key Exposure",
        "description": "Gemini/OpenAI API keys get leaked.",
        "risk_level": "CRITICAL",
        "channel": "output / environment",
        "gate": "Gate 4 (Output Guard) & Subprocess Jail",
        "defense_module": "security.output_guard / sandbox_runner",
        "mitigation": "Shannon entropy scanner, automated regex redaction of live key signatures, and subprocess env scrubbing.",
        "status": "DEFENDED"
    },
    "BE-05": {
        "id": "BE-05",
        "name": "Rate Limit Bypass",
        "description": "Attacker sends excessive API requests.",
        "risk_level": "HIGH",
        "channel": "api",
        "gate": "Server Perimeter",
        "defense_module": "app.py",
        "mitigation": "IP/session-scoped rate limiting, payload byte caps (200 KB MAX_CONTENT_LENGTH), and wall-clock execution quotas.",
        "status": "DEFENDED"
    },
    "BE-06": {
        "id": "BE-06",
        "name": "Server-Side Request Forgery (SSRF)",
        "description": "Server is tricked into accessing internal resources.",
        "risk_level": "CRITICAL",
        "channel": "tool / network",
        "gate": "Gate 2 (Tool Guard) & Sandbox Runner",
        "defense_module": "security.tool_guard / sandbox_runner",
        "mitigation": "Zero outbound networking tools in closed whitelist; Python audit hooks block socket connections to 127.0.0.1 and metadata IPs.",
        "status": "DEFENDED"
    },
    "BE-07": {
        "id": "BE-07",
        "name": "CORS Misconfiguration",
        "description": "Unauthorized websites interact with APIs.",
        "risk_level": "MEDIUM",
        "channel": "api / headers",
        "gate": "Server Perimeter",
        "defense_module": "app.py",
        "mitigation": "Strict Same-Origin headers, Cache-Control: no-store, and rejection of unauthorized cross-origin mutation requests.",
        "status": "DEFENDED"
    },
    "BE-08": {
        "id": "BE-08",
        "name": "Insecure File Upload",
        "description": "Malicious files are uploaded and processed.",
        "risk_level": "HIGH",
        "channel": "upload / api",
        "gate": "Server Perimeter & Gate 2",
        "defense_module": "app.py / security.tool_guard",
        "mitigation": "validate_workspace_filename() blocks hidden files, executables, traversal paths, and oversized files (>200 KB).",
        "status": "DEFENDED"
    },
    "BE-09": {
        "id": "BE-09",
        "name": "Request Tampering",
        "description": "Attacker modifies API parameters or payloads.",
        "risk_level": "HIGH",
        "channel": "api",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "security.tool_guard / agent_proposals",
        "mitigation": "Strict JSON schema validation, parameter lockdown (forbidding skip_scan, force), and HMAC integrity checks.",
        "status": "DEFENDED"
    },
    "BE-10": {
        "id": "BE-10",
        "name": "Sensitive Error Leakage",
        "description": "Stack traces reveal internal implementation details.",
        "risk_level": "MEDIUM",
        "channel": "output / error_text",
        "gate": "Gate 4 (Output Guard)",
        "defense_module": "security.output_guard / error_extractor",
        "mitigation": "Exception sanitization stripping server file paths, internal modules, and raw tracebacks from client responses.",
        "status": "DEFENDED"
    }
}

DATA_PRIVACY_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "DP-01": {
        "id": "DP-01",
        "name": "Source Code Leakage",
        "description": "Private source code is exposed.",
        "risk_level": "CRITICAL",
        "channel": "output / telemetry",
        "gate": "Gate 4 & Local Architecture",
        "defense_module": "security.output_guard / app.py",
        "mitigation": "Local-first execution model, zero third-party telemetry, and path isolation preventing source exfiltration.",
        "status": "DEFENDED"
    },
    "DP-02": {
        "id": "DP-02",
        "name": "API Secret Leakage",
        "description": "Credentials appear in logs or AI responses.",
        "risk_level": "CRITICAL",
        "channel": "output / logs",
        "gate": "Gate 4 (Output Guard) & Audit Ledger",
        "defense_module": "security.output_guard / security.audit_log",
        "mitigation": "High-entropy token redaction in Gate 4 sink and pre-write secret scrubbing in audit logging routines.",
        "status": "DEFENDED"
    },
    "DP-03": {
        "id": "DP-03",
        "name": "Conversation Leakage",
        "description": "One user's AI conversation becomes accessible to another.",
        "risk_level": "HIGH",
        "channel": "agent_memory / api",
        "gate": "Session Boundary",
        "defense_module": "agent.py / app.py",
        "mitigation": "Ephemeral session memory; conversations are not persisted across user boundaries or global caches.",
        "status": "DEFENDED"
    },
    "DP-04": {
        "id": "DP-04",
        "name": "Insecure Memory Storage",
        "description": "Sensitive information is stored without protection.",
        "risk_level": "HIGH",
        "channel": "agent_memory",
        "gate": "Memory Management",
        "defense_module": "agent_memory.py / agent_proposals",
        "mitigation": "In-memory proposal tokens are cryptographically randomized; raw secret keys are scrubbed from memory buffers.",
        "status": "DEFENDED"
    },
    "DP-05": {
        "id": "DP-05",
        "name": "Log Injection",
        "description": "Malicious input manipulates application logs.",
        "risk_level": "HIGH",
        "channel": "logs",
        "gate": "Audit Ledger Integrity",
        "defense_module": "security.audit_log",
        "mitigation": "Strict newline and escape character sanitization, structured JSON Lines format, and SHA-256 hash chaining.",
        "status": "DEFENDED"
    },
    "DP-06": {
        "id": "DP-06",
        "name": "Data Exfiltration",
        "description": "Agent sends private data to external destinations.",
        "risk_level": "CRITICAL",
        "channel": "tool / network",
        "gate": "Gate 2 & Gate 3 & Sandbox",
        "defense_module": "security.code_guard / sandbox_runner",
        "mitigation": "AST blocks socket and network libraries; sandbox audit hook aborts external connection attempts.",
        "status": "DEFENDED"
    },
    "DP-07": {
        "id": "DP-07",
        "name": "Insecure Data Retention",
        "description": "Source code and credentials remain stored unnecessarily.",
        "risk_level": "MEDIUM",
        "channel": "disk / temp_files",
        "gate": "Ephemeral Workspace",
        "defense_module": "sandbox_runner / app.py",
        "mitigation": "Deterministic cleanup of temporary files in finally blocks; ephemeral proposal store with TTL expiration.",
        "status": "DEFENDED"
    },
    "DP-08": {
        "id": "DP-08",
        "name": "Cross-User Data Contamination",
        "description": "One user's code or context influences another user's session.",
        "risk_level": "HIGH",
        "channel": "session / execution",
        "gate": "Process & Context Isolation",
        "defense_module": "sandbox_runner / agent.py",
        "mitigation": "Independent OS subprocesses per execution with fresh virtual memory address space and zero cross-request contamination.",
        "status": "DEFENDED"
    }
}

SUPPLY_CHAIN_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "SC-01": {
        "id": "SC-01",
        "name": "Typosquatting",
        "description": "Attacker introduces a malicious package with a similar name.",
        "risk_level": "CRITICAL",
        "channel": "healed_code / imports",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "AST Import visitor restricts imports to standard built-in libraries; unknown or typosquatted external packages are blocked.",
        "status": "DEFENDED"
    },
    "SC-02": {
        "id": "SC-02",
        "name": "Dependency Confusion",
        "description": "A malicious package replaces an intended dependency.",
        "risk_level": "CRITICAL",
        "channel": "environment / imports",
        "gate": "Gate 3 & Sandbox",
        "defense_module": "security.code_guard / sandbox_runner",
        "mitigation": "Zero external package repository resolution; execution environment runs in hermetic offline sandbox without pip.",
        "status": "DEFENDED"
    },
    "SC-03": {
        "id": "SC-03",
        "name": "Vulnerable Dependencies",
        "description": "Outdated libraries contain known security flaws.",
        "risk_level": "HIGH",
        "channel": "environment",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "Minimal attack surface using Python standard library primitives; bans legacy/vulnerable modules.",
        "status": "DEFENDED"
    },
    "SC-04": {
        "id": "SC-04",
        "name": "Malicious Package Installation",
        "description": "Agent installs an unsafe package.",
        "risk_level": "CRITICAL",
        "channel": "tool",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "security.tool_guard",
        "mitigation": "No package installer tools (pip, npm, easy_install) exist in the closed 4-tool whitelist.",
        "status": "DEFENDED"
    },
    "SC-05": {
        "id": "SC-05",
        "name": "Compromised Build Tools",
        "description": "Compiler tools or plugins are compromised.",
        "risk_level": "CRITICAL",
        "channel": "build_pipeline",
        "gate": "Cryptographic Manifest",
        "defense_module": "security.policy_engine",
        "mitigation": "SHA-256 cryptographic manifest verification (shield_manifest.json) ensuring compiler tools and policies remain untampered.",
        "status": "DEFENDED"
    },
    "SC-06": {
        "id": "SC-06",
        "name": "Unverified Model Downloads",
        "description": "Malicious or tampered models are loaded.",
        "risk_level": "HIGH",
        "channel": "model_pipeline",
        "gate": "Deterministic Fallback",
        "defense_module": "automaton_engine / offline_guide",
        "mitigation": "Local deterministic DFA/PDA repair rules requiring zero model weight downloads; official TLS-pinned APIs only.",
        "status": "DEFENDED"
    },
    "SC-07": {
        "id": "SC-07",
        "name": "Dependency Version Manipulation",
        "description": "Attacker changes package versions to introduce unsafe code.",
        "risk_level": "HIGH",
        "channel": "workspace / files",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "agent_proposals / app.py",
        "mitigation": "PROTECTED_FILES blacklist forbids proposals modifying requirements.txt, setup.py, pyproject.toml, or lockfiles.",
        "status": "DEFENDED"
    }
}

PATCH_TRANSFORMATION_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "PT-01": {
        "id": "PT-01",
        "name": "Insecure Code Generation",
        "description": "AI generates code containing security flaws.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "Pre-commit static AST scan gate inspecting every proposed patch for security vulnerabilities.",
        "status": "DEFENDED"
    },
    "PT-02": {
        "id": "PT-02",
        "name": "Security Regression",
        "description": "A repair introduces a new vulnerability.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (Differential AST)",
        "defense_module": "security.code_guard / security_analyzer",
        "mitigation": "Differential AST security comparison ensuring repaired code contains strictly fewer or equal flaws than original.",
        "status": "DEFENDED"
    },
    "PT-03": {
        "id": "PT-03",
        "name": "Incomplete Repair",
        "description": "AI fixes the syntax but not the underlying problem.",
        "risk_level": "HIGH",
        "channel": "healed_code / execution",
        "gate": "Sandbox Runner & Test Suite",
        "defense_module": "sandbox_runner / automata_validator",
        "mitigation": "Multi-stage verification: bytecode compilation, execution in isolated sandbox, and automated test pass confirmation.",
        "status": "DEFENDED"
    },
    "PT-04": {
        "id": "PT-04",
        "name": "Logic Manipulation",
        "description": "AI changes the intended program behavior.",
        "risk_level": "HIGH",
        "channel": "healed_code",
        "gate": "Gate 3 (AST Semantic Delta)",
        "defense_module": "security.blast_radius",
        "mitigation": "Semantic delta verification preserving function interfaces, signature invariants, and surrounding control flow.",
        "status": "DEFENDED"
    },
    "PT-05": {
        "id": "PT-05",
        "name": "Hidden Backdoor Injection",
        "description": "AI inserts malicious functionality into repaired code.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "AST visitor checks for covert imports, listener sockets, hidden subprocess calls, and dynamic execution traps.",
        "status": "DEFENDED"
    },
    "PT-06": {
        "id": "PT-06",
        "name": "Validation Bypass",
        "description": "AI removes security checks to make code execute.",
        "risk_level": "CRITICAL",
        "channel": "healed_code",
        "gate": "Gate 3 (AST Validation Preserver)",
        "defense_module": "security.blast_radius / security.code_guard",
        "mitigation": "AST Diff analyzer checks that existing assert statements, input validation blocks, and error handling nodes are not stripped.",
        "status": "DEFENDED"
    },
    "PT-07": {
        "id": "PT-07",
        "name": "Patch Scope Violation",
        "description": "AI modifies unrelated files or code sections.",
        "risk_level": "HIGH",
        "channel": "healed_code",
        "gate": "Gate 3 (AST Blast Radius)",
        "defense_module": "security.blast_radius",
        "mitigation": "Strict line/byte growth bounds; patches restricted to localized syntax error node spans.",
        "status": "DEFENDED"
    },
    "PT-08": {
        "id": "PT-08",
        "name": "Unsafe Exception Handling",
        "description": "AI suppresses errors instead of properly fixing them.",
        "risk_level": "HIGH",
        "channel": "healed_code",
        "gate": "Gate 3 (Code Guard)",
        "defense_module": "security.code_guard",
        "mitigation": "AST scanner flags and blocks bare 'except:' or 'except Exception: pass' error-masking anti-patterns.",
        "status": "DEFENDED"
    },
    "PT-09": {
        "id": "PT-09",
        "name": "Regression Test Manipulation",
        "description": "AI modifies tests to make an incorrect fix appear successful.",
        "risk_level": "CRITICAL",
        "channel": "tool (apply_patch)",
        "gate": "Gate 2 (Tool Guard)",
        "defense_module": "agent_proposals / app.py",
        "mitigation": "PROTECTED_FILES policy freezes test files (tests_*.py, test_*.py) as immutable; agent proposals on tests are rejected.",
        "status": "DEFENDED"
    },
    "PT-10": {
        "id": "PT-10",
        "name": "Repair Chain Poisoning",
        "description": "One malicious repair influences subsequent repairs.",
        "risk_level": "CRITICAL",
        "channel": "workflow",
        "gate": "Multi-Gate Pipeline & Ephemeral State",
        "defense_module": "agent_memory / agent.py",
        "mitigation": "Proposals remain staged in memory without disk commits; state resets per repair cycle with SHA-256 integrity validation.",
        "status": "DEFENDED"
    }
}

UI_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "UI-01": {
        "id": "UI-01",
        "name": "Cross-Site Scripting (XSS)",
        "description": "Malicious output executes in the browser.",
        "risk_level": "CRITICAL",
        "channel": "ui / output",
        "gate": "UI DOM Isolation & CSP",
        "defense_module": "templates/index.html / app.py",
        "mitigation": "Strict textContent and createElement DOM bindings; zero innerHTML with untrusted strings; Content Security Policy.",
        "status": "DEFENDED"
    },
    "UI-02": {
        "id": "UI-02",
        "name": "HTML Injection",
        "description": "Malicious HTML is rendered in the interface.",
        "risk_level": "HIGH",
        "channel": "ui / output",
        "gate": "Entity Encoding & Text Nodes",
        "defense_module": "templates/index.html",
        "mitigation": "Dynamic table renderers use document.createTextNode and escape HTML entities (<, >, &) before rendering.",
        "status": "DEFENDED"
    },
    "UI-03": {
        "id": "UI-03",
        "name": "Cross-Site Request Forgery (CSRF)",
        "description": "User is tricked into performing unintended actions.",
        "risk_level": "HIGH",
        "channel": "ui / api",
        "gate": "SameSite Cookies & Dual-Key",
        "defense_module": "app.py / security.dual_key",
        "mitigation": "SameSite=Strict cookie policy, custom X-Requested-With verification, and HMAC-signed approval tokens for mutation actions.",
        "status": "DEFENDED"
    },
    "UI-04": {
        "id": "UI-04",
        "name": "Client-Side Validation Bypass",
        "description": "Attacker bypasses frontend restrictions.",
        "risk_level": "HIGH",
        "channel": "ui / api",
        "gate": "Server-Side Full Gate Verification",
        "defense_module": "app.py / security.shield",
        "mitigation": "Server re-evaluates all 4 shield gates on every request; zero client-side validation assumptions.",
        "status": "DEFENDED"
    },
    "UI-05": {
        "id": "UI-05",
        "name": "Sensitive Information Exposure",
        "description": "Secrets appear in browser responses or developer tools.",
        "risk_level": "CRITICAL",
        "channel": "output / ui",
        "gate": "Gate 4 (Output Guard)",
        "defense_module": "security.output_guard",
        "mitigation": "Shannon entropy scanner redacts API keys, passwords, and private tokens prior to JSON transmission.",
        "status": "DEFENDED"
    },
    "UI-06": {
        "id": "UI-06",
        "name": "DOM Manipulation",
        "description": "Malicious content changes application behavior.",
        "risk_level": "MEDIUM",
        "channel": "ui / frontend",
        "gate": "Safe DOM Binding & Scoped State",
        "defense_module": "templates/index.html",
        "mitigation": "Immutable event handlers bound via closures; sandboxed DOM tree updates preventing prototype pollution.",
        "status": "DEFENDED"
    }
}

MONITORING_OBSERVABILITY_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "MO-01": {
        "id": "MO-01",
        "name": "Audit Log Tampering",
        "description": "Attacker modifies or deletes attack records.",
        "risk_level": "CRITICAL",
        "channel": "logs",
        "gate": "Cryptographic Ledger & Hash Chain",
        "defense_module": "security.audit_log",
        "mitigation": "Append-only SHA-256 hash-chained JSON Lines ledger; verification utility detects any retrofitted line edits.",
        "status": "DEFENDED"
    },
    "MO-02": {
        "id": "MO-02",
        "name": "Detection Evasion",
        "description": "Malicious instructions bypass the detection engine.",
        "risk_level": "CRITICAL",
        "channel": "user_instruction / code_content",
        "gate": "Multi-Channel Input Guard",
        "defense_module": "security.input_guard",
        "mitigation": "Multi-channel parsing (prompt, comments, docstrings, error text) with Unicode NFKC normalization and homoglyph resolution.",
        "status": "DEFENDED"
    },
    "MO-03": {
        "id": "MO-03",
        "name": "False Negative",
        "description": "Attack is not detected.",
        "risk_level": "HIGH",
        "channel": "all_channels",
        "gate": "Multi-Gate Defense-in-Depth",
        "defense_module": "security.shield",
        "mitigation": "Defense-in-depth: if an attack evades Gate 1, Gate 2 (Tool Guard), Gate 3 (Code Guard), or Gate 4 (Output Guard) catches it.",
        "status": "DEFENDED"
    },
    "MO-04": {
        "id": "MO-04",
        "name": "False Positive",
        "description": "Benign input is incorrectly classified as malicious.",
        "risk_level": "MEDIUM",
        "channel": "all_channels",
        "gate": "Negation Rules & Calibrated Thresholds",
        "defense_module": "security.input_guard / eval_security",
        "mitigation": "Contextual negation parsing (e.g. 'verify_not_dangerous') and empirical calibration (0.00% FPR on benchmark suite).",
        "status": "DEFENDED"
    },
    "MO-05": {
        "id": "MO-05",
        "name": "Risk Score Manipulation",
        "description": "Attacker manipulates risk-scoring signals.",
        "risk_level": "HIGH",
        "channel": "risk_scoring",
        "gate": "Server-Side Frozen Rule Scoring",
        "defense_module": "security.input_guard / security.policy_engine",
        "mitigation": "Scoring logic is purely server-side with frozen policy weights cryptographically verified in shield_manifest.json.",
        "status": "DEFENDED"
    },
    "MO-06": {
        "id": "MO-06",
        "name": "Alert Suppression",
        "description": "Security alerts are prevented from reaching administrators.",
        "risk_level": "CRITICAL",
        "channel": "alerts",
        "gate": "Fail-Closed Audit Hook & Exception Trap",
        "defense_module": "security.audit_log / app.py",
        "mitigation": "Audit log writes are mandatory and synchronous; log write failures trigger immediate fail-closed system halts.",
        "status": "DEFENDED"
    },
    "MO-07": {
        "id": "MO-07",
        "name": "Incomplete Attack Logging",
        "description": "Security events are not recorded properly.",
        "risk_level": "HIGH",
        "channel": "logs",
        "gate": "Synchronous Audit Event Hooks",
        "defense_module": "security.audit_log",
        "mitigation": "Universal audit hook invoked across all 4 gates recording timestamp, channel, category, score, and hash.",
        "status": "DEFENDED"
    },
    "MO-08": {
        "id": "MO-08",
        "name": "Metric Manipulation",
        "description": "Attack detection results are artificially inflated.",
        "risk_level": "MEDIUM",
        "channel": "metrics",
        "gate": "Ground-Truth Cryptographic Ledger",
        "defense_module": "eval_security / app.py",
        "mitigation": "Metrics calculated directly from verifiable audit logs and reproducible test harnesses with Wilson Score confidence intervals.",
        "status": "DEFENDED"
    }
}

ARCHITECTURAL_ADVANCED_VULNERABILITIES: Dict[str, Dict[str, Any]] = {
    "AD-01": {
        "id": "AD-01",
        "name": "Time-of-Check to Time-of-Use (TOCTOU)",
        "description": "File changes between security validation and execution.",
        "risk_level": "CRITICAL",
        "channel": "filesystem",
        "gate": "Atomic Proposals & Pre-Commit Rescan",
        "defense_module": "agent_proposals / security_analyzer",
        "mitigation": "In-memory atomic staging; patches undergo full Gate 3 AST re-scan immediately prior to disk commit.",
        "status": "DEFENDED"
    },
    "AD-02": {
        "id": "AD-02",
        "name": "Race Conditions",
        "description": "Simultaneous agent operations cause unexpected behavior.",
        "risk_level": "HIGH",
        "channel": "concurrency",
        "gate": "Thread Locks & Single-Use Tokens",
        "defense_module": "agent_proposals / app.py",
        "mitigation": "Single-use cryptographically random proposal tokens invalidated immediately upon first approval.",
        "status": "DEFENDED"
    },
    "AD-03": {
        "id": "AD-03",
        "name": "Unicode Homoglyph Attacks",
        "description": "Visually similar characters hide malicious instructions.",
        "risk_level": "HIGH",
        "channel": "user_instruction / code",
        "gate": "Unicode NFKC & Homoglyph Normalizer",
        "defense_module": "security.input_guard / tokenizer.py",
        "mitigation": "Unicode NFKC normalization and Cyrillic/Greek homoglyph canonicalization before regex or tokenizer parsing.",
        "status": "DEFENDED"
    },
    "AD-04": {
        "id": "AD-04",
        "name": "Polyglot File Attacks",
        "description": "A file behaves differently across parsers or interpreters.",
        "risk_level": "HIGH",
        "channel": "parsing",
        "gate": "Strict Python AST Parser & Schema Check",
        "defense_module": "security.code_guard / safe_ast",
        "mitigation": "Strict single-grammar Python AST compiler validation, rejecting polyglot HTML/JS/Python hybrid formats.",
        "status": "DEFENDED"
    },
    "AD-05": {
        "id": "AD-05",
        "name": "Side-Channel Leakage",
        "description": "Timing or resource usage reveals sensitive information.",
        "risk_level": "MEDIUM",
        "channel": "crypto / timing",
        "gate": "Constant-Time HMAC & Bounded Errors",
        "defense_module": "security.dual_key / app.py",
        "mitigation": "hmac.compare_digest for all signature comparisons; standardized error responses preventing timing side channels.",
        "status": "DEFENDED"
    },
    "AD-06": {
        "id": "AD-06",
        "name": "Denial of Service (DoS)",
        "description": "Attacker makes the compiler unavailable.",
        "risk_level": "HIGH",
        "channel": "execution",
        "gate": "Hard Quotas, Timeouts & State Caps",
        "defense_module": "sandbox_runner / automaton_engine",
        "mitigation": "Hard execution ceiling (5.0s sandbox, 40s agent loop), DFA state bounds (256), and PDA step limits (500).",
        "status": "DEFENDED"
    },
    "AD-07": {
        "id": "AD-07",
        "name": "Distributed Denial of Service (DDoS)",
        "description": "Multiple sources overwhelm the service.",
        "risk_level": "HIGH",
        "channel": "network / api",
        "gate": "Perimeter Rate Limiting & Size Caps",
        "defense_module": "app.py",
        "mitigation": "Request size bounds (200 KB MAX_CONTENT_LENGTH), connection rate limiting, and early fail-fast syntax screening.",
        "status": "DEFENDED"
    },
    "AD-08": {
        "id": "AD-08",
        "name": "Policy Confusion",
        "description": "Different security components interpret the same action differently.",
        "risk_level": "HIGH",
        "channel": "policy",
        "gate": "Centralized Policy Engine & Manifest Hash",
        "defense_module": "security.policy_engine",
        "mitigation": "Single authoritative policy file (security/policy.json) verified via SHA-256 manifest hash across all 4 gates.",
        "status": "DEFENDED"
    },
    "AD-09": {
        "id": "AD-09",
        "name": "Trust Boundary Confusion",
        "description": "Untrusted data is mistakenly treated as trusted instructions.",
        "risk_level": "CRITICAL",
        "channel": "input_channels",
        "gate": "Strict Multi-Channel Isolation",
        "defense_module": "security.input_guard / llm_explainer",
        "mitigation": "Strict multi-channel segregation: user instructions, code comments, error text, and system framing are strictly partitioned.",
        "status": "DEFENDED"
    },
    "AD-10": {
        "id": "AD-10",
        "name": "Security Control Desynchronization",
        "description": "Agent, backend, and execution engine apply inconsistent policies.",
        "risk_level": "CRITICAL",
        "channel": "architecture",
        "gate": "Unified Multi-Gate Orchestrator",
        "defense_module": "security.shield",
        "mitigation": "Unified security shield orchestrator (security/shield.py) synchronizes Gate 1, 2, 3, and 4 under a single immutable policy.",
        "status": "DEFENDED"
    }
}


def get_ai_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 AI vulnerabilities."""
    return list(AI_VULNERABILITIES.values())


def get_agent_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 Agent vulnerabilities."""
    return list(AGENT_VULNERABILITIES.values())


def get_compiler_code_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 Compiler & Code vulnerabilities."""
    return list(COMPILER_CODE_VULNERABILITIES.values())


def get_sandbox_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 Sandbox vulnerabilities."""
    return list(SANDBOX_VULNERABILITIES.values())


def get_backend_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 Backend vulnerabilities."""
    return list(BACKEND_VULNERABILITIES.values())


def get_data_privacy_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 8 Data and Privacy vulnerabilities."""
    return list(DATA_PRIVACY_VULNERABILITIES.values())


def get_supply_chain_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 7 Supply Chain vulnerabilities."""
    return list(SUPPLY_CHAIN_VULNERABILITIES.values())


def get_patch_transformation_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 Patch and Transformation vulnerabilities."""
    return list(PATCH_TRANSFORMATION_VULNERABILITIES.values())


def get_ui_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 6 User Interface vulnerabilities."""
    return list(UI_VULNERABILITIES.values())


def get_monitoring_observability_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 8 Monitoring and Observability vulnerabilities."""
    return list(MONITORING_OBSERVABILITY_VULNERABILITIES.values())


def get_architectural_advanced_vulnerabilities() -> List[Dict[str, Any]]:
    """Returns list of all 10 Architectural and Advanced vulnerabilities."""
    return list(ARCHITECTURAL_ADVANCED_VULNERABILITIES.values())


def get_all_threats() -> List[Dict[str, Any]]:
    """Returns combined list of all 99 vulnerabilities across all 11 pillars."""
    return (
        get_ai_vulnerabilities()
        + get_agent_vulnerabilities()
        + get_compiler_code_vulnerabilities()
        + get_sandbox_vulnerabilities()
        + get_backend_vulnerabilities()
        + get_data_privacy_vulnerabilities()
        + get_supply_chain_vulnerabilities()
        + get_patch_transformation_vulnerabilities()
        + get_ui_vulnerabilities()
        + get_monitoring_observability_vulnerabilities()
        + get_architectural_advanced_vulnerabilities()
    )


def get_threat_by_id(threat_id: str) -> Optional[Dict[str, Any]]:
    """Look up threat metadata by ID (e.g. 'AI-01', 'BE-04', 'PT-01', 'AD-01')."""
    clean_id = (threat_id or "").strip().upper()
    all_dicts = [
        AI_VULNERABILITIES,
        AGENT_VULNERABILITIES,
        COMPILER_CODE_VULNERABILITIES,
        SANDBOX_VULNERABILITIES,
        BACKEND_VULNERABILITIES,
        DATA_PRIVACY_VULNERABILITIES,
        SUPPLY_CHAIN_VULNERABILITIES,
        PATCH_TRANSFORMATION_VULNERABILITIES,
        UI_VULNERABILITIES,
        MONITORING_OBSERVABILITY_VULNERABILITIES,
        ARCHITECTURAL_ADVANCED_VULNERABILITIES,
    ]
    for d in all_dicts:
        if clean_id in d:
            return dict(d[clean_id])
    return None


