"""security/tool_guard.py - Pre-Execution Guard for Agent Tool Calls.

Enforces:
1. Tool allow-list confinement (only run_code, scan_security, read_file, apply_patch).
2. Workspace boundary path verification (rejects .., absolute paths, drive letters, symlinks).
3. Human approval requirement for apply_patch execution.
4. Prohibition on disabling or skipping the validation / scanning step.
"""

import os
from typing import Any, Dict, List, Optional, Tuple

ALLOWLISTED_TOOLS = {"run_code", "scan_security", "read_file", "apply_patch"}
WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def is_safe_workspace_path(path_str: str, workspace_root: Optional[str] = None) -> Tuple[bool, str]:
    """
    Validates that a path is strictly confined within the workspace root.
    Rejects:
    - Path traversal sequences ("..", "%2e%2e")
    - Absolute paths, UNC paths, and Windows drive roots (e.g. "C:\\", "\\\\server\\share")
    - Alternate Data Streams (":")
    - Symlinks that resolve outside the workspace root
    """
    if not isinstance(path_str, str):
        return False, "Path argument must be a string."

    ws_root = os.path.realpath(workspace_root or WORKSPACE_ROOT)
    clean_p = path_str.strip()

    if not clean_p:
        return False, "Path argument cannot be empty."

    # Check for traversal indicators
    if ".." in clean_p or "%2e%2e" in clean_p.lower():
        return False, "Path traversal sequence ('..') detected."

    # Check for Alternate Data Streams
    colon_idx = clean_p.find(":")
    if colon_idx != -1:
        if os.name == "nt" and colon_idx == 1 and clean_p[0].isalpha():
            if ":" in clean_p[2:]:
                return False, "Alternate Data Stream delimiter (':') detected."
        else:
            return False, "Alternate Data Stream delimiter (':') detected."

    # Check for drive letter / absolute path attempting to escape
    if os.path.isabs(clean_p):
        real_target = os.path.realpath(clean_p)
        try:
            common = os.path.commonpath([ws_root, real_target])
            if common != ws_root:
                return False, f"Absolute path '{clean_p}' resolves outside workspace root."
        except ValueError:
            return False, f"Path '{clean_p}' on different drive than workspace."
    else:
        # Relative path
        combined = os.path.join(ws_root, clean_p)
        real_target = os.path.realpath(combined)
        try:
            common = os.path.commonpath([ws_root, real_target])
            if common != ws_root:
                return False, f"Path '{clean_p}' escapes workspace boundary."
        except ValueError:
            return False, f"Path '{clean_p}' resolves outside workspace."

    return True, "Path resolves safely within workspace."


def check_tool_call(
    tool_name: str,
    args: Optional[Dict[str, Any]] = None,
    approved: bool = False,
    workspace_root: Optional[str] = None
) -> Dict[str, Any]:
    """
    Evaluates a tool invocation before execution.
    Returns:
        decision dict containing:
        - allowed: bool
        - decision: "ALLOW" or "BLOCK"
        - signals: List[Dict[str, Any]]
        - evidence: List[str]
        - tool_name: str
    """
    signals: List[Dict[str, Any]] = []
    evidence: List[str] = []
    call_args = args or {}

    # 1. Allow-list check
    if tool_name not in ALLOWLISTED_TOOLS:
        signals.append({
            "name": "tool_arg_violation",
            "weight": 50,
            "evidence": f"Unallowlisted tool invocation: '{tool_name}'"
        })
        evidence.append(f"Tool '{tool_name}' is not in allow-list {sorted(list(ALLOWLISTED_TOOLS))}")

    # 2. Check path arguments for confinement
    path_keys = ["filename", "path", "target_file", "file", "dest"]
    for k in path_keys:
        if k in call_args and call_args[k]:
            path_val = str(call_args[k])
            safe, reason = is_safe_workspace_path(path_val, workspace_root=workspace_root)
            if not safe:
                signals.append({
                    "name": "path_outside_workspace",
                    "weight": 40,
                    "evidence": f"Path arg '{k}={path_val}': {reason}"
                })
                evidence.append(reason)

    # 3. Check for apply_patch approval enforcement
    if tool_name == "apply_patch":
        is_staging = bool(call_args.get("staging"))
        # apply_patch requires explicit human approval unless explicitly flagged as staging proposal
        if not approved and not is_staging:
            signals.append({
                "name": "tool_arg_violation",
                "weight": 50,
                "evidence": "apply_patch called without valid human approval token"
            })
            evidence.append("Unapproved apply_patch attempt (approval bypass)")

    # 4. Check for scan bypass flags or parameters
    bypass_keys = [
        "skip_scan", "disable_scan", "bypass_scan", "disable_validation",
        "skip_validation", "force", "force_apply", "override_policy", "trust_mode"
    ]
    for bk in bypass_keys:
        if bk in call_args and call_args[bk]:
            signals.append({
                "name": "policy_override",
                "weight": 40,
                "evidence": f"Attempted scan bypass via parameter '{bk}={call_args[bk]}'"
            })
            evidence.append(f"Validation bypass flag '{bk}' is prohibited")

    # If any string in args mentions 'mark safe' or 'skip validation'
    for k, v in call_args.items():
        if isinstance(v, str):
            v_lower = v.lower()
            if "disable validation" in v_lower or "skip validation" in v_lower or "mark safe" in v_lower:
                signals.append({
                    "name": "verdict_forcing",
                    "weight": 30,
                    "evidence": f"Verdict forcing detected in argument '{k}'"
                })
                evidence.append(f"Argument '{k}' attempted to force safe verdict")

    allowed = len(signals) == 0
    decision = "ALLOW" if allowed else "BLOCK"

    return {
        "allowed": allowed,
        "decision": decision,
        "signals": signals,
        "evidence": evidence,
        "tool_name": tool_name
    }
