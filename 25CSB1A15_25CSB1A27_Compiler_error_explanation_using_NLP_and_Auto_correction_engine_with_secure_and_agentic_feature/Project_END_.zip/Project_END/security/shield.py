"""security/shield.py - Autonomous AI (AAI) Shield.

The single authoritative entry point for multi-gate security enforcement:
- Gate 1: Input Guard (Channels 1-3: user instruction, code content, error text)
- Gate 2: Tool Guard (Pre-execution validation, path confinement, approval checks)
- Gate 3: Code Guard (Healed code AST inspection, taint analysis, diff scope)
- Gate 4: Output Guard & Audit Log (Sensitive data redaction, hash-chained logging)

Design Constraints:
- SHIELD_ENABLED is evaluated lazily via function call (never cached at import time).
  Default True when unset. Bypassed when False (allowing attacks to succeed against baseline).
- Refuses to arm if policy or security file hashes fail integrity check (fails closed safely).
- The agent cannot edit, reconfigure, or disable the Shield.
"""

import os
from typing import Any, Dict, List, Optional, Tuple

from security import audit_log, code_guard, output_guard, policy_engine, risk_engine, tool_guard


def is_shield_enabled() -> bool:
    """
    Lazily evaluate whether the AAI Shield is active in the current process environment.
    Default True when unset. Bypassed only when set to 0, false, no, or off.
    """
    val = os.environ.get("SHIELD_ENABLED")
    if val is None:
        return True
    return val.strip().lower() not in ("0", "false", "no", "off")


class Shield:
    """AAI Shield orchestrator controlling all 4 security gates."""

    def __init__(self):
        self._policy_engine = policy_engine.get_policy_engine()
        self._armed: bool = False
        self._arm_checked: bool = False
        self._arm_error: Optional[str] = None

    def arm(self) -> Tuple[bool, str]:
        """
        Verify security manifest integrity and arm the Shield.
        Scoped to Shield invocation only; never runs at Flask app start.
        """
        ok, msg = self._policy_engine.initialize()
        self._arm_checked = True
        self._armed = ok
        self._arm_error = None if ok else msg
        return self._armed, msg

    def _ensure_armed(self) -> Tuple[bool, Optional[str]]:
        """Ensures the Shield has attempted arming."""
        if not self._arm_checked:
            self.arm()
        return self._armed, self._arm_error

    # =========================================================================
    # GATE 1: Input Inspection
    # =========================================================================
    def inspect_input(
        self,
        text: str,
        channel: str = "user_instruction",
        attack_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Gate 1: Inspects input across channels (user_instruction, code_content, error_text).
        """
        if not is_shield_enabled():
            return {
                "allowed": True,
                "decision": risk_engine.DECISION_ALLOW,
                "score": 0,
                "signals": [],
                "evidence": [],
                "bypassed": True,
                "channel": channel
            }

        armed, arm_err = self._ensure_armed()
        if not armed:
            # Fail closed safely
            audit_log.log_event(
                channel=channel,
                decision=risk_engine.DECISION_BLOCK,
                risk_score=100,
                action_attempted="inspect_input",
                category="SHIELD_UNAVAILABLE",
                attack_id=attack_id,
                evidence=arm_err
            )
            return {
                "allowed": False,
                "decision": risk_engine.DECISION_BLOCK,
                "score": 100,
                "signals": [{"name": "policy_override", "weight": 50, "evidence": arm_err}],
                "evidence": [f"Shield unavailable: {arm_err}"],
                "bypassed": False,
                "channel": channel
            }

        from security import input_guard
        guard_res = input_guard.inspect_text(text, channel=channel)
        signals = guard_res.get("signals", [])

        # Score with risk engine
        risk = risk_engine.compute_risk(signals)
        allowed = (risk["decision"] == risk_engine.DECISION_ALLOW)

        # Log block or warning
        if not allowed or risk["score"] > 0:
            audit_log.log_event(
                channel=channel,
                decision=risk["decision"],
                risk_score=risk["score"],
                action_attempted="input_submission",
                category=guard_res.get("category", "PROMPT_INJECTION"),
                attack_id=attack_id,
                evidence=risk["evidence"]
            )

        return {
            "allowed": allowed,
            "decision": risk["decision"],
            "score": risk["score"],
            "signals": risk["signals"],
            "evidence": risk["evidence"],
            "bypassed": False,
            "channel": channel
        }

    # =========================================================================
    # GATE 2: Tool Guard
    # =========================================================================
    def check_tool(
        self,
        tool_name: str,
        args: Optional[Dict[str, Any]] = None,
        approved: bool = False,
        attack_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Gate 2: Validates tool name, argument confinement, approval token, and scan persistence.
        """
        if not is_shield_enabled():
            return {
                "allowed": True,
                "decision": risk_engine.DECISION_ALLOW,
                "score": 0,
                "signals": [],
                "evidence": [],
                "bypassed": True,
                "tool_name": tool_name
            }

        armed, arm_err = self._ensure_armed()
        if not armed:
            return {
                "allowed": False,
                "decision": risk_engine.DECISION_BLOCK,
                "score": 100,
                "signals": [{"name": "policy_override", "weight": 50, "evidence": arm_err}],
                "evidence": [f"Shield unavailable: {arm_err}"],
                "bypassed": False,
                "tool_name": tool_name
            }

        guard_res = tool_guard.check_tool_call(tool_name, args=args, approved=approved)
        signals = guard_res.get("signals", [])

        risk = risk_engine.compute_risk(signals)
        allowed = (risk["decision"] == risk_engine.DECISION_ALLOW)

        if not allowed or risk["score"] > 0:
            audit_log.log_event(
                channel="tool",
                decision=risk["decision"],
                risk_score=risk["score"],
                action_attempted=f"call_tool:{tool_name}",
                category="TOOL_GUARD_VIOLATION",
                attack_id=attack_id,
                evidence=risk["evidence"]
            )

        return {
            "allowed": allowed,
            "decision": risk["decision"],
            "score": risk["score"],
            "signals": risk["signals"],
            "evidence": risk["evidence"],
            "bypassed": False,
            "tool_name": tool_name
        }

    # =========================================================================
    # GATE 3: Code Guard (Healed Code)
    # =========================================================================
    def inspect_healed_code(
        self,
        original: str,
        fixed: str,
        attack_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Gate 3: Inspects healed code for AST anomalies, taint flow, obfuscation, and over-broad patches.
        """
        if not is_shield_enabled():
            return {
                "allowed": True,
                "decision": risk_engine.DECISION_ALLOW,
                "score": 0,
                "signals": [],
                "evidence": [],
                "bypassed": True
            }

        armed, arm_err = self._ensure_armed()
        if not armed:
            return {
                "allowed": False,
                "decision": risk_engine.DECISION_BLOCK,
                "score": 100,
                "signals": [{"name": "policy_override", "weight": 50, "evidence": arm_err}],
                "evidence": [f"Shield unavailable: {arm_err}"],
                "bypassed": False
            }

        guard_res = code_guard.inspect_healed_code(original, fixed)
        signals = guard_res.get("signals", [])

        risk = risk_engine.compute_risk(signals)
        allowed = (risk["decision"] == risk_engine.DECISION_ALLOW)

        if not allowed or risk["score"] > 0:
            audit_log.log_event(
                channel="healed_code",
                decision=risk["decision"],
                risk_score=risk["score"],
                action_attempted="apply_patch_verification",
                category="CODE_GUARD_VIOLATION",
                attack_id=attack_id,
                evidence=risk["evidence"]
            )

        return {
            "allowed": allowed,
            "decision": risk["decision"],
            "score": risk["score"],
            "signals": risk["signals"],
            "evidence": risk["evidence"],
            "bypassed": False
        }

    # =========================================================================
    # GATE 4: Output Guard & Log
    # =========================================================================
    def sanitize_output(
        self,
        output_data: Any,
        attack_id: Optional[str] = None,
        channel: str = "output"
    ) -> Tuple[Any, Dict[str, Any]]:
        """
        Gate 4: Redacts sensitive patterns, tokens, and canary data from response.
        """
        if not is_shield_enabled():
            return output_data, {"redacted": False, "items": [], "decision": risk_engine.DECISION_ALLOW}

        if isinstance(output_data, dict):
            clean_data, redacted_items = output_guard.sanitize_dict(output_data)
        elif isinstance(output_data, str):
            clean_data, redacted_items = output_guard.redact_output(output_data)
        else:
            clean_data = output_data
            redacted_items = []

        has_redactions = len(redacted_items) > 0

        if has_redactions:
            audit_log.log_event(
                channel=channel,
                decision=risk_engine.DECISION_REDACT,
                risk_score=0,
                action_attempted="output_serialization",
                category="OUTPUT_LEAK_PREVENTION",
                attack_id=attack_id,
                evidence=[f"Redacted {len(redacted_items)} sensitive item(s)"]
            )

        return clean_data, {
            "redacted": has_redactions,
            "items": redacted_items,
            "decision": risk_engine.DECISION_REDACT if has_redactions else risk_engine.DECISION_ALLOW
        }


# Singleton Shield instance
_GLOBAL_SHIELD: Optional[Shield] = None


def get_shield() -> Shield:
    """Return the global Shield instance (instantiated lazily)."""
    global _GLOBAL_SHIELD
    if _GLOBAL_SHIELD is None:
        _GLOBAL_SHIELD = Shield()
    return _GLOBAL_SHIELD


def inspect_input(text: str, channel: str = "user_instruction", attack_id: Optional[str] = None) -> Dict[str, Any]:
    return get_shield().inspect_input(text, channel=channel, attack_id=attack_id)


def check_tool(tool_name: str, args: Optional[Dict[str, Any]] = None, approved: bool = False, attack_id: Optional[str] = None) -> Dict[str, Any]:
    return get_shield().check_tool(tool_name, args=args, approved=approved, attack_id=attack_id)


def inspect_healed_code(original_code: str, fixed_code: str, attack_id: Optional[str] = None) -> Dict[str, Any]:
    return get_shield().inspect_healed_code(original_code, fixed_code, attack_id=attack_id)


def inspect_output(output_data: Any, channel: str = "output", attack_id: Optional[str] = None) -> Tuple[Any, Dict[str, Any]]:
    return get_shield().inspect_output(output_data, channel=channel, attack_id=attack_id)

