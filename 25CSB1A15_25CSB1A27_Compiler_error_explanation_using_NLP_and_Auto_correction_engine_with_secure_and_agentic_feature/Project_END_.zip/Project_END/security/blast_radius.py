"""security/blast_radius.py - Tree-Edit-Distance (TED) & AST Blast-Radius Limiter.

Implements the classical Zhang-Shasha algorithm on Python Abstract Syntax Trees
to calculate exact structural edit distance between original and healed code.
Guarantees that autonomous AI patches:
1. Stay strictly within the structural neighborhood of the target error.
2. Do not exceed allowable AST churn (Blast Radius Ratio).
3. Do not mutate unrelated top-level functions, classes, or out-of-scope blocks.
"""

import ast
from typing import Any, Dict, List, Optional, Set, Tuple


class _ASTNodeWrapper:
    """Lightweight representation of an AST node for Zhang-Shasha tree edit distance."""
    __slots__ = ("node_type", "label", "lineno", "children", "post_idx", "leftmost_leaf")

    def __init__(self, node_type: str, label: str = "", lineno: Optional[int] = None):
        self.node_type = node_type
        self.label = label
        self.lineno = lineno
        self.children: List["_ASTNodeWrapper"] = []
        self.post_idx: int = 0
        self.leftmost_leaf: int = 0

    def rename_cost(self, other: "_ASTNodeWrapper") -> int:
        """Cost of relabeling/substituting this node with other."""
        if self.node_type == other.node_type and self.label == other.label:
            return 0
        if self.node_type == other.node_type:
            return 1  # Same syntactic category, different identifier/literal
        return 2      # Different syntactic construct (e.g., Call vs Assign)


def _ast_to_tree(node: ast.AST) -> _ASTNodeWrapper:
    """Converts a standard Python ast.AST into an ordered _ASTNodeWrapper tree."""
    node_type = type(node).__name__
    label = ""
    lineno = getattr(node, "lineno", None)

    # Capture distinguishing semantic labels
    if isinstance(node, ast.Name):
        label = node.id
    elif isinstance(node, ast.Constant):
        label = str(node.value)[:32]
    elif isinstance(node, ast.Attribute):
        label = node.attr
    elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        label = node.name
    elif isinstance(node, ast.arg):
        label = node.arg
    elif isinstance(node, (ast.Import, ast.ImportFrom)):
        names = [alias.name for alias in getattr(node, "names", [])]
        label = ",".join(names)

    wrapper = _ASTNodeWrapper(node_type, label, lineno)

    for field, value in ast.iter_fields(node):
        if isinstance(value, list):
            for item in value:
                if isinstance(item, ast.AST):
                    wrapper.children.append(_ast_to_tree(item))
        elif isinstance(value, ast.AST):
            wrapper.children.append(_ast_to_tree(value))

    return wrapper


def _postorder_label(root: _ASTNodeWrapper) -> List[_ASTNodeWrapper]:
    """Indexes tree nodes in post-order and computes leftmost leaf descendants."""
    nodes: List[_ASTNodeWrapper] = []

    def _traverse(curr: _ASTNodeWrapper) -> int:
        leftmost = None
        for ch in curr.children:
            ch_leftmost = _traverse(ch)
            if leftmost is None:
                leftmost = ch_leftmost

        idx = len(nodes) + 1  # 1-based indexing for Zhang-Shasha
        curr.post_idx = idx
        curr.leftmost_leaf = leftmost if leftmost is not None else idx
        nodes.append(curr)
        return curr.leftmost_leaf

    _traverse(root)
    return nodes


def _get_keyroots(nodes: List[_ASTNodeWrapper]) -> List[int]:
    """Identifies keyroots (roots of subtrees that need distinct DP table passes)."""
    keyroots: List[int] = []
    seen_leftmost: Set[int] = set()

    for node in reversed(nodes):
        if node.leftmost_leaf not in seen_leftmost:
            keyroots.append(node.post_idx)
            seen_leftmost.add(node.leftmost_leaf)

    return sorted(keyroots)


def zhang_shasha_ted(tree1: ast.AST, tree2: ast.AST) -> int:
    """
    Computes exact Tree Edit Distance (Zhang-Shasha algorithm) between two ASTs.
    Returns integer minimal edit distance.
    """
    root1 = _ast_to_tree(tree1)
    root2 = _ast_to_tree(tree2)

    nodes1 = _postorder_label(root1)
    nodes2 = _postorder_label(root2)

    n1 = len(nodes1)
    n2 = len(nodes2)

    if n1 == 0:
        return n2
    if n2 == 0:
        return n1

    # Fast structural multiset distance approximation for large ASTs to avoid O(N^2 D^2) lockup
    if n1 > 250 or n2 > 250:
        from collections import Counter
        c1 = Counter(node.label for node in nodes1)
        c2 = Counter(node.label for node in nodes2)
        diff = sum((c1 - c2).values()) + sum((c2 - c1).values())
        return diff

    # 1-indexed lookup maps
    map1 = {node.post_idx: node for node in nodes1}
    map2 = {node.post_idx: node for node in nodes2}

    keyroots1 = _get_keyroots(nodes1)
    keyroots2 = _get_keyroots(nodes2)

    # Permanent table for tree distances between subtrees rooted at i and j
    treedist: Dict[Tuple[int, int], int] = {}

    for kr1 in keyroots1:
        for kr2 in keyroots2:
            # Run DP on subforests
            l1 = map1[kr1].leftmost_leaf
            l2 = map2[kr2].leftmost_leaf

            forestdist: Dict[Tuple[int, int], int] = {}
            forestdist[(l1 - 1, l2 - 1)] = 0

            for i in range(l1, kr1 + 1):
                forestdist[(i, l2 - 1)] = forestdist[(i - 1, l2 - 1)] + 1

            for j in range(l2, kr2 + 1):
                forestdist[(l1 - 1, j)] = forestdist[(l1 - 1, j - 1)] + 1

            for i in range(l1, kr1 + 1):
                for j in range(l2, kr2 + 1):
                    node_i = map1[i]
                    node_j = map2[j]

                    del_cost = forestdist[(i - 1, j)] + 1
                    ins_cost = forestdist[(i, j - 1)] + 1

                    if node_i.leftmost_leaf == l1 and node_j.leftmost_leaf == l2:
                        rename_cost = forestdist[(i - 1, j - 1)] + node_i.rename_cost(node_j)
                        cost = min(del_cost, ins_cost, rename_cost)
                        forestdist[(i, j)] = cost
                        treedist[(i, j)] = cost
                    else:
                        sub_tree_dist = treedist.get((i, j), 0)
                        sub_forest_cost = forestdist[(node_i.leftmost_leaf - 1, node_j.leftmost_leaf - 1)] + sub_tree_dist
                        forestdist[(i, j)] = min(del_cost, ins_cost, sub_forest_cost)

    return treedist.get((n1, n2), abs(n1 - n2))


def extract_top_level_scopes(code: str) -> Dict[str, Tuple[int, int, str]]:
    """
    Extracts top-level declarations (functions, classes) with their line spans and signatures.
    Returns: {name: (start_line, end_line, ast_type)}
    """
    scopes: Dict[str, Tuple[int, int, str]] = {}
    try:
        tree = ast.parse(code)
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                end_lineno = getattr(node, "end_lineno", getattr(node, "lineno", 1) + 10)
                scopes[node.name] = (node.lineno, end_lineno, type(node).__name__)
    except Exception:
        pass
    return scopes


def evaluate_blast_radius(
    original_code: str,
    healed_code: str,
    error_line: Optional[int] = None,
    max_radius: float = 0.40
) -> Dict[str, Any]:
    """
    Computes structural AST Tree Edit Distance, evaluates blast radius ratio,
    and checks scope locality.

    Returns:
        Dict containing:
        - blast_radius_ratio: float (0.0 to 1.0)
        - tree_edit_distance: int
        - orig_nodes: int
        - fixed_nodes: int
        - out_of_scope_mutations: List[str]
        - is_safe: bool
        - summary: str
    """
    orig_tree = None
    fixed_tree = None

    try:
        orig_tree = ast.parse(original_code)
    except SyntaxError:
        pass

    try:
        fixed_tree = ast.parse(healed_code)
    except SyntaxError:
        pass

    # If neither parses, fall back safely
    if not fixed_tree:
        return {
            "blast_radius_ratio": 1.0,
            "tree_edit_distance": 999,
            "orig_nodes": 0,
            "fixed_nodes": 0,
            "out_of_scope_mutations": ["Fixed code failed AST parsing"],
            "is_safe": False,
            "summary": "Synthesized code contains syntax errors; cannot construct AST."
        }

    # Count nodes
    fixed_nodes = len(list(ast.walk(fixed_tree)))
    orig_nodes = len(list(ast.walk(orig_tree))) if orig_tree else 0

    # 1. Compute Tree Edit Distance
    if orig_tree:
        ted = zhang_shasha_ted(orig_tree, fixed_tree)
        max_possible = max(orig_nodes, fixed_nodes, 1)
        radius_ratio = round(min(ted / max_possible, 1.0), 4)
    else:
        # Original had syntax error; estimate blast radius via size comparison
        ted = abs(fixed_nodes - orig_nodes)
        radius_ratio = 0.20  # Baseline acceptable repair ratio for broken original syntax

    # 2. Check Top-Level Scope Tampering (Locality Check)
    orig_scopes = extract_top_level_scopes(original_code)
    fixed_scopes = extract_top_level_scopes(healed_code)
    out_of_scope_mutations: List[str] = []

    # If error_line is specified, find which scope should be modified
    target_scope = None
    if error_line is not None and orig_scopes:
        for sname, (start, end, _) in orig_scopes.items():
            if start <= error_line <= end:
                target_scope = sname
                break

    # Inspect other scopes: verify unchanged functions were not modified
    for sname, (orig_start, orig_end, stype) in orig_scopes.items():
        if target_scope and sname != target_scope:
            if sname in fixed_scopes:
                # Compare AST of this specific function between orig and fixed
                try:
                    orig_func_node = next(n for n in orig_tree.body if getattr(n, "name", None) == sname)
                    fixed_func_node = next(n for n in fixed_tree.body if getattr(n, "name", None) == sname)
                    func_ted = zhang_shasha_ted(orig_func_node, fixed_func_node)
                    if func_ted > 0:
                        out_of_scope_mutations.append(
                            f"Unrelated {stype} '{sname}' was altered (TED={func_ted}) despite error being in scope '{target_scope}'"
                        )
                except Exception:
                    pass
            else:
                out_of_scope_mutations.append(f"Unrelated {stype} '{sname}' was deleted by the patch.")

    # 3. Determine Safety Verdict
    # For small scripts (< 20 AST nodes), allow normal single-statement fixes where relative ratio
    # can be mathematically higher, while still bounding absolute TED <= 12 and blocking out-of-scope edits.
    if orig_nodes < 20:
        is_safe = (ted <= 12) and (len(out_of_scope_mutations) == 0)
    else:
        is_safe = (radius_ratio <= max_radius) and (len(out_of_scope_mutations) == 0)

    summary = (
        f"AST TED={ted}, Nodes: (orig={orig_nodes}, fixed={fixed_nodes}), "
        f"Blast Radius={radius_ratio:.1%} (Max Allowed: {max_radius:.1%})"
    )
    if out_of_scope_mutations:
        summary += f" | Out-of-Scope Mutations: {'; '.join(out_of_scope_mutations)}"

    return {
        "blast_radius_ratio": radius_ratio,
        "tree_edit_distance": ted,
        "orig_nodes": orig_nodes,
        "fixed_nodes": fixed_nodes,
        "out_of_scope_mutations": out_of_scope_mutations,
        "is_safe": is_safe,
        "summary": summary
    }
