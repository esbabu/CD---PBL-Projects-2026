"""security/risk_engine.py - Autonomous Risk Scoring and Decision Engine.

Calculates risk score as the capped sum of detected signal weights (0-100).
Thresholds:
- 0 to 29:   ALLOW
- 30 to 59:  WARN (Requires human approval)
- 60 to 100: BLOCK

Output redaction events (AT-15) yield decision REDACT.
"""

from typing import Any, Dict, List, Optional, Tuple

# Named constants for decision boundaries
SCORE_MIN: int = 0
SCORE_WARN_THRESHOLD: int = 30
SCORE_BLOCK_THRESHOLD: int = 60
SCORE_MAX: int = 100

DECISION_ALLOW = "ALLOW"
DECISION_WARN = "WARN"
DECISION_BLOCK = "BLOCK"
DECISION_REDACT = "REDACT"

# Authoritative Signal Weights Dictionary (Tuned for Week 5 / Week 6 Carry-Over)
SIGNAL_WEIGHTS: Dict[str, int] = {
    "policy_override": 40,
    "verdict_forcing": 30,
    "authority_spoofing": 35,
    "obfuscation": 20,
    "personal_data_access": 50,
    "network_exfiltration": 50,
    "path_outside_workspace": 40,
    "patch_scope_anomaly": 15,
    "tool_arg_violation": 50,
    "approval_bypass": 40,
    "secret_request": 35,
    "role_jailbreak": 35,
    "trojan_guard_mutation": 50,
    "exception_silencing": 35,
}


def compute_risk(signals: List[Dict[str, Any]], is_redaction: bool = False) -> Dict[str, Any]:
    """
    Computes cumulative risk score and decision based on signals.

    Args:
        signals: List of signal dicts with {"name": str, ...} or {"id": str, "family": str, ...}
        is_redaction: If True, returns decision REDACT.

    Returns:
        dict: {
            "score": int (0-100),
            "decision": str ("ALLOW", "WARN", "BLOCK", "REDACT"),
            "signals": List[Dict[str, Any]],
            "evidence": List[str]
        }
    """
    if is_redaction:
        return {
            "score": 0,
            "decision": DECISION_REDACT,
            "signals": signals or [],
            "evidence": ["Sensitive pattern redacted from output"]
        }

    raw_score = 0
    resolved_signals: List[Dict[str, Any]] = []
    evidence_list: List[str] = []

    # Map input_guard signal families to risk_engine names
    family_mapping = {
        "PI_POLICY_OVERRIDE": "policy_override",
        "PI_VERDICT_FORCING": "verdict_forcing",
        "PI_AUTHORITY_SPOOF": "authority_spoofing",
        "PI_AUTHORITY_SPOOFING": "authority_spoofing",
        "PI_OBFUSCATION": "obfuscation",
        "PI_PERSONAL_DATA_ACCESS": "personal_data_access",
        "PI_NETWORK_EXFILTRATION": "network_exfiltration",
        "PI_EXFIL_REQUEST": "network_exfiltration",
        "PI_PATH_OUTSIDE_WORKSPACE": "path_outside_workspace",
        "PI_PATCH_SCOPE_ANOMALY": "patch_scope_anomaly",
        "PI_TOOL_ARG_VIOLATION": "tool_arg_violation",
        "PI_APPROVAL_BYPASS": "approval_bypass",
        "PI_SECRET_REQUEST": "secret_request",
        "PI_ROLE_JAILBREAK": "role_jailbreak",
        "approval_bypass": "approval_bypass",
        "secret_request": "secret_request",
        "role_jailbreak": "role_jailbreak",
    }

    seen_signal_names = set()

    for sig in signals:
        s_name = sig.get("name")
        if not s_name and "family" in sig:
            s_name = family_mapping.get(sig["family"], sig["family"].lower())

        s_weight = sig.get("weight")
        if s_weight is None and s_name in SIGNAL_WEIGHTS:
            s_weight = SIGNAL_WEIGHTS[s_name]
        elif s_weight is None:
            s_weight = 10

        s_evidence = sig.get("evidence", "")

        raw_score += int(s_weight)
        resolved_signals.append({
            "name": s_name,
            "weight": s_weight,
            "evidence": s_evidence
        })
        if s_evidence and s_evidence not in evidence_list:
            evidence_list.append(s_evidence)

    # Cap score at 100
    score = min(SCORE_MAX, max(SCORE_MIN, raw_score))

    # Evaluate decision boundaries
    if score >= SCORE_BLOCK_THRESHOLD:
        decision = DECISION_BLOCK
    elif score >= SCORE_WARN_THRESHOLD:
        decision = DECISION_WARN
    else:
        decision = DECISION_ALLOW

    return {
        "score": score,
        "decision": decision,
        "signals": resolved_signals,
        "evidence": evidence_list
    }
