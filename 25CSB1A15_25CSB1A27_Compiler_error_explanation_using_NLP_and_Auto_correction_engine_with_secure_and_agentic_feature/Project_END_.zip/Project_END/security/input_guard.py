"""input_guard.py - Advisory Prompt-Injection and Policy-Bypass Detector for IntelliFix.

Implements Feature 13b (TOC Week 3):
- Inspects text across three channels: 'user_instruction', 'code_content', 'error_text'.
- Multi-phase normalization: NFKC, zero-width removal, homoglyph mapping, casefold,
  percent-decoding, de-spacing, leetspeak normalization, and recursive safe base64/hex decoding.
- Bounded pattern matching across prioritized threat families:
    PI_POLICY_OVERRIDE (40), PI_VERDICT_FORCING (30), PI_AUTHORITY_SPOOF (25),
    PI_SECRET_REQUEST (35), PI_EXFIL_REQUEST (35), PI_APPROVAL_BYPASS (40),
    PI_ROLE_JAILBREAK (25), PI_AI_ADDRESSED (+15, code/error channels only),
    PI_OBFUSCATION (+20).
- Negation suppression rule (negation within 3 words before verb cancels signal).
- Linear-time ReDoS immunity with bounded gaps and strict pre-truncation.
- Redacted evidence snippets (max 80 chars, secrets masked).
- Code channel scanner leveraging tokenizer.py for comments and docstrings.
- STRICTLY ADVISORY: Never blocks execution and never writes to disk.
"""

from __future__ import annotations

import base64
import binascii
import re
import unicodedata
import urllib.parse
from typing import Any, Dict, List, Optional, Set, Tuple

# Valid input channels
VALID_CHANNELS = {"user_instruction", "code_content", "error_text"}

# Bands
BAND_LOW_THRESHOLD = 30
BAND_HIGH_THRESHOLD = 60

# Signal Weights
SIGNAL_WEIGHTS = {
    "PI_POLICY_OVERRIDE": 40,
    "PI_VERDICT_FORCING": 30,
    "PI_AUTHORITY_SPOOF": 35,
    "PI_SECRET_REQUEST": 35,
    "PI_EXFIL_REQUEST": 35,
    "PI_APPROVAL_BYPASS": 40,
    "PI_ROLE_JAILBREAK": 35,
    "PI_AI_ADDRESSED": 15,
    "PI_OBFUSCATION": 20,
}

# Homoglyph look-alike character mapping (Cyrillic & Greek to Latin)
HOMOGLYPH_MAP = {
    "\u0430": "a", "\u0410": "A",  # Cyrillic a
    "\u0441": "c", "\u0421": "C",  # Cyrillic c
    "\u0435": "e", "\u0415": "E",  # Cyrillic e
    "\u0456": "i", "\u0406": "I",  # Cyrillic i
    "\u0458": "j", "\u0408": "J",  # Cyrillic j
    "\u043e": "o", "\u041e": "O",  # Cyrillic o
    "\u0440": "p", "\u0420": "P",  # Cyrillic p
    "\u0455": "s", "\u0405": "S",  # Cyrillic s
    "\u0443": "y", "\u0423": "Y",  # Cyrillic y
    "\u0445": "x", "\u0425": "X",  # Cyrillic x
    "\u03b1": "a", "\u0391": "A",  # Greek alpha
    "\u03bf": "o", "\u039f": "O",  # Greek omicron
}

# Controlled signal vocabulary for de-spacing and leetspeak recovery
SIGNAL_VOCAB = {
    "ignore", "disregard", "bypass", "disable", "override", "skip",
    "deactivate", "circumvent", "forget", "policy", "security",
    "validation", "validator", "rules", "safety", "guardrails",
    "checks", "restrictions", "admin", "system", "passwords",
    "secrets", "credentials", "tokens", "safe", "clean", "approve",
    "confirmation", "prompt", "operator", "root", "unrestricted"
}

# Leetspeak translation table
LEET_TRANS = str.maketrans({
    "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"
})

# Precompiled Bounded Patterns
# Negation prefix: within 3 words before verb
NEGATION_WORDS = {"not", "don't", "dont", "don", "never", "no", "shouldn't", "shouldnt", "mustn't", "mustnt"}

OVERRIDE_VERBS = r"\b(?:ignore|disregard|bypass|disable|override|skip|turn\s+off|deactivate|circumvent|forget)\b"
SECURITY_OBJECTS = r"\b(?:polic(?:y|ies)|security|validation|validator|scan(?:ner)?|guard(?:rails)?|rules|safety|checks|restrictions|instructions|previous\s+(?:instructions|rules|prompts|messages))\b"
PAT_POLICY_OVERRIDE = re.compile(
    rf"({OVERRIDE_VERBS})(?:\W+\w+){{0,5}}\W+({SECURITY_OBJECTS})|({SECURITY_OBJECTS})(?:\W+\w+){{0,5}}\W+({OVERRIDE_VERBS})",
    re.IGNORECASE
)

PAT_VERDICT_FORCING = re.compile(
    r"\b(?:mark\b(?:\W+\w+){0,4}\W+\bas\s+safe|report\s+no\s+vulnerabilities|say\s+it\s+is\s+clean|approve\s+this|pass\s+the\s+check)\b",
    re.IGNORECASE
)

PAT_AUTHORITY_SPOOF = re.compile(
    r"(?:"
    r"\[\s*(?:system|admin|root|system\s+operator|system\s+message|security\s+team\s+advisory)\b[^\]]*\]:?|"
    r"#{1,3}\s*system\s*(?:instruction|message|directive)\s*#{1,3}:?|"
    r"\b(?:system\s*:\s*|system\s+(?:message|instruction|operator)|admin(?:istrator)?\s+(?:mode|override)|developer\s+mode|developer\s+message|"
    r"maintenance\s+(?:state|session)|root\s+(?:override|privilege)|from\s+the\s+security\s+team|new\s+instructions)\b"
    r")",
    re.IGNORECASE
)

SECRET_VERBS = r"\b(?:print|show|reveal|output|send|give\s+me|tell\s+me|list|dump|leak|expose)\b"
SECRET_NOUNS = r"\b(?:environment\s+variables|api\s+keys?|tokens?|passwords?|personal\s+files|credentials|home\s+directory\s+secrets)\b"
PAT_SECRET_REQUEST = re.compile(
    rf"({SECRET_VERBS})(?:\W+\w+){{0,5}}\W+({SECRET_NOUNS})|({SECRET_NOUNS})(?:\W+\w+){{0,5}}\W+({SECRET_VERBS})",
    re.IGNORECASE
)

# Exfil request: upload/post/email as verb sending data out, not noun 'email address'
PAT_EXFIL_REQUEST = re.compile(
    r"\b(?:upload|post\s+to|send\s+to\s+(?:a\s+url|https?://|[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)|email\s+(?:the\s+)?(?:credentials|secrets|tokens|keys|passwords|files|code))\b",
    re.IGNORECASE
)

PAT_APPROVAL_BYPASS = re.compile(
    r"(?:"
    r"\b(?:apply|write|persist|save|commit)\b(?:\W+\w+){0,6}\W+\b(?:without\s+(?:asking|requesting|waiting)|skipping\s+(?:the\s+)?approval|no\s+confirmation|directly\s+to\s+disk)\b|"
    r"\b(?:without|skipping)\b(?:\W+\w+){0,4}\W+\b(?:user\s+confirmation|developer\s+confirmation|approval\s+prompt|confirmation\s+modal|requesting\s+user)\b|"
    r"\bdo\s+not\s+ask\b(?:\W+\w+){0,4}\W+\b(?:confirmation|approval|user|developer|me)\b|"
    r"\b(?:force\s+approval|auto-?approv\w*|skip\s+confirmation|bypass\s+(?:human\s+)?confirmation|apply\s+without\s+asking)\b"
    r")",
    re.IGNORECASE
)

PAT_ROLE_JAILBREAK = re.compile(
    r"\b(?:you\s+are\s+now\b|pretend\s+to\s+be\b|(?:zero|no)\s+restrictions|developer\s+mode|\bDAN\b|hypothetically\b|imagine\s+you\s+are\b|unrestricted\s+(?:mode|terminal)|jailbreak)\b",
    re.IGNORECASE
)

PAT_AI_ADDRESSED = re.compile(
    r"\b(?:assistant|agent|ai|model|llm|copilot|you\s+must|when\s+you\s+read\s+this)\b",
    re.IGNORECASE
)


def _check_negation(text: str, match_start: int) -> bool:
    """Check if a negation word appears within 3 words before match_start."""
    prefix = text[:match_start].strip()
    if not prefix:
        return False
    words = re.findall(r"\b\w+\b", prefix)
    window = [w.lower() for w in words[-4:]]
    for w in window:
        if w in NEGATION_WORDS or w in ("never", "shouldn't", "mustn't"):
            return True
    return False


def _redact_evidence(text: str) -> str:
    """Produce a safe, redacted evidence snippet of at most 80 chars."""
    # Mask runs of 32+ hex/alphanumeric characters (like API keys or hashes)
    masked = re.sub(r"\b[A-Za-z0-9_-]{32,}\b", "[redacted]", text)
    # Escape control chars
    escaped = "".join(c if (32 <= ord(c) <= 126) else f"\\x{ord(c):02x}" for c in masked)
    if len(escaped) > 80:
        return escaped[:77] + "..."
    return escaped


def _normalize_text(text: str) -> Tuple[str, Dict[str, Any], bool]:
    """Apply normalization pipeline and return normalized string, audit record, and obfuscation_detected."""
    applied: List[str] = []
    decoded_blobs: List[str] = []
    obfuscation_detected = False

    # 1. NFKC normalization
    nfkc = unicodedata.normalize("NFKC", text)
    if nfkc != text:
        applied.append("nfkc")
    cur = nfkc

    # 2. Zero-width and BiDi character removal
    # Zero width: U+200B, U+200C, U+200D, U+FEFF; BiDi: U+202A-U+202E, U+2066-U+2069
    cleaned = re.sub(r"[\u200b-\u200d\ufeff\u202a-\u202e\u2066-\u2069]", "", cur)
    if len(cleaned) != len(cur):
        applied.append("zero_width_stripped")
        obfuscation_detected = True
    cur = cleaned

    # 3. Look-alike (homoglyph) mapping
    homoglyph_applied = False
    chars = []
    for ch in cur:
        if ch in HOMOGLYPH_MAP:
            chars.append(HOMOGLYPH_MAP[ch])
            homoglyph_applied = True
        else:
            chars.append(ch)
    if homoglyph_applied:
        applied.append("homoglyph_mapped")
        obfuscation_detected = True
        cur = "".join(chars)

    # 4. Percent-decoding (URL decode)
    if "%" in cur:
        try:
            unquoted = urllib.parse.unquote(cur)
            if unquoted != cur:
                applied.append("percent_decoded")
                obfuscation_detected = True
                cur = unquoted
        except Exception:
            pass

    # 5. Casefold
    cur = cur.casefold()

    # 6. De-spacing letter runs: e.g. "i g n o r e" or "i.g.n.o.r.e"
    # Find words with single characters separated by space or dot
    def _despace_match(m: re.Match) -> str:
        s = m.group()
        collapsed = re.sub(r"[\s.]", "", s).lower()
        if collapsed in SIGNAL_VOCAB:
            return collapsed
        return s

    despaced = re.sub(r"\b(?:[a-zA-Z][\s.]){3,}[a-zA-Z]\b", _despace_match, cur)
    if despaced != cur:
        applied.append("despaced_vocabulary")
        obfuscation_detected = True
        cur = despaced

    # 7. Leetspeak reversal for signal vocabulary
    words = cur.split()
    leet_fixed = []
    for w in words:
        clean_w = re.sub(r"[^\w@$]", "", w)
        cand = clean_w.translate(LEET_TRANS)
        if cand in SIGNAL_VOCAB and cand != clean_w:
            leet_fixed.append(cand)
            obfuscation_detected = True
        else:
            leet_fixed.append(w)
    if obfuscation_detected and "leetspeak_normalized" not in applied and leet_fixed != words:
        applied.append("leetspeak_normalized")
        cur = " ".join(leet_fixed)

    # 8. Safe Base64 and Hex decode
    # Base64 pattern: 12+ chars of valid base64 (handling =, == padding)
    b64_matches = re.findall(r"(?:[A-Za-z0-9+/]{4}){2,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})", text)
    for b_str in b64_matches:
        try:
            raw = base64.b64decode(b_str, validate=True)
            if 4 <= len(raw) <= 8192 and all(32 <= b <= 126 or b in (9, 10, 13) for b in raw):
                dec_text = raw.decode("utf-8", errors="ignore")
                decoded_blobs.append(dec_text)
                applied.append("base64_decoded")
                obfuscation_detected = True
        except Exception:
            pass

    # Hex pattern: 16+ hex digits
    hex_matches = re.findall(r"\b(?:[0-9a-fA-F]{2}){8,}\b", text)
    for h_str in hex_matches:
        try:
            raw = binascii.unhexlify(h_str)
            if 4 <= len(raw) <= 8192 and all(32 <= b <= 126 or b in (9, 10, 13) for b in raw):
                dec_text = raw.decode("utf-8", errors="ignore")
                decoded_blobs.append(dec_text)
                applied.append("hex_decoded")
                obfuscation_detected = True
        except Exception:
            pass

    return cur, {"applied": list(set(applied)), "decoded_blobs": decoded_blobs}, obfuscation_detected


def inspect_text(text: str, channel: str, max_len: int = 20000) -> Dict[str, Any]:
    """Inspect a text string for prompt-injection and policy-bypass signals.

    Args:
        text: Input string to analyze.
        channel: One of 'user_instruction', 'code_content', or 'error_text'.
        max_len: Maximum length of text to inspect (pre-truncated).

    Returns:
        Structured advisory report dictionary.
    """
    if channel not in VALID_CHANNELS:
        raise ValueError(f"Invalid channel '{channel}'. Expected one of {sorted(VALID_CHANNELS)}.")

    if not isinstance(text, str) or not text.strip():
        return {
            "channel": channel,
            "score": 0,
            "band": "low",
            "signals": [],
            "normalization": {"applied": [], "decoded_blobs": []},
            "truncated": False,
            "advisory": True,
        }

    truncated = len(text) > max_len
    target_text = text[:max_len]

    norm_text, norm_record, obfuscation_found = _normalize_text(target_text)

    # Combine normalized target text with any safely decoded blobs
    texts_to_scan = [norm_text] + [b.casefold() for b in norm_record["decoded_blobs"]]

    detected_signals: List[Dict[str, Any]] = []
    seen_families: Set[str] = set()

    for scan_idx, s_text in enumerate(texts_to_scan):
        is_decoded = (scan_idx > 0)

        # 1. PI_POLICY_OVERRIDE
        for m in PAT_POLICY_OVERRIDE.finditer(s_text):
            if not _check_negation(s_text, m.start()):
                fam = "PI_POLICY_OVERRIDE"
                if fam not in seen_families:
                    seen_families.add(fam)
                    detected_signals.append({
                        "id": f"SIG_{len(detected_signals)+1:02d}",
                        "family": fam,
                        "weight": SIGNAL_WEIGHTS[fam],
                        "evidence": _redact_evidence(m.group()),
                        "start": m.start(),
                        "end": m.end(),
                        "decoded": is_decoded,
                    })

        # 2. PI_VERDICT_FORCING
        for m in PAT_VERDICT_FORCING.finditer(s_text):
            if not _check_negation(s_text, m.start()):
                fam = "PI_VERDICT_FORCING"
                if fam not in seen_families:
                    seen_families.add(fam)
                    detected_signals.append({
                        "id": f"SIG_{len(detected_signals)+1:02d}",
                        "family": fam,
                        "weight": SIGNAL_WEIGHTS[fam],
                        "evidence": _redact_evidence(m.group()),
                        "start": m.start(),
                        "end": m.end(),
                        "decoded": is_decoded,
                    })

        # 3. PI_AUTHORITY_SPOOF
        for m in PAT_AUTHORITY_SPOOF.finditer(s_text):
            fam = "PI_AUTHORITY_SPOOF"
            if fam not in seen_families:
                seen_families.add(fam)
                detected_signals.append({
                    "id": f"SIG_{len(detected_signals)+1:02d}",
                    "family": fam,
                    "weight": SIGNAL_WEIGHTS[fam],
                    "evidence": _redact_evidence(m.group()),
                    "start": m.start(),
                    "end": m.end(),
                    "decoded": is_decoded,
                })

        # 4. PI_SECRET_REQUEST
        for m in PAT_SECRET_REQUEST.finditer(s_text):
            if not _check_negation(s_text, m.start()):
                fam = "PI_SECRET_REQUEST"
                if fam not in seen_families:
                    seen_families.add(fam)
                    detected_signals.append({
                        "id": f"SIG_{len(detected_signals)+1:02d}",
                        "family": fam,
                        "weight": SIGNAL_WEIGHTS[fam],
                        "evidence": _redact_evidence(m.group()),
                        "start": m.start(),
                        "end": m.end(),
                        "decoded": is_decoded,
                    })

        # 5. PI_EXFIL_REQUEST
        for m in PAT_EXFIL_REQUEST.finditer(s_text):
            if not _check_negation(s_text, m.start()):
                fam = "PI_EXFIL_REQUEST"
                if fam not in seen_families:
                    seen_families.add(fam)
                    detected_signals.append({
                        "id": f"SIG_{len(detected_signals)+1:02d}",
                        "family": fam,
                        "weight": SIGNAL_WEIGHTS[fam],
                        "evidence": _redact_evidence(m.group()),
                        "start": m.start(),
                        "end": m.end(),
                        "decoded": is_decoded,
                    })

        # 6. PI_APPROVAL_BYPASS
        for m in PAT_APPROVAL_BYPASS.finditer(s_text):
            fam = "PI_APPROVAL_BYPASS"
            if fam not in seen_families:
                seen_families.add(fam)
                detected_signals.append({
                    "id": f"SIG_{len(detected_signals)+1:02d}",
                    "family": fam,
                    "weight": SIGNAL_WEIGHTS[fam],
                    "evidence": _redact_evidence(m.group()),
                    "start": m.start(),
                    "end": m.end(),
                    "decoded": is_decoded,
                })

        # 7. PI_ROLE_JAILBREAK
        for m in PAT_ROLE_JAILBREAK.finditer(s_text):
            fam = "PI_ROLE_JAILBREAK"
            if fam not in seen_families:
                seen_families.add(fam)
                detected_signals.append({
                    "id": f"SIG_{len(detected_signals)+1:02d}",
                    "family": fam,
                    "weight": SIGNAL_WEIGHTS[fam],
                    "evidence": _redact_evidence(m.group()),
                    "start": m.start(),
                    "end": m.end(),
                    "decoded": is_decoded,
                })

        # 8. PI_AI_ADDRESSED (Only on code_content and error_text)
        if channel in ("code_content", "error_text"):
            for m in PAT_AI_ADDRESSED.finditer(s_text):
                fam = "PI_AI_ADDRESSED"
                if fam not in seen_families:
                    seen_families.add(fam)
                    detected_signals.append({
                        "id": f"SIG_{len(detected_signals)+1:02d}",
                        "family": fam,
                        "weight": SIGNAL_WEIGHTS[fam],
                        "evidence": _redact_evidence(m.group()),
                        "start": m.start(),
                        "end": m.end(),
                        "decoded": is_decoded,
                    })

    # Add PI_OBFUSCATION bonus if obfuscation was present AND any core signal fired
    if (obfuscation_found or any(s["decoded"] for s in detected_signals)) and len(detected_signals) > 0:
        fam = "PI_OBFUSCATION"
        if fam not in seen_families:
            seen_families.add(fam)
            detected_signals.append({
                "id": f"SIG_{len(detected_signals)+1:02d}",
                "family": fam,
                "weight": SIGNAL_WEIGHTS[fam],
                "evidence": f"Normalization steps applied: {', '.join(norm_record['applied'])}",
                "start": 0,
                "end": 0,
                "decoded": False,
            })

    total_score = min(100, sum(s["weight"] for s in detected_signals))

    if total_score >= BAND_HIGH_THRESHOLD:
        band = "high"
    elif total_score >= BAND_LOW_THRESHOLD:
        band = "medium"
    else:
        band = "low"

    return {
        "channel": channel,
        "score": total_score,
        "band": band,
        "signals": detected_signals,
        "normalization": norm_record,
        "truncated": truncated,
        "advisory": True,
    }


def scan_code_channels(code: str, max_segments: int = 500, max_bytes: int = 200 * 1024) -> Dict[str, Any]:
    """Extract comment and string tokens from source code and scan via the input guard.

    Args:
        code: Full Python source code.
        max_segments: Maximum number of tokens to inspect.
        max_bytes: Maximum cumulative bytes of token content to analyze.

    Returns:
        Summary inspection record across code segments.
    """
    import tokenizer
    tok_res = tokenizer.tokenize(code)
    tokens = tok_res.get("tokens", [])

    segments_checked = 0
    bytes_checked = 0
    max_score = 0
    truncated = False
    all_signals: List[Dict[str, Any]] = []

    for t in tokens:
        if t["type"] in ("COMMENT", "STRING"):
            if segments_checked >= max_segments or bytes_checked >= max_bytes:
                truncated = True
                break

            seg_text = t["text"]
            bytes_checked += len(seg_text.encode("utf-8"))
            segments_checked += 1

            res = inspect_text(seg_text, channel="code_content")
            if res["score"] > max_score:
                max_score = res["score"]
            for s in res["signals"]:
                s["token_line"] = t["line"]
                all_signals.append(s)

    # Sort signals descending by weight and pick top 5
    all_signals.sort(key=lambda x: x["weight"], reverse=True)
    top_signals = all_signals[:5]

    if max_score >= BAND_HIGH_THRESHOLD:
        band = "high"
    elif max_score >= BAND_LOW_THRESHOLD:
        band = "medium"
    else:
        band = "low"

    return {
        "segments_checked": segments_checked,
        "max_score": max_score,
        "band": band,
        "flagged": top_signals,
        "by_channel": {"code_content": {"segments": segments_checked, "score": max_score}},
        "truncated": truncated,
        "advisory": True,
    }
