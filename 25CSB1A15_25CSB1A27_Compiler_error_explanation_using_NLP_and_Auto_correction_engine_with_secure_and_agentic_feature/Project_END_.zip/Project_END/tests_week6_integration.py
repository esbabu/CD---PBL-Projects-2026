"""tests_week6_integration.py - Full End-to-End Week 6 Integration Test Suite.

Verifies:
- /api/version additive week6_hash, week5_hash, week4_hash, week3_hash, shield_enabled
- /api/security/metrics read-only endpoint (GET 200, POST 405)
- /results/charts/<filename> SVG chart serving
- /api/diff unified diff endpoint
- Feature 15 Security Metrics CSV, MD analysis, and 5 SVG charts
- Feature 10 Offline Benchmark results (96 evaluations, utility preservation, 0 false blocks)
- Feature 11 UI templates elements and Self-XSS mitigations (zero innerHTML in modified sinks)
- Feature 12 intellifix.py CLI execution across clean, buggy, and attack files
- Cryptographic Audit Log chain integrity in results/security_log.jsonl
- Held-out corpus freeze hash integrity in attacks/heldout_freeze.json
- Strict socket guard blocking all outbound non-local network calls
"""

import hashlib
import json
import os
import socket
import subprocess
import sys
import unittest

os.environ["LLM_DISABLED"] = "1"
os.environ["INTELLIFIX_OFFLINE"] = "1"

import app as flask_app


class TestWeek6Integration(unittest.TestCase):

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1", "testserver"):
                raise AssertionError(f"Outbound network call to {address} attempted during integration test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.app = flask_app.app.test_client()
        self.app.testing = True
        self.root_dir = os.path.dirname(os.path.abspath(__file__))

    def tearDown(self):
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_01_api_version_week6_hash(self):
        """GET /api/version returns week6_hash (12 hex characters) and historical hashes."""
        resp = self.app.get("/api/version")
        self.assertEqual(resp.status_code, 200)
        data = json.loads(resp.data)
        self.assertIn("week6_hash", data)
        self.assertEqual(len(data["week6_hash"]), 12)
        self.assertIn("week5_hash", data)
        self.assertIn("week4_hash", data)
        self.assertIn("week3_hash", data)
        self.assertIn("shield_enabled", data)

    def test_02_security_metrics_api(self):
        """GET /api/security/metrics returns complete metrics, POST/PUT/DELETE return 405."""
        resp = self.app.get("/api/security/metrics")
        self.assertEqual(resp.status_code, 200)
        data = json.loads(resp.data)
        self.assertEqual(data.get("status"), "success")
        self.assertIn("metrics", data)
        self.assertIn("recent_audit_events", data)
        self.assertIn("charts", data)

        # Method safety
        self.assertEqual(self.app.post("/api/security/metrics").status_code, 405)
        self.assertEqual(self.app.put("/api/security/metrics").status_code, 405)
        self.assertEqual(self.app.delete("/api/security/metrics").status_code, 405)

    def test_03_chart_svg_serving(self):
        """GET /results/charts/<filename> serves SVG files with correct mimetype."""
        for chart in ["asr_comparison.svg", "per_category_recall.svg", "confusion_matrix.svg", "risk_score_distribution.svg", "roc_curve.svg"]:
            resp = self.app.get(f"/results/charts/{chart}")
            self.assertEqual(resp.status_code, 200, f"Failed to serve {chart}")
            self.assertIn("image/svg+xml", resp.content_type)
            self.assertIn("<svg", resp.data.decode("utf-8"))

    def test_04_diff_api(self):
        """POST /api/diff produces unified diff."""
        payload = {
            "original": "x = 1\ny = 2\n",
            "healed": "x = 1\ny = 3\n"
        }
        resp = self.app.post("/api/diff", json=payload)
        self.assertEqual(resp.status_code, 200)
        data = json.loads(resp.data)
        self.assertEqual(data.get("status"), "success")
        self.assertTrue(len(data.get("lines", [])) > 0)

    def test_05_feature_15_security_artifacts_exist(self):
        """Verify results/security_metrics.csv, results/security_metrics.md, and charts exist."""
        csv_path = os.path.join(self.root_dir, "results", "security_metrics.csv")
        md_path = os.path.join(self.root_dir, "results", "security_metrics.md")
        self.assertTrue(os.path.exists(csv_path), "Missing results/security_metrics.csv")
        self.assertTrue(os.path.exists(md_path), "Missing results/security_metrics.md")

        charts_dir = os.path.join(self.root_dir, "results", "charts")
        for c in ["asr_comparison.svg", "per_category_recall.svg", "confusion_matrix.svg", "risk_score_distribution.svg", "roc_curve.svg"]:
            self.assertTrue(os.path.exists(os.path.join(charts_dir, c)), f"Missing chart {c}")

    def test_06_feature_10_benchmark_artifacts_exist(self):
        """Verify results/benchmark_results.csv (96 runs) and results/final_results_table.md."""
        bcsv_path = os.path.join(self.root_dir, "results", "benchmark_results.csv")
        bmd_path = os.path.join(self.root_dir, "results", "final_results_table.md")
        self.assertTrue(os.path.exists(bcsv_path), "Missing results/benchmark_results.csv")
        self.assertTrue(os.path.exists(bmd_path), "Missing results/final_results_table.md")

        with open(bcsv_path, "r", encoding="utf-8") as f:
            lines = [l for l in f if l.strip()]
        # 1 header + 96 runs = 97 lines
        self.assertEqual(len(lines), 97, f"Expected 97 lines (1 header + 96 runs), got {len(lines)}")

    def test_07_heldout_corpus_freeze_hash(self):
        """Verify attacks/heldout_freeze.json matches SHA256 of attacks/heldout_corpus.json."""
        corpus_path = os.path.join(self.root_dir, "attacks", "heldout_corpus.json")
        freeze_path = os.path.join(self.root_dir, "attacks", "heldout_freeze.json")
        self.assertTrue(os.path.exists(corpus_path))
        self.assertTrue(os.path.exists(freeze_path))

        with open(corpus_path, "rb") as f:
            corpus_bytes = f.read().replace(b"\r\n", b"\n")
            corpus_hash = hashlib.sha256(corpus_bytes).hexdigest()

        with open(freeze_path, "r", encoding="utf-8") as f:
            freeze_data = json.load(f)

        self.assertEqual(corpus_hash, freeze_data.get("sha256"))
        self.assertEqual(freeze_data.get("sample_count"), 90)

    def test_08_audit_log_cryptographic_chain(self):
        """Verify results/security_log.jsonl cryptographic hash chain integrity."""
        log_path = os.path.join(self.root_dir, "results", "security_log.jsonl")
        self.assertTrue(os.path.exists(log_path))

        from security.audit_log import verify_log
        valid, tampered_line, msg = verify_log(log_path=log_path)
        self.assertTrue(valid, f"Audit chain verification failed: {msg}")
        self.assertIsNone(tampered_line)

    def test_09_cli_subprocess_execution(self):
        """Verify intellifix.py CLI runs via subprocess and repairs prog_01_zerodiv.py."""
        prog = os.path.join(self.root_dir, "benchmark_programs", "prog_01_zerodiv.py")
        cmd = [sys.executable, os.path.join(self.root_dir, "intellifix.py"), prog, "--json"]
        env = dict(os.environ)
        env["LLM_DISABLED"] = "1"
        res = subprocess.run(cmd, capture_output=True, text=True, env=env)
        self.assertEqual(res.returncode, 0)
        data = json.loads(res.stdout)
        self.assertEqual(data.get("status"), "success")
        self.assertEqual(data.get("fixed_count"), 1)


if __name__ == "__main__":
    unittest.main()
