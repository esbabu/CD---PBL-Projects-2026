# Phase A - Pilot Dataset Generator
# 160 hand-crafted Python error snippets (20 per type x 8 types).
# Static security scan + python -I sandbox (3s timeout) for verification.
# Output: dataset/pilot_dataset.json

import sys, os, json, subprocess, tempfile

PYTHON_EXE = sys.executable
CANDIDATES = []

FORBIDDEN = [
    "socket","urllib","requests","http.client","http.server",
    "subprocess","os.system","os.popen","shutil","ctypes",
    "pathlib","pickle","marshal","eval(","exec(","compile(",
    "__import__","importlib","multiprocessing","threading",
    "asyncio","signal",
]

def add(error_type, snippet, mistake, reason, fix, rule_engine):
    CANDIDATES.append({
        "error_type": error_type,
        "snippet": snippet.strip(),
        "mistake": mistake,
        "reason": reason,
        "fix": fix,
        "rule_engine": rule_engine,
    })

# ══ 1. ZeroDivisionError (rule_engine=True, 20) ══════════════════════════
add("ZeroDivisionError","x = 10 / 0","Dividing 10 by literal 0.","Python raises ZeroDivisionError when divisor is exactly zero.","Guard: if divisor != 0: result = 10 / divisor.",True)
add("ZeroDivisionError","a = 5; b = 0\nprint(a // b)","Integer floor-division by zero.","Floor-division // raises ZeroDivisionError when right operand is 0.","Check b != 0 before dividing.",True)
add("ZeroDivisionError","def rate(total, count):\n    return total / count\nrate(100, 0)","Calling rate() with count=0.","Function divides by count which is 0.","Add: if count == 0: return 0",True)
add("ZeroDivisionError","nums = [4, 2, 0]\nresult = 8 / nums[2]","Using third list element (0) as divisor.","nums[2] is 0; ZeroDivisionError.","Check nums[2] != 0 before dividing.",True)
add("ZeroDivisionError","x = int('0')\ny = 9 / x","Dividing by variable parsed from '0'.","x is 0 after parsing.","Validate x != 0 after parsing.",True)
add("ZeroDivisionError","d = {'a': 0}\nprint(1 / d['a'])","Dividing by dict value that is 0.","Key 'a' maps to 0.","Validate dict value is non-zero.",True)
add("ZeroDivisionError","for i in range(3, -1, -1):\n    print(10 / i)","Loop divides by i which reaches 0.","ZeroDivisionError when i becomes 0.","Add: if i != 0: before dividing.",True)
add("ZeroDivisionError","n = 5\nwhile n >= 0:\n    print(1 / n)\n    n -= 1","While loop divides by n which hits 0.","ZeroDivisionError when n is 0.","Change condition to n > 0.",True)
add("ZeroDivisionError","def percent(part, total):\n    return (part / total) * 100\npercent(0, 0)","Passing total=0 to percentage function.","Division by zero in return expression.","Add: if total == 0: return 0.0",True)
add("ZeroDivisionError","x = 10\ny = x - 10\nprint(x / y)","y evaluates to 0 (x minus x).","x - 10 is 0 when x=10.","Ensure y is non-zero.",True)
add("ZeroDivisionError","def inverse(n):\n    return 1 / n\nresult = inverse(0)","Calling inverse(0).","1/0 is undefined.","Raise ValueError for n==0.",True)
add("ZeroDivisionError","total = 0\ncount = 0\nmean = total / count","Computing mean with both zero.","0/0 triggers ZeroDivisionError.","Check if count > 0 before dividing.",True)
add("ZeroDivisionError","result = 3 % 0","Modulo with 0 as divisor.","% also raises ZeroDivisionError for 0.","Ensure modulo divisor is non-zero.",True)
add("ZeroDivisionError","x = 2.0\ny = x - 2.0\nprint(x / y)","Float subtraction yields 0.0 used as divisor.","0.0 as divisor raises ZeroDivisionError.","Guard with: if y != 0.0:",True)
add("ZeroDivisionError","scores = []\nprint(sum(scores) / len(scores))","Dividing sum of empty list by its length (0).","len([]) is 0.","Check if scores: before computing average.",True)
add("ZeroDivisionError","a = 4; b = 2\nresult = a // (b - 2)","Denominator b-2 evaluates to 0.","Floor-division by 0.","Validate denominator before dividing.",True)
add("ZeroDivisionError","def safe_div(a, b):\n    return a / b\nprint(safe_div(7, 7 - 7))","Argument 7-7 evaluates to 0.","Passing 0 as divisor causes ZeroDivisionError.","Validate arguments before calling.",True)
add("ZeroDivisionError","n = 10\nfactors = [f for f in range(1, n) if n % f == 0]\nprint(n % 0)","Explicitly computing n % 0.","n % 0 raises ZeroDivisionError.","Never use 0 as modulo operand.",True)
add("ZeroDivisionError","import math\nangle = 0\nresult = 1 / math.sin(angle)","sin(0) is 0; dividing raises ZeroDivisionError.","math.sin(0) returns 0.0.","Check math.sin(angle) != 0 before dividing.",True)
add("ZeroDivisionError","x = 0\ny = 0\nprint((x + y) / (x - y))","Denominator x - y is 0 when x == y == 0.","0/0 triggers ZeroDivisionError.","Validate denominator is non-zero.",True)

# ══ 2. NameError (rule_engine=True, 20) ══════════════════════════════════
add("NameError","print(mesage)","Using 'mesage' which was never defined.","Python cannot find 'mesage'; typo for 'message'.","Define: message = 'Hello' then print(message).",True)
add("NameError","x = 5\nprint(X)","Using X (uppercase) when variable is x (lowercase).","Python identifiers are case-sensitive.","Change print(X) to print(x).",True)
add("NameError","def greet():\n    name = 'Alice'\ngreet()\nprint(name)","Accessing name outside function where defined.","name is local to greet().","Return name and capture: name = greet().",True)
add("NameError","for i in range(5):\n    pass\nprint(total)","Referencing total which was never assigned.","total has no binding anywhere.","Initialize total = 0 before loop.",True)
add("NameError","class Dog:\n    def bark(self):\n        return sound\nDog().bark()","Referencing sound inside method where not defined.","sound is not local, attribute, or module-level.","Pass sound as parameter.",True)
add("NameError","pint(42)","Calling pint instead of built-in print.","pint is not a defined name.","Replace pint(42) with print(42).",True)
add("NameError","numbers = [1, 2, 3]\nprint(numbres)","Accessing numbres; typo for numbers.","Python finds no binding for numbres.","Correct typo: print(numbers).",True)
add("NameError","def compute():\n    result = 0\ncompute()\nprint(result)","result is local to compute() and inaccessible outside.","Local variables do not leak into module scope.","Return value and assign: result = compute().",True)
add("NameError","total = sum(nubmers)\nnubmers = [1, 2, 3]","Using nubmers before it is assigned.","Python evaluates top-to-bottom; nubmers is unbound.","Define numbers first; fix typo.",True)
add("NameError","y = x + 1","Using x without defining it.","No assignment to x anywhere.","Assign first: x = 0; y = x + 1.",True)
add("NameError","def square(n):\n    return n ** 2\nprint(sqaure(5))","Calling sqaure; typo for square.","sqaure is not found.","Fix typo: print(square(5)).",True)
add("NameError","MAX = 100\nprint(max_val)","Using max_val when constant is MAX.","Different name; Python does not auto-alias.","Use correct name: print(MAX).",True)
add("NameError","class Counter:\n    count = 0\nc = Counter()\nprint(count)","Accessing bare count instead of Counter.count.","count is class attribute, not module-level.","Use Counter.count or c.count.",True)
add("NameError","items = [10, 20, 30]\nfor item in items:\n    running_total += item","Using running_total without initializing.","running_total has no initial binding.","Initialize before loop: running_total = 0.",True)
add("NameError","a = 1\nb = 2\nc = a + b + d","Adding undefined variable d.","d has never been assigned.","Define d before use: d = 3.",True)
add("NameError","data = [3, 1, 4]\nsorted_data = sroted","Assigning from sroted; typo for sorted.","Python looks up sroted as name; not found.","Correct: sorted_data = sorted(data).",True)
add("NameError","pi = 3.14159\ncircle_area = radius * radius * pi\nradius = 5","Using radius before it is assigned on next line.","Python evaluates RHS before assignment below.","Swap lines: define radius = 5 first.",True)
add("NameError","a = 10\nif a > 5:\n    big = True\nprint(big if a > 5 else smal)","Referencing smal; typo for small or undefined.","smal is undefined name.","Define small = False or fix typo.",True)
add("NameError","def area(r):\n    return PI * r * r\narea(5)","Using PI (uppercase) which is not defined.","PI is not defined in any scope.","Define PI = 3.14159 or use math.pi.",True)
add("NameError","result = multiply(4, 5)\ndef multiply(a, b):\n    return a * b","Calling multiply before def is reached.","Function definitions are not hoisted in plain scripts.","Move def multiply block above the call.",True)

# ══ 3. TypeError (rule_engine=True, 20) ══════════════════════════════════
add("TypeError","print('Value: ' + 42)","Concatenating string with integer using +.","Python + cannot implicitly convert int to str.","Convert: print('Value: ' + str(42)).",True)
add("TypeError","x = 'hello'\ny = x + 5","Adding integer to string variable.","+ on str and int is undefined.","Convert: y = x + str(5).",True)
add("TypeError","result = len(42)","Calling len() on an integer.","len() requires a sequence; int is not.","Pass sequence: len(str(42)).",True)
add("TypeError","nums = [1, 2, 3]\nprint(nums + 4)","Concatenating list with integer using +.","List + requires another list.","Use nums + [4] or nums.append(4).",True)
add("TypeError","def add(a, b):\n    return a + b\nadd(1, 2, 3)","Calling add() with 3 args when it accepts 2.","Mismatched positional argument count.","Match call: add(1, 2).",True)
add("TypeError","x = None\nprint(x + 1)","Adding integer to None.","Arithmetic with None is undefined.","Initialize x to a numeric value.",True)
add("TypeError","t = (1, 2, 3)\nt[0] = 10","Assigning to index of a tuple.","Tuples are immutable; item assignment raises TypeError.","Use list: t = [1, 2, 3].",True)
add("TypeError","def greet(name):\n    return 'Hi ' + name\ngreet()","Calling greet() without required argument.","Missing positional argument triggers TypeError.","Provide argument: greet('Alice').",True)
add("TypeError","x = '5'\ny = x * 'abc'","Multiplying string by non-integer string.","String * requires int right operand.","Use integer multiplier: x * 3.",True)
add("TypeError","items = [3, 1, 'two', 4]\nitems.sort()","Sorting list with mixed int and str.","Python cannot compare int and str with <.","Ensure all elements same type.",True)
add("TypeError","print(True + 'yes')","Adding bool and string.","bool + str raises TypeError.","Convert: print(str(True) + 'yes').",True)
add("TypeError","n = 5\nfor c in n:\n    print(c)","Iterating over an integer.","int is not iterable.","Iterate over range: for c in range(n):",True)
add("TypeError","result = 'abc'[1.5]","Using float as string index.","Sequence indices must be integers.","Use integer index: 'abc'[1].",True)
add("TypeError","x = [1, 2]\nx.append(3, 4)","Calling list.append() with two arguments.","append() accepts exactly one argument.","Use extend([3, 4]) or call append twice.",True)
add("TypeError","a = (1, 2)\nb = (3, 4)\nprint(a - b)","Subtracting two tuples.","Tuples do not support - operator.","Compute element-wise manually.",True)
add("TypeError","s = 'hello'\ns += 5","Augmented-adding integer to string.","s += int raises TypeError same as +.","Convert: s += str(5).",True)
add("TypeError","vals = [1, 2, 3]\nresult = sum(vals, 'start')","Passing string as start to sum().","sum() requires numeric start value.","Use numeric start: sum(vals, 0).",True)
add("TypeError","x = {'key': 'value'}\nprint(x['key'] + x)","Adding string and dict.","String + dict is undefined.","Concatenate with another string.",True)
add("TypeError","def multiply(a, b):\n    return a * b\nmultiply('x', 1.5)","Multiplying string by float.","String * requires integer multiplier.","Use integer: multiply('x', 2).",True)
add("TypeError","data = {'a': 1}\nprint(data + {'b': 2})","Using + to merge two dicts.","Python dicts do not support + operator.","Use {**data, 'b': 2} or data.update({'b': 2}).",True)

# ══ 4. ValueError (rule_engine=True, 20) ═════════════════════════════════
add("ValueError","x = int('hello')","Passing non-numeric string to int().","int() cannot parse 'hello'.","Validate input or use try/except ValueError.",True)
add("ValueError","x = int('3.14')","Passing decimal string to int().","int() expects whole-number string.","Use int(float('3.14')) to truncate.",True)
add("ValueError","x = float('not_a_number')","Passing alphabetic string to float().","float() cannot parse 'not_a_number'.","Wrap in try/except or validate first.",True)
add("ValueError","import math\nx = math.sqrt(-1)","Square root of negative number.","math.sqrt requires non-negative argument.","Use cmath.sqrt(-1) or validate input.",True)
add("ValueError","a, b = [1, 2, 3]","Unpacking 3-element list into 2 variables.","Too many values to unpack.","Match targets: a, b, c = [1, 2, 3].",True)
add("ValueError","a, b, c = [1, 2]","Unpacking 2-element list into 3 variables.","Not enough values to unpack.","Ensure iterable has exactly 3 elements.",True)
add("ValueError","x = int('')","Calling int() on empty string.","Empty string has no numeric representation.","Check non-empty: if s: int(s).",True)
add("ValueError","import math\nmath.log(0)","Taking log of zero.","Logarithm undefined at 0.","Ensure argument > 0: if x > 0: math.log(x).",True)
add("ValueError","import math\nmath.log(-5)","Taking log of negative number.","math.log undefined for negative values.","Validate input > 0.",True)
add("ValueError","lst = [1, 2, 3]\nlst.remove(99)","Calling remove() with value not in list.","remove() raises ValueError when element absent.","Check: if 99 in lst: lst.remove(99).",True)
add("ValueError","n = int('  ')","Passing whitespace-only string to int().","Nothing remains after strip; ValueError.","Strip and validate: s.strip().isdigit().",True)
add("ValueError","base = int('ff', 9)","Parsing 'ff' in base 9; 'f' invalid in base 9.","'f' exceeds base 9.","Use valid base: int('ff', 16).",True)
add("ValueError","idx = [1, 2, 3].index(99)","Calling index() with value not in list.","index() raises ValueError when item absent.","Guard with: if 99 in lst:.",True)
add("ValueError","t = (10, 20)\na, b, c = t","Unpacking 2-element tuple into 3 names.","Mismatch: 2 values, 3 targets.","Match number of targets to tuple length.",True)
add("ValueError","x = int('12 34')","Passing string with internal space to int().","Internal spaces not allowed.","Remove spaces: int('12 34'.replace(' ', '')).",True)
add("ValueError","import math\nmath.asin(2.0)","Calling math.asin with value outside [-1, 1].","Domain of arcsin is [-1, 1].","Clamp: math.asin(max(-1.0, min(1.0, val))).",True)
add("ValueError","import math\nmath.acos(-2)","Calling math.acos with -2 outside domain.","arccos domain is [-1, 1].","Ensure input within [-1, 1].",True)
add("ValueError","pair = (1,)\na, b = pair","Unpacking single-element tuple into 2 variables.","1 value for 2 targets.","Add second element or use (a,) = pair.",True)
add("ValueError","nums = []\nmin_val = min(nums)","Calling min() on empty list.","min() raises ValueError for empty iterable.","Check if nums: before calling min().",True)
add("ValueError","x, y = map(int, '1 two'.split())","Converting '1' and 'two' to int; 'two' is non-numeric.","int('two') raises ValueError.","Ensure all tokens numeric before converting.",True)

# ══ 5. RecursionError (rule_engine=False, 20) ════════════════════════════
add("RecursionError","def f():\n    return f()\nf()","Function calls itself unconditionally.","Infinite recursion exhausts call stack.","Add a base case to stop recursion.",False)
add("RecursionError","def count_down(n):\n    return count_down(n - 1)\ncount_down(5)","Recursive countdown with no base case.","Recurses past 0 indefinitely.","Add: if n <= 0: return",False)
add("RecursionError","def a():\n    return b()\ndef b():\n    return a()\na()","Mutual recursion without termination.","Call graph cycles endlessly.","Add shared counter to stop cycles.",False)
add("RecursionError","def factorial(n):\n    return n * factorial(n)\nfactorial(5)","Factorial passes n unchanged.","Argument never decreases.","Fix: return n * factorial(n - 1) with if n == 0: return 1",False)
add("RecursionError","def sum_list(lst):\n    return lst[0] + sum_list(lst)\nsum_list([1, 2, 3])","Passing whole list to every recursive call.","List never shrinks.","Recurse on tail: sum_list(lst[1:]) with base case.",False)
add("RecursionError","class Node:\n    def depth(self):\n        return 1 + self.depth()\nn = Node()\nn.depth()","Method calls itself without termination.","Stack overflows.","Track depth via a parameter.",False)
add("RecursionError","def power(base, exp):\n    return base * power(base, exp)\npower(2, 3)","Exponential recursion passes exp unchanged.","Never reaches base case.","Fix: power(base, exp - 1) with if exp == 0: return 1",False)
add("RecursionError","def fib(n):\n    return fib(n) + fib(n - 1)\nfib(5)","One recursive call uses fib(n) instead of fib(n-2).","fib(n) is infinitely self-referencing.","Fix: return fib(n-1) + fib(n-2) with base cases.",False)
add("RecursionError","def collatz(n):\n    if n % 2 == 0:\n        return collatz(n // 2)\n    return collatz(3 * n + 1)\ncollatz(6)","Collatz with no base case for n == 1.","Loops back from 1 indefinitely.","Add: if n == 1: return",False)
add("RecursionError","def echo(x):\n    print(x)\n    return echo(x)\necho('hi')","Function echoes then recurses unconditionally.","No stopping condition.","Add counter parameter.",False)
add("RecursionError","def reverse(s):\n    return reverse(s) + s[0]\nreverse('abc')","Reversing by calling reverse(s) on full string.","Argument never shrinks.","Fix: reverse(s[1:]) + s[0] with if len(s) == 0: return ''",False)
add("RecursionError","def length(lst):\n    return 1 + length(lst)\nlength([1, 2, 3])","Computing length by recursing on same list.","List never reduced.","Recurse on lst[1:] with if not lst: return 0",False)
add("RecursionError","def my_max(lst):\n    return max(lst[0], my_max(lst))\nmy_max([3, 1, 4])","Recursing on lst instead of lst[1:].","List size never decreases.","Fix: my_max(lst[1:]) with if len(lst) == 1: return lst[0]",False)
add("RecursionError","def is_even(n):\n    return is_odd(n - 1)\ndef is_odd(n):\n    return is_even(n - 1)\nis_even(10)","Mutual parity recursion without base cases.","Call each other forever.","Add: if n == 0: return True in is_even.",False)
add("RecursionError","def binary_search(lst, target):\n    mid = len(lst) // 2\n    if lst[mid] == target:\n        return mid\n    return binary_search(lst, target)\nbinary_search([1, 2, 3], 5)","Binary search recurses on full list.","List never shrinks.","Pass half: binary_search(lst[:mid], target).",False)
add("RecursionError","def gcd(a, b):\n    return gcd(a, b)\ngcd(12, 8)","GCD recurses with both arguments unchanged.","Infinite recursion.","Fix: return gcd(b, a % b) with if b == 0: return a",False)
add("RecursionError","def copy_list(lst):\n    if not lst:\n        return []\n    return [lst[0]] + copy_list(lst)\ncopy_list([1, 2, 3])","Recursing on full list instead of lst[1:].","Base never reached.","Change to copy_list(lst[1:]).",False)
add("RecursionError","def digit_sum(n):\n    return n % 10 + digit_sum(n)\ndigit_sum(123)","Digit-sum passes n unchanged.","No reduction step.","Fix: digit_sum(n // 10) with if n < 10: return n",False)
add("RecursionError","def merge_sort(lst):\n    if len(lst) <= 1:\n        return lst\n    return merge_sort(lst)\nmerge_sort([3, 1])","Merge sort recurses on unsplit list.","List never halved.","Split: left, right = lst[:mid], lst[mid:]",False)
add("RecursionError","def flatten(lst):\n    result = []\n    for item in lst:\n        result.extend(flatten(lst))\n    return result\nflatten([1, 2])","Recursing on lst instead of item.","Every element triggers recursion on full list.","Recurse on item when it is a list.",False)

# ══ 6. OverflowError (rule_engine=False, 20) ═════════════════════════════
add("OverflowError","import math\nresult = math.exp(1000)","Computing e^1000 exceeds float range.","Result > float max (~1.8e308).","Guard: if x < 710: math.exp(x).",False)
add("OverflowError","import math\nx = math.exp(710)","e^710 overflows IEEE 754 double.","Value exceeds float max.","Use decimal.Decimal for precision.",False)
add("OverflowError","import math\nresult = math.exp(800)","e^800 far exceeds double range.","OverflowError: math range error.","Clamp exponent < 709.78.",False)
add("OverflowError","import math\nprint(math.exp(750))","e^750 beyond float capacity.","math.exp uses C exp(); overflow.","Validate exp_val < 709.",False)
add("OverflowError","x = 1.0\nfor _ in range(1100):\n    x *= 10.0","Repeatedly multiply float by 10 until overflow.","After ~309 iterations float exceeds max.","Use decimal.Decimal or check each step.",False)
add("OverflowError","import math\nmath.cosh(1000)","Hyperbolic cosine of 1000 overflows.","cosh(1000) ~ e^1000/2 > float max.","Clamp input or catch OverflowError.",False)
add("OverflowError","import math\nmath.sinh(1000)","Hyperbolic sine of 1000 overflows.","sinh(1000) ~ e^1000/2 exceeds float max.","Limit input abs(x) < 710.",False)
add("OverflowError","x = 2.0 ** 1100","Raising 2.0 (float) to power 1100.","2.0^1100 >> 1.8e308; float overflows.","Use integer: 2 ** 1100.",False)
add("OverflowError","import math\nmath.exp(950)","e^950 exceeds float64 max.","OverflowError: math range error.","Use decimal.Decimal('950').exp().",False)
add("OverflowError","import math\nresult = math.pow(10, 400)","10^400 overflows double-precision float.","math.pow returns float; 10^400 > max.","Use 10 ** 400 (Python int).",False)
add("OverflowError","import math\nmath.exp(1e4)","Exponent 10000 far beyond float range.","math.exp requires arg < ~709.78.","Validate exp_val < 709 before calling.",False)
add("OverflowError","import math\nf = float(math.factorial(180))","Converting factorial(180) to float overflows.","180! has ~347 digits.","Keep as int or use decimal.Decimal.",False)
add("OverflowError","import math\nprint(math.exp(709.8))","e^709.8 marginally exceeds float64 max.","float max ~ 1.7977e308; e^709.8 ~ 2.0e308.","Stay below 709.78: math.exp(709.0) is safe.",False)
add("OverflowError","import math\nresult = math.exp(500) * math.exp(500)","Product of two large exponentials overflows.","Each ~1.4e217; product ~2e434 >> float max.","Use log-addition: math.exp(1000).",False)
add("OverflowError","import math\nprint(math.exp(1500))","e^1500 astronomically larger than float max.","OverflowError: math range error.","Cap exponent < 709.78 or use Decimal.",False)
add("OverflowError","import math\nprint(math.exp(2000))","e^2000 far beyond float64.","OverflowError from C-level exp().","import decimal; decimal.Decimal(2000).exp().",False)
add("OverflowError","import math\nprint(math.exp(int(1e3)))","int(1e3) is 1000; e^1000 overflows.","Same as math.exp(1000).","Clamp: min(val, 709) before math.exp.",False)
add("OverflowError","import math\nmath.exp(900)","e^900 exceeds double precision.","OverflowError for arg > ~709.78.","Use log-space or Decimal.",False)
add("OverflowError","import math\nmath.exp(850)","e^850 overflows IEEE 754 double.","OverflowError: math range error.","Clamp exponent or use arbitrary precision.",False)
add("OverflowError","import math\nmath.exp(770)","e^770 beyond float64 capacity.","Float max ~ e^709.78; above overflows.","Keep exponent below 709.78.",False)

# ══ 7. AssertionError (rule_engine=False, 20) ════════════════════════════
add("AssertionError","x = -5\nassert x > 0, 'x must be positive'","Asserting -5 > 0 which is False.","assert raises AssertionError when expression is False.","Ensure x is positive or use if-raise.",False)
add("AssertionError","lst = []\nassert len(lst) > 0, 'List is empty'","Asserting non-empty list when list is empty.","len([]) > 0 is False.","Populate list before asserting.",False)
add("AssertionError","def divide(a, b):\n    assert b != 0\n    return a / b\ndivide(10, 0)","Calling divide with b=0 fails assertion guard.","assert b != 0 is False when b=0.","Pass non-zero or replace assert with ValueError.",False)
add("AssertionError","name = ''\nassert name, 'Name cannot be empty'","Asserting truthiness of empty string.","Empty string is falsy.","Assign non-empty string before assertion.",False)
add("AssertionError","a = 5\nb = 10\nassert a == b, 'not equal'","Asserting two unequal values are equal.","5 == 10 is False.","Make values equal or fix assertion logic.",False)
add("AssertionError","result = 2 + 2\nassert result == 5, 'Math is broken'","Asserting 2+2 equals 5.","4 == 5 is False.","Fix: assert result == 4.",False)
add("AssertionError","def check_positive(n):\n    assert n > 0\ncheck_positive(-1)","Passing negative to function with positivity assertion.","-1 > 0 is False.","Pass positive value.",False)
add("AssertionError","data = None\nassert data is not None, 'data must not be None'","Asserting data is not None when it is None.","None is not None is False.","Initialize data with proper value.",False)
add("AssertionError","score = 150\nassert 0 <= score <= 100, 'Score out of range'","Asserting score in [0,100] when it is 150.","0 <= 150 <= 100 is False.","Clamp score to valid range.",False)
add("AssertionError","items = [1, 2, 3]\nassert 4 in items, '4 not found'","Asserting 4 in list not containing it.","4 in [1,2,3] is False.","Append 4 first or use ValueError.",False)
add("AssertionError","assert isinstance('hello', int), 'Expected int'","Asserting string is instance of int.","isinstance('hello', int) is False.","Fix: isinstance('hello', str).",False)
add("AssertionError","x = 3.14\nassert x == int(x), 'not whole number'","Asserting float equals integer truncation.","3.14 == 3 is False.","Use x = 3.0 or fix assertion.",False)
add("AssertionError","stack = []\nassert stack, 'Stack must not be empty'","Asserting stack truthy when empty.","Empty list is falsy.","Push element before asserting.",False)
add("AssertionError","MAX = 10\ncount = 11\nassert count <= MAX, 'count exceeds MAX'","Count exceeds defined maximum.","11 <= 10 is False.","Ensure count does not exceed MAX.",False)
add("AssertionError","def factorial(n):\n    assert n >= 0, 'n must be non-negative'\n    if n == 0:\n        return 1\n    return n * factorial(n - 1)\nfactorial(-3)","Calling factorial with negative argument.","-3 >= 0 is False.","Pass non-negative: factorial(5).",False)
add("AssertionError","text = 'python'\nassert text.startswith('P'), 'Expected uppercase P'","Asserting uppercase P start on lowercase text.","Case-sensitive comparison.","Use text.lower().startswith('p').",False)
add("AssertionError","a = [1, 2]\nb = [2, 1]\nassert a == b, 'Lists differ'","Asserting list equality ignoring order.","[1,2] != [2,1].","Sort both: assert sorted(a) == sorted(b).",False)
add("AssertionError","n = 10\nassert n % 3 == 0, '10 not divisible by 3'","Asserting divisibility by 3 for 10.","10 % 3 == 1, not 0.","Use n = 9 or fix assertion.",False)
add("AssertionError","price = -50\nassert price >= 0, 'Price cannot be negative'","Asserting non-negative price on negative value.","-50 >= 0 is False.","Validate price at input time.",False)
add("AssertionError","d = {}\nassert 'key' in d, 'Missing required key'","Asserting key in empty dict.","'key' in {} is False.","Populate dict before asserting.",False)

# ══ 8. NotImplementedError (rule_engine=False, 20) ═══════════════════════
add("NotImplementedError","class Shape:\n    def area(self):\n        raise NotImplementedError('Subclass must implement area')\nShape().area()","Calling abstract method on base class.","Base class raises NotImplementedError.","Subclass and override area().",False)
add("NotImplementedError","class Animal:\n    def speak(self):\n        raise NotImplementedError\nAnimal().speak()","Calling unimplemented method on base class.","Method only raises NotImplementedError.","Subclass Animal and override speak().",False)
add("NotImplementedError","class Plugin:\n    def run(self):\n        raise NotImplementedError('run() must be overridden')\nPlugin().run()","Calling run() on abstract Plugin base.","Raises NotImplementedError to enforce override.","Define subclass: class MyPlugin(Plugin): def run(self): ...",False)
add("NotImplementedError","class Serializer:\n    def serialize(self, data):\n        raise NotImplementedError\nSerializer().serialize({'a': 1})","Calling abstract serialize on base class.","NotImplementedError; subclasses must implement.","Implement serialize in subclass.",False)
add("NotImplementedError","class Iterator:\n    def __next__(self):\n        raise NotImplementedError\nit = Iterator()\nnext(it)","Calling next() on iterator with stub __next__.","NotImplementedError raised from stub.","Implement __next__ with iteration logic.",False)
add("NotImplementedError","class Comparator:\n    def compare(self, a, b):\n        raise NotImplementedError('Must implement compare')\nComparator().compare(1, 2)","Using abstract comparator directly.","compare() not implemented.","Subclass: class AscComparator(Comparator): def compare(self, a, b): return a < b",False)
add("NotImplementedError","class BaseCache:\n    def get(self, key):\n        raise NotImplementedError\nc = BaseCache()\nc.get('x')","Using base cache without implementation.","get() raises NotImplementedError.","Implement DictCache subclass.",False)
add("NotImplementedError","class Transformer:\n    def transform(self, x):\n        raise NotImplementedError\nTransformer().transform(5)","Calling unimplemented transform on base.","Raises NotImplementedError.","Create concrete subclass.",False)
add("NotImplementedError","class Logger:\n    def log(self, msg):\n        raise NotImplementedError('log not implemented')\nLogger().log('test')","Calling log() on abstract Logger.","Intentionally unimplemented.","Implement ConsoleLogger subclass.",False)
add("NotImplementedError","class Encoder:\n    def encode(self, text):\n        raise NotImplementedError\nEncoder().encode('hello')","Using abstract Encoder without codec.","encode() raises NotImplementedError.","Subclass Encoder and implement encode.",False)
add("NotImplementedError","class Validator:\n    def validate(self, val):\n        raise NotImplementedError\nValidator().validate(42)","Calling validate on abstract Validator.","NotImplementedError; not overridden.","Implement validate in subclass.",False)
add("NotImplementedError","class Repository:\n    def find(self, id):\n        raise NotImplementedError\nRepository().find(1)","Calling find on unimplemented base.","NotImplementedError.","Create InMemoryRepo subclass.",False)
add("NotImplementedError","class Formatter:\n    def format(self, data):\n        raise NotImplementedError('format() is abstract')\nFormatter().format([1,2,3])","Calling abstract format() on base.","No concrete formatting logic.","Subclass: class CSVFormatter(Formatter): def format(self, data): return ','.join(str(x) for x in data)",False)
add("NotImplementedError","class Strategy:\n    def execute(self):\n        raise NotImplementedError\nStrategy().execute()","Using Strategy base without concrete strategy.","execute() is pure abstract.","Create ConcreteStrategy subclass.",False)
add("NotImplementedError","class Parser:\n    def parse(self, text):\n        raise NotImplementedError\nParser().parse('data')","Calling parse on abstract base.","No parsing logic.","Implement JSONParser subclass.",False)
add("NotImplementedError","class DataSource:\n    def fetch(self):\n        raise NotImplementedError\nDataSource().fetch()","Calling fetch on abstract DataSource.","Must be overridden.","Create FileDataSource subclass.",False)
add("NotImplementedError","class Hasher:\n    def hash(self, data):\n        raise NotImplementedError('Implement hash()')\nHasher().hash('abc')","Calling hash on abstract Hasher.","Explicit stub raises NotImplementedError.","Subclass with SHA256 implementation.",False)
add("NotImplementedError","class Notifier:\n    def notify(self, msg):\n        raise NotImplementedError\nNotifier().notify('alert')","Using abstract Notifier without channel.","NotImplementedError raised.","Implement EmailNotifier subclass.",False)
add("NotImplementedError","class Filter:\n    def apply(self, items):\n        raise NotImplementedError\nFilter().apply([1,2,3])","Calling apply on abstract Filter.","apply() is stub.","Subclass: class EvenFilter(Filter): def apply(self, items): return [x for x in items if x%2==0]",False)
add("NotImplementedError","class Exporter:\n    def export(self, data):\n        raise NotImplementedError('Implement export')\nExporter().export({'k': 'v'})","Calling export on unimplemented base.","Explicitly raises NotImplementedError.","Create JSONExporter subclass.",False)

# ── Security check ────────────────────────────────────────────────────────
def is_safe(snippet):
    for tok in FORBIDDEN:
        if tok in snippet:
            return False
    return True

# ── Sandbox runner ────────────────────────────────────────────────────────
def run_snippet(snippet, expected, timeout=3):
    with tempfile.TemporaryDirectory() as tmp:
        p = os.path.join(tmp, "s.py")
        with open(p, "w", encoding="utf-8") as f:
            f.write(snippet)
        try:
            proc = subprocess.run(
                [PYTHON_EXE, "-I", p],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, cwd=tmp, timeout=timeout)
            stderr = proc.stderr.strip()
            last = ""
            for line in reversed(stderr.split("\n")):
                line = line.strip()
                if line: last = line; break
            actual = last.split(":")[0].strip() if last else "NoError"
            return actual == expected, actual, stderr[-200:]
        except subprocess.TimeoutExpired:
            return False, "TimeoutExpired", ""
        except Exception as e:
            return False, "RunnerError", str(e)

# ── Main ──────────────────────────────────────────────────────────────────
def main():
    print(f"Candidates: {len(CANDIDATES)}")
    verified, stats = [], {}
    for i, e in enumerate(CANDIDATES):
        et, sn = e["error_type"], e["snippet"]
        if not is_safe(sn):
            print(f"[{i+1:3d}] BLOCKED  {et}")
            continue
        ok, actual, tail = run_snippet(sn, et)
        stats.setdefault(et, {"pass": 0, "fail": 0})
        if ok:
            stats[et]["pass"] += 1
            verified.append(e)
            print(f"[{i+1:3d}] PASS  {et}")
        else:
            stats[et]["fail"] += 1
            print(f"[{i+1:3d}] FAIL  {et} -> got '{actual}'")
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pilot_dataset.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(verified, f, indent=2)
    print(f"\nVerified {len(verified)}/{len(CANDIDATES)} -> {out}")
    for et, s in sorted(stats.items()):
        print(f"  {et:25s} pass={s['pass']} fail={s['fail']}")
    return verified

if __name__ == "__main__":
    main()
