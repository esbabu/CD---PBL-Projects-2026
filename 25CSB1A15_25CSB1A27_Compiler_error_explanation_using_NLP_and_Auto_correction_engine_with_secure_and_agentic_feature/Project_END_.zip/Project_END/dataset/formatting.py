"""
dataset/formatting.py – Phase B
Unified tokenizer-safe encoding for Flan-T5 fine-tuning and inference.

Unified substitution table for all text (error messages, code, prose, targets).
Quotes, angle brackets, braces, and other problematic tokens are encoded consistently.
"""

NL_TOK  = "[NL]"
IN1_TOK = "[IN]"
IN2_TOK = "[I2]"
IN3_TOK = "[I3]"
ERR_PFX = "[ER]"

CHAR_SUBS = [
    ("\t", "[TB]"),
    ("{", "[LB]"),
    ("}", "[RB]"),
    ("\\", "[BS]"),
    ("`", "[BT]"),
    ("<", "[LT]"),
    ("^", "[CR]"),
    ("~", "[TL]"),
    ("'", "[SQ]"),
    ('"', "[DQ]"),
    ("!", "[EX]"),
]

def encode_text(text):
    """Encodes special characters in any text using bracket tokens."""
    if not text:
        return ""
    for old, new in CHAR_SUBS:
        text = text.replace(old, new)
    return text

def decode_text(text):
    """Reverses bracket token substitutions."""
    if not text:
        return ""
    for old, new in reversed(CHAR_SUBS):
        text = text.replace(new, old)
    return text

def _encode_leading(raw_line):
    """Encodes leading 4-space indentations and special characters for a single line."""
    stripped = raw_line.lstrip(" ")
    n = len(raw_line) - len(stripped)
    ind = ""
    while n >= 12:
        ind += IN3_TOK
        n -= 12
    while n >= 8:
        ind += IN2_TOK
        n -= 8
    while n >= 4:
        ind += IN1_TOK
        n -= 4
    if n:
        ind += " " * n
    return ind + encode_text(stripped)

def encode(text):
    """Unified encoder for any text (code, target, error message, prose)."""
    if not text:
        return ""
    lines = text.split("\n")
    return NL_TOK.join(_encode_leading(l) for l in lines)

def decode_output(encoded):
    """Turns model output (or encoded target) back into readable text."""
    if not encoded:
        return ""
    lines = encoded.split(NL_TOK)
    decoded_lines = []
    for line in lines:
        s = line.replace(IN3_TOK, "            ").replace(IN2_TOK, "        ").replace(IN1_TOK, "    ")
        decoded_lines.append(decode_text(s))
    return "\n".join(decoded_lines)

def encode_code_window(code, error_line, window=10):
    """Encodes code snippet window around error_line with [ER] prefix and line numbers."""
    lines = code.splitlines()
    n = len(lines)
    if not error_line or error_line < 1:
        error_line = 1
    error_line = min(error_line, n)
    half  = window // 2
    start = max(0, error_line - 1 - half)
    end   = min(n, start + window)
    start = max(0, end - window)
    parts = []
    for i in range(start, end):
        ln  = i + 1
        enc = _encode_leading(lines[i])
        pfx = ERR_PFX if ln == error_line else ""
        parts.append(f"{pfx}L{ln}: {enc}")
    return NL_TOK.join(parts)

def format_input(error_type, message, line_no, code):
    """Formats model input prompt."""
    line_str  = str(line_no) if line_no else "?"
    msg_clean = encode_text(message.strip()) if message else "no message"
    enc_code  = encode_code_window(code, int(line_no) if line_no else 1)
    return (f"Explain this Python error in simple terms. "
            f"Error: {error_type}: {msg_clean}. Line {line_str}. Code: {enc_code}")

def format_target(mistake, reason, fix):
    """Builds readable target string."""
    return f"Mistake: {mistake} Reason: {reason} Fix: {fix}"
