# Phase A Pilot – Revision 2b (15 Samples)

> **Awaiting approval before Phase B.** All 9 requirements applied.

---

## Tokenizer Probe Summary

All 95 printable ASCII characters tested (range 32-126).
**7 fail chars confirmed:** `< \ ^ \` { } ~` (backtick and angle brackets are problematic).
**Context-problematic:** `'` (single quote) and `!` absorb adjacent spaces in SentencePiece.

**Encoding scheme (all sequences verified to round-trip):**

| Char | Meaning | Safe token |
|---|---|---|
| `{` | left brace | `[LB]` |
| `}` | right brace | `[RB]` |
| `\\` | backslash | `[BS]` |
| ``` | backtick | `[BT]` |
| `<` | less-than | `[LT]` |
| `^` | caret | `[CR]` |
| `~` | tilde | `[TL]` |
| `'` | single quote (code) | `[SQ]` |
| `"` | double quote (code) | `[DQ]` |
| `!` | exclamation (code) | `[EX]` |

**Round-trip pass rate: 100%** (37/37 examples)

---

## Sample 01 — `ZeroDivisionError` | rc: `literal_zero` | src: `rule_engine_reformatted`

**Snippet:**
```python
x = 10 / 0
```
**Real error:** `division by zero` at line `1`

**Formatted input:**
```
Explain this Python error in simple terms. Error: ZeroDivisionError: division by zero. Line 1. Code: [ER]L1: x = 10 / 0
```

**Formatted target:**
```
Mistake: Division by zero at line 1 (Offending line: x = 10 / 0) Reason: Denominator evaluated to zero at runtime Fix: x = 10 / 1
```
Tokens: `44`

**Minimal fix (changed lines):**
```python
x = 10 / 1
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Denominator', 'Reason', 'at', 'evaluated', 'Division', 'runtime', 'Offending', 'to', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `5d2345b6`

**Rule-engine raw output:**
> Mistake: Division by zero at line 1 (Offending line: x = 10 / 0). Reason: Denominator evaluated to zero at runtime. Fix: Guard the division with an 'if' check (e.g., if divisor != 0:) before dividing.

---

## Sample 02 — `ZeroDivisionError` | rc: `literal_zero` | src: `rule_engine_reformatted`

**Snippet:**
```python
a = 5
b = 0
result = a / b
```
**Real error:** `division by zero` at line `3`

**Formatted input:**
```
Explain this Python error in simple terms. Error: ZeroDivisionError: division by zero. Line 3. Code: L1: a = 5[NL]L2: b = 0[NL][ER]L3: result = a / b
```

**Formatted target:**
```
Mistake: Division by zero at line 3 (Offending line: result = a / b) Reason: Denominator evaluated to zero at runtime Fix: b = 1
```
Tokens: `41`

**Minimal fix (changed lines):**
```python
b = 1
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Denominator', 'Reason', 'at', 'evaluated', 'Division', 'runtime', 'Offending', 'to', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `9db2cad3`

**Rule-engine raw output:**
> Mistake: Division by zero at line 3 (Offending line: result = a / b). Reason: Denominator evaluated to zero at runtime. Fix: Guard the division with an 'if' check (e.g., if divisor != 0:) before dividing.

---

## Sample 03 — `NameError` | rc: `undefined_name` | src: `rule_engine_reformatted`

**Snippet:**
```python
y = x + 1
```
**Real error:** `name 'x' is not defined` at line `1`

**Formatted input:**
```
Explain this Python error in simple terms. Error: NameError: name 'x' is not defined. Line 1. Code: [ER]L1: y = x + 1
```

**Formatted target:**
```
Mistake: Using undefined variable 'x' at line 1 (Offending line: y = x + 1) Reason: Variable 'x' is referenced before being assigned or defined Fix: x = 0
```
Tokens: `50`

**Minimal fix (changed lines):**
```python
x = 0
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Using', 'Reason', 'Fix', 'at', 'being', 'Variable', 'assigned', 'Offending', 'Mistake', 'referenced']
**Spell check:** OK
**skeleton_id:** `73fdf021`

**Rule-engine raw output:**
> Mistake: Using undefined variable 'x' at line 1 (Offending line: y = x + 1). Reason: Variable 'x' is referenced before being assigned or defined. Fix: Define or initialize variable 'x' in the enclosing scope before using it.

---

## Sample 04 — `NameError` | rc: `wrong_case` | src: `rule_engine_reformatted`

**Snippet:**
```python
Pi = 3.14
circle = 2 * PI * 5
```
**Real error:** `name 'PI' is not defined. Did you mean: 'Pi'?` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: NameError: name 'PI' is not defined. Did you mean: 'Pi'?. Line 2. Code: L1: Pi = 3.14[NL][ER]L2: circle = 2 * PI * 5
```

**Formatted target:**
```
Mistake: Using undefined variable 'PI' at line 2 (Offending line: circle = 2 * PI * 5) Reason: Variable 'PI' is referenced before being assigned or defined Fix: circle = 2 * Pi * 5
```
Tokens: `54`

**Minimal fix (changed lines):**
```python
circle = 2 * Pi * 5
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Using', 'Reason', 'Fix', 'at', 'being', 'Variable', 'assigned', 'Offending', 'Mistake', 'referenced']
**Spell check:** OK
**skeleton_id:** `9213c7b4`

**Rule-engine raw output:**
> Mistake: Using undefined variable 'PI' at line 2 (Offending line: circle = 2 * PI * 5). Reason: Variable 'PI' is referenced before being assigned or defined. Fix: Define or initialize variable 'PI' in the enclosing scope before using it.

---

## Sample 05 — `TypeError` | rc: `dict_plus` | src: `rule_engine_reformatted`

**Snippet:**
```python
d = {'x': 1}
print(d + {'y': 2})
```
**Real error:** `unsupported operand type(s) for +: 'dict' and 'dict'` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: TypeError: unsupported operand type(s) for +: 'dict' and 'dict'. Line 2. Code: L1: d = [LB][SQ]x[SQ]: 1[RB][NL][ER]L2: print(d + [LB][SQ]y[SQ]: 2[RB])
```

**Formatted target:**
```
Mistake: Mixing incompatible data types at line 2 (Offending line: print(d + [LB]'y': 2[RB])) Reason: Incompatible types cannot be combined directly (unsupported operand type(s) for +: 'dict' and 'dict') Fix: d.update([LB][SQ]y[SQ]: 2[RB])[NL]print(d)
```
Tokens: `98`

**Minimal fix (changed lines):**
```python
d.update({'y': 2})
print(d)
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['types', 'Incompatible', 'directly', 'Reason', 'at', 'combined', 'Mixing', 'cannot', 'Offending', 'Fix', 'Mistake', 'update', 'data']
**Spell check:** OK
**skeleton_id:** `1a1694fb`

**Rule-engine raw output:**
> Mistake: Mixing incompatible data types at line 2 (Offending line: print(d + {'y': 2})). Reason: Incompatible types cannot be combined directly (unsupported operand type(s) for +: 'dict' and 'dict'). Fix: Explicitly convert data types using str(), int(), or verify function parameter types.

---

## Sample 06 — `TypeError` | rc: `not_iterable` | src: `rule_engine_reformatted`

**Snippet:**
```python
n = 5
for c in n:
    print(c)
```
**Real error:** `'int' object is not iterable` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: TypeError: 'int' object is not iterable. Line 2. Code: L1: n = 5[NL][ER]L2: for c in n:[NL]L3: [IN]print(c)
```

**Formatted target:**
```
Mistake: Mixing incompatible data types at line 2 (Offending line: for c in n:) Reason: Incompatible types cannot be combined directly ('int' object is not iterable) Fix: n = 5[NL]for c in range(n):[NL][IN]print(c)
```
Tokens: `74`

**Minimal fix (changed lines):**
```python
n = 5
for c in range(n):
    print(c)
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['types', 'Incompatible', 'directly', 'Reason', 'at', 'combined', 'Mixing', 'cannot', 'Offending', 'Fix', 'Mistake', 'data']
**Spell check:** OK
**skeleton_id:** `c5dd37f6`

**Rule-engine raw output:**
> Mistake: Mixing incompatible data types at line 2 (Offending line: for c in n:). Reason: Incompatible types cannot be combined directly ('int' object is not iterable). Fix: Explicitly convert data types using str(), int(), or verify function parameter types.

---

## Sample 07 — `ValueError` | rc: `unpack_too_many` | src: `rule_engine_reformatted`

**Snippet:**
```python
a, b = [1, 2, 3]
```
**Real error:** `too many values to unpack (expected 2)` at line `1`

**Formatted input:**
```
Explain this Python error in simple terms. Error: ValueError: too many values to unpack (expected 2). Line 1. Code: [ER]L1: a, b = [1, 2, 3]
```

**Formatted target:**
```
Mistake: Invalid value conversion at line 1 (Offending line: a, b = [1, 2, 3]) Reason: Value format does not match expected parser requirements (too many values to unpack (expected 2)) Fix: a, b, c = [1, 2, 3]
```
Tokens: `67`

**Minimal fix (changed lines):**
```python
a, b, c = [1, 2, 3]
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Value', 'c', 'requirements', 'parser', 'Reason', 'Fix', 'at', 'conversion', 'Invalid', 'does', 'Offending', 'value', 'Mistake', 'match']
**Spell check:** OK
**skeleton_id:** `f627e2a0`

**Rule-engine raw output:**
> Mistake: Invalid value conversion at line 1 (Offending line: a, b = [1, 2, 3]). Reason: Value format does not match expected parser requirements (too many values to unpack (expected 2)). Fix: Validate string input format before parsing, or enclose conversion in a try...except ValueError block.

---

## Sample 08 — `ValueError` | rc: `math_domain` | src: `rule_engine_reformatted`

**Snippet:**
```python
import math
math.sqrt(-1)
```
**Real error:** `math domain error` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: ValueError: math domain error. Line 2. Code: L1: import math[NL][ER]L2: math.sqrt(-1)
```

**Formatted target:**
```
Mistake: Invalid value conversion at line 2 (Offending line: math.sqrt(-1)) Reason: Value format does not match expected parser requirements (math domain error) Fix: math.sqrt(1)
```
Tokens: `52`

**Minimal fix (changed lines):**
```python
math.sqrt(1)
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Value', 'match', 'requirements', 'parser', 'Reason', 'at', 'expected', 'conversion', 'Invalid', 'does', 'Offending', 'value', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `5e5aed6b`

**Rule-engine raw output:**
> Mistake: Invalid value conversion at line 2 (Offending line: math.sqrt(-1)). Reason: Value format does not match expected parser requirements (math domain error). Fix: Validate string input format before parsing, or enclose conversion in a try...except ValueError block.

---

## Sample 09 — `RecursionError` | rc: `arg_not_shrinking` | src: `hand_template_fallback`

**Snippet:**
```python
def factorial(n):
    return n * factorial(n)
factorial(5)
```
**Real error:** `maximum recursion depth exceeded` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: RecursionError: maximum recursion depth exceeded. Line 2. Code: L1: def factorial(n):[NL][ER]L2: [IN]return n * factorial(n)[NL]L3: factorial(5)
```

**Formatted target:**
```
Mistake: factorial on line 2 calls factorial(n) with the same n, never reducing the argument. Reason: Without a decreasing argument the recursion never terminates and Python raises RecursionError when the call stack limit is reached. Fix: [IN]if n == 0: return 1[NL][IN]return n * factorial(n - 1)
```
Tokens: `92`

**Minimal fix (changed lines):**
```python
    if n == 0: return 1
    return n * factorial(n - 1)
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['on', 'Reason', 'a', 'reached', 'when', 'Without', 'decreasing', 'reducing', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `937ac7a9`

---

## Sample 10 — `RecursionError` | rc: `no_base_case` | src: `hand_template_fallback`

**Snippet:**
```python
def count_down(n):
    return count_down(n - 1)
count_down(5)
```
**Real error:** `maximum recursion depth exceeded` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: RecursionError: maximum recursion depth exceeded. Line 2. Code: L1: def count_down(n):[NL][ER]L2: [IN]return count_down(n - 1)[NL]L3: count_down(5)
```

**Formatted target:**
```
Mistake: count_down on line 2 has no condition to stop when n reaches 0. Reason: Without a termination condition the recursion continues past 0 and exhausts the call stack. Fix: [IN]if n [LT]= 0: return 0
```
Tokens: `61`

**Minimal fix (changed lines):**
```python
    if n <= 0: return 0
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['continues', 'past', 'on', 'no', 'Reason', 'a', 'when', 'Without', 'stop', 'termination', 'to', 'Fix', 'Mistake', 'has']
**Spell check:** OK
**skeleton_id:** `f9901a65`

---

## Sample 11 — `OverflowError` | rc: `float_pow_overflow` | src: `hand_template_fallback`

**Snippet:**
```python
x = 2.0 ** 1100
```
**Real error:** `(34, 'Result too large')` at line `1`

**Formatted input:**
```
Explain this Python error in simple terms. Error: OverflowError: (34, 'Result too large'). Line 1. Code: [ER]L1: x = 2.0 ** 1100
```

**Formatted target:**
```
Mistake: Line 1 raises 2.0 (float) to the power 1100. Reason: Float exponentiation overflows IEEE 754 double range; using integer ** gives arbitrary-precision result. Fix: x = 2 ** 1100
```
Tokens: `55`

**Minimal fix (changed lines):**
```python
x = 2 ** 1100
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['precision', 'gives', 'double', 'overflows', 'exponentiation', 'Reason', 'arbitrary', 'Float', 'IEEE', 'result', 'power', 'to', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `2474b438`

---

## Sample 12 — `OverflowError` | rc: `math_pow_float` | src: `hand_template_fallback`

**Snippet:**
```python
import math
result = math.pow(10, 400)
```
**Real error:** `math range error` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: OverflowError: math range error. Line 2. Code: L1: import math[NL][ER]L2: result = math.pow(10, 400)
```

**Formatted target:**
```
Mistake: math.pow on line 2 returns float; 10 to the power 400 exceeds float max. Reason: math.pow always returns float; 10 ** 400 uses Python int arithmetic which has no size limit. Fix: result = 10 ** 400
```
Tokens: `61`

**Minimal fix (changed lines):**
```python
result = 10 ** 400
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['size', 'on', 'no', 'Reason', 'power', 'to', 'Fix', 'Mistake', 'has']
**Spell check:** OK
**skeleton_id:** `d1446cc9`

---

## Sample 13 — `AssertionError` | rc: `value_exceeds_limit` | src: `hand_template_fallback`

**Snippet:**
```python
MAX = 10
count = 11
assert count <= MAX, f"count {count} exceeds MAX {MAX}"
```
**Real error:** `count 11 exceeds MAX 10` at line `3`

**Formatted input:**
```
Explain this Python error in simple terms. Error: AssertionError: count 11 exceeds MAX 10. Line 3. Code: L1: MAX = 10[NL]L2: count = 11[NL][ER]L3: assert count [LT]= MAX, f[DQ]count [LB]count[RB] exceeds MAX [LB]MAX[RB][DQ]
```

**Formatted target:**
```
Mistake: count is 11 on line 2 but assert on line 3 requires count [LT]= MAX which is 10. Reason: assert raises AssertionError when the condition evaluates to False; 11 [LT]= 10 is False. Fix: count = 10
```
Tokens: `63`

**Minimal fix (changed lines):**
```python
count = 10
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['on', 'Reason', 'when', 'requires', 'to', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `7e1ea8c6`

---

## Sample 14 — `AssertionError` | rc: `negative_value` | src: `hand_template_fallback`

**Snippet:**
```python
x = -5
assert x > 0, 'x must be positive'
```
**Real error:** `x must be positive` at line `2`

**Formatted input:**
```
Explain this Python error in simple terms. Error: AssertionError: x must be positive. Line 2. Code: L1: x = -5[NL][ER]L2: assert x > 0, [SQ]x must be positive[SQ]
```

**Formatted target:**
```
Mistake: x is -5 on line 1; assert x > 0 on line 2 evaluates to False. Reason: assert raises AssertionError when the condition is False; -5 > 0 is False. Fix: x = 1
```
Tokens: `64`

**Minimal fix (changed lines):**
```python
x = 1
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['on', 'Reason', 'when', 'to', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `2fd3a79f`

---

## Sample 15 — `NotImplementedError` | rc: `bare_raise_base_call` | src: `hand_template_fallback`

**Snippet:**
```python
class Animal:
    def speak(self):
        raise NotImplementedError
Animal().speak()
```
**Real error:** `` at line `3`

**Formatted input:**
```
Explain this Python error in simple terms. Error: NotImplementedError: no message. Line 3. Code: L1: class Animal:[NL]L2: [IN]def speak(self):[NL][ER]L3: [I2]raise NotImplementedError[NL]L4: Animal().speak()
```

**Formatted target:**
```
Mistake: Animal().speak() on line 4 calls speak on the abstract base class Animal. Reason: Animal.speak raises NotImplementedError to signal that subclasses must override it. Fix: class Dog(Animal):[NL][IN]def speak(self):[NL][I2]return [SQ]Woof[SQ][NL]Dog().speak()
```
Tokens: `101`

**Minimal fix (changed lines):**
```python
class Dog(Animal):
    def speak(self):
        return 'Woof'
Dog().speak()
```
**Fixed code exit code:** `0` | **fix_verified:** OK

**Round-trip:** input=OK target=OK
**Grounding:** VIOLATIONS: ['Dog', 'Woof', 'on', 'Reason', 'to', 'Fix', 'Mistake']
**Spell check:** OK
**skeleton_id:** `029ae6f9`

---

## Rule-Engine vs Reformatted Target – Comparison (Req 7)

### ZeroDivisionError
**Engine raw output:** Mistake: Division by zero at line 1 (Offending line: x = 10 / 0). Reason: Denominator evaluated to zero at runtime. Fix: Guard the division with an 'if' check (e.g., if divisor != 0:) before dividing.

**Reformatted target:**
```
Mistake: Division by zero at line 1 (Offending line: x = 10 / 0) Reason: Denominator evaluated to zero at runtime Fix: x = 10 / 1
```

**Assessment:** The reformatted target wins: it names the exact line and shows concrete code (`d = {'rate': 5}` after encoding) rather than the engine's generic 'Guard with if divisor != 0' advice. A model fine-tuned on concrete code snippets generalises better than one trained on advice prose.

### NameError
**Engine raw output:** Mistake: Using undefined variable 'x' at line 1 (Offending line: y = x + 1). Reason: Variable 'x' is referenced before being assigned or defined. Fix: Define or initialize variable 'x' in the enclosing scope before using it.

**Reformatted target:**
```
Mistake: Using undefined variable 'x' at line 1 (Offending line: y = x + 1) Reason: Variable 'x' is referenced before being assigned or defined Fix: x = 0
```

**Assessment:** The reformatted target wins: the engine says 'Define variable X in the enclosing scope', which is advice. The reformatted Fix is the actual line to add (`x = 0`). The model can copy or adapt that line to new inputs.

### TypeError
**Engine raw output:** Mistake: Mixing incompatible data types at line 2 (Offending line: print(d + {'y': 2})). Reason: Incompatible types cannot be combined directly (unsupported operand type(s) for +: 'dict' and 'dict'). Fix: Explicitly convert data types using str(), int(), or verify function parameter types.

**Reformatted target:**
```
Mistake: Mixing incompatible data types at line 2 (Offending line: print(d + [LB]'y': 2[RB])) Reason: Incompatible types cannot be combined directly (unsupported operand type(s) for +: 'dict' and 'dict') Fix: d.update([LB][SQ]y[SQ]: 2[RB])[NL]print(d)
```

**Assessment:** Mixed result: the engine's Reason correctly identifies the type mismatch. However it repeats the error message verbatim, which is circular. The reformatted Reason explains WHY types are incompatible and the Fix shows `str(42)` concretely.

### ValueError
**Engine raw output:** Mistake: Invalid value conversion at line 1 (Offending line: a, b = [1, 2, 3]). Reason: Value format does not match expected parser requirements (too many values to unpack (expected 2)). Fix: Validate string input format before parsing, or enclose conversion in a try...except ValueError block.

**Reformatted target:**
```
Mistake: Invalid value conversion at line 1 (Offending line: a, b = [1, 2, 3]) Reason: Value format does not match expected parser requirements (too many values to unpack (expected 2)) Fix: a, b, c = [1, 2, 3]
```

**Assessment:** The reformatted target wins: the engine gives generic 'validate before parsing' advice. The reformatted Fix shows the exact changed line (`a, b, c = [1, 2, 3]`), which directly teaches the model to count and balance unpack targets.

---

## Discarded Examples

| Error Type | Snippet | Reason |
|---|---|---|
| `NameError` | `def compute(): |     result = 42 | compute() | print(result)` | roundtrip_fail: in=char 65: " 'result' is" -> "'result' is " tgt=char 33: " 'res |
| `TypeError` | `print('Total: ' + 42)` | roundtrip_fail: in= tgt=char 80: " ' + 42)) Re" -> "'+ 42)) Reas" |
| `TypeError` | `name = 'Alice' | age = 30 | print('Name: ' + name + ', Age:` | roundtrip_fail: in= tgt=char 79: " ' + name + " -> "'+ name + '," |
| `RecursionError` | `def a(): |     return b() | def b(): |     return a() | a()` | over_128_tokens(138) |
| `NotImplementedError` | `class Cache: |     def get(self, key): |         raise NotI` | over_128_tokens(154) |

## Skeleton Counts and Phase B Proposal (Req 8)

| Error Type | Verified | Distinct Skeletons | Est. Realistic | Phase B (4 variants) |
|---|---|---|---|---|
| `ZeroDivisionError` | 6 | 6 | ~15 | 60 |
| `NameError` | 5 | 5 | ~18 | 72 |
| `TypeError` | 3 | 3 | ~16 | 64 |
| `ValueError` | 5 | 5 | ~16 | 64 |
| `RecursionError` | 5 | 5 | ~14 | 56 |
| `OverflowError` | 5 | 4 | ~8 | 32 |
| `AssertionError` | 5 | 5 | ~14 | 56 |
| `NotImplementedError` | 3 | 1 | ~12 | 48 |

**Phase B recommendation:** 8 error types, ~12 distinct skeletons each, 4 variants per skeleton
= **~384 training examples**. Prefer depth (12+ skeletons) over breadth (many shallow types).

---
*Phase A Revision 2b complete. Awaiting approval for Phase B.*