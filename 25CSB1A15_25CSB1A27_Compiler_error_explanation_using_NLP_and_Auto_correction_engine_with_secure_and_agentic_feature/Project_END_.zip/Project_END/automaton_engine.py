"""automaton_engine.py - Thompson NFA → Subset Construction DFA → Hopcroft Minimization.

Feature 1 of IntelliFix (TOC Project):
  - Thompson's NFA construction from a simple regex syntax
  - Subset construction (NFA → DFA)
  - Hopcroft's minimization algorithm  O(n log n)
  - String stepper / step-trace
  - Mermaid diagram generation (flowchart LR)
  - Five preset DFAs: identifier, float, int_underscore, email_simple, hex

Supported regex syntax
----------------------
  Literals  : single ASCII chars, \\.  \\d  \\w  \\s
  Character classes : [a-z]  [0-9]  [A-Z]  combined ranges/literals
  Dot       : . (any single char – represented as the special symbol ANY)
  Operators : |  *  +  ?  concatenation  ()

Only the Python standard library is used.
"""

from __future__ import annotations

import string
from collections import deque
from typing import Dict, FrozenSet, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# NFA State
# ---------------------------------------------------------------------------

class NFAState:
    """A single state in a Thompson NFA.

    Attributes:
        id: Unique integer identifier.
        transitions: Mapping from symbol (str) or None (epsilon) to a set of
            target state ids.  ``None`` represents an ε-transition.
    """

    _counter: int = 0

    def __init__(self) -> None:
        self.id: int = NFAState._counter
        NFAState._counter += 1
        self.transitions: Dict[Optional[str], Set[int]] = {}

    def add_transition(self, symbol: Optional[str], target_id: int) -> None:
        """Add a transition on *symbol* (None = epsilon) to *target_id*."""
        self.transitions.setdefault(symbol, set()).add(target_id)

    def __repr__(self) -> str:  # pragma: no cover
        return f"NFAState(id={self.id})"


# ---------------------------------------------------------------------------
# NFA fragment helper (used during Thompson construction)
# ---------------------------------------------------------------------------

class _NFA:
    """A Thompson NFA fragment, identified by its start and accept state ids."""

    def __init__(self, states: Dict[int, NFAState], start: int, accept: int) -> None:
        self.states = states          # id → NFAState
        self.start = start
        self.accept = accept


def _fresh_state(registry: Dict[int, NFAState]) -> NFAState:
    """Create a new NFAState and register it."""
    s = NFAState()
    registry[s.id] = s
    return s


# ---------------------------------------------------------------------------
# Regex tokeniser / parser (recursive descent)
# ---------------------------------------------------------------------------

_ANY_SYMBOL = "\x00ANY\x00"          # internal sentinel for '.'
_EPSILON_SYMBOL = None               # epsilon


def _expand_escape(ch: str) -> List[str]:
    """Return the list of concrete characters represented by an escape sequence.

    Supported: \\d  \\w  \\s  \\.  (and any other escaped literal).
    """
    if ch == "d":
        return list(string.digits)
    if ch == "w":
        return list(string.ascii_letters + string.digits + "_")
    if ch == "s":
        return list(" \t\n\r\f\v")
    return [ch]   # \\. → '.'  or any literal escaped char


def _expand_char_class(spec: str) -> List[str]:
    """Expand a bracket expression like ``a-z0-9_`` into a flat character list.

    Args:
        spec: The inner content of ``[...]`` (without the brackets).

    Returns:
        Sorted, deduplicated list of characters represented by the class.
    """
    chars: Set[str] = set()
    negated = False
    idx = 0
    if spec and spec[0] == "^":
        negated = True
        idx = 1
    while idx < len(spec):
        c = spec[idx]
        if c == "\\" and idx + 1 < len(spec):
            chars.update(_expand_escape(spec[idx + 1]))
            idx += 2
        elif idx + 2 < len(spec) and spec[idx + 1] == "-":
            start_c, end_c = spec[idx], spec[idx + 2]
            if ord(start_c) > ord(end_c):
                raise ValueError(f"Invalid character class range '{start_c}-{end_c}': start exceeds end")
            chars.update(chr(o) for o in range(ord(start_c), ord(end_c) + 1))
            idx += 3
        else:
            chars.add(c)
            idx += 1
    if negated:
        all_print = set(string.printable)
        chars = all_print - chars
    return sorted(chars)


# ---------------------------------------------------------------------------
# Regex → list-of-tokens (lexer)
# ---------------------------------------------------------------------------

def _tokenise(pattern: str) -> List:
    """Convert a regex pattern string to a flat list of tokens.

    Token types:
        ``("CHAR", ch)``        – single literal character
        ``("CLASS", [chars])``  – character class (expanded)
        ``("ANY",)``            – dot wildcard
        ``("PIPE",)``           – |
        ``("STAR",)``           – *
        ``("PLUS",)``           – +
        ``("QUEST",)``          – ?
        ``("LPAREN",)``         – (
        ``("RPAREN",)``         – )
    """
    tokens = []
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == "\\":
            if i + 1 >= len(pattern):
                raise ValueError("Trailing backslash in pattern")
            escaped = pattern[i + 1]
            chars = _expand_escape(escaped)
            if len(chars) == 1:
                tokens.append(("CHAR", chars[0]))
            else:
                tokens.append(("CLASS", chars))
            i += 2
        elif c == "[":
            j = i + 1
            while j < len(pattern):
                if pattern[j] == "\\":
                    j += 2
                    continue
                if pattern[j] == "]":
                    break
                j += 1
            if j >= len(pattern):
                raise ValueError("Unclosed character class '['")
            inner = pattern[i + 1: j]
            tokens.append(("CLASS", _expand_char_class(inner)))
            i = j + 1
        elif c == ".":
            tokens.append(("ANY",))
            i += 1
        elif c == "|":
            tokens.append(("PIPE",))
            i += 1
        elif c == "*":
            tokens.append(("STAR",))
            i += 1
        elif c == "+":
            tokens.append(("PLUS",))
            i += 1
        elif c == "?":
            tokens.append(("QUEST",))
            i += 1
        elif c == "(":
            tokens.append(("LPAREN",))
            i += 1
        elif c == ")":
            tokens.append(("RPAREN",))
            i += 1
        else:
            tokens.append(("CHAR", c))
            i += 1
    return tokens


# ---------------------------------------------------------------------------
# Thompson's NFA construction
# ---------------------------------------------------------------------------

def _nfa_literal(ch: str, registry: Dict[int, NFAState]) -> _NFA:
    """NFA that accepts exactly the single character *ch*."""
    start = _fresh_state(registry)
    accept = _fresh_state(registry)
    start.add_transition(ch, accept.id)
    return _NFA(registry, start.id, accept.id)


def _nfa_any(registry: Dict[int, NFAState]) -> _NFA:
    """NFA that accepts any single character (dot wildcard)."""
    start = _fresh_state(registry)
    accept = _fresh_state(registry)
    start.add_transition(_ANY_SYMBOL, accept.id)
    return _NFA(registry, start.id, accept.id)


def _nfa_union(a: _NFA, b: _NFA, registry: Dict[int, NFAState]) -> _NFA:
    """Thompson union: NFA accepting L(a) ∪ L(b)."""
    start = _fresh_state(registry)
    accept = _fresh_state(registry)
    start.add_transition(None, a.start)
    start.add_transition(None, b.start)
    registry[a.accept].add_transition(None, accept.id)
    registry[b.accept].add_transition(None, accept.id)
    return _NFA(registry, start.id, accept.id)


def _nfa_concat(a: _NFA, b: _NFA, registry: Dict[int, NFAState]) -> _NFA:
    """Thompson concatenation: NFA accepting L(a)·L(b)."""
    registry[a.accept].add_transition(None, b.start)
    return _NFA(registry, a.start, b.accept)


def _nfa_star(a: _NFA, registry: Dict[int, NFAState]) -> _NFA:
    """Thompson Kleene star: NFA accepting L(a)*."""
    start = _fresh_state(registry)
    accept = _fresh_state(registry)
    start.add_transition(None, a.start)
    start.add_transition(None, accept.id)
    registry[a.accept].add_transition(None, a.start)
    registry[a.accept].add_transition(None, accept.id)
    return _NFA(registry, start.id, accept.id)


def _nfa_plus(a: _NFA, registry: Dict[int, NFAState]) -> _NFA:
    """Thompson one-or-more: NFA accepting L(a)+  (= a·a*)."""
    star_copy_registry: Dict[int, NFAState] = {}
    # We need a fresh copy of 'a' for the star part; simpler: aa*
    # Build a* from the same fragment and concat
    a_star = _nfa_star(a, registry)
    # a was already consumed by star; re-read accept and wire concat
    # Actually _nfa_star already modified a.accept; return as-is treating start as "one pass then loop"
    # Easier: just wire: start --ε--> a.start, a.accept --ε--> a.start (loop), a.accept --ε--> new_accept
    # But _nfa_star already did that correctly, returning (new_start → a.start → ... → new_accept).
    # For +: we need at least one, so: a_start → ... → a_accept → (loop or end)
    # Re-implement correctly:
    # At this point a_star = new NFA with start and accept, and a.accept has been patched.
    # The a_star.start has: ε to a.start AND ε to a_star.accept
    # We want + = a then a* but a is consumed.  Instead patch:
    # Remove the ε edge from a_star.start to a_star.accept (makes it mandatory first pass)
    s = registry[a_star.start]
    s.transitions[None].discard(a_star.accept)
    if not s.transitions[None]:
        del s.transitions[None]
    return a_star


def _nfa_question(a: _NFA, registry: Dict[int, NFAState]) -> _NFA:
    """Thompson zero-or-one: NFA accepting L(a)?."""
    start = _fresh_state(registry)
    accept = _fresh_state(registry)
    start.add_transition(None, a.start)
    start.add_transition(None, accept.id)
    registry[a.accept].add_transition(None, accept.id)
    return _NFA(registry, start.id, accept.id)


# ---------------------------------------------------------------------------
# Recursive-descent parser over token list
# ---------------------------------------------------------------------------

class _Parser:
    """LL(1) recursive-descent parser for the regex token list.

    Grammar (after precedence):
        expr    → concat ('|' concat)*
        concat  → quantified quantified*
        quantified → atom ('*' | '+' | '?')?
        atom    → CHAR | CLASS | ANY | '(' expr ')'
    """

    def __init__(self, tokens: List, registry: Dict[int, NFAState]) -> None:
        self._tokens = tokens
        self._pos = 0
        self._registry = registry

    def _peek(self):
        if self._pos < len(self._tokens):
            return self._tokens[self._pos]
        return None

    def _consume(self):
        tok = self._tokens[self._pos]
        self._pos += 1
        return tok

    def parse(self) -> _NFA:
        """Parse the full token list and return the root NFA fragment."""
        nfa = self._expr()
        if self._pos < len(self._tokens):
            raise ValueError(f"Unexpected token at position {self._pos}: {self._peek()}")
        return nfa

    def _expr(self) -> _NFA:
        """expr → concat ('|' concat)*"""
        left = self._concat()
        while self._peek() and self._peek()[0] == "PIPE":
            self._consume()   # consume '|'
            right = self._concat()
            left = _nfa_union(left, right, self._registry)
        return left

    def _concat(self) -> _NFA:
        """concat → quantified quantified*"""
        result = self._quantified()
        while True:
            tok = self._peek()
            if tok is None or tok[0] in ("PIPE", "RPAREN"):
                break
            right = self._quantified()
            result = _nfa_concat(result, right, self._registry)
        return result

    def _quantified(self) -> _NFA:
        """quantified → atom ('*' | '+' | '?')?"""
        base = self._atom()
        tok = self._peek()
        if tok is None:
            return base
        if tok[0] == "STAR":
            self._consume()
            return _nfa_star(base, self._registry)
        if tok[0] == "PLUS":
            self._consume()
            return _nfa_plus(base, self._registry)
        if tok[0] == "QUEST":
            self._consume()
            return _nfa_question(base, self._registry)
        return base

    def _atom(self) -> _NFA:
        """atom → CHAR | CLASS | ANY | '(' expr ')'"""
        tok = self._peek()
        if tok is None:
            raise ValueError("Unexpected end of pattern inside atom")
        if tok[0] == "CHAR":
            self._consume()
            return _nfa_literal(tok[1], self._registry)
        if tok[0] == "CLASS":
            self._consume()
            # Build a union NFA over all chars in the class
            chars = tok[1]
            if not chars:
                raise ValueError("Empty character class")
            fragments = [_nfa_literal(ch, self._registry) for ch in chars]
            result = fragments[0]
            for frag in fragments[1:]:
                result = _nfa_union(result, frag, self._registry)
            return result
        if tok[0] == "ANY":
            self._consume()
            return _nfa_any(self._registry)
        if tok[0] == "LPAREN":
            self._consume()
            inner = self._expr()
            if self._peek() is None or self._peek()[0] != "RPAREN":
                raise ValueError("Missing closing ')'")
            self._consume()
            return inner
        raise ValueError(f"Unexpected token in atom: {tok}")


def regex_to_nfa(pattern: str) -> Tuple[_NFA, Dict[int, NFAState]]:
    """Build a Thompson NFA from *pattern*.

    Args:
        pattern: Regex pattern string using the supported syntax.

    Returns:
        ``(nfa_fragment, registry)`` where *registry* maps state id → NFAState.

    Raises:
        ValueError: On malformed patterns.
    """
    NFAState._counter = 0  # reset for reproducible ids
    registry: Dict[int, NFAState] = {}
    tokens = _tokenise(pattern)
    parser = _Parser(tokens, registry)
    nfa = parser.parse()
    return nfa, registry


# ---------------------------------------------------------------------------
# Subset construction (NFA → DFA)
# ---------------------------------------------------------------------------

def _epsilon_closure(state_ids: FrozenSet[int], registry: Dict[int, NFAState]) -> FrozenSet[int]:
    """Compute the ε-closure of a set of NFA state ids.

    Uses BFS/DFS over epsilon (None) transitions.
    """
    stack = list(state_ids)
    closure: Set[int] = set(state_ids)
    while stack:
        sid = stack.pop()
        for target in registry[sid].transitions.get(None, set()):
            if target not in closure:
                closure.add(target)
                stack.append(target)
    return frozenset(closure)


def _nfa_move(state_ids: FrozenSet[int], symbol: str, registry: Dict[int, NFAState]) -> FrozenSet[int]:
    """Compute the set of NFA states reachable from *state_ids* on *symbol*."""
    result: Set[int] = set()
    for sid in state_ids:
        s = registry[sid]
        # regular symbol
        result.update(s.transitions.get(symbol, set()))
        # ANY symbol matches any non-epsilon input
        result.update(s.transitions.get(_ANY_SYMBOL, set()))
    return frozenset(result)


class BuiltDFA:
    """A DFA produced by subset construction or hand-built for presets.

    Attributes:
        states: Set of state names (strings).
        alphabet: Set of input symbols (strings).
        transitions: ``{(state, symbol): next_state}``
        start_state: Name of the start state.
        accepting_states: Set of accepting state names.
        name: Human-readable label.
        total_nfa_states: Number of NFA states before conversion (informational).
        minimized_states: Set after Hopcroft minimization (populated later).
    """

    def __init__(
        self,
        states: Set[str],
        alphabet: Set[str],
        transitions: Dict[Tuple[str, str], str],
        start_state: str,
        accepting_states: Set[str],
        name: str = "DFA",
        total_nfa_states: int = 0,
    ) -> None:
        self.states = set(states)
        self.alphabet = set(alphabet)
        self.transitions = dict(transitions)
        self.start_state = start_state
        self.accepting_states = set(accepting_states)
        self.name = name
        self.total_nfa_states = total_nfa_states
        self.minimized_states: int = len(states)   # updated by minimize()

    def accepts(self, s: str) -> bool:
        """Return True if *s* is accepted by this DFA."""
        state = self.start_state
        for ch in s:
            key = (state, ch)
            if key in self.transitions:
                state = self.transitions[key]
            else:
                # try ANY symbol
                any_key = (state, _ANY_SYMBOL)
                if any_key in self.transitions:
                    state = self.transitions[any_key]
                else:
                    return False
        return state in self.accepting_states


MAX_DFA_STATES = 256
MAX_REGEX_PATTERN_LEN = 256

def nfa_to_dfa(nfa: _NFA, registry: Dict[int, NFAState], name: str = "DFA") -> BuiltDFA:
    """Convert a Thompson NFA to a DFA using the subset construction algorithm.

    Args:
        nfa: The root NFA fragment (start + accept state ids).
        registry: Map from state id → NFAState.
        name: Label for the resulting DFA.

    Returns:
        A :class:`BuiltDFA` instance.
    """
    # Gather all symbols used by the NFA (excluding epsilon and ANY for now)
    all_symbols: Set[str] = set()
    has_any = False
    for s in registry.values():
        for sym in s.transitions:
            if sym is None:
                continue
            if sym == _ANY_SYMBOL:
                has_any = True
            else:
                all_symbols.add(sym)

    start_closure = _epsilon_closure(frozenset([nfa.start]), registry)
    # Map frozenset of NFA state ids → DFA state name
    dfa_state_map: Dict[FrozenSet[int], str] = {}
    state_counter = [0]

    def get_name(fs: FrozenSet[int]) -> str:
        if fs not in dfa_state_map:
            dfa_state_map[fs] = f"D{state_counter[0]}"
            state_counter[0] += 1
        return dfa_state_map[fs]

    get_name(start_closure)

    dfa_transitions: Dict[Tuple[str, str], str] = {}
    dfa_accepting: Set[str] = set()
    worklist: deque = deque([start_closure])
    visited: Set[FrozenSet[int]] = {start_closure}

    while worklist:
        if len(visited) > MAX_DFA_STATES:
            raise ValueError(
                f"Automaton state complexity limit exceeded (maximum {MAX_DFA_STATES} DFA states allowed). "
                "Regex is too complex or non-deterministic."
            )
        current_fs = worklist.popleft()
        current_name = get_name(current_fs)
        if nfa.accept in current_fs:
            dfa_accepting.add(current_name)

        symbols_to_try = set(all_symbols)
        if has_any:
            symbols_to_try.add(_ANY_SYMBOL)

        for sym in symbols_to_try:
            move_result = _nfa_move(current_fs, sym, registry)
            if not move_result:
                continue
            next_closure = _epsilon_closure(move_result, registry)
            if not next_closure:
                continue
            next_name = get_name(next_closure)
            dfa_transitions[(current_name, sym)] = next_name
            if next_closure not in visited:
                visited.add(next_closure)
                worklist.append(next_closure)

    dfa_states = set(dfa_state_map.values())
    return BuiltDFA(
        states=dfa_states,
        alphabet=all_symbols | ({_ANY_SYMBOL} if has_any else set()),
        transitions=dfa_transitions,
        start_state=get_name(start_closure),
        accepting_states=dfa_accepting,
        name=name,
        total_nfa_states=len(registry),
    )


# ---------------------------------------------------------------------------
# Hopcroft's minimization  O(n log n)
# ---------------------------------------------------------------------------

def minimize_dfa(dfa: BuiltDFA) -> BuiltDFA:
    """Minimize *dfa* using Hopcroft's partition-refinement algorithm.

    Args:
        dfa: A :class:`BuiltDFA` to minimize.

    Returns:
        A new minimized :class:`BuiltDFA`.  The original is not modified.
    """
    # Only keep reachable states
    reachable = _reachable_states(dfa)
    states = reachable
    alphabet = dfa.alphabet

    accepting = states & dfa.accepting_states
    non_accepting = states - accepting

    # Build reverse transition table: sym → {target_state: set of source states}
    reverse: Dict[str, Dict[str, Set[str]]] = {sym: {} for sym in alphabet}
    for (src, sym), tgt in dfa.transitions.items():
        if src in states and tgt in states:
            reverse[sym].setdefault(tgt, set()).add(src)

    # Initial partition
    partitions: List[FrozenSet[str]] = []
    if accepting:
        partitions.append(frozenset(accepting))
    if non_accepting:
        partitions.append(frozenset(non_accepting))

    # Map state → partition index
    state_to_part: Dict[str, int] = {}
    for i, part in enumerate(partitions):
        for s in part:
            state_to_part[s] = i

    # Worklist: initialize with all initial partitions
    worklist: deque = deque(partitions)

    while worklist:
        splitter = worklist.popleft()
        for sym in alphabet:
            # X = set of states that transition into 'splitter' on 'sym'
            x: Set[str] = set()
            for tgt in splitter:
                x.update(reverse[sym].get(tgt, set()))
            if not x:
                continue

            new_partitions: List[FrozenSet[str]] = []
            for part in partitions:
                inter = part & x
                diff = part - x
                if inter and diff:
                    new_partitions.append(frozenset(inter))
                    new_partitions.append(frozenset(diff))
                    # Update state_to_part
                    new_idx_inter = len(new_partitions) - 2
                    new_idx_diff = len(new_partitions) - 1
                    # We'll rebuild state_to_part after the loop
                else:
                    new_partitions.append(part)

            if len(new_partitions) != len(partitions):
                partitions = new_partitions
                # Rebuild state_to_part
                state_to_part = {}
                for i, part in enumerate(partitions):
                    for s in part:
                        state_to_part[s] = i
                # Add smaller of inter/diff to worklist
                # (approximation: add both)
                for new_part in new_partitions:
                    if new_part not in worklist:
                        worklist.append(new_part)

    # Build minimized DFA from partitions
    # Representative of each partition = smallest state name
    def rep(part: FrozenSet[str]) -> str:
        return min(part)

    part_states: Set[str] = set()
    part_accepting: Set[str] = set()
    part_transitions: Dict[Tuple[str, str], str] = {}

    for part in partitions:
        r = rep(part)
        part_states.add(r)
        if part & dfa.accepting_states:
            part_accepting.add(r)

    for part in partitions:
        r = rep(part)
        any_state = next(iter(part))
        for sym in alphabet:
            tgt = dfa.transitions.get((any_state, sym))
            if tgt and tgt in states:
                tgt_part = partitions[state_to_part[tgt]]
                part_transitions[(r, sym)] = rep(tgt_part)

    start_part_idx = state_to_part.get(dfa.start_state, 0)
    start_part = partitions[start_part_idx]
    min_start = rep(start_part)

    result = BuiltDFA(
        states=part_states,
        alphabet=alphabet,
        transitions=part_transitions,
        start_state=min_start,
        accepting_states=part_accepting,
        name=dfa.name + " (minimized)",
        total_nfa_states=dfa.total_nfa_states,
    )
    result.minimized_states = len(part_states)
    # Also record original state count on original dfa
    dfa.minimized_states = len(part_states)
    return result


def _reachable_states(dfa: BuiltDFA) -> Set[str]:
    """Return the set of states reachable from the start state."""
    visited: Set[str] = set()
    stack = [dfa.start_state]
    while stack:
        s = stack.pop()
        if s in visited:
            continue
        visited.add(s)
        for sym in dfa.alphabet:
            tgt = dfa.transitions.get((s, sym))
            if tgt:
                stack.append(tgt)
    return visited


# ---------------------------------------------------------------------------
# Step Trace
# ---------------------------------------------------------------------------

def step_trace(dfa: BuiltDFA, input_string: str) -> dict:
    """Trace the DFA on *input_string* step-by-step.

    Args:
        dfa: A :class:`BuiltDFA` to run.
        input_string: The string to test.

    Returns:
        A dict with keys:
            - ``accepted`` (bool)
            - ``steps`` (list of step dicts)
            - ``total_states`` (int) – states before minimization
            - ``minimized_states`` (int) – states after minimization
            - ``name`` (str)
    """
    steps = []
    state = dfa.start_state
    dead = False

    for i, ch in enumerate(input_string):
        from_state = state
        # Try exact symbol first, then ANY
        key = (state, ch)
        if key in dfa.transitions:
            next_state = dfa.transitions[key]
        elif (state, _ANY_SYMBOL) in dfa.transitions:
            next_state = dfa.transitions[(state, _ANY_SYMBOL)]
        else:
            next_state = "DEAD"
            dead = True

        is_accepting = next_state in dfa.accepting_states
        steps.append({
            "step": i,
            "char": ch,
            "from_state": from_state,
            "to_state": next_state,
            "is_accepting": is_accepting,
            "is_dead": dead,
        })
        state = next_state
        if dead:
            break

    accepted = (not dead) and (state in dfa.accepting_states)
    return {
        "accepted": accepted,
        "steps": steps,
        "total_states": len(dfa.states),
        "minimized_states": dfa.minimized_states,
        "name": dfa.name,
    }


# ---------------------------------------------------------------------------
# Mermaid diagram generation
# ---------------------------------------------------------------------------

def _safe_label(s: str) -> str:
    """Escape a string for use as a Mermaid node label."""
    return s.replace('"', "'").replace("<", "lt").replace(">", "gt")


def _sym_label(sym: str) -> str:
    """Human-readable label for an alphabet symbol."""
    if sym == _ANY_SYMBOL:
        return "."
    return sym.replace('"', '#quot;')


def dfa_to_mermaid(dfa: BuiltDFA, highlight_path: Optional[List[str]] = None) -> str:
    """Generate a Mermaid ``flowchart LR`` diagram for *dfa*.

    Args:
        dfa: The DFA to visualize.
        highlight_path: Optional list of state names forming a path to highlight
            in red.  If provided, transitions along this path are styled with a
            ``:::red`` classDef and thick arrows.

    Returns:
        A string containing the complete Mermaid diagram.
    """
    lines = ["flowchart LR"]
    lines.append("    classDef accepting fill:#6fdc8c,stroke:#198038,color:#000")
    lines.append("    classDef dead fill:#fa4d56,stroke:#a2191f,color:#fff")
    lines.append("    classDef highlight stroke:#ff0000,stroke-width:3px,color:#ff0000")

    # Determine highlight edges
    highlight_edges: Set[Tuple[str, str]] = set()
    if highlight_path and len(highlight_path) >= 2:
        for i in range(len(highlight_path) - 1):
            highlight_edges.add((highlight_path[i], highlight_path[i + 1]))

    # Node definitions
    for state in sorted(dfa.states):
        label = _safe_label(state)
        if state == dfa.start_state and state in dfa.accepting_states:
            lines.append(f'    {state}(["▶ {label} ✓"]):::accepting')
        elif state == dfa.start_state:
            lines.append(f'    {state}(["▶ {label}"])')
        elif state in dfa.accepting_states:
            lines.append(f'    {state}(("{label} ✓")):::accepting')
        else:
            lines.append(f'    {state}["{label}"]')

    # Group transitions by (src, tgt) to merge labels
    edge_labels: Dict[Tuple[str, str], List[str]] = {}
    for (src, sym), tgt in sorted(dfa.transitions.items()):
        edge_labels.setdefault((src, tgt), []).append(_sym_label(sym))

    for (src, tgt), syms in sorted(edge_labels.items()):
        # Truncate very long label lists
        label_str = ", ".join(sorted(syms)[:8])
        if len(syms) > 8:
            label_str += f", …+{len(syms)-8}"
        if (src, tgt) in highlight_edges:
            lines.append(f'    {src} --"{label_str}"--> {tgt}:::highlight')
        else:
            lines.append(f'    {src} --"{label_str}"--> {tgt}')

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Preset DFAs  (hand-built for performance & correctness; same BuiltDFA API)
# ---------------------------------------------------------------------------

def _build_identifier_dfa() -> BuiltDFA:
    """DFA for C-style identifiers: ``[A-Za-z_][A-Za-z0-9_]*``."""
    alpha = set(string.ascii_letters) | {"_"}
    alnum = set(string.ascii_letters + string.digits) | {"_"}

    states = {"START", "IDENT", "DEAD"}
    transitions: Dict[Tuple[str, str], str] = {}
    for c in alpha:
        transitions[("START", c)] = "IDENT"
    for c in alnum:
        transitions[("IDENT", c)] = "IDENT"

    dfa = BuiltDFA(
        states=states,
        alphabet=alpha | alnum,
        transitions=transitions,
        start_state="START",
        accepting_states={"IDENT"},
        name="identifier",
        total_nfa_states=len(states) + 2,
    )
    dfa.minimized_states = 2  # START, IDENT (DEAD implicit)
    return dfa


def _build_float_dfa() -> BuiltDFA:
    r"""DFA for decimal/float: ``[0-9]+(\.[0-9]+)?``."""
    digits = set(string.digits)
    states = {"q0", "q_int", "q_dot", "q_float", "DEAD"}
    transitions: Dict[Tuple[str, str], str] = {}
    for d in digits:
        transitions[("q0", d)] = "q_int"
        transitions[("q_int", d)] = "q_int"
        transitions[("q_dot", d)] = "q_float"
        transitions[("q_float", d)] = "q_float"
    transitions[("q_int", ".")] = "q_dot"

    dfa = BuiltDFA(
        states=states,
        alphabet=digits | {"."},
        transitions=transitions,
        start_state="q0",
        accepting_states={"q_int", "q_float"},
        name="float",
        total_nfa_states=len(states) + 4,
    )
    dfa.minimized_states = 4  # q0, q_int, q_dot, q_float
    return dfa


def _build_int_underscore_dfa() -> BuiltDFA:
    """DFA for integers with underscores: ``[0-9](_?[0-9])*``."""
    digits = set(string.digits)
    states = {"q0", "q_digit", "q_under", "DEAD"}
    transitions: Dict[Tuple[str, str], str] = {}
    for d in digits:
        transitions[("q0", d)] = "q_digit"
        transitions[("q_digit", d)] = "q_digit"
        transitions[("q_under", d)] = "q_digit"
    transitions[("q_digit", "_")] = "q_under"

    dfa = BuiltDFA(
        states=states,
        alphabet=digits | {"_"},
        transitions=transitions,
        start_state="q0",
        accepting_states={"q_digit"},
        name="int_underscore",
        total_nfa_states=len(states) + 2,
    )
    dfa.minimized_states = 3
    return dfa


def _build_email_simple_dfa() -> BuiltDFA:
    """DFA for simplified email: ``[a-z0-9]+@[a-z0-9]+\\.[a-z]+``."""
    lower = set(string.ascii_lowercase)
    digits = set(string.digits)
    local_chars = lower | digits      # before @
    domain_chars = lower | digits     # between @ and .
    tld_chars = lower                 # after .

    states = {"q0", "q_local", "q_at", "q_domain", "q_dot", "q_tld", "DEAD"}
    transitions: Dict[Tuple[str, str], str] = {}

    for c in local_chars:
        transitions[("q0", c)] = "q_local"
        transitions[("q_local", c)] = "q_local"
    transitions[("q_local", "@")] = "q_at"
    for c in domain_chars:
        transitions[("q_at", c)] = "q_domain"
        transitions[("q_domain", c)] = "q_domain"
    transitions[("q_domain", ".")] = "q_dot"
    for c in tld_chars:
        transitions[("q_dot", c)] = "q_tld"
        transitions[("q_tld", c)] = "q_tld"

    dfa = BuiltDFA(
        states=states,
        alphabet=local_chars | {"@", "."},
        transitions=transitions,
        start_state="q0",
        accepting_states={"q_tld"},
        name="email_simple",
        total_nfa_states=len(states) + 5,
    )
    dfa.minimized_states = 6
    return dfa


def _build_hex_dfa() -> BuiltDFA:
    """DFA for hex literals: ``0x[0-9A-Fa-f]+``."""
    hex_chars = set(string.hexdigits) - {"_"}  # 0-9 A-F a-f
    states = {"q0", "q_0", "q_x", "q_hex", "DEAD"}
    transitions: Dict[Tuple[str, str], str] = {}
    transitions[("q0", "0")] = "q_0"
    transitions[("q_0", "x")] = "q_x"
    transitions[("q_0", "X")] = "q_x"
    for c in hex_chars:
        transitions[("q_x", c)] = "q_hex"
        transitions[("q_hex", c)] = "q_hex"

    dfa = BuiltDFA(
        states=states,
        alphabet={"0", "x", "X"} | hex_chars,
        transitions=transitions,
        start_state="q0",
        accepting_states={"q_hex"},
        name="hex",
        total_nfa_states=len(states) + 2,
    )
    dfa.minimized_states = 4
    return dfa


# ---------------------------------------------------------------------------
# Preset registry
# ---------------------------------------------------------------------------

_PRESET_BUILDERS = {
    "identifier": _build_identifier_dfa,
    "float": _build_float_dfa,
    "int_underscore": _build_int_underscore_dfa,
    "email_simple": _build_email_simple_dfa,
    "hex": _build_hex_dfa,
}

PRESET_DESCRIPTIONS = {
    "identifier": "C-style identifier: [A-Za-z_][A-Za-z0-9_]*",
    "float": "Decimal integer or float: [0-9]+([.][0-9]+)?",
    "int_underscore": "Integer with underscores: [0-9](_?[0-9])*",
    "email_simple": "Simplified email: [a-z0-9]+@[a-z0-9]+.[a-z]+",
    "hex": "Hexadecimal literal: 0x[0-9A-Fa-f]+",
}


def get_preset_dfa(preset_name: str) -> BuiltDFA:
    """Return a :class:`BuiltDFA` for the named preset.

    Args:
        preset_name: One of ``"identifier"``, ``"float"``, ``"int_underscore"``,
            ``"email_simple"``, ``"hex"``.

    Returns:
        A ready-to-use :class:`BuiltDFA` instance.

    Raises:
        KeyError: If the preset name is unknown.
    """
    if preset_name not in _PRESET_BUILDERS:
        raise KeyError(
            f"Unknown preset '{preset_name}'. "
            f"Available: {sorted(_PRESET_BUILDERS)}"
        )
    return _PRESET_BUILDERS[preset_name]()


def list_presets() -> List[dict]:
    """Return a list of preset descriptors for API consumption.

    Returns:
        List of ``{"name": str, "description": str}`` dicts.
    """
    return [
        {"name": name, "description": PRESET_DESCRIPTIONS[name]}
        for name in sorted(_PRESET_BUILDERS)
    ]


# ---------------------------------------------------------------------------
# Full pipeline helper: regex string → minimized DFA
# ---------------------------------------------------------------------------

def compile_regex(pattern: str, name: str = "regex_dfa") -> BuiltDFA:
    """Compile a regex *pattern* all the way to a minimized DFA.

    Pipeline: regex → Thompson NFA → Subset DFA → Hopcroft minimization.

    Args:
        pattern: Regex pattern string.
        name: Label for the DFA.

    Returns:
        Minimized :class:`BuiltDFA`.
    """
    if not isinstance(pattern, str):
        raise ValueError("Regex pattern must be a string")
    if len(pattern) > MAX_REGEX_PATTERN_LEN:
        raise ValueError(f"Regex pattern exceeds maximum length limit of {MAX_REGEX_PATTERN_LEN} characters.")

    nfa, registry = regex_to_nfa(pattern)
    dfa = nfa_to_dfa(nfa, registry, name=name)
    min_dfa = minimize_dfa(dfa)
    min_dfa.name = name
    return min_dfa
