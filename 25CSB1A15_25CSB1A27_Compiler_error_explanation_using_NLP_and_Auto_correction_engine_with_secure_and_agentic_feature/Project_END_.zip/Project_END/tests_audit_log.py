"""tests_audit_log.py - Unit Tests for Tamper-Evident Audit Log and Hash Chain.

Tests:
- Hash chain creation and validity across multiple events
- Edited line detection (tampering detected at exact line)
- Deleted line detection (broken prev_hash detected at exact line)
- Evidence redaction within log entries
- verify_log() diagnostic reports
- Socket guard ensuring zero real external network connections
"""

import json
import os
import socket
import tempfile
import unittest
from unittest.mock import patch

from security import audit_log


class TestAuditLog(unittest.TestCase):
    """Unit tests for security/audit_log.py."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1"):
                raise AssertionError(f"Real outbound network call to {address} attempted in test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_log_chain_validity(self):
        """Append-only events create an unbroken, cryptographically valid hash chain."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_p = os.path.join(tmpdir, "test_log.jsonl")

            e1 = audit_log.log_event(
                channel="input",
                decision="BLOCK",
                risk_score=70,
                action_attempted="injection_payload",
                category="AT-01",
                attack_id="AT-01-V1",
                evidence="Ignore security rules",
                log_path=log_p
            )
            self.assertEqual(e1["prev_hash"], audit_log.GENESIS_HASH)

            e2 = audit_log.log_event(
                channel="tool",
                decision="WARN",
                risk_score=40,
                action_attempted="read_file:test.py",
                category="AT-11",
                attack_id="AT-11-V1",
                evidence="Large scope",
                log_path=log_p
            )
            self.assertEqual(e2["prev_hash"], e1["hash"])

            e3 = audit_log.log_event(
                channel="output",
                decision="REDACT",
                risk_score=0,
                action_attempted="serialize",
                category="AT-15",
                attack_id="AT-15-V1",
                evidence="Key leaked",
                log_path=log_p
            )
            self.assertEqual(e3["prev_hash"], e2["hash"])

            # Verify unbroken log
            ok, line_num, reason = audit_log.verify_log(log_path=log_p)
            self.assertTrue(ok, f"Verification failed: {reason}")
            self.assertIsNone(line_num)
            self.assertIn("verified cleanly", reason.lower())

    def test_edited_line_detected(self):
        """Modifying content of any log line is detected by verify_log."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_p = os.path.join(tmpdir, "test_log.jsonl")

            for i in range(1, 4):
                audit_log.log_event(
                    channel="tool",
                    decision="BLOCK",
                    risk_score=50 + i * 10,
                    action_attempted=f"action_{i}",
                    category=f"AT-0{i}",
                    log_path=log_p
                )

            # Edit line 2 (tamper risk_score without updating hash)
            with open(log_p, "r", encoding="utf-8") as f:
                lines = f.readlines()

            entry_2 = json.loads(lines[1])
            entry_2["risk_score"] = 0  # Tamper
            lines[1] = json.dumps(entry_2) + "\n"

            with open(log_p, "w", encoding="utf-8") as f:
                f.writelines(lines)

            ok, tampered_line, reason = audit_log.verify_log(log_path=log_p)
            self.assertFalse(ok)
            self.assertEqual(tampered_line, 2)
            self.assertIn("tampered entry at line 2", reason.lower())

    def test_deleted_line_detected(self):
        """Deleting any line breaks the hash chain linkage."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_p = os.path.join(tmpdir, "test_log.jsonl")

            for i in range(1, 5):
                audit_log.log_event(
                    channel="input",
                    decision="ALLOW" if i == 1 else "BLOCK",
                    risk_score=i * 20,
                    action_attempted=f"action_{i}",
                    category=f"AT-0{i}",
                    log_path=log_p
                )

            # Delete line 2
            with open(log_p, "r", encoding="utf-8") as f:
                lines = f.readlines()

            del lines[1]  # Remove line 2

            with open(log_p, "w", encoding="utf-8") as f:
                f.writelines(lines)

            # Now what was line 3 has prev_hash pointing to line 2 (which is gone)
            ok, tampered_line, reason = audit_log.verify_log(log_path=log_p)
            self.assertFalse(ok)
            self.assertEqual(tampered_line, 2)  # New line 2 fails prev_hash check
            self.assertIn("hash chain broken", reason.lower())

    def test_evidence_redacted_before_logging(self):
        """Sensitive API keys and personal data in evidence are redacted in the log."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_p = os.path.join(tmpdir, "test_log.jsonl")

            audit_log.log_event(
                channel="output",
                decision="BLOCK",
                risk_score=90,
                action_attempted="leak",
                evidence="Leaked key: " + "AIza" + "SyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6 and phone 555-123-4567",
                log_path=log_p
            )

            with open(log_p, "r", encoding="utf-8") as f:
                content = f.read()

            self.assertNotIn("AIzaSyA1B2C3", content)
            self.assertNotIn("555-123-4567", content)
            self.assertIn("[REDACTED_GEMINI_KEY]", content)
            self.assertIn("[REDACTED_PHONE]", content)


if __name__ == "__main__":
    unittest.main()
