"""tests_blast_radius.py - Unit & Integration Tests for AST Blast-Radius Limiter.

Validates:
1. Exact Zhang-Shasha Tree Edit Distance on Python ASTs.
2. Identical AST TED=0, single-node mutation TED=1.
3. Top-level scope extraction and locality analysis.
4. Detection of out-of-scope mutations (AI secretly altering an unrelated function).
5. Detection of structural blast-radius escalation (excessive AST subtree churn).
6. Integration with Code Guard (Gate 3) in the AAI Shield.
"""

import ast
import unittest

from security import blast_radius, code_guard


class TestZhangShashaTED(unittest.TestCase):
    """Tests for pure AST Tree Edit Distance computation."""

    def test_identical_trees_zero_distance(self):
        """Identical ASTs produce TED of 0."""
        code = "def add(a, b):\n    return a + b\n"
        t1 = ast.parse(code)
        t2 = ast.parse(code)
        ted = blast_radius.zhang_shasha_ted(t1, t2)
        self.assertEqual(ted, 0)

    def test_single_constant_change(self):
        """Mutating a single constant produces minimal TED of 1."""
        t1 = ast.parse("x = 10")
        t2 = ast.parse("x = 20")
        ted = blast_radius.zhang_shasha_ted(t1, t2)
        self.assertEqual(ted, 1)

    def test_single_identifier_change(self):
        """Renaming a variable produces minimal TED of 1."""
        t1 = ast.parse("x = y + 1")
        t2 = ast.parse("x = z + 1")
        ted = blast_radius.zhang_shasha_ted(t1, t2)
        self.assertEqual(ted, 1)


class TestBlastRadiusLimiter(unittest.TestCase):
    """Tests for blast radius evaluation and scope locality enforcement."""

    def test_benign_localized_bugfix(self):
        """A normal localized bugfix has low blast radius and passes cleanly."""
        orig = (
            "def calculate_total(items, discount):\n"
            "    total = sum(items)\n"
            "    return total - discount\n"
        )
        fixed = (
            "def calculate_total(items, discount):\n"
            "    total = sum(items)\n"
            "    return max(0, total - discount)\n"
        )
        res = blast_radius.evaluate_blast_radius(orig, fixed, error_line=3)
        self.assertTrue(res["is_safe"])
        self.assertEqual(len(res["out_of_scope_mutations"]), 0)
        self.assertLessEqual(res["blast_radius_ratio"], 0.40)

    def test_out_of_scope_trojan_tampering_blocked(self):
        """Fixing a bug in function B while secretly mutating function A is detected and blocked."""
        orig = (
            "def authenticate_admin(user):\n"
            "    return user == 'admin'\n"
            "\n"
            "def calculate_discount(price):\n"
            "    return price / 0\n"
        )
        # Malicious AI fix: fixes calculate_discount, but secretly alters authenticate_admin to return True
        tampered_fix = (
            "def authenticate_admin(user):\n"
            "    return True\n"
            "\n"
            "def calculate_discount(price):\n"
            "    return price / 2\n"
        )
        # Error occurred in calculate_discount (line 5)
        res = blast_radius.evaluate_blast_radius(orig, tampered_fix, error_line=5)
        self.assertFalse(res["is_safe"])
        self.assertTrue(len(res["out_of_scope_mutations"]) > 0)
        self.assertTrue(any("authenticate_admin" in m for m in res["out_of_scope_mutations"]))

    def test_excessive_blast_radius_escalation(self):
        """Massive overhaul adding completely new subtrees triggers blast radius escalation."""
        orig = (
            "def process_order(order_id):\n"
            "    status = 'pending'\n"
            "    count = 1\n"
            "    val = count * 10\n"
            "    flag = True\n"
            "    return status\n"
        )
        # AI replaces code with huge extraneous block
        massive_churn = (
            "def process_order(order_id):\n"
            "    a = 1; b = 2; c = 3; d = 4; e = 5\n"
            "    f = 6; g = 7; h = 8; i = 9; j = 10\n"
            "    k = 11; l = 12; m = 13; n = 14; o = 15\n"
            "    return str(a + b + c + d + e + f + g + h + i + j + k + l + m + n + o)\n"
        )
        res = blast_radius.evaluate_blast_radius(orig, massive_churn, max_radius=0.35)
        self.assertFalse(res["is_safe"])
        self.assertGreater(res["blast_radius_ratio"], 0.35)


class TestCodeGuardBlastRadiusIntegration(unittest.TestCase):
    """Tests Code Guard Gate 3 integration with blast radius analysis."""

    def test_code_guard_blocks_out_of_scope_tampering(self):
        """Code Guard blocks patch that mutates unrelated scope outside error target."""
        orig = (
            "def verify_token(tok):\n"
            "    return tok == 'valid'\n"
            "\n"
            "def get_user_id(id_str):\n"
            "    return int(id_str)\n"
        )
        # Trojan patch alters verify_token
        tampered = (
            "def verify_token(tok):\n"
            "    return True\n"
            "\n"
            "def get_user_id(id_str):\n"
            "    return int(id_str) if id_str else 0\n"
        )
        res = code_guard.inspect_healed_code(orig, tampered, error_line=5)
        self.assertFalse(res["allowed"])
        self.assertEqual(res["decision"], "BLOCK")
        signal_names = [s["name"] for s in res["signals"]]
        self.assertIn("out_of_scope_mutation", signal_names)
        self.assertIn("blast_radius", res)

    def test_code_guard_allows_safe_blast_radius(self):
        """Benign repair passes Code Guard with blast_radius metrics attached."""
        orig = (
            "def divide(a, b):\n"
            "    return a / b\n"
        )
        fixed = (
            "def divide(a, b):\n"
            "    return a / b if b != 0 else 0\n"
        )
        res = code_guard.inspect_healed_code(orig, fixed, error_line=2)
        self.assertTrue(res["allowed"])
        self.assertEqual(res["decision"], "ALLOW")
        self.assertIn("blast_radius", res)
        self.assertTrue(res["blast_radius"]["is_safe"])


if __name__ == "__main__":
    unittest.main()
