import os
import sys

# Load API keys and env vars from .env file
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass

def _load_env_file():
    env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(env_file):
        try:
            with open(env_file, "r", encoding="utf-8") as _f:
                for _line in _f:
                    _line = _line.strip()
                    if _line and not _line.startswith("#") and "=" in _line:
                        _k, _v = _line.split("=", 1)
                        _k = _k.strip()
                        _v = _v.strip().strip('"').strip("'")
                        if _k and _k not in os.environ:
                            os.environ[_k] = _v
        except Exception:
            pass
_load_env_file()

# Fast-path for PyInstaller frozen execution: handle sandbox_child subprocess without GUI/Flask
if any("sandbox_child" in arg or arg.startswith("--nonce=") for arg in sys.argv):
    base_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    if base_dir not in sys.path:
        sys.path.insert(0, base_dir)
    import sandbox_child
    sandbox_child.main()
    sys.exit(0)

import threading
import time
import socket
import logging

# Ensure base directory is in sys.path
base_dir = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import webview
from app import app, SERVER_PORT

# Suppress verbose werkzeug logs to keep console clean
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

def is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0

def find_available_port(start_port: int = 5000) -> int:
    for port in range(start_port, start_port + 50):
        if not is_port_in_use(port):
            return port
    return start_port

def run_server(port: int):
    try:
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"Error starting server: {e}")

def main():
    port = find_available_port(SERVER_PORT)

    # Start Flask server as a daemon thread
    server_thread = threading.Thread(target=run_server, args=(port,), daemon=True)
    server_thread.start()

    # Wait for Flask to become available
    for _ in range(60):
        if is_port_in_use(port):
            break
        time.sleep(0.1)

    # Create PyWebView window (Option 1: Native Desktop Window)
    window = webview.create_window(
        title="TOC-COMPILER v3.2 - Formal Methods IDE & Code Optimizer",
        url=f"http://127.0.0.1:{port}",
        width=1380,
        height=880,
        min_size=(1024, 650),
        resizable=True,
        confirm_close=False
    )

    webview.start()

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    main()

