message = "hello"
print(mesage)

def greet(name)
    print("Hi", name)
greet("Sam")

print("Total: " + 5)

nums = [3, 1, 2]
nums.apend(4)

import math
print(math.sqrt(-1))

for x in 100:
    print(x)

def countdown(n):
    return countdown(n - 1)
countdown(5)

count = 0
def add():
    count = count + 1
add()

import json
json.loads("")

import jsno
print("ok")

import some_missing_package

it = iter([])
print(next(it))
