"""tests_optimizer_universal.py - Comprehensive Unit Tests for Universal Compiler Optimization Wing.

Tests all 5 Tiers:
1. Algorithmic AST Transformations:
   - O(N^2) -> O(N) Duplicate Removal using Companion Hash Set
   - O(N*M) -> O(N+M) Linear Search to Set Lookup Hoisting
   - Safe Loop-Invariant Code Motion (LICM) protecting induction variables
   - Accumulator Loop to CPython List Comprehension
   - Exponential Branching Recursion to Dynamic Programming (@lru_cache)
2. IR Optimization Passes:
   - Constant Folding & Strength Reduction
   - Security-Aware Dead Code Elimination (DCE) preserving cryptographic wiping
3. Translation Validation Correctness Shield:
   - Differential fuzzing passes valid transformations
   - Fails semantically broken transformations with concrete counterexamples
4. Multi-Mode REST API (/api/optimize):
   - Modes: 'hybrid', 'offline', 'ai_only'
   - Schema: diff_text, ir_optimization, improvements, verification
5. DOM Elements in templates/index.html:
   - Mode selector, speedup badge, security preservation badge, diff container
"""

import ast
import json
import os
import unittest
from unittest.mock import patch

from app import app
import code_quality
from ir_optimizer import optimize_ir
from translation_validator import validate_translation


class TestUniversalOptimizerWing(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    # -----------------------------------------------------------------------
    # Tier 1: Algorithmic AST Transformations
    # -----------------------------------------------------------------------

    def test_01_duplicate_removal_quadratic_to_linear(self):
        """O(N^2) duplicate filtering loop is transformed to O(N) using companion hash-set."""
        code = '''def unique_elements(items):
    seen = []
    for x in items:
        if x not in seen:
            seen.append(x)
    return seen
'''
        opt_code, applied = code_quality.deterministic_ast_optimize(code)
        self.assertIn("_seen_seen", opt_code)
        self.assertTrue(any("companion hash-set" in a for a in applied))

        # Functional equivalence test
        scope_orig, scope_opt = {}, {}
        exec(code, scope_orig)
        exec(opt_code, scope_opt)
        test_inputs = [
            [1, 2, 2, 3, 1, 4, 3, 5],
            [],
            ["a", "b", "a", "c"],
            [42] * 50
        ]
        for inp in test_inputs:
            self.assertEqual(
                scope_orig["unique_elements"](list(inp)),
                scope_opt["unique_elements"](list(inp))
            )

    def test_02_linear_search_to_set_lookup_hoisting(self):
        """Linear search in collection is hoisted to O(1) set lookup before loop."""
        code = '''def filter_targets(targets, corpus):
    matches = []
    for t in targets:
        if t in corpus:
            matches.append(t)
    return matches
'''
        opt_code, applied = code_quality.deterministic_ast_optimize(code)
        self.assertIn("_corpus_set = set(corpus)", opt_code)
        self.assertTrue(any("O(1) hash set lookup" in a for a in applied))

        # Functional equivalence test
        scope_orig, scope_opt = {}, {}
        exec(code, scope_orig)
        exec(opt_code, scope_opt)
        targets = [1, 5, 9, 12, 15]
        corpus = [2, 5, 8, 9, 10, 15]
        self.assertEqual(
            scope_orig["filter_targets"](targets, corpus),
            scope_opt["filter_targets"](targets, corpus)
        )

    def test_03_safe_licm_preserves_induction_variables(self):
        """LICM hoists pure invariant calculations but strictly protects loop induction variables."""
        code = '''def compute_scaled_sum(n, scale):
    total = 0
    i = 0
    while i < n:
        factor = scale * 10
        total = total + (i * factor)
        i = i + 1
    return total
'''
        opt_code, applied = code_quality.deterministic_ast_optimize(code)
        # Verify factor was hoisted
        self.assertTrue(any("Hoisted loop-invariant calculation 'factor'" in a for a in applied))
        # Ensure while loop still contains induction step i = i + 1
        tree = ast.parse(opt_code)
        while_node = next(n for n in ast.walk(tree) if isinstance(n, ast.While))
        while_source = ast.unparse(while_node)
        self.assertIn("i = i + 1", while_source)
        self.assertIn("total = total +", while_source)

        # Functional equivalence test
        scope_orig, scope_opt = {}, {}
        exec(code, scope_orig)
        exec(opt_code, scope_opt)
        for n, scale in [(0, 5), (1, 2), (5, 3), (10, -2)]:
            self.assertEqual(
                scope_orig["compute_scaled_sum"](n, scale),
                scope_opt["compute_scaled_sum"](n, scale)
            )

    def test_04_accumulator_to_list_comprehension(self):
        """Accumulator for-loops are transformed into CPython list comprehensions."""
        code = '''def double_positives(numbers):
    out = []
    for x in numbers:
        if x > 0:
            out.append(x * 2)
    return out
'''
        opt_code, applied = code_quality.deterministic_ast_optimize(code)
        self.assertIn("[x * 2 for x in numbers if x > 0]", opt_code)
        self.assertTrue(any("list comprehension" in a.lower() for a in applied))

        scope_orig, scope_opt = {}, {}
        exec(code, scope_orig)
        exec(opt_code, scope_opt)
        self.assertEqual(
            scope_orig["double_positives"]([-3, 0, 2, 5, -1, 4]),
            scope_opt["double_positives"]([-3, 0, 2, 5, -1, 4])
        )

    def test_05_branching_recursion_to_memoization(self):
        """Exponential branching recursion (e.g. Fibonacci) is decorated with @functools.lru_cache."""
        code = '''def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
'''
        opt_code, applied = code_quality.deterministic_ast_optimize(code)
        self.assertIn("import functools", opt_code)
        self.assertIn("@functools.lru_cache", opt_code)
        self.assertTrue(any("memoization" in a.lower() for a in applied))

        scope_opt = {}
        exec(opt_code, scope_opt)
        # Should easily compute n=35 instantaneously due to memoization
        self.assertEqual(scope_opt["fibonacci"](10), 55)
        self.assertEqual(scope_opt["fibonacci"](20), 6765)

    # -----------------------------------------------------------------------
    # Tier 2: IR Optimizer Passes & Security-Aware DCE
    # -----------------------------------------------------------------------

    def test_06_ir_optimizer_constant_folding_and_strength_reduction(self):
        """IR Optimizer applies constant folding (2+3->5) and strength reduction (x*2->x+x)."""
        code = '''def process_sample(x):
    a = 2 + 3
    b = x * 2
    c = x ** 2
    return a + b + c
'''
        res = optimize_ir(code)
        self.assertTrue(res["success"])
        self.assertGreater(res["total_transformations"], 0)
        self.assertGreaterEqual(res["speedup_ratio"], 1.0)
        opt_py = res.get("optimized_code", "")
        # Constant folding check
        self.assertIn("5", opt_py)
        # Strength reduction check
        self.assertTrue("x + x" in opt_py or "x * x" in opt_py)

    def test_07_ir_optimizer_security_aware_dce_preservation(self):
        """Security-Aware DCE eliminates unused variables while preserving cryptographic wiping."""
        code = '''def secure_logout(user_token):
    dead_temp = 99 * 42
    # Security-critical credentials zeroing
    user_token = ""
    secret = 0
    return True
'''
        res = optimize_ir(code)
        self.assertTrue(res["success"])
        # Verify security preservation was logged
        preserved = res["security_invariants_preserved"]
        self.assertGreater(len(preserved), 0)
        self.assertTrue(any("Zeroing of sensitive credential" in p for p in preserved))

        # Check synthesized code keeps token zeroing
        opt_py = res.get("optimized_code", "")
        self.assertTrue('user_token = ""' in opt_py or "secret = 0" in opt_py or "user_token = ''" in opt_py)

    # -----------------------------------------------------------------------
    # Tier 3: Translation Validation Correctness Shield
    # -----------------------------------------------------------------------

    def test_08_translation_validation_passes_valid_optimization(self):
        """Valid behavior-preserving optimization passes differential testing and validation."""
        orig = '''def square_all(nums):
    res = []
    for x in nums:
        res.append(x * x)
    return res
'''
        opt = '''def square_all(nums):
    """Optimized with list comprehension."""
    return [x * x for x in nums]
'''
        val = validate_translation(orig, opt)
        self.assertTrue(val["equivalent"])
        self.assertIn(val["verdict"], ["PROVEN_EQUIVALENT", "PROBABILISTICALLY_EQUIVALENT", "DIFFERENTIAL_PASSED"])
        self.assertIsNone(val["counterexample"])

    def test_09_translation_validation_rejects_buggy_ai_transformation(self):
        """Buggy optimization changing semantics is caught with a concrete counterexample."""
        orig = '''def calculate_total(a, b):
    return a * b
'''
        broken = '''def calculate_total(a, b):
    # Faulty AI suggestion
    return a + b
'''
        val = validate_translation(orig, broken)
        self.assertFalse(val["equivalent"])
        self.assertEqual(val["verdict"], "COUNTEREXAMPLE_FOUND")
        self.assertIsNotNone(val["counterexample"])
        self.assertIn("explanation", val["counterexample"])

    # -----------------------------------------------------------------------
    # Tier 4: Multi-Mode REST API (/api/optimize)
    # -----------------------------------------------------------------------

    def test_10_api_optimize_hybrid_mode(self):
        """POST /api/optimize with mode='hybrid' returns full optimization bundle."""
        code = '''def filter_positives(arr):
    res = []
    for i in range(len(arr)):
        if arr[i] > 0:
            res.append(arr[i])
    return res
'''
        resp = self.app.post("/api/optimize", json={
            "code": code,
            "mode": "hybrid"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertEqual(data.get("mode"), "hybrid")
        self.assertIn("diff_text", data)
        self.assertIn("--- original.py", data["diff_text"])
        self.assertIn("+++ optimized.py", data["diff_text"])
        self.assertIn("ir_optimization", data)
        self.assertIn("verification", data)
        self.assertTrue(data["verification"]["verified"])

    def test_11_api_optimize_offline_mode_zero_quota(self):
        """POST /api/optimize with mode='offline' runs pure compiler passes with no AI."""
        code = '''def get_squares(n):
    res = []
    for x in range(n):
        res.append(x * x)
    return res
'''
        resp = self.app.post("/api/optimize", json={
            "code": code,
            "mode": "offline"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertEqual(data.get("mode"), "offline")
        self.assertIn("diff_text", data)
        # Should not have any AI optimization labels in applied
        self.assertFalse(any("AI Algorithmic" in a for a in data.get("optimizations_applied", [])))

    def test_12_api_optimize_ai_only_mocked(self):
        """POST /api/optimize with mode='ai_only' prioritizes neural optimization."""
        code = '''def calc_sum(n):
    s = 0
    for i in range(n):
        s += i
    return s
'''
        mock_reply = "```python\ndef calc_sum(n: int) -> int:\n    return (n * (n - 1)) // 2\n```"
        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "", "LLM_DISABLED": "0", "AUTOFIX_AI": "1"}), \
             patch("llm_calls.call_gemini", return_value=(mock_reply, None, False)):
            resp = self.app.post("/api/optimize", json={
                "code": code,
                "mode": "ai_only"
            })
            self.assertEqual(resp.status_code, 200)
            data = resp.get_json()
            self.assertEqual(data.get("status"), "success")
            self.assertEqual(data.get("mode"), "ai_only")
            self.assertTrue(any("AI Algorithmic Optimization" in a for a in data.get("optimizations_applied", [])))

    # -----------------------------------------------------------------------
    # Tier 5: UI Template DOM Elements
    # -----------------------------------------------------------------------

    def test_13_ui_dom_elements_present(self):
        """Verify templates/index.html includes mode select, speedup badge, security badge, and diff container."""
        template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        required_ui = [
            'id="qm-mode-select"',
            'id="qm-ir-speedup-badge"',
            'id="qm-ir-security-badge"',
            'id="qm-diff-container"',
            'id="qm-diff-text"'
        ]
        for el in required_ui:
            self.assertIn(el, html, f"Missing element {el} in templates/index.html")


if __name__ == "__main__":
    unittest.main()
