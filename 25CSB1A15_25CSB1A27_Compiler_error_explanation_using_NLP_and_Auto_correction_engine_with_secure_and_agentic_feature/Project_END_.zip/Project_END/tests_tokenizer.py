"""tests_tokenizer.py - Comprehensive test suite for tokenizer.py (Feature 5).

Verifies token classification, edge cases, error recovery, performance under
adversarial inputs (no catastrophic backtracking), and comparison against stdlib.
"""

from __future__ import annotations

import glob
import os
import random
import time
import unittest

import tokenizer
from tests.tokenizer.compare_with_tokenize import compare_files


class TestTokenizer(unittest.TestCase):
    """Unit tests for deterministic lexical analyzer."""

    def test_empty_and_bom(self) -> None:
        """Test empty input and BOM stripping."""
        res = tokenizer.tokenize("")
        self.assertEqual(res["tokens"], [])
        self.assertEqual(res["errors"], [])
        self.assertFalse(res["truncated"])

        res_bom = tokenizer.tokenize("\ufeffx = 1")
        self.assertEqual(res_bom["tokens"][0]["type"], "NAME")
        self.assertEqual(res_bom["tokens"][0]["text"], "x")

    def test_crlf_and_newlines(self) -> None:
        """Test Windows CRLF, Unix LF, and line continuations."""
        code = "a = 1\r\nb = 2\nc = \\\r\n3\n"
        res = tokenizer.tokenize(code)
        tokens = [t for t in res["tokens"] if t["type"] != "NEWLINE"]
        texts = [t["text"] for t in tokens]
        self.assertEqual(texts, ["a", "=", "1", "b", "=", "2", "c", "=", "3"])
        # Check line numbering
        c_tok = [t for t in tokens if t["text"] == "c"][0]
        three_tok = [t for t in tokens if t["text"] == "3"][0]
        self.assertEqual(c_tok["line"], 3)
        self.assertEqual(three_tok["line"], 4)

    def test_keywords_vs_names_vs_soft_keywords(self) -> None:
        """Test standard keywords, soft keywords, and normal identifiers."""
        code = "def class return match case type _ my_var"
        res = tokenizer.tokenize(code)
        toks = res["tokens"]
        types = [(t["type"], t["text"]) for t in toks]
        expected = [
            ("KEYWORD", "def"),
            ("KEYWORD", "class"),
            ("KEYWORD", "return"),
            ("NAME", "match"),
            ("NAME", "case"),
            ("NAME", "type"),
            ("NAME", "_"),
            ("NAME", "my_var"),
        ]
        self.assertEqual(types, expected)

    def test_number_formats(self) -> None:
        """Test decimal, hex, octal, binary, floats, underscores, and imaginary suffix."""
        code = "123 1_000 0x1A_F 0o77 0b1011 3.14 .5 1. 1e-4 2.5e3 4j 1.5J"
        res = tokenizer.tokenize(code)
        for t in res["tokens"]:
            self.assertEqual(t["type"], "NUMBER", f"Expected NUMBER for {t['text']}")

    def test_string_prefixes_and_quotes(self) -> None:
        """Test all string prefixes and single/double/triple quotes."""
        prefixes = ["", "r", "u", "b", "f", "br", "rb", "fr", "rf", "R", "F", "BR"]
        code_parts = []
        for p in prefixes:
            code_parts.append(f"{p}'single'")
            code_parts.append(f'{p}"double"')
            code_parts.append(f"{p}'''trip1\ntrip2'''")
            code_parts.append(f'{p}"""trip3\ntrip4"""')
        code = "\n".join(code_parts)
        res = tokenizer.tokenize(code)
        str_tokens = [t for t in res["tokens"] if t["type"] == "STRING"]
        self.assertEqual(len(str_tokens), len(prefixes) * 4)

    def test_triple_quote_positioning(self) -> None:
        """Verify accurate multi-line start and end tracking for triple-quoted strings."""
        code = 'x = """line1\nline2\nline3"""\ny = 1'
        res = tokenizer.tokenize(code)
        str_tok = res["tokens"][2]
        self.assertEqual(str_tok["type"], "STRING")
        self.assertEqual(str_tok["line"], 1)
        self.assertEqual(str_tok["col"], 4)
        self.assertEqual(str_tok["end_line"], 3)
        self.assertEqual(str_tok["end_col"], 8)

    def test_operators_longest_first(self) -> None:
        """Test that multi-character operators are matched greedily."""
        code = "**= //= >>= <<= -> := ... != == <= >= ** // << >> += -= *= /= %= &= |= ^= @= @"
        res = tokenizer.tokenize(code)
        ops = [t["text"] for t in res["tokens"] if t["type"] == "OP"]
        expected = code.split()
        self.assertEqual(ops, expected)

    def test_brackets(self) -> None:
        """Test parentheses, brackets, and braces."""
        code = "( ) [ ] { }"
        res = tokenizer.tokenize(code)
        types = [t["type"] for t in res["tokens"]]
        subtypes = [t["subtype"] for t in res["tokens"]]
        self.assertEqual(types, ["BRACKET"] * 6)
        self.assertEqual(subtypes, ["(", ")", "[", "]", "{", "}"])

    def test_comments(self) -> None:
        """Test single-line comments."""
        code = "# full line comment\nx = 1 # inline comment"
        res = tokenizer.tokenize(code)
        comments = [t["text"] for t in res["tokens"] if t["type"] == "COMMENT"]
        self.assertEqual(comments, ["# full line comment", "# inline comment"])

    def test_error_tokens(self) -> None:
        """Test error handling for unknown chars, unterminated strings, invalid numbers."""
        # 1. Unknown characters
        res = tokenizer.tokenize("? $ `")
        self.assertEqual(len(res["errors"]), 3)
        self.assertEqual(res["errors"][0]["kind"], "unknown_character")

        # 2. Unterminated single string
        res = tokenizer.tokenize("'hello")
        self.assertTrue(res["partial"])
        self.assertEqual(res["errors"][0]["kind"], "unterminated_string")

        # 3. Unterminated triple string
        res = tokenizer.tokenize('"""long docstring starts here')
        self.assertTrue(res["partial"])
        self.assertEqual(res["errors"][0]["kind"], "unterminated_triple_string")
        self.assertEqual(res["errors"][0]["line"], 1)

        # 4. Invalid number literal
        res = tokenizer.tokenize("12abc")
        self.assertEqual(res["errors"][0]["kind"], "invalid_number_literal")

        # 5. Invalid number followed by keyword (warning note)
        res = tokenizer.tokenize("1if")
        self.assertEqual(res["errors"][0]["kind"], "invalid_number_warning")

    def test_truncation_flag(self) -> None:
        """Test max_tokens truncation flag."""
        code = "a + b + c + d + e"
        res = tokenizer.tokenize(code, max_tokens=3)
        self.assertTrue(res["truncated"])
        self.assertEqual(len(res["tokens"]), 3)

    def test_adversarial_performance_no_redos(self) -> None:
        """Verify linear time and no ReDoS on adversarial inputs."""
        # 100k quotes
        t0 = time.perf_counter()
        res1 = tokenizer.tokenize('"' * 100000)
        t1 = time.perf_counter()
        self.assertLess(t1 - t0, 1.0)
        self.assertIsInstance(res1, dict)

        # 100k backslashes
        t0 = time.perf_counter()
        res2 = tokenizer.tokenize('\\' * 100000)
        t1 = time.perf_counter()
        self.assertLess(t1 - t0, 1.0)

        # 50k nested brackets
        t0 = time.perf_counter()
        res3 = tokenizer.tokenize('(' * 50000 + ')' * 50000)
        t1 = time.perf_counter()
        self.assertLess(t1 - t0, 1.0)

        # 1 MB single line
        t0 = time.perf_counter()
        res4 = tokenizer.tokenize("x = 1; " * 150000)
        t1 = time.perf_counter()
        self.assertLess(t1 - t0, 1.0)

    def test_random_fuzzing(self) -> None:
        """Fuzz with 200 pseudo-random strings to ensure tokenizer never crashes."""
        rng = random.Random(42)
        chars = [chr(i) for i in range(32, 127)] + ["\r", "\n", "\t", "\ufeff", "€", "§", "α"]
        for _ in range(200):
            length = rng.randint(0, 500)
            rand_str = "".join(rng.choice(chars) for _ in range(length))
            try:
                res = tokenizer.tokenize(rand_str)
                self.assertIsInstance(res, dict)
            except Exception as e:
                self.fail(f"Tokenizer crashed on random input {repr(rand_str)}: {e}")

    def test_comparison_against_real_programs(self) -> None:
        """Run comparison against Python stdlib tokenize on all real test files."""
        root = os.path.dirname(os.path.abspath(__file__))
        patterns = [
            os.path.join(root, "test*.py"),
            os.path.join(root, "test_*.py"),
            os.path.join(root, "*_fixed.py"),
        ]
        files = []
        for pat in patterns:
            files.extend(glob.glob(pat))
        files = sorted(list(set(files)))

        self.assertGreater(len(files), 10)
        results = compare_files(files)

        print("\n=== Tokenizer vs stdlib tokenize Comparison Table ===")
        print(f"{'Filename':<28} | {'Custom':<7} | {'Stdlib':<18} | {'Mismatches':<10} | {'Note'}")
        print("-" * 90)

        unexplained_mismatches = 0
        for r in results:
            custom_c = str(r["custom_count"])
            std_c = str(r["std_count"])
            mismatches = r["mismatches"]
            note = r["note"]
            print(f"{r['file']:<28} | {custom_c:<7} | {std_c:<18} | {mismatches:<10} | {note}")
            if mismatches > 0 and "Explained" not in note and "SyntaxError" not in std_c:
                unexplained_mismatches += 1

        self.assertEqual(unexplained_mismatches, 0, "Found unexplained tokenizer mismatches!")


if __name__ == "__main__":
    unittest.main()
