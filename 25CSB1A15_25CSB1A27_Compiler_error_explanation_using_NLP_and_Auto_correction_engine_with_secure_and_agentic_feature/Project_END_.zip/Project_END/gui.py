import logging
from app import app

# Suppress verbose Flask traffic logs to keep terminal clean
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

print("\n" + "="*60)
print("[TOC COMPILER WORKBENCH INITIALIZED]")
print("Target: Python 3.13 (CFG/AST) | Automata Engine: Active")
print("Interactive Compiler IDE available at:")
print("  http://127.0.0.1:5000")
print("="*60 + "\n")

if __name__ == '__main__':
    try:
        app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False)
    except Exception as e:
        print(f"Failed to start Compiler Workbench Server: {e}")
