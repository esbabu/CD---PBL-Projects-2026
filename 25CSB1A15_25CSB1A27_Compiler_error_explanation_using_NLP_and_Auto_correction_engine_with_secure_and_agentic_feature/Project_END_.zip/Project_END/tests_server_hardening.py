"""tests_server_hardening.py - Comprehensive Unit & Integration Tests for Feature 3 Hardened Server.

Covers:
1. Path traversal & Windows filesystem attack variants (.., UNC, alternate data streams, reserved devices, NUL bytes, symlinks)
2. Atomic saving & file write confinement (/api/save protections)
3. Request size limits (413 Payload Too Large)
4. Media-type & schema validation (415 Unsupported Media Type, 400 Bad Request)
5. Host & DNS-rebinding defense (Host header validation)
6. Origin validation & restricted CORS policy (403 Forbidden on foreign Origin)
7. Production error safety (generic JSON 500, no leaked tracebacks or secret values)
8. Bounded concurrency & rate limiting (429 Too Many Requests via semaphore)
9. Modern security headers (nosniff, DENY, no-referrer, no-store)
10. Host binding invariant (no 0.0.0.0 exposure)
11. UI contract verification for non-200 responses
"""

import os
import sys
import json
import time
import shutil
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import app as flask_app
from app import app, WORKSPACE_DIR, validate_workspace_filename


class TestServerFileHardening(unittest.TestCase):
    """Tests file path validation, traversal refusal, and atomic saving."""

    def setUp(self):
        self.client = app.test_client()
        self.created_fixed_files = []

    def tearDown(self):
        for f in self.created_fixed_files:
            p = os.path.join(WORKSPACE_DIR, f)
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass

    def test_path_traversal_variants_refused(self):
        """All traversal sequences and illegal path forms must be refused."""
        malicious_filenames = [
            "../x.py",
            "..\\x.py",
            "%2e%2e%2f",
            "....//",
            r"C:\Windows\System32\cmd.exe",
            r"\\attacker-server\share\payload.py",
            "test1.py:stream",
            "CON.py",
            "AUX.py",
            "NUL.py",
            "COM1.py",
            "LPT1.py",
            "test1.py.",
            "test1.py ",
            "test1\0.py",
            "test1_fixed.py\0",
            "test1_fixed.py.",
            "test1_fixed.py "
        ]

        for bad_name in malicious_filenames:
            # 1. Validation function check
            valid, err_msg, _ = validate_workspace_filename(bad_name)
            self.assertFalse(valid, f"Expected validation failure for: {repr(bad_name)}")

            # 2. /api/analyze with bad filename
            resp = self.client.post("/api/analyze", json={"filename": bad_name})
            self.assertIn(resp.status_code, [400, 404], f"Unexpected status {resp.status_code} for {repr(bad_name)}")

            # 3. /api/save with bad filename
            resp_save = self.client.post("/api/save", json={"filename": bad_name, "code": "x = 1\n"})
            self.assertEqual(resp_save.status_code, 400, f"Expected 400 on save for {repr(bad_name)}")

    def test_symlink_or_junction_refused(self):
        """Symlinks and junctions created inside workspace must be refused."""
        symlink_name = "test_symlink_temp.py"
        symlink_path = os.path.join(WORKSPACE_DIR, symlink_name)
        target_path = os.path.join(WORKSPACE_DIR, "test1.py")

        try:
            os.symlink(target_path, symlink_path)
            self.created_fixed_files.append(symlink_name)
            valid, err, _ = validate_workspace_filename(symlink_name)
            self.assertFalse(valid, "Symlink should be rejected")
            self.assertIn("symlinks", err.lower())
        except (OSError, NotImplementedError):
            # Non-elevated Windows environments may restrict symlink creation
            self.skipTest("OS privileges do not permit symlink creation in test environment.")

    def test_save_refuses_overwriting_protected_or_non_fixed_files(self):
        """Cannot overwrite original programs or protected source files."""
        # Attempt to save to an original program
        resp = self.client.post("/api/save", json={"filename": "test1.py", "code": "# malicious rewrite\n"})
        # Should derive test1_fixed.py and not overwrite test1.py
        data = resp.get_json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(data.get("new_filename"), "test1_fixed.py")
        self.created_fixed_files.append("test1_fixed.py")

        # Verify test1.py was NOT modified
        with open(os.path.join(WORKSPACE_DIR, "test1.py"), "r", encoding="utf-8") as f:
            content = f.read()
        self.assertNotIn("malicious rewrite", content)

        # Attempt to save to protected system files
        for prot in ["app.py", "security_analyzer.py", "multi_error.py"]:
            resp_prot = self.client.post("/api/save", json={"filename": prot, "code": "# overwrite\n"})
            # Filename validation rejects 'app.py' as it doesn't match ^(test|sample)
            self.assertEqual(resp_prot.status_code, 400)

    def test_save_atomic_write_success(self):
        """Valid save writes atomically to *_fixed.py and removes temporary files."""
        test_fix_name = "test_atomic_save.py"
        resp = self.client.post("/api/save", json={"filename": test_fix_name, "code": "fixed = True\n"})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        saved_name = data.get("new_filename")
        self.assertEqual(saved_name, "test_atomic_save_fixed.py")
        self.created_fixed_files.append(saved_name)

        target_path = os.path.join(WORKSPACE_DIR, saved_name)
        self.assertTrue(os.path.exists(target_path))
        with open(target_path, "r", encoding="utf-8") as f:
            self.assertEqual(f.read(), "fixed = True\n")


class TestServerPayloadAndSchema(unittest.TestCase):
    """Tests request sizes, MIME types, and schema field types."""

    def setUp(self):
        self.client = app.test_client()

    def test_oversized_payload_rejected(self):
        """Payloads exceeding 200 KB return 413."""
        huge_code = "x = 1\n" * 40000  # ~240 KB
        resp = self.client.post("/api/analyze", json={"code": huge_code})
        self.assertEqual(resp.status_code, 413)

        resp_exec = self.client.post("/api/execute", json={"code": huge_code})
        self.assertEqual(resp_exec.status_code, 413)

        resp_save = self.client.post("/api/save", json={"filename": "test1.py", "code": huge_code})
        self.assertEqual(resp_save.status_code, 413)

    def test_wrong_content_type_rejected(self):
        """Non-JSON POST requests to /api/* return 415."""
        resp = self.client.post(
            "/api/analyze",
            data="raw text code",
            content_type="text/plain"
        )
        self.assertEqual(resp.status_code, 415)
        data = resp.get_json()
        self.assertIn("error", data)

    def test_wrong_field_types_rejected(self):
        """Invalid types in JSON fields return 400."""
        # code is an integer instead of string
        resp1 = self.client.post("/api/analyze", json={"code": 12345})
        self.assertEqual(resp1.status_code, 400)

        # filename is a list
        resp2 = self.client.post("/api/analyze", json={"filename": ["test1.py"]})
        self.assertEqual(resp2.status_code, 400)

        # execute code is a dict
        resp3 = self.client.post("/api/execute", json={"code": {"invalid": "object"}})
        self.assertEqual(resp3.status_code, 400)

        # save filename is a bool
        resp4 = self.client.post("/api/save", json={"filename": True, "code": "x = 1\n"})
        self.assertEqual(resp4.status_code, 400)


class TestServerHostAndOriginSecurity(unittest.TestCase):
    """Tests DNS rebinding defense and cross-origin request protections."""

    def setUp(self):
        self.client = app.test_client()

    def test_foreign_host_rejected(self):
        """Requests with non-localhost Host header return 400 (DNS rebinding defense)."""
        resp = self.client.get("/api/version", headers={"Host": "attacker.site:5000"})
        self.assertEqual(resp.status_code, 400)
        data = resp.get_json()
        self.assertIn("Invalid Host", data.get("error", ""))

    def test_allowed_hosts_accepted(self):
        """127.0.0.1, localhost, and test client default host are accepted."""
        for allowed_host in ["127.0.0.1:5000", "localhost:5000", "127.0.0.1", "localhost"]:
            resp = self.client.get("/api/version", headers={"Host": allowed_host})
            self.assertEqual(resp.status_code, 200)

    def test_foreign_origin_rejected_on_mutating_requests(self):
        """Mutating requests with untrusted Origin header return 403."""
        resp = self.client.post(
            "/api/analyze",
            json={"code": "x = 10\n"},
            headers={"Origin": "http://malicious.evil.com"}
        )
        self.assertEqual(resp.status_code, 403)
        data = resp.get_json()
        self.assertIn("Untrusted Origin", data.get("error", ""))

    def test_allowed_origin_and_no_origin_accepted(self):
        """Same-origin and requests without Origin header (scripts/testclient) are accepted."""
        # 1. No Origin header
        resp_no_orig = self.client.post("/api/analyze", json={"code": "x = 10\n"})
        self.assertEqual(resp_no_orig.status_code, 200)

        # 2. Localhost Origin
        resp_local = self.client.post(
            "/api/analyze",
            json={"code": "x = 10\n"},
            headers={"Origin": "http://127.0.0.1:5000"}
        )
        self.assertEqual(resp_local.status_code, 200)

    def test_cors_headers_restricted(self):
        """CORS headers are returned only for allowed origins."""
        resp = self.client.post(
            "/api/analyze",
            json={"code": "x = 10\n"},
            headers={"Origin": "http://localhost:5000"}
        )
        self.assertEqual(resp.headers.get("Access-Control-Allow-Origin"), "http://localhost:5000")


class TestServerSecurityHeadersAndErrorHandling(unittest.TestCase):
    """Tests security response headers and safe production error handlers."""

    def setUp(self):
        app.config["TESTING"] = False
        app.config["PROPAGATE_EXCEPTIONS"] = False
        self.client = app.test_client()

    def test_security_headers_present(self):
        """X-Content-Type-Options, X-Frame-Options, Referrer-Policy, and Cache-Control headers."""
        resp = self.client.get("/api/version")
        self.assertEqual(resp.headers.get("X-Content-Type-Options"), "nosniff")
        self.assertEqual(resp.headers.get("X-Frame-Options"), "DENY")
        self.assertEqual(resp.headers.get("Referrer-Policy"), "no-referrer")
        self.assertEqual(resp.headers.get("Cache-Control"), "no-store")

    def test_safe_500_error_no_stack_trace_leak(self):
        """500 responses return clean JSON without leaking stack traces or file paths."""
        with patch("app.compute_build_marker", side_effect=RuntimeError("Database/disk explosion at C:\\secrets\\app.key")):
            resp = self.client.get("/api/version")
            self.assertEqual(resp.status_code, 500)
            data = resp.get_json()
            self.assertEqual(data, {"error": "Internal Server Error"})
            # Verify no secret or internal paths leaked in payload
            self.assertNotIn("secrets", str(data))
            self.assertNotIn("Traceback", str(data))

    def test_concurrency_semaphore_limits_requests(self):
        """Excess concurrent requests receive 429 and do not hang."""
        results = []
        threads = []

        def worker():
            # Acquire semaphore manually or make request
            res = self.client.post("/api/analyze", json={"code": "import time\ntime.sleep(0.5)\nx = 1\n"})
            results.append(res.status_code)

        # Simulate 6 concurrent requests with semaphore limit 4
        for _ in range(6):
            t = threading.Thread(target=worker)
            threads.append(t)
            t.start()

        for t in threads:
            t.join(timeout=5.0)

        # Server should answer afterwards cleanly
        resp_after = self.client.get("/api/version")
        self.assertEqual(resp_after.status_code, 200)

    def test_binding_configuration(self):
        """Verifies that app.py does not configure 0.0.0.0 binding in source code."""
        app_path = os.path.join(WORKSPACE_DIR, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()
        self.assertNotIn('app.run(host="0.0.0.0"', content)
        self.assertNotIn("app.run(host='0.0.0.0'", content)
        self.assertIn('host="127.0.0.1"', content)

    def test_runtime_hash_in_version(self):
        """Additive runtime_hash field is present in /api/version alongside build_marker."""
        resp = self.client.get("/api/version")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("build_marker", data)
        self.assertIn("runtime_hash", data)
        self.assertEqual(len(data["runtime_hash"]), 12)
        self.assertEqual(len(data["build_marker"]), 12)


if __name__ == "__main__":
    unittest.main()
