@echo off
echo ========================================================
echo Building Standalone Single-File Executable...
echo ========================================================
python -m PyInstaller desktop_app_onefile.spec --noconfirm
echo.
echo Build complete! Single executable file ready at:
echo dist\TOC_Studio_Standalone.exe
pause
