"""tests_compiler_upgrades.py - Comprehensive Test Suite for the 5 Compiler & Verification Subsystems.

Tests:
1. Semantic Analysis & Symbol Table (scopes, types, undefined, use-before-assignment, did-you-mean)
2. Intermediate Representation (Three-Address Code lowering, SSA conversion, PHI nodes, before/after diff)
3. Dataflow-based Taint Analysis (sources, CFG propagation, sanitization, sinks, path explanations, risk score)
4. Multi-Pass Compiler IR Optimizer (constant folding, strength reduction, CSE, LICM, security-aware DCE)
5. Translation Validation (differential fuzzing, formal SMT equivalence proofs, counterexample isolation)
6. Flask REST API Endpoints (/api/semantic/analyze, /api/ir/*, /api/dataflow/taint, /api/compiler/optimize, /api/translation/validate)
"""

import ast
import json
import os
import sys
import unittest

# Ensure TOC_PROJECT 2 directory is on python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import semantic_analyzer
import ir_generator
import dataflow_engine
import ir_optimizer
import translation_validator
from app import app


class TestSemanticAnalysisAndSymbolTable(unittest.TestCase):
    """1. Tests for Semantic Analysis, Symbol Table, and Scope Resolution."""

    def test_scope_resolution_and_symbol_table(self):
        code = """
x = 10
def outer(a):
    b = a + 5
    def inner(c):
        return a + b + c
    return inner(b)
"""
        res = semantic_analyzer.analyze_semantics(code)
        self.assertTrue(res["success"])
        self.assertGreaterEqual(res["summary"]["scope_count"], 3)
        self.assertGreaterEqual(res["summary"]["scope_depth"], 2)

        # Check symbol records
        sym_names = {s["name"] for s in res["symbol_table"]}
        self.assertIn("x", sym_names)
        self.assertIn("outer", sym_names)
        self.assertIn("a", sym_names)
        self.assertIn("b", sym_names)
        self.assertIn("inner", sym_names)
        self.assertIn("c", sym_names)

    def test_undefined_variable_with_grounded_did_you_mean(self):
        code = """
total_count = 100
def process():
    print(total_cout)
"""
        res = semantic_analyzer.analyze_semantics(code)
        self.assertTrue(res["success"])
        undef = res["undefined_variables"]
        self.assertEqual(len(undef), 1)
        self.assertEqual(undef[0]["name"], "total_cout")
        # Check grounded symbol table suggestion
        hint = undef[0]["did_you_mean"]
        self.assertIsNotNone(hint)
        self.assertEqual(hint["name"], "total_count")
        self.assertEqual(hint["scope"], "<global>")
        self.assertGreater(hint["confidence"], 80)

    def test_use_before_assignment(self):
        code = """
x = 10
def f():
    print(x)
    x = 20
"""
        res = semantic_analyzer.analyze_semantics(code)
        self.assertTrue(res["success"])
        uba = res["use_before_assignment"]
        self.assertEqual(len(uba), 1)
        self.assertEqual(uba[0]["name"], "x")
        self.assertEqual(uba[0]["line"], 4)
        self.assertEqual(uba[0]["assignment_line"], 5)
        self.assertIn("UnboundLocalError", uba[0]["message"])

    def test_redeclared_and_duplicate_parameters(self):
        code = """
def bad_func(arg, arg):
    return arg
"""
        res = semantic_analyzer.analyze_semantics(code)
        self.assertTrue(res["success"])
        redecl = res["redeclared_variables"]
        self.assertEqual(len(redecl), 1)
        self.assertEqual(redecl[0]["type"], "Duplicate Parameter")
        self.assertEqual(redecl[0]["name"], "arg")

    def test_type_checking_mismatches(self):
        code = """
a = 10
b = 'hello'
c = a + b
x = 5
x()
"""
        res = semantic_analyzer.analyze_semantics(code)
        self.assertTrue(res["success"])
        mismatches = res["type_mismatches"]
        types_flagged = [m["type"] for m in mismatches]
        self.assertIn("Incompatible Addition/Concatenation", types_flagged)
        self.assertIn("Calling Non-Callable", types_flagged)


class TestIntermediateRepresentationTACAndSSA(unittest.TestCase):
    """2. Tests for Three-Address Code and SSA Lowering."""

    def test_tac_lowering_expressions_and_blocks(self):
        code = """
def compute(x, y):
    z = x + y * 2
    if z > 10:
        return z
    else:
        return 0
"""
        res = ir_generator.generate_ir_for_code(code)
        self.assertTrue(res["success"])
        self.assertFalse(res["is_ssa"])
        self.assertGreaterEqual(res["block_count"], 4)
        self.assertGreater(res["instruction_count"], 5)

        tac_text = res["tac_text"]
        self.assertIn("MUL", tac_text)
        self.assertIn("ADD", tac_text)
        self.assertIn("JUMP_IF_FALSE", tac_text)
        self.assertIn("RETURN", tac_text)

    def test_ssa_form_with_phi_nodes(self):
        code = """
x = 1
if x > 0:
    x = 2
else:
    x = 3
y = x
"""
        res = ir_generator.generate_ir_for_code(code, ssa=True)
        self.assertTrue(res["success"])
        self.assertTrue(res["is_ssa"])

        tac_text = res["tac_text"]
        self.assertIn("PHI", tac_text)
        self.assertIn("x_0", tac_text)

    def test_ir_compare_before_and_after(self):
        orig = "def f(x):\n    return x * 2\n"
        fixed = "def f(x):\n    return x + x\n"

        comp = ir_generator.compare_code_ir(orig, fixed)
        self.assertTrue(comp["success"])
        self.assertTrue(comp["has_changes"])
        self.assertIn("MUL", comp["diff_text"])
        self.assertIn("ADD", comp["diff_text"])


class TestDataflowTaintAnalysis(unittest.TestCase):
    """3. Tests for CFG Dataflow Taint Tracking, Path Explanations, and Risk Scoring."""

    def test_untrusted_input_to_shell_sink(self):
        code = """
user_val = input("Enter cmd: ")
cmd = "echo " + user_val
import os
os.system(cmd)
"""
        res = dataflow_engine.analyze_dataflow(code)
        self.assertTrue(res["success"])
        self.assertGreaterEqual(res["risk_score"], 90)
        self.assertEqual(res["verdict"], "BLOCK")
        self.assertGreaterEqual(len(res["taint_findings"]), 1)

        finding = res["taint_findings"][0]
        self.assertEqual(finding["sink"], "os.system")
        self.assertEqual(finding["tainted_variable"], "cmd")
        self.assertIn("input()", finding["explanation"])
        self.assertIn("os.system()", finding["explanation"])
        self.assertGreaterEqual(len(finding["path"]), 3)

    def test_sanitization_neutralizes_taint(self):
        code = """
user_id = int(input("Enter id: "))
import os
os.system(f"echo {user_id}")
"""
        res = dataflow_engine.analyze_dataflow(code)
        self.assertTrue(res["success"])
        # int() sanitizer neutralizes taint
        self.assertEqual(res["risk_score"], 0)
        self.assertEqual(res["verdict"], "ALLOW")
        self.assertEqual(len(res["taint_findings"]), 0)

    def test_reaching_definitions_and_dead_stores(self):
        code = """
unused_variable = 999
active = 10
print(active)
"""
        res = dataflow_engine.analyze_dataflow(code)
        self.assertTrue(res["success"])
        dead_vars = [d["variable"] for d in res["dead_stores"]]
        self.assertIn("unused_variable", dead_vars)


class TestCompilerIROptimizer(unittest.TestCase):
    """4. Tests for Multi-Pass IR Optimizer and Security-Aware DCE."""

    def test_constant_folding_and_strength_reduction(self):
        code = """
def test_calc(n):
    a = 10 + 20
    b = n * 2
    c = n ** 2
    d = n * 0
    return a + b + c + d
"""
        res = ir_optimizer.optimize_ir(code)
        self.assertTrue(res["success"])
        self.assertGreater(res["total_transformations"], 0)
        self.assertGreater(res["speedup_ratio"], 1.0)

        # Passes executed
        pass_names = [p["pass_name"] for p in res["passes"]]
        self.assertIn("Constant Folding & Propagation", pass_names)
        self.assertIn("Strength Reduction & Algebraic Simplification", pass_names)

    def test_security_aware_dead_code_elimination(self):
        """CRITICAL: Proves optimizer NEVER removes security-critical memory scrubbing."""
        code = """
def authenticate():
    secret_key = 'super_secret_token_123'
    # Sensitive operation complete, zero out secret from memory
    secret_key = ''
    return True
"""
        res = ir_optimizer.optimize_ir(code)
        self.assertTrue(res["success"])
        # Verify the security guard logged the preservation
        self.assertGreater(len(res["security_invariants_preserved"]), 0)
        log_entry = res["security_invariants_preserved"][0]
        self.assertIn("secret_key", log_entry)
        self.assertIn("Zeroing of sensitive credential", log_entry)

        # Check that the final IR retained the secret_key zeroing
        self.assertIn("secret_key", res["final_ir"])

    def test_common_subexpression_elimination(self):
        code = """
def calc(x):
    y = x * 7
    z = x * 7
    return y + z
"""
        res = ir_optimizer.optimize_ir(code)
        self.assertTrue(res["success"])
        cse_pass = next(p for p in res["passes"] if "Common Subexpression" in p["pass_name"])
        self.assertGreater(cse_pass["transformations_count"], 0)


class TestTranslationValidation(unittest.TestCase):
    """5. Tests for Translation Validation, Differential Testing, and SMT Prover."""

    def test_validate_equivalent_functions(self):
        orig = """
def f(x):
    return x * 2
"""
        fixed = """
def f(x):
    return x + x
"""
        res = translation_validator.validate_translation(orig, fixed)
        self.assertTrue(res["is_valid"])
        self.assertIn(res["status"], ("PROVEN_EQUIVALENT", "DIFFERENTIAL_PASSED"))
        self.assertEqual(res["differential_testing"]["match_percentage"], 100.0)
        self.assertIsNone(res["counterexample"])

    def test_detect_divergent_fix_with_counterexample(self):
        orig = """
def f(x):
    return x * 2
"""
        # Erroneous fix that alters program semantics!
        bad_fixed = """
def f(x):
    return x + 2
"""
        res = translation_validator.validate_translation(orig, bad_fixed)
        self.assertFalse(res["is_valid"])
        self.assertIn(res["status"], ("COUNTEREXAMPLE_FOUND", "DIVERGENCE_DETECTED"))
        self.assertIsNotNone(res["counterexample"])


class TestFlaskAppEndpoints(unittest.TestCase):
    """6. Integration tests for Flask REST API routes."""

    def setUp(self):
        self.client = app.test_client()

    def test_semantic_analyze_route(self):
        resp = self.client.post("/api/semantic/analyze", json={"code": "x = 42\nprint(x)"})
        self.assertEqual(resp.status_code, 200)
        data = resp.json
        self.assertTrue(data["success"])
        self.assertGreaterEqual(data["summary"]["total_symbols"], 1)

    def test_ir_generate_and_compare_routes(self):
        r_gen = self.client.post("/api/ir/generate", json={"code": "x = 10 + 20", "ssa": False})
        self.assertEqual(r_gen.status_code, 200)
        self.assertTrue(r_gen.json["success"])

        r_comp = self.client.post("/api/ir/compare", json={"original_code": "x = 1", "fixed_code": "x = 2"})
        self.assertEqual(r_comp.status_code, 200)
        self.assertTrue(r_comp.json["success"])
        self.assertTrue(r_comp.json["has_changes"])

    def test_dataflow_taint_route(self):
        resp = self.client.post("/api/dataflow/taint", json={"code": "cmd = input()\nos.system(cmd)"})
        self.assertEqual(resp.status_code, 200)
        data = resp.json
        self.assertEqual(data["verdict"], "BLOCK")
        self.assertGreaterEqual(data["risk_score"], 90)

    def test_compiler_optimize_route(self):
        resp = self.client.post("/api/compiler/optimize", json={"code": "x = 2 * 3\ny = x * 2"})
        self.assertEqual(resp.status_code, 200)
        data = resp.json
        self.assertTrue(data["success"])
        self.assertGreater(data["total_transformations"], 0)

    def test_translation_validate_route(self):
        resp = self.client.post("/api/translation/validate", json={
            "original_code": "def f(x):\n    return x * 2",
            "fixed_code": "def f(x):\n    return x + x"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.json
        self.assertTrue(data["is_valid"])


if __name__ == "__main__":
    unittest.main()
