"""tests_policy.py – Unit tests for Stage 3 (Feature 13a: Policy File and Threat Model Integrity).
"""

import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

# Ensure project root is in path
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from security.policy_loader import (
    load_policy,
    policy_hash,
    verify_integrity,
    PolicyValidationError,
    _DEFAULT_POLICY_PATH,
    _DEFAULT_HASH_PATH
)


class TestPolicyLoader(unittest.TestCase):
    """Verifies that security/policy.json and security/policy_loader.py function correctly."""

    def test_policy_loads_and_validates(self):
        """1. Verifies that the authoritative policy.json loads and adheres to the required schema."""
        policy = load_policy()
        self.assertIsInstance(policy, dict)
        self.assertIn("policy_version", policy)
        self.assertIn("rules", policy)
        self.assertIn("risk", policy)
        
        # Verify specific required rules exist
        rules = policy["rules"]
        self.assertIn("no_scan_bypass", rules)
        self.assertIn("healed_code_containment", rules)
        self.assertIn("human_approval_required", rules)
        self.assertIn("allowlisted_tools_only", rules)
        self.assertIn("policy_files_immutable", rules)
        self.assertIn("policy_runtime_readonly", rules)

        self.assertEqual(rules["no_scan_bypass"]["action"], "deny")
        self.assertEqual(rules["human_approval_required"]["action"], "require_approval")

    def test_missing_key_gives_clear_error(self):
        """2a. Verifies that a missing required root key raises PolicyValidationError."""
        raw_policy = load_policy()
        mutated = copy.deepcopy(raw_policy)
        del mutated["rules"]

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_policy_path = os.path.join(tmpdir, "policy.json")
            with open(tmp_policy_path, "w", encoding="utf-8") as f:
                json.dump(mutated, f)

            with self.assertRaises(PolicyValidationError) as ctx:
                load_policy(tmp_policy_path)
            self.assertIn("Missing required policy root key: 'rules'", str(ctx.exception))

    def test_wrong_type_gives_clear_error(self):
        """2b. Verifies that a wrong data type raises PolicyValidationError."""
        raw_policy = load_policy()
        mutated = copy.deepcopy(raw_policy)
        mutated["rules"] = ["not_a_dictionary"]

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_policy_path = os.path.join(tmpdir, "policy.json")
            with open(tmp_policy_path, "w", encoding="utf-8") as f:
                json.dump(mutated, f)

            with self.assertRaises(PolicyValidationError) as ctx:
                load_policy(tmp_policy_path)
            self.assertIn("'rules' key in policy must be a dictionary", str(ctx.exception))

    def test_malformed_json_gives_clear_error(self):
        """2c. Verifies that invalid JSON syntax raises PolicyValidationError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_policy_path = os.path.join(tmpdir, "policy.json")
            with open(tmp_policy_path, "w", encoding="utf-8") as f:
                f.write("{ invalid json content ...")

            with self.assertRaises(PolicyValidationError) as ctx:
                load_policy(tmp_policy_path)
            self.assertIn("contains invalid JSON", str(ctx.exception))

    def test_policy_hash_matches_authoritative_checksum(self):
        """3. Verifies that the computed SHA-256 of policy.json matches policy.sha256."""
        self.assertTrue(os.path.exists(_DEFAULT_HASH_PATH), "policy.sha256 file must exist")
        with open(_DEFAULT_HASH_PATH, "r", encoding="utf-8") as f:
            expected_hash = f.read().strip()

        computed_hash = policy_hash()
        self.assertEqual(computed_hash.lower(), expected_hash.lower())

        ok, msg = verify_integrity()
        self.assertTrue(ok, f"Integrity check failed: {msg}")
        self.assertIn("Integrity verified", msg)

    def test_modifying_copy_causes_integrity_failure(self):
        """4. Verifies that tampering with a copy causes verify_integrity to fail."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_policy = os.path.join(tmpdir, "policy.json")
            tmp_hash = os.path.join(tmpdir, "policy.sha256")
            shutil.copyfile(_DEFAULT_POLICY_PATH, tmp_policy)
            shutil.copyfile(_DEFAULT_HASH_PATH, tmp_hash)

            # Initially passes
            ok, _ = verify_integrity(policy_path=tmp_policy)
            self.assertTrue(ok)

            # Tamper with the policy file (ensure writable on Windows)
            import stat
            os.chmod(tmp_policy, stat.S_IWRITE | stat.S_IREAD)
            with open(tmp_policy, "a", encoding="utf-8") as f:
                f.write("\n ")

            # Now fails
            ok, reason = verify_integrity(policy_path=tmp_policy)
            self.assertFalse(ok)
            self.assertIn("Hash mismatch", reason)

    def test_no_import_time_side_effects(self):
        """5. Verifies that importing policy_loader creates no files or global state."""
        snap_before = set(os.listdir(_PROJECT_ROOT))
        sec_dir = os.path.join(_PROJECT_ROOT, "security")
        sec_before = set(os.listdir(sec_dir))

        code = (
            "import sys; sys.path.insert(0, '.'); "
            "import security.policy_loader; "
            "print('IMPORT_OK')"
        )
        res = subprocess.run(
            [sys.executable, "-c", code],
            cwd=_PROJECT_ROOT,
            capture_output=True,
            text=True
        )
        self.assertEqual(res.returncode, 0, f"Subprocess import failed: {res.stderr}")
        self.assertIn("IMPORT_OK", res.stdout)

        snap_after = set(os.listdir(_PROJECT_ROOT))
        sec_after = set(os.listdir(sec_dir))

        self.assertEqual(snap_before, snap_after, "Root directory changed after import")
        self.assertEqual(sec_before, sec_after, "security/ directory changed after import")


class TestThreatModelDocument(unittest.TestCase):
    """Verifies that docs/THREAT_MODEL.md satisfies all documented requirements."""

    @classmethod
    def setUpClass(cls):
        cls.doc_path = os.path.join(_PROJECT_ROOT, "docs", "THREAT_MODEL.md")
        with open(cls.doc_path, "r", encoding="utf-8") as f:
            cls.content = f.read()

    def test_threat_model_exists(self):
        """6a. Verifies that docs/THREAT_MODEL.md exists."""
        self.assertTrue(os.path.exists(self.doc_path))

    def test_all_16_attack_ids_present(self):
        """6b. Verifies that all 16 attack identifiers (AT-01 to AT-16) are present in the text."""
        for i in range(1, 17):
            att_id = f"AT-{i:02d}"
            self.assertIn(att_id, self.content, f"Missing attack identifier: {att_id}")

    def test_all_four_attack_channels_present(self):
        """6c. Verifies that all four attack vector channels are defined."""
        self.assertIn("Channel 1: User Instruction Text", self.content)
        self.assertIn("Channel 2: Code Content", self.content)
        self.assertIn("Channel 3: Error Text and Tracebacks", self.content)
        self.assertIn("Channel 4: Healed (Fixed) Code", self.content)

    def test_diagrams_present(self):
        """6d. Verifies that both Mermaid and ASCII architecture diagrams are included."""
        self.assertIn("```mermaid", self.content)
        self.assertIn("flowchart TD", self.content)
        self.assertIn("```text", self.content)

    def test_coverage_matrix_names_controls_and_gaps(self):
        """7. Verifies that every AT-ID in the Coverage Matrix names a control and a future gap."""
        self.assertIn("Security Coverage Matrix", self.content)
        for i in range(1, 17):
            att_id = f"**AT-{i:02d}**"
            self.assertIn(att_id, self.content, f"Coverage table missing row for {att_id}")


if __name__ == "__main__":
    unittest.main()
