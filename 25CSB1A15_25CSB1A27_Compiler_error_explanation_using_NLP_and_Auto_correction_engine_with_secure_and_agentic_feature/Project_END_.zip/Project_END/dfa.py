"""dfa.py - Explicit Deterministic Finite Automata (DFA) Engine for IntelliFix.

Implements Feature 5 (TOC Week 3):
- Formal Deterministic Finite Automaton class (5-tuple: Q, Sigma, delta, q0, F).
- Explicit state transition dictionary and dead/trap state handling.
- Concrete hand-written DFAs for:
    1. ASCII Identifiers: [A-Za-z_][A-Za-z0-9_]*
    2. Decimal & Float Numbers: [0-9]+(\\.[0-9]+)?
    3. Decimal Integers with Underscores: [0-9](_?[0-9])*
- Detailed state-tracing method returning full computation paths.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, FrozenSet, List, Optional, Set, Tuple


class DFA:
    """Formal Deterministic Finite Automaton (Q, Sigma, delta, q0, F)."""

    def __init__(
        self,
        states: Set[str],
        alphabet_desc: str,
        char_classifier: Callable[[str], str],
        transitions: Dict[Tuple[str, str], str],
        start_state: str,
        accepting_states: Set[str],
        name: str = "DFA",
    ) -> None:
        """Initialize the DFA.

        Args:
            states: Finite set of state identifiers Q.
            alphabet_desc: Human-readable description of Sigma.
            char_classifier: Function mapping any input character to an abstract symbol class in Sigma.
            transitions: Transition function delta: (current_state, symbol_class) -> next_state.
            start_state: Initial state q0 in Q.
            accepting_states: Subset of states F subset of Q.
            name: Descriptive name for reporting and visualization.
        """
        self.states = set(states)
        self.alphabet_desc = alphabet_desc
        self.char_classifier = char_classifier
        self.transitions = dict(transitions)
        self.start_state = start_state
        self.accepting_states = set(accepting_states)
        self.name = name

        # Validate start and accepting states belong to Q
        if self.start_state not in self.states:
            raise ValueError(f"Start state '{self.start_state}' not in states Q.")
        for s in self.accepting_states:
            if s not in self.states:
                raise ValueError(f"Accepting state '{s}' not in states Q.")

    def step(self, current_state: str, char: str) -> str:
        """Compute the next state delta(current_state, char_class).

        If transition is undefined, returns 'DEAD' (trap state).
        """
        sym = self.char_classifier(char)
        return self.transitions.get((current_state, sym), "DEAD")

    def accepts(self, s: str) -> bool:
        """Evaluate string s through the DFA and return True if accepted."""
        state = self.start_state
        for ch in s:
            state = self.step(state, ch)
            if state == "DEAD":
                return False
        return state in self.accepting_states

    def trace(self, s: str) -> Dict[str, Any]:
        """Trace the state transitions step-by-step for visualization and viva examination.

        Returns:
            Dict containing input string, accepted boolean, final state, and steps trace.
        """
        steps: List[Dict[str, str]] = []
        state = self.start_state
        for i, ch in enumerate(s):
            sym = self.char_classifier(ch)
            next_state = self.transitions.get((state, sym), "DEAD")
            steps.append({
                "index": i,
                "char": ch,
                "class": sym,
                "from_state": state,
                "to_state": next_state,
            })
            state = next_state
            if state == "DEAD":
                break

        return {
            "name": self.name,
            "input": s,
            "accepted": state in self.accepting_states,
            "final_state": state,
            "steps": steps,
        }


# ==============================================================================
# Hand-written Concrete DFAs
# ==============================================================================

# 1. ASCII Identifier DFA: [A-Za-z_][A-Za-z0-9_]*
def _ident_classifier(ch: str) -> str:
    if (("a" <= ch <= "z") or ("A" <= ch <= "Z") or ch == "_"):
        return "LETTER_OR_UNDERSCORE"
    elif "0" <= ch <= "9":
        return "DIGIT"
    return "OTHER"


IDENT_DFA = DFA(
    name="ASCII_IDENTIFIER_DFA",
    states={"q0", "q_accept", "DEAD"},
    alphabet_desc="ASCII [A-Za-z_][A-Za-z0-9_]*",
    char_classifier=_ident_classifier,
    transitions={
        ("q0", "LETTER_OR_UNDERSCORE"): "q_accept",
        ("q_accept", "LETTER_OR_UNDERSCORE"): "q_accept",
        ("q_accept", "DIGIT"): "q_accept",
    },
    start_state="q0",
    accepting_states={"q_accept"},
)


# 2. Decimal & Float Number DFA: [0-9]+(\.[0-9]+)?
def _number_classifier(ch: str) -> str:
    if "0" <= ch <= "9":
        return "DIGIT"
    elif ch == ".":
        return "DOT"
    return "OTHER"


NUMBER_DFA = DFA(
    name="DECIMAL_FLOAT_DFA",
    states={"q0", "q_int", "q_dot", "q_float", "DEAD"},
    alphabet_desc="[0-9]+(\\.[0-9]+)?",
    char_classifier=_number_classifier,
    transitions={
        ("q0", "DIGIT"): "q_int",
        ("q_int", "DIGIT"): "q_int",
        ("q_int", "DOT"): "q_dot",
        ("q_dot", "DIGIT"): "q_float",
        ("q_float", "DIGIT"): "q_float",
    },
    start_state="q0",
    accepting_states={"q_int", "q_float"},
)


# 3. Decimal Integer with Underscores DFA: [0-9](_?[0-9])*
def _int_underscore_classifier(ch: str) -> str:
    if "0" <= ch <= "9":
        return "DIGIT"
    elif ch == "_":
        return "UNDERSCORE"
    return "OTHER"


INT_UNDERSCORE_DFA = DFA(
    name="INT_WITH_UNDERSCORES_DFA",
    states={"q0", "q_digit", "q_under", "DEAD"},
    alphabet_desc="[0-9](_?[0-9])*",
    char_classifier=_int_underscore_classifier,
    transitions={
        ("q0", "DIGIT"): "q_digit",
        ("q_digit", "DIGIT"): "q_digit",
        ("q_digit", "UNDERSCORE"): "q_under",
        ("q_under", "DIGIT"): "q_digit",
    },
    start_state="q0",
    accepting_states={"q_digit"},
)
