"""reverify_compiler_features.py - Exhaustive Reverification Script for IntelliFix.

Tests all 5 newly added compiler & program analysis features:
1. Semantic Analysis & Symbol Table
2. Intermediate Representation (TAC & SSA)
3. Dataflow Taint Analysis & Reaching Definitions
4. Multi-Pass Compiler Optimizer & Security-Aware DCE
5. Translation Validation (Differential Testing & SMT Equivalence)
6. API Endpoints & Flask Integration
7. Frontend Templates & DOM Elements
"""

import sys
import os
import json
import ast

def test_feature_1_semantic_analysis():
    print("--- [1/5] Testing Semantic Analysis & Symbol Table ---")
    import semantic_analyzer

    code = """
total_amount = 100

def process_order(price, quantity):
    disc = 5
    if quantity > 10:
        total = price * quantity - disc
    else:
        total = price * quantity
    return total

def buggy_function():
    # Use before assignment
    print(val)
    val = 42

def undefined_demo():
    print(totl_amount + 10)

def type_mismatch_demo():
    x = "hello" + 42
"""
    res = semantic_analyzer.analyze_semantics(code)
    assert res["success"] is True, "Semantic analysis failed unexpectedly"

    # Check symbol table
    symbols = {s["name"]: s for s in res["symbol_table"]}
    assert "total_amount" in symbols, "Missing 'total_amount' in symbol table"
    assert "process_order" in symbols, "Missing 'process_order' in symbol table"
    print(f"  [OK] Extracted {len(symbols)} symbols in symbol table across scopes.")

    # Check use before assignment
    uba = res["use_before_assignment"]
    assert any(u["variable"] == "val" for u in uba), f"Failed to detect use-before-assignment on 'val': {uba}"
    print("  [OK] Successfully detected use-before-assignment (UnboundLocalError).")

    # Check undefined variable & grounded "Did you mean...?"
    undef = res["undefined_variables"]
    assert any(u["variable"] == "totl_amount" for u in undef), f"Failed to detect undefined 'totl_amount': {undef}"
    totl_item = next(u for u in undef if u["variable"] == "totl_amount")
    assert totl_item.get("did_you_mean", {}).get("name") == "total_amount", f"Did you mean failed: {totl_item}"
    print(f"  [OK] Symbol-table grounded suggestion: '{totl_item['variable']}' -> Did you mean '{totl_item['did_you_mean']['name']}'?")

    # Check type mismatch
    type_errs = res["type_mismatches"]
    assert len(type_errs) > 0, "Failed to detect type mismatch ('hello' + 42)"
    print(f"  [OK] Type checker flagged invalid binary op: {type_errs[0]['message']}")
    print("  => Feature 1 VERIFIED PASS.\n")


def test_feature_2_ir_tac_and_ssa():
    print("--- [2/5] Testing Intermediate Representation (TAC & SSA) ---")
    import ir_generator

    code = """
def compute(x, y):
    a = x + y * 2
    if a > 10:
        r = a * 3
    else:
        r = a - 1
    return r
"""
    ir_out = ir_generator.generate_ir(code)
    assert ir_out["success"] is True, "IR generation failed"
    tac_text = ir_out["tac_text"]
    assert "ADD" in tac_text or "+" in tac_text, "Missing arithmetic in TAC"
    assert "JUMP_IF_FALSE" in tac_text or "if" in tac_text.lower(), "Missing branch instruction in TAC"
    print(f"  [OK] Lowered AST to {ir_out['instruction_count']} TAC instructions.")

    # Basic blocks
    blocks = ir_out["blocks"]
    assert len(blocks) >= 3, f"Expected at least 3 basic blocks (if, then, else, join), got {len(blocks)}"
    print(f"  [OK] Partitioned TAC into {len(blocks)} basic blocks with CFG predecessor/successor links.")

    # SSA form
    ssa_out = ir_generator.generate_ir_for_code(code, ssa=True)
    assert ssa_out["success"] is True, "SSA generation failed"
    phi_found = "PHI" in ssa_out["tac_text"]
    assert phi_found, "Expected at least one PHI node in SSA form at convergence point"
    print("  [OK] SSA transformation correctly synthesized PHI nodes at confluence points.")

    # IR Comparison
    fixed_code = code.replace("a * 3", "a * 4")
    cmp_res = ir_generator.compare_code_ir(code, fixed_code)
    assert cmp_res["success"] is True, "IR comparison failed"
    assert cmp_res["ir_changed"] is True, "IR should show differences"
    assert len(cmp_res["diff_lines"]) > 0, "Diff lines empty"
    print(f"  [OK] IR Diff engine generated unified before/after comparison ({len(cmp_res['diff_lines'])} diff lines).")
    print("  => Feature 2 VERIFIED PASS.\n")


def test_feature_3_dataflow_taint():
    print("--- [3/5] Testing Dataflow Taint Analysis & Reaching Definitions ---")
    import dataflow_engine

    # Vulnerable code with multi-step propagation
    vuln_code = """
import os

def handle_request():
    user_payload = input("Enter command: ")
    cmd_prefix = "run --arg="
    final_cmd = cmd_prefix + user_payload
    os.system(final_cmd)
"""
    vuln_res = dataflow_engine.analyze_dataflow(vuln_code)
    assert vuln_res["taint_detected"] is True, "Failed to detect taint flow"
    findings = vuln_res["findings"]
    assert len(findings) > 0, "No findings generated"
    top_finding = findings[0]
    assert top_finding["source"] in ("input", "input()"), f"Wrong source: {top_finding['source']}"
    assert top_finding["sink"] in ("os.system", "os.system()"), f"Wrong sink: {top_finding['sink']}"
    assert top_finding["risk_score"] >= 80, f"Risk score too low: {top_finding['risk_score']}"
    assert "input()" in top_finding["explanation"] and "os.system" in top_finding["explanation"]
    print(f"  [OK] Taint detected with path explanation: {top_finding['explanation']}")
    print(f"  [OK] Risk Score: {top_finding['risk_score']}/100, Severity: {top_finding['severity']}")

    # Sanitized code (should NOT trigger vulnerability)
    safe_sanitized_code = """
import os

def handle_request():
    user_num = input("Enter port: ")
    port = int(user_num)
    os.system(f"nc -l {port}")
"""
    safe_res = dataflow_engine.analyze_dataflow(safe_sanitized_code)
    # The int() sanitizer neutralizes taint
    assert safe_res["taint_detected"] is False, "Sanitization failed to neutralize taint!"
    print("  [OK] Sanitization barrier (int()) successfully neutralized untrusted taint.")

    # Reaching definitions
    assert len(vuln_res["reaching_definitions"]) > 0, "Reaching definitions empty"
    print(f"  [OK] Kildall fixed-point dataflow computed {len(vuln_res['reaching_definitions'])} reaching definition sets.")
    print("  => Feature 3 VERIFIED PASS.\n")


def test_feature_4_ir_optimizer():
    print("--- [4/5] Testing Real Multi-Pass IR Optimizer & Security-Aware DCE ---")
    import ir_optimizer

    code = """
def process(x):
    a = 10 + 20
    b = x * 2
    c = b ** 2
    d = c * 0
    token = "sk_live_secret_key_12345"
    token = ""
    dead_temp = 999
    return b + a
"""
    opt = ir_optimizer.IROptimizer(code)
    res = opt.optimize()

    # Verify pass count
    assert len(res["passes"]) == 5, f"Expected 5 passes, got {len(res['passes'])}"
    print("  [OK] Successfully executed all 5 formal compiler passes:")
    for p in res["passes"]:
        print(f"       - {p['pass_name']}: {p['transformations_count']} transformations ({p['description']})")

    # Verify constant folding: 10 + 20 -> 30
    folding_pass = res["passes"][0]
    assert folding_pass["transformations_count"] >= 1, "Constant folding found no transformations"
    print("  [OK] Constant Folding successfully evaluated static subexpressions.")

    # Verify strength reduction: a * 2 -> a + a, b ** 2 -> b * b, c * 0 -> 0
    sr_pass = res["passes"][1]
    assert sr_pass["transformations_count"] >= 2, f"Strength reduction found {sr_pass['transformations_count']}"
    print(f"  [OK] Strength Reduction transformed {sr_pass['transformations_count']} arithmetic operations.")

    # CRITICAL: Verify Security-Aware Dead Code Elimination
    dce_pass = res["passes"][4]
    assert len(dce_pass["security_invariants_preserved"]) > 0, "Security DCE failed to preserve sensitive store!"
    assert any("token" in msg for msg in dce_pass["security_invariants_preserved"]), "Token zeroing was not preserved!"
    assert "token = ''" in res["optimized_tac"] or "token = \"\"" in res["optimized_tac"] or "token" in res["optimized_tac"], \
        "Optimized TAC stripped sensitive credential zeroing!"
    print(f"  [OK] Security-Aware DCE successfully intercepted and preserved: {dce_pass['security_invariants_preserved']}")
    print("  => Feature 4 VERIFIED PASS.\n")


def test_feature_5_translation_validation():
    print("--- [5/5] Testing Translation Validation & Equivalence Prover ---")
    import translation_validator

    # Test 1: Functionally equivalent functions
    orig_eq = """
def scale(x):
    return x * 2
"""
    fixed_eq = """
def scale(x):
    return x + x
"""
    val_eq = translation_validator.validate_translation(orig_eq, fixed_eq)
    assert val_eq["equivalent"] is True, f"Failed to prove equivalence: {val_eq}"
    assert val_eq["status"] == "PROVEN_EQUIVALENT", f"Wrong status: {val_eq['status']}"
    print(f"  [OK] Proven Equivalent: Status='{val_eq['status']}', Verified on {val_eq['differential_testing']['passed_tests']} fuzzing inputs.")

    # Test 2: Functionally divergent functions (regression detection)
    orig_div = """
def compute(x):
    return x * 2
"""
    fixed_div = """
def compute(x):
    return x + 2
"""
    val_div = translation_validator.validate_translation(orig_div, fixed_div)
    assert val_div["equivalent"] is False, "Failed to catch semantic divergence!"
    assert val_div["counterexample"] is not None, "Missing counterexample for divergent fix"
    print(f"  [OK] Semantic Divergence Flagged! Status='{val_div['status']}'")
    print(f"  [OK] Isolated concrete counterexample: {val_div['counterexample']['explanation']}")
    print("  => Feature 5 VERIFIED PASS.\n")


def test_feature_6_flask_routes():
    print("--- Testing API Endpoints in app.py ---")
    from app import app
    client = app.test_client()

    routes_to_test = [
        ("/api/semantic/analyze", {"code": "x = 10\ny = x + 2\n"}),
        ("/api/ir/generate", {"code": "def f(x):\n    return x + 1\n"}),
        ("/api/ir/compare", {"original_code": "x = 1\n", "fixed_code": "x = 2\n"}),
        ("/api/dataflow/taint", {"code": "import os\ncmd = input()\nos.system(cmd)\n"}),
        ("/api/compiler/optimize", {"code": "def f():\n    return 2 + 3\n"}),
        ("/api/translation/validate", {
            "original_code": "def f(x):\n    return x * 2\n",
            "fixed_code": "def f(x):\n    return x + x\n"
        }),
    ]

    for path, payload in routes_to_test:
        resp = client.post(path, json=payload)
        assert resp.status_code == 200, f"Route {path} returned status {resp.status_code}: {resp.data}"
        data = resp.get_json()
        assert data.get("status") in ("success", "PROVEN_EQUIVALENT", "DIFFERENTIAL_PASSED") or data.get("success") is True, f"Route {path} returned unsuccessful payload: {data}"
        print(f"  [OK] POST {path} -> 200 OK (status: success)")

    # Test /api/analyze full pipeline integration
    full_resp = client.post("/api/analyze", json={"code": "import os\nx = input()\nos.system(x)\n"})
    assert full_resp.status_code == 200
    full_data = full_resp.get_json()
    assert "semantic_analysis" in full_data, "Missing semantic_analysis in /api/analyze"
    assert "dataflow_taint" in full_data, "Missing dataflow_taint in /api/analyze"
    assert "ir_representation" in full_data, "Missing ir_representation in /api/analyze"
    print("  [OK] POST /api/analyze contains all 5 integrated subsystem payloads.")
    print("  => API Endpoints VERIFIED PASS.\n")


def test_feature_7_ui_templates():
    print("--- Testing UI DOM Elements in templates/index.html ---")
    template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
    if not os.path.exists(template_path):
        template_path = os.path.join("templates", "index.html")
    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    expected_elements = [
        # Sidebar launcher buttons
        'id="w3_btn_open_semantics"',
        'id="w3_btn_open_ir"',
        'id="w3_btn_open_taint"',
        'id="w3_btn_open_ir_opt"',
        'id="w3_btn_open_translation_val"',
        # Modals
        'id="w3_modal_semantics"',
        'id="w3_modal_ir"',
        'id="w3_modal_taint"',
        'id="w3_modal_ir_opt"',
        'id="w3_modal_translation_val"',
        # JavaScript handlers
        'runSemanticAnalysis',
        'runIRGenerate',
        'runIRCompare',
        'runDataflowTaint',
        'runIROptimizer',
        'runTranslationValidation',
    ]

    for el in expected_elements:
        assert el in html, f"Missing element or handler in templates/index.html: {el}"
        print(f"  [OK] Found UI element: {el}")
    print("  => UI Integration VERIFIED PASS.\n")


if __name__ == "__main__":
    print("======================================================================")
    print("INTELLIFIX COMPILER & PROGRAM ANALYSIS DEEP REVERIFICATION")
    print("======================================================================")
    try:
        test_feature_1_semantic_analysis()
        test_feature_2_ir_tac_and_ssa()
        test_feature_3_dataflow_taint()
        test_feature_4_ir_optimizer()
        test_feature_5_translation_validation()
        test_feature_6_flask_routes()
        test_feature_7_ui_templates()
        print("======================================================================")
        print("ALL 5 FEATURES + API + UI REVERIFIED AND 100% OPERATIONAL!")
        print("======================================================================")
    except AssertionError as e:
        print(f"\n[REVERIFICATION FAILURE] {e}")
        sys.exit(1)
    except Exception as e:
        import traceback
        traceback.print_exc()
        sys.exit(2)
