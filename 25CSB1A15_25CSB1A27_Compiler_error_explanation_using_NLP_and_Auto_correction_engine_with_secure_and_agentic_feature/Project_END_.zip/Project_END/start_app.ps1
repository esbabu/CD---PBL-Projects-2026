<#
.SYNOPSIS
    Starts the Python Error Analysis & Auto-Correction server with automatic stale-process cleanup.

.PARAMETER Force
    If specified, stops all existing app.py server processes for this project before launching.
#>
[CmdletBinding()]
param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

$appPath = Join-Path $scriptDir "app.py"
if (-not (Test-Path $appPath)) {
    Write-Error "app.py not found in $scriptDir"
    exit 1
}

$appMTime = (Get-Item $appPath).LastWriteTime
Write-Host "=================================================" -ForegroundColor Cyan
Write-Host "TOC Project Server Starter" -ForegroundColor Cyan
Write-Host "Project Directory: $scriptDir"
Write-Host "app.py Last Modified: $appMTime"
Write-Host "================================================="

# Auto-load .env file into current process environment if present
$envFilePath = Join-Path $scriptDir ".env"
if (Test-Path $envFilePath) {
    Get-Content $envFilePath | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith("#") -and $line.Contains("=")) {
            $parts = $line.Split("=", 2)
            $k = $parts[0].Trim()
            $v = $parts[1].Trim().Trim('"').Trim("'")
            if ($k -and -not [System.Environment]::GetEnvironmentVariable($k)) {
                [System.Environment]::SetEnvironmentVariable($k, $v, "Process")
            }
        }
    }
}

if ($env:LLM_DISABLED) {
    Write-Host "[WARNING] LLM_DISABLED is set in environment: '$($env:LLM_DISABLED)' (LLM explanation tier will be disabled)." -ForegroundColor Yellow
}
if ($env:AUTOFIX_AI) {
    Write-Host "[WARNING] AUTOFIX_AI is set in environment: '$($env:AUTOFIX_AI)' (AI autofix mode is overridden)." -ForegroundColor Yellow
}

# Locate venv python (prefer project-local venvs, then user venv, then PATH)
$candidatePythons = @(
    (Join-Path $scriptDir "venv\Scripts\python.exe"),
    (Join-Path $scriptDir ".venv\Scripts\python.exe"),
    "C:\Users\lsrin\venvs\toc_project\Scripts\python.exe",
    "C:\Users\lsrin\venvs\toc_project\Scripts\pythonw.exe"
)

$venvPython = $null
foreach ($cand in $candidatePythons) {
    if (Test-Path $cand) {
        $venvPython = $cand
        break
    }
}

if (-not $venvPython) {
    $cmdPython = Get-Command "python.exe" -ErrorAction SilentlyContinue
    if ($cmdPython) {
        $venvPython = $cmdPython.Source
    } else {
        $venvPython = "python.exe"
    }
}

# 1. Discover existing python processes running this project's app.py
$procs = Get-CimInstance Win32_Process -Filter "Name LIKE 'python%.exe'" | Where-Object {
    $_.CommandLine -and ($_.CommandLine -like "*app.py*" -or $_.CommandLine -like "*gui.py*") -and ($_.CommandLine -like "*TOC_PROJECT*")
}

if ($procs) {
    Write-Host "`nFound active project python processes:" -ForegroundColor Yellow
    foreach ($p in $procs) {
        $targetPid = $p.ProcessId
        $createTime = $p.CreationDate
        $conns = Get-NetTCPConnection -OwningProcess $targetPid -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalPort
        $portsStr = if ($conns) { ($conns -join ", ") } else { "None" }
        Write-Host "  PID: $targetPid | Created: $createTime | Ports: $portsStr"
        
        $shouldKill = $false
        if ($Force) {
            $shouldKill = $true
            Write-Host "    -> Stopping PID $targetPid (-Force specified)" -ForegroundColor Red
        } elseif ($createTime -lt $appMTime) {
            $shouldKill = $true
            Write-Host "    -> Stopping PID $targetPid (Stale: created before app.py last modified)" -ForegroundColor Red
        } else {
            Write-Host "    -> Keeping PID $targetPid (Up to date)" -ForegroundColor Green
        }
        
        if ($shouldKill) {
            Stop-Process -Id $targetPid -Force -ErrorAction SilentlyContinue
        }
    }
} else {
    Write-Host "No prior project python processes running." -ForegroundColor Gray
}

# Ensure port 5000 is free or check if already running current version
$port5000Proc = Get-NetTCPConnection -LocalPort 5000 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($port5000Proc) {
    $owningPid = $port5000Proc.OwningProcess
    if ($Force) {
        Write-Host "Stopping PID $owningPid on port 5000 (-Force specified)..." -ForegroundColor Red
        Stop-Process -Id $owningPid -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
    } else {
        try {
            $versionResp = Invoke-RestMethod -Uri "http://127.0.0.1:5000/api/version" -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($versionResp) {
                Write-Host "`nPort 5000 is already running server with build marker: $($versionResp.build_marker)" -ForegroundColor Green
                Write-Host "URL: http://127.0.0.1:5000" -ForegroundColor Cyan
                exit 0
            }
        } catch {
            # Process on 5000 not responding to /api/version
            Write-Host "Port 5000 occupied by PID $owningPid without /api/version. Stopping PID $owningPid..." -ForegroundColor Yellow
            Stop-Process -Id $owningPid -Force -ErrorAction SilentlyContinue
        }
    }
}

# 2. Start the app with the venv Python in the background (detached process)
Write-Host "`nStarting server with $venvPython..." -ForegroundColor Cyan
$launcherCode = "import subprocess, sys; subprocess.Popen([sys.argv[1], 'app.py'], cwd=sys.argv[2], creationflags=0x00000008 | 0x00000200)"
& $venvPython -c $launcherCode $venvPython $scriptDir

# 3. Wait until /api/version answers
Write-Host "Waiting for server to initialize..." -NoNewline
$maxAttempts = 30
$running = $false
$versionInfo = $null

for ($i = 0; $i -lt $maxAttempts; $i++) {
    Start-Sleep -Milliseconds 500
    Write-Host "." -NoNewline
    try {
        $versionInfo = Invoke-RestMethod -Uri "http://127.0.0.1:5000/api/version" -TimeoutSec 2 -ErrorAction Stop
        if ($versionInfo -and $versionInfo.build_marker) {
            $running = $true
            break
        }
    } catch {
        # Keep waiting
    }
}
Write-Host ""

if ($running) {
    Write-Host "=================================================" -ForegroundColor Green
    Write-Host "Server successfully started (Loopback Only)!" -ForegroundColor Green
    Write-Host "Local Access:   http://127.0.0.1:5000" -ForegroundColor Cyan
    Write-Host "Security Mode:  Localhost only (DNS rebinding / LAN access protected)" -ForegroundColor Gray
    Write-Host "Build Marker:   $($versionInfo.build_marker)" -ForegroundColor Yellow
    Write-Host "Started At:     $($versionInfo.process_start_time)"
    Write-Host "App Path:       $($versionInfo.app_path)"
    Write-Host "================================================="
} else {
    Write-Error "Server failed to respond on http://127.0.0.1:5000/api/version within 15 seconds."
    exit 1
}
