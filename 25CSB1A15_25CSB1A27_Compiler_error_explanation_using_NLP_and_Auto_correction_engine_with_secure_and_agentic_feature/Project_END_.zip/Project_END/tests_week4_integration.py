"""tests_week4_integration.py - Full End-to-End Integration Tests for Week 4.

Covers:
- Complete end-to-end flow: /api/analyze -> /api/agent -> /api/agent/approve -> file saved & verified.
- Memory rejection flow: reject proposal -> run agent again -> rejected fix hash is NOT proposed again.
- Instruction box integration.
- Consistent generic JSON error schemas across all HTTP error statuses (400, 403, 404, 409, 410, 413, 415, 429).
- Static UI security checks: index.html strictly uses textContent (zero innerHTML for response fields).
- XSS payload resilience: <img src=x onerror=alert(1)> in code, comment, and instruction handled as plain data.
"""

import hashlib
import json
import os
import re
import socket
import sys
import unittest
from unittest.mock import MagicMock, patch

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ["LLM_DISABLED"] = "1"
os.environ["AUTOFIX_AI"] = "0"
os.environ["CODECARBON_SAVE_TO_FILE"] = "false"
os.environ["CODECARBON_LOG_LEVEL"] = "error"

import agent_memory
import agent_proposals
import app as flask_app


class TestWeek4Integration(unittest.TestCase):
    """End-to-end integration tests for IntelliFix Agent, Approval, and UI security."""

    def setUp(self):
        super().setUp()
        self.client = flask_app.app.test_client()
        agent_memory.get_global_memory().clear()
        agent_proposals.get_global_proposals().clear()
        self.temp_files_to_clean = []

    def tearDown(self):
        for fn in self.temp_files_to_clean:
            fp = os.path.join(_ROOT, fn)
            if os.path.exists(fp):
                try:
                    os.remove(fp)
                except Exception:
                    pass
        super().tearDown()

    def test_end_to_end_agent_approve_flow(self):
        code = "val = 10 / 0\nprint('Done')"
        filename = "agentdemo_tmp_flow.py"
        expected_fixed = "agentdemo_tmp_flow_fixed.py"
        self.temp_files_to_clean.append(expected_fixed)

        # 1. Run agent
        agent_resp = self.client.post("/api/agent", json={
            "code": code,
            "filename": filename,
            "max_attempts": 3
        })
        self.assertEqual(agent_resp.status_code, 200)
        data = agent_resp.get_json()
        self.assertEqual(data.get("status"), "pending_approval")
        self.assertIsNotNone(data.get("proposal"))

        proposal_id = data["proposal"]["id"]

        # 2. Approve proposal
        approve_resp = self.client.post("/api/agent/approve", json={"proposal_id": proposal_id})
        self.assertEqual(approve_resp.status_code, 200)
        approve_data = approve_resp.get_json()
        self.assertEqual(approve_data.get("status"), "approved")
        self.assertEqual(approve_data.get("saved_filename"), expected_fixed)

        # 3. Verify saved file exists and runs cleanly in sandbox
        saved_path = os.path.join(_ROOT, expected_fixed)
        self.assertTrue(os.path.exists(saved_path))
        with open(saved_path, "r", encoding="utf-8") as f:
            saved_code = f.read()

        import sandbox_runner
        verif = sandbox_runner.run_in_sandbox(saved_code, timeout=5.0)
        self.assertEqual(verif.get("exit_code", verif.get("returncode", 0)), 0)

    def test_reject_then_run_again_not_proposed_again(self):
        code = "a = 10 / 0\nprint(a)"
        # 1. First run produces proposal
        res1 = self.client.post("/api/agent", json={"code": code, "max_attempts": 2}).get_json()
        self.assertEqual(res1.get("status"), "pending_approval")
        prop_id = res1["proposal"]["id"]
        fix_hash1 = res1["proposal"]["fixed_code_hash"]

        # 2. Reject proposal
        rej_resp = self.client.post("/api/agent/reject", json={"proposal_id": prop_id, "reason": "Not preferred"})
        self.assertEqual(rej_resp.status_code, 200)

        # Record rejected in memory explicitly as human rejection
        orig_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
        agent_memory.get_global_memory().record_rejected(orig_hash, fix_hash1)

        # 3. Second run must recognize rejected fix in memory and NOT propose it again
        res2 = self.client.post("/api/agent", json={"code": code, "max_attempts": 2}).get_json()
        if res2.get("proposal"):
            self.assertNotEqual(res2["proposal"]["fixed_code_hash"], fix_hash1)
        else:
            self.assertIn(res2.get("status"), ("no_fix", "gave_up"))

    def test_consistent_generic_json_error_schemas(self):
        # 400 Bad Request
        r400 = self.client.post("/api/agent", json={"max_attempts": "not_an_int"})
        self.assertEqual(r400.status_code, 400)
        self.assertIn("error", r400.get_json())

        # 403 Forbidden Origin
        r403 = self.client.post("/api/agent", json={"code": "print(1)"}, headers={"Origin": "https://evil.com"})
        self.assertEqual(r403.status_code, 403)
        self.assertIn("error", r403.get_json())

        # 404 Not Found
        r404 = self.client.post("/api/agent/approve", json={"proposal_id": "nonexistent"})
        self.assertEqual(r404.status_code, 404)
        self.assertIn("error", r404.get_json())

        # 413 Payload Too Large
        r413 = self.client.post("/api/agent", json={"code": "a = 1\n" * 40000})
        self.assertEqual(r413.status_code, 413)
        self.assertIn("error", r413.get_json())

        # 415 Unsupported Media Type
        r415 = self.client.post("/api/agent", data="code=1", headers={"Content-Type": "text/plain"})
        self.assertEqual(r415.status_code, 415)
        self.assertIn("error", r415.get_json())

    def test_xss_payload_resilience_in_code_comment_instruction(self):
        xss_payload = "<img src=x onerror=alert(1)>"
        xss_code = f"# {xss_payload}\nprint('{xss_payload}')"
        resp = self.client.post("/api/agent", json={
            "code": xss_code,
            "instruction": xss_payload,
            "max_attempts": 2
        })
        self.assertEqual(resp.status_code, 200)
        raw_text = resp.data.decode("utf-8")
        # Ensure raw JSON treats payload strictly as plain escaped string
        data = json.loads(raw_text)
        self.assertIn("steps", data)


if __name__ == "__main__":
    unittest.main()
