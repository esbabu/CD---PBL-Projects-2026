"""tests_llm.py – Mocked unit tests for LLMExplainer, multi-provider failover, grounding, and tolerant parser.

All tests use unittest.mock; no real network calls are made.
Run with: python -m unittest tests_llm -v
"""

import ast
import glob
import json
import os
import sys
import threading
import time
import unittest
from unittest.mock import MagicMock, patch, call

import llm_config
from llm_explainer import (
    LLMExplainer,
    _clean_markdown_to_plain_text,
    _is_trivial_or_destructive_fix,
    _normalize_and_validate_reply,
    get_call_counts,
    reset_call_counts,
)
from nlp_explainer import NLPExplainer

GOOD_REPLY = (
    "Mistake: Division by zero at line 1.\n"
    "Reason: The denominator evaluates to zero, which Python cannot handle.\n"
    "Fix: Replace line 1 with:\n    result = a / b if b != 0 else 0"
)

RULE_TYPES = [
    "ZeroDivisionError", "NameError", "IndexError", "TypeError",
    "ValueError", "SyntaxError", "IndentationError", "KeyError",
    "AttributeError", "FileNotFoundError",
]


class _BaseLLMTest(unittest.TestCase):
    def setUp(self):
        self.env_patcher = patch.dict(os.environ, {"LLM_DISABLED": "0"})
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)
        reset_call_counts()


class TestLLMExplainerGoodReply(_BaseLLMTest):
    """Good format -> reply returned as normalized string."""

    def test_good_format_accepted(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(GOOD_REPLY, None, False)):
            result = ex.explain("RecursionError", "max depth exceeded", 1, "def f():\n    return f()\nf()")
        self.assertIsNotNone(result)
        self.assertIn("Mistake:", result)
        self.assertIn("Reason:", result)
        self.assertIn("Fix:", result)


class TestLLMExplainerTolerantParser(_BaseLLMTest):
    """Tests for tolerant parsing of markdown, bold, bullets, dashes, and casing."""

    def _run(self, text):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(text, None, False)):
            return ex.explain("RecursionError", "depth", 1, "def f(): return f()\nf()")

    def test_markdown_bold_accepted(self):
        text = "**Mistake:** Infinite recursion on line 2.\n**Reason:** No base condition.\n**Fix:** Return 0."
        res = self._run(text)
        self.assertIsNotNone(res)
        self.assertTrue(res.startswith("Mistake: Infinite recursion"))
        self.assertIn("Reason: No base condition.", res)
        self.assertIn("Fix: Return 0.", res)

    def test_dashes_and_bullets_accepted(self):
        text = "* **Mistake** - Infinite loop on line 2\n* **Reason** - Condition never met\n* **Fix** - Add break"
        res = self._run(text)
        self.assertIsNotNone(res)
        self.assertIn("Mistake: Infinite loop", res)
        self.assertIn("Reason: Condition never met", res)
        self.assertIn("Fix: Add break", res)

    def test_case_insensitivity(self):
        text = "mistake: bad logic\nreason: cannot divide\nfix: check zero"
        res = self._run(text)
        self.assertIsNotNone(res)
        self.assertIn("Mistake: bad logic", res)
        self.assertIn("Reason: cannot divide", res)
        self.assertIn("Fix: check zero", res)

    def test_wrapping_code_fence_stripped(self):
        text = "```markdown\nMistake: line 1 error\nReason: invalid syntax\nFix: add colon\n```"
        res = self._run(text)
        self.assertIsNotNone(res)
        self.assertIn("Mistake: line 1 error", res)

    def test_markdown_to_plain_text_clean(self):
        md = "Mistake: line 1.\nReason: bad.\nFix: Replace line 1 with:\n```python\nresult = 1\n```"
        clean = _clean_markdown_to_plain_text(md)
        self.assertNotIn("```", clean)
        self.assertIn("    result = 1", clean)

    def test_trivial_fix_rejected(self):
        self.assertTrue(_is_trivial_or_destructive_fix("pass"))
        self.assertTrue(_is_trivial_or_destructive_fix("Replace line 2 with: return"))
        self.assertTrue(_is_trivial_or_destructive_fix("Remove line 10"))
        self.assertFalse(_is_trivial_or_destructive_fix("Replace line 2 with:\n    if n <= 0: return 1\n    return f(n-1)"))

    def test_normalize_validates_and_rejects_trivial(self):
        bad_reply = "Mistake: bad\nReason: why\nFix: pass"
        ok, norm, reason = _normalize_and_validate_reply(bad_reply)
        self.assertFalse(ok)
        self.assertIn("trivial", reason)


class TestLLMExplainerBadReplies(_BaseLLMTest):
    """Various invalid replies must return None and record last_error."""

    def _run(self, text):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(text, None, False)):
            return ex.explain("RecursionError", "depth", 1, "def f(): return f()\nf()"), ex.last_error

    def test_missing_reason_returns_none(self):
        res, err = self._run("Mistake: bad.\nFix: fix it")
        self.assertIsNone(res)
        self.assertIn("validation", err)

    def test_missing_fix_returns_none(self):
        res, err = self._run("Mistake: bad.\nReason: because.")
        self.assertIsNone(res)
        self.assertIn("validation", err)

    def test_empty_reply_returns_none(self):
        res, err = self._run("")
        self.assertIsNone(res)
        self.assertTrue(any(k in err for k in ("empty", "validation", "failed")))


    def test_none_reply_returns_none(self):
        res, err = self._run(None)
        self.assertIsNone(res)

    def test_over_1500_chars_returns_none(self):
        long = "Mistake: x.\nReason: y.\nFix: z.\n" + "x" * 1500
        res, err = self._run(long)
        self.assertIsNone(res)
        self.assertIn("validation", err)


class TestLLMExplainerNoKey(_BaseLLMTest):
    def test_no_key_returns_none(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=False), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False):
            result = ex.explain("RecursionError", "depth", 1, "code")
            self.assertIsNone(result)
            self.assertIn("No LLM API keys", ex.last_error)


class TestLLMExplainerTimeoutAndExceptions(_BaseLLMTest):
    def test_timeout_returns_none(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(None, "TimeoutError", False)):
            result = ex.explain("RecursionError", "depth", 1, "code")
        self.assertIsNone(result)
        self.assertIn("TimeoutError", ex.last_error)

    def test_arbitrary_exception_returns_none(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(None, "RuntimeError", False)):
            result = ex.explain("RecursionError", "depth", 1, "code")
        self.assertIsNone(result)
        self.assertIn("RuntimeError", ex.last_error)


class TestLLMProviderFailover(_BaseLLMTest):
    def setUp(self):
        super().setUp()
        reset_call_counts()

    def test_gemini_fails_groq_answers(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=True), \
             patch.object(ex.adapters["gemini"], "call", return_value=(None, "Gemini 500 error", True)), \
             patch.object(ex.adapters["groq"], "call", return_value=(GOOD_REPLY, None, False)):
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertIsNotNone(res)
            self.assertEqual(ex.last_provider, "Groq")

    def test_both_fail_returns_none(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=True), \
             patch.object(ex.adapters["gemini"], "call", return_value=(None, "error", True)), \
             patch.object(ex.adapters["groq"], "call", return_value=(None, "error", True)):
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertIsNone(res)

    def test_only_groq_key_present(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=False), \
             patch.object(ex.adapters["groq"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "call", return_value=(GOOD_REPLY, None, False)) as mock_groq_call:
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertIsNotNone(res)
            self.assertEqual(ex.last_provider, "Groq")
            mock_groq_call.assert_called_once()

    def test_only_gemini_key_present(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(GOOD_REPLY, None, False)) as mock_gem_call:
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertIsNotNone(res)
            self.assertEqual(ex.last_provider, "Gemini")
            mock_gem_call.assert_called_once()

    def test_provider_order_override(self):
        ex = LLMExplainer()
        with patch.dict(os.environ, {"LLM_PROVIDER_ORDER": "groq,gemini"}), \
             patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "call", return_value=(GOOD_REPLY, None, False)) as mock_groq, \
             patch.object(ex.adapters["gemini"], "call") as mock_gemini:
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertEqual(ex.last_provider, "Groq")
            mock_groq.assert_called_once()
            mock_gemini.assert_not_called()

    def test_llm_disabled_flag(self):
        ex = LLMExplainer()
        with patch.dict(os.environ, {"LLM_DISABLED": "1"}), \
             patch.object(ex.adapters["gemini"], "is_available", return_value=True):
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertIsNone(res)
            self.assertEqual(ex.last_error, "LLM_DISABLED=1")

    def test_no_sleeping_when_fallback_exists(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=True), \
             patch.object(ex.adapters["gemini"], "call", return_value=(None, "429", True)), \
             patch.object(ex.adapters["groq"], "call", return_value=(GOOD_REPLY, None, False)), \
             patch("time.sleep") as mock_sleep:
            res = ex.explain("RecursionError", "max depth", 2, "def f(): f()")
            self.assertEqual(ex.last_provider, "Groq")
            mock_sleep.assert_not_called()

    def test_shared_cache(self):
        ex = LLMExplainer()
        with patch.object(ex.adapters["gemini"], "is_available", return_value=True), \
             patch.object(ex.adapters["groq"], "is_available", return_value=False), \
             patch.object(ex.adapters["gemini"], "call", return_value=(GOOD_REPLY, None, False)) as mock_call:
            r1 = ex.explain("RecursionError", "max depth", 2, "code")
            r2 = ex.explain("RecursionError", "max depth", 2, "code")
            self.assertEqual(r1, r2)
            self.assertEqual(mock_call.call_count, 1)

    def test_per_provider_circuit_breaker(self):
        ex = LLMExplainer()
        gemini = ex.adapters["gemini"]
        for _ in range(3):
            gemini.record_failure()
        self.assertTrue(gemini.is_breaker_open())
        self.assertFalse(ex.adapters["groq"].is_breaker_open())


class TestNLPExplainerWiringAndCodePassing(_BaseLLMTest):
    def test_rule_types_never_call_any_provider(self):
        explainer = NLPExplainer()
        mock_llm = MagicMock()
        explainer._llm = mock_llm

        for etype in RULE_TYPES:
            ir = {
                "error_type": etype,
                "error_message": "some message",
                "line_number": 1,
                "traceback": "",
            }
            res = explainer.explain(ir, code="x = 1")
            self.assertEqual(explainer.last_source, "rule")

        mock_llm.explain.assert_not_called()

    def test_code_passed_to_llm(self):
        import nlp_explainer
        orig = nlp_explainer.USE_LLM
        try:
            nlp_explainer.USE_LLM = True
            explainer = NLPExplainer()
            mock_llm = MagicMock()
            mock_llm.explain.return_value = GOOD_REPLY
            mock_llm.last_provider = "Gemini"
            explainer._llm = mock_llm

            test_code = "def f():\n    return f()\nf()"
            ir = {
                "error_type": "RecursionError",
                "error_message": "max recursion",
                "line_number": 2,
                "traceback": ""
            }
            res = explainer.explain(ir, code=test_code)
            self.assertEqual(explainer.last_source, "ai")
            mock_llm.explain.assert_called_once_with("RecursionError", "max recursion", 2, test_code)
        finally:
            nlp_explainer.USE_LLM = orig

    def test_unrecognised_falls_to_offline_guide_when_llm_none(self):
        import nlp_explainer
        orig = nlp_explainer.USE_LLM
        try:
            nlp_explainer.USE_LLM = True
            explainer = NLPExplainer()
            mock_llm = MagicMock()
            mock_llm.explain.return_value = None
            explainer._llm = mock_llm

            ir = {
                "error_type": "RecursionError",
                "error_message": "maximum recursion depth exceeded",
                "line_number": 2,
                "traceback": 'File "<string>", line 2\nreturn f()'
            }
            res = explainer.explain(ir, code="def f():\n    return f()\nf()")
            self.assertEqual(explainer.last_source, "offline_guide")
            self.assertIn("[Offline guide - no AI used]", res)
        finally:
            nlp_explainer.USE_LLM = orig


class TestLLMCallsAccountingSecurity(_BaseLLMTest):
    """Rule 10: Verify no active project source file outside llm_calls.py directly invokes raw SDK APIs."""

    def test_no_external_raw_llm_api_calls(self):
        workspace = os.path.dirname(os.path.abspath(__file__))
        py_files = glob.glob(os.path.join(workspace, "*.py"))

        violations = []
        for p in py_files:
            rel = os.path.basename(p)
            # Skip llm_calls.py, tests, and backups
            if rel == "llm_calls.py" or rel.startswith("tests_") or "_before_" in rel:
                continue
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            for target in ["generate_content(", "chat.completions.create("]:
                if target in content:
                    violations.append((rel, target))

        self.assertEqual(violations, [], f"Direct raw client API calls found outside llm_calls.py: {violations}")


class TestLLMBudgetEnforcementAndAccounting(_BaseLLMTest):
    """Verify selective budget enforcement and continuous call counting."""

    def test_budget_unset_allows_call_beyond_cap(self):
        """When LLM_BUDGET_ENFORCE is unset, calls proceed even if counts >= cap."""
        import tempfile
        import llm_calls

        with tempfile.TemporaryDirectory() as tmpdir:
            t_budget = os.path.join(tmpdir, "budget.json")
            t_counts = os.path.join(tmpdir, ".call_counts.json")
            t_log = os.path.join(tmpdir, "call_log.jsonl")

            with open(t_budget, "w", encoding="utf-8") as f:
                json.dump({"gemini": 5, "groq": 5}, f)
            with open(t_counts, "w", encoding="utf-8") as f:
                json.dump({"gemini": 10, "groq": 10}, f)

            env = {"GEMINI_API_KEY": "fake_gemini_key", "LLM_DISABLED": "0"}
            with patch.dict(os.environ, env, clear=False), \
                 patch("llm_calls._BUDGET_FILE", t_budget), \
                 patch("llm_calls._COUNTS_FILE", t_counts), \
                 patch("llm_calls._LOG_FILE", t_log), \
                 patch("llm_calls._MIN_INTERVAL_SECONDS", {"gemini": 0.0, "groq": 0.0}), \
                 patch("llm_calls._get_gemini_client") as mock_client_getter:

                if "LLM_BUDGET_ENFORCE" in os.environ:
                    del os.environ["LLM_BUDGET_ENFORCE"]

                mock_client = MagicMock()
                mock_candidate = MagicMock()
                mock_candidate.finish_reason = None
                mock_response = MagicMock()
                mock_response.candidates = [mock_candidate]
                mock_response.text = GOOD_REPLY
                mock_client.models.generate_content.return_value = mock_response
                mock_client_getter.return_value = mock_client

                text, err, is_retry = llm_calls.call_gemini("test prompt")
                self.assertEqual(text, GOOD_REPLY)
                self.assertIsNone(err)

                with open(t_counts, "r", encoding="utf-8") as f:
                    c = json.load(f)
                self.assertEqual(c.get("gemini"), 11)

    def test_budget_enforced_refuses_call_at_cap(self):
        """When LLM_BUDGET_ENFORCE=1, calls are refused if counts >= cap."""
        import tempfile
        import llm_calls

        with tempfile.TemporaryDirectory() as tmpdir:
            t_budget = os.path.join(tmpdir, "budget.json")
            t_counts = os.path.join(tmpdir, ".call_counts.json")

            with open(t_budget, "w", encoding="utf-8") as f:
                json.dump({"gemini": 5, "groq": 5}, f)
            with open(t_counts, "w", encoding="utf-8") as f:
                json.dump({"gemini": 5, "groq": 5}, f)

            with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini_key", "LLM_BUDGET_ENFORCE": "1", "LLM_DISABLED": "0"}), \
                 patch("llm_calls._BUDGET_FILE", t_budget), \
                 patch("llm_calls._COUNTS_FILE", t_counts):

                with self.assertRaises(llm_calls.BudgetExceeded):
                    llm_calls._enforce_pre_call_checks("gemini")

    def test_counter_increments_in_both_modes(self):
        """Verify counters increment properly under both enforce=0/unset and enforce=1."""
        import tempfile
        import llm_calls

        with tempfile.TemporaryDirectory() as tmpdir:
            t_budget = os.path.join(tmpdir, "budget.json")
            t_counts = os.path.join(tmpdir, ".call_counts.json")
            t_log = os.path.join(tmpdir, "call_log.jsonl")

            with open(t_budget, "w", encoding="utf-8") as f:
                json.dump({"groq": 50}, f)
            with open(t_counts, "w", encoding="utf-8") as f:
                json.dump({"groq": 0}, f)

            with patch("llm_calls._BUDGET_FILE", t_budget), \
                 patch("llm_calls._COUNTS_FILE", t_counts), \
                 patch("llm_calls._LOG_FILE", t_log), \
                 patch("llm_calls._MIN_INTERVAL_SECONDS", {"gemini": 0.0, "groq": 0.0}), \
                 patch("llm_calls._get_groq_client") as mock_groq_getter:

                mock_client = MagicMock()
                mock_choice = MagicMock()
                mock_choice.finish_reason = "stop"
                mock_choice.message.content = GOOD_REPLY
                mock_resp = MagicMock()
                mock_resp.choices = [mock_choice]
                mock_client.chat.completions.create.return_value = mock_resp
                mock_groq_getter.return_value = mock_client

                # Mode 1: LLM_BUDGET_ENFORCE unset
                with patch.dict(os.environ, {"GROQ_API_KEY": "fake_groq_key", "LLM_DISABLED": "0"}):
                    if "LLM_BUDGET_ENFORCE" in os.environ:
                        del os.environ["LLM_BUDGET_ENFORCE"]
                    t1, _, _ = llm_calls.call_groq("prompt 1")
                    self.assertEqual(t1, GOOD_REPLY)

                with open(t_counts, "r", encoding="utf-8") as f:
                    c1 = json.load(f)
                self.assertEqual(c1.get("groq"), 1)

                # Mode 2: LLM_BUDGET_ENFORCE=1 (under cap)
                with patch.dict(os.environ, {"GROQ_API_KEY": "fake_groq_key", "LLM_BUDGET_ENFORCE": "1", "LLM_DISABLED": "0"}):
                    t2, _, _ = llm_calls.call_groq("prompt 2")
                    self.assertEqual(t2, GOOD_REPLY)

                with open(t_counts, "r", encoding="utf-8") as f:
                    c2 = json.load(f)
                self.assertEqual(c2.get("groq"), 2)

    def test_importing_app_does_not_set_budget_enforce(self):
        """Verify importing app does not set LLM_BUDGET_ENFORCE in environment."""
        import llm_calls
        with patch.dict(os.environ, {}, clear=False):
            if "LLM_BUDGET_ENFORCE" in os.environ:
                del os.environ["LLM_BUDGET_ENFORCE"]
            import app
            self.assertNotIn("LLM_BUDGET_ENFORCE", os.environ)
            self.assertFalse(llm_calls.is_budget_enforced())


if __name__ == "__main__":
    unittest.main(verbosity=2)
