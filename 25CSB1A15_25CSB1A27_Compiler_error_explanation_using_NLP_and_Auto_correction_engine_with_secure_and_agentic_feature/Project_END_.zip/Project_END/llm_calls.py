


"""llm_calls.py – Centralized, accountable, quota-safe wrapper for all real LLM calls.

Features:
- Enforces strict call budgets defined in benchmark/budget.json (raises BudgetExceeded).
- Logs every real call to benchmark/call_log.jsonl (timestamp, provider, purpose, ok, seconds).
- Updates benchmark/.call_counts.json after every call.
- Enforces thread-safe quota throttling (min 4.0s for Gemini, min 2.5s for Groq).
- Halts provider usage after 3 consecutive quota/rate-limit failures (raises QuotaExhausted).
- Sole authorized module for calling google.genai and groq client APIs.
"""

import json
import os
import threading
import time
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple

def _load_env_file():
    env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(env_file):
        try:
            with open(env_file, "r", encoding="utf-8") as _f:
                for _line in _f:
                    _line = _line.strip()
                    if _line and not _line.startswith("#") and "=" in _line:
                        _k, _v = _line.split("=", 1)
                        _k = _k.strip()
                        _v = _v.strip().strip('"').strip("'")
                        if _k:
                            os.environ[_k] = _v
        except Exception:
            pass
_load_env_file()

import llm_config

# ── Exceptions ───────────────────────────────────────────────────────────────

class BudgetExceeded(Exception):
    """Raised when a provider's call count has reached or exceeded its budget cap."""


class QuotaExhausted(Exception):
    """Raised when a provider has experienced 3 consecutive quota/rate-limit errors."""


# ── File Paths & Configuration ──────────────────────────────────────────────
_WORKSPACE = os.path.dirname(os.path.abspath(__file__))
_BUDGET_FILE = os.path.join(_WORKSPACE, "benchmark", "budget.json")
_COUNTS_FILE = os.path.join(_WORKSPACE, "benchmark", ".call_counts.json")
_LOG_FILE = os.path.join(_WORKSPACE, "benchmark", "call_log.jsonl")

_DEFAULT_BUDGETS: Dict[str, int] = {
    "gemini": 160,
    "groq": 200,
}

_MIN_INTERVAL_SECONDS: Dict[str, float] = {
    "gemini": 4.0,
    "groq": 2.5,
}

_QUOTA_ERROR_THRESHOLD = 3

# ── Thread-Safe Accounting State ─────────────────────────────────────────────
_LOCK = threading.Lock()
_LAST_CALL_TIMESTAMP: Dict[str, float] = {
    "gemini": 0.0,
    "groq": 0.0,
}
_CONSECUTIVE_QUOTA_ERRORS: Dict[str, int] = {
    "gemini": 0,
    "groq": 0,
}
_PROVIDER_QUOTA_HALTED: Dict[str, bool] = {
    "gemini": False,
    "groq": False,
}

# Cached client singletons
_GEMINI_CLIENT = None
_GROQ_CLIENT = None


def _load_budget() -> Dict[str, int]:
    """Load call budget caps from benchmark/budget.json."""
    if os.path.exists(_BUDGET_FILE):
        try:
            with open(_BUDGET_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return dict(_DEFAULT_BUDGETS)


def is_budget_enforced() -> bool:
    """Return whether call budget cap enforcement is actively enabled."""
    return os.environ.get("LLM_BUDGET_ENFORCE") == "1"


def get_call_counts() -> Dict[str, int]:
    """Return the current counts of calls made per provider."""
    with _LOCK:
        if os.path.exists(_COUNTS_FILE):
            try:
                with open(_COUNTS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"gemini": 0, "groq": 0}


def _update_call_accounting(provider: str, purpose: str, ok: bool, duration: float) -> None:
    """Update call log and counts file under lock."""
    # Ensure benchmark directory exists
    os.makedirs(os.path.join(_WORKSPACE, "benchmark"), exist_ok=True)

    # 1. Update counts file
    counts = {"gemini": 0, "groq": 0}
    if os.path.exists(_COUNTS_FILE):
        try:
            with open(_COUNTS_FILE, "r", encoding="utf-8") as f:
                counts = json.load(f)
        except Exception:
            counts = {"gemini": 0, "groq": 0}

    counts[provider] = counts.get(provider, 0) + 1

    with open(_COUNTS_FILE, "w", encoding="utf-8") as f:
        json.dump(counts, f, indent=2)

    # 2. Append to call_log.jsonl
    log_entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "provider": provider,
        "purpose": purpose,
        "ok": ok,
        "seconds": round(duration, 3),
    }
    with open(_LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(log_entry) + "\n")


def _enforce_pre_call_checks(provider: str) -> None:
    """Enforce budget check, quota halt check, and rate throttle."""
    with _LOCK:
        # Check if provider halted due to quota errors
        if _PROVIDER_QUOTA_HALTED.get(provider, False):
            raise QuotaExhausted(f"Provider '{provider}' halted due to consecutive quota errors (not_run: quota)")

        # Check budget cap (enforced only during benchmark / audit runs when LLM_BUDGET_ENFORCE=1)
        if os.environ.get("LLM_BUDGET_ENFORCE") == "1":
            budget = _load_budget()
            cap = budget.get(provider, _DEFAULT_BUDGETS.get(provider, 0))

            counts = {"gemini": 0, "groq": 0}
            if os.path.exists(_COUNTS_FILE):
                try:
                    with open(_COUNTS_FILE, "r", encoding="utf-8") as f:
                        counts = json.load(f)
                except Exception:
                    pass

            current_count = counts.get(provider, 0)
            if current_count >= cap:
                raise BudgetExceeded(f"Budget exceeded for provider '{provider}': {current_count}/{cap} calls used.")

        # Rate throttle
        now = time.monotonic()
        last_time = _LAST_CALL_TIMESTAMP.get(provider, 0.0)
        min_interval = _MIN_INTERVAL_SECONDS.get(provider, 2.0)
        elapsed = now - last_time
        if elapsed < min_interval:
            sleep_needed = min_interval - elapsed
            time.sleep(sleep_needed)
        _LAST_CALL_TIMESTAMP[provider] = time.monotonic()


def _record_call_result(provider: str, purpose: str, ok: bool, duration: float, is_quota_error: bool) -> None:
    """Record call metrics, log entry, and quota status."""
    with _LOCK:
        _update_call_accounting(provider, purpose, ok, duration)
        if is_quota_error:
            _CONSECUTIVE_QUOTA_ERRORS[provider] = _CONSECUTIVE_QUOTA_ERRORS.get(provider, 0) + 1
            if _CONSECUTIVE_QUOTA_ERRORS[provider] >= _QUOTA_ERROR_THRESHOLD:
                _PROVIDER_QUOTA_HALTED[provider] = True
        elif ok:
            _CONSECUTIVE_QUOTA_ERRORS[provider] = 0


# ── Client Access & Execution ───────────────────────────────────────────────

def _get_gemini_client(timeout_seconds: Optional[float] = None):
    global _GEMINI_CLIENT
    if _GEMINI_CLIENT is None:
        from google import genai
        from google.genai import types
        key = os.environ.get("GEMINI_API_KEY", "")
        t = timeout_seconds or llm_config.TIMEOUT_SECONDS
        _GEMINI_CLIENT = genai.Client(
            api_key=key,
            http_options=types.HttpOptions(timeout=int(t * 1000)),
        )
    return _GEMINI_CLIENT


def _get_groq_client(timeout_seconds: Optional[float] = None):
    global _GROQ_CLIENT
    if _GROQ_CLIENT is None:
        from groq import Groq
        key = os.environ.get("GROQ_API_KEY", "")
        t = timeout_seconds or llm_config.GROQ_TIMEOUT_SECONDS
        _GROQ_CLIENT = Groq(api_key=key, timeout=t)
    return _GROQ_CLIENT


def call_gemini(
    prompt: str,
    system_instruction: str = "",
    model: Optional[str] = None,
    purpose: str = "explainer",
    temperature: Optional[float] = None,
    max_output_tokens: Optional[int] = None,
    thinking_budget: Optional[int] = None,
    timeout: Optional[float] = None,
) -> Tuple[Optional[str], Optional[str], bool]:
    """Execute a real Gemini API call with accounting and rate-limiting.

    Returns (raw_text, error_msg, is_retryable).
    """
    if not os.environ.get("GEMINI_API_KEY"):
        return None, "GEMINI_API_KEY missing", False

    _enforce_pre_call_checks("gemini")

    model_name = model or llm_config.MODEL
    temp = temperature if temperature is not None else llm_config.TEMPERATURE
    max_tok = max_output_tokens or llm_config.MAX_OUTPUT_TOKENS
    tb = thinking_budget if thinking_budget is not None else getattr(llm_config, "THINKING_BUDGET", 0)

    start_time = time.monotonic()
    try:
        try:
            from google.genai import types
        except ImportError:
            types = None

        client = _get_gemini_client(timeout)
        gen_config_kwargs = {
            "system_instruction": system_instruction,
            "temperature": temp,
            "max_output_tokens": max_tok,
        }
        if types is not None and hasattr(types, "ThinkingConfig") and tb > 0:
            try:
                gen_config_kwargs["thinking_config"] = types.ThinkingConfig(thinking_budget=tb)
            except Exception:
                pass

        if types is not None and hasattr(types, "GenerateContentConfig"):
            config_arg = types.GenerateContentConfig(**gen_config_kwargs)
        else:
            config_arg = gen_config_kwargs

        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=config_arg,
        )

        duration = time.monotonic() - start_time

        if response.candidates:
            candidate = response.candidates[0]
            finish_reason = getattr(candidate, "finish_reason", None)
            finish_str = str(finish_reason).upper() if finish_reason else ""
            if "MAX_TOKEN" in finish_str or "LENGTH" in finish_str:
                _record_call_result("gemini", purpose, False, duration, False)
                return None, "reply truncated by token limit", False

        text = (response.text or "").strip()
        if not text:
            _record_call_result("gemini", purpose, False, duration, False)
            return None, "empty reply from Gemini", False

        _record_call_result("gemini", purpose, True, duration, False)
        return text, None, False

    except Exception as exc:
        duration = time.monotonic() - start_time
        exc_str = repr(exc).lower()
        is_quota = any(k in exc_str for k in ("429", "resource_exhausted", "quota", "rate_limit"))
        is_retryable = is_quota or any(k in exc_str for k in ("503", "unavailable", "overloaded", "timeout"))
        _record_call_result("gemini", purpose, False, duration, is_quota)
        return None, f"Gemini error: {exc}", is_retryable


def call_groq(
    prompt: str,
    system_instruction: str = "",
    model: Optional[str] = None,
    purpose: str = "explainer",
    temperature: Optional[float] = None,
    max_output_tokens: Optional[int] = None,
    timeout: Optional[float] = None,
) -> Tuple[Optional[str], Optional[str], bool]:
    """Execute a real Groq API call with accounting and rate-limiting.

    Returns (raw_text, error_msg, is_retryable).
    """
    if not os.environ.get("GROQ_API_KEY"):
        return None, "GROQ_API_KEY missing", False

    _enforce_pre_call_checks("groq")

    model_name = model or llm_config.GROQ_MODEL
    temp = temperature if temperature is not None else llm_config.TEMPERATURE
    max_tok = max_output_tokens or llm_config.MAX_OUTPUT_TOKENS

    start_time = time.monotonic()
    try:
        client = _get_groq_client(timeout)
        messages = []
        if system_instruction:
            messages.append({"role": "system", "content": system_instruction})
        messages.append({"role": "user", "content": prompt})

        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=temp,
            max_tokens=max_tok,
        )

        duration = time.monotonic() - start_time

        if response.choices:
            choice = response.choices[0]
            finish_reason = getattr(choice, "finish_reason", "")
            if finish_reason == "length":
                _record_call_result("groq", purpose, False, duration, False)
                return None, "reply truncated by token limit", False

            text = (choice.message.content or "").strip()
            if not text:
                _record_call_result("groq", purpose, False, duration, False)
                return None, "empty reply from Groq", False

            _record_call_result("groq", purpose, True, duration, False)
            return text, None, False

        _record_call_result("groq", purpose, False, duration, False)
        return None, "no choices returned from Groq", False

    except Exception as exc:
        duration = time.monotonic() - start_time
        exc_str = repr(exc).lower()
        is_quota = any(k in exc_str for k in ("429", "rate_limit", "quota"))
        is_retryable = is_quota or any(k in exc_str for k in ("503", "500", "overloaded", "service_unavailable", "timeout"))
        _record_call_result("groq", purpose, False, duration, is_quota)
        return None, f"Groq error: {exc}", is_retryable
