"""tests_ui.py – UI frontend contract and rendering tests.

Validates:
(a) Flask API response field types for all statuses (security_blocked, success, error_intercepted, timeout, empty, non-ASCII) match what the frontend expects.
(b) Static inspection of templates/index.html confirms the toText normalising helper is defined and applied across unsafe rendering sites.
(c) Headless Node.js execution of rendering logic against real Phase 1 JSON responses with a minimal DOM stub.
"""

import os
import sys
import json
import subprocess
import unittest
from unittest.mock import patch

from app import app


class TestUIContractAndRendering(unittest.TestCase):
    def setUp(self):
        self.env_patcher = patch.dict(os.environ, {
            "LLM_DISABLED": "1",
            "AUTOFIX_AI": "0",
            "CODECARBON_SAVE_TO_FILE": "false",
            "CODECARBON_LOG_LEVEL": "error"
        })
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)
        self.client = app.test_client()

    def test_case_c4_security_blocked_types(self):
        """Case C4: Blocked security code response fields must have safe string and list types."""
        code = 'import os\nos.system("echo hi")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "security_blocked")
        self.assertIsInstance(data.get("metrics"), str, "metrics field must be a string, not array or tuple")
        self.assertIsInstance(data.get("security_alerts"), list)
        self.assertIsInstance(data.get("raw_text"), str)
        self.assertIsInstance(data.get("original_code"), str)
        self.assertIsInstance(data.get("fixed_code"), str)
        self.assertIsInstance(data.get("message"), str)

    def test_case_success_types(self):
        """Success case: Clean code response types."""
        code = 'print("hello")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIsInstance(data.get("metrics"), str)
        self.assertIsInstance(data.get("original_code"), str)
        self.assertIsInstance(data.get("message"), str)

    def test_case_error_intercepted_types(self):
        """Error case: Runtime TypeError response types."""
        code = 'print("Total: " + 5)'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertIsInstance(data.get("metrics"), str)
        self.assertIsInstance(data.get("raw_text"), str)
        self.assertIsInstance(data.get("fixed_code"), str)

    def test_case_syntax_error_types(self):
        """SyntaxError case: Missing colon response types."""
        code = 'def greet(name)\n    print("Hi", name)\ngreet("Sam")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertIsInstance(data.get("metrics"), str)
        self.assertIsInstance(data.get("raw_text"), str)

    def test_case_empty_code_types(self):
        """Empty code: 400 Bad Request error types."""
        resp = self.client.post('/api/analyze', json={'code': ''})
        self.assertEqual(resp.status_code, 400)
        data = resp.get_json()
        self.assertIsInstance(data.get("error"), str)

    def test_case_timeout_types(self):
        """Timeout case: Infinite loop response types."""
        code = 'while True: pass'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "error_intercepted")
        self.assertIn("TimeoutError", data.get("raw_text"))
        self.assertIsInstance(data.get("metrics"), str)

    def test_case_non_ascii_types(self):
        """Non-ASCII case: UTF-8 payload response types."""
        code = 'print("héllo ✓")'
        resp = self.client.post('/api/analyze', json={'code': code})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIsInstance(data.get("metrics"), str)
        self.assertIn("héllo ✓", data.get("original_code"))

    def test_static_index_html_safeguards(self):
        """Static inspection: verify toText helper exists and is applied at flagged sites."""
        html_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(html_path, "r", encoding="utf-8") as f:
            content = f.read()

        # 1. Helper function definition
        self.assertIn("function toText(val)", content)
        self.assertIn("Array.isArray(val)", content)

        # 2. Applied in renderMetricsCards
        self.assertIn("const text = toText(val);", content)

        # 3. Applied in security_blocked rendering
        self.assertIn("BLOCKED by security scan:", content)
        self.assertIn("Not executed (blocked by security scan)", content)

    def test_node_rendering_with_dom_stub(self):
        """Execute Node.js with a DOM stub against all 7 response shapes."""
        node_script = """
        // Minimal DOM Stub
        const ui = {
            diagOutput: { textContent: '' },
            execOutput: { textContent: '' },
            modifiedCode: { value: '' },
            originalCode: { value: '' },
            lblFile: { textContent: '' },
            fileList: { innerHTML: '', appendChild: () => {} },
            kpiTime: { textContent: '' },
            kpiEmissions: { textContent: '' },
            kpiEnergy: { textContent: '' },
            kpiOverhead: { textContent: '' },
            kpiVirt: { textContent: '' },
            workspace: { classList: { add: () => {}, remove: () => {} } }
        };

        function toText(val) {
            if (val === null || val === undefined) return '';
            if (typeof val === 'string') return val;
            if (Array.isArray(val)) return val.map(item => toText(item)).join('\\n');
            if (typeof val === 'object') {
                return Object.entries(val).map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`).join('\\n');
            }
            return String(val);
        }

        function renderMetricsCards(val) {
            const text = toText(val);
            if (!text) return;
            const lines = text.split('\\n').map(l => l.trim()).filter(Boolean);
            for (let i = 0; i < lines.length - 1; i++) {
                const title = lines[i].toLowerCase();
                const valStr = lines[i+1];
                if (title.includes('response time') && ui.kpiTime) ui.kpiTime.textContent = valStr;
                else if (title.includes('emissions') && ui.kpiEmissions) ui.kpiEmissions.textContent = valStr;
                else if ((title.includes('energy') || title.includes('rapl')) && ui.kpiEnergy) ui.kpiEnergy.textContent = valStr;
                else if ((title.includes('overhead') || title.includes('ovhd')) && ui.kpiOverhead) ui.kpiOverhead.textContent = valStr;
                else if (title.includes('virtualization') && ui.kpiVirt) ui.kpiVirt.textContent = valStr;
            }
        }

        function resetMetricsCards() {
            if (ui.kpiTime) ui.kpiTime.textContent = '--';
            if (ui.kpiEmissions) ui.kpiEmissions.textContent = '--';
            if (ui.kpiEnergy) ui.kpiEnergy.textContent = '--';
            if (ui.kpiOverhead) ui.kpiOverhead.textContent = '--';
            if (ui.kpiVirt) ui.kpiVirt.textContent = '--';
        }

        function handleAnalyzeResponse(resStatus, data, rawCode) {
            if(resStatus === 400 || resStatus === 413) {
                ui.diagOutput.textContent = `[HTTP ${resStatus}] ${toText(data.error || "Bad Request")}`;
            } else if(data.status === 'error_intercepted') {
                ui.diagOutput.textContent = toText(data.raw_text || data.message);
                renderMetricsCards(data.metrics);
                ui.modifiedCode.value = toText(data.fixed_code || rawCode);
            } else if(data.status === 'security_blocked') {
                const findings = (data.security_alerts && data.security_alerts.length > 0)
                    ? data.security_alerts.join("; ")
                    : (toText(data.message) || "High-risk vulnerability detected");
                ui.diagOutput.textContent = `BLOCKED by security scan: ${findings} - your code was not executed\\n\\n${toText(data.raw_text || data.message)}`;
                if (ui.execOutput) ui.execOutput.textContent = "Not executed (blocked by security scan)";
                resetMetricsCards();
                ui.modifiedCode.value = toText(data.original_code || rawCode);
            } else if(data.status === 'success') {
                ui.diagOutput.textContent = toText(data.raw_text) || ("[SECURITY SCAN] Code appears safe.\\n----------------------------------------\\n" + toText(data.message));
                renderMetricsCards(data.metrics);
                ui.modifiedCode.value = toText(data.original_code || rawCode);
            } else {
                ui.diagOutput.textContent = `[ERROR] ${toText(data.error || data.message || "Failed to analyze code.")}`;
            }
        }

        // Test 1: security_blocked (including array metrics regression case)
        handleAnalyzeResponse(200, {
            status: "security_blocked",
            message: "Execution blocked: High-risk security vulnerability detected.",
            security_alerts: ["[HIGH] Line 1: Use of os.system"],
            raw_text: "[SECURITY SCAN - HIGH RISK FINDING DETECTED]",
            metrics: ["Total Response Time\\n0.10 ms\\n\\nEmissions\\n0.00 ug", "estimated"],
            original_code: 'import os\\nos.system("echo hi")'
        }, 'import os\\nos.system("echo hi")');

        if (!ui.diagOutput.textContent.includes("BLOCKED by security scan")) {
            throw new Error("security_blocked textContent missing expected prefix");
        }
        if (ui.execOutput.textContent !== "Not executed (blocked by security scan)") {
            throw new Error("execOutput mismatch on security_blocked");
        }
        if (ui.kpiTime.textContent !== '--') {
            throw new Error("kpiTime not reset to -- on security_blocked");
        }

        // Test 2: success
        handleAnalyzeResponse(200, {
            status: "success",
            message: "Code executed cleanly with 0 errors.",
            metrics: "Total Response Time\\n12.50 ms\\n\\nEmissions (Estimated: 25W TDP baseline)\\n0.0868 ug CO2 eq\\n\\nRAPL Package Energy (Estimated)\\n0.31 mJ\\n\\nPinpoint Agent Overhead\\n1.25 ms\\n\\nVirtualization Efficiency\\n99.99%",
            original_code: 'print("hello")'
        }, 'print("hello")');

        if (ui.kpiTime.textContent !== '12.50 ms') {
            throw new Error("kpiTime mismatch on success");
        }

        // Test 3: error_intercepted
        handleAnalyzeResponse(200, {
            status: "error_intercepted",
            raw_text: "Mistake: Mixing types\\nReason: Cannot concat int to str\\nFix: print('Total: ' + str(5))",
            metrics: "Total Response Time\\n5.00 ms\\n\\nEmissions\\n0.01 ug",
            fixed_code: 'print("Total: " + str(5))'
        }, 'print("Total: " + 5)');

        if (!ui.diagOutput.textContent.includes("Mistake:")) {
            throw new Error("diagOutput missing Mistake in error_intercepted");
        }

        // Test 4: 400 Bad Request
        handleAnalyzeResponse(400, {
            error: "Empty code provided"
        }, '');

        if (!ui.diagOutput.textContent.includes("[HTTP 400] Empty code provided")) {
            throw new Error("diagOutput missing 400 message");
        }

        console.log("All Node rendering checks passed successfully.");
        """
        result = subprocess.run(
            ["node", "-e", node_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            encoding="utf-8",
            errors="replace"
        )
        self.assertEqual(result.returncode, 0, f"Node rendering failed:\nSTDOUT: {result.stdout}\nSTDERR: {result.stderr}")
        self.assertIn("All Node rendering checks passed successfully.", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
