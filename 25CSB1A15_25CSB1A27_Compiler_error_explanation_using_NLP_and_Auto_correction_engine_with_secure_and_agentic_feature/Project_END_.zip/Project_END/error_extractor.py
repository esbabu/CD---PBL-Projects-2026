import sys
import os
import traceback
import time
import re
from typing import Dict, Any, Optional

try:
    from codecarbon import EmissionsTracker
    CODECARBON_AVAILABLE = True
except ImportError:
    CODECARBON_AVAILABLE = False

from sandbox_runner import run_in_sandbox


def extract_error(code: str) -> Dict[str, Any]:
    """
    Executes Python code safely inside an isolated sandbox subprocess, captures
    error type, message, traceback, line number, and optionally tracks CodeCarbon emissions.
    
    Returns a dictionary (IR) with the extracted details and sandbox metadata.
    """
    if isinstance(code, str) and code.startswith("\ufeff"):
        code = code[1:]
    
    ir = {
        "error_type": None,
        "error_message": None,
        "line_number": None,
        "traceback": None,
        "green_metrics": None,
        "stdout": "",
        "sandbox_status": "ok",
        "violations": [],
        "peak_memory_mb": 0.0,
        "duration_ms": 0.0
    }

    # Pre-execution static security scan
    try:
        from security_analyzer import scan_gate
        gate_res = scan_gate(code)
        if not gate_res.get("allowed", True):
            ir["sandbox_status"] = "blocked"
            ir["violations"] = gate_res.get("findings", [])
            ir["error_type"] = "SecurityViolation"
            ir["error_message"] = gate_res.get("message")
            ir["traceback"] = f"SecurityViolation: {gate_res.get('message')}"
            return ir
    except Exception:
        pass

    tracker = None
    if CODECARBON_AVAILABLE:
        try:
            tracker = EmissionsTracker(save_to_file=True, log_level='error')
            tracker.start()
        except Exception:
            tracker = None

    start_time = time.perf_counter()

    try:
        sb_res = run_in_sandbox(code, timeout=5.0)
        ir["sandbox_status"] = sb_res.get("status", "ok")
        ir["violations"] = sb_res.get("violations", [])
        ir["peak_memory_mb"] = sb_res.get("peak_memory_mb", 0.0)
        ir["duration_ms"] = sb_res.get("duration_ms", 0.0)
        ir["stdout"] = sb_res.get("stdout", "")

        if sb_res.get("error"):
            err = sb_res["error"]
            ir["error_type"] = err.get("error_type")
            ir["error_message"] = err.get("error_message")
            ir["line_number"] = err.get("line_number")
            ir["traceback"] = err.get("traceback")
        elif sb_res.get("status") != "ok":
            ir["error_type"] = sb_res.get("status")
            ir["error_message"] = sb_res.get("stderr") or sb_res.get("status")
            ir["traceback"] = sb_res.get("stderr") or ""
    except Exception as e:
        ir["sandbox_status"] = "sandbox_failure"
        ir["error_type"] = type(e).__name__
        ir["error_message"] = str(e)
        ir["traceback"] = traceback.format_exc()

    duration = time.perf_counter() - start_time

    # Record Green metrics
    if tracker:
        try:
            emissions = tracker.stop()
            energy_kwh = 0.0
            if hasattr(tracker, '_total_energy') and tracker._total_energy is not None:
                energy_kwh = getattr(tracker._total_energy, 'kWh', 0.0)
                try:
                    energy_kwh = float(energy_kwh)
                except (TypeError, ValueError):
                    energy_kwh = 0.0
            elif hasattr(tracker, 'final_emissions_data') and tracker.final_emissions_data:
                energy_kwh = getattr(tracker.final_emissions_data, 'energy_consumed', 0.0)

            emissions_kg = emissions if (emissions is not None and emissions > 0) else getattr(tracker, '_total_emissions', 0.0)
            if (not emissions_kg or emissions_kg == 0) and energy_kwh > 0:
                emissions_kg = energy_kwh * 0.475

            ir["green_metrics"] = {
                "emissions_kg": float(emissions_kg or 0.0),
                "energy_consumed_kwh": float(energy_kwh or 0.0),
                "execution_time_sec": duration
            }
        except Exception:
            ir["green_metrics"] = {
                "execution_time_sec": duration,
                "emissions_kg": 0.0,
                "energy_consumed_kwh": 0.0
            }
    else:
        ir["green_metrics"] = {
            "execution_time_sec": duration,
            "emissions_kg": 0.0,
            "energy_consumed_kwh": 0.0
        }

    return ir


def _run_in_sandbox(code_str: str, timeout: float = 5.0) -> Any:
    """Legacy compatibility shim delegating to run_in_sandbox."""
    res = run_in_sandbox(code_str, timeout=timeout)
    is_clean = (res["status"] == "ok")
    err_type = res["error"]["error_type"] if res.get("error") else None
    err_msg = res["error"]["error_message"] if res.get("error") else None
    line_no = res["error"]["line_number"] if res.get("error") else None
    return is_clean, err_type, err_msg, line_no