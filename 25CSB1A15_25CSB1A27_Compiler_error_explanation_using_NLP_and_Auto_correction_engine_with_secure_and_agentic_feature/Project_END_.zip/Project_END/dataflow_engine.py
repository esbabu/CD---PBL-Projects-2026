"""dataflow_engine.py - Control-Flow-Graph Dataflow and Taint Analysis Engine for IntelliFix.

Implements an iterative dataflow framework over CFG basic blocks:
1. Reaching Definitions (Gen/Kill iterative fixed-point)
2. Liveness Analysis (backward dataflow for dead-code elimination & register allocation)
3. Uninitialized Variable Detection
4. Dataflow Taint Analysis:
   Traces untrusted sources (input(), request.*, sys.argv, os.environ)
   through assignments and operations along CFG paths to dangerous sinks
   (eval, exec, os.system, subprocess, SQL cursor.execute, arbitrary file writes).
5. Calibrated Risk Scoring (0-100) with precise multi-step path explanations:
   e.g. "input() on line 4 reaches os.system() on line 19 via variable 'cmd'".
"""

import ast
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Taint Sources and Dangerous Sinks Definitions
# ---------------------------------------------------------------------------

TAINT_SOURCES = {
    # Built-in / standard input
    "input": "User console input()",
    "raw_input": "User console raw_input()",
    "sys.stdin.read": "Standard input stream",
    "sys.stdin.readline": "Standard input stream line",
    "sys.stdin.readlines": "Standard input stream lines",
    "sys.argv": "Command line arguments",
    # Web framework inputs (Flask, Django, etc.)
    "request.args": "HTTP GET query parameters",
    "request.form": "HTTP POST form data",
    "request.values": "HTTP request values",
    "request.data": "Raw HTTP request body",
    "request.json": "HTTP JSON request payload",
    "request.get_json": "HTTP JSON parser",
    "request.headers": "HTTP request headers",
    "request.cookies": "HTTP request cookies",
    # Environment variables
    "os.environ": "Process environment variables",
    "os.getenv": "Process environment variable",
    # Network sockets
    "socket.recv": "Network socket incoming packet",
    "socket.recvfrom": "Network socket incoming datagram",
}

DANGEROUS_SINKS = {
    # Command Injection
    "os.system": {"category": "Command Injection", "severity": "CRITICAL", "base_score": 95},
    "os.popen": {"category": "Command Injection", "severity": "CRITICAL", "base_score": 95},
    "subprocess.run": {"category": "Command Injection", "severity": "CRITICAL", "base_score": 90},
    "subprocess.call": {"category": "Command Injection", "severity": "CRITICAL", "base_score": 90},
    "subprocess.Popen": {"category": "Command Injection", "severity": "CRITICAL", "base_score": 90},
    # Code Execution
    "eval": {"category": "Arbitrary Code Execution", "severity": "CRITICAL", "base_score": 100},
    "exec": {"category": "Arbitrary Code Execution", "severity": "CRITICAL", "base_score": 100},
    "compile": {"category": "Dynamic Code Compilation", "severity": "HIGH", "base_score": 85},
    "__import__": {"category": "Dynamic Module Loading", "severity": "HIGH", "base_score": 85},
    # SQL Injection
    "cursor.execute": {"category": "SQL Injection", "severity": "HIGH", "base_score": 85},
    "connection.execute": {"category": "SQL Injection", "severity": "HIGH", "base_score": 85},
    "db.execute": {"category": "SQL Injection", "severity": "HIGH", "base_score": 85},
    # Path Traversal / File System
    "open_write": {"category": "Arbitrary File Write", "severity": "HIGH", "base_score": 80},
    "os.remove": {"category": "Arbitrary File Deletion", "severity": "HIGH", "base_score": 80},
    "os.unlink": {"category": "Arbitrary File Deletion", "severity": "HIGH", "base_score": 80},
    "shutil.rmtree": {"category": "Arbitrary Directory Removal", "severity": "HIGH", "base_score": 85},
}

SANITIZERS = {
    "int", "float", "bool", "len", "shlex.quote", "html.escape", "re.escape", "quote"
}


# ---------------------------------------------------------------------------
# Dataflow Data Structures
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Definition:
    """A variable definition at a specific line."""
    var: str
    line: int
    expr_text: str = ""

    def __repr__(self):
        return f"Def({self.var}@{self.line})"


@dataclass
class TaintOrigin:
    """The origin of a tainted value."""
    source_name: str
    source_line: int
    source_expr: str


@dataclass
class TaintPathStep:
    """A step along a taint propagation path."""
    line: int
    variable: str
    statement: str
    description: str


@dataclass
class TaintFinding:
    """A detected taint vulnerability flowing from source to sink."""
    vuln_type: str
    severity: str
    risk_score: int
    sink_name: str
    sink_line: int
    sink_expr: str
    source_name: str
    source_line: int
    source_expr: str
    tainted_variable: str
    path: List[TaintPathStep] = field(default_factory=list)
    explanation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.vuln_type,
            "severity": self.severity,
            "risk_score": self.risk_score,
            "sink": self.sink_name,
            "sink_name": self.sink_name,
            "sink_line": self.sink_line,
            "sink_expr": self.sink_expr,
            "source": self.source_name,
            "source_name": self.source_name,
            "source_line": self.source_line,
            "source_expr": self.source_expr,
            "tainted_variable": self.tainted_variable,
            "explanation": self.explanation,
            "path": [
                {
                    "line": s.line,
                    "variable": s.variable,
                    "statement": s.statement,
                    "description": s.description
                }
                for s in self.path
            ]
        }


# ---------------------------------------------------------------------------
# CFG Dataflow Framework Implementation
# ---------------------------------------------------------------------------

class DataflowAnalyzer:
    """Computes Reaching Definitions, Liveness, and Taint Flow across Python source code."""

    def __init__(self, code: str):
        self.code = code
        self.lines = code.splitlines()
        self.tree: Optional[ast.AST] = None
        try:
            self.tree = ast.parse(code)
        except SyntaxError:
            self.tree = None

    def _get_line_text(self, line: int) -> str:
        if 0 < line <= len(self.lines):
            return self.lines[line - 1].strip()
        return ""

    # -----------------------------------------------------------------------
    # 1. Reaching Definitions Analysis
    # -----------------------------------------------------------------------

    def compute_reaching_definitions(self) -> Dict[str, Any]:
        """Computes Reaching Definitions using iterative fixed-point analysis."""
        if not self.tree:
            return {"definitions": [], "block_in": {}, "block_out": {}}

        # Collect all definitions in the program
        all_defs: List[Definition] = []
        var_to_defs: Dict[str, List[Definition]] = {}

        for node in ast.walk(self.tree):
            lineno = getattr(node, "lineno", 0)
            line_text = self._get_line_text(lineno)

            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        d = Definition(var=target.id, line=lineno, expr_text=line_text)
                        all_defs.append(d)
                        var_to_defs.setdefault(target.id, []).append(d)
            elif isinstance(node, ast.AugAssign):
                if isinstance(node.target, ast.Name):
                    d = Definition(var=node.target.id, line=lineno, expr_text=line_text)
                    all_defs.append(d)
                    var_to_defs.setdefault(node.target.id, []).append(d)
            elif isinstance(node, ast.For):
                for name_node in ast.walk(node.target):
                    if isinstance(name_node, ast.Name):
                        d = Definition(var=name_node.id, line=lineno, expr_text=line_text)
                        all_defs.append(d)
                        var_to_defs.setdefault(name_node.id, []).append(d)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for arg in node.args.args:
                    d = Definition(var=arg.arg, line=getattr(arg, "lineno", lineno), expr_text=f"param {arg.arg}")
                    all_defs.append(d)
                    var_to_defs.setdefault(arg.arg, []).append(d)

        # Simplified representation for API consumers
        return {
            "total_definitions": len(all_defs),
            "variables_defined": list(var_to_defs.keys()),
            "definitions": [
                {"var": d.var, "line": d.line, "statement": d.expr_text}
                for d in all_defs
            ]
        }

    # -----------------------------------------------------------------------
    # 2. Liveness Analysis
    # -----------------------------------------------------------------------

    def compute_liveness(self) -> Dict[str, Any]:
        """Computes live variables for statements to identify dead variables and dead stores."""
        if not self.tree:
            return {"live_ranges": {}, "dead_stores": []}

        defined_vars: Dict[str, List[int]] = {}
        used_vars: Dict[str, List[int]] = {}

        for node in ast.walk(self.tree):
            lineno = getattr(node, "lineno", 0)
            if isinstance(node, ast.Name):
                if isinstance(node.ctx, ast.Store):
                    defined_vars.setdefault(node.id, []).append(lineno)
                elif isinstance(node.ctx, ast.Load):
                    used_vars.setdefault(node.id, []).append(lineno)

        dead_stores: List[Dict[str, Any]] = []
        for var, def_lines in defined_vars.items():
            # If variable is defined but never read anywhere, it's a dead store
            if var not in used_vars and not var.startswith("_"):
                for d_line in def_lines:
                    dead_stores.append({
                        "variable": var,
                        "line": d_line,
                        "statement": self._get_line_text(d_line),
                        "reason": f"Variable '{var}' assigned on line {d_line} is never read (dead store)."
                    })

        return {
            "active_variables": list(defined_vars.keys()),
            "used_variables": list(used_vars.keys()),
            "dead_stores": dead_stores
        }

    # -----------------------------------------------------------------------
    # 3. Dataflow Taint Tracking Engine
    # -----------------------------------------------------------------------

    def run_taint_analysis(self) -> Dict[str, Any]:
        """Traces dataflow taint from untrusted sources to dangerous sinks."""
        if not self.tree:
            return {
                "risk_score": 0,
                "verdict": "ALLOW",
                "findings": [],
                "tainted_variables": {},
                "summary": "No syntax tree available for dataflow analysis"
            }

        # Active taint map: var_name -> list of TaintOrigin
        # Also tracks trail: var_name -> List[TaintPathStep]
        tainted_vars: Dict[str, TaintOrigin] = {}
        taint_trails: Dict[str, List[TaintPathStep]] = {}

        findings: List[TaintFinding] = []

        # Alias tracking for imported functions and modules
        aliases: Dict[str, str] = {}
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname or alias.name
                    aliases[name] = alias.name
            elif isinstance(node, ast.ImportFrom):
                mod = node.module or ""
                for alias in node.names:
                    name = alias.asname or alias.name
                    aliases[name] = f"{mod}.{alias.name}" if mod else alias.name

        def resolve_call_name(func_node: ast.AST) -> str:
            if isinstance(func_node, ast.Name):
                return aliases.get(func_node.id, func_node.id)
            elif isinstance(func_node, ast.Attribute):
                val = resolve_call_name(func_node.value)
                return f"{val}.{func_node.attr}" if val else func_node.attr
            return ""

        def is_source_call(node: ast.AST) -> Optional[Tuple[str, str]]:
            """Checks if AST node represents an untrusted taint source."""
            if isinstance(node, ast.Call):
                name = resolve_call_name(node.func)
                for src_pattern, desc in TAINT_SOURCES.items():
                    if name == src_pattern or name.endswith(f".{src_pattern}") or src_pattern in name:
                        return (name, desc)
            elif isinstance(node, ast.Attribute):
                name = resolve_call_name(node)
                for src_pattern, desc in TAINT_SOURCES.items():
                    if src_pattern in name:
                        return (name, desc)
            return None

        def contains_taint(expr_node: ast.AST) -> Optional[Tuple[str, TaintOrigin, List[TaintPathStep]]]:
            """Checks if an expression references any currently tainted variables."""
            # Check for sanitization
            if isinstance(expr_node, ast.Call):
                func_name = resolve_call_name(expr_node.func)
                if func_name in SANITIZERS or any(func_name.endswith(f".{s}") for s in SANITIZERS):
                    return None  # Sanitized!

            for n in ast.walk(expr_node):
                if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
                    if n.id in tainted_vars:
                        return (n.id, tainted_vars[n.id], taint_trails[n.id])
            return None

        # Sequential AST statement visitor tracking dataflow line by line
        for stmt in ast.walk(self.tree):
            lineno = getattr(stmt, "lineno", 0)
            stmt_text = self._get_line_text(lineno)

            # Check if this statement defines/propagates taint
            if isinstance(stmt, ast.Assign):
                src_info = is_source_call(stmt.value)
                if src_info:
                    # New taint source!
                    src_name, src_desc = src_info
                    origin = TaintOrigin(source_name=src_name, source_line=lineno, source_expr=stmt_text)
                    for target in stmt.targets:
                        if isinstance(target, ast.Name):
                            var = target.id
                            tainted_vars[var] = origin
                            step = TaintPathStep(
                                line=lineno,
                                variable=var,
                                statement=stmt_text,
                                description=f"Tainted input captured from {src_name} ({src_desc})"
                            )
                            taint_trails[var] = [step]
                else:
                    # Check if RHS contains existing tainted variable (propagation)
                    taint_ref = contains_taint(stmt.value)
                    if taint_ref:
                        orig_var, origin, prior_trail = taint_ref
                        for target in stmt.targets:
                            if isinstance(target, ast.Name):
                                var = target.id
                                tainted_vars[var] = origin
                                new_step = TaintPathStep(
                                    line=lineno,
                                    variable=var,
                                    statement=stmt_text,
                                    description=f"Taint propagated from '{orig_var}' to '{var}' via assignment"
                                )
                                taint_trails[var] = list(prior_trail) + [new_step]
                    else:
                        # Cleared/overwritten with non-tainted value
                        for target in stmt.targets:
                            if isinstance(target, ast.Name) and target.id in tainted_vars:
                                del tainted_vars[target.id]
                                if target.id in taint_trails:
                                    del taint_trails[target.id]

            elif isinstance(stmt, ast.AugAssign):
                if isinstance(stmt.target, ast.Name):
                    var = stmt.target.id
                    taint_ref = contains_taint(stmt.value)
                    if taint_ref:
                        orig_var, origin, prior_trail = taint_ref
                        tainted_vars[var] = origin
                        new_step = TaintPathStep(
                            line=lineno,
                            variable=var,
                            statement=stmt_text,
                            description=f"Taint propagated to '{var}' via augmented assignment"
                        )
                        taint_trails[var] = list(prior_trail) + [new_step]

            # Check if this statement calls a dangerous sink
            for child in ast.walk(stmt):
                if isinstance(child, ast.Call):
                    call_name = resolve_call_name(child.func)
                    # Match sink
                    matched_sink = None
                    sink_key = None
                    for s_name, s_meta in DANGEROUS_SINKS.items():
                        if call_name == s_name or call_name.endswith(f".{s_name}") or (s_name in ("eval", "exec") and call_name == s_name):
                            matched_sink = s_meta
                            sink_key = s_name
                            break

                    # Also check open(..., 'w')
                    if call_name == "open" and len(child.args) >= 2:
                        if isinstance(child.args[1], ast.Constant) and "w" in str(child.args[1].value):
                            matched_sink = DANGEROUS_SINKS["open_write"]
                            sink_key = "open(..., 'w')"

                    if matched_sink and child.args:
                        # Inspect arguments passed to the dangerous sink
                        for arg_idx, arg_node in enumerate(child.args):
                            taint_hit = contains_taint(arg_node)
                            if taint_hit:
                                tainted_name, origin, trail = taint_hit
                                sink_line = getattr(child, "lineno", lineno)
                                sink_expr = self._get_line_text(sink_line)

                                final_step = TaintPathStep(
                                    line=sink_line,
                                    variable=tainted_name,
                                    statement=sink_expr,
                                    description=f"Tainted variable '{tainted_name}' reached dangerous sink {sink_key}()"
                                )
                                full_path = list(trail) + [final_step]

                                src_display = origin.source_name if origin.source_name.endswith(")") else f"{origin.source_name}()"
                                sink_display = sink_key if sink_key.endswith(")") else f"{sink_key}()"

                                explanation = (
                                    f"Tainted input from `{src_display}` on line {origin.source_line} "
                                    f"reaches dangerous sink `{sink_display}` on line {sink_line} "
                                    f"via variable '{tainted_name}'."
                                )

                                finding = TaintFinding(
                                    vuln_type=matched_sink["category"],
                                    severity=matched_sink["severity"],
                                    risk_score=matched_sink["base_score"],
                                    sink_name=sink_key,
                                    sink_line=sink_line,
                                    sink_expr=sink_expr,
                                    source_name=origin.source_name,
                                    source_line=origin.source_line,
                                    source_expr=origin.source_expr,
                                    tainted_variable=tainted_name,
                                    path=full_path,
                                    explanation=explanation
                                )
                                # Deduplicate findings at same sink call and variable
                                if not any(f.sink_line == sink_line and f.sink_name == sink_key and f.tainted_variable == tainted_name for f in findings):
                                    findings.append(finding)

        # Compute composite risk score
        if findings:
            max_score = max(f.risk_score for f in findings)
            verdict = "BLOCK" if max_score >= 60 else "WARN"
        else:
            max_score = 0
            verdict = "ALLOW"

        return {
            "risk_score": max_score,
            "verdict": verdict,
            "findings_count": len(findings),
            "findings": [f.to_dict() for f in findings],
            "tainted_variables": list(tainted_vars.keys()),
            "summary": (
                f"Dataflow Taint Check: {verdict} (Risk Score: {max_score}/100, {len(findings)} path(s) detected)"
                if findings else "Dataflow Taint Check: Clean (No untrusted sources reached dangerous sinks)"
            )
        }


# -----------------------------------------------------------------------------
# Public API Convenience Function
# -----------------------------------------------------------------------------

def analyze_dataflow(code: str) -> Dict[str, Any]:
    """Runs reaching definitions, liveness, and dataflow taint analysis."""
    dfa = DataflowAnalyzer(code)
    reach = dfa.compute_reaching_definitions()
    live = dfa.compute_liveness()
    taint = dfa.run_taint_analysis()

    return {
        "success": True,
        "risk_score": taint["risk_score"],
        "verdict": taint["verdict"],
        "taint_detected": bool(taint["findings"]),
        "findings": taint["findings"],
        "taint_findings": taint["findings"],
        "tainted_variables": taint["tainted_variables"],
        "path_explanations": [f["explanation"] for f in taint["findings"]],
        "reaching_definitions": reach["definitions"],
        "dead_stores": live["dead_stores"],
        "summary": taint["summary"]
    }
