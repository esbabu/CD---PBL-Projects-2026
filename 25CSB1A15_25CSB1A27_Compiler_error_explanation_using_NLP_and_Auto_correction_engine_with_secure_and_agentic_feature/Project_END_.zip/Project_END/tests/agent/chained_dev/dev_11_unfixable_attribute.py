class EmptyClass:
    pass
obj = EmptyClass()
obj.totally_nonexistent_custom_method_xyz()
