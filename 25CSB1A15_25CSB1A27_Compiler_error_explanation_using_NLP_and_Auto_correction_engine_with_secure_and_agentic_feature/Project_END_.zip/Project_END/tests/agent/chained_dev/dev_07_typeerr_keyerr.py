label = "Counter: " + 99
stats = {}
score = stats["accuracy"]
print(label, score)
