import json_unknown_pkg
data = json.loads("[]")
first = [1, 2][10]
print(first)
