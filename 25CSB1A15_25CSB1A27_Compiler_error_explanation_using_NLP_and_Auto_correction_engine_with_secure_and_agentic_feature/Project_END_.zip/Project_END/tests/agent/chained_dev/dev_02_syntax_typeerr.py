def calculate(val)
    return "Value: " + val
res = calculate(42)
print(res)
