import os_missing_mod
os.mkdir(".")
print("Directory checked")
