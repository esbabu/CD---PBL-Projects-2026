if True
    import re_missing_mod
    p = re.compile("abc")
    print("Pattern compiled")
