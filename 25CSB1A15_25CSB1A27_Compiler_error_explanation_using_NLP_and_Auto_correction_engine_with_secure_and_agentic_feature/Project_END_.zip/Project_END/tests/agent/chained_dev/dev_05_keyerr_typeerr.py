mapping = {"alpha": 1}
val = mapping["beta"]
for item in 100:
    print(item)
