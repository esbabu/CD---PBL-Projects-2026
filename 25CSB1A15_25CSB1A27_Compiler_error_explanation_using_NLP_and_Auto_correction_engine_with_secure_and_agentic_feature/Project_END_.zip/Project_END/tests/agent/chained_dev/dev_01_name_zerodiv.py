import math_mod_xyz
x = math.sqrt(16)
y = 10 / 0
print(x, y)
