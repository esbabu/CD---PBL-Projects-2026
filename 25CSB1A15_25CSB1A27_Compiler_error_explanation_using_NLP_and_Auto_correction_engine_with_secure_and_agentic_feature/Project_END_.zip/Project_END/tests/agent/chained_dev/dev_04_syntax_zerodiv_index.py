for i in [1, 2, 3]
    a = 1 / 0
    b = [10][5]
print("Done")
