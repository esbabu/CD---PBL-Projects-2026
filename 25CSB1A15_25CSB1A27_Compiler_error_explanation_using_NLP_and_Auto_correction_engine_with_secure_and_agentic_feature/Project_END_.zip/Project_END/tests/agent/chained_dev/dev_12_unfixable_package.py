import non_existent_3rdparty_package_xyz_9999
print("Loaded package")
