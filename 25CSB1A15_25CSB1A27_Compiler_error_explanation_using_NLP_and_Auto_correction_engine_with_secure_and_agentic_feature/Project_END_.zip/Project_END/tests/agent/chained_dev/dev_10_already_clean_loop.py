numbers = [1, 2, 3, 4]
total = sum([n * 2 for n in numbers])
print("Total:", total)
