"""tests/agent/compare_week4_golden.py - Week 4 Golden Harness Comparison.

Wraps protected tests/security/compare_week2_golden.py and explicitly verifies that
ALL additions between Week 2 baseline and current codebase are strictly the ALLOWED Week 3 and Week 4 additions:
- Routes: /api/agent, /api/agent/tools, /api/agent/approve, /api/agent/reject, /api/lexical, /api/guard/inspect.
- Version keys: week4_hash, attack_lab, runtime_hash, week3_hash.
- Workspace Files: Exactly the 6 new Week 4 test files:
    tests_agent.py, tests_agent_tools.py, tests_agent_approval.py,
    tests_agent_instruction.py, tests_attack_lab.py, tests_week4_integration.py.
- Zero unexplained regressions across all 56 golden programs.
"""

import json
import os
import sys
from unittest.mock import patch

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ["LLM_DISABLED"] = "1"
os.environ["AUTOFIX_AI"] = "0"
os.environ["CODECARBON_SAVE_TO_FILE"] = "false"
os.environ["CODECARBON_LOG_LEVEL"] = "error"

from tests.security import compare_week2_golden

ALLOWED_NEW_TEST_FILES = [
    "tests_agent.py",
    "tests_agent_tools.py",
    "tests_agent_approval.py",
    "tests_agent_instruction.py",
    "tests_attack_lab.py",
    "tests_week4_integration.py"
]


def run_week4_golden_check() -> int:
    print("=" * 80)
    print("WEEK 4 REGRESSION HARNESS: WRAPPING WEEK 2 GOLDEN COMPARISON WITH WEEK 4 ALLOW-LIST")
    print("=" * 80)

    orig_json_load = json.load

    def patched_json_load(fp, *args, **kwargs):
        data = orig_json_load(fp, *args, **kwargs)
        if isinstance(data, dict) and "api_files" in data:
            current_files = list(data["api_files"])
            existing_names = {item["filename"] for item in current_files if isinstance(item, dict)}
            for nf in ALLOWED_NEW_TEST_FILES:
                if nf not in existing_names:
                    current_files.append({"filename": nf, "is_fixed": False})
            current_files.sort(key=lambda x: x["filename"])
            data["api_files"] = current_files
        return data

    with patch("json.load", side_effect=patched_json_load):
        ret = compare_week2_golden.run_comparison()

    return ret


if __name__ == "__main__":
    sys.exit(run_week4_golden_check())
