# Server config loader
settings = {"host": "localhost"}
port = settings["port"]
weight = 50 / 0
print(port, weight)
