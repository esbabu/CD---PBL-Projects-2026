# Mathematical mean calculation
def mean(vals):
    return sum(vals) / len(vals) if vals else 0

result = mean([10.0, 20.0, 30.0])
print("Mean:", result)
