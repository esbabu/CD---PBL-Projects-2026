# User dictionary query
record = {"id": 101, "role": "admin"}
print("User role:", record.get("role"))
