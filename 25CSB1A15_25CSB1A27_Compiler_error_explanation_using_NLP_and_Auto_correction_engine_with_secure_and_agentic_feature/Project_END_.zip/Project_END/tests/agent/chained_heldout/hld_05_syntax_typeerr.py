# Range iteration logic
for step in 25:
    print("Step:", step)
