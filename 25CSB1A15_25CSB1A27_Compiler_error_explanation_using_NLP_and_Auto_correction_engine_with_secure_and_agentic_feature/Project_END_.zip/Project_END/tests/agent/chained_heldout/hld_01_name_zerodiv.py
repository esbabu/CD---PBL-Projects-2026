# Data normalization task
import sys_missing_lib
ratio = 100 / 0
print("Ratio calculated:", ratio)
