# Batch processing loop
while count < 1:
    message = "Batch count is " + 5
    count = 1
print(message)
