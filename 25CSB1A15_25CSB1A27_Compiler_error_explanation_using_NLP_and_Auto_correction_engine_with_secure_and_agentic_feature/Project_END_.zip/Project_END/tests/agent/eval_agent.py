"""tests/agent/eval_agent.py - Fair Offline Evaluation of Agent Orchestrator vs Baseline.

Compares:
(A) Existing Baseline: multi_error.fix_all_errors(code_str) with offline rule tier.
(B) Agent Orchestrator: agent.repair(code_str, max_attempts=5) with offline rule tier.

Evaluated over:
- DEV split: tests/agent/chained_dev/ (12 programs)
- HELD-OUT split: tests/agent/chained_heldout/ (8 programs, frozen)

Zero live LLM calls: AI disabled strictly with LLM_DISABLED=1 and AUTOFIX_AI=0.
"""

import hashlib
import json
import os
import sys
import time
from typing import Any, Dict, List, Tuple

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ["LLM_DISABLED"] = "1"
os.environ["AUTOFIX_AI"] = "0"
os.environ["CODECARBON_SAVE_TO_FILE"] = "false"
os.environ["CODECARBON_LOG_LEVEL"] = "error"

import agent
import multi_error
import sandbox_runner

DEV_DIR = os.path.join(_ROOT, "tests", "agent", "chained_dev")
HLD_DIR = os.path.join(_ROOT, "tests", "agent", "chained_heldout")
FREEZE_JSON = os.path.join(_ROOT, "tests", "agent", "heldout_freeze.json")


def verify_heldout_freeze() -> Tuple[bool, str, str]:
    """Verify that heldout fixtures have not been modified since freeze."""
    if not os.path.exists(FREEZE_JSON):
        return False, "FREEZE_JSON_MISSING", ""
    with open(FREEZE_JSON, "r", encoding="utf-8") as f:
        freeze_data = json.load(f)
    expected_hash = freeze_data.get("freeze_sha256", "")

    files = sorted(os.listdir(HLD_DIR))
    h = hashlib.sha256()
    for f in files:
        p = os.path.join(HLD_DIR, f)
        with open(p, "rb") as fp:
            sha = hashlib.sha256(fp.read()).hexdigest()
        h.update(f"{f}:{sha}\n".encode("utf-8"))
    actual_hash = h.hexdigest()
    return (actual_hash == expected_hash), expected_hash, actual_hash


def run_eval_on_folder(folder_path: str, label: str) -> Dict[str, Any]:
    print(f"\n{'=' * 85}")
    print(f"EVALUATION ON {label.upper()} SPLIT: {folder_path}")
    print(f"{'=' * 85}")

    files = sorted([f for f in os.listdir(folder_path) if f.endswith(".py")])
    results = []

    a_full_count = 0
    a_part_count = 0
    a_total_time = 0.0

    b_full_count = 0
    b_part_count = 0
    b_total_time = 0.0
    b_total_attempts = 0

    print(f"{'Fixture':<32} | {'Base Status':<12} | {'Base Time':<10} | {'Agent Status':<16} | {'Agent Att':<10} | {'Agent Time':<10}")
    print("-" * 105)

    for fname in files:
        fpath = os.path.join(folder_path, fname)
        with open(fpath, "r", encoding="utf-8") as fp:
            code = fp.read()

        # (A) Baseline Repair
        t0 = time.time()
        base_res = multi_error.fix_all_errors(code, max_rounds=20)
        t1 = time.time()
        base_time = t1 - t0
        a_total_time += base_time

        base_clean = False
        base_cand = base_res.get("fixed_code", code)
        if base_res.get("remaining_count") == 0:
            # Verify clean execution
            chk = sandbox_runner.run_in_sandbox(base_cand, timeout=3.0)
            if chk.get("returncode") == 0 and not chk.get("stderr", "").strip():
                base_clean = True

        if base_clean:
            a_full_count += 1
            base_status = "Full"
        elif base_res.get("fixed_count", 0) > 0:
            a_part_count += 1
            base_status = "Partial"
        else:
            base_status = "None"

        # (B) Agent Repair Loop
        t0 = time.time()
        agent_res = agent.repair(code, max_attempts=5)
        t1 = time.time()
        agent_time = t1 - t0
        b_total_time += agent_time
        b_total_attempts += agent_res.get("attempts", 1)

        agent_status_str = agent_res.get("status")
        agent_clean = False
        if agent_status_str == "already_clean":
            agent_clean = True
            b_full_count += 1
            agent_label = "Clean"
        elif agent_status_str == "pending_approval":
            prop = agent_res.get("proposal")
            if prop and prop.get("fixed_code"):
                chk = sandbox_runner.run_in_sandbox(prop["fixed_code"], timeout=3.0)
                if chk.get("returncode") == 0 and not chk.get("stderr", "").strip():
                    agent_clean = True
                    b_full_count += 1
                    agent_label = "Full"
                else:
                    b_part_count += 1
                    agent_label = "Partial"
            else:
                b_part_count += 1
                agent_label = "Partial"
        elif agent_status_str == "no_fix":
            agent_label = "NoFix"
        else:
            agent_label = "GaveUp"

        print(f"{fname:<32} | {base_status:<12} | {base_time:7.3f}s   | {agent_label:<16} | {agent_res.get('attempts'):<10} | {agent_time:7.3f}s")
        results.append({
            "fixture": fname,
            "baseline_status": base_status,
            "baseline_time": base_time,
            "agent_status": agent_label,
            "agent_attempts": agent_res.get("attempts"),
            "agent_time": agent_time
        })

    n = len(files)
    print("-" * 105)
    print(f"Summary for {label.upper()}:")
    print(f"  (A) Baseline: Fully Fixed = {a_full_count}/{n} ({a_full_count/n*100:.1f}%), Partially Fixed = {a_part_count}/{n}, Avg Time = {a_total_time/n:.3f}s")
    print(f"  (B) Agent:    Fully Fixed = {b_full_count}/{n} ({b_full_count/n*100:.1f}%), Partially Fixed = {b_part_count}/{n}, Avg Attempts = {b_total_attempts/n:.1f}, Avg Time = {b_total_time/n:.3f}s")

    return {
        "label": label,
        "count": n,
        "baseline_full": a_full_count,
        "baseline_partial": a_part_count,
        "baseline_avg_time": a_total_time / n,
        "agent_full": b_full_count,
        "agent_partial": b_part_count,
        "agent_avg_attempts": b_total_attempts / n,
        "agent_avg_time": b_total_time / n,
        "fixtures": results
    }


def main():
    print("=" * 85)
    print("ITEM 1.3: AGENT EVALUATION (DEV & HELD-OUT SPLITS)")
    print("=" * 85)

    is_frozen, exp_h, act_h = verify_heldout_freeze()
    print("HELD-OUT INTEGRITY CHECK:")
    print(f"  Frozen SHA256:  {exp_h}")
    print(f"  Current SHA256: {act_h}")
    print(f"  Status:         {'FROZEN & VERIFIED' if is_frozen else 'CONTAMINATED/MISMATCH'}")
    if not is_frozen:
        print("WARNING: Held-out dataset does not match frozen hash!")

    dev_summary = run_eval_on_folder(DEV_DIR, "dev")
    hld_summary = run_eval_on_folder(HLD_DIR, "heldout")

    print("\n" + "=" * 85)
    print("HONEST ORCHESTRATION ASSESSMENT:")
    print("=" * 85)
    print("Findings:")
    print(f"- DEV Split Accuracy:      Baseline={dev_summary['baseline_full']}/{dev_summary['count']} vs Agent={dev_summary['agent_full']}/{dev_summary['count']}")
    print(f"- HELD-OUT Accuracy:      Baseline={hld_summary['baseline_full']}/{hld_summary['count']} vs Agent={hld_summary['agent_full']}/{hld_summary['count']}")
    print("- Architectural Impact:    The agent acts strictly as an orchestrator around the existing")
    print("                           rule fixers. Fix accuracy is determined by the underlying rule tier;")
    print("                           the agent adds step-by-step trace logging, clean stop conditions,")
    print("                           hash-based loop/progress memory, and mandatory human approval.")
    print("=" * 85)


if __name__ == "__main__":
    main()
