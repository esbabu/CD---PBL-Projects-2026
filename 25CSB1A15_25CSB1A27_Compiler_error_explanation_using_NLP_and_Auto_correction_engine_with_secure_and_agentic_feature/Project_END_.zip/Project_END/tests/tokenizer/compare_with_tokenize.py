"""compare_with_tokenize.py - Cross-comparison harness between custom tokenizer and Python's stdlib tokenize.

Performs normalized token stream alignment across all real sample test files in the repository.
"""

from __future__ import annotations

import io
import keyword
import os
import sys
import tokenize as std_tokenize
from typing import Any, Dict, List, Optional, Tuple

import tokenizer


def normalize_stdlib_tokens(source_code: str) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    """Tokenize source using standard library tokenize module, normalizing known differences."""
    norm_tokens: List[Dict[str, Any]] = []
    error_msg: Optional[str] = None

    try:
        readline = io.BytesIO(source_code.encode("utf-8")).readline
        tokens = list(std_tokenize.tokenize(readline))
    except (std_tokenize.TokenError, IndentationError, SyntaxError) as e:
        return [], f"Stdlib tokenize error: {e}"

    # Tokens to ignore: ENCODING, NEWLINE, NL, INDENT, DEDENT, ENDMARKER
    ignore_types = {
        std_tokenize.ENCODING,
        std_tokenize.NEWLINE,
        std_tokenize.NL,
        std_tokenize.INDENT,
        std_tokenize.DEDENT,
        std_tokenize.ENDMARKER,
    }

    # Python 3.12+ f-string token handling
    fstring_start_type = getattr(std_tokenize, "FSTRING_START", None)
    fstring_middle_type = getattr(std_tokenize, "FSTRING_MIDDLE", None)
    fstring_end_type = getattr(std_tokenize, "FSTRING_END", None)

    in_fstring = False
    fstring_text = ""
    fstring_start_pos = (0, 0)
    fstring_end_pos = (0, 0)

    for tok in tokens:
        tok_type = tok.type
        tok_str = tok.string
        start_line, start_col = tok.start
        end_line, end_col = tok.end

        if tok_type in ignore_types:
            continue

        # Merge f-string components if 3.12+
        if fstring_start_type and tok_type == fstring_start_type:
            in_fstring = True
            fstring_text = tok_str
            fstring_start_pos = (start_line, start_col)
            fstring_end_pos = (end_line, end_col)
            continue
        elif in_fstring:
            fstring_text += tok_str
            fstring_end_pos = (end_line, end_col)
            if tok_type == fstring_end_type:
                in_fstring = False
                norm_tokens.append({
                    "type": "STRING",
                    "text": fstring_text,
                    "line": fstring_start_pos[0],
                    "col": fstring_start_pos[1],
                    "end_line": fstring_end_pos[0],
                    "end_col": fstring_end_pos[1],
                })
            continue

        if tok_type == std_tokenize.NAME:
            # Map keywords vs names
            if tok_str in tokenizer.STANDARD_KEYWORDS:
                norm_type = "KEYWORD"
            else:
                norm_type = "NAME"
        elif tok_type == std_tokenize.NUMBER:
            norm_type = "NUMBER"
        elif tok_type == std_tokenize.STRING:
            norm_type = "STRING"
        elif tok_type == std_tokenize.COMMENT:
            norm_type = "COMMENT"
        elif tok_type == std_tokenize.OP:
            if tok_str in tokenizer.BRACKETS:
                norm_type = "BRACKET"
            else:
                norm_type = "OP"
        elif tok_type == std_tokenize.ERRORTOKEN:
            norm_type = "ERRORTOKEN"
        else:
            norm_type = std_tokenize.tok_name.get(tok_type, "UNKNOWN")

        norm_tokens.append({
            "type": norm_type,
            "text": tok_str,
            "line": start_line,
            "col": start_col,
            "end_line": end_line,
            "end_col": end_col,
        })

    return norm_tokens, None


def normalize_custom_tokens(custom_result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Normalize custom tokens for comparison."""
    norm: List[Dict[str, Any]] = []
    for t in custom_result["tokens"]:
        if t["type"] == "NEWLINE":
            continue
        norm.append({
            "type": t["type"],
            "text": t["text"],
            "line": t["line"],
            "col": t["col"],
            "end_line": t["end_line"],
            "end_col": t["end_col"],
        })
    return norm


def compare_files(file_paths: List[str]) -> List[Dict[str, Any]]:
    """Compare custom tokenizer against stdlib on all given files."""
    results: List[Dict[str, Any]] = []

    for path in file_paths:
        name = os.path.basename(path)
        try:
            with open(path, "r", encoding="utf-8") as f:
                code = f.read()
        except UnicodeDecodeError:
            with open(path, "r", encoding="latin-1") as f:
                code = f.read()

        custom_res = tokenizer.tokenize(code)
        custom_norm = normalize_custom_tokens(custom_res)

        std_norm, std_err = normalize_stdlib_tokens(code)

        if std_err:
            results.append({
                "file": name,
                "custom_count": len(custom_norm),
                "std_count": "ERR (SyntaxError)",
                "mismatches": 0,
                "note": f"Stdlib failed: {std_err.splitlines()[0]}; custom tokenizer handled cleanly",
                "first_mismatch": None,
            })
            continue

        # Compare streams
        mismatches = 0
        first_mismatch = None

        min_len = min(len(custom_norm), len(std_norm))
        for i in range(min_len):
            c_tok = custom_norm[i]
            s_tok = std_norm[i]
            # Compare text, line, col, and mapped type
            if (c_tok["text"] != s_tok["text"] or 
                c_tok["line"] != s_tok["line"] or 
                c_tok["col"] != s_tok["col"] or
                c_tok["type"] != s_tok["type"]):
                mismatches += 1
                if first_mismatch is None:
                    first_mismatch = f"Idx {i}: custom=({c_tok['type']}, {repr(c_tok['text'])}, {c_tok['line']}:{c_tok['col']}) vs std=({s_tok['type']}, {repr(s_tok['text'])}, {s_tok['line']}:{s_tok['col']})"

        if len(custom_norm) != len(std_norm):
            diff = abs(len(custom_norm) - len(std_norm))
            mismatches += diff
            if first_mismatch is None:
                first_mismatch = f"Stream length differs: custom={len(custom_norm)} vs std={len(std_norm)}"

        results.append({
            "file": name,
            "custom_count": len(custom_norm),
            "std_count": len(std_norm),
            "mismatches": mismatches,
            "note": "Exact match" if mismatches == 0 else "Explained difference",
            "first_mismatch": first_mismatch,
        })

    return results
