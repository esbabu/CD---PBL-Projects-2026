import os
import sys
sys.path.insert(0, os.path.abspath("."))
import unittest
import app as flask_app

client = flask_app.app.test_client()
test_code = 'x = (1 + 2)\n'

envs = [
    ('E1 (default)', {'MULTI_ERROR': '1', 'AUTOFIX_AI': '1'}),
    ('E2 (offline)', {'LLM_DISABLED': '1', 'MULTI_ERROR': '1'}),
    ('E3 (ai enabled)', {'AUTOFIX_AI': '1', 'GEMINI_API_KEY': 'fake_key', 'LLM_BUDGET_ENFORCE': '1'}),
    ('E4 (single-error)', {'MULTI_ERROR': '0'}),
]

print("=" * 80)
print("VERIFICATION MATRIX: ENVIRONMENTS E1 - E4")
print("=" * 80)

for name, e_dict in envs:
    # Set env
    for k, v in e_dict.items():
        os.environ[k] = v
    resp = client.post("/api/analyze", json={"code": test_code})
    data = resp.get_json()
    has_bracket = "bracket_check" in data
    has_guard = "input_guard" in data
    status_ok = resp.status_code == 200
    print(f"[{name}] HTTP {resp.status_code} | bracket_check present: {has_bracket} | input_guard present: {has_guard} | Status: {data.get('status')}")
    assert status_ok and has_bracket and has_guard

print("\nALL ENVIRONMENTS E1-E4 VERIFIED SUCCESSFULLY (PASS)")
