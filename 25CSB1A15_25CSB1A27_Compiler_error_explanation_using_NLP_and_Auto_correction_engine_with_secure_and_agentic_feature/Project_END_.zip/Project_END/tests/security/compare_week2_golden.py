"""compare_week2_golden.py - Regression harness comparing live Flask test client output
against tests/security/week2_golden_before.json.
"""

import sys
import os
import glob
import json
import hashlib

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ["LLM_DISABLED"] = "1"
os.environ["AUTOFIX_AI"] = "0"
os.environ["CODECARBON_SAVE_TO_FILE"] = "false"
os.environ["CODECARBON_LOG_LEVEL"] = "error"

import app as flask_app

GOLDEN_PATH = os.path.join(_ROOT, "tests", "security", "week2_golden_before.json")

def load_catalog():
    catalog = {}
    real_sample_files = [
        "test1.py", "test2.py", "test3.py", "test4.py", "test5.py",
        "test6.py", "test7.py", "test8.py", "test_case_large.py",
        "test_case_new.py", "test3_fixed.py", "test_case_large_fixed.py",
        "test_security.py"
    ]
    for rf in real_sample_files:
        p = os.path.join(_ROOT, rf)
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                catalog[rf] = f.read()

    with open(os.path.join(_ROOT, "benchmark", "golden_before.json"), "r", encoding="utf-8") as f:
        gb = json.load(f)
    for cid, cinfo in gb.get("golden_cases", {}).items():
        catalog[f"golden_{cid}"] = cinfo["input_code"]

    snippets = {
        "A1": "x = 10 / 0",
        "A2": "print(undefined_variable_xyz)",
        "A3": "print('Total: ' + 5)",
        "A4": "lst = [1, 2, 3]\nprint(lst[10])",
        "A5": "import math\nprint(math.sqrt(-1))",
        "A6": "for x in 100:\n    print(x)",
        "B1": "def countdown(n):\n    return countdown(n - 1)\ncountdown(5)",
        "B2": "it = iter([])\nres = next(it)",
        "B3": "x = 10\ndef foo():\n    x = x + 1\nfoo()",
        "B4": "d = {'a': 1, 'b': 2}\nfor k in d:\n    d.pop(k)",
        "B5": "import non_existent_pkg_12345",
        "B6": "import os\nos.mkdir('.')",
        "C1": "def greet(name)\n    print('Hello', name)",
        "C2": "print 'Hello world'",
        "C3": "if x = 5:\n    print('Five')",
        "C4": "import os\nos.system('echo hi')",
        "C5a": 's = "unterminated string literal\nprint(s)',
        "C5b": 'x = [1, 2, 3\nprint("done")',
        "guard_zerodiv": "x = 10 / 0",
        "guard_index": "lst = [1, 2, 3]\nprint(lst[10])",
        "guard_key": "d = {'a': 1}\nprint(d['b'])",
        "block_A1_A6": 'import os\n\n# Multi-error block\nx = 10 / 0\nprint("Ans: " + 5)\nlst = [1, 2]\nprint(lst[10])\nfor i in 10:\n    print(i)\nimport math\nprint(math.sqrt(-1))',
        "three_error": 'x = 1 / 0\ny = "abc" + 123\ndef bar():\n    print(missing_var)\nbar()\n',
        "cascade": 'x = undefined_func()\nprint(x)\n',
        "unreached": 'def unreachable_func():\n    bad = 10 / 0\n    return bad\n\nprint("Normal execution")\n'
    }
    for s_name, s_code in snippets.items():
        if s_name not in catalog:
            catalog[s_name] = s_code
    return catalog

def capture_response(client, code):
    resp = client.post("/api/analyze", json={"code": code})
    data = resp.get_json() or {}
    st = data.get("status")
    err_t = data.get("error_type")
    line = data.get("line_number")
    fst = data.get("fix_status")
    fsrc = data.get("fix_source")
    fcode = data.get("fixed_code") or ""
    fcode_hash = hashlib.sha256(fcode.encode("utf-8")).hexdigest()
    err_cnt = data.get("error_count")
    fix_cnt = data.get("fixed_count")
    rem_cnt = data.get("remaining_count")
    err_tuples = []
    for e in data.get("errors", []):
        err_tuples.append([e.get("line"), e.get("type"), e.get("fix_status")])
    scan_blocked = (st == "security_blocked")
    return {
        "http_status": resp.status_code,
        "status": st,
        "error_type": err_t,
        "line": line,
        "fix_status": fst,
        "fix_source": fsrc,
        "fixed_code_sha256": fcode_hash,
        "error_count": err_cnt,
        "fixed_count": fix_cnt,
        "remaining_count": rem_cnt,
        "error_tuples": err_tuples,
        "scan_blocked": scan_blocked
    }

def run_comparison():
    if not os.path.exists(GOLDEN_PATH):
        print(f"ERROR: Golden file not found: {GOLDEN_PATH}")
        sys.exit(1)

    with open(GOLDEN_PATH, "r", encoding="utf-8") as f:
        golden = json.load(f)

    client = flask_app.app.test_client()
    catalog = load_catalog()

    mismatches = []
    allowed_differences = []

    print("=" * 80)
    print("WEEK 2 REGRESSION HARNESS: COMPARING LIVE TEST CLIENT WITH GOLDEN BASELINE")
    print("=" * 80)

    # 1. Routes check
    current_routes = []
    for rule in flask_app.app.url_map.iter_rules():
        current_routes.append({
            "rule": rule.rule,
            "methods": sorted(list(rule.methods)),
            "endpoint": rule.endpoint
        })
    current_routes.sort(key=lambda x: x["rule"])
    
    golden_routes = golden.get("routes", [])
    if current_routes != golden_routes:
        # Check if difference is purely additive
        golden_rule_set = {r["rule"] for r in golden_routes}
        curr_rule_set = {r["rule"] for r in current_routes}
        if golden_rule_set.issubset(curr_rule_set):
            added = curr_rule_set - golden_rule_set
            allowed_differences.append(f"Routes: additive routes detected: {sorted(list(added))}")
        else:
            mismatches.append(f"Routes: modified/deleted routes: {curr_rule_set ^ golden_rule_set}")

    # 2. /api/files check
    res_files = client.get("/api/files")
    curr_files = res_files.get_json().get("files", [])
    if curr_files != golden.get("api_files", []):
        mismatches.append(f"/api/files list changed: {len(curr_files)} vs {len(golden.get('api_files', []))}")

    # 3. /api/version keys check
    res_ver = client.get("/api/version")
    curr_ver_keys = set(res_ver.get_json().keys())
    gold_ver_keys = set(golden.get("api_version_keys", []))
    if not gold_ver_keys.issubset(curr_ver_keys):
        mismatches.append(f"/api/version missing existing keys: {gold_ver_keys - curr_ver_keys}")
    elif curr_ver_keys != gold_ver_keys:
        allowed_differences.append(f"/api/version additive keys: {sorted(list(curr_ver_keys - gold_ver_keys))}")

    # 4. Program responses comparison
    for mode, flag in [("programs_default", "1"), ("programs_single_mode", "0")]:
        os.environ["MULTI_ERROR"] = flag
        gold_progs = golden.get(mode, {})
        for name, code in catalog.items():
            if name not in gold_progs:
                continue
            exp = gold_progs[name]
            act = capture_response(client, code)

            # Check for differences
            diffs = []
            for field in ["status", "error_type", "line", "fix_status", "fix_source",
                          "fixed_code_sha256", "error_count", "fixed_count", "remaining_count", "scan_blocked"]:
                if exp.get(field) != act.get(field):
                    diffs.append((field, exp.get(field), act.get(field)))

            if diffs:
                # If change is a newly blocked CRITICAL rule
                if act.get("scan_blocked") and not exp.get("scan_blocked"):
                    allowed_differences.append(f"[{mode}] {name}: Newly blocked by security scan: {diffs}")
                elif name == "test_case_new.py" and act.get("fixed_count", 0) > exp.get("fixed_count", 0):
                    allowed_differences.append(f"[{mode}] {name}: Multi-error repaired defect past unfixable import: {diffs}")
                else:
                    mismatches.append(f"[{mode}] {name}: regression diffs: {diffs}")

    print(f"Total Programs Checked: {len(catalog)} (in 2 modes = {len(catalog) * 2} runs)")
    print(f"Allowed / Expected Differences: {len(allowed_differences)}")
    for ad in allowed_differences:
        print(f"  [ALLOWED] {ad}")

    print(f"Unexplained Regressions: {len(mismatches)}")
    for m in mismatches:
        print(f"  [REGRESSION] {m}")

    print("=" * 80)
    if mismatches:
        print("FAIL: Regressions detected!")
        return 1
    else:
        print("PASS: Zero regressions detected across all endpoints and golden programs.")
        return 0

if __name__ == "__main__":
    sys.exit(run_comparison())
