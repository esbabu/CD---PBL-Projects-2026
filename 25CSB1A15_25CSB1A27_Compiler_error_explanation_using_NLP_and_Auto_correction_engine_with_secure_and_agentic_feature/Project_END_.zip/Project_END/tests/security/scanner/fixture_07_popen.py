import os
p = os.popen('whoami')
