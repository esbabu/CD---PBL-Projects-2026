import os
with open('MARKER_EXECUTED.txt', 'w') as f:
    f.write('MALICIOUS_EXECUTION_TRIGGERED')
