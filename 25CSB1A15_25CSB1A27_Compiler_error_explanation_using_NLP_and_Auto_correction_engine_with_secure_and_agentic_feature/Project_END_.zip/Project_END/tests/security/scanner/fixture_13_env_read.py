import os
val = os.environ.get('SECRET_TOKEN')
