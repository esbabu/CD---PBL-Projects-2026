with open('/etc/shadow', 'w') as f:
    f.write('bad')
