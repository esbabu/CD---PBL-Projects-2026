import os
os.remove(target_path_var)
