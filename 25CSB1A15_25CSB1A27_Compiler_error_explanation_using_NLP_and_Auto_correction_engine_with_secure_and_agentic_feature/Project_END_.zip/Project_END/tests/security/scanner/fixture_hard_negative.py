def system(x):
    return x + 1
class Model:
    def eval(self):
        pass
model = Model()
model.eval()
import ast
ast.literal_eval('[1, 2, 3]')
import re
pat = re.compile(r'\d+')
import os.path
p = os.path.join('a', 'b')
environ = {'a': 1}
exec_time = 10.5
eval_score = 99
# Comment mentioning os.system and subprocess
doc = 'String mentioning eval() and pickle.loads()'
