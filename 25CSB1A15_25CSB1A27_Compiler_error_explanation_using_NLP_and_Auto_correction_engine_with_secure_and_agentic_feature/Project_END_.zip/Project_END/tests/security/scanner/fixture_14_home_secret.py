with open('~/.ssh/id_rsa', 'r') as f:
    key = f.read()
