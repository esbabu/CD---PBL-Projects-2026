import pickle
data = pickle.loads(b'cos\nsystem\n(S\x27id\x27\ntR.')
