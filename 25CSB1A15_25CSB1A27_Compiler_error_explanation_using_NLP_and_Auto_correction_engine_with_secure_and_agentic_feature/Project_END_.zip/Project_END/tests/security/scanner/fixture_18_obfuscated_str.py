exec(''.join(['p', 'r', 'i', 'n', 't']))
