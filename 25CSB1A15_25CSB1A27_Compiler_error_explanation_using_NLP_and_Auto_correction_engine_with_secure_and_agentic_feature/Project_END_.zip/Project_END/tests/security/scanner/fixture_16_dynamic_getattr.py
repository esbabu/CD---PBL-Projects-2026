import math
func = getattr(math, func_name_var)
