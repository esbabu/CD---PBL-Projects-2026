code = '1+1'
eval(code)
