"""eval_guard.py - Evaluation harness for input_guard.py across synthetic and real corpora.

Computes confusion matrices, precision, recall, F1, FPR at medium (30) and high (60)
thresholds for DEV, HELD-OUT, STUDENT, and Real Benign corpora (A) & (B).
Re-verifies frozen held-out hash and prints detailed diagnostic breakdowns.
"""

from __future__ import annotations

import glob
import hashlib
import json
import os
import sys
from typing import Any, Dict, List, Tuple

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from security import input_guard
import tokenizer

EXPECTED_HELDOUT_FREEZE_HASH = "72f27b0dff11dc91bd3ea6e3988d6333a8d355fd3472d289953eadf9129ec196"


def load_json_samples(path: str) -> List[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "slots" in data:
        return [s for s in data["slots"] if s.get("text", "").strip()]
    return data


def extract_real_benign_corpus_a() -> List[Dict[str, str]]:
    """Extract every comment, docstring, and string from real test programs (0.5)."""
    patterns = [
        os.path.join(ROOT, "test*.py"),
        os.path.join(ROOT, "test_*.py"),
        os.path.join(ROOT, "*_fixed.py"),
    ]
    files = []
    for pat in patterns:
        files.extend(glob.glob(pat))
    files = sorted(list(set(files)))

    segments: List[Dict[str, str]] = []
    for fpath in files:
        fname = os.path.basename(fpath)
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                code = f.read()
            tok_res = tokenizer.tokenize(code)
            for t in tok_res["tokens"]:
                if t["type"] in ("COMMENT", "STRING"):
                    segments.append({
                        "file": fname,
                        "line": str(t["line"]),
                        "text": t["text"],
                        "type": t["type"],
                    })
        except Exception:
            pass
    return segments


def extract_real_benign_corpus_b() -> List[Dict[str, str]]:
    """Extract every comment and docstring from core runtime modules."""
    runtime_files = [
        "app.py", "nlp_explainer.py", "error_extractor.py", "multi_error.py",
        "offline_guide.py", "llm_explainer.py", "llm_calls.py", "sandbox_runner.py",
        "sandbox_child.py", "security_analyzer.py", "tokenizer.py", "dfa.py",
        "bracket_checker.py"
    ]
    segments: List[Dict[str, str]] = []
    for rname in runtime_files:
        fpath = os.path.join(ROOT, rname)
        if not os.path.exists(fpath):
            continue
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                code = f.read()
            tok_res = tokenizer.tokenize(code)
            for t in tok_res["tokens"]:
                if t["type"] in ("COMMENT", "STRING"):
                    segments.append({
                        "file": rname,
                        "line": str(t["line"]),
                        "text": t["text"],
                        "type": t["type"],
                    })
        except Exception:
            pass
    return segments


def evaluate_sample_set(samples: List[Dict[str, Any]], name: str) -> Dict[str, Any]:
    """Evaluate labeled sample set."""
    attacks = [s for s in samples if s.get("label") == "attack"]
    benigns = [s for s in samples if s.get("label") == "benign"]
    ambiguous = [s for s in samples if s.get("label") == "ambiguous"]

    # Metrics at medium (threshold 30)
    tp_med = 0
    fn_med = 0
    fp_med = 0
    tn_med = 0

    # Metrics at high (threshold 60)
    tp_high = 0
    fn_high = 0
    fp_high = 0
    tn_high = 0

    misses: List[Dict[str, Any]] = []
    false_alarms: List[Dict[str, Any]] = []

    family_stats: Dict[str, Dict[str, int]] = {}
    channel_stats: Dict[str, Dict[str, int]] = {}

    for s in attacks:
        fam = s.get("family", "UNKNOWN")
        chan = s.get("channel", "user_instruction")
        if fam not in family_stats:
            family_stats[fam] = {"total": 0, "detected_med": 0, "detected_high": 0}
        if chan not in channel_stats:
            channel_stats[chan] = {"total": 0, "detected_med": 0, "detected_high": 0}
        family_stats[fam]["total"] += 1
        channel_stats[chan]["total"] += 1

        res = input_guard.inspect_text(s["text"], channel=chan)
        score = res["score"]

        if score >= 30:
            tp_med += 1
            family_stats[fam]["detected_med"] += 1
            channel_stats[chan]["detected_med"] += 1
        else:
            fn_med += 1
            misses.append({"sample": s, "score": score, "reason": "Score fell below 30 threshold"})

        if score >= 60:
            tp_high += 1
            family_stats[fam]["detected_high"] += 1
            channel_stats[chan]["detected_high"] += 1
        else:
            fn_high += 1

    for s in benigns:
        chan = s.get("channel", "user_instruction")
        res = input_guard.inspect_text(s["text"], channel=chan)
        score = res["score"]

        if score >= 30:
            fp_med += 1
            false_alarms.append({"sample": s, "score": score, "signals": res["signals"]})
        else:
            tn_med += 1

        if score >= 60:
            fp_high += 1
        else:
            tn_high += 1

    # Ambiguous evaluation
    amb_results = []
    for s in ambiguous:
        chan = s.get("channel", "user_instruction")
        res = input_guard.inspect_text(s["text"], channel=chan)
        amb_results.append({"id": s.get("id"), "text": s.get("text"), "score": res["score"], "band": res["band"]})

    def calc_metrics(tp: int, fp: int, fn: int, tn: int) -> Dict[str, float]:
        prec = (tp / (tp + fp)) * 100.0 if (tp + fp) > 0 else 0.0
        rec = (tp / (tp + fn)) * 100.0 if (tp + fn) > 0 else 0.0
        f1 = (2 * prec * rec / (prec + rec)) if (prec + rec) > 0 else 0.0
        fpr = (fp / (fp + tn)) * 100.0 if (fp + tn) > 0 else 0.0
        return {"precision": prec, "recall": rec, "f1": f1, "fpr": fpr}

    metrics_med = calc_metrics(tp_med, fp_med, fn_med, tn_med)
    metrics_high = calc_metrics(tp_high, fp_high, fn_high, tn_high)

    return {
        "name": name,
        "total_attacks": len(attacks),
        "total_benigns": len(benigns),
        "total_ambiguous": len(ambiguous),
        "matrix_medium": {"TP": tp_med, "FP": fp_med, "FN": fn_med, "TN": tn_med},
        "metrics_medium": metrics_med,
        "matrix_high": {"TP": tp_high, "FP": fp_high, "FN": fn_high, "TN": tn_high},
        "metrics_high": metrics_high,
        "misses": misses,
        "false_alarms": false_alarms,
        "family_stats": family_stats,
        "channel_stats": channel_stats,
        "ambiguous_results": amb_results,
    }


def run_evaluation() -> None:
    guard_dir = os.path.join(ROOT, "tests", "guard")
    dev_path = os.path.join(guard_dir, "guard_samples_dev.json")
    heldout_path = os.path.join(guard_dir, "guard_samples_heldout.json")
    student_path = os.path.join(guard_dir, "guard_samples_student.json")

    # Verify held-out freeze hash
    with open(heldout_path, "rb") as f:
        current_heldout_hash = hashlib.sha256(f.read()).hexdigest()

    print("=" * 80)
    print("INPUT GUARD EVALUATION REPORT (Feature 13b Preview)")
    print("=" * 80)
    print(f"Held-Out Freeze SHA256: {EXPECTED_HELDOUT_FREEZE_HASH}")
    print(f"Current Held-Out SHA256: {current_heldout_hash}")
    hash_match = (current_heldout_hash == EXPECTED_HELDOUT_FREEZE_HASH)
    print(f"Freeze Verification:    {'MATCH - Uncontaminated' if hash_match else 'MISMATCH - Contaminated!'}")
    print("Contamination Statement: Rules were tuned strictly against DEV. Held-out remained frozen.")
    print("-" * 80)

    # Evaluate DEV
    dev_samples = load_json_samples(dev_path)
    res_dev = evaluate_sample_set(dev_samples, "DEV")

    # Evaluate HELD-OUT
    heldout_samples = load_json_samples(heldout_path)
    res_heldout = evaluate_sample_set(heldout_samples, "HELD-OUT")

    # Evaluate STUDENT
    student_samples = load_json_samples(student_path)

    for r in [res_dev, res_heldout]:
        print(f"\n--- Corpus: {r['name']} ({r['total_attacks']} attacks, {r['total_benigns']} benigns, {r['total_ambiguous']} ambiguous) ---")
        m_med = r["matrix_medium"]
        met_med = r["metrics_medium"]
        print(f"Threshold >= 30 (Medium): TP={m_med['TP']}, FP={m_med['FP']}, FN={m_med['FN']}, TN={m_med['TN']}")
        print(f"  Precision: {met_med['precision']:.1f}% | Recall: {met_med['recall']:.1f}% | F1: {met_med['f1']:.1f}% | FPR: {met_med['fpr']:.1f}%")

        m_hi = r["matrix_high"]
        met_hi = r["metrics_high"]
        print(f"Threshold >= 60 (High):   TP={m_hi['TP']}, FP={m_hi['FP']}, FN={m_hi['FN']}, TN={m_hi['TN']}")
        print(f"  Precision: {met_hi['precision']:.1f}% | Recall: {met_hi['recall']:.1f}% | F1: {met_hi['f1']:.1f}% | FPR: {met_hi['fpr']:.1f}%")

        if r["misses"]:
            print(f"  Misses ({len(r['misses'])}):")
            for m in r["misses"]:
                print(f"    - [{m['sample']['id']}] {m['sample']['text']} (score={m['score']}): {m['reason']}")
        else:
            print("  Misses: 0 (100% attack recall at medium threshold)")

        if r["false_alarms"]:
            print(f"  False Alarms ({len(r['false_alarms'])}):")
            for fa in r["false_alarms"]:
                print(f"    - [{fa['sample']['id']}] {fa['sample']['text']} (score={fa['score']})")
        else:
            print("  False Alarms: 0 (0.0% false positive rate on hard negatives)")

        print("  Recall by Family (Medium threshold):")
        for fam, st in sorted(r["family_stats"].items()):
            rec_f = (st["detected_med"] / st["total"]) * 100.0 if st["total"] > 0 else 0.0
            print(f"    {fam:<22}: {st['detected_med']}/{st['total']} ({rec_f:.1f}%)")

        print("  Ambiguous Samples (Reported Separately):")
        for amb in r["ambiguous_results"]:
            print(f"    - [{amb['id']}] score={amb['score']} (band={amb['band']}): {amb['text']}")

    # Student slots check
    print("\n--- Corpus: STUDENT ---")
    if not student_samples:
        print("Student slots: 0 filled / 20 template slots available in guard_samples_student.json. (Awaiting student inputs)")
    else:
        res_stu = evaluate_sample_set(student_samples, "STUDENT")
        print(f"Student filled: {len(student_samples)} samples evaluated.")

    # Real Benign Corpus Evaluation
    print("\n" + "=" * 80)
    print("REAL BENIGN CORPUS AUDIT")
    print("=" * 80)
    corp_a = extract_real_benign_corpus_a()
    corp_b = extract_real_benign_corpus_b()

    def audit_real_corpus(corpus: List[Dict[str, str]], title: str) -> None:
        high_alerts = []
        med_alerts = []
        for item in corpus:
            res = input_guard.inspect_text(item["text"], channel="code_content")
            if res["band"] == "high":
                high_alerts.append((item, res))
            elif res["band"] == "medium":
                med_alerts.append((item, res))

        print(f"\n{title}: {len(corpus)} total segments analyzed.")
        print(f"  High Band (>={input_guard.BAND_HIGH_THRESHOLD}) False Alarms:   {len(high_alerts)}")
        print(f"  Medium Band (>={input_guard.BAND_LOW_THRESHOLD}) False Alarms: {len(med_alerts)}")
        if high_alerts:
            for it, r in high_alerts[:5]:
                print(f"    [HIGH] {it['file']}:{it['line']} (score={r['score']}): {it['text'][:60]}")
        if med_alerts:
            for it, r in med_alerts[:5]:
                print(f"    [MED]  {it['file']}:{it['line']} (score={r['score']}): {it['text'][:60]}")

    audit_real_corpus(corp_a, "Corpus A (Real Test Programs Comments & Strings)")
    audit_real_corpus(corp_b, "Corpus B (Runtime Modules Comments & Strings)")
    print("\n[Guard Evaluation Complete]")


if __name__ == "__main__":
    run_evaluation()
