"""tests_bracket.py - Pushdown Automaton (PDA) bracket validation tests.

Tests Feature 6 (TOC Week 3):
- 300+ deterministic random mutants generated against Python 3.13 compile() SyntaxError messages.
- Confusion matrix output (agree-bracket, agree-clean, you-flag-not-python, python-flags-not-you) and agreement rate.
- Hand-written unit tests for nested structures, mismatches, unclosed delimiters, comments/strings immunity, trace execution, and recovery.
"""

from __future__ import annotations

import glob
import os
import random
import re
import unittest

import bracket_checker
import tokenizer

PYTHON_BRACKET_PATTERNS = [
    re.compile(r"was never closed", re.IGNORECASE),
    re.compile(r"unmatched", re.IGNORECASE),
    re.compile(r"does not match opening parenthesis", re.IGNORECASE),
    re.compile(r"closing parenthesis .* does not match", re.IGNORECASE),
]


def is_python_bracket_syntax_error(msg: str) -> bool:
    """Check if Python's SyntaxError message indicates a bracket problem."""
    return any(p.search(msg) for p in PYTHON_BRACKET_PATTERNS)


class TestBracketChecker(unittest.TestCase):
    """Test suite for explicit Pushdown Automaton bracket checker."""

    def test_handwritten_clean_and_nested(self) -> None:
        """Test valid nested expressions."""
        clean_cases = [
            "",
            "x = (1 + [2, {3: 4}])",
            "def foo(a, b):\n    return [x for x in (a, b)]\n",
            "matrix = [[1, 2], [3, 4]]",
            "d = {'a': {'b': (1, [2, 3])}}",
        ]
        for c in clean_cases:
            res = bracket_checker.check_brackets(c)
            self.assertTrue(res["ok"], f"Expected OK for clean code: {c}")
            self.assertEqual(len(res["problems"]), 0)

    def test_brackets_in_strings_and_comments_ignored(self) -> None:
        """Verify that unbalanced brackets within comments and string literals are ignored."""
        code = (
            '# Unmatched bracket in comment: ) ] }\n'
            's1 = "Unmatched string bracket: ( [ {"\n'
            's2 = """Multi-line bracket: ( (\n)"""\n'
            'valid_expr = (1 + 2)\n'
        )
        res = bracket_checker.check_brackets(code)
        self.assertTrue(res["ok"], "Brackets in strings/comments must not trigger errors")
        self.assertEqual(len(res["problems"]), 0)

    def test_unclosed_brackets(self) -> None:
        """Verify detection of unclosed brackets."""
        code = "def f():\n    return (1 + 2"
        res = bracket_checker.check_brackets(code)
        self.assertFalse(res["ok"])
        self.assertEqual(len(res["problems"]), 1)
        self.assertEqual(res["problems"][0]["kind"], "unclosed")
        self.assertEqual(res["problems"][0]["line"], 2)

    def test_unmatched_closing_bracket(self) -> None:
        """Verify detection of extra/unmatched closing brackets."""
        code = "x = 1 + 2)"
        res = bracket_checker.check_brackets(code)
        self.assertFalse(res["ok"])
        self.assertEqual(len(res["problems"]), 1)
        self.assertEqual(res["problems"][0]["kind"], "unmatched_closing")
        self.assertEqual(res["problems"][0]["line"], 1)

    def test_mismatched_brackets(self) -> None:
        """Verify detection of mismatched delimiter pairs."""
        code = "items = [1, 2, 3)"
        res = bracket_checker.check_brackets(code)
        self.assertFalse(res["ok"])
        self.assertEqual(len(res["problems"]), 1)
        self.assertEqual(res["problems"][0]["kind"], "mismatched")
        self.assertEqual(res["problems"][0]["open_char"], "[")
        self.assertEqual(res["problems"][0]["close_char"], ")")

    def test_pda_trace(self) -> None:
        """Verify formal PDA transition trace output."""
        code = "( [ ] ) }"
        res = bracket_checker.check_brackets(code, trace=True)
        self.assertFalse(res["ok"])
        self.assertIsNotNone(res["trace"])
        trace = res["trace"]
        # Actions should include PUSH, PUSH, POP, POP, REJECT
        actions = [step["action"] for step in trace]
        self.assertIn("PUSH(()", actions[0])
        self.assertIn("PUSH([)", actions[1])
        self.assertIn("POP([)", actions[2])
        self.assertIn("POP(()", actions[3])
        self.assertIn("REJECT_UNMATCHED_CLOSING", actions[4])

    def test_mutants_agreement_with_python(self) -> None:
        """Generate 300+ deterministic random mutants from real clean files and compare against Python compile()."""
        seed = 42
        rng = random.Random(seed)
        print(f"\n[Bracket Mutant Testing] Initializing deterministic mutation engine with seed={seed}")

        # Collect clean source files
        root = os.path.dirname(os.path.abspath(__file__))
        clean_sources = []
        for path in sorted(glob.glob(os.path.join(root, "test*.py"))):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                compile(content, path, "exec")
                clean_sources.append((os.path.basename(path), content))
            except Exception:
                continue

        self.assertGreater(len(clean_sources), 0, "No clean source files found to mutate")

        # Mutation operations
        mutant_records = []
        target_count = 350
        mutation_types = ["delete", "extra_close", "swap", "unclosed_open"]

        while len(mutant_records) < target_count:
            file_name, original_code = rng.choice(clean_sources)
            tok_res = tokenizer.tokenize(original_code)
            bracket_indices = [
                i for i, t in enumerate(tok_res["tokens"]) if t["type"] == "BRACKET"
            ]

            m_type = rng.choice(mutation_types)

            if m_type in ("delete", "swap") and bracket_indices:
                idx = rng.choice(bracket_indices)
                target_tok = tok_res["tokens"][idx]
                t_line = target_tok["line"]
                t_col = target_tok["col"]

                lines = original_code.splitlines(keepends=True)
                if t_line - 1 < len(lines):
                    line_str = lines[t_line - 1]
                    if t_col < len(line_str):
                        if m_type == "delete":
                            new_line = line_str[:t_col] + line_str[t_col + 1:]
                        else:  # swap
                            orig_ch = line_str[t_col]
                            swaps = {"(": "[", "[": "{", "{": "(", ")": "]", "]": "}", "}": ")"}
                            new_line = line_str[:t_col] + swaps.get(orig_ch, "(") + line_str[t_col + 1:]
                        lines[t_line - 1] = new_line
                        mutant_code = "".join(lines)
                        mutant_records.append((f"{file_name}_{m_type}_{len(mutant_records)}", mutant_code))

            elif m_type == "extra_close":
                extra_ch = rng.choice([")", "]", "}"])
                lines = original_code.splitlines(keepends=True)
                if lines:
                    insert_line = rng.randint(0, len(lines) - 1)
                    lines[insert_line] = lines[insert_line].rstrip("\r\n") + extra_ch + "\n"
                    mutant_code = "".join(lines)
                    mutant_records.append((f"{file_name}_extra_{len(mutant_records)}", mutant_code))

            elif m_type == "unclosed_open":
                open_ch = rng.choice(["(", "[", "{"])
                lines = original_code.splitlines(keepends=True)
                if lines:
                    insert_line = rng.randint(0, len(lines) - 1)
                    lines[insert_line] = lines[insert_line].rstrip("\r\n") + f" + {open_ch}1\n"
                    mutant_code = "".join(lines)
                    mutant_records.append((f"{file_name}_unclosed_{len(mutant_records)}", mutant_code))

        # Confusion matrix counters
        agree_bracket = 0
        agree_clean = 0
        you_flag_python_not = 0
        python_flags_you_not = 0

        disagreements = []

        for name, m_code in mutant_records:
            # 1. Custom PDA evaluation
            pda_res = bracket_checker.check_brackets(m_code)
            pda_flagged = not pda_res["ok"]

            # 2. Python compile() evaluation
            py_flagged = False
            py_syntax_msg = ""
            try:
                compile(m_code, "<mutant>", "exec")
            except SyntaxError as e:
                py_syntax_msg = str(e)
                if is_python_bracket_syntax_error(py_syntax_msg):
                    py_flagged = True
                else:
                    # Other syntax error induced by bracket edit
                    py_flagged = False
            except Exception:
                pass

            if pda_flagged and py_flagged:
                agree_bracket += 1
            elif not pda_flagged and not py_flagged:
                agree_clean += 1
            elif pda_flagged and not py_flagged:
                # PDA caught bracket mismatch/unclosed, but Python reported non-bracket error or accepted
                you_flag_python_not += 1
                disagreements.append((name, "PDA flagged, Python did not", pda_res["problems"][0]["message"], py_syntax_msg))
            else:
                # Python flagged bracket error, but PDA missed it
                python_flags_you_not += 1
                disagreements.append((name, "Python flagged bracket error, PDA missed", "", py_syntax_msg))

        total_checked = len(mutant_records)
        agreement_count = agree_bracket + agree_clean
        agreement_rate = (agreement_count / total_checked) * 100.0

        print("\n=== Bracket Mutant Confusion Matrix ===")
        print(f"Seed: {seed} | Total Mutants Checked: {total_checked}")
        print(f"  Agree Bracket Error:            {agree_bracket}")
        print(f"  Agree Clean:                    {agree_clean}")
        print(f"  You Flagged, Python Did Not:    {you_flag_python_not} (e.g. Python raised cascade SyntaxError like 'invalid syntax')")
        print(f"  Python Flagged, You Did Not:    {python_flags_you_not}")
        print(f"  Agreement Rate on Bracket Err:  {agreement_rate:.2f}%")

        # Assert PDA never misses a bracket error caught by Python
        self.assertEqual(
            python_flags_you_not,
            0,
            f"PDA missed {python_flags_you_not} bracket errors flagged by Python: {disagreements[:3]}",
        )
        self.assertGreaterEqual(total_checked, 300)


if __name__ == "__main__":
    unittest.main()
