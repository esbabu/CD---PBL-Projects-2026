"""offline_guide.py – Deterministic offline guide for Python errors.

Provides:
- guide(error_type, message, line_no, offending_line, code) -> str
- get_reference_notes(error_type, message) -> str (for grounding AI prompts)

Never makes network calls, never raises, and never leaves unformatted placeholders.
"""

import builtins
import re
from typing import Optional, Tuple

# Common package alias mapping (import name -> PyPI package name)
PACKAGE_ALIASES = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "yaml": "PyYAML",
    "bs4": "beautifulsoup4",
    "dateutil": "python-dateutil",
    "dotenv": "python-dotenv",
    "skimage": "scikit-image",
    "Crypto": "pycryptodome",
    "serial": "pyserial",
}


def _extract_slots(error_type_clean: str, message: str) -> dict:
    """Extract message-aware slots (module name, variable name, path, table, etc.)."""
    slots = {}
    if not message:
        return slots

    msg = str(message)

    # ModuleNotFoundError: "No module named 'xyz'"
    m = re.search(r"No module named\s+'([^']+)'", msg, re.IGNORECASE)
    if m:
        mod_name = m.group(1)
        slots["module"] = mod_name
        # Check alias
        top_mod = mod_name.split(".")[0]
        slots["pypi_package"] = PACKAGE_ALIASES.get(top_mod, mod_name)

    # ImportError: "cannot import name 'foo' from 'bar'"
    m = re.search(r"cannot import name\s+'([^']+)'(?:\s+from\s+'([^']+)')?", msg, re.IGNORECASE)
    if m:
        slots["import_name"] = m.group(1)
        if m.group(2):
            slots["import_source"] = m.group(2)
            top_mod = m.group(2).split(".")[0]
            slots["pypi_package"] = PACKAGE_ALIASES.get(top_mod, m.group(2))

    # UnboundLocalError: "local variable 'v' referenced before assignment"
    # or "cannot access local variable 'v' where it is not associated with a value"
    m = re.search(r"(?:local variable|variable)\s+'([^']+)'\s+(?:referenced before assignment|where it is not associated)", msg, re.IGNORECASE)
    if m:
        slots["variable"] = m.group(1)

    # NameError: "name 'x' is not defined"
    m = re.search(r"name\s+'([^']+)'\s+is not defined", msg, re.IGNORECASE)
    if m:
        slots["name"] = m.group(1)

    # File / Path errors: Permission denied, File exists, No such file
    m = re.search(r"(?:Permission denied|File exists|No such file or directory|Not a directory|Is a directory):\s*'([^']+)'", msg, re.IGNORECASE)
    if m:
        slots["path"] = m.group(1)

    # SQLite table / column errors
    m = re.search(r"no such table:\s*([^\s,]+)", msg, re.IGNORECASE)
    if m:
        slots["table"] = m.group(1)
    m = re.search(r"no such column:\s*([^\s,]+)", msg, re.IGNORECASE)
    if m:
        slots["column"] = m.group(1)

    # JSON decode error diagnosis
    if "Expecting value" in msg:
        slots["json_cause"] = "Input string is empty, truncated, or contains non-JSON text."
    elif "Expecting property name enclosed in double quotes" in msg:
        slots["json_cause"] = "JSON keys must use double quotes (not single quotes), or there is a trailing comma."
    elif "Expecting ',' delimiter" in msg:
        slots["json_cause"] = "Missing comma separating properties or list elements."
    elif "Extra data" in msg:
        slots["json_cause"] = "Multiple top-level JSON documents or trailing text found after valid JSON."
    elif "Unterminated string" in msg:
        slots["json_cause"] = "A string literal was opened with quotes but never closed before newline/EOF."
    
    m_pos = re.search(r"(?:line\s+(\d+)\s+column\s+(\d+)\s*\(char\s+(\d+)\)|char\s+(\d+))", msg, re.IGNORECASE)
    if m_pos:
        slots["json_pos"] = m_pos.group(0)

    # KeyError: key representation
    m = re.search(r"^['\"]?(.*?)['\"]?$", msg.strip())
    if m and error_type_clean == "KeyError" and msg.strip():
        slots["key"] = msg.strip().strip("'\"")

    return slots


# Knowledge base of error types with meaning, causes, and fixes
_KNOWLEDGE_BASE = {
    "ModuleNotFoundError": {
        "meaning": "Python could not find or load the requested module in the current environment.",
        "causes": [
            "The library is not installed in the active virtual environment.",
            "The module name is misspelled or differs from the package name (e.g. PIL -> Pillow, cv2 -> opencv-python).",
            "A local file shares the same name as the library and shadows it."
        ],
        "fixes": [
            "First double-check the spelling of the import name.",
            "Install the package using the PyPI package name: run pip install {pypi_package}.",
            "Ensure you are running the script in the active virtual environment."
        ]
    },
    "ImportError": {
        "meaning": "An imported name could not be resolved from the specified module or package.",
        "causes": [
            "The attribute, class, or function does not exist in the imported module.",
            "Circular import dependencies between two modules.",
            "A local file has the same name as the module being imported and shadows it."
        ],
        "fixes": [
            "Verify the imported symbol name is exported by the module and check for circular imports.",
            "If importing a package, check if the package name on PyPI differs (e.g. pip install {pypi_package})."
        ]
    },
    "UnboundLocalError": {
        "meaning": "A local variable was accessed before a value was assigned to it inside a function.",
        "causes": [
            "Assigning to a variable inside a function marks it as local, shadowing outer scope variables.",
            "Referencing the variable before its assignment line in that function."
        ],
        "fixes": [
            "Assign an initial value to the variable before reading it.",
            "If intending to modify an outer variable, declare `global {var_name}` or `nonlocal {var_name}`.",
            "Pass the variable into the function as an explicit parameter."
        ]
    },
    "RecursionError": {
        "meaning": "A function called itself repeatedly without reaching a base condition, exceeding Python's call stack limit.",
        "causes": [
            "Missing or incorrect base condition in a recursive function.",
            "Mutually recursive functions calling each other indefinitely."
        ],
        "fixes": [
            "Add a base termination condition (e.g. `if n <= 0: return ...`) that stops further recursion while preserving function intent.",
            "Ensure recursive arguments advance towards the base condition on every step."
        ]
    },
    "OverflowError": {
        "meaning": "A numerical calculation produced a result too large for Python's floating-point or integer representation.",
        "causes": [
            "Floating-point exponents growing too large (e.g. `math.exp(1000)`).",
            "Unbounded multiplication in a loop causing float overflow."
        ],
        "fixes": [
            "Clamp or scale numerical inputs before exponentiation.",
            "Use logarithmic transformations (e.g. `math.log`) or arbitrary-precision libraries."
        ]
    },
    "AssertionError": {
        "meaning": "An `assert` statement evaluated to False, indicating an unmet precondition or test expectation.",
        "causes": [
            "An invariant or precondition check failed during execution.",
            "A unit test assertion did not receive the expected value."
        ],
        "fixes": [
            "Inspect the values on both sides of the comparison to determine why they differ.",
            "Correct the state of the program before the assert line runs."
        ]
    },
    "NotImplementedError": {
        "meaning": "An abstract method or feature was called that has not been implemented yet.",
        "causes": [
            "A subclass did not override an abstract base method.",
            "A stub function raised `NotImplementedError` as a placeholder."
        ],
        "fixes": [
            "Provide a concrete implementation for the method in the subclass.",
            "Complete the placeholder code if it was left as a TODO."
        ]
    },
    "StopIteration": {
        "meaning": "An iterator or generator has no further items to produce.",
        "causes": [
            "Calling next() on an exhausted iterator without a default fallback value.",
            "An iterator completed all available elements."
        ],
        "fixes": [
            "Provide a default value to next(iterator, default_value) to avoid raising.",
            "Use a standard for loop which handles iteration termination automatically."
        ]
    },
    "RuntimeError": {
        "meaning": "A generic runtime error occurred that does not fit into more specific exception categories.",
        "causes": [
            "Modifying a dictionary or collection while iterating over it.",
            "Attempting an operation in an invalid program lifecycle state."
        ],
        "fixes": [
            "Iterate over a copy of the collection (e.g., for k in list(my_dict):).",
            "Verify prerequisite setup steps before calling runtime operations."
        ]
    },
    "EOFError": {
        "meaning": "An input operation hit the End-Of-File (EOF) unexpectedly without reading data.",
        "causes": [
            "Calling input() in an automated script or sandbox without piped stdin.",
            "Reading from a closed stream or empty file buffer."
        ],
        "fixes": [
            "Supply simulated input or mock input in automated environments.",
            "Wrap input() in a try/except EOFError block to handle end-of-stream gracefully."
        ]
    },
    "LookupError": {
        "meaning": "A key, index, or codec lookup failed.",
        "causes": [
            "Accessing an invalid index or key in a mapping or sequence.",
            "Requesting an unsupported character encoding."
        ],
        "fixes": [
            "Verify the index or key exists before looking it up.",
            "Use safe lookup methods like .get(key, default) or length checks."
        ]
    },
    "ReferenceError": {
        "meaning": "A weak reference proxy was used after the referenced object was already garbage collected.",
        "causes": [
            "Accessing a weakref target whose strong references have all been cleared."
        ],
        "fixes": [
            "Maintain a strong reference to the object as long as access is required.",
            "Check whether the weak reference is alive before accessing its attributes."
        ]
    },
    "TabError": {
        "meaning": "The code contains inconsistent mixing of tabs and spaces for indentation.",
        "causes": [
            "Mixing tab characters and space characters in the same code block.",
            "Copy-pasting code with different indentation styles."
        ],
        "fixes": [
            "Convert all indentation to 4 spaces consistently across the file.",
            "Configure your editor to automatically expand tabs to spaces."
        ]
    },

    "UnicodeDecodeError": {
        "meaning": "Bytes could not be decoded into text using the specified character encoding.",
        "causes": [
            "Reading a file encoded in utf-8 using an incompatible encoding, or vice versa.",
            "Binary data passed to a text reader."
        ],
        "fixes": [
            "Specify the correct encoding when opening files (e.g. `open(path, 'r', encoding='utf-8')`).",
            "Open binary files in binary mode (e.g. `rb`)."
        ]
    },
    "UnicodeEncodeError": {
        "meaning": "Text characters could not be converted into bytes using the target character encoding.",
        "causes": [
            "Writing non-ASCII characters to a stream that only supports ASCII."
        ],
        "fixes": [
            "Specify `encoding='utf-8'` explicitly when writing files or network streams.",
            "Use unicode escape formatting if restricted to ASCII targets."
        ]
    },
    "FileExistsError": {
        "meaning": "Attempted to create a file or directory that already exists on disk.",
        "causes": [
            "Calling `os.mkdir()` or `os.makedirs()` on an existing directory without `exist_ok=True`.",
            "Opening a file in exclusive creation mode (`'x'`) when it already exists."
        ],
        "fixes": [
            "Pass `exist_ok=True` when creating directories with `os.makedirs(path, exist_ok=True)`.",
            "Check `os.path.exists(path)` before attempting creation, or use standard write mode `'w'`."
        ]
    },
    "NotADirectoryError": {
        "meaning": "A directory operation was attempted on a path that is actually a regular file.",
        "causes": [
            "Listing contents (`os.listdir`) of a regular file path.",
            "Using a file path as if it were a directory in a path join."
        ],
        "fixes": [
            "Verify whether the target path is a directory using `os.path.isdir(path)`.",
            "Check path resolution to ensure the correct folder path is provided."
        ]
    },
    "PermissionError": {
        "meaning": "The operating system denied permission to perform the requested file or resource action.",
        "causes": [
            "Insufficient filesystem privileges to read, write, or execute the target path.",
            "Attempting to write to a read-only file or open a directory as a file."
        ],
        "fixes": [
            "Verify file permissions and ensure your user account has write/read access.",
            "Close any other process that currently has an exclusive lock on the file.",
            "Choose an accessible directory such as user home or a temporary folder."
        ]
    },
    "IsADirectoryError": {
        "meaning": "A file operation was attempted on a directory path.",
        "causes": [
            "Opening a directory with `open(path, 'r')`.",
            "Attempting to write file contents directly to a directory name."
        ],
        "fixes": [
            "Specify the full path including the file name inside the directory.",
            "Check `os.path.isfile(path)` before opening."
        ]
    },
    "TimeoutError": {
        "meaning": "An operation timed out before completing.",
        "causes": [
            "Infinite loops or heavy computation taking longer than the allowed timeout.",
            "A network request or subprocess hanging."
        ],
        "fixes": [
            "Check loop termination conditions to avoid infinite loops.",
            "Optimize expensive operations or increase the timeout limit if appropriate."
        ]
    },
    "MemoryError": {
        "meaning": "The program exhausted available system or process memory.",
        "causes": [
            "Allocating massive lists or arrays at once.",
            "Unbounded caching or memory leaks in long-running loops."
        ],
        "fixes": [
            "Use generators or chunked processing instead of loading entire datasets into memory.",
            "Release large references when no longer needed using `del` and clear caches."
        ]
    },
    "OSError": {
        "meaning": "An operating system error occurred during a system call or file I/O.",
        "causes": [
            "Hardware, device, or filesystem communication failure.",
            "Invalid file descriptors or OS parameters."
        ],
        "fixes": [
            "Verify system resource paths and hardware connectivity.",
            "Handle OS-specific error codes using `try/except OSError:`."
        ]
    },
    "ConnectionError": {
        "meaning": "A network connection failed, was refused, or was interrupted.",
        "causes": [
            "The target host or server is unreachable or offline.",
            "Firewall or network routing issues blocking traffic."
        ],
        "fixes": [
            "Verify internet connectivity and server URL/port.",
            "Implement retry logic with exponential backoff for transient connection drops."
        ]
    },
    "ArithmeticError": {
        "meaning": "An error occurred during a mathematical operation.",
        "causes": [
            "Division by zero, floating point errors, or numeric range overflows."
        ],
        "fixes": [
            "Validate numerical inputs before applying math operations."
        ]
    },
    "FloatingPointError": {
        "meaning": "A floating point computation failed or produced an undefined value.",
        "causes": [
            "Floating point exceptions enabled in numpy or C-extensions encountering NaN/Inf."
        ],
        "fixes": [
            "Guard floating point calculations against division by zero and domain violations."
        ]
    },
    "JSONDecodeError": {
        "meaning": "The string provided to the JSON parser is not formatted as valid JSON.",
        "causes": [
            "Unquoted keys, single quotes instead of double quotes, or trailing commas.",
            "Empty string or non-JSON text passed to `json.loads()`."
        ],
        "fixes": [
            "Ensure JSON text uses valid syntax (double quotes for strings/keys, no trailing commas).",
            "Verify that the input string is non-empty and contains valid JSON before parsing."
        ]
    },
    "OperationalError": {
        "meaning": "A database operational error occurred (such as SQLite locking or missing schema).",
        "causes": [
            "Querying a table or column that does not exist in the database schema.",
            "Database file is locked by another connection."
        ],
        "fixes": [
            "Verify table and column names against your database schema definition.",
            "Run migrations or `CREATE TABLE IF NOT EXISTS` before querying.",
            "Ensure database connections are closed or committed properly."
        ]
    },
    "StatisticsError": {
        "meaning": "A statistics calculation failed due to invalid data points.",
        "causes": [
            "Passing an empty list to functions like `mean()`, `median()`, or `mode()`.",
            "Multimodal data where a single unique mode does not exist."
        ],
        "fixes": [
            "Verify that the input collection is non-empty before calling statistical functions.",
            "Use `multimode()` instead of `mode()` if data may contain multiple modal values."
        ]
    },
    # 10 Rule-engine types included for universal coverage
    "ZeroDivisionError": {
        "meaning": "A number was divided by zero.",
        "causes": ["Denominator evaluated to zero at runtime."],
        "fixes": ["Guard the division with an if-check (e.g. `if divisor != 0:`) before dividing."]
    },
    "NameError": {
        "meaning": "A variable or function name was used that has not been defined in the current scope.",
        "causes": ["Misspelled name, or variable referenced before assignment."],
        "fixes": ["Define or initialize the variable before reading it, and check spelling."]
    },
    "TypeError": {
        "meaning": "An operation or function was applied to an object of inappropriate data type.",
        "causes": ["Combining incompatible types or passing wrong arguments to a function."],
        "fixes": ["Convert data types explicitly using `str()`, `int()`, or verify arguments."]
    },
    "SyntaxError": {
        "meaning": "Python could not parse the code due to incorrect syntax structure.",
        "causes": ["Missing colon, unclosed brackets, or invalid keywords."],
        "fixes": ["Check syntax at the highlighted line and add missing colons or parentheses."]
    },
    "IndexError": {
        "meaning": "Sequence subscript is out of range.",
        "causes": ["Accessing an index that is >= the length of the list or tuple."],
        "fixes": ["Check `len(sequence)` before indexing, or use `for item in sequence:`."]
    },
    "KeyError": {
        "meaning": "A mapping key was not found in the dictionary.",
        "causes": ["Looking up a key that does not exist."],
        "fixes": ["Use `.get(key, default)` or verify with `if key in dict:`."]
    },
    "ValueError": {
        "meaning": "A function received an argument that has the right type but an inappropriate value.",
        "causes": ["Converting an invalid string to int/float or domain errors."],
        "fixes": ["Validate the input value before passing it to the conversion function."]
    },
    "AttributeError": {
        "meaning": "An attribute reference or assignment failed on the object.",
        "causes": ["Calling a method that does not exist on that type (e.g. NoneType)."],
        "fixes": ["Verify the object is not None and has the expected type and methods."]
    },
    "IndentationError": {
        "meaning": "Incorrect indentation level in a code block.",
        "causes": ["Missing indentation after compound statements or mixed indentation."],
        "fixes": ["Indent the block by 4 spaces consistently."]
    },
    "FileNotFoundError": {
        "meaning": "A file or directory requested for opening could not be found.",
        "causes": ["The path is wrong or the file does not exist in the working directory."],
        "fixes": ["Check the file path and verify `os.path.exists(path)`."]
    }
}


def _find_nearest_known_type(error_type: str) -> Tuple[str, dict]:
    """Look up error type by last dotted component, or walk exception MRO."""
    clean_type = (error_type or "").split(".")[-1].strip()
    
    if clean_type in _KNOWLEDGE_BASE:
        return clean_type, _KNOWLEDGE_BASE[clean_type]
    
    if error_type in _KNOWLEDGE_BASE:
        return error_type, _KNOWLEDGE_BASE[error_type]

    # Walk built-in exception hierarchy
    exc_cls = getattr(builtins, clean_type, None)
    if exc_cls and isinstance(exc_cls, type) and issubclass(exc_cls, BaseException):
        for base in exc_cls.__mro__[1:]:
            base_name = base.__name__
            if base_name in _KNOWLEDGE_BASE:
                return base_name, _KNOWLEDGE_BASE[base_name]

    # Fallback generic knowledge
    return clean_type or "Exception", {
        "meaning": f"An unhandled {clean_type or 'Exception'} occurred during execution.",
        "causes": [
            "An unexpected runtime state or invalid operation was encountered.",
            "Unhandled edge case in function inputs."
        ],
        "fixes": [
            "Inspect the error message and traceback to identify the failing operation.",
            "Add defensive checks or wrap the failing block in a try/except block."
        ]
    }


def get_reference_notes(error_type: str, message: str) -> str:
    """Generate concise reference notes for grounding LLM prompts."""
    matched_type, entry = _find_nearest_known_type(error_type)
    slots = _extract_slots(matched_type, message)

    notes = [f"Error Meaning: {entry['meaning']}"]
    causes = entry.get("causes", [])
    if causes:
        notes.append("Common Causes: " + "; ".join(causes[:2]))
    fixes = entry.get("fixes", [])
    if fixes:
        clean_fix = fixes[0].replace("{pypi_package}", slots.get("pypi_package", "the required package"))
        clean_fix = clean_fix.replace("{var_name}", slots.get("variable", "the variable"))
        notes.append("Standard Fix: " + clean_fix)

    return "\n".join(notes)


def guide(
    error_type: str,
    message: str,
    line_no: Optional[int] = None,
    offending_line: str = "",
    code: str = ""  # noqa: ARG001
) -> str:
    """Generate an offline, deterministic error explanation.
    
    Returns text in the format:
    [Offline guide - no AI used] Mistake: ... Reason: ... Fix: ...
    Never raises, never calls network.
    """
    try:
        raw_type = error_type or "Exception"
        matched_type, entry = _find_nearest_known_type(raw_type)
        slots = _extract_slots(matched_type, message)

        if code and isinstance(line_no, int):
            lines = code.splitlines()
            if 1 <= line_no <= len(lines):
                offending_line = lines[line_no - 1]

        line_str = f" on line {line_no}" if line_no else ""
        offending_str = f" (Offending line: `{offending_line.strip()}`)" if offending_line and offending_line.strip() else ""


        # Construct customized Mistake
        if matched_type == "ModuleNotFoundError" and "module" in slots:
            pypi = slots.get("pypi_package", slots["module"])
            if pypi != slots["module"]:
                mistake = f"Python could not find module '{slots['module']}' (PyPI package: {pypi}){line_str}{offending_str}."
            else:
                mistake = f"Python could not find module '{slots['module']}'{line_str}{offending_str}."

        elif matched_type == "ImportError" and "import_name" in slots:
            src = f" from '{slots['import_source']}'" if "import_source" in slots else ""
            mistake = f"Cannot import name '{slots['import_name']}'{src}{line_str}{offending_str}."
        elif matched_type == "UnboundLocalError" and "variable" in slots:
            mistake = f"Local variable '{slots['variable']}' was referenced before assignment{line_str}{offending_str}."
        elif matched_type == "NameError" and "name" in slots:
            mistake = f"Using undefined variable or name '{slots['name']}'{line_str}{offending_str}."
        elif "path" in slots:
            mistake = f"{entry['meaning'][:-1]} for path '{slots['path']}'{line_str}{offending_str}."
        elif "table" in slots:
            mistake = f"Database query references non-existent table '{slots['table']}'{line_str}{offending_str}."
        elif "column" in slots:
            mistake = f"Database query references non-existent column '{slots['column']}'{line_str}{offending_str}."
        elif matched_type == "RecursionError":
            mistake = f"Maximum recursion depth exceeded{line_str}{offending_str}."
        elif matched_type == "JSONDecodeError":
            pos_info = f" at {slots['json_pos']}" if "json_pos" in slots else ""
            mistake = f"JSON decoding failed{pos_info}{line_str}{offending_str}."
        elif matched_type == "AssertionError":
            expr = offending_line.replace("assert", "").strip() if offending_line and "assert" in offending_line else "the assertion expression"
            mistake = f"Assertion condition failed: `{expr}`{line_str}{offending_str}."
        elif matched_type == "KeyError" and "key" in slots:
            mistake = f"Dictionary key '{slots['key']}' was not found{line_str}{offending_str}."
        else:
            meaning = entry["meaning"]
            mistake = f"{raw_type}{line_str}{offending_str}: {meaning}"

        # Construct Reason
        if matched_type == "JSONDecodeError" and "json_cause" in slots:
            reason = slots["json_cause"]
        elif matched_type == "AssertionError":
            reason = "The expression evaluated to False at runtime. Compare both sides of the condition to check for mismatched state."
        else:
            causes = entry.get("causes", ["Unexpected runtime condition."])
            reason = " ".join(causes[:2])

        # Construct customized Fix
        fixes = list(entry.get("fixes", ["Check the line where the error occurred."]))
        custom_fix = None

        if matched_type == "ModuleNotFoundError" and "module" in slots:
            pypi = slots.get("pypi_package", slots["module"])
            if pypi != slots["module"]:
                custom_fix = f"Check the import spelling first. If correct, install via 'pip install {pypi}'."
            else:
                custom_fix = f"Check the import spelling first, then install the package via 'pip install {slots['module']}'."
        elif matched_type == "ImportError" and "import_name" in slots:
            src = f" in '{slots['import_source']}'" if "import_source" in slots else ""
            custom_fix = f"Verify that '{slots['import_name']}' is defined{src} and check for circular imports."
        elif matched_type == "UnboundLocalError" and "variable" in slots:
            custom_fix = f"Initialize '{slots['variable']}' before reading it, or declare 'global {slots['variable']}' / 'nonlocal {slots['variable']}'."
        elif matched_type == "NameError" and "name" in slots:
            custom_fix = f"Define or initialize variable '{slots['name']}' in the enclosing scope before using it."
        elif "path" in slots and matched_type in ("PermissionError", "FileExistsError", "FileNotFoundError", "NotADirectoryError"):
            custom_fix = f"Verify that path '{slots['path']}' exists with correct permissions or pass exist_ok=True."
        elif "table" in slots:
            custom_fix = f"Ensure table '{slots['table']}' is created in the database schema before executing this query."
        elif "column" in slots:
            custom_fix = f"Verify column '{slots['column']}' exists in the database table schema."
        elif matched_type == "AssertionError":
            custom_fix = "Inspect why the expected condition failed and update the logic or expected values accordingly."
        elif matched_type == "JSONDecodeError":
            custom_fix = "Ensure JSON strings use double quotes, have valid delimiters without trailing commas, and are non-empty."

        if custom_fix:
            fix = custom_fix
        else:
            fix = fixes[0].replace("{pypi_package}", slots.get("pypi_package", "the required package"))
            fix = fix.replace("{var_name}", slots.get("variable", "the variable"))
            fix = re.sub(r'\{.*?\}|<.*?>', 'the required value', fix)

        # Assemble normalized string with prefix
        result = f"[Offline guide - no AI used] Mistake: {mistake}\nReason: {reason}\nFix: {fix}"
        return result

    except Exception:
        # Ultimate fail-safe generic guide
        return (
            f"[Offline guide - no AI used] Mistake: Error {error_type or 'Exception'} occurred.\n"
            f"Reason: An unhandled exception was encountered during execution.\n"
            f"Fix: Check the traceback and error message for details."
        )
