"""pda_engine.py - Formal Pushdown Automaton (PDA) Stack & Tape Animator.

Implements Feature 2:
- Formal 7-tuple Pushdown Automaton: M = (Q, Sigma, Gamma, delta, q0, Z0, F)
- Full step-by-step Instantaneous Description (ID) generation: (q, w, gamma)
- Tape animator displaying consumed tokens, current read head, and remaining tape
- Stack animator tracking push/pop operations, stack depth, and visual stack frame layers
- Context-Free Grammar rejection diagnosis explaining Chomsky Level-2 memory requirements
- Mermaid flowchart generator for the PDA state transitions
- Automatic integration with tokenizer.py and bracket_checker.py
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple
import bracket_checker
import tokenizer

BOTTOM_MARKER = "Z0"
MAX_PDA_STEPS = 500
MAX_PDA_STACK_DEPTH = 500

OPEN_BRACKETS: Set[str] = {"(", "[", "{"}
CLOSE_BRACKETS: Set[str] = {")", "]", "}"}
MATCHING_PAIRS: Dict[str, str] = {")": "(", "]": "[", "}": "{"}
REVERSE_PAIRS: Dict[str, str] = {"(": ")", "[": "]", "{": "}"}

# Formal 7-tuple specification
PDA_STATES = ["q0", "q_loop", "q_accept", "q_reject"]
PDA_START_STATE = "q0"
PDA_ACCEPT_STATES = ["q_accept"]
PDA_INPUT_ALPHABET = ["(", ")", "[", "]", "{", "}"]
PDA_STACK_ALPHABET = ["Z0", "(", "[", "{"]


class PushdownAutomaton:
    """Formal 7-tuple Pushdown Automaton for Context-Free Language parsing."""

    def __init__(self) -> None:
        self.states = list(PDA_STATES)
        self.sigma = list(PDA_INPUT_ALPHABET)
        self.gamma = list(PDA_STACK_ALPHABET)
        self.start_state = PDA_START_STATE
        self.bottom_marker = BOTTOM_MARKER
        self.accept_states = list(PDA_ACCEPT_STATES)

    def get_definition(self) -> Dict[str, Any]:
        """Returns the formal 7-tuple definition of the PDA."""
        return {
            "Q": self.states,
            "Sigma": self.sigma,
            "Gamma": self.gamma,
            "q0": self.start_state,
            "Z0": self.bottom_marker,
            "F": self.accept_states,
            "description": "7-Tuple PDA M = (Q, Sigma, Gamma, delta, q0, Z0, F) accepting balanced Dyck language by final state and empty stack."
        }


def format_instantaneous_description(state: str, remaining_tape: str, stack: List[str]) -> str:
    """Formats the formal Instantaneous Description (ID): (q, w, gamma).

    In automata theory, gamma is written with the top-of-stack as the leftmost symbol.
    """
    stack_str = "".join(reversed(stack))
    tape_str = remaining_tape if remaining_tape else "ε"
    return f"({state}, {tape_str}, {stack_str})"


def animate_pda(code_or_expression: str) -> Dict[str, Any]:
    """Simulates the PDA on code or bracket expression, generating step-by-step IDs.

    Args:
        code_or_expression: Source code string or bracket string.

    Returns:
        Dict with:
            accepted: bool
            final_state: str
            steps: List of step frames (IDs, stack snapshot, tape snapshot, action)
            problems: List of syntax/bracket errors
            summary: Natural language explanation
            mermaid: Mermaid diagram string
            pda_definition: Formal 7-tuple definition
    """
    pda = PushdownAutomaton()

    # Step 1: Tokenize input, extracting bracket events (filtering out brackets in strings/comments)
    tok_res = tokenizer.tokenize(code_or_expression)
    bracket_tokens = [t for t in tok_res.get("tokens", []) if t.get("type") == "BRACKET"]

    # Extract all bracket characters to form the initial input tape
    tape_chars = [t["text"] for t in bracket_tokens]
    full_tape_str = "".join(tape_chars)

    # Initial PDA configuration: (q0, full_tape, Z0)
    current_state = "q0"
    stack: List[str] = [BOTTOM_MARKER]
    steps: List[Dict[str, Any]] = []
    problems: List[Dict[str, Any]] = []

    # Step 0: Initial transition from q0 to q_loop with initial stack marker Z0
    step_num = 0
    init_id = format_instantaneous_description(current_state, full_tape_str, stack)
    steps.append({
        "step": step_num,
        "from_state": "q0",
        "to_state": "q_loop",
        "consumed_char": "",
        "remaining_tape": full_tape_str,
        "stack": list(stack),
        "stack_top": BOTTOM_MARKER,
        "stack_depth": 1,
        "action": f"INIT: Push {BOTTOM_MARKER} onto stack",
        "rule": f"δ(q0, ε, ε) -> (q_loop, {BOTTOM_MARKER})",
        "id": init_id,
        "line": 1,
        "col": 0,
    })
    current_state = "q_loop"

    # Step through each bracket token
    has_error = False

    for idx, tok in enumerate(bracket_tokens):
        if step_num >= MAX_PDA_STEPS or len(stack) >= MAX_PDA_STACK_DEPTH:
            problems.append({
                "kind": "animation_limit_exceeded",
                "message": f"PDA trace exceeded step limit ({MAX_PDA_STEPS}) or stack limit ({MAX_PDA_STACK_DEPTH}). Simulation truncated for safety.",
                "line": tok.get("line", 1),
                "col": tok.get("col", 0)
            })
            break
        step_num += 1
        ch = tok["text"]
        line = tok["line"]
        col = tok["col"]
        remaining_tape = "".join(tape_chars[idx + 1:])
        top_sym = stack[-1]

        if ch in OPEN_BRACKETS:
            # Action: PUSH
            stack.append(ch)
            rule_str = f"δ(q_loop, '{ch}', '{top_sym}') -> (q_loop, '{ch}{top_sym}')"
            curr_id = format_instantaneous_description(current_state, remaining_tape, stack)
            steps.append({
                "step": step_num,
                "from_state": "q_loop",
                "to_state": "q_loop",
                "consumed_char": ch,
                "remaining_tape": remaining_tape,
                "stack": list(stack),
                "stack_top": ch,
                "stack_depth": len(stack),
                "action": f"PUSH('{ch}')",
                "rule": rule_str,
                "id": curr_id,
                "line": line,
                "col": col,
            })

        elif ch in CLOSE_BRACKETS:
            expected_open = MATCHING_PAIRS[ch]

            if top_sym == BOTTOM_MARKER:
                # Underflow error: closing delimiter without any opening bracket
                has_error = True
                current_state = "q_reject"
                curr_id = format_instantaneous_description(current_state, remaining_tape, stack)
                problems.append({
                    "kind": "unmatched_closing",
                    "message": f"Unmatched '{ch}' at line {line}, col {col} (stack has only {BOTTOM_MARKER})",
                    "line": line,
                    "col": col,
                    "expected": None,
                })
                steps.append({
                    "step": step_num,
                    "from_state": "q_loop",
                    "to_state": "q_reject",
                    "consumed_char": ch,
                    "remaining_tape": remaining_tape,
                    "stack": list(stack),
                    "stack_top": top_sym,
                    "stack_depth": len(stack),
                    "action": f"REJECT: Unmatched '{ch}' on stack {BOTTOM_MARKER}",
                    "rule": f"δ(q_loop, '{ch}', '{BOTTOM_MARKER}') = UNDEFINED -> q_reject",
                    "id": curr_id,
                    "line": line,
                    "col": col,
                })
                break

            elif top_sym == expected_open:
                # Match found: POP
                popped = stack.pop()
                new_top = stack[-1]
                rule_str = f"δ(q_loop, '{ch}', '{popped}') -> (q_loop, ε)"
                curr_id = format_instantaneous_description(current_state, remaining_tape, stack)
                steps.append({
                    "step": step_num,
                    "from_state": "q_loop",
                    "to_state": "q_loop",
                    "consumed_char": ch,
                    "remaining_tape": remaining_tape,
                    "stack": list(stack),
                    "stack_top": new_top,
                    "stack_depth": len(stack),
                    "action": f"POP('{popped}') [Matches '{ch}']",
                    "rule": rule_str,
                    "id": curr_id,
                    "line": line,
                    "col": col,
                })

            else:
                # Mismatch error
                has_error = True
                current_state = "q_reject"
                expected_closer = REVERSE_PAIRS.get(top_sym, "")
                problems.append({
                    "kind": "mismatched",
                    "message": f"'{top_sym}' was closed by '{ch}' at line {line}, col {col} (expected '{expected_closer}')",
                    "line": line,
                    "col": col,
                    "open_char": top_sym,
                    "close_char": ch,
                    "expected": expected_closer,
                })
                curr_id = format_instantaneous_description(current_state, remaining_tape, stack)
                steps.append({
                    "step": step_num,
                    "from_state": "q_loop",
                    "to_state": "q_reject",
                    "consumed_char": ch,
                    "remaining_tape": remaining_tape,
                    "stack": list(stack),
                    "stack_top": top_sym,
                    "stack_depth": len(stack),
                    "action": f"REJECT: Mismatched closer '{ch}' (stack top is '{top_sym}', expected '{expected_closer}')",
                    "rule": f"δ(q_loop, '{ch}', '{top_sym}') = UNDEFINED -> q_reject",
                    "id": curr_id,
                    "line": line,
                    "col": col,
                })
                break

    # Tape exhausted: check if stack returned to Z0
    if not has_error:
        step_num += 1
        if len(stack) == 1 and stack[0] == BOTTOM_MARKER:
            # Pop Z0 and enter q_accept
            current_state = "q_accept"
            final_id = format_instantaneous_description(current_state, "", ["ε"])
            steps.append({
                "step": step_num,
                "from_state": "q_loop",
                "to_state": "q_accept",
                "consumed_char": "ε",
                "remaining_tape": "ε",
                "stack": [BOTTOM_MARKER],
                "stack_top": BOTTOM_MARKER,
                "stack_depth": 1,
                "action": f"ACCEPT: Tape empty, stack clean at {BOTTOM_MARKER}",
                "rule": f"δ(q_loop, ε, {BOTTOM_MARKER}) -> (q_accept, ε)",
                "id": final_id,
                "line": bracket_tokens[-1]["line"] if bracket_tokens else 1,
                "col": bracket_tokens[-1]["col"] if bracket_tokens else 0,
            })
        else:
            # Unclosed delimiters remaining on stack
            current_state = "q_reject"
            unclosed_syms = stack[1:]
            last_line = bracket_tokens[-1]["line"] if bracket_tokens else 1
            last_col = bracket_tokens[-1]["col"] if bracket_tokens else 0
            for s in reversed(unclosed_syms):
                problems.append({
                    "kind": "unclosed",
                    "message": f"'{s}' was opened but never closed at end of input",
                    "expected": REVERSE_PAIRS.get(s),
                    "open_char": s,
                    "line": last_line,
                    "col": last_col
                })
            final_id = format_instantaneous_description(current_state, "", stack)
            steps.append({
                "step": step_num,
                "from_state": "q_loop",
                "to_state": "q_reject",
                "consumed_char": "ε",
                "remaining_tape": "ε",
                "stack": list(stack),
                "stack_top": stack[-1],
                "stack_depth": len(stack),
                "action": f"REJECT: Tape exhausted with unclosed symbols {unclosed_syms}",
                "rule": f"δ(q_loop, ε, {stack[-1]}) = UNDEFINED -> q_reject",
                "id": final_id,
                "line": bracket_tokens[-1]["line"] if bracket_tokens else 1,
                "col": bracket_tokens[-1]["col"] if bracket_tokens else 0,
            })

    accepted = (current_state == "q_accept") and len(problems) == 0

    # Summary analysis
    if accepted:
        summary = f"Valid Context-Free string. PDA completed execution in {len(steps)} steps, successfully reaching q_accept with balanced stack."
    else:
        err_kinds = [p["kind"] for p in problems]
        summary = f"Rejected Context-Free string. PDA halted in q_reject due to {', '.join(err_kinds)}. Memory stack violated Dyck language balance."

    mermaid_str = pda_to_mermaid(steps, accepted=accepted)

    # Check for possible repair
    repaired_code = bracket_checker.fix_brackets(code_or_expression)

    return {
        "status": "success",
        "accepted": accepted,
        "final_state": current_state,
        "summary": summary,
        "steps": steps,
        "total_steps": len(steps),
        "problems": problems,
        "repaired_code": repaired_code,
        "mermaid_diagram": mermaid_str,
        "pda_definition": pda.get_definition(),
    }


def pda_to_mermaid(steps: List[Dict[str, Any]], accepted: bool = True) -> str:
    """Generates a Mermaid diagram representing the PDA state trajectory."""
    lines = [
        "flowchart LR",
        '    q0(["q0 (Start)"])',
        '    q_loop["q_loop (Process Tape)"]',
        '    q_accept((("q_accept (Balanced) ")))',
        '    q_reject["q_reject (Syntax Error)"]',
        "",
        '    q0 -->|"ε, ε → Z0"| q_loop',
        '    q_loop -->|"open, X → open X (Push)"| q_loop',
        '    q_loop -->|"close, open → ε (Pop)"| q_loop',
        '    q_loop -->|"ε, Z0 → ε"| q_accept',
        '    q_loop -.->|"mismatch / underflow"| q_reject',
        ""
    ]

    # Node styling
    if accepted:
        lines.append("    style q_accept fill:#4CAF50,stroke:#2E7D32,color:#ffffff,stroke-width:3px")
        lines.append("    style q_loop fill:#2196F3,stroke:#1565C0,color:#ffffff")
        lines.append("    style q0 fill:#9E9E9E,stroke:#616161,color:#ffffff")
    else:
        lines.append("    style q_reject fill:#F44336,stroke:#C62828,color:#ffffff,stroke-width:3px")
        lines.append("    style q_loop fill:#2196F3,stroke:#1565C0,color:#ffffff")
        lines.append("    style q0 fill:#9E9E9E,stroke:#616161,color:#ffffff")

    return "\n".join(lines)
