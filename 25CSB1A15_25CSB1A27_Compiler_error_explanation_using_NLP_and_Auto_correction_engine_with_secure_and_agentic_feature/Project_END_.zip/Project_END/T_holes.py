# C1  expect: no error; the page says the code ran fine
print("hello")

# C2  leave the box empty and click Analyze; expect a polite message, no crash

# C3  expect: stops after about 5 seconds with a timeout message; the page must not freeze
while True:
    pass

# C4  expect: flagged or blocked by the security scan; nothing should run silently (the command is harmless)
import os
os.system("echo hi")

# C5  expect: works; accents and symbols display correctly
print("héllo ✓")
x = [1, 2, 3
