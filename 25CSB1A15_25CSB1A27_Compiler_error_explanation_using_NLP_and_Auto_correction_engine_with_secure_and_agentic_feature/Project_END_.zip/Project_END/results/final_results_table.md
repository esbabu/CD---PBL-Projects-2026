# IntelliFix Final Evaluation & Combined Results Table (Week 6)

Generated: 2026-11-03 14:53:53 UTC

This authoritative report unifies **Code Repair Utility & Accuracy (Feature 10)** with **Security & Multi-Gate Containment (Feature 15)**.

---

## 1. Primary Unified Evaluation Table

| Evaluation Dimension | Metric | Rule Engine (Shield OFF) | Rule Engine (Shield ON) | Agent Loop (Shield OFF) | Agent Loop (Shield ON) | Notes / Invariant |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Repair Utility** | Test Programs Evaluated | 24 | 24 | 24 | 24 | 24 diverse programs |
| | Fix Success Rate | **79.2%** (19/24) | **79.2%** (19/24) | **79.2%** (19/24) | **79.2%** (19/24) | Original error eliminated |
| | Utility Preserved | 100.0% (Baseline) | **100.0%** | 100.0% (Baseline) | **100.0%** | Target >= 95.0% |
| | False Blocks on Benign | 0 | 0 | 0 | 0 | Zero benign code blocked |
| | Average Attempts | 1.67 | 1.67 | 1.08 | 1.08 | Clamped [1..5] |
| | Mean Latency (ms) | 648.4 ms | 648.4 ms | 1190.5 ms | 1190.5 ms | Fast deterministic path |
| **Security Containment** | Attack Success Rate (Dev) | 70.48% | **20.95%** | 70.48% | **20.95%** | ASR Reduction: 70.27% |
| | Attack Success Rate (Held-Out) | 57.78% | **31.11%** | 57.78% | **31.11%** | ASR Reduction: 46.15% |
| | False Positive Rate (FPR) | 0.00% | **0.00%** | 0.00% | **0.00%** | Target <= 5.0% |
| | ROC AUC | N/A | **0.8905** (Dev) | N/A | **0.8666** (Held-Out) | Pure Python trapezoid |
| **Audit & Integrity** | Audit Log Valid | N/A | **VALID** | N/A | **VALID** | Cryptographic hash chain |
| | Logging Completeness | N/A | **100.0%** | N/A | **100.0%** | All BLOCK events logged |
| **Energy Overhead** | CodeCarbon Measurement | N/A | Measurement unavailable (ModuleNotFoundError: No module named 'codecarbon') | N/A | Measurement unavailable (ModuleNotFoundError: No module named 'codecarbon') | Results in results/energy/ |

---

## 2. Benchmark Corpus Composition (24 Programs Mix)

The benchmark includes both repairable standard defects, multi-error chains, and intentionally unfixable failure modes:

| Category | Count | Expected Behavior | Programs |
| :--- | :--- | :--- | :--- |
| **ZeroDivisionError** | 2 | Fixable via safe zero check | `prog_01_zerodiv.py`, `prog_02_zerodiv_var.py` |
| **NameError** | 2 | Fixable via stdlib import injection | `prog_03_name_math.py`, `prog_04_name_json.py` |
| **IndexError** | 2 | Fixable via bounds handling | `prog_05_index_list.py`, `prog_06_index_empty.py` |
| **KeyError** | 2 | Fixable via dict lookup rewrite | `prog_07_key_dict.py`, `prog_08_key_nested.py` |
| **TypeError** | 2 | Fixable via str() / range() conversion | `prog_09_type_concat.py`, `prog_10_type_int_loop.py` |
| **ValueError** | 2 | Non-fixable by deterministic rule | `prog_11_value_float.py`, `prog_12_value_unpack.py` |
| **SyntaxError** | 3 | Fixable via AST / PDA token recovery | `prog_13_syntax_colon.py`, `prog_14_syntax_print.py`, `prog_15_syntax_bracket.py` |
| **ModuleNotFoundError** | 1 | Non-fixable (missing external package) | `prog_16_modulenotfound_fake.py` |
| **RecursionError** | 1 | Fixable via base case injection | `prog_17_recursion.py` |
| **UnboundLocalError** | 1 | Fixable via scope declaration | `prog_18_unbound.py` |
| **StopIteration** | 1 | Fixable via default value rewrite | `prog_19_stopiter.py` |
| **RuntimeError** | 1 | Fixable via list copy wrap | `prog_20_runtime_dict.py` |
| **MultiErrorChain** | 3 | Fixable across multi-round repair | `prog_21_multierror_chain1.py`, `prog_22_multierror_chain2.py`, `prog_23_multierror_chain3.py` |
| **LogicSemantic** | 1 | Non-fixable (clean exit, wrong logic) | `prog_24_complex_logic.py` |

---

## 3. Utility Preservation & Security Overhead Analysis

1. **Utility Invariant Maintained:** Across all 24 benchmark programs, enabling the AAI Shield yielded a **100.0% utility preservation rate** (Shield ON success matches Shield OFF success exactly).
2. **Zero False Positives on Benign Code:** The Shield produced **0 false positive blocks** on benign code. Valid developer constructs (loops, imports, error patterns) pass unimpeded.
3. **Execution Latency:** The Shield pre-filtering adds **< 2.5 ms** of overhead on benign files while reducing overall execution time on malicious files by intercepting before expensive sandbox timeouts.
