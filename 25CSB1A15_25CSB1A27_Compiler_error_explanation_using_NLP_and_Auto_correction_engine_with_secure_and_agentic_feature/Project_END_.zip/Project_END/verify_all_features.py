"""verify_all_features.py - Full End-to-End Verification of Features Added Today.

Checks:
1. Honeypot & Canary Defense System (security/canary.py + sandbox_runner)
2. Merkle Tree & Tamper-Evident Audit Ledger (security/audit_log.py)
3. AST Tree-Edit-Distance & Blast-Radius Limiter (security/blast_radius.py)
4. Dual-Key / Four-Eyes Authorization Engine (security/dual_key.py)
5. Thompson NFA -> Subset DFA -> Hopcroft Minimizer & Stepper (automaton_engine.py)
6. Control Flow Graph & Cyclomatic Complexity Heatmap (cfg_engine.py)
7. Pushdown Automaton Stack & Tape Animator (pda_engine.py)
8. AAI Shield Cryptographic Manifest & Arming Integrity (security/policy_engine.py)
9. Flask API Endpoints Live Execution (app.py)
"""

import sys
import unittest

def verify_all():
    print("=" * 70)
    print("INTELLIFIX - COMPREHENSIVE VERIFICATION OF TODAY'S FEATURES")
    print("=" * 70)

    # 1. Canary
    import security.canary as canary
    assert len(canary.DEFAULT_CANARY_ENV_VARS) >= 4, "Missing canary env vars"
    assert canary.detect_canary_leak(canary.CANARY_SIGNATURE_PREFIX + "test") is not None
    print("[PASS] 1. Canary Token & Honeypot System (Decoy envs, decoy files, leak detector)")

    # 2. Merkle Ledger
    import security.audit_log as audit_log
    root, count = audit_log.compute_merkle_root()
    is_valid, tampered_line, msg = audit_log.verify_log()
    assert is_valid is True, f"Log invalid: {msg}"
    print(f"[PASS] 2. Cryptographic Audit Ledger & Merkle Tree (Root: {root[:12]}..., Valid: {is_valid})")

    # 3. Blast Radius
    import security.blast_radius as blast_radius
    clean_eval = blast_radius.evaluate_blast_radius("x = 10", "x = 20")
    assert clean_eval["is_safe"] is True
    assert clean_eval["tree_edit_distance"] == 1
    # Check out of scope detection
    orig = "def auth(): return True\ndef calc(): return 1 / 0"
    trojan = "def auth(): return False\ndef calc(): return 1 / 2"
    trojan_eval = blast_radius.evaluate_blast_radius(orig, trojan, error_line=2)
    assert trojan_eval["is_safe"] is False
    assert len(trojan_eval["out_of_scope_mutations"]) > 0
    print("[PASS] 3. AST Tree-Edit-Distance (Zhang-Shasha TED & Out-of-Scope Detection)")

    # 4. Dual Key
    import security.dual_key as dual_key
    ok_a, k_a, _ = dual_key.generate_auditor_key("prop_demo", "x=1", "x=2")
    assert ok_a is True
    k_b = dual_key.generate_operator_key("prop_demo", "x=2", operator_id="admin_user")
    ok_v, _, v = dual_key.verify_dual_key_authorization("prop_demo", "x=2", k_a, k_b, log_audit=False)
    assert ok_v is True and v["status"] == "DUAL_KEY_AUTHORIZED"
    print("[PASS] 4. Banking Four-Eyes Dual-Key Vault (HMAC Auditor Key + Operator Key)")

    # 5. Automaton Engine
    import automaton_engine as dfa_eng
    presets = dfa_eng.list_presets()
    assert len(presets) >= 5
    dfa = dfa_eng.get_preset_dfa("identifier")
    trace = dfa_eng.step_trace(dfa, "my_var_123")
    assert trace["accepted"] is True
    min_d = dfa_eng.minimize_dfa(dfa)
    assert min_d.accepts("my_var_123") is True
    print(f"[PASS] 5. Automaton Engine (5 Presets, Hopcroft Minimizer, Trace, Mermaid LR)")

    # 6. CFG Engine
    import cfg_engine
    cfg_res = cfg_engine.analyze_code("def compute(x):\n    if x > 0:\n        return x\n    elif x == 0:\n        return 0\n    return -x")
    assert cfg_res["overall_complexity"] >= 3
    assert len(cfg_res["functions"]) == 1
    assert "flowchart TD" in cfg_res["mermaid_diagram"]
    print(f"[PASS] 6. Control Flow Graph & Complexity Heatmap (McCabe M={cfg_res['overall_complexity']}, Blocks: {len(cfg_res['cfg']['blocks'])})")

    # 7. PDA Engine
    import pda_engine
    pda_res = pda_engine.animate_pda("result = (1 + [2, {'key': (3, 4)}])")
    assert pda_res["accepted"] is True
    assert pda_res["final_state"] == "q_accept"
    pda_err = pda_engine.animate_pda("result = (1 + [2, 3))")
    assert pda_err["accepted"] is False
    assert pda_err["final_state"] == "q_reject"
    assert len(pda_err["problems"]) > 0
    print(f"[PASS] 7. Pushdown Automaton Tape & Stack Animator (Dyck Balanced Language, IDs: {pda_res['total_steps']})")

    # 8. Shield Manifest Integrity
    import security.policy_engine as policy_engine
    pe = policy_engine.get_policy_engine()
    ok_arm, arm_msg = pe.initialize()
    assert ok_arm is True, f"Shield failed arming: {arm_msg}"
    print(f"[PASS] 8. AAI Shield Cryptographic Manifest (All components armed and verified)")

    # 9. Flask API Endpoints
    import app as flask_app
    flask_app.app.config["TESTING"] = True
    client = flask_app.app.test_client()

    # Test audit endpoint
    r = client.get("/api/security/audit/verify")
    assert r.status_code == 200 and r.get_json()["status"] == "success"

    # Test dual-key attest endpoint
    r = client.post("/api/security/dual-key/attest", json={"proposal_id": "test_p", "original_code": "x=1", "fixed_code": "x=2"})
    assert r.status_code == 200 and r.get_json()["status"] == "success"

    # Test automaton presets
    r = client.get("/api/automaton/presets")
    presets_json = r.get_json()
    presets_list = presets_json.get("presets", presets_json) if isinstance(presets_json, dict) else presets_json
    assert r.status_code == 200 and len(presets_list) >= 5

    # Test CFG analyze
    r = client.post("/api/cfg/complexity", json={"code": "x = 1"})
    assert r.status_code == 200 and "overall_complexity" in r.get_json()

    # Test PDA trace
    r = client.post("/api/pda/trace", json={"expression": "([{}])"})
    assert r.status_code == 200 and r.get_json()["accepted"] is True

    print("[PASS] 9. Flask API Endpoints (All new security and automata routes verified)")

    print("=" * 70)
    print("ALL 9 SYSTEMS FULLY OPERATIONAL AND VERIFIED!")
    print("=" * 70)

if __name__ == "__main__":
    verify_all()
