"""tests_position.py – Position invariance tests for IntelliFix autofix engine.

Verifies that deterministic fixers, guards, repair loop, and AI autofix
work consistently regardless of where the failing code is located in the editor:
- W0: as is
- W1: leading comment
- W2: leading blank lines (1 and 3)
- W3: leading valid statements (x = 1)
- W4: one-line and multi-line module docstrings
- W5: leading imports
- W6: CRLF line endings
- W7: trailing comments on failing line
- W8: indented function body under main
- W9: mid-statement blank and comment lines
- W10: tab-indented bodies
- W11: UTF-8 BOM without trailing newline
"""

import os
import sys
import unittest
from unittest.mock import patch

WORKSPACE = os.path.dirname(os.path.abspath(__file__))
if WORKSPACE not in sys.path:
    sys.path.insert(0, WORKSPACE)

import app
import nlp_explainer

client = app.app.test_client()

def wrap_code(code: str, w_id: str) -> str:
    if w_id == "W0":
        return code
    elif w_id == "W1":
        return f"# leading comment line\n{code}"
    elif w_id == "W2_1":
        return f"\n{code}"
    elif w_id == "W2_3":
        return f"\n\n\n{code}"
    elif w_id == "W3":
        return f"x = 1\n{code}"
    elif w_id == "W4_1":
        return f'"""Single line module docstring."""\n{code}'
    elif w_id == "W4_m":
        return f'"""\nMulti-line\nmodule docstring.\n"""\n{code}'
    elif w_id == "W5":
        return f"import math\nimport sys\n{code}"
    elif w_id == "W6":
        return code.replace("\n", "\r\n")
    elif w_id == "W7":
        lines = code.split("\n")
        lines[-1] = lines[-1] + "  # trailing comment"
        return "\n".join(lines)
    elif w_id == "W8":
        indented = "\n".join(f"    {l}" for l in code.split("\n"))
        return f'def main():\n{indented}\n\nif __name__ == "__main__":\n    main()'
    elif w_id == "W9":
        lines = code.split("\n")
        return "\n# mid comment\n\n".join(lines)
    elif w_id == "W10":
        return code.replace("    ", "\t")
    elif w_id == "W11":
        return "\ufeff" + code.rstrip("\n")
    return code

WRAPPERS = ["W0", "W1", "W2_1", "W2_3", "W3", "W4_1", "W4_m", "W5", "W6", "W7", "W8", "W9", "W10", "W11"]


class TestPositionInvariance(unittest.TestCase):
    def setUp(self):
        os.environ["AUTOFIX_AI"] = "0"
        os.environ["LLM_DISABLED"] = "1"

    def _test_snippet_across_wrappers(self, name, code, expected_source="deterministic"):
        for w_id in WRAPPERS:
            wrapped = wrap_code(code, w_id)
            resp = client.post("/api/analyze", json={"code": wrapped})
            self.assertEqual(resp.status_code, 200, f"Failed on {name} + {w_id}: status code {resp.status_code}")
            data = resp.get_json() or {}
            
            fix_status = data.get("fix_status")
            fixed_code = data.get("fixed_code")
            fix_source = data.get("fix_source")

            self.assertEqual(fix_status, "applied", f"Expected applied fix on {name} + {w_id}, got {fix_status}")
            self.assertIsNotNone(fixed_code, f"fixed_code is None for {name} + {w_id}")
            self.assertNotEqual(fixed_code, wrapped, f"fixed_code unchanged for {name} + {w_id}")

            # Verify sandbox clean exit
            is_clean, err_t, err_m, line_no, stdout, stderr = nlp_explainer._run_in_sandbox_full(fixed_code)
            self.assertTrue(is_clean, f"Fixed code still failed for {name} + {w_id}: {err_t}: {err_m} at line {line_no}")

    def test_A1_name_error_typo(self):
        code = 'message = "hello"\nprint(mesage)'
        self._test_snippet_across_wrappers("A1", code, expected_source="rule")

    def test_A2_missing_colon(self):
        code = 'def greet(name)\n    print("Hi", name)\ngreet("Sam")'
        self._test_snippet_across_wrappers("A2", code, expected_source="rule")

    def test_A3_type_error_str_concat(self):
        code = 'print("Total: " + 5)'
        self._test_snippet_across_wrappers("A3", code, expected_source="deterministic")

    def test_A4_attribute_error_typo(self):
        code = 'nums = [3, 1, 2]\nnums.apend(4)'
        self._test_snippet_across_wrappers("A4", code, expected_source="deterministic")

    def test_A6_type_error_int_iterable(self):
        code = 'for x in 100:\n    print(x)'
        self._test_snippet_across_wrappers("A6", code, expected_source="deterministic")

    def test_B2_unbound_local(self):
        code = 'count = 0\ndef add():\n    count = count + 1\nadd()'
        self._test_snippet_across_wrappers("B2", code, expected_source="deterministic")

    def test_B3_json_empty_decode(self):
        code = 'import json\njson.loads("")'
        self._test_snippet_across_wrappers("B3", code, expected_source="deterministic")

    def test_B4_modulenotfound_typo(self):
        code = 'import jsno\nprint("ok")'
        self._test_snippet_across_wrappers("B4", code, expected_source="deterministic")

    def test_B6_stop_iteration(self):
        code = 'it = iter([])\nprint(next(it))'
        self._test_snippet_across_wrappers("B6", code, expected_source="deterministic")

    def test_G1_zerodivision_guard(self):
        code = 'a = 10\nb = 0\nprint(a / b)'
        self._test_snippet_across_wrappers("G1", code, expected_source="deterministic")

    def test_G2_indexerror_guard(self):
        code = 'lst = [1, 2, 3]\nprint(lst[10])'
        self._test_snippet_across_wrappers("G2", code, expected_source="deterministic")

    def test_G3_keyerror_guard(self):
        code = 'd = {"a": 1}\nprint(d["b"])'
        self._test_snippet_across_wrappers("G3", code, expected_source="deterministic")

    def test_C5b_unclosed_brackets(self):
        code = 'print("test")\nitems = [\'\\u20ac\', 2'
        self._test_snippet_across_wrappers("C5b", code, expected_source="deterministic")

    def test_combined_block_A1_to_A6(self):
        code = """message = "hello"
print(mesage)
def greet(name)
    print("Hi", name)
greet("Sam")
print("Total: " + 5)
nums = [3, 1, 2]
nums.apend(4)
import math
print(math.sqrt(-1))
for x in 100:
    print(x)"""
        for w_id in ["W0", "W1", "W2_1", "W3", "W6"]:
            wrapped = wrap_code(code, w_id)
            resp = client.post("/api/analyze", json={"code": wrapped})
            self.assertEqual(resp.status_code, 200)
            data = resp.get_json() or {}
            
            fix_status = data.get("fix_status", "")
            self.assertTrue(fix_status.startswith("fixed 4; stopped at line") or fix_status.startswith("fixed 5; stopped at line"), f"Unexpected fix_status for combined on {w_id}: {fix_status}")
            self.assertIn("no automatic fix; any errors after this line cannot be detected until it is fixed", fix_status)
            self.assertIn(len(data.get("fix_steps", [])), (4, 5))

    def test_ai_path_with_mocked_provider(self):
        os.environ["AUTOFIX_AI"] = "1"
        os.environ["LLM_DISABLED"] = "0"
        
        # Test B1 recursion error with mocked AI reply that uses original line numbering
        code = "def countdown(n):\n    return countdown(n - 1)\ncountdown(5)"
        
        for w_id in ["W0", "W1", "W2_1", "W3"]:
            wrapped = wrap_code(code, w_id)
            orig_lines = wrapped.splitlines()
            rec_line = 1
            for idx, l in enumerate(orig_lines, 1):
                if "return countdown" in l:
                    rec_line = idx
                    break
            
            shifted_reply = f"Replace line {rec_line} with:\n    if n <= 0:\n        return 0\n    return countdown(n - 1)"
            
            with patch("llm_calls.call_gemini", return_value=(shifted_reply, None, True)):
                explainer = nlp_explainer.NLPExplainer()
                fixed = explainer.generate_fixed_code(wrapped)
                self.assertEqual(explainer.last_fix_status, "applied")
                is_clean, _, _, _, _, _ = nlp_explainer._run_in_sandbox_full(fixed)
                self.assertTrue(is_clean, f"Mocked AI fixed code failed sandbox for {w_id}")


if __name__ == "__main__":
    unittest.main()
