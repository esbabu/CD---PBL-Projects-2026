"""tests_shield_tool_guard.py - Unit Tests for Tool Guard (Gate 2).

Tests:
- Tool allow-list enforcement (run_code, scan_security, read_file, apply_patch allowed; others blocked)
- Workspace path confinement (rejects .., absolute paths, drive letters, alternate streams)
- Approval bypass prevention on apply_patch
- Validation / scan bypass argument prevention
- Socket guard ensuring zero real external network connections
"""

import os
import socket
import unittest
from unittest.mock import patch

from security import tool_guard


class TestShieldToolGuard(unittest.TestCase):
    """Unit tests for security/tool_guard.py."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1"):
                raise AssertionError(f"Real outbound network call to {address} attempted in test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_allowlisted_tools_pass(self):
        """Allow-listed tools are accepted."""
        for tool in ["run_code", "scan_security", "read_file", "apply_patch"]:
            # With appropriate args
            args = {"code": "x = 1"} if tool != "read_file" else {"filename": "test1.py"}
            if tool == "apply_patch":
                args["staging"] = True
            res = tool_guard.check_tool_call(tool, args=args, approved=True)
            self.assertTrue(res["allowed"], f"Tool '{tool}' should be allowed with valid args")
            self.assertEqual(res["decision"], "ALLOW")

    def test_unallowlisted_tool_blocked(self):
        """Unallowlisted tools are strictly blocked with tool_arg_violation signal."""
        forbidden_tools = ["bash", "sh", "exec_shell", "rm_rf", "download_file", "eval"]
        for tool in forbidden_tools:
            res = tool_guard.check_tool_call(tool, args={})
            self.assertFalse(res["allowed"])
            self.assertEqual(res["decision"], "BLOCK")
            signals = [s["name"] for s in res["signals"]]
            self.assertIn("tool_arg_violation", signals)

    def test_path_traversal_blocked(self):
        """Path traversal sequences (.., absolute paths, drive letters) are blocked."""
        traversal_attempts = [
            "../secret.txt",
            "..\\config.json",
            "../../etc/passwd",
            "%2e%2e/data.txt",
            "C:\\Windows\\System32\\cmd.exe",
            "D:\\secrets.txt",
            "/etc/shadow",
            "test1.py:stream"
        ]
        for path in traversal_attempts:
            res = tool_guard.check_tool_call("read_file", args={"filename": path})
            self.assertFalse(res["allowed"], f"Path '{path}' should have been blocked")
            self.assertEqual(res["decision"], "BLOCK")
            signals = [s["name"] for s in res["signals"]]
            self.assertIn("path_outside_workspace", signals)

    def test_apply_patch_requires_approval_or_staging(self):
        """apply_patch without approval and without staging flag is blocked."""
        res = tool_guard.check_tool_call("apply_patch", args={"fixed_code": "x = 1"}, approved=False)
        self.assertFalse(res["allowed"])
        self.assertEqual(res["decision"], "BLOCK")
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("tool_arg_violation", signals)

        # When approved=True, it passes
        res_approved = tool_guard.check_tool_call("apply_patch", args={"fixed_code": "x = 1"}, approved=True)
        self.assertTrue(res_approved["allowed"])

    def test_scan_bypass_flags_blocked(self):
        """Flags attempting to skip or disable scanning are blocked with policy_override."""
        bypass_args = [
            {"skip_scan": True},
            {"disable_scan": True},
            {"bypass_scan": True},
            {"force": True},
            {"override_policy": True}
        ]
        for b_arg in bypass_args:
            args = {"code": "x = 1"}
            args.update(b_arg)
            res = tool_guard.check_tool_call("run_code", args=args)
            self.assertFalse(res["allowed"])
            self.assertEqual(res["decision"], "BLOCK")
            signals = [s["name"] for s in res["signals"]]
            self.assertIn("policy_override", signals)


if __name__ == "__main__":
    unittest.main()
