"""agent.py - Orchestration Agent for IntelliFix Auto-Correction Pipeline.

Orchestrates existing repair modules (multi_error, error_extractor, nlp_explainer)
using an immutable tool registry (agent_tools.py) and bounded memory (agent_memory.py).
Enforces:
- Strict wall-clock budget (AGENT_MAX_SECONDS, default 40s).
- Attempt clamping (1..5) and step log cap (200 steps).
- Clean stop conditions with explicit reason codes.
- Redaction of code bodies and secrets from step logs.
- Instruction post-filtering ("explain only", "keep my variable names").
- Pre-execution input guard advisory analysis.
"""

import ast
import hashlib
import os
import re
import time
from typing import Any, Dict, List, Optional, Set, Tuple

import agent_memory
import agent_proposals
import agent_tools

DEFAULT_AGENT_MAX_SECONDS = 40.0
MAX_STEPS_LOG_CAP = 200
MAX_SUMMARY_LEN = 160


def get_agent_max_seconds() -> float:
    """Lazily read max wall-clock time limit from environment."""
    val = os.environ.get("AGENT_MAX_SECONDS")
    if val:
        try:
            return max(5.0, float(val))
        except ValueError:
            pass
    return DEFAULT_AGENT_MAX_SECONDS


def _sanitize_summary(text: str) -> str:
    """Ensure step log summary is single-line, <= 160 chars, with no raw code/secrets."""
    clean = " ".join(text.split())
    # Redact potential secret keys
    clean = re.sub(r"AIza[A-Za-z0-9_\-]{20,}", "[REDACTED_GEMINI_KEY]", clean)
    clean = re.sub(r"gsk_[A-Za-z0-9]{20,}", "[REDACTED_GROQ_KEY]", clean)
    if len(clean) > MAX_SUMMARY_LEN:
        clean = clean[:MAX_SUMMARY_LEN - 3] + "..."
    return clean


def _extract_ast_identifiers(code_str: str) -> Set[str]:
    """Extract variable and function identifiers defined in code."""
    try:
        tree = ast.parse(code_str)
        ids = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Param)):
                ids.add(node.id)
            elif isinstance(node, ast.FunctionDef):
                ids.add(node.name)
            elif isinstance(node, ast.ClassDef):
                ids.add(node.name)
        return ids
    except Exception:
        return set()


def _check_variable_names_preserved(orig_code: str, fixed_code: str) -> bool:
    """Verify that patch does not introduce novel variable names (post-filter)."""
    orig_ids = _extract_ast_identifiers(orig_code)
    fixed_ids = _extract_ast_identifiers(fixed_code)
    # Check if any new variable was defined that was not in the original
    new_ids = fixed_ids - orig_ids
    # Allow standard builtin names or common helpers
    allowed_helpers = {"_idx", "_val", "_key", "range", "len", "str", "int", "float", "list", "dict"}
    return len(new_ids - allowed_helpers) == 0


def _guarded_call_tool(tool_name: str, args: Dict[str, Any], approved: bool = False) -> Dict[str, Any]:
    """Wraps agent_tools.call_tool with Shield Gate 2 (Tool Guard) enforcement."""
    try:
        from security.shield import get_shield
        shield_res = get_shield().check_tool(tool_name, args=args, approved=approved)
        if not shield_res.get("allowed", True):
            return {
                "status": "security_blocked",
                "decision": "BLOCK",
                "error": f"Tool call blocked by Shield Gate 2: {'; '.join(shield_res.get('evidence', []))}",
                "shield": shield_res
            }
    except Exception as e:
        return {
            "status": "security_blocked",
            "decision": "BLOCK",
            "error": f"Tool call blocked (Shield Gate 2 failed closed: {str(e)})",
            "shield": {"allowed": False, "error": str(e)}
        }
    return agent_tools.call_tool(tool_name, args)


def repair(
    code: str,
    instruction: Optional[str] = None,
    max_attempts: int = 3,
    filename: Optional[str] = None,
    mode: str = "default",
    _time_fn=time.time
) -> Dict[str, Any]:
    """
    Main entry point for IntelliFix agent loop.

    Orchestrates execution, error extraction, tier repair, security scanning,
    and sandbox verification. Never raises to caller.
    """
    start_time = _time_fn()
    wall_clock_limit = get_agent_max_seconds()

    # Input validation and clamping
    if not isinstance(code, str):
        return {
            "status": "error",
            "attempts": 0,
            "steps": [],
            "proposal": None,
            "tier_counts": {"rules": 0, "gemini": 0, "groq": 0},
            "duration_ms": 0,
            "notes": "Input 'code' must be a string."
        }

    clamped_attempts = max(1, min(5, int(max_attempts)))
    steps: List[Dict[str, Any]] = []
    tier_counts = {"rules": 0, "gemini": 0, "groq": 0}
    current_attempt = 1

    def add_step(kind: str, tool: Optional[str], status: str, summary: str, duration_ms: int = 0) -> None:
        if len(steps) >= MAX_STEPS_LOG_CAP:
            return
        steps.append({
            "n": len(steps) + 1,
            "attempt": current_attempt,
            "kind": kind,
            "tool": tool,
            "status": status,
            "summary": _sanitize_summary(summary),
            "duration_ms": max(0, duration_ms)
        })

    # Guard inspection (Advisory only)
    guard_report = None
    try:
        from security import input_guard
        if instruction and instruction.strip():
            guard_report = input_guard.inspect_text(instruction, channel="user_instruction")
        else:
            guard_report = input_guard.scan_code_channels(code)
    except Exception:
        pass

    # Week 5 AAI Shield Integration (Gate 1: Input Inspection)
    shield_gate1 = None
    try:
        from security.shield import get_shield
        shield = get_shield()
        target_input = instruction if (instruction and instruction.strip()) else code
        input_chan = "user_instruction" if (instruction and instruction.strip()) else "code_content"
        shield_gate1 = shield.inspect_input(target_input, channel=input_chan)
        if not shield_gate1.get("allowed", True):
            add_step("shield", None, "blocked", f"Shield Gate 1 blocked input: {'; '.join(shield_gate1.get('evidence', []))[:120]}")
            return {
                "status": "security_blocked",
                "attempts": 0,
                "steps": steps,
                "proposal": None,
                "tier_counts": tier_counts,
                "duration_ms": int((_time_fn() - start_time) * 1000),
                "notes": f"Blocked by AAI Shield: {'; '.join(shield_gate1.get('evidence', []))}",
                "guard": guard_report,
                "shield": shield_gate1
            }
    except Exception as e:
        add_step("shield", None, "error", f"Shield Gate 1 failed closed: {str(e)[:120]}")
        return {
            "status": "security_error",
            "attempts": 0,
            "steps": steps,
            "proposal": None,
            "tier_counts": tier_counts,
            "duration_ms": int((_time_fn() - start_time) * 1000),
            "notes": f"Security shield inspection error: {str(e)}",
            "guard": guard_report,
            "shield": {"allowed": False, "error": str(e)}
        }

    current_attempt = 1
    current_code = code
    orig_hash = hashlib.sha256(code.encode("utf-8")).hexdigest()
    mem = agent_memory.get_global_memory()

    # Track seen error signatures for no-progress detection
    seen_state_signatures: Set[str] = set()

    # Check for "explain only" instruction intent
    clean_instr = (instruction or "").lower().strip()
    if "explain only" in clean_instr or "explain-only" in clean_instr:
        t0 = _time_fn()
        # Run original code to extract error
        run_res = _guarded_call_tool("run_code", {"code": code, "timeout": 5.0})
        t1 = _time_fn()
        add_step("run", "run_code", run_res.get("status", "ok"), "Executed code in sandbox for explanation", int((t1 - t0)*1000))

        add_step("stop", None, "ok", "Stopped due to 'explain only' instruction", 0)
        return {
            "status": "already_clean" if run_res.get("returncode") == 0 else "no_fix",
            "attempts": 1,
            "steps": steps,
            "proposal": None,
            "tier_counts": tier_counts,
            "duration_ms": int((_time_fn() - start_time) * 1000),
            "notes": "Explain only requested: no fix proposed.",
            "guard": guard_report
        }

    # Main Agent Iteration Loop
    final_status = "gave_up"
    final_proposal = None
    stop_reason = "max_attempts"

    for attempt in range(1, clamped_attempts + 1):
        current_attempt = attempt

        # Check wall-clock budget
        elapsed = _time_fn() - start_time
        if elapsed > wall_clock_limit:
            stop_reason = "wall_clock_budget"
            final_status = "gave_up"
            break

        # 1. RUN: Execute current code in sandbox
        t0 = _time_fn()
        run_res = _guarded_call_tool("run_code", {"code": current_code, "timeout": 5.0})
        t1 = _time_fn()
        run_ms = int((t1 - t0) * 1000)

        # Check for original code timeout on attempt 1
        if attempt == 1 and run_res.get("timed_out"):
            add_step("run", "run_code", "timeout", "Original code timed out in sandbox (infinite loop detected)", run_ms)
            stop_reason = "sandbox_timeout_on_original"
            final_status = "error"
            break

        if run_res.get("status") == "security_blocked":
            add_step("run", "run_code", "security_blocked", "Security scan blocked code execution", run_ms)
            stop_reason = "fix_rejected_by_scan"
            final_status = "error"
            break

        if run_res.get("status") == "sandbox_failure":
            add_step("run", "run_code", "error", f"Sandbox failure: {run_res.get('error', 'unknown')}", run_ms)
            stop_reason = "sandbox_failure"
            final_status = "error"
            break

        # Check if code runs cleanly
        is_clean = (
            run_res.get("status") in ("ok", "success")
            and run_res.get("exit_code", 0) == 0
            and not run_res.get("error")
        )
        if is_clean:
            add_step("run", "run_code", "success", "Code executed cleanly with exit code 0", run_ms)
            if attempt == 1:
                stop_reason = "success"
                final_status = "already_clean"
            else:
                stop_reason = "success"
                final_status = "pending_approval"
            break

        add_step("run", "run_code", "error_detected", f"Sandbox returned non-zero exit code {run_res.get('returncode')}", run_ms)

        # 2. EXTRACT: Analyze errors and construct state signature
        import multi_error
        err_items, cov, _ = multi_error.scan_all_errors(current_code, generate_explanations=False)
        primary_err = err_items[0] if err_items else None
        err_type = primary_err.error_type if primary_err else "RuntimeError"
        err_line = primary_err.line if primary_err else 1
        err_msg = primary_err.message if primary_err else ""

        code_hash = hashlib.sha256(current_code.encode("utf-8")).hexdigest()
        state_sig = f"{code_hash}:{err_type}:{err_line}"

        # No-progress detection: same error signature and same code seen twice
        if state_sig in seen_state_signatures:
            add_step("extract", None, "no_progress", f"Duplicate error signature {err_type} at line {err_line} detected", 0)
            stop_reason = "no_progress"
            final_status = "gave_up"
            break
        seen_state_signatures.add(state_sig)

        add_step("extract", None, "extracted", f"Extracted {err_type} at line {err_line}", 0)

        # 3. PROPOSE: Attempt single round fix using existing pipeline
        t0 = _time_fn()
        fix_res = multi_error.fix_all_errors(current_code, max_rounds=1)
        t1 = _time_fn()
        prop_ms = int((t1 - t0) * 1000)

        cand_code = fix_res.get("fixed_code")
        fix_status = fix_res.get("fix_status", "")
        fix_source = fix_res.get("fix_source", "none")
        fix_steps = fix_res.get("fix_steps", [])

        # No fix could be found by existing tiers
        if not cand_code or cand_code == current_code:
            add_step("propose", None, "no_fix", f"No fix found by repair pipeline for {err_type}", prop_ms)
            stop_reason = "no_alternative_fix"
            final_status = "no_fix"
            break

        cand_hash = hashlib.sha256(cand_code.encode("utf-8")).hexdigest()

        # Check memory to prevent repeating rejected or tried fixes
        if mem.has_tried(orig_hash, cand_hash):
            add_step("propose", None, "duplicate", f"Fix {cand_hash[:8]} already tried in memory", prop_ms)
            stop_reason = "no_alternative_fix"
            final_status = "gave_up"
            break

        # Record attempt in memory
        mem.record_attempt(orig_hash, cand_hash, err_type)

        tier_name = "rules"
        if fix_source == "ai" or "ai" in fix_res.get("fix_providers", []):
            tier_name = "gemini" if "gemini" in fix_res.get("fix_providers", []) else "groq"
        tier_counts[tier_name] = tier_counts.get(tier_name, 0) + 1

        step_summary = f"Proposed {tier_name} fix ({fix_steps[0] if fix_steps else err_type})"
        add_step("propose", None, "proposed", step_summary, prop_ms)

        # Post-filter: "keep my variable names"
        if "keep my variable names" in clean_instr or "preserve variable names" in clean_instr:
            if not _check_variable_names_preserved(current_code, cand_code):
                mem.record_rejected(orig_hash, cand_hash)
                add_step("propose", None, "rejected", "Patch violated 'keep my variable names' post-filter", 0)
                stop_reason = "fix_rejected_by_scan"
                final_status = "gave_up"
                break

        # 4. SCAN: Run security scan on candidate patch
        t0 = _time_fn()
        scan_res = _guarded_call_tool("scan_security", {"code": cand_code})
        t1 = _time_fn()
        scan_ms = int((t1 - t0) * 1000)

        if not scan_res.get("allowed", True):
            mem.record_rejected(orig_hash, cand_hash)
            add_step("scan", "scan_security", "rejected", f"Patch rejected by scanner: {', '.join(scan_res.get('reasons', []))}", scan_ms)
            stop_reason = "fix_rejected_by_scan"
            final_status = "gave_up"
            break

        add_step("scan", "scan_security", "clean", f"Security scan passed ({scan_res.get('findings_count', 0)} warnings)", scan_ms)

        # 5. VERIFY: Sandboxed verification of the patch
        t0 = _time_fn()
        verif_res = _guarded_call_tool("run_code", {"code": cand_code, "timeout": 5.0})
        t1 = _time_fn()
        verif_ms = int((t1 - t0) * 1000)

        verif_clean = (
            verif_res.get("status") in ("ok", "success")
            and verif_res.get("exit_code", 0) == 0
            and not verif_res.get("error")
        )
        if verif_clean:
            add_step("verify", "run_code", "verified", "Candidate patch verified cleanly in sandbox", verif_ms)

            # Week 5 AAI Shield Integration (Gate 3: Healed Code Inspection)
            try:
                from security.shield import get_shield
                shield_gate3 = get_shield().inspect_healed_code(code, cand_code)
                if not shield_gate3.get("allowed", True):
                    add_step("shield", None, "blocked", f"Shield Gate 3 blocked healed code: {'; '.join(shield_gate3.get('evidence', []))[:120]}")
                    mem.record_rejected(orig_hash, cand_hash)
                    stop_reason = "fix_rejected_by_scan"
                    final_status = "gave_up"
                    break
            except Exception:
                pass

            # Create in-memory proposal for human approval (Feature 8)
            prop_res = _guarded_call_tool("apply_patch", {
                "original_code": code,
                "fixed_code": cand_code,
                "original_hash": orig_hash,
                "filename": filename,
                "tier": tier_name,
                "findings": scan_res.get("findings", [])
            }, approved=True)

            prop_id = prop_res.get("proposal_id", "")
            prop_id_str = str(prop_id)[:8] if prop_id else "unknown"
            add_step("await_approval", "apply_patch", "pending", f"Created proposal {prop_id_str} awaiting approval", 0)
            final_proposal = {
                "id": prop_res.get("proposal_id"),
                "diff": prop_res.get("diff"),
                "original_hash": orig_hash,
                "fixed_code_hash": cand_hash,
                "tier": tier_name,
                "fixed_code": cand_code
            }
            final_status = "pending_approval"
            stop_reason = "success"
            break
        else:
            add_step("verify", "run_code", "partial", "Patch reduced errors but code did not run cleanly yet", verif_ms)
            current_code = cand_code

    # Record final stop condition
    add_step("stop", None, "stopped", f"Agent stopped with reason: {stop_reason}", 0)

    total_duration_ms = int((_time_fn() - start_time) * 1000)

    ret_dict = {
        "status": final_status,
        "attempts": current_attempt,
        "steps": steps,
        "proposal": final_proposal,
        "tier_counts": tier_counts,
        "duration_ms": total_duration_ms,
        "notes": f"Completed with stop reason '{stop_reason}'.",
        "guard": guard_report
    }

    # Week 5 AAI Shield Integration (Gate 4: Output Redaction)
    try:
        from security.shield import get_shield
        ret_dict, _ = get_shield().sanitize_output(ret_dict)
    except Exception as e:
        add_step("shield", None, "warn", f"Shield Gate 4 output sanitization warning: {str(e)[:120]}")

    return ret_dict
