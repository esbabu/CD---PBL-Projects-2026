"""tests_quality_metrics.py – Unit tests for Poor Code Metrics & AST Optimizer.

Tests:
1. Static code quality analysis (clean vs unoptimized/poor code).
2. Big-O time and space complexity estimation (O(1), O(N), O(N^2)).
3. Anti-pattern and code smell detection (range(len), in-loop search, += string in loop).
4. Behavior-preserving code optimization and AST refactoring.
5. REST API endpoints (/api/quality/metrics, /api/optimize).
6. Integration with /api/analyze (automatic quality_metrics in response).
7. UI template DOM elements verification (panel-quality, comparison chart, optimizer controls).
"""

import ast
import json
import os
import unittest
from unittest.mock import patch
from app import app
import code_quality


class TestQualityMetrics(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_01_clean_code_metrics(self):
        """Clean, idiomatic code should score high with minimal complexity."""
        clean_code = '''def greet(name: str) -> str:
    """Return greeting string."""
    return f"Hello, {name}!"
'''
        res = code_quality.analyze_code_quality(clean_code)
        self.assertGreaterEqual(res["quality_score"], 80.0)
        self.assertIn(res["rating"], ["A", "B"])
        self.assertEqual(res["cyclomatic_complexity"], 1)
        self.assertEqual(res["time_complexity"], "O(1)")
        self.assertEqual(res["smell_count"], 0)

    def test_02_poor_code_metrics_detection(self):
        """Unoptimized code with nested loops, linear search in loop, and range(len) should be penalized."""
        poor_code = '''def process_items(arr, targets):
    result = ""
    for i in range(len(arr)):
        if arr[i] == True:
            pass
        for j in range(len(targets)):
            if targets[j] in arr:
                result += str(arr[i])
    return result
'''
        res = code_quality.analyze_code_quality(poor_code)
        self.assertLess(res["quality_score"], 70.0)
        self.assertIn(res["rating"], ["C", "D", "F"])
        self.assertEqual(res["time_complexity"], "O(N²)")
        self.assertGreater(res["smell_count"], 0)
        
        # Verify detected smells
        smell_titles = [s["title"] for s in res["smells"]]
        self.assertTrue(any("range(len" in t for t in smell_titles))
        self.assertTrue(any("Membership Lookup" in t for t in smell_titles))
        self.assertTrue(any("String Concatenation" in t for t in smell_titles))

    def test_03_code_optimization_execution(self):
        """Optimizer refactors code, generates valid AST, and improves code metrics."""
        poor_code = '''def process_items(arr, targets):
    result = ""
    for i in range(len(arr)):
        if arr[i] == True:
            pass
        for j in range(len(targets)):
            if targets[j] in arr:
                result += str(arr[i])
    return result
'''
        opt_res = code_quality.optimize_code(poor_code)
        self.assertEqual(opt_res["status"], "success")
        self.assertIn("optimized_code", opt_res)
        
        # Ensure optimized code is syntactically valid Python
        ast.parse(opt_res["optimized_code"])
        
        # Ensure improvements are tracked
        im = opt_res["improvements"]
        self.assertIn("quality_delta", im)
        self.assertIn("optimizations_applied", opt_res)
        self.assertGreater(len(opt_res["optimizations_applied"]), 0)
        
        # Check chart data schema for graphs
        chart_data = opt_res["chart_data"]
        self.assertIn("labels", chart_data)
        self.assertIn("datasets", chart_data)
        self.assertEqual(len(chart_data["datasets"]), 2)
        self.assertEqual(chart_data["datasets"][0]["label"], "Original Input Code")
        self.assertEqual(chart_data["datasets"][1]["label"], "Optimized Code")

    def test_04_api_quality_metrics_endpoint(self):
        """POST /api/quality/metrics returns 200 with code quality schema."""
        resp = self.app.post("/api/quality/metrics", json={
            "code": "def square(x):\n    return x * x\n"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("metrics", data)
        self.assertIn("quality_score", data["metrics"])
        self.assertIn("readability_score", data["metrics"])
        self.assertIn("optimality_score", data["metrics"])

    def test_05_api_optimize_endpoint(self):
        """POST /api/optimize returns 200 with optimized_code, comparison, and chart_data."""
        resp = self.app.post("/api/optimize", json={
            "code": "def count_positives(numbers):\n    c = 0\n    for i in range(len(numbers)):\n        if numbers[i] > 0:\n            c = c + 1\n    return c\n"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("optimized_code", data)
        self.assertIn("before_metrics", data)
        self.assertIn("after_metrics", data)
        self.assertIn("chart_data", data)
        self.assertIn("optimizations_applied", data)

    def test_06_analyze_includes_quality_metrics(self):
        """POST /api/analyze automatically includes quality_metrics in the response."""
        resp = self.app.post("/api/analyze", json={
            "code": "x = 42\nprint(x)\n"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("quality_metrics", data)
        self.assertIn("quality_score", data["quality_metrics"])

    def test_07_ui_template_dom_elements(self):
        """Verify templates/index.html contains all Poor Code Metrics & Optimizer DOM elements."""
        template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        required_elements = [
            'id="panel-quality"',
            'id="btn-open-quality"',
            'id="btn-optimize-code"',
            'id="quality-rating-badge"',
            'id="qm-quality-score"',
            'id="qm-readability"',
            'id="qm-optimality"',
            'id="qm-complexity"',
            'id="qm-time-complexity"',
            'id="qm-smells-list"',
            'id="quality-before-view"',
            'id="quality-after-view"',
            'id="quality-comparison-chart"',
            'id="qm-delta-quality"',
            'id="qm-applied-list"',
            'id="btn-revert-optimization"'
        ]
        for el in required_elements:
            self.assertIn(el, html, f"Missing required element in index.html: {el}")

    def test_08_verification_layer_api_endpoint(self):
        """POST /api/verify performs multi-gate verification using existing project APIs."""
        resp = self.app.post("/api/verify", json={
            "original_code": "def run():\n    print('Hello World')\nrun()\n",
            "optimized_code": "def run():\n    '''Documented run.'''\n    print('Hello World')\nrun()\n"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("verification", data)
        v = data["verification"]
        self.assertTrue(v["verified"])
        self.assertIn("gates", v)
        self.assertIn("pda_bracket", v["gates"])
        self.assertIn("security_scan", v["gates"])
        self.assertIn("input_guard", v["gates"])
        self.assertIn("sandbox_execution", v["gates"])
        self.assertIn("equivalence", v["gates"])
        self.assertTrue(v["gates"]["pda_bracket"]["passed"])
        self.assertTrue(v["gates"]["security_scan"]["passed"])
        self.assertTrue(v["gates"]["sandbox_execution"]["passed"])

    def test_09_verification_in_optimize_response(self):
        """POST /api/optimize automatically includes multi-gate verification results."""
        resp = self.app.post("/api/optimize", json={
            "code": "def compute():\n    nums = [1, 2, 3]\n    return sum(nums)\n"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("verification", data)
        self.assertIn("verdict", data["verification"])
        self.assertTrue(data["verification"]["verified"])

    def test_10_verification_dom_elements(self):
        """Verify templates/index.html contains Verification Layer DOM elements."""
        template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        verify_elements = [
            'id="btn-verify-code"',
            'id="qm-verification-card"',
            'id="qm-verify-status-badge"',
            'id="qm-gate-pda"',
            'id="qm-gate-sec"',
            'id="qm-gate-guard"',
            'id="qm-gate-sandbox"',
            'id="qm-gate-equiv"'
        ]
        for el in verify_elements:
            self.assertIn(el, html, f"Missing verification element in index.html: {el}")

    def test_11_verify_with_ai_offline_fallback(self):
        """When LLM is disabled or keys omitted, verify_with_ai falls back to offline AST validation."""
        orig = "def add(a, b):\n    return a + b\n"
        opt = "def add(a, b):\n    '''Docstring.'''\n    return a + b\n"
        with patch.dict(os.environ, {"LLM_DISABLED": "1", "GEMINI_API_KEY": "", "GROQ_API_KEY": ""}):
            res = code_quality.verify_with_ai(orig, opt)
            self.assertTrue(res["passed"])
            self.assertEqual(res["status"], "offline_fallback")
            self.assertEqual(res["consensus"], "OFFLINE_VERIFIED")
            self.assertIn("gemini", res)
            self.assertIn("groq", res)
            self.assertFalse(res["gemini"]["available"])
            self.assertFalse(res["groq"]["available"])

    def test_12_verify_with_ai_mocked_gemini_and_groq(self):
        """When Gemini and Groq return valid PASS json, AI verification layer yields unanimous PASS."""
        orig = "def find_max(items):\n    m = items[0]\n    for i in range(len(items)):\n        if items[i] > m:\n            m = items[i]\n    return m\n"
        opt = "def find_max(items):\n    m = items[0]\n    for item in items:\n        if item > m:\n            m = item\n    return m\n"
        
        gemini_json = json.dumps({
            "equivalent": True,
            "verdict": "PASS",
            "confidence": 98,
            "summary": "Equivalent functional logic with improved loop iteration",
            "semantic_analysis": "Variable m tracks maximum correctly; range(len) replaced with direct iteration."
        })
        groq_json = json.dumps({
            "equivalent": True,
            "verdict": "PASS",
            "confidence": 96,
            "summary": "Verified loop invariant and boundary behavior",
            "semantic_analysis": "No mutations to input; return value identical."
        })

        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "fake_groq", "LLM_DISABLED": "0"}), \
             patch("llm_calls.call_gemini", return_value=(gemini_json, None, False)), \
             patch("llm_calls.call_groq", return_value=(groq_json, None, False)):
            
            res = code_quality.verify_with_ai(orig, opt)
            self.assertTrue(res["passed"])
            self.assertEqual(res["consensus"], "PASS")
            self.assertEqual(res["confidence"], 97)
            self.assertEqual(res["gemini"]["verdict"], "PASS")
            self.assertEqual(res["groq"]["verdict"], "PASS")
            self.assertIn("Gemini + Groq", res["detail"])

    def test_13_verify_with_ai_detects_semantic_failure(self):
        """When an AI model flags a regression or divergence, consensus drops to FAIL."""
        orig = "def calc(x):\n    return x * 2\n"
        broken_opt = "def calc(x):\n    return x + 2\n"

        gemini_json = json.dumps({
            "equivalent": False,
            "verdict": "FAIL",
            "confidence": 99,
            "summary": "Semantic mismatch: multiplication replaced by addition",
            "semantic_analysis": "For x=3, original returns 6, optimized returns 5."
        })

        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "", "LLM_DISABLED": "0"}), \
             patch("llm_calls.call_gemini", return_value=(gemini_json, None, False)):

            res = code_quality.verify_with_ai(orig, broken_opt)
            self.assertFalse(res["passed"])
            self.assertEqual(res["consensus"], "FAIL")
            self.assertIn("semantic regressions", res["detail"].lower())

    def test_14_api_verify_ai_endpoint(self):
        """POST /api/verify/ai returns status success with dual-model verification report."""
        resp = self.app.post("/api/verify/ai", json={
            "original_code": "def mul(a, b):\n    return a * b\n",
            "optimized_code": "def mul(a, b):\n    '''Fast multiplication.'''\n    return a * b\n"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("ai_verification", data)
        self.assertIn("gemini", data["ai_verification"])
        self.assertIn("groq", data["ai_verification"])

    def test_15_ai_verification_dom_elements(self):
        """Verify templates/index.html contains Gemini & Groq Neural Verification DOM elements."""
        template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        ai_elements = [
            'id="qm-gate-ai"',
            'id="btn-run-ai-verify"',
            'id="qm-gemini-verdict"',
            'id="qm-gemini-status"',
            'id="qm-groq-verdict"',
            'id="qm-groq-status"'
        ]
        for el in ai_elements:
            self.assertIn(el, html, f"Missing AI verification element in index.html: {el}")

    def test_16_1000_loc_analysis_speed_and_metrics(self):
        """Verify static AST analysis evaluates a 1,000-line Python module cleanly and rapidly."""
        import time
        chunks = ['# 1000 LOC Benchmark Module\nimport math\n\n']
        for i in range(1, 260):
            chunks.append(f'def util_func_{i}(x, y):\n    """Utility function {i}."""\n    return x * 2 + y + {i}\n')
        code_1000 = "\n".join(chunks)
        total_lines = len(code_1000.splitlines())
        self.assertGreaterEqual(total_lines, 1000)

        t0 = time.monotonic()
        metrics = code_quality.analyze_code_quality(code_1000)
        dur_ms = (time.monotonic() - t0) * 1000

        self.assertLess(dur_ms, 300)  # Sub-300ms parsing on 1000 lines
        self.assertGreaterEqual(metrics["quality_score"], 80.0)
        self.assertEqual(metrics["loc"]["total"], total_lines)
        self.assertEqual(metrics["cyclomatic_complexity"], 1)

    def test_17_1000_loc_surgical_chunked_optimization(self):
        """Verify AST chunking optimizes specific unoptimized functions in a 1,000-line module without mutating surrounding code."""
        chunks = ['# 1000 LOC Surgical Optimization Test\nimport math\n\n']
        for i in range(1, 260):
            if i == 50:
                chunks.append('def unoptimized_filter(arr):\n    res = ""\n    for i in range(len(arr)):\n        if arr[i] == True:\n            pass\n    return res\n')
            elif i == 150:
                chunks.append('def slow_lookup(arr, targets):\n    result = ""\n    for i in range(len(arr)):\n        for j in range(len(targets)):\n            if targets[j] in arr:\n                result += str(arr[i])\n    return result\n')
            else:
                chunks.append(f'def stable_worker_{i}(n: int) -> int:\n    """Worker {i}."""\n    return n * {i}\n')
        code_1000 = "\n".join(chunks)
        self.assertGreaterEqual(len(code_1000.splitlines()), 1000)

        opt_res = code_quality.optimize_code(code_1000)
        self.assertEqual(opt_res["status"], "success")
        opt_code = opt_res["optimized_code"]

        # Ensure valid syntax
        ast.parse(opt_code)

        # Total lines should remain ~1000
        self.assertGreaterEqual(len(opt_code.splitlines()), 1000)

        # Verify unoptimized functions were refactored
        self.assertIn("enumerate", opt_code)
        self.assertNotIn("for i in range(len(arr)):", opt_code)

        # Verify surrounding functions are preserved intact
        self.assertIn("def stable_worker_1(n: int) -> int:", opt_code)
        self.assertIn("def stable_worker_200(n: int) -> int:", opt_code)
        self.assertGreater(len(opt_res["optimizations_applied"]), 0)

    def test_18_1000_loc_ai_verification_diff_contract(self):
        """Verify AI verification on 1,000-line files constructs a compact unified diff contract rather than monolithic dumps."""
        chunks = ['# 1000 LOC Diff Contract Verification\nimport math\n\n']
        for i in range(1, 201):
            chunks.append(f'def comp_func_{i}(x):\n    """Doc {i}."""\n    return x + {i}\n')
        orig_1000 = "\n".join(chunks)
        
        # Modify only one function
        opt_1000 = orig_1000.replace('return x + 50', 'return x + 50 # optimized constant')

        mock_reply = json.dumps({
            "equivalent": True,
            "verdict": "PASS",
            "confidence": 98,
            "summary": "Diff verified: comment annotation preserves exact semantics.",
            "semantic_analysis": "Return value invariant identical."
        })

        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "fake_groq", "LLM_DISABLED": "0"}), \
             patch("llm_calls.call_gemini") as mock_gemini, \
             patch("llm_calls.call_groq") as mock_groq:
            
            mock_gemini.return_value = (mock_reply, None, False)
            mock_groq.return_value = (mock_reply, None, False)

            res = code_quality.verify_with_ai(orig_1000, opt_1000)
            self.assertTrue(res["passed"])
            self.assertEqual(res["consensus"], "PASS")

            # Verify that the prompt sent to Gemini/Groq contained UNIFIED CODE DIFF and not 1000 lines of raw code
            call_kwargs = mock_gemini.call_args[1]
            prompt_sent = call_kwargs["prompt"]
            self.assertIn("UNIFIED CODE DIFF", prompt_sent)
            self.assertIn("--- original.py", prompt_sent)
            self.assertIn("+++ optimized.py", prompt_sent)
            # The prompt length should be extremely compact (< 2,500 chars) instead of 50,000 chars!
            self.assertLess(len(prompt_sent), 3000)

    def test_19_array_mutation_not_corrupted(self):
        """Verify optimizer preserves in-place list mutation without rewriting arr[i] = ... to item = ..."""
        code = '''def double_items(arr):
    for i in range(len(arr)):
        arr[i] = arr[i] * 2
    return arr
'''
        opt_res = code_quality.optimize_code(code)
        opt_code = opt_res["optimized_code"]
        scope = {}
        exec(opt_code, scope)
        res = scope["double_items"]([1, 2, 3])
        self.assertEqual(res, [2, 4, 6])

    def test_20_boolean_precedence_and_multiple_comparisons(self):
        """Verify AST optimizer preserves boolean precedence and simplifies multiple booleans."""
        code = '''def check_flag(flag1, flag2):
    if flag1 and flag2 == False:
        return True
    return False

def check_multi(a, b):
    if a == True and b == True:
        return 1
    return 0
'''
        opt_res = code_quality.optimize_code(code)
        opt_code = opt_res["optimized_code"]
        scope = {}
        exec(opt_code, scope)
        # Original: flag1=False, flag2=True -> False
        self.assertFalse(scope["check_flag"](False, True))
        # Original: flag1=True, flag2=False -> True
        self.assertTrue(scope["check_flag"](True, False))
        # Both true:
        self.assertEqual(scope["check_multi"](True, True), 1)

    def test_21_string_concat_intermediate_access_safe(self):
        """Verify string concat optimization scopes ''.join() right after loop without NameError or UnboundLocalError."""
        code = '''def check_nested(items):
    res = ""
    for x in items:
        res += str(x)
    if len(items) > 0:
        return res
    return "empty"
'''
        opt_res = code_quality.optimize_code(code)
        opt_code = opt_res["optimized_code"]
        scope = {}
        exec(opt_code, scope)
        self.assertEqual(scope["check_nested"]([1, 2]), "12")
        self.assertEqual(scope["check_nested"]([]), "empty")

    def test_22_class_method_chunked_optimization(self):
        """Verify class methods can be chunk-optimized without indentation errors."""
        class_code = '''class Processor:
    def process(self, arr, targets):
        res = ""
        for i in range(len(arr)):
            if arr[i] == True:
                pass
            for j in range(len(targets)):
                if targets[j] in arr:
                    res += str(arr[i])
        return res
'''
        opt_code, applied = code_quality.chunked_optimize_code(class_code)
        scope = {}
        exec(opt_code, scope)
        inst = scope["Processor"]()
        out = inst.process([True, False], [True, "other"])
        self.assertEqual(out, "TrueFalse")

    def test_23_verification_fails_on_crashing_code(self):
        """Verify that code raising a runtime error in sandbox fails verification."""
        orig = "def foo():\n    return 42\nfoo()\n"
        broken = "def foo():\n    raise RuntimeError('boom')\nfoo()\n"
        res = code_quality.verify_code_optimization(orig, broken, run_ai=False)
        self.assertFalse(res["verified"])
        self.assertEqual(res["verdict"], "VERIFIED_WITH_WARNINGS")
        self.assertFalse(res["gates"]["sandbox_execution"]["passed"])
        self.assertFalse(res["gates"]["equivalence"]["passed"])

    def test_24_api_fallback_triggered_when_rules_insufficient(self):
        """Verify AI API fallback is triggered when deterministic AST rules cannot optimize code."""
        code = '''def compute_sum(n):
    total = 0
    i = 0
    while i <= n:
        total = total + i
        i = i + 1
    return total
'''
        mock_ai_code = '''def compute_sum(n: int) -> int:
    """Optimized constant time arithmetic series formula."""
    return (n * (n + 1)) // 2
'''
        mock_llm_reply = f"```python\n{mock_ai_code}\n```"
        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "", "LLM_DISABLED": "0", "AUTOFIX_AI": "1"}), \
             patch("llm_calls.call_gemini", return_value=(mock_llm_reply, None, False)):

            res = code_quality.optimize_code(code)
            self.assertEqual(res["status"], "success")
            self.assertIn("compute_sum", res["optimized_code"])
            self.assertTrue(any("AI Algorithmic Optimization (Gemini)" in a for a in res["optimizations_applied"]))

    def test_25_api_fallback_discarded_if_syntax_invalid(self):
        """Verify AI candidate is discarded safely if the LLM output fails syntax or sandbox check."""
        code = '''def compute(x):
    return x + 1
'''
        mock_bad_reply = "```python\ndef compute(x:\n    invalid syntax here\n```"
        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "", "LLM_DISABLED": "0", "AUTOFIX_AI": "1"}), \
             patch("llm_calls.call_gemini", return_value=(mock_bad_reply, None, False)):

            res = code_quality.optimize_code(code)
            self.assertEqual(res["status"], "success")
            # Should have fallen back to deterministic code safely
            ast.parse(res["optimized_code"])
            self.assertFalse(any("AI Algorithmic Optimization" in a for a in res["optimizations_applied"]))

    def test_26_api_fallback_provider_failover(self):
        """Verify fallback fails over from Gemini to Groq if Gemini returns an error or quota failure."""
        code = '''def slow_func(n):
    res = 0
    while n > 0:
        res += n
        n -= 1
    return res
'''
        mock_groq_code = '''def slow_func(n: int) -> int:
    """Fast linear closed form."""
    return (n * (n + 1)) // 2
'''
        mock_groq_reply = f"```python\n{mock_groq_code}\n```"
        with patch.dict(os.environ, {"GEMINI_API_KEY": "fake_gemini", "GROQ_API_KEY": "fake_groq", "LLM_DISABLED": "0", "AUTOFIX_AI": "1"}), \
             patch("llm_calls.call_gemini", return_value=(None, "429 Quota Exceeded", True)), \
             patch("llm_calls.call_groq", return_value=(mock_groq_reply, None, False)):

            res = code_quality.optimize_code(code)
            self.assertEqual(res["status"], "success")
            self.assertTrue(any("AI Algorithmic Optimization (Groq)" in a for a in res["optimizations_applied"]))


if __name__ == "__main__":
    unittest.main()
