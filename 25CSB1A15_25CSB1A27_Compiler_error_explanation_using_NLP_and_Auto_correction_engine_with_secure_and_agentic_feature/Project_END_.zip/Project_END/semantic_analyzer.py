"""semantic_analyzer.py - Semantic Analysis and Symbol Table Engine for IntelliFix.

Implements lexical scope resolution, hierarchical symbol tables, type checking,
undefined variable detection, redeclared variable tracking, and use-before-assignment
(UnboundLocalError) diagnostics.

Also powers grounded "Did you mean...?" suggestions by pulling candidates directly
from visible symbols across local, enclosing, and global scopes.
"""

import ast
import builtins
import difflib
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List, Optional, Set, Tuple


class ScopeType(Enum):
    GLOBAL = "global"
    FUNCTION = "function"
    CLASS = "class"
    COMPREHENSION = "comprehension"
    BLOCK = "block"


@dataclass
class SymbolRecord:
    """A record in the symbol table representing an identifier."""
    name: str
    inferred_type: str = "Any"
    declared_line: int = 0
    declared_col: int = 0
    scope_id: int = 0
    scope_name: str = "<global>"
    scope_level: int = 0
    is_parameter: bool = False
    is_assigned: bool = False
    is_redeclared: bool = False
    is_constant: bool = False
    reads: List[Tuple[int, int]] = field(default_factory=list)
    writes: List[Tuple[int, int]] = field(default_factory=list)
    value_repr: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "inferred_type": self.inferred_type,
            "declared_line": self.declared_line,
            "declared_col": self.declared_col,
            "scope_id": self.scope_id,
            "scope_name": self.scope_name,
            "scope_level": self.scope_level,
            "is_parameter": self.is_parameter,
            "is_assigned": self.is_assigned,
            "is_redeclared": self.is_redeclared,
            "is_constant": self.is_constant,
            "read_count": len(self.reads),
            "write_count": len(self.writes),
            "reads": self.reads,
            "writes": self.writes,
            "value_repr": self.value_repr,
        }


class Scope:
    """A lexical scope in the program's scope hierarchy."""

    def __init__(self, scope_id: int, name: str, scope_type: ScopeType, parent: Optional["Scope"] = None):
        self.scope_id = scope_id
        self.name = name
        self.scope_type = scope_type
        self.parent = parent
        self.children: List["Scope"] = []
        self.symbols: Dict[str, SymbolRecord] = {}
        self.level: int = (parent.level + 1) if parent else 0
        self.line_start: int = 0
        self.line_end: int = 0
        self.nonlocals: Set[str] = set()
        self.globals: Set[str] = set()
        self.params: List[str] = []
        # Function signature metadata if this is a function scope
        self.func_args: Dict[str, Any] = {}

        if parent:
            parent.children.append(self)

    def define(self, name: str, symbol: SymbolRecord) -> None:
        """Adds or updates a symbol in this scope."""
        self.symbols[name] = symbol

    def lookup(self, name: str, current_only: bool = False) -> Optional[SymbolRecord]:
        """Looks up a symbol in this scope, and if not current_only, in parent scopes."""
        if name in self.symbols:
            return self.symbols[name]
        if not current_only and self.parent:
            return self.parent.lookup(name, current_only=False)
        return None

    def get_all_visible_symbols(self) -> Dict[str, SymbolRecord]:
        """Returns a dict of all symbols visible from this scope (inner shadowing outer)."""
        visible = {}
        if self.parent:
            visible.update(self.parent.get_all_visible_symbols())
        visible.update(self.symbols)
        return visible

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scope_id": self.scope_id,
            "name": self.name,
            "type": self.scope_type.value,
            "level": self.level,
            "parent_id": self.parent.scope_id if self.parent else None,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "symbols": {k: v.to_dict() for k, v in self.symbols.items()},
            "children_ids": [c.scope_id for c in self.children],
        }


# Standard Python built-in names
BUILTIN_NAMES = set(dir(builtins))


def _infer_literal_type(node: ast.AST) -> str:
    """Infers the primitive type of an AST expression node if statically decidable."""
    if isinstance(node, ast.Constant):
        val = node.value
        if val is None:
            return "None"
        elif isinstance(val, bool):
            return "bool"
        elif isinstance(val, int):
            return "int"
        elif isinstance(val, float):
            return "float"
        elif isinstance(val, str):
            return "str"
        elif isinstance(val, bytes):
            return "bytes"
        return type(val).__name__
    elif isinstance(node, ast.List):
        return "list"
    elif isinstance(node, ast.Dict):
        return "dict"
    elif isinstance(node, ast.Set):
        return "set"
    elif isinstance(node, ast.Tuple):
        return "tuple"
    elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
        if isinstance(node, ast.ListComp):
            return "list"
        elif isinstance(node, ast.SetComp):
            return "set"
        elif isinstance(node, ast.DictComp):
            return "dict"
        return "generator"
    elif isinstance(node, ast.Lambda):
        return "callable"
    elif isinstance(node, ast.Call):
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            if func_name in ("int", "round", "len", "abs", "sum", "ord"):
                return "int"
            elif func_name in ("float", "pow"):
                return "float"
            elif func_name in ("str", "repr", "chr", "input", "format"):
                return "str"
            elif func_name in ("bool", "isinstance", "issubclass", "hasattr"):
                return "bool"
            elif func_name in ("list", "sorted"):
                return "list"
            elif func_name in ("dict",):
                return "dict"
            elif func_name in ("set",):
                return "set"
            elif func_name in ("tuple",):
                return "tuple"
    return "Any"


class SemanticAnalyzer(ast.NodeVisitor):
    """AST Visitor that builds a scope tree, populates the symbol table,

    and performs semantic verification.
    """

    def __init__(self, code: str):
        self.code = code
        self.lines = code.splitlines()
        self.next_scope_id = 0
        self.global_scope = Scope(self._alloc_scope_id(), "<global>", ScopeType.GLOBAL)
        self.current_scope: Scope = self.global_scope
        self.all_scopes: List[Scope] = [self.global_scope]

        # Diagnostic findings
        self.undefined_variables: List[Dict[str, Any]] = []
        self.redeclared_variables: List[Dict[str, Any]] = []
        self.use_before_assignment: List[Dict[str, Any]] = []
        self.type_mismatches: List[Dict[str, Any]] = []
        self.warnings: List[Dict[str, Any]] = []

        # Tracking for use-before-assignment inside each function
        # function_scope_id -> set of names assigned anywhere in that function
        self._func_local_assigns: Dict[int, Set[str]] = {}
        # function_scope_id -> dict of name -> line where first assigned
        self._func_first_assign_line: Dict[int, Dict[str, int]] = {}
        # Imported modules and symbols
        self.imported_symbols: Set[str] = set()
        # Function definitions metadata: name -> {args_count, defaults_count, has_varargs, has_kwargs, line}
        self.function_signatures: Dict[str, Dict[str, Any]] = {}

    def _alloc_scope_id(self) -> int:
        sid = self.next_scope_id
        self.next_scope_id += 1
        return sid

    def _push_scope(self, name: str, scope_type: ScopeType, line_start: int = 0) -> Scope:
        new_scope = Scope(self._alloc_scope_id(), name, scope_type, parent=self.current_scope)
        new_scope.line_start = line_start
        self.current_scope = new_scope
        self.all_scopes.append(new_scope)
        return new_scope

    def _pop_scope(self, line_end: int = 0) -> Scope:
        popped = self.current_scope
        popped.line_end = line_end
        if popped.parent:
            self.current_scope = popped.parent
        return popped

    def analyze(self) -> Dict[str, Any]:
        """Runs the semantic analyzer on the AST and returns structured findings."""
        try:
            tree = ast.parse(self.code)
        except SyntaxError as e:
            return {
                "success": False,
                "syntax_error": {
                    "line": e.lineno,
                    "column": e.offset,
                    "message": str(e.msg)
                },
                "symbol_table": [],
                "scopes": [],
                "undefined_variables": [],
                "redeclared_variables": [],
                "use_before_assignment": [],
                "type_mismatches": [],
                "summary": {"total_symbols": 0, "scope_depth": 0, "issues_count": 1}
            }

        # Pre-pass: scan for imports, function signatures, and function-level local assignments
        self._pre_pass(tree)

        # Main traversal: build symbol table and detect semantic violations
        self.visit(tree)

        # Wrap up global scope line span
        self.global_scope.line_start = 1
        self.global_scope.line_end = len(self.lines) if self.lines else 1

        # Flatten symbol table records
        flat_symbols: List[Dict[str, Any]] = []
        for sc in self.all_scopes:
            for sym in sc.symbols.values():
                flat_symbols.append(sym.to_dict())

        total_issues = (
            len(self.undefined_variables)
            + len(self.redeclared_variables)
            + len(self.use_before_assignment)
            + len(self.type_mismatches)
        )

        max_depth = max((sc.level for sc in self.all_scopes), default=0)

        return {
            "success": True,
            "scopes": [sc.to_dict() for sc in self.all_scopes],
            "symbol_table": flat_symbols,
            "undefined_variables": self.undefined_variables,
            "redeclared_variables": self.redeclared_variables,
            "use_before_assignment": self.use_before_assignment,
            "type_mismatches": self.type_mismatches,
            "warnings": self.warnings,
            "summary": {
                "total_symbols": len(flat_symbols),
                "scope_depth": max_depth,
                "scope_count": len(self.all_scopes),
                "issues_count": total_issues,
                "clean": total_issues == 0
            }
        }

    def _pre_pass(self, tree: ast.AST) -> None:
        """Pre-scans AST to collect imports and identify local assignments per function."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname or alias.name
                    self.imported_symbols.add(name.split(".")[0])
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    name = alias.asname or alias.name
                    self.imported_symbols.add(name)

        # For each function, pre-collect all target names that are assigned in its body
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                local_names: Set[str] = set()
                first_lines: Dict[str, int] = {}
                # Add parameters as already defined at the function start
                for arg in node.args.args:
                    local_names.add(arg.arg)
                    first_lines[arg.arg] = getattr(node, "lineno", 1)
                if node.args.vararg:
                    local_names.add(node.args.vararg.arg)
                    first_lines[node.args.vararg.arg] = getattr(node, "lineno", 1)
                if node.args.kwarg:
                    local_names.add(node.args.kwarg.arg)
                    first_lines[node.args.kwarg.arg] = getattr(node, "lineno", 1)

                for inner in ast.walk(node):
                    if inner is node:
                        continue
                    # Skip nested functions (they have their own scope)
                    if isinstance(inner, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        continue
                    if isinstance(inner, ast.Assign):
                        for target in inner.targets:
                            for name_node in ast.walk(target):
                                if isinstance(name_node, ast.Name) and isinstance(name_node.ctx, ast.Store):
                                    local_names.add(name_node.id)
                                    if name_node.id not in first_lines:
                                        first_lines[name_node.id] = getattr(inner, "lineno", 1)
                    elif isinstance(inner, (ast.AugAssign, ast.AnnAssign)):
                        target = inner.target
                        for name_node in ast.walk(target):
                            if isinstance(name_node, ast.Name):
                                local_names.add(name_node.id)
                                if name_node.id not in first_lines:
                                    first_lines[name_node.id] = getattr(inner, "lineno", 1)
                    elif isinstance(inner, ast.For):
                        for name_node in ast.walk(inner.target):
                            if isinstance(name_node, ast.Name):
                                local_names.add(name_node.id)
                                if name_node.id not in first_lines:
                                    first_lines[name_node.id] = getattr(inner, "lineno", 1)

                func_key = getattr(node, "lineno", 0)
                self._func_local_assigns[func_key] = local_names
                self._func_first_assign_line[func_key] = first_lines

    # -------------------------------------------------------------------------
    # AST Visitors
    # -------------------------------------------------------------------------

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.asname or alias.name
            sym = SymbolRecord(
                name=name,
                inferred_type="module",
                declared_line=getattr(node, "lineno", 0),
                declared_col=getattr(node, "col_offset", 0),
                scope_id=self.current_scope.scope_id,
                scope_name=self.current_scope.name,
                scope_level=self.current_scope.level,
                is_assigned=True,
            )
            self.current_scope.define(name, sym)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for alias in node.names:
            name = alias.asname or alias.name
            sym = SymbolRecord(
                name=name,
                inferred_type="module_item",
                declared_line=getattr(node, "lineno", 0),
                declared_col=getattr(node, "col_offset", 0),
                scope_id=self.current_scope.scope_id,
                scope_name=self.current_scope.name,
                scope_level=self.current_scope.level,
                is_assigned=True,
            )
            self.current_scope.define(name, sym)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._handle_function_def(node, is_async=False)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._handle_function_def(node, is_async=True)

    def _handle_function_def(self, node: Any, is_async: bool = False) -> None:
        func_name = node.name
        lineno = getattr(node, "lineno", 0)
        col_offset = getattr(node, "col_offset", 0)

        # Record function in current scope
        if func_name in self.current_scope.symbols:
            prev = self.current_scope.symbols[func_name]
            self.redeclared_variables.append({
                "type": "Redeclared Function",
                "name": func_name,
                "variable": func_name,
                "line": lineno,
                "column": col_offset,
                "previous_line": prev.declared_line,
                "scope": self.current_scope.name,
                "message": f"Function '{func_name}' redeclared; shadows previous definition at line {prev.declared_line}."
            })

        func_sym = SymbolRecord(
            name=func_name,
            inferred_type="callable",
            declared_line=lineno,
            declared_col=col_offset,
            scope_id=self.current_scope.scope_id,
            scope_name=self.current_scope.name,
            scope_level=self.current_scope.level,
            is_assigned=True,
        )
        self.current_scope.define(func_name, func_sym)

        # Record signature metadata for arity checking
        pos_args = [a.arg for a in node.args.args]
        defaults_count = len(node.args.defaults)
        min_args = len(pos_args) - defaults_count
        max_args = len(pos_args) if (not node.args.vararg) else float("inf")
        self.function_signatures[func_name] = {
            "name": func_name,
            "min_args": min_args,
            "max_args": max_args,
            "vararg": bool(node.args.vararg),
            "kwarg": bool(node.args.kwarg),
            "line": lineno
        }

        # Check for duplicate parameter names
        seen_params: Dict[str, int] = {}
        for arg in node.args.args:
            if arg.arg in seen_params:
                self.redeclared_variables.append({
                    "type": "Duplicate Parameter",
                    "name": arg.arg,
                    "variable": arg.arg,
                    "line": getattr(arg, "lineno", lineno),
                    "column": getattr(arg, "col_offset", 0),
                    "previous_line": seen_params[arg.arg],
                    "scope": f"Function {func_name}",
                    "message": f"Duplicate parameter '{arg.arg}' in definition of function '{func_name}'."
                })
            else:
                seen_params[arg.arg] = getattr(arg, "lineno", lineno)

        # Push new function scope
        func_scope = self._push_scope(func_name, ScopeType.FUNCTION, line_start=lineno)
        func_scope.params = list(seen_params.keys())

        # Register parameters in the function scope
        for arg in node.args.args:
            p_sym = SymbolRecord(
                name=arg.arg,
                inferred_type="Any",
                declared_line=getattr(arg, "lineno", lineno),
                declared_col=getattr(arg, "col_offset", 0),
                scope_id=func_scope.scope_id,
                scope_name=func_scope.name,
                scope_level=func_scope.level,
                is_parameter=True,
                is_assigned=True,
            )
            func_scope.define(arg.arg, p_sym)

        if node.args.vararg:
            v_sym = SymbolRecord(
                name=node.args.vararg.arg,
                inferred_type="tuple",
                declared_line=getattr(node.args.vararg, "lineno", lineno),
                declared_col=getattr(node.args.vararg, "col_offset", 0),
                scope_id=func_scope.scope_id,
                scope_name=func_scope.name,
                scope_level=func_scope.level,
                is_parameter=True,
                is_assigned=True,
            )
            func_scope.define(node.args.vararg.arg, v_sym)

        if node.args.kwarg:
            k_sym = SymbolRecord(
                name=node.args.kwarg.arg,
                inferred_type="dict",
                declared_line=getattr(node.args.kwarg, "lineno", lineno),
                declared_col=getattr(node.args.kwarg, "col_offset", 0),
                scope_id=func_scope.scope_id,
                scope_name=func_scope.name,
                scope_level=func_scope.level,
                is_parameter=True,
                is_assigned=True,
            )
            func_scope.define(node.args.kwarg.arg, k_sym)

        # Visit body statements
        for stmt in node.body:
            self.visit(stmt)

        end_line = getattr(node, "end_lineno", lineno)
        self._pop_scope(line_end=end_line)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        class_name = node.name
        lineno = getattr(node, "lineno", 0)
        col_offset = getattr(node, "col_offset", 0)

        sym = SymbolRecord(
            name=class_name,
            inferred_type=f"class:{class_name}",
            declared_line=lineno,
            declared_col=col_offset,
            scope_id=self.current_scope.scope_id,
            scope_name=self.current_scope.name,
            scope_level=self.current_scope.level,
            is_assigned=True,
        )
        self.current_scope.define(class_name, sym)

        class_scope = self._push_scope(class_name, ScopeType.CLASS, line_start=lineno)

        for stmt in node.body:
            self.visit(stmt)

        end_line = getattr(node, "end_lineno", lineno)
        self._pop_scope(line_end=end_line)

    def visit_Assign(self, node: ast.Assign) -> None:
        # First visit the value (RHS) to detect reads/undefined variables on RHS
        self.visit(node.value)

        rhs_type = _infer_literal_type(node.value)
        val_repr = None
        if isinstance(node.value, ast.Constant):
            val_repr = repr(node.value.value)

        lineno = getattr(node, "lineno", 0)
        col_offset = getattr(node, "col_offset", 0)

        for target in node.targets:
            if isinstance(target, ast.Name):
                name = target.id
                existing = self.current_scope.lookup(name, current_only=True)
                if existing:
                    existing.writes.append((lineno, col_offset))
                    if rhs_type != "Any":
                        existing.inferred_type = rhs_type
                    if val_repr:
                        existing.value_repr = val_repr
                else:
                    is_const = name.isupper() and len(name) > 1
                    sym = SymbolRecord(
                        name=name,
                        inferred_type=rhs_type,
                        declared_line=lineno,
                        declared_col=col_offset,
                        scope_id=self.current_scope.scope_id,
                        scope_name=self.current_scope.name,
                        scope_level=self.current_scope.level,
                        is_assigned=True,
                        is_constant=is_const,
                        writes=[(lineno, col_offset)],
                        value_repr=val_repr
                    )
                    self.current_scope.define(name, sym)
            else:
                self.visit(target)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        lineno = getattr(node, "lineno", 0)
        col_offset = getattr(node, "col_offset", 0)

        # In AugAssign, the target is both READ and WRITTEN
        if isinstance(node.target, ast.Name):
            name = node.target.id
            self._check_variable_read(name, lineno, col_offset)
            existing = self.current_scope.lookup(name, current_only=True)
            if existing:
                existing.writes.append((lineno, col_offset))
            else:
                sym = SymbolRecord(
                    name=name,
                    inferred_type=_infer_literal_type(node.value),
                    declared_line=lineno,
                    declared_col=col_offset,
                    scope_id=self.current_scope.scope_id,
                    scope_name=self.current_scope.name,
                    scope_level=self.current_scope.level,
                    is_assigned=True,
                    writes=[(lineno, col_offset)]
                )
                self.current_scope.define(name, sym)
        else:
            self.visit(node.target)

        self.visit(node.value)

    def visit_For(self, node: ast.For) -> None:
        self.visit(node.iter)

        lineno = getattr(node, "lineno", 0)
        col_offset = getattr(node, "col_offset", 0)

        # Register target variables
        for name_node in ast.walk(node.target):
            if isinstance(name_node, ast.Name):
                name = name_node.id
                existing = self.current_scope.lookup(name, current_only=True)
                if existing:
                    existing.writes.append((lineno, col_offset))
                else:
                    sym = SymbolRecord(
                        name=name,
                        inferred_type="Any",
                        declared_line=lineno,
                        declared_col=col_offset,
                        scope_id=self.current_scope.scope_id,
                        scope_name=self.current_scope.name,
                        scope_level=self.current_scope.level,
                        is_assigned=True,
                        writes=[(lineno, col_offset)]
                    )
                    self.current_scope.define(name, sym)

        for stmt in node.body:
            self.visit(stmt)
        for stmt in node.orelse:
            self.visit(stmt)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            lineno = getattr(node, "lineno", 0)
            col_offset = getattr(node, "col_offset", 0)
            self._check_variable_read(node.id, lineno, col_offset)
        self.generic_visit(node)

    def _check_variable_read(self, name: str, lineno: int, col_offset: int) -> None:
        """Inspects a variable access for undefined variable or use-before-assignment."""
        # Builtin or imported symbols are always valid
        if name in BUILTIN_NAMES or name in self.imported_symbols:
            return

        # Check for use-before-assignment if inside a function scope
        if self.current_scope.scope_type == ScopeType.FUNCTION:
            func_line = self.current_scope.line_start
            locals_in_func = self._func_local_assigns.get(func_line, set())
            first_lines = self._func_first_assign_line.get(func_line, {})

            if name in locals_in_func and name not in self.current_scope.globals and name not in self.current_scope.nonlocals:
                first_assign = first_lines.get(name, 0)
                # If reading the variable before its first assignment line in this function
                if lineno < first_assign and name not in self.current_scope.params:
                    self.use_before_assignment.append({
                        "name": name,
                        "variable": name,
                        "line": lineno,
                        "column": col_offset,
                        "assignment_line": first_assign,
                        "scope": self.current_scope.name,
                        "message": (
                            f"Variable '{name}' referenced at line {lineno} before assignment at line {first_assign} "
                            f"(will raise UnboundLocalError at runtime)."
                        )
                    })
                    return

        # Look up in current scope hierarchy
        found_symbol = self.current_scope.lookup(name, current_only=False)
        if found_symbol:
            found_symbol.reads.append((lineno, col_offset))
            return

        # Not found: Undefined Variable!
        # Generate symbol-table-grounded suggestion
        suggestion = self.suggest_did_you_mean(name)
        evidence = self.lines[lineno - 1].strip() if (0 < lineno <= len(self.lines)) else name

        self.undefined_variables.append({
            "name": name,
            "variable": name,
            "line": lineno,
            "column": col_offset,
            "scope": self.current_scope.name,
            "evidence": evidence,
            "did_you_mean": suggestion,
            "message": (
                f"Undefined variable '{name}' at line {lineno} in scope '{self.current_scope.name}'."
                + (f" Did you mean '{suggestion['name']}' ({suggestion['scope']}, line {suggestion['line']})?" if suggestion else "")
            )
        })

    def visit_BinOp(self, node: ast.BinOp) -> None:
        """Type checks binary operations for primitive mismatches."""
        left_type = self._resolve_expr_type(node.left)
        right_type = self._resolve_expr_type(node.right)
        lineno = getattr(node, "lineno", 0)

        # Check incompatible concatenation / addition
        if isinstance(node.op, ast.Add):
            if (left_type == "str" and right_type in ("int", "float", "bool", "list", "dict")) or \
               (right_type == "str" and left_type in ("int", "float", "bool", "list", "dict")):
                self.type_mismatches.append({
                    "type": "Incompatible Addition/Concatenation",
                    "line": lineno,
                    "left_type": left_type,
                    "right_type": right_type,
                    "operator": "+",
                    "message": f"TypeError: Can only concatenate str to str, not '{right_type if left_type == 'str' else left_type}' at line {lineno}."
                })
            elif (left_type == "list" and right_type not in ("list", "Any")) or \
                 (right_type == "list" and left_type not in ("list", "Any")):
                self.type_mismatches.append({
                    "type": "Incompatible Sequence Addition",
                    "line": lineno,
                    "left_type": left_type,
                    "right_type": right_type,
                    "operator": "+",
                    "message": f"TypeError: Can only concatenate list to list (got '{left_type}' and '{right_type}') at line {lineno}."
                })
        elif isinstance(node.op, ast.Mult):
            if left_type == "str" and right_type == "str":
                self.type_mismatches.append({
                    "type": "Invalid String Multiplication",
                    "line": lineno,
                    "left_type": left_type,
                    "right_type": right_type,
                    "operator": "*",
                    "message": f"TypeError: Can't multiply sequence by non-int of type 'str' at line {lineno}."
                })

        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """Type checks calls on non-callables and verifies function arity."""
        lineno = getattr(node, "lineno", 0)

        # Check if calling a known non-callable variable
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            sym = self.current_scope.lookup(func_name, current_only=False)
            if sym and sym.inferred_type in ("int", "float", "str", "list", "dict", "bool", "None"):
                self.type_mismatches.append({
                    "type": "Calling Non-Callable",
                    "name": func_name,
                    "line": lineno,
                    "inferred_type": sym.inferred_type,
                    "message": f"TypeError: '{sym.inferred_type}' object is not callable (attempted to call '{func_name}' at line {lineno})."
                })

            # Check arity for known defined functions
            if func_name in self.function_signatures:
                sig = self.function_signatures[func_name]
                arg_count = len(node.args)
                if not sig["vararg"]:
                    if arg_count < sig["min_args"]:
                        missing = sig["min_args"] - arg_count
                        self.type_mismatches.append({
                            "type": "Function Arity Mismatch",
                            "name": func_name,
                            "line": lineno,
                            "expected": f"at least {sig['min_args']}",
                            "actual": arg_count,
                            "message": f"TypeError: {func_name}() missing {missing} required positional argument(s) at line {lineno}."
                        })
                    elif arg_count > sig["max_args"]:
                        self.type_mismatches.append({
                            "type": "Function Arity Mismatch",
                            "name": func_name,
                            "line": lineno,
                            "expected": f"at most {sig['max_args']}",
                            "actual": arg_count,
                            "message": f"TypeError: {func_name}() takes {sig['max_args']} positional arguments but {arg_count} were given at line {lineno}."
                        })

        self.generic_visit(node)

    def visit_Subscript(self, node: ast.Subscript) -> None:
        """Checks indexing on non-subscriptables and list index types."""
        lineno = getattr(node, "lineno", 0)
        target_type = self._resolve_expr_type(node.value)

        if target_type in ("int", "float", "bool", "None"):
            self.type_mismatches.append({
                "type": "Indexing Non-Subscriptable",
                "line": lineno,
                "target_type": target_type,
                "message": f"TypeError: '{target_type}' object is not subscriptable at line {lineno}."
            })
        elif target_type in ("list", "tuple") and isinstance(node.slice, ast.Constant):
            if isinstance(node.slice.value, str):
                self.type_mismatches.append({
                    "type": "Invalid Index Type",
                    "line": lineno,
                    "target_type": target_type,
                    "index_type": "str",
                    "message": f"TypeError: {target_type} indices must be integers or slices, not str at line {lineno}."
                })

        self.generic_visit(node)

    def _resolve_expr_type(self, node: ast.AST) -> str:
        """Resolves expression type from constants or symbol table lookups."""
        lit_type = _infer_literal_type(node)
        if lit_type != "Any":
            return lit_type
        if isinstance(node, ast.Name):
            sym = self.current_scope.lookup(node.id, current_only=False)
            if sym and sym.inferred_type != "Any":
                return sym.inferred_type
        return "Any"

    # -------------------------------------------------------------------------
    # "Did you mean...?" Symbol Table Suggestion Engine
    # -------------------------------------------------------------------------

    def suggest_did_you_mean(self, var_name: str) -> Optional[Dict[str, Any]]:
        """Finds closest match for an undefined variable from visible symbols and builtins."""
        visible_symbols = self.current_scope.get_all_visible_symbols()

        candidates: List[Tuple[str, str, int, str]] = []
        for name, sym in visible_symbols.items():
            if name != var_name and not name.startswith("__"):
                candidates.append((name, sym.scope_name, sym.declared_line, sym.inferred_type))

        # Also consider standard builtins with lower priority
        for b in BUILTIN_NAMES:
            if not b.startswith("_") and b != var_name and b not in visible_symbols:
                candidates.append((b, "builtin", 0, "builtin"))

        if not candidates:
            return None

        candidate_names = [c[0] for c in candidates]
        matches = difflib.get_close_matches(var_name, candidate_names, n=3, cutoff=0.55)
        if not matches:
            return None

        best_name = matches[0]
        ratio = difflib.SequenceMatcher(None, var_name, best_name).ratio()

        for c_name, c_scope, c_line, c_type in candidates:
            if c_name == best_name:
                return {
                    "name": best_name,
                    "scope": c_scope,
                    "line": c_line,
                    "type": c_type,
                    "confidence": round(ratio * 100, 1)
                }

        return None


# -----------------------------------------------------------------------------
# Public API Convenience Functions
# -----------------------------------------------------------------------------

def analyze_semantics(code: str) -> Dict[str, Any]:
    """Top-level entry point to run semantic analysis on Python code."""
    analyzer = SemanticAnalyzer(code)
    return analyzer.analyze()


def suggest_symbol_hint(code: str, error_var: str, line_no: int = 0) -> Optional[Dict[str, Any]]:
    """Grounded 'Did you mean...?' helper using the actual symbol table."""
    analyzer = SemanticAnalyzer(code)
    res = analyzer.analyze()
    if not res.get("success"):
        return None

    # Find the deepest scope containing line_no
    target_scope = analyzer.global_scope
    for sc in analyzer.all_scopes:
        if sc.line_start <= line_no <= (sc.line_end or 999999):
            if sc.level > target_scope.level:
                target_scope = sc

    analyzer.current_scope = target_scope
    return analyzer.suggest_did_you_mean(error_var)
