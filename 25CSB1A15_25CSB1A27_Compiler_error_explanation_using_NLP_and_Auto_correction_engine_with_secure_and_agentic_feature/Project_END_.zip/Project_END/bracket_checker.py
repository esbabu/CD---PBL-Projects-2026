"""bracket_checker.py - Pushdown Automaton (PDA) for Bracket Validation in IntelliFix.

Implements Feature 6 (TOC Week 3):
- Formal Pushdown Automaton (7-tuple: Q, Sigma, Gamma, delta, q0, Z0, F).
- Explicit stack transition operations with bottom-of-stack marker 'Z0'.
- Multi-error reporting with documented panic-mode / sync recovery.
- Uses tokenizer.py to automatically bypass brackets within comments and string literals.
- Tracks exact (line, col) positions for opening and closing delimiters.
- Maximum nesting depth limit (10,000) prevents stack overflow.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import tokenizer

# Delimiter pairings
MATCHING_OPEN = {")": "(", "]": "[", "}": "{"}
MATCHING_CLOSE = {"(": ")", "[": "]", "{": "}"}
OPEN_BRACKETS = set(MATCHING_CLOSE.keys())
CLOSE_BRACKETS = set(MATCHING_OPEN.keys())

MAX_STACK_DEPTH = 128
BOTTOM_MARKER = "Z0"


def check_brackets(code: str, trace: bool = False) -> Dict[str, Any]:
    """Validate balanced brackets using an explicit Pushdown Automaton (PDA).

    Args:
        code: Python source code string.
        trace: If True, returns detailed transition steps and stack configurations.

    Returns:
        Dict containing:
            ok: Boolean True if no bracket problems detected, False otherwise.
            problems: List of problem dicts {kind, message, line, col, expected}.
            trace: List of transition records if trace=True, else None.
    """
    tok_res = tokenizer.tokenize(code)
    tokens = tok_res["tokens"]

    # Stack holds tuples: (bracket_char, line, col)
    # Bottom marker: (BOTTOM_MARKER, 0, 0)
    stack: List[Tuple[str, int, int]] = [(BOTTOM_MARKER, 0, 0)]
    problems: List[Dict[str, Any]] = []
    trace_steps: List[Dict[str, Any]] = []

    step_num = 0

    for tok in tokens:
        if tok["type"] != "BRACKET":
            continue

        ch = tok["text"]
        line = tok["line"]
        col = tok["col"]
        step_num += 1

        top_ch, top_line, top_col = stack[-1]

        if ch in OPEN_BRACKETS:
            # Check maximum depth limit
            if len(stack) > MAX_STACK_DEPTH:
                problems.append({
                    "kind": "max_depth_exceeded",
                    "message": f"Bracket nesting depth exceeded maximum limit ({MAX_STACK_DEPTH}) at line {line}, col {col}",
                    "line": line,
                    "col": col,
                })
                break

            # PDA Action: PUSH
            stack.append((ch, line, col))
            if trace:
                trace_steps.append({
                    "step": step_num,
                    "state": "q_loop",
                    "input": ch,
                    "action": f"PUSH({ch})",
                    "stack_depth": len(stack),
                    "stack_top": ch,
                    "line": line,
                    "col": col,
                })

        elif ch in CLOSE_BRACKETS:
            expected_open = MATCHING_OPEN[ch]

            if top_ch == BOTTOM_MARKER:
                # PDA Action: REJECT / UNMATCHED CLOSING
                problems.append({
                    "kind": "unmatched_closing",
                    "message": f"Unmatched '{ch}' at line {line}, col {col} (nothing is open)",
                    "line": line,
                    "col": col,
                    "expected": None,
                })
                if trace:
                    trace_steps.append({
                        "step": step_num,
                        "state": "q_loop",
                        "input": ch,
                        "action": "REJECT_UNMATCHED_CLOSING",
                        "stack_depth": len(stack),
                        "stack_top": top_ch,
                        "line": line,
                        "col": col,
                    })

            elif top_ch == expected_open:
                # PDA Action: POP (Successful match)
                stack.pop()
                if trace:
                    trace_steps.append({
                        "step": step_num,
                        "state": "q_loop",
                        "input": ch,
                        "action": f"POP({expected_open})",
                        "stack_depth": len(stack),
                        "stack_top": stack[-1][0],
                        "line": line,
                        "col": col,
                    })

            else:
                # Mismatch detected: top_ch does not match expected_open
                expected_close = MATCHING_CLOSE.get(top_ch, "")
                problems.append({
                    "kind": "mismatched",
                    "message": (
                        f"'{top_ch}' opened at line {top_line}, col {top_col} "
                        f"was closed by '{ch}' at line {line}, col {col} (expected '{expected_close}')"
                    ),
                    "line": line,
                    "col": col,
                    "open_line": top_line,
                    "open_col": top_col,
                    "open_char": top_ch,
                    "close_char": ch,
                    "expected": expected_close,
                })

                # Documented Recovery Rule:
                # Look back up to 5 elements in the stack to see if expected_open is waiting.
                # If found, pop the stack up to that element (reporting unclosed brackets).
                # Otherwise, treat the closing bracket as a stray character and discard it.
                lookback_idx = -1
                for idx in range(len(stack) - 1, max(-1, len(stack) - 6), -1):
                    if stack[idx][0] == expected_open:
                        lookback_idx = idx
                        break

                if lookback_idx != -1:
                    # Pop intermediate unclosed items
                    while len(stack) - 1 > lookback_idx:
                        popped_open, p_line, p_col = stack.pop()
                        problems.append({
                            "kind": "unclosed",
                            "message": f"'{popped_open}' opened at line {p_line}, col {p_col} was never closed",
                            "line": p_line,
                            "col": p_col,
                            "expected": MATCHING_CLOSE.get(popped_open),
                        })
                    # Pop the now-matching element
                    stack.pop()
                else:
                    # Direct mismatch without opener deeper in stack:
                    # Consume the mismatched opener so it does not trigger a duplicate unclosed error
                    if len(stack) > 1:
                        stack.pop()

                if trace:
                    trace_steps.append({
                        "step": step_num,
                        "state": "q_loop",
                        "input": ch,
                        "action": f"RECOVERY_MISMATCH({top_ch} vs {ch})",
                        "stack_depth": len(stack),
                        "stack_top": stack[-1][0],
                        "line": line,
                        "col": col,
                    })

    # End of input: check for remaining unclosed opening brackets
    while len(stack) > 1:
        unclosed_ch, u_line, u_col = stack.pop()
        problems.append({
            "kind": "unclosed",
            "message": f"'{unclosed_ch}' opened at line {u_line}, col {u_col} was never closed",
            "line": u_line,
            "col": u_col,
            "expected": MATCHING_CLOSE.get(unclosed_ch),
        })

    is_ok = (len(problems) == 0) and (len(stack) == 1 and stack[0][0] == BOTTOM_MARKER)

    return {
        "ok": is_ok,
        "problems": problems,
        "trace": trace_steps if trace else None,
    }


def fix_brackets(code: str) -> Optional[str]:
    """Attempts deterministic repair of bracket defects using PDA diagnostics.

    Handles:
    - Mismatched delimiters: replaces erroneous closer with matching closer.
    - Unmatched/stray closing delimiters: removes the stray closer.
    - Unclosed opening delimiters: appends matching closer at end of line/file.

    Returns:
        Repaired code string if defects were found and changed, otherwise None.
    """
    chk = check_brackets(code)
    if chk.get("ok") or not chk.get("problems"):
        return None

    problems = chk["problems"]
    lines = code.splitlines()
    newline = "\r\n" if "\r\n" in code else "\n"

    unclosed = [p for p in problems if p.get("kind") == "unclosed"]
    others = [p for p in problems if p.get("kind") != "unclosed"]

    from collections import defaultdict
    by_line = defaultdict(list)
    for p in others:
        if "line" in p and p["line"] is not None:
            by_line[p["line"]].append(p)

    for l_num, plist in by_line.items():
        if 1 <= l_num <= len(lines):
            line_idx = l_num - 1
            cur_line = list(lines[line_idx])
            plist.sort(key=lambda x: x.get("col", 0), reverse=True)
            for p in plist:
                c_idx = p.get("col", 0)
                if 0 <= c_idx < len(cur_line):
                    if p.get("kind") == "mismatched" and p.get("expected"):
                        cur_line[c_idx] = p["expected"]
                    elif p.get("kind") == "unmatched_closing":
                        cur_line.pop(c_idx)
            lines[line_idx] = "".join(cur_line)

    if unclosed:
        for p in sorted(unclosed, key=lambda x: (x.get("line") or 0, x.get("col") or 0), reverse=True):
            target_l = p.get("line")
            exp = p.get("expected")
            if exp and target_l and 1 <= target_l <= len(lines):
                target_idx = target_l - 1
                line_content = lines[target_idx]
                comm_idx = -1
                in_quote = None
                for c_i, c_char in enumerate(line_content):
                    if in_quote:
                        if c_char == in_quote and (c_i == 0 or line_content[c_i - 1] != "\\"):
                            in_quote = None
                    elif c_char in ('"', "'"):
                        in_quote = c_char
                    elif c_char == '#' and not in_quote:
                        comm_idx = c_i
                        break

                if comm_idx != -1:
                    c_part = line_content[:comm_idx]
                    comm_part = line_content[comm_idx + 1:]
                    lines[target_idx] = f"{c_part.rstrip()}{exp} #{comm_part}"
                else:
                    lines[target_idx] = line_content + exp
            elif exp and lines:
                lines[-1] = lines[-1] + exp

    cand = newline.join(lines)
    return cand if cand != code else None
