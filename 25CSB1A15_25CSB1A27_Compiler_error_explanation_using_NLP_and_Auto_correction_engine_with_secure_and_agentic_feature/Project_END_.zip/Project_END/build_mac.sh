#!/bin/bash
# ============================================================
#  build_mac.sh — Build TOC Studio as a macOS .app bundle
# ============================================================

set -e   # stop on any error

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo ""
echo "======================================================"
echo "  TOC Studio — macOS .app Builder"
echo "======================================================"
echo ""

# 1. Check Python
if ! command -v python3 &>/dev/null; then
    echo "❌ python3 not found. Install from https://python.org"
    exit 1
fi
echo "✅ Python: $(python3 --version)"

# 2. Install PyInstaller if missing
if ! python3 -c "import PyInstaller" 2>/dev/null; then
    echo "📦 Installing PyInstaller..."
    pip3 install pyinstaller
fi
echo "✅ PyInstaller: $(python3 -m PyInstaller --version)"

# 3. Install required packages
echo ""
echo "📦 Checking required packages..."
pip3 install -r requirements.txt --quiet
pip3 install python-dotenv --quiet

# 4. Clean previous builds
echo ""
echo "🧹 Cleaning previous build artifacts..."
rm -rf build/desktop_app_mac
rm -rf "dist/TOC Studio.app"

# 5. Run PyInstaller
echo ""
echo "🔨 Building .app bundle (this takes 2–5 minutes)..."
python3 -m PyInstaller desktop_app_mac.spec --noconfirm --clean

# 6. Done
echo ""
if [ -d "dist/TOC Studio.app" ]; then
    echo "======================================================"
    echo "✅  Build SUCCESS!"
    echo ""
    echo "   Your app is ready at:"
    echo "   📁  dist/TOC Studio.app"
    echo ""
    echo "   Double-click it in Finder, or run:"
    echo "   open \"dist/TOC Studio.app\""
    echo "======================================================"
    # Auto-open Finder to the dist folder
    open dist/
else
    echo "❌  Build FAILED — dist/TOC Studio.app not found."
    echo "    Check the output above for errors."
    exit 1
fi

