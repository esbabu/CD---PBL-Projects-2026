#!/usr/bin/env python3
"""IntelliFix CLI - Automated Python Compiler Error Diagnosis and Repair Engine.

Usage:
    python intellifix.py <file.py> [options]

Options:
    --agent         Use multi-turn LLM agent for repair (if keys available; falls back to rules offline)
    --shield-off    Disable Security Shield protection (default: Shield enabled)
    --json          Output results in JSON format
    --diff          Display colorized unified diff between original and repaired code
    --write         Write repaired code to disk (<filename>_fixed.py)
    --in-place      Overwrite target file directly with repaired code
    --version       Print version and Week 6 verification hash
"""

import argparse
import difflib
import hashlib
import json
import os
import sys
from typing import Dict, Any, List, Optional


def compute_week6_hash(workspace_dir: str = ".") -> str:
    """Computes SHA256 (first 12 hex) over security/metrics.py, run_benchmark.py, intellifix.py."""
    files = [
        os.path.join("security", "metrics.py"),
        "run_benchmark.py",
        "intellifix.py"
    ]
    h = hashlib.sha256()
    for fn in files:
        p = os.path.join(workspace_dir, fn)
        if os.path.exists(p):
            with open(p, "rb") as f:
                h.update(f.read())
    return h.hexdigest()[:12]


def color_diff_line(line: str) -> str:
    """Adds ANSI terminal colors to diff lines."""
    if line.startswith("+") and not line.startswith("+++"):
        return f"\033[92m{line}\033[0m"
    elif line.startswith("-") and not line.startswith("---"):
        return f"\033[91m{line}\033[0m"
    elif line.startswith("@"):
        return f"\033[96m{line}\033[0m"
    return line


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="intellifix",
        description="IntelliFix - Automated Python Error Diagnosis & Security-Guarded Auto-Repair Engine"
    )
    parser.add_argument("file", nargs="?", default=None, help="Path to Python file to analyze and repair")
    parser.add_argument("--agent", action="store_true", help="Use multi-turn agent repair instead of rule-based repair")
    parser.add_argument("--shield-off", action="store_true", help="Disable Security Shield protection (default: Shield enabled)")
    parser.add_argument("--json", action="store_true", help="Output machine-readable JSON")
    parser.add_argument("--diff", action="store_true", help="Display unified diff of repair")
    parser.add_argument("--write", action="store_true", help="Save fixed code to <filename>_fixed.py")
    parser.add_argument("--in-place", action="store_true", help="Overwrite the original input file with repaired code")
    parser.add_argument("--version", action="store_true", help="Print IntelliFix version and Week 6 verification hash")

    args = parser.parse_args()

    # Handle --version
    if args.version:
        w6_hash = compute_week6_hash(os.path.dirname(os.path.abspath(__file__)))
        if args.json:
            print(json.dumps({"version": "1.0.0", "week6_hash": w6_hash, "shield_default": True}, indent=2))
        else:
            print(f"IntelliFix v1.0.0 (Week 6 Final Release, Hash: {w6_hash})")
            print("Deterministic Rule Engine + Guarded Agent Repair + 4-Gate AAI Shield")
        return 0

    if not args.file:
        if args.json:
            print(json.dumps({"error": "No input file specified. Run with -h for help.", "status": "error"}, indent=2))
        else:
            parser.print_help()
        return 1

    file_path = os.path.abspath(args.file)
    if not os.path.isfile(file_path):
        err_msg = f"File not found: {args.file}"
        if args.json:
            print(json.dumps({"error": err_msg, "status": "error"}, indent=2))
        else:
            print(f"Error: {err_msg}", file=sys.stderr)
        return 1

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            code = f.read()
    except UnicodeDecodeError:
        with open(file_path, "r", encoding="latin-1") as f:
            code = f.read()

    # Strip BOM if present
    if code.startswith("\ufeff"):
        code = code[1:]

    # Security Shield Gate Checks (Enabled by default unless --shield-off is passed)
    shield_enabled = not args.shield_off
    if shield_enabled:
        try:
            from security.shield import get_shield
            shield = get_shield()
            verdict = shield.inspect_input(code, channel="code_content")
            if not verdict.get("allowed", True):
                evidence = verdict.get("evidence", [])
                signals = verdict.get("signals", [])
                findings = [s.get("evidence") for s in signals if isinstance(s, dict) and s.get("evidence")]
                if args.json:
                    print(json.dumps({
                        "status": "security_blocked",
                        "gate": "Gate 1 (Input Guard)",
                        "risk_score": verdict.get("score", 100),
                        "reason": "Security shield blocked input code content",
                        "findings": findings or evidence,
                        "evidence": evidence,
                        "shield_enabled": True
                    }, indent=2))
                else:
                    print("============================================================")
                    print("[INTELLIFIX SECURITY SHIELD: EXECUTION BLOCKED]")
                    print("  Gate:       Gate 1 (Input Guard)")
                    print(f"  Risk Score: {verdict.get('score', 100)}/100")
                    print("  Reason:     Security shield blocked input code content")
                    display_findings = findings or evidence
                    if display_findings:
                        print("  Findings:")
                        for finding in display_findings:
                            print(f"    - {finding}")
                    print("============================================================")
                return 2
        except Exception:
            pass

        # Static Code Analysis Guard
        try:
            from security_analyzer import scan_gate
            gate_res = scan_gate(code)
            if not gate_res.get("allowed", True):
                if args.json:
                    print(json.dumps({
                        "status": "security_blocked",
                        "gate": "Gate 3 (Static Code Guard)",
                        "reason": gate_res.get("message", "Static security violation"),
                        "findings": gate_res.get("findings", []),
                        "shield_enabled": True
                    }, indent=2))
                else:
                    print("============================================================")
                    print("[INTELLIFIX SECURITY SCAN: EXECUTION BLOCKED]")
                    print(f"  Reason: {gate_res.get('message')}")
                    for finding in gate_res.get("findings", []):
                        print(f"    - [{finding.get('severity')}] {finding.get('type')}: {finding.get('message')}")
                    print("============================================================")
                return 2
        except ImportError:
            pass

    # Diagnosis and Repair Execution
    fixed_code = code
    status = "clean"
    errors = []
    fixed_count = 0
    rem_count = 0
    fix_status = "already_clean"
    repair_source = "none"

    offline_mode = (os.environ.get("LLM_DISABLED") == "1") or (
        not os.environ.get("GEMINI_API_KEY") and not os.environ.get("GROQ_API_KEY")
    )

    if args.agent and not offline_mode:
        try:
            from agent import repair
            agent_res = repair(code, instruction="Diagnose and repair all compiler and runtime errors")
            status = agent_res.get("status")
            if status in ("success", "pending_approval") and agent_res.get("proposal"):
                prop = agent_res["proposal"]
                fixed_code = prop.get("fixed_code") or prop.get("code") or code
                repair_source = "agent"
                fix_status = "agent_repaired"
            elif status == "already_clean":
                repair_source = "agent"
                fix_status = "already_clean"
            else:
                repair_source = "agent_failed"
        except Exception:
            # Fall back to multi_error rule-based engine
            pass

    if repair_source in ("none", "agent_failed"):
        try:
            import multi_error
            multi_res = multi_error.analyze_multi_error(code)
            errors = multi_res.get("errors", [])
            fixed_code = multi_res.get("fixed_code", code)
            fixed_count = multi_res.get("fixed_count", 0)
            rem_count = multi_res.get("remaining_count", 0)
            fix_status = multi_res.get("fix_status", "already_clean")
            repair_source = multi_res.get("fix_source", "deterministic_rules")
        except ImportError:
            from error_extractor import extract_error
            ir_dict = extract_error(code)
            if ir_dict and ir_dict.get("error_type"):
                errors = [{"error_type": ir_dict.get("error_type"), "message": ir_dict.get("error_message")}]
                rem_count = 1

    # Pre-execution scan gate for synthesized fixed_code
    fixed_is_safe = True
    if fixed_code != code:
        try:
            from security_analyzer import scan_gate
            sg_res = scan_gate(fixed_code)
            if not sg_res.get("allowed", True):
                fixed_is_safe = False
                fixed_code = code  # Revert to original to prevent running malicious synthesized code
        except Exception:
            pass

    # Verify if fixed_code executes cleanly in sandbox
    from sandbox_runner import run_in_sandbox
    if fixed_is_safe:
        sb_after = run_in_sandbox(fixed_code, timeout=5.0)
        final_clean = (sb_after.get("status") == "ok")
    else:
        sb_after = {"status": "security_blocked"}
        final_clean = False

    if final_clean:
        exit_code = 0
        final_status = "success"
    else:
        exit_code = 1
        final_status = "repair_incomplete"

    # Compute diff
    diff_lines = list(difflib.unified_diff(
        code.splitlines(keepends=True),
        fixed_code.splitlines(keepends=True),
        fromfile=os.path.basename(file_path),
        tofile=os.path.basename(file_path) + " (fixed)"
    ))

    # Protected files blacklist to prevent overwriting core system, security or test modules
    PROTECTED_FILES = {
        "app.py", "nlp_explainer.py", "error_extractor.py", "security_analyzer.py",
        "multi_error.py", "sandbox_runner.py", "sandbox_child.py", "llm_explainer.py",
        "llm_calls.py", "offline_guide.py", "main.py", "agent.py", "agent_tools.py",
        "agent_proposals.py", "automaton_engine.py", "cfg_engine.py", "pda_engine.py",
        "bracket_checker.py", "tokenizer.py", "dfa.py", "intellifix.py",
        "run_benchmark.py", "gui.py", "desktop_app.py", "policy.json",
        "policy.sha256", "shield_manifest.json"
    }

    # Handle write flags
    saved_to = None
    if args.in_place and fixed_code != code:
        real_file = os.path.realpath(file_path)
        base_name = os.path.basename(real_file).lower()
        is_security_dir = os.path.basename(os.path.dirname(real_file)).lower() == "security"
        if base_name in {p.lower() for p in PROTECTED_FILES} or is_security_dir or base_name.startswith("tests_"):
            if args.json:
                print(json.dumps({
                    "status": "error",
                    "error": f"Cannot modify protected file '{base_name}' in-place"
                }, indent=2))
            else:
                print(f"[ERROR] Cannot modify protected system or test file '{base_name}' in-place.")
            return 1

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(fixed_code)
        saved_to = file_path
    elif args.write and fixed_code != code:
        base, ext = os.path.splitext(file_path)
        out_path = f"{base}_fixed{ext}"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(fixed_code)
        saved_to = out_path

    # Output formatting
    if args.json:
        result = {
            "file": file_path,
            "status": final_status,
            "initial_errors": len(errors),
            "errors": errors,
            "fixed_count": fixed_count,
            "remaining_count": rem_count if not final_clean else 0,
            "fix_status": fix_status,
            "repair_source": repair_source,
            "sandbox_status": sb_after.get("status"),
            "has_diff": (fixed_code != code),
            "diff": "".join(diff_lines),
            "saved_to": saved_to,
            "shield_enabled": shield_enabled
        }
        print(json.dumps(result, indent=2))
    else:
        print("============================================================")
        print(f"IntelliFix Analysis: {os.path.basename(file_path)}")
        print("============================================================")
        if not errors and final_clean:
            print("Status: [CLEAN] No syntax, type, or runtime errors detected.")
        else:
            print(f"Status: [{final_status.upper()}] Initial errors: {len(errors)} | Fixed: {fixed_count}")
            for err in errors:
                line_info = f" (line {err.get('line')})" if err.get('line') else ""
                print(f"  - {err.get('error_type')}{line_info}: {err.get('message')}")
            print(f"Repair Engine: {repair_source} -> {fix_status}")

        if args.diff and diff_lines:
            print("\n--- Code Unified Diff ---")
            for dl in diff_lines:
                print(color_diff_line(dl.rstrip("\r\n")))

        if saved_to:
            print(f"\nRepaired code written to: {saved_to}")
        print("============================================================")

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
