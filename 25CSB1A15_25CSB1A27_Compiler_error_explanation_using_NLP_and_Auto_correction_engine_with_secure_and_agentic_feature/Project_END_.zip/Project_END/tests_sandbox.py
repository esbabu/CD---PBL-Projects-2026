"""
tests_sandbox.py - Unit and Integration Tests for IntelliFix Feature 2A Sandboxed Code Runner.

Covers all 23 test requirements:
 1. Normal program execution (ok, stdout, exit 0)
 2. Golden baseline comparison across all sample programs
 3. SyntaxError line accuracy
 4. Timeout handling and server responsiveness
 5. Memory limit enforcement
 6. Output limit enforcement
 7. Process creation prevention (violation "process")
 8. Process tree termination and orphan prevention
 9. Network access prevention (violation "network")
10. File isolation (write inside allowed, write outside blocked as violation)
11. Environment secret isolation (GEMINI_API_KEY, GROQ_API_KEY, secrets scrubbed)
12. Non-interactive input() handling (EOFError, no hang)
13. Tamper resistance against forged result delimiters and sys.argv inspection
14. Temporary folder cleanup across repeated runs
15. Parallel execution concurrency safety
16. Fail-closed behavior on invalid interpreter
17. Flask test client contract across ok, error, timeout, output_limit, violation
18. UI contract static verification
19. Static scan verifying no direct exec/eval of user code in server runtime
20. UTF-8 unicode integrity under -I -X utf8
21. Traceback source line preservation
22. Windows Job Object limits
23. Interplay between static security analyzer and sandbox runtime guards
"""

import sys
import os
import io
import json
import time
import re
import glob
import tempfile
import unittest
import unittest.mock
from concurrent.futures import ThreadPoolExecutor

import psutil

# Ensure project root is on sys.path
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from sandbox_runner import run_in_sandbox, DEFAULT_TIMEOUT, DEFAULT_MEMORY_MB, DEFAULT_MAX_OUTPUT_KB
from error_extractor import extract_error
import security_analyzer
import app as flask_app


class SandboxRunnerTests(unittest.TestCase):

    def setUp(self):
        # Enforce clean test environment
        self.env_patcher = unittest.mock.patch.dict(os.environ, {
            "CODECARBON_SAVE_TO_FILE": "false",
            "CODECARBON_LOG_LEVEL": "error",
            "LLM_DISABLED": "1",
            "AUTOFIX_AI": "0"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()

    def test_01_normal_program(self):
        """1. Normal program: ok, stdout correct, exit 0."""
        code = "print('Hello, IntelliFix Sandbox!')"
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "ok")
        self.assertEqual(res["exit_code"], 0)
        self.assertIn("Hello, IntelliFix Sandbox!", res["stdout"])
        self.assertIsNone(res["error"])
        self.assertEqual(res["violations"], [])

    def test_02_sample_programs_golden_baseline(self):
        """2. Every sample program: same error_type, line number, stdout as golden_baseline.json."""
        baseline_path = os.path.join(_PROJECT_ROOT, "tests", "sandbox", "golden_baseline.json")
        if not os.path.exists(baseline_path):
            self.skipTest("golden_baseline.json not found")

        with open(baseline_path, "r", encoding="utf-8") as f:
            baseline = json.load(f)

        for fname, expected in baseline.get("sample_files", {}).items():
            fpath = os.path.join(_PROJECT_ROOT, fname)
            if not os.path.exists(fpath):
                continue
            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                code = f.read()

            ir = extract_error(code)
            self.assertEqual(ir.get("error_type"), expected.get("error_type"),
                             f"Error type mismatch in {fname}: {ir.get('error_type')} vs {expected.get('error_type')}")
            self.assertEqual(ir.get("line_number"), expected.get("line_number"),
                             f"Line number mismatch in {fname}: {ir.get('line_number')} vs {expected.get('line_number')}")

            # Verify traceback contains failing source line if applicable
            if expected.get("traceback_contains_failing_line") and ir.get("line_number"):
                line_no = ir["line_number"]
                code_lines = code.splitlines()
                if 1 <= line_no <= len(code_lines):
                    failing_line = code_lines[line_no - 1].strip()
                    tb = ir.get("traceback") or ""
                    self.assertIn(failing_line, tb, f"Traceback for {fname} missing source line: {failing_line}")

    def test_03_syntax_error_line(self):
        """3. SyntaxError sample: same line."""
        code = "def invalid_func(\n    x = 1\n"
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "error")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["error_type"], "SyntaxError")
        self.assertEqual(res["error"]["line_number"], 1)

    def test_04_infinite_loop_timeout(self):
        """4. while True: pass: 'timeout' in about the timeout; Flask client still answers afterwards."""
        t0 = time.perf_counter()
        res = run_in_sandbox("while True: pass", timeout=1.0)
        elapsed = time.perf_counter() - t0

        self.assertEqual(res["status"], "timeout")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["error_type"], "TimeoutError")
        self.assertLess(elapsed, 4.0, "Timeout took unreasonably long")

        # Test Flask test client still answers normally
        client = flask_app.app.test_client()
        resp = client.get("/api/version")
        self.assertEqual(resp.status_code, 200)

    def test_05_memory_hog(self):
        """5. memory hog: 'memory_exceeded' (allocate in 10 MB chunks and stop at 600 MB)."""
        code = """
chunks = []
for i in range(60):
    chunks.append(b"x" * (10 * 1024 * 1024))
"""
        # Set tight memory limit of 64 MB
        res = run_in_sandbox(code, memory_mb=64, timeout=5.0)
        self.assertIn(res["status"], ("memory_exceeded", "error"))
        if res["status"] == "memory_exceeded":
            self.assertEqual(res["error"]["error_type"], "MemoryError")

    def test_06_output_flood(self):
        """6. output flood: 'output_limit'; parent memory stays small."""
        code = "for _ in range(50000):\n    print('A' * 100)"
        proc_before = psutil.Process().memory_info().rss
        res = run_in_sandbox(code, max_output_kb=16, timeout=5.0)
        proc_after = psutil.Process().memory_info().rss

        self.assertEqual(res["status"], "output_limit")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["error_type"], "OutputLimitExceeded")
        # Ensure parent process memory did not balloon
        mem_diff_mb = (proc_after - proc_before) / (1024 * 1024)
        self.assertLess(mem_diff_mb, 50.0, "Parent memory grew excessively during output flood")

    def test_07_process_spawning_violation(self):
        """7. subprocess or os.system attempt via run_in_sandbox directly: violation 'process'."""
        code = "import subprocess\nsubprocess.Popen(['cmd.exe'])"
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "violation")
        kinds = [v["kind"] for v in res["violations"]]
        self.assertIn("process", kinds)

    def test_08_process_tree_kill_no_orphans(self):
        """8. process-tree kill: no orphans afterwards."""
        init_children = len(psutil.Process().children(recursive=True))
        res = run_in_sandbox("import time; time.sleep(10)", timeout=1.0)
        time.sleep(0.2)
        final_children = len(psutil.Process().children(recursive=True))
        self.assertEqual(res["status"], "timeout")
        self.assertEqual(final_children, init_children, "Orphan child processes remained after timeout kill")

    def test_09_socket_connect_violation(self):
        """9. socket connect to a closed local port: violation 'network' before connection."""
        code = "import socket\ns = socket.socket()\ns.connect(('127.0.0.1', 65432))"
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "violation")
        kinds = [v["kind"] for v in res["violations"]]
        self.assertIn("network", kinds)

    def test_10_file_write_isolation(self):
        """10. write outside folder: violation 'file_write_outside'; write inside works and file is cleaned."""
        # Write outside
        outside_path = os.path.join(r"C:\Windows\Temp", "illegal_sandbox_write.txt")
        code_outside = f"with open(r'{outside_path}', 'w') as f: f.write('bad')"
        res_out = run_in_sandbox(code_outside)
        self.assertEqual(res_out["status"], "violation")
        kinds = [v["kind"] for v in res_out["violations"]]
        self.assertIn("file_write_outside", kinds)

        # Write inside
        code_inside = """
with open('local_temp.txt', 'w') as f:
    f.write('inside allowed')
with open('local_temp.txt', 'r') as f:
    content = f.read()
print('READ:', content)
"""
        res_in = run_in_sandbox(code_inside)
        self.assertEqual(res_in["status"], "ok")
        self.assertIn("inside allowed", res_in["stdout"])

    def test_11_environment_secrets_isolation(self):
        """11. parent has FAKE_SECRET_TEST=abc123 and GEMINI_API_KEY=fake; child sees neither."""
        with unittest.mock.patch.dict(os.environ, {
            "FAKE_SECRET_TEST": "abc123secret",
            "GEMINI_API_KEY": "fake_gemini_key_xyz",
            "GROQ_API_KEY": "fake_groq_key_123"
        }):
            code = "import os\nprint('ENV_KEYS:', sorted(list(os.environ.keys())))"
            res = run_in_sandbox(code)
            self.assertEqual(res["status"], "ok")
            self.assertNotIn("FAKE_SECRET_TEST", res["stdout"])
            self.assertNotIn("GEMINI_API_KEY", res["stdout"])
            self.assertNotIn("GROQ_API_KEY", res["stdout"])
            self.assertNotIn("abc123secret", res["stdout"])

    def test_12_non_interactive_input_eof(self):
        """12. input(): EOFError, no hang."""
        code = "name = input('Enter name: ')\nprint(name)"
        t0 = time.perf_counter()
        res = run_in_sandbox(code, timeout=3.0)
        elapsed = time.perf_counter() - t0
        self.assertLess(elapsed, 2.0, "input() hung waiting for stdin")
        self.assertEqual(res["status"], "error")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["error_type"], "EOFError")

    def test_13_tamper_resistant_nonce_channel(self):
        """13. forged result block and delimiters in user output ignored; sys.argv inspection clean."""
        code = """
import sys
print("\\n---SANDBOX_RESULT_fake123---\\n{\\"status\\": \\"ok\\", \\"violations\\": []}\\n---SANDBOX_RESULT_fake123---\\n")
print('ARGV_LEN:', len(sys.argv))
print('ARGV_0:', sys.argv[0])
raise ValueError('Real error')
"""
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "error")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["error_type"], "ValueError")
        self.assertIn("ARGV_LEN: 1", res["stdout"])
        self.assertIn("ARGV_0: <string>", res["stdout"])

    def test_14_no_leftover_temp_folders(self):
        """14. no leftover sandbox folders after 20 runs including timeouts."""
        created_dirs = []
        for i in range(20):
            if i % 3 == 0:
                res = run_in_sandbox("import os\nprint('CWD:' + os.getcwd())\nwhile True: pass", timeout=0.2)
            elif i % 3 == 1:
                res = run_in_sandbox("import os\nprint('CWD:' + os.getcwd())\n1 / 0")
            else:
                res = run_in_sandbox("import os\nprint('CWD:' + os.getcwd())")

            for line in res.get("stdout", "").splitlines():
                if line.startswith("CWD:"):
                    created_dirs.append(line[4:].strip())

        time.sleep(0.3)
        lingering = [d for d in created_dirs if os.path.exists(d)]
        self.assertEqual(len(lingering), 0, f"Lingering sandbox temporary folders found: {lingering}")

    def test_15_parallel_concurrency_safety(self):
        """15. five parallel runs: all correct."""
        snippets = [
            ("print('P1')", "ok", "P1"),
            ("print(10 + 20)", "ok", "30"),
            ("1 / 0", "error", None),
            ("def bad_syntax(", "error", None),
            ("print('P5: done')", "ok", "P5: done")
        ]

        def _exec(item):
            code, exp_status, exp_out = item
            return run_in_sandbox(code), exp_status, exp_out

        with ThreadPoolExecutor(max_workers=5) as executor:
            results = list(executor.map(_exec, snippets))

        for res, exp_status, exp_out in results:
            self.assertEqual(res["status"], exp_status)
            if exp_out:
                self.assertIn(exp_out, res["stdout"])

    def test_16_fail_closed_on_bad_interpreter(self):
        """16. fail closed (test parameter pointing to a bad interpreter): 'sandbox_failure', no exec in server."""
        bad_bin = "C:\\nonexistent_python_binary_xyz.exe"
        res = run_in_sandbox("print('Should never run')", _test_python_bin=bad_bin)
        self.assertEqual(res["status"], "sandbox_failure")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["error_type"], "SandboxFailure")

    def test_17_flask_api_contract_all_statuses(self):
        """17. Flask test client: /api/execute and /api/analyze return valid JSON across statuses."""
        client = flask_app.app.test_client()

        # 1. OK execution
        resp_ok = client.post("/api/execute", json={"code": "print('Clean run')"})
        self.assertEqual(resp_ok.status_code, 200)
        data_ok = resp_ok.get_json()
        self.assertIn("Clean run", data_ok.get("output", ""))
        self.assertEqual(data_ok.get("status"), "ok")
        self.assertIn("sandbox_status", data_ok)

        # 2. Error execution
        resp_err = client.post("/api/execute", json={"code": "1 / 0"})
        self.assertEqual(resp_err.status_code, 200)
        data_err = resp_err.get_json()
        self.assertIn("ZeroDivisionError", data_err.get("output", ""))
        self.assertEqual(data_err.get("status"), "error")

        # 3. Timeout execution
        resp_to = client.post("/api/execute", json={"code": "while True: pass"})
        self.assertEqual(resp_to.status_code, 200)
        data_to = resp_to.get_json()
        self.assertIn("TimeoutError", data_to.get("output", ""))
        self.assertEqual(data_to.get("status"), "timeout")

        # 4. /api/analyze with normal error
        resp_ana = client.post("/api/analyze", json={"code": "x = 10\nprint(y)"})
        self.assertEqual(resp_ana.status_code, 200)
        data_ana = resp_ana.get_json()
        self.assertEqual(data_ana.get("status"), "error_intercepted")
        self.assertIn("sandbox_status", data_ana)

    def test_18_ui_contract_status_handling(self):
        """18. UI contract: static check that index.html handles every status string without undefined field."""
        index_path = os.path.join(_PROJECT_ROOT, "templates", "index.html")
        with open(index_path, "r", encoding="utf-8") as f:
            html = f.read()

        expected_statuses = [
            "error_intercepted",
            "security_blocked",
            "timeout",
            "memory_exceeded",
            "output_limit",
            "violation",
            "sandbox_failure",
            "success"
        ]

        for st in expected_statuses:
            self.assertIn(st, html, f"UI template index.html missing explicit handler for status '{st}'")

    def test_19_no_exec_eval_in_server_runtime(self):
        """19. Grep of runtime modules proves no direct exec( or eval( on user code remains in server process."""
        runtime_files = [
            "app.py",
            "error_extractor.py",
            "nlp_explainer.py",
            "main.py",
            "ir_generator.py",
            "security_analyzer.py"
        ]

        forbidden_patterns = [
            re.compile(r"\bexec\s*\(\s*(?:code|user_code|patched_code|code_to_run|code_str)"),
            re.compile(r"\beval\s*\(\s*(?:code|user_code|patched_code|code_to_run|code_str)")
        ]

        for fname in runtime_files:
            fpath = os.path.join(_PROJECT_ROOT, fname)
            if not os.path.exists(fpath):
                continue
            with open(fpath, "r", encoding="utf-8") as f:
                lines = f.readlines()
            for idx, line in enumerate(lines, 1):
                # Ignore model.eval() or comments
                if "model.eval()" in line or line.strip().startswith("#"):
                    continue
                for pat in forbidden_patterns:
                    match = pat.search(line)
                    self.assertIsNone(match, f"Found direct exec/eval of user code in {fname}:{idx}: {line.strip()}")

    def test_20_utf8_integrity(self):
        """20. UTF-8: print('héllo ✓') comes back exactly under -I."""
        code = "print('héllo ✓ 日本語 🚀')"
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "ok")
        self.assertIn("héllo ✓ 日本語 🚀", res["stdout"])

    def test_21_traceback_contains_failing_source_line(self):
        """21. A runtime error's traceback contains the failing source line text."""
        code = "alpha = 10\nbeta = 0\nresult = alpha / beta\nprint(result)"
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "error")
        self.assertIsNotNone(res["error"])
        self.assertEqual(res["error"]["line_number"], 3)
        self.assertIn("result = alpha / beta", res["error"]["traceback"])

    def test_22_job_object_limits_active(self):
        """22. Sandbox works under Job Object (process limit and memory applied on Windows)."""
        res = run_in_sandbox("print('Job object check')")
        self.assertEqual(res["status"], "ok")
        if os.name == 'nt':
            self.assertIn("Windows Job Object active", res["sandbox"]["notes"])

    def test_23_security_analyzer_and_sandbox_interplay(self):
        """23. API blocks os.system before execution; run_in_sandbox directly reports violation."""
        code = "import os\nos.system('echo dangerous')"

        # 1. Through security analyzer (API path)
        sec = security_analyzer.SecurityAnalyzer()
        vulns = sec.scan_code(code)
        self.assertTrue(any(v.get("type") == "Command Injection" for v in vulns))

        # 2. Through run_in_sandbox directly (Runtime path)
        res = run_in_sandbox(code)
        self.assertEqual(res["status"], "violation")
        kinds = [v["kind"] for v in res["violations"]]
        self.assertIn("process", kinds)


if __name__ == "__main__":
    unittest.main()
