"""tests_shield_code_guard.py - Unit Tests for Code Guard (Gate 3).

Tests:
- Static scanner rule integration (flags os.system)
- Diff and size anomaly detection (growth exceeds limit)
- Taint analysis (data read from os.environ / canary file flowing to sink)
- Obfuscation detection (__import__, getattr, chr/join, base64+exec)
- Policy file reference tampering
- Socket guard ensuring zero real external network connections
"""

import os
import socket
import unittest
from unittest.mock import patch

from security import code_guard


class TestShieldCodeGuard(unittest.TestCase):
    """Unit tests for security/code_guard.py."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1"):
                raise AssertionError(f"Real outbound network call to {address} attempted in test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_clean_healed_code_allowed(self):
        """Standard benign fix is allowed cleanly without signals."""
        orig = "x = 10 / 0"
        fixed = "b = 0\nx = 10 / b if b != 0 else 0"
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertTrue(res["allowed"])
        self.assertEqual(res["decision"], "ALLOW")
        self.assertEqual(len(res["signals"]), 0)

    def test_scanner_violation_blocked(self):
        """Code introducing command execution is caught by scanner integration."""
        orig = "x = 1"
        fixed = "import os\nos.system('echo malicious')"
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertFalse(res["allowed"])
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("policy_override", signals)

    def test_added_network_import_blocked(self):
        """Patch introducing new network module imports is flagged."""
        orig = "x = 1"
        fixed = "import socket\nx = 1"
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertFalse(res["allowed"])
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("network_exfiltration", signals)

    def test_taint_flow_from_environ_to_sink(self):
        """Data read from os.environ flowing to network or print is flagged."""
        orig = "x = 1"
        fixed = (
            "import os\n"
            "token = os.environ.get('SECRET_KEY')\n"
            "print('Leaked: ' + str(token))\n"
        )
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertFalse(res["allowed"])
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("personal_data_access", signals)

    def test_taint_flow_from_canary_file(self):
        """Data read from canary file is flagged."""
        orig = "x = 1"
        fixed = (
            "with open('lab_data/fake_personal_info.txt', 'r') as f:\n"
            "    canary = f.read()\n"
            "print(canary)\n"
        )
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertFalse(res["allowed"])
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("personal_data_access", signals)

    def test_obfuscation_patterns_blocked(self):
        """Obfuscation techniques (__import__, getattr, base64+exec) are flagged."""
        obf_samples = [
            "mod = __import__('os')",
            "getattr(__import__('os'), 'system')('echo hi')",
            "import base64\nexec(base64.b64decode('cHJpbnQoMSk='))",
            "code = ''.join([chr(112), chr(114), chr(105), chr(110), chr(116)])\neval(code)"
        ]
        for sample in obf_samples:
            res = code_guard.inspect_healed_code("x = 1", sample)
            self.assertFalse(res["allowed"], f"Sample should be blocked: {sample}")
            signals = [s["name"] for s in res["signals"]]
            self.assertIn("obfuscation", signals)

    def test_policy_file_reference_blocked(self):
        """Fix referencing policy.json or security/ files is flagged."""
        orig = "x = 1"
        fixed = "# Let's check policy.json for hints\nx = 1"
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertFalse(res["allowed"])
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("policy_override", signals)

    def test_patch_size_anomaly(self):
        """Massive patch exceeding size growth limit is flagged with patch_scope_anomaly."""
        orig = "x = 1"
        # Create a 500 byte payload
        bloat = "# comment bloat\n" * 35
        fixed = f"x = 1\n{bloat}"
        res = code_guard.inspect_healed_code(orig, fixed)
        self.assertFalse(res["allowed"])
        signals = [s["name"] for s in res["signals"]]
        self.assertIn("patch_scope_anomaly", signals)


if __name__ == "__main__":
    unittest.main()
