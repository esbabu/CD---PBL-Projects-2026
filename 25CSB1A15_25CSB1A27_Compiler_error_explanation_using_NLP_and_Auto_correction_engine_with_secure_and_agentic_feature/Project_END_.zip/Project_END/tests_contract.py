"""tests_contract.py

Regression test harness comparing live application behavior against benchmark/golden_before.json.
Validates Flask routes, JSON response contracts, frontend HTML element IDs, fetch endpoints,
and execution/fix invariants across standard error snippets.
"""

import unittest
import os
import sys
import json
import re
import socket
import subprocess
import time
import urllib.request
import urllib.error
import tempfile


def get_free_port():
    for p in range(5100, 5200):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('127.0.0.1', p))
                return p
            except OSError:
                continue
    return 5150


class TestContractAndRegression(unittest.TestCase):
    server_proc = None
    port = None
    base_url = None
    golden = None

    @classmethod
    def setUpClass(cls):
        golden_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "benchmark", "golden_before.json")
        if not os.path.exists(golden_path):
            raise RuntimeError(f"Golden benchmark file not found at {golden_path}. Run generate_golden.py first.")
        
        with open(golden_path, "r", encoding="utf-8") as f:
            cls.golden = json.load(f)

        cls.port = get_free_port()
        cls.base_url = f"http://127.0.0.1:{cls.port}"

        env = os.environ.copy()
        env["AUTOFIX_AI"] = "0"
        env["LLM_DISABLED"] = "1"
        env["CODECARBON_SAVE_TO_FILE"] = "false"
        env["CODECARBON_LOG_LEVEL"] = "error"
        env["PYTHONUTF8"] = "1"

        server_code = f"""
import app, sys, os
from app import app as flask_app
flask_app.run(host="127.0.0.1", port={cls.port}, debug=False, use_reloader=False)
"""
        cls.server_proc = subprocess.Popen(
            [r"C:\Users\lsrin\venvs\toc_project\Scripts\python.exe", "-c", server_code],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8"
        )

        started = False
        start_time = time.time()
        while time.time() - start_time < 10.0:
            try:
                req = urllib.request.Request(f"{cls.base_url}/api/version")
                with urllib.request.urlopen(req, timeout=1.0) as resp:
                    if resp.status == 200:
                        started = True
                        break
            except Exception:
                time.sleep(0.2)

        if not started:
            cls.tearDownClass()
            raise RuntimeError(f"Server on port {cls.port} failed to start within timeout.")

    @classmethod
    def tearDownClass(cls):
        if cls.server_proc:
            try:
                cls.server_proc.terminate()
                cls.server_proc.wait(timeout=3)
            except Exception:
                cls.server_proc.kill()
            finally:
                if cls.server_proc.stdout:
                    cls.server_proc.stdout.close()
                if cls.server_proc.stderr:
                    cls.server_proc.stderr.close()
            cls.server_proc = None

    def post_json(self, endpoint, payload):
        req = urllib.request.Request(
            f"{self.base_url}{endpoint}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json; charset=utf-8"},
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                return resp.status, json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode("utf-8"))

    def get_json(self, endpoint):
        req = urllib.request.Request(f"{self.base_url}{endpoint}")
        with urllib.request.urlopen(req, timeout=5.0) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))

    def test_01_routes_and_methods(self):
        """Verify all routes in golden_before.json are present with required HTTP methods."""
        import app
        current_routes = {}
        for rule in app.app.url_map.iter_rules():
            current_routes[str(rule)] = sorted(list(rule.methods))

        for r_entry in self.golden["routes"]:
            rule_str = r_entry["rule"]
            expected_methods = set(r_entry["methods"])
            self.assertIn(rule_str, current_routes, f"Missing route: {rule_str}")
            self.assertTrue(
                expected_methods.issubset(set(current_routes[rule_str])),
                f"Route {rule_str} missing methods. Expected {expected_methods}, found {current_routes[rule_str]}"
            )

    def test_02_api_response_schema_keys(self):
        """Verify JSON response keys for standard endpoints match or expand golden baseline."""
        # /api/files
        status, res_files = self.get_json("/api/files")
        self.assertEqual(status, 200)
        for k in self.golden["route_keys"]["/api/files"]:
            self.assertIn(k, res_files)

        # /api/version
        status, res_ver = self.get_json("/api/version")
        self.assertEqual(status, 200)
        for k in self.golden["route_keys"]["/api/version"]:
            self.assertIn(k, res_ver)

        # /api/analyze
        status, res_ana = self.post_json("/api/analyze", {"code": 'print("hello")'})
        self.assertEqual(status, 200)
        for k in self.golden["route_keys"]["/api/analyze"]:
            self.assertIn(k, res_ana)

    def test_03_frontend_html_element_ids_and_fetches(self):
        """Verify HTML element IDs referenced in JS exist in HTML, and fetch URLs match routes."""
        import app
        valid_endpoints = {str(r) for r in app.app.url_map.iter_rules()}

        for tmpl, audit_data in self.golden["frontend_audit"].items():
            tmpl_path = os.path.join("templates", tmpl)
            self.assertTrue(os.path.exists(tmpl_path), f"Template {tmpl_path} missing")
            with open(tmpl_path, "r", encoding="utf-8") as f:
                content = f.read()

            html_ids = set(re.findall(r'id=["\']([a-zA-Z0-9_\-]+)["\']', content))
            scripts = re.findall(r'<script(?:\s+[^>]*)?>(.*?)</script>', content, flags=re.DOTALL)
            js_code = "\n".join(scripts)

            by_id = set(re.findall(r'getElementById\(["\']([a-zA-Z0-9_\-]+)["\']\)', js_code))
            query_id = set(re.findall(r'querySelector\(["\']#([a-zA-Z0-9_\-]+)["\']\)', js_code))
            query_all_id = set(re.findall(r'querySelectorAll\(["\']#([a-zA-Z0-9_\-]+)["\']\)', js_code))
            referenced = by_id | query_id | query_all_id

            missing = referenced - html_ids
            self.assertEqual(len(missing), 0, f"Template {tmpl} has missing HTML element IDs: {missing}")

            # Check fetch calls match valid routes
            for match in re.finditer(r'fetch\(["\']([^"\']+)["\']', js_code):
                url = match.group(1).split("?")[0]
                self.assertIn(url, valid_endpoints, f"Template {tmpl} fetches unmapped endpoint {url}")

    def test_04_golden_cases_regression(self):
        """Verify no regressions across the 18 golden cases."""
        golden_cases = self.golden["golden_cases"]
        improvements = []

        for cid, g_info in golden_cases.items():
            code = g_info["input_code"]
            status_code, body = self.post_json("/api/analyze", {"code": code})
            self.assertEqual(
                status_code, g_info["http_status"],
                f"Case {cid} status code mismatch: got {status_code}, expected {g_info['http_status']}"
            )

            curr_status = body.get("status")
            curr_fix_status = body.get("fix_status")
            curr_fixed_code = body.get("fixed_code", "")
            curr_raw = body.get("raw_text", "")

            # Security invariant: C4 must NEVER execute
            if cid == "C4":
                self.assertEqual(curr_status, "security_blocked", f"Case C4 was not security blocked")
                self.assertNotIn("hi", curr_raw.splitlines(), f"Case C4 executed os.system!")

            # UTF-8 invariant: C5a must decode clean
            if cid == "C5a":
                self.assertIn("héllo ✓", curr_raw, f"Case C5a mangled UTF-8")
                self.assertNotIn("Ã", curr_raw)
                self.assertNotIn("â", curr_raw)

            # Regression check on previously fixed cases (A1, A2, A3, A4, B4)
            if g_info.get("fix_status") == "applied" and g_info.get("sandbox_result", {}).get("runs_clean"):
                self.assertEqual(
                    curr_fix_status, "applied",
                    f"Regression in case {cid}: previously applied fix is now {curr_fix_status}"
                )
                # Verify current fix runs clean in sandbox
                with tempfile.NamedTemporaryFile(suffix=".py", mode="w", encoding="utf-8", delete=False) as tf:
                    tf.write(curr_fixed_code)
                    tf_path = tf.name
                try:
                    r = subprocess.run(
                        [r"C:\Users\lsrin\venvs\toc_project\Scripts\python.exe", tf_path],
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    self.assertEqual(r.returncode, 0, f"Regression in case {cid}: fixed code does not run clean")
                finally:
                    if os.path.exists(tf_path):
                        os.remove(tf_path)

            # Check if an unfixable case became fixed (Improvement)
            if g_info.get("fix_status") != "applied" and curr_fix_status == "applied":
                improvements.append(cid)

        if improvements:
            print(f"\n[Contract Check] Improvements detected (cases newly fixed): {improvements}")


if __name__ == '__main__':
    unittest.main()
