# Program 02: ZeroDivisionError (Variable in loop)
# Expected: Fixable by rule/agent
divisors = [10, 5, 2, 0]
results = []
for d in divisors:
    results.append(100 / d)
print('Results:', results)
