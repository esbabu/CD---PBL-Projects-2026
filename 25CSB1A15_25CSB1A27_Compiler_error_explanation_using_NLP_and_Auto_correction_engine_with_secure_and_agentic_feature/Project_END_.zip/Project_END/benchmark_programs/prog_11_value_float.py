# Program 11: ValueError (Invalid string for float conversion)
# Expected: Non-fixable by rule (semantic runtime input issue)
raw_input = 'twenty-five-point-five'
val = float(raw_input)
print('Float:', val)
