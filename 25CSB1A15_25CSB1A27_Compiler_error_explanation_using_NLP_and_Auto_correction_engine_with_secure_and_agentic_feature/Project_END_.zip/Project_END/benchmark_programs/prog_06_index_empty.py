# Program 06: IndexError (Pop/index on empty container)
# Expected: Fixable
queue = []
item = queue[0]
print('Item:', item)
