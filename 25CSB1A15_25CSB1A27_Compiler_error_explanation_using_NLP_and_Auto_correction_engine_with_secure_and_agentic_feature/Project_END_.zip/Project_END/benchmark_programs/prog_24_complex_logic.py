# Program 24: Logic / Semantic Non-Fixable (No runtime exception, wrong output)
# Expected: Non-fixable (program exits 0, no diagnostic trigger)
def check_is_even(num):
    # Bug: returns True for odd, False for even
    return num % 2 == 1

print('Is 4 even?:', check_is_even(4))
