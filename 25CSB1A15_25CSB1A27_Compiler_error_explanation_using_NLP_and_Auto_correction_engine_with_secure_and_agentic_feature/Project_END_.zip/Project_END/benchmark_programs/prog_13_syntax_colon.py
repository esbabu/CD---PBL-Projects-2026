# Program 13: SyntaxError (Missing colon on if statement)
# Expected: Fixable by syntax recovery / token repair
threshold = 50
score = 75
if score > threshold
    print('Passed!')
