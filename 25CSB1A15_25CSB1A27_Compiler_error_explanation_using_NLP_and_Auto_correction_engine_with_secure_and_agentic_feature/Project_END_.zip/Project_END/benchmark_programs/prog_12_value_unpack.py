# Program 12: ValueError (Too many values to unpack)
# Expected: Non-fixable by rule (structural mismatch)
record = (1, 'Alice', 'Engineer', 120000)
user_id, name, title = record
print(user_id, name, title)
