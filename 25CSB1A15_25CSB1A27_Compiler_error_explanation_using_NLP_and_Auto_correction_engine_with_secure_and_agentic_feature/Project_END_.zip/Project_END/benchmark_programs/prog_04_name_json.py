# Program 04: NameError (Missing standard json import)
# Expected: Fixable by standard library import injection
data = {'user': 'alice', 'active': True}
payload = json.dumps(data)
print('JSON payload:', payload)
