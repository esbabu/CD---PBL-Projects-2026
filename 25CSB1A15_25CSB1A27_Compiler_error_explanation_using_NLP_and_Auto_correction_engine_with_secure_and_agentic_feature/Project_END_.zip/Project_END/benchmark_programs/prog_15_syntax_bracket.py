# Program 15: SyntaxError (Unclosed square bracket)
# Expected: Fixable by bracket checker / recovery
coordinates = [12.5, 45.2, 88.0
print('Coordinates loaded')
