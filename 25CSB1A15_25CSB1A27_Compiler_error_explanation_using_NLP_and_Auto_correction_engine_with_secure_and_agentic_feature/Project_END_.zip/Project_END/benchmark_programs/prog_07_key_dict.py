# Program 07: KeyError (Missing dictionary key)
# Expected: Fixable via dict.get or default
user_record = {'name': 'Bob', 'role': 'admin'}
email = user_record['email']
print('Email:', email)
