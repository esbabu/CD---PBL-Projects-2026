# Program 14: SyntaxError (Python 2 print statement)
# Expected: Fixable by print function transform
message = 'Hello world from legacy python'
print message
