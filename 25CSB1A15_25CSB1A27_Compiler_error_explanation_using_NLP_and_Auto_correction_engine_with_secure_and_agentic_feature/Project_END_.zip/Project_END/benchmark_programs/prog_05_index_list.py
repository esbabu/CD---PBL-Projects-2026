# Program 05: IndexError (Static out-of-bounds list access)
# Expected: Fixable by bounds check or list wrap
scores = [95, 88, 72, 90]
top_score = scores[10]
print('Top score:', top_score)
