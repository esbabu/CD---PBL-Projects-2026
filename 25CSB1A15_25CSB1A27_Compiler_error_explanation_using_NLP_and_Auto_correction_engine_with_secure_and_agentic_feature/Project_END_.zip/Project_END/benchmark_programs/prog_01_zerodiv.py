# Program 01: ZeroDivisionError (Direct numeric constant division)
# Expected: Fixable by rule (safe default or denominator check)
def compute_ratio(a, b):
    return a / b

val = compute_ratio(100, 0)
print('Result:', val)
