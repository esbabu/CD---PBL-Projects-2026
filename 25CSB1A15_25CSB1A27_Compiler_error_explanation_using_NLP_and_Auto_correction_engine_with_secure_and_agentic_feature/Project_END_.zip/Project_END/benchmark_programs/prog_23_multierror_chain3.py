# Program 23: Multi-Error Chain 3 (Syntax unclosed bracket followed by ZeroDivision)
# Expected: Fixable across 2 repair rounds
items = [10, 20, 30
print('Items count:', len(items))
rate = 50 / 0
print('Rate:', rate)
