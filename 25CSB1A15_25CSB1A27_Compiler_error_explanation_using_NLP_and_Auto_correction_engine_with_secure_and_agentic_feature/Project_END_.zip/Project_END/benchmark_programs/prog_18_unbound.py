# Program 18: UnboundLocalError (Local variable referenced before assignment)
# Expected: Fixable by global/nonlocal insertion
counter = 0

def increment():
    counter = counter + 1
    return counter

print(increment())
