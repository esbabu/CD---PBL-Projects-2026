# Program 09: TypeError (String + Integer concatenation)
# Expected: Fixable by string conversion str(...)
prefix = 'Item count: '
count = 42
msg = prefix + count
print(msg)
