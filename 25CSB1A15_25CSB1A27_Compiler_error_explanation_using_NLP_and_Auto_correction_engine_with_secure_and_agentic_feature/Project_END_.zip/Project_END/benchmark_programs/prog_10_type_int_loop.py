# Program 10: TypeError (Iterating directly over integer)
# Expected: Fixable by rewrite to range(...)
for i in 10:
    print('Iteration:', i)
