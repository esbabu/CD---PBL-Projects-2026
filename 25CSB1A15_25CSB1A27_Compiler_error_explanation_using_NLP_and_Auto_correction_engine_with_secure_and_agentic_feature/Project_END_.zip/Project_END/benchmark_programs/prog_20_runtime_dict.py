# Program 20: RuntimeError (Dictionary changed size during iteration)
# Expected: Fixable by wrapping in list(...)
registry = {'a': 1, 'b': 2, 'c': 3}
for k in registry:
    if k == 'b':
        registry.pop(k)
print('Registry:', registry)
