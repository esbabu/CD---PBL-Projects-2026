# Program 21: Multi-Error Chain 1 (ZeroDivision followed by TypeError)
# Expected: Fixable across 2 repair rounds
a = 100 / 0
label = 'Result: ' + 50
print(label)
