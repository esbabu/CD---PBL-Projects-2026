# Program 08: KeyError (Nested dictionary lookup)
# Expected: Fixable
config = {'database': {'host': 'localhost'}}
port = config['database']['port']
print('Port:', port)
