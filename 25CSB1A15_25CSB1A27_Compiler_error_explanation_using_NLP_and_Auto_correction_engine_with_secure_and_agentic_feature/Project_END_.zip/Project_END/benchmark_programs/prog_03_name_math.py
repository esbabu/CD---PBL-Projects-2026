# Program 03: NameError (Missing standard math import)
# Expected: Fixable by standard library import injection
def calc_hypotenuse(a, b):
    return math.sqrt(a**2 + b**2)

print('Hypotenuse:', calc_hypotenuse(3, 4))
