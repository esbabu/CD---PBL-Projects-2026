# Program 17: RecursionError (Linear countdown without base case)
# Expected: Fixable by recursive base case injection
def countdown(n):
    return countdown(n - 1)

print('Countdown:', countdown(5))
