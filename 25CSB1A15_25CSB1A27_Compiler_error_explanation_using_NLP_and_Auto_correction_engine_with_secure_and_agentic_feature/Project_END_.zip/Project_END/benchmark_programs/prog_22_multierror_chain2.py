# Program 22: Multi-Error Chain 2 (Missing math import followed by IndexError)
# Expected: Fixable across 2 repair rounds
root = math.sqrt(64)
arr = [1, 2, 3]
elem = arr[10]
print(root, elem)
