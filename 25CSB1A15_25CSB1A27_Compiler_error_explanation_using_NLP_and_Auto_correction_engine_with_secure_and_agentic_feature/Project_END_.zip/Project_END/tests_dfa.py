"""tests_dfa.py - Formal equivalence and unit tests for hand-written DFAs.

Tests Feature 5 (TOC Week 3):
- Exhaustive equivalence testing of IDENT_DFA against regex [A-Za-z_][A-Za-z0-9_]* up to length 5.
- Exhaustive equivalence testing of NUMBER_DFA against regex [0-9]+(\\.[0-9]+)? up to length 5.
- Exhaustive equivalence testing of INT_UNDERSCORE_DFA against regex [0-9](_?[0-9])* up to length 5.
- Trace verification, state transition correctness, dead state trapping.
"""

from __future__ import annotations

import itertools
import re
import unittest

from dfa import DFA, IDENT_DFA, INT_UNDERSCORE_DFA, NUMBER_DFA


class TestDFAEngine(unittest.TestCase):
    """Test suite for explicit DFA engine and hand-written automata."""

    def test_ident_dfa_exhaustive_equivalence(self) -> None:
        """Exhaustively verify IDENT_DFA against regex [A-Za-z_][A-Za-z0-9_]* up to length 5."""
        alphabet = ["a", "Z", "0", "9", "_", ".", "$", " ", "ñ"]
        regex = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
        checked_count = 0

        for length in range(1, 6):
            for chars in itertools.product(alphabet, repeat=length):
                s = "".join(chars)
                dfa_result = IDENT_DFA.accepts(s)
                regex_result = bool(regex.match(s))
                self.assertEqual(
                    dfa_result,
                    regex_result,
                    f"Mismatch on string {repr(s)}: DFA={dfa_result}, regex={regex_result}",
                )
                checked_count += 1

        print(
            f"[DFA Equivalence] IDENT_DFA exhaustively checked against regex on {checked_count} strings (length 1..5). 100% agreement."
        )
        print("Note: This is an exhaustive check up to a bound of length 5, not a general proof.")

    def test_number_dfa_exhaustive_equivalence(self) -> None:
        """Exhaustively verify NUMBER_DFA against regex [0-9]+(\\.[0-9]+)? up to length 5."""
        alphabet = ["0", "7", ".", "a", "_", "-", " "]
        regex = re.compile(r"^[0-9]+(\.[0-9]+)?$")
        checked_count = 0

        for length in range(1, 6):
            for chars in itertools.product(alphabet, repeat=length):
                s = "".join(chars)
                dfa_result = NUMBER_DFA.accepts(s)
                regex_result = bool(regex.match(s))
                self.assertEqual(
                    dfa_result,
                    regex_result,
                    f"Mismatch on string {repr(s)}: DFA={dfa_result}, regex={regex_result}",
                )
                checked_count += 1

        print(
            f"[DFA Equivalence] NUMBER_DFA exhaustively checked against regex on {checked_count} strings (length 1..5). 100% agreement."
        )
        print("Note: This is an exhaustive check up to a bound of length 5, not a general proof.")

    def test_int_underscore_dfa_exhaustive_equivalence(self) -> None:
        """Exhaustively verify INT_UNDERSCORE_DFA against regex [0-9](_?[0-9])* up to length 5."""
        alphabet = ["0", "9", "_", "x", "."]
        regex = re.compile(r"^[0-9](_?[0-9])*$")
        checked_count = 0

        for length in range(1, 6):
            for chars in itertools.product(alphabet, repeat=length):
                s = "".join(chars)
                dfa_result = INT_UNDERSCORE_DFA.accepts(s)
                regex_result = bool(regex.match(s))
                self.assertEqual(
                    dfa_result,
                    regex_result,
                    f"Mismatch on string {repr(s)}: DFA={dfa_result}, regex={regex_result}",
                )
                checked_count += 1

        print(
            f"[DFA Equivalence] INT_UNDERSCORE_DFA checked against regex on {checked_count} strings (length 1..5). 100% agreement."
        )

    def test_trace_generation(self) -> None:
        """Verify that trace produces accurate step-by-step state logs."""
        trace = IDENT_DFA.trace("var_1")
        self.assertTrue(trace["accepted"])
        self.assertEqual(trace["final_state"], "q_accept")
        self.assertEqual(len(trace["steps"]), 5)
        self.assertEqual(trace["steps"][0]["from_state"], "q0")
        self.assertEqual(trace["steps"][0]["to_state"], "q_accept")

        # Invalid trace entering dead state
        bad_trace = IDENT_DFA.trace("1var")
        self.assertFalse(bad_trace["accepted"])
        self.assertEqual(bad_trace["final_state"], "DEAD")

    def test_custom_dfa_validation(self) -> None:
        """Verify invalid DFA configurations raise ValueError."""
        with self.assertRaises(ValueError):
            DFA(
                states={"q0", "q1"},
                alphabet_desc="test",
                char_classifier=lambda c: "X",
                transitions={},
                start_state="non_existent",
                accepting_states={"q1"},
            )
        with self.assertRaises(ValueError):
            DFA(
                states={"q0", "q1"},
                alphabet_desc="test",
                char_classifier=lambda c: "X",
                transitions={},
                start_state="q0",
                accepting_states={"non_existent"},
            )


if __name__ == "__main__":
    unittest.main()
