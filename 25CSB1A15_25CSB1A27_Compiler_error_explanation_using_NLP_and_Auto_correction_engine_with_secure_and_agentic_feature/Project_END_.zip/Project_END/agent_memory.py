"""agent_memory.py - Bounded in-memory fix cache and attempt tracking.

Thread-safe, bounded LRU memory tracking tried and rejected fix hashes per original code hash.
Crucially, this module stores ONLY hashes, counters, and error-type names.
It NEVER stores free-form user instruction text, comment text, error messages,
or raw code bodies, mitigating indirect prompt injection and memory-poisoning attacks (AT-16).
"""

import collections
import hashlib
import threading
from typing import Dict, Optional, Set, Tuple

# Server-side bounded cache capacity (LRU eviction)
MEMORY_CAPACITY = 500


class AgentMemory:
    """Thread-safe bounded in-memory record of fix attempts and signatures."""

    def __init__(self, capacity: int = MEMORY_CAPACITY):
        self.capacity = max(10, capacity)
        self._lock = threading.Lock()
        # OrderedDict mapping original_code_sha256 -> Dict of metadata
        self._store: collections.OrderedDict[str, Dict] = collections.OrderedDict()

    def _ensure_entry(self, orig_hash: str) -> Dict:
        """Helper to get or initialize an entry while maintaining LRU ordering."""
        if orig_hash in self._store:
            self._store.move_to_end(orig_hash)
            return self._store[orig_hash]
        
        # Evict oldest if capacity exceeded
        while len(self._store) >= self.capacity:
            self._store.popitem(last=False)

        entry = {
            "tried_hashes": set(),
            "rejected_hashes": set(),
            "error_signatures": set(),
            "attempts_count": 0
        }
        self._store[orig_hash] = entry
        return entry

    def record_attempt(self, orig_hash: str, fix_hash: str, error_type: Optional[str] = None) -> None:
        """Record that a fix hash was attempted for a given original code hash."""
        if not orig_hash or not fix_hash:
            return
        with self._lock:
            entry = self._ensure_entry(orig_hash)
            entry["tried_hashes"].add(fix_hash)
            entry["attempts_count"] += 1
            if error_type and isinstance(error_type, str):
                # Clean error-type string to alphanumeric + underscores only
                clean_type = "".join(c for c in error_type if c.isalnum() or c == "_")[:64]
                if clean_type:
                    entry["error_signatures"].add(clean_type)

    def record_rejected(self, orig_hash: str, fix_hash: str) -> None:
        """Record that a fix hash was rejected (by scan, memory, or human)."""
        if not orig_hash or not fix_hash:
            return
        with self._lock:
            entry = self._ensure_entry(orig_hash)
            entry["rejected_hashes"].add(fix_hash)

    def has_tried(self, orig_hash: str, fix_hash: str) -> bool:
        """Check if a fix hash has already been attempted or rejected for this code."""
        if not orig_hash or not fix_hash:
            return False
        with self._lock:
            if orig_hash not in self._store:
                return False
            self._store.move_to_end(orig_hash)
            entry = self._store[orig_hash]
            return (fix_hash in entry["tried_hashes"]) or (fix_hash in entry["rejected_hashes"])

    def is_rejected(self, orig_hash: str, fix_hash: str) -> bool:
        """Check if a fix hash was specifically rejected."""
        if not orig_hash or not fix_hash:
            return False
        with self._lock:
            if orig_hash not in self._store:
                return False
            entry = self._store[orig_hash]
            return fix_hash in entry["rejected_hashes"]

    def get_tried_count(self, orig_hash: str) -> int:
        """Return the number of fix hashes tried for this code hash."""
        with self._lock:
            entry = self._store.get(orig_hash)
            return len(entry["tried_hashes"]) if entry else 0

    def forget(self, orig_hash: str) -> None:
        """Remove memory entry for a specific original code hash."""
        with self._lock:
            self._store.pop(orig_hash, None)

    def clear(self) -> None:
        """Clear all memory entries (used on restart or test cleanup)."""
        with self._lock:
            self._store.clear()

    def size(self) -> int:
        """Return the number of tracked original code entries."""
        with self._lock:
            return len(self._store)


# Global singleton instance for runtime agent orchestration
_GLOBAL_MEMORY = AgentMemory()


def get_global_memory() -> AgentMemory:
    """Return the runtime singleton memory instance."""
    return _GLOBAL_MEMORY
