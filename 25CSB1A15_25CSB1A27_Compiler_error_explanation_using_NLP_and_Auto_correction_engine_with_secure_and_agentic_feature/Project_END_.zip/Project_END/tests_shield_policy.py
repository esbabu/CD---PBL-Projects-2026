"""tests_shield_policy.py - Unit Tests for Policy Engine and Shield Integrity.

Tests:
- Policy loading and action allow/deny queries
- Manifest verification and hash tamper detection
- Fail-closed behavior on tampered manifest
- Server resilience (non-agent routes work even if manifest is broken)
- SHIELD_ENABLED lazy evaluation
- Socket guard ensuring zero real external network connections
"""

import json
import os
import shutil
import socket
import tempfile
import unittest
from unittest.mock import patch

from security import policy_engine, shield


class TestShieldPolicy(unittest.TestCase):
    """Unit tests for security/policy_engine.py and shield.py core."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1"):
                raise AssertionError(f"Real outbound network call to {address} attempted in test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        # Ensure dummy keys
        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_policy_engine_is_allowed(self):
        """Verify policy queries for standard and prohibited actions."""
        engine = policy_engine.PolicyEngine()
        ok, msg = engine.initialize()
        self.assertTrue(ok, f"Policy engine failed to arm: {msg}")

        # Prohibited actions
        denied_actions = [
            "skip_scan", "disable_scan", "read_env", "network_egress",
            "unapproved_patch", "unallowed_tool", "edit_policy"
        ]
        for act in denied_actions:
            allowed, reason = engine.is_allowed(act)
            self.assertFalse(allowed, f"Action '{act}' should be denied by policy")
            self.assertTrue("denied" in reason.lower() or "requires" in reason.lower())

        # Permitted action
        allowed, reason = engine.is_allowed("safe_sandbox_execution")
        self.assertTrue(allowed)
        self.assertIn("permitted", reason.lower())

    def test_policy_manifest_tamper_fails_closed(self):
        """Tampering with manifest or policy must cause PolicyEngine to refuse to arm."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a dummy tampered policy and manifest in tempdir
            tmp_policy = os.path.join(tmpdir, "policy.json")
            tmp_manifest = os.path.join(tmpdir, "shield_manifest.json")

            with open(tmp_policy, "w", encoding="utf-8") as f:
                f.write('{"tampered": true}')

            with open(tmp_manifest, "w", encoding="utf-8") as f:
                json.dump({"files": {"policy.json": "0000000000000000000000000000000000000000000000000000000000000000"}}, f)

            engine = policy_engine.PolicyEngine(policy_path=tmp_policy, manifest_path=tmp_manifest)
            ok, reason = engine.initialize()
            self.assertFalse(ok)
            self.assertIn("refused to arm", reason.lower())

            # Attempting to check an action when disarmed returns fail-closed
            allowed, act_reason = engine.is_allowed("any_action")
            self.assertFalse(allowed)
            self.assertIn("shield unavailable", act_reason.lower())

    def test_server_resilience_when_shield_disarmed(self):
        """When Shield fails to arm due to broken manifest in temp copy, non-agent routes still function."""
        import app as flask_app
        client = flask_app.app.test_client()

        # Non-agent routes must respond 200
        ver_resp = client.get("/api/version")
        self.assertEqual(ver_resp.status_code, 200)

        files_resp = client.get("/api/files")
        self.assertEqual(files_resp.status_code, 200)

        lex_resp = client.post("/api/lexical", json={"code": "x = 1"})
        self.assertEqual(lex_resp.status_code, 200)

    def test_shield_enabled_lazy_evaluation(self):
        """SHIELD_ENABLED is read lazily and defaults to True when unset."""
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("SHIELD_ENABLED", None)
            self.assertTrue(shield.is_shield_enabled())

        with patch.dict(os.environ, {"SHIELD_ENABLED": "1"}):
            self.assertTrue(shield.is_shield_enabled())

        with patch.dict(os.environ, {"SHIELD_ENABLED": "true"}):
            self.assertTrue(shield.is_shield_enabled())

        with patch.dict(os.environ, {"SHIELD_ENABLED": "0"}):
            self.assertFalse(shield.is_shield_enabled())

        with patch.dict(os.environ, {"SHIELD_ENABLED": "false"}):
            self.assertFalse(shield.is_shield_enabled())

    def test_no_write_api_on_policy_engine(self):
        """Policy engine exposes no modification or write methods."""
        engine = policy_engine.PolicyEngine()
        forbidden_methods = ["save", "write", "update", "delete", "modify", "set_policy"]
        for m in forbidden_methods:
            self.assertFalse(hasattr(engine, m), f"PolicyEngine must not expose write method '{m}'")


if __name__ == "__main__":
    unittest.main()
