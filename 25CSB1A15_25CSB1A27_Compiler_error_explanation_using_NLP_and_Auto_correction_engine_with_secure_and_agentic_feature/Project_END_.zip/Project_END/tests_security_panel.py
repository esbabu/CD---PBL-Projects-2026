"""Unit and integration tests for Feature 11:
Security Metrics Dashboard, Red/Green Diff View, and Self-XSS mitigations.
"""

import json
import os
import re
import socket
import unittest

os.environ["LLM_DISABLED"] = "1"
os.environ["INTELLIFIX_OFFLINE"] = "1"

import app as flask_app


class TestSecurityPanel(unittest.TestCase):

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1", "testserver"):
                raise AssertionError(f"Outbound network call to {address} attempted during security panel test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.app = flask_app.app.test_client()
        self.app.testing = True

    def tearDown(self):
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_metrics_api_get(self):
        """GET /api/security/metrics returns complete metrics json."""
        resp = self.app.get("/api/security/metrics")
        self.assertEqual(resp.status_code, 200)
        data = json.loads(resp.data)
        self.assertEqual(data.get("status"), "success")
        self.assertIn("metrics", data)
        self.assertIn("recent_audit_events", data)
        self.assertIn("charts", data)
        self.assertIn("honest_limitations", data)
        metrics = data["metrics"]
        self.assertIn("asr_reduction_pct", metrics)
        self.assertIn("recall_standard", metrics)
        self.assertIn("roc_auc", metrics)

    def test_metrics_api_methods_blocked(self):
        """POST, PUT, DELETE to /api/security/metrics return 405 Method Not Allowed."""
        resp_post = self.app.post("/api/security/metrics", json={})
        self.assertEqual(resp_post.status_code, 405)
        resp_put = self.app.put("/api/security/metrics", json={})
        self.assertEqual(resp_put.status_code, 405)
        resp_delete = self.app.delete("/api/security/metrics")
        self.assertEqual(resp_delete.status_code, 405)

    def test_diff_api_success(self):
        """POST /api/diff produces unified diff between original and healed."""
        payload = {
            "original": "def add(a, b):\n    retun a + b\n",
            "healed": "def add(a, b):\n    return a + b\n",
        }
        resp = self.app.post("/api/diff", json=payload)
        self.assertEqual(resp.status_code, 200)
        data = json.loads(resp.data)
        self.assertEqual(data.get("status"), "success")
        self.assertIn("diff", data)
        self.assertIn("lines", data)
        lines = data["lines"]
        has_add = any(l.startswith("+") and not l.startswith("+++") for l in lines)
        has_rem = any(l.startswith("-") and not l.startswith("---") for l in lines)
        self.assertTrue(has_add and has_rem)

    def test_dom_elements_present_in_template(self):
        """Verify Week 6 UI element IDs exist in templates/index.html."""
        template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        required_ids = [
            "w6_btn_open_security",
            "w6_modal_security",
            "w6_security_blocked_banner",
            "btn-view-diff",
            "code-diff-container",
            "w6-asr-reduction",
            "w6-audit-events-tbody"
        ]
        for el_id in required_ids:
            self.assertIn(f'id="{el_id}"', html, f"Missing element id: {el_id}")

    def test_self_xss_sink_fixes_verified(self):
        """Verify multi-error table and file list use textContent and createElement, not innerHTML."""
        template_path = os.path.join(os.path.dirname(__file__), "templates", "index.html")
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        # Find renderErrorListPanel function
        render_err_match = re.search(r"function renderErrorListPanel\([^)]*\)\s*\{([\s\S]*?)\n\s*\}", html)
        self.assertIsNotNone(render_err_match, "renderErrorListPanel function not found")
        render_body = render_err_match.group(1)
        self.assertNotIn(".innerHTML", render_body, "renderErrorListPanel must not use innerHTML")
        self.assertIn("textContent", render_body, "renderErrorListPanel must use textContent")

        # Find loadFiles function
        load_files_match = re.search(r"function loadFiles\([^)]*\)\s*\{([\s\S]*?)\n\s*\}", html)
        self.assertIsNotNone(load_files_match, "loadFiles function not found")
        load_body = load_files_match.group(1)
        self.assertNotIn(".innerHTML", load_body, "loadFiles must not use innerHTML")
        self.assertIn("textContent", load_body, "loadFiles must use textContent")

    def test_analyze_endpoint_unbroken(self):
        """Golden check verifying /api/analyze remains operational and returns expected keys."""
        resp = self.app.post("/api/analyze", json={"code": "x = 10\nprint(x)\n"})
        self.assertEqual(resp.status_code, 200)
        data = json.loads(resp.data)
        self.assertEqual(data.get("status"), "success")
        self.assertIn("errors", data)
        self.assertEqual(data["errors"], [])


if __name__ == "__main__":
    unittest.main()
