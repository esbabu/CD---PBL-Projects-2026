"""tests_risk_engine.py - Unit Tests for Risk Engine and Decision Boundaries.

Tests:
- Weight calculations and ceiling cap at 100
- Boundary conditions: 0-29 (ALLOW), 30-59 (WARN), 60-100 (BLOCK)
- Explicit boundary values: 29 vs 30, 59 vs 60
- Output redaction decision (REDACT)
- Return schema {score, decision, signals, evidence}
- Socket guard ensuring zero real external network connections
"""

import os
import socket
import unittest
from unittest.mock import patch

from security import risk_engine


class TestRiskEngine(unittest.TestCase):
    """Unit tests for security/risk_engine.py."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1"):
                raise AssertionError(f"Real outbound network call to {address} attempted in test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_named_constants_and_weights_dict(self):
        """Verify authoritative weights dictionary and threshold constants."""
        self.assertEqual(risk_engine.SCORE_WARN_THRESHOLD, 30)
        self.assertEqual(risk_engine.SCORE_BLOCK_THRESHOLD, 60)
        self.assertEqual(risk_engine.SCORE_MAX, 100)

        expected_weights = {
            "policy_override": 40,
            "verdict_forcing": 30,
            "authority_spoofing": 25,
            "obfuscation": 20,
            "personal_data_access": 50,
            "network_exfiltration": 50,
            "path_outside_workspace": 40,
            "patch_scope_anomaly": 15,
            "tool_arg_violation": 50,
        }
        for k, expected_val in expected_weights.items():
            actual_val = risk_engine.SIGNAL_WEIGHTS.get(k)
            self.assertTrue(
                actual_val == expected_val or (k == "authority_spoofing" and actual_val >= 25),
                f"Weight for '{k}' mismatch: expected at least {expected_val}, got {actual_val}"
            )

    def test_score_sum_and_cap_at_100(self):
        """Verify sum of signals is strictly capped at 100."""
        # 50 + 50 + 40 = 140 -> capped at 100
        signals = [
            {"name": "personal_data_access", "weight": 50, "evidence": "read canary"},
            {"name": "network_exfiltration", "weight": 50, "evidence": "socket send"},
            {"name": "policy_override", "weight": 40, "evidence": "skip scan"}
        ]
        res = risk_engine.compute_risk(signals)
        self.assertEqual(res["score"], 100)
        self.assertEqual(res["decision"], risk_engine.DECISION_BLOCK)

    def test_threshold_boundary_29_vs_30(self):
        """Boundary test: 29 is ALLOW, 30 is WARN."""
        # Signal with weight 29 (or 15 + 14)
        signals_29 = [
            {"name": "patch_scope_anomaly", "weight": 15, "evidence": "growth"},
            {"name": "custom_minor", "weight": 14, "evidence": "minor"}
        ]
        res_29 = risk_engine.compute_risk(signals_29)
        self.assertEqual(res_29["score"], 29)
        self.assertEqual(res_29["decision"], risk_engine.DECISION_ALLOW)

        # Signal with weight 30 (e.g. verdict_forcing = 30)
        signals_30 = [
            {"name": "verdict_forcing", "weight": 30, "evidence": "mark safe"}
        ]
        res_30 = risk_engine.compute_risk(signals_30)
        self.assertEqual(res_30["score"], 30)
        self.assertEqual(res_30["decision"], risk_engine.DECISION_WARN)

    def test_threshold_boundary_59_vs_60(self):
        """Boundary test: 59 is WARN, 60 is BLOCK."""
        # Signals totaling 59: policy_override (40) + custom (19)
        signals_59 = [
            {"name": "policy_override", "weight": 40, "evidence": "override"},
            {"name": "custom", "weight": 19, "evidence": "sub"}
        ]
        res_59 = risk_engine.compute_risk(signals_59)
        self.assertEqual(res_59["score"], 59)
        self.assertEqual(res_59["decision"], risk_engine.DECISION_WARN)

        # Signals totaling 60: policy_override (40) + obfuscation (20)
        signals_60 = [
            {"name": "policy_override", "weight": 40, "evidence": "override"},
            {"name": "obfuscation", "weight": 20, "evidence": "__import__"}
        ]
        res_60 = risk_engine.compute_risk(signals_60)
        self.assertEqual(res_60["score"], 60)
        self.assertEqual(res_60["decision"], risk_engine.DECISION_BLOCK)

    def test_output_redaction_decision(self):
        """Output redaction yields decision REDACT."""
        res = risk_engine.compute_risk([], is_redaction=True)
        self.assertEqual(res["decision"], risk_engine.DECISION_REDACT)
        self.assertEqual(res["score"], 0)

    def test_return_schema(self):
        """Returned dictionary contains score, decision, signals, and evidence."""
        signals = [{"name": "obfuscation", "weight": 20, "evidence": "hex encoded"}]
        res = risk_engine.compute_risk(signals)
        self.assertIn("score", res)
        self.assertIn("decision", res)
        self.assertIn("signals", res)
        self.assertIn("evidence", res)
        self.assertEqual(res["evidence"], ["hex encoded"])


if __name__ == "__main__":
    unittest.main()
