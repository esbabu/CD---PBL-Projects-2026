# -*- mode: python ; coding: utf-8 -*-

import sys
import os
import glob
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

datas = [
    ('templates', 'templates'),
    ('results', 'results'),
    ('security', 'security'),
]

for optional_dir in ['attacks', 'benchmark', 'lab_data', 'docs']:
    if os.path.exists(optional_dir):
        datas.append((optional_dir, optional_dir))

for optional_file in ['data.json', 'emissions.csv', 'index.html']:
    if os.path.exists(optional_file):
        datas.append((optional_file, '.'))

# Include all .py files so runtime hash functions can read their source
for py_file in glob.glob('*.py'):
    datas.append((py_file, '.'))

datas += collect_data_files('webview')

hiddenimports = [
    'webview',
    'webview.platforms.winforms',
    'clr',
    'pythonnet',
    'flask',
    'flask_cors',
    'jinja2',
    'werkzeug',
    'psutil',
    'requests',
    'urllib3',
    'code_quality',
    'sandbox_child',
    'sandbox_runner',
    'multi_error',
    'automaton_engine',
    'tokenizer',
    'pda_engine',
    'cfg_engine',
    'security_analyzer',
    'security',
    'security.threat_catalog',
    'security.audit_log',
    'security.dual_key',
    'security.input_guard',
    'security.tool_guard',
    'security.policy_engine',
    'error_extractor',
    'ir_generator',
    'nlp_explainer',
    'llm_calls',
    'llm_config',
]
hiddenimports += collect_submodules('webview')

a = Analysis(
    ['desktop_app.py'],
    pathex=['.'],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['torch', 'transformers', 'matplotlib', 'scipy', 'IPython', 'jupyter', 'notebook'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='TOC_Studio_Standalone',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

