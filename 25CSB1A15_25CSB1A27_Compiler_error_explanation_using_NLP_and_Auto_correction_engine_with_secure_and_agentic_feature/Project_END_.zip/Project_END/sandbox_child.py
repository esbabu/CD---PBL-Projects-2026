"""
sandbox_child.py - Child process execution wrapper for IntelliFix Sandbox Runner.

Overview:
1. Runs inside an isolated child interpreter under sys.executable -I -X utf8.
2. Installs security audit hooks (sys.addaudithook) to block unauthorized operations
   (network access, subprocess spawning, native DLL loads, file writes outside temp directory).
3. Reads code from a temporary input file, registers the source in linecache so tracebacks
   retain the exact failing line text, and compiles/executes the code with clean globals.
4. Reports structured execution status, error IR, and violations through a tamper-resistant
   nonce-delimited stderr channel.
"""

import sys
import os
import io
import json
import ast
import linecache
import traceback
import re
from typing import Dict, Any, List, Optional

# Ensure user site-packages are accessible even when invoked under -I
try:
    import site
    _usp = site.getusersitepackages()
    if _usp and os.path.exists(_usp) and _usp not in sys.path:
        sys.path.append(_usp)
except Exception:
    pass

# Track security violations triggered during execution
_SANDBOX_VIOLATIONS: List[Dict[str, str]] = []
_SANDBOX_DIR: str = ""

_CANARY_ENV_KEYS = {
    "AWS_SECRET_ACCESS_KEY",
    "DATABASE_ADMIN_PASSWORD",
    "OPENAI_API_SECRET_KEY",
    "INTELLIFIX_CANARY_TOKEN"
}

_CANARY_FILE_BASES = {
    ".env.canary",
    ".aws_credentials",
    "secrets_canary.json"
}


def _is_canary_file_target(file_path: Any) -> bool:
    """Returns True if the target path is a canary honeypot file."""
    if not file_path:
        return False
    try:
        base = os.path.basename(str(file_path).replace("\\", "/")).lower()
        return base in _CANARY_FILE_BASES or "canary" in base
    except Exception:
        return False


def _install_canary_traps() -> None:
    """Instruments os.environ and os.getenv to trap access to decoy honeypot secrets."""
    try:
        orig_getitem = os._Environ.__getitem__
        orig_get = os._Environ.get
        orig_getenv = os.getenv

        def _trap_env_access(key: Any) -> None:
            if isinstance(key, str) and key.upper() in _CANARY_ENV_KEYS:
                _SANDBOX_VIOLATIONS.append({
                    "kind": "canary_trap_triggered",
                    "detail": f"Unauthorized access to canary honeypot environment variable '{key}'"
                })
                raise PermissionError(f"Sandbox security violation: Access to honeypot canary environment variable '{key}' is blocked.")

        def _monitored_getitem(self, key):
            _trap_env_access(key)
            return orig_getitem(self, key)

        def _monitored_get(self, key, default=None):
            _trap_env_access(key)
            return orig_get(self, key, default)

        def _monitored_getenv(key, default=None):
            _trap_env_access(key)
            return orig_getenv(key, default)

        os._Environ.__getitem__ = _monitored_getitem
        os._Environ.get = _monitored_get
        os.getenv = _monitored_getenv
    except Exception:
        pass


def _is_inside_dir(target_path: Any, base_dir: str) -> bool:
    """Return True if target_path is within base_dir or points to base_dir."""
    if not target_path or not base_dir:
        return False
    try:
        norm_target = os.path.realpath(os.path.abspath(str(target_path)))
        norm_base = os.path.realpath(os.path.abspath(str(base_dir)))
        if os.name == 'nt':
            norm_target = norm_target.lower()
            norm_base = norm_base.lower()
        return norm_target == norm_base or norm_target.startswith(norm_base + os.sep)
    except Exception:
        return False


def _install_audit_hooks(sandbox_dir: str) -> None:
    """
    Installs Python runtime audit hooks for defense-in-depth behavior restrictions.
    Note: Audit hooks are a safeguard, not a complete kernel security boundary.
    """
    def _audit_hook(event: str, args: tuple) -> None:
        global _SANDBOX_VIOLATIONS

        # 1. Guard against network operations
        if event in ("socket.connect", "socket.bind", "socket.sendto", "socket.connect_ex"):
            _SANDBOX_VIOLATIONS.append({
                "kind": "network",
                "detail": f"{event} {args}"
            })
            raise PermissionError(f"Sandbox security violation: Network operation '{event}' is blocked.")

        # 2. Guard against process spawning
        elif event in ("subprocess.Popen", "os.system", "os.posix_spawn", "os.spawn", "os.startfile", "os.exec"):
            _SANDBOX_VIOLATIONS.append({
                "kind": "process",
                "detail": f"{event} {args}"
            })
            raise PermissionError(f"Sandbox security violation: Process execution '{event}' is blocked.")

        # 3. Guard against loading native DLLs / shared objects
        elif event.startswith("ctypes.dlopen") or event.startswith("ctypes.dlsym") or event.startswith("_ctypes.dlopen"):
            _SANDBOX_VIOLATIONS.append({
                "kind": "native_code",
                "detail": f"{event} {args}"
            })
            raise PermissionError(f"Sandbox security violation: Native library loading '{event}' is blocked.")

        # 4. Guard against canary honeypot files (any read or write) and out-of-sandbox writes
        elif event == "open":
            if len(args) >= 1:
                file_path = args[0]
                if _is_canary_file_target(file_path):
                    _SANDBOX_VIOLATIONS.append({
                        "kind": "canary_trap_triggered",
                        "detail": f"Unauthorized access to canary honeypot file '{file_path}'"
                    })
                    raise PermissionError(f"Sandbox security violation: Access to honeypot canary file '{file_path}' is blocked.")

                # Block reading sensitive user secrets, project security tokens, or environment files outside sandbox
                if file_path and isinstance(file_path, (str, bytes)):
                    fp_norm = str(file_path).replace("\\", "/").lower()
                    if not _is_inside_dir(file_path, sandbox_dir):
                        base_name = os.path.basename(fp_norm)
                        # 1. Block access to project security files, keys, and audit ledgers
                        if any(p in fp_norm for p in (
                            ".secret", "security_log.jsonl", "policy.json", "shield_manifest.json",
                            "policy.sha256", "dual_key", "call_log.jsonl", ".call_counts.json", ".redeemed_keys.json"
                        )):
                            _SANDBOX_VIOLATIONS.append({
                                "kind": "sensitive_file_read",
                                "detail": f"Unauthorized read of protected system/security file '{file_path}'"
                            })
                            raise PermissionError(f"Sandbox security violation: Access to protected security file '{file_path}' is blocked.")

                        # 2. Block sensitive host files, credentials, SSH, AWS, and system configs
                        if (
                            base_name.startswith((".", "id_rsa", "id_ed25519", "credentials", "secrets"))
                            or any(s in fp_norm for s in (
                                "/.ssh", "/.aws", "/secrets", "/password", "/.bash", "/.env",
                                "system32/config", "/etc/shadow", "/etc/passwd", "/etc/sudoers"
                            ))
                        ):
                            _SANDBOX_VIOLATIONS.append({
                                "kind": "sensitive_file_read",
                                "detail": f"Unauthorized read of sensitive host path '{file_path}'"
                            })
                            raise PermissionError(f"Sandbox security violation: Reading sensitive host path '{file_path}' is blocked.")

            if len(args) >= 2:
                file_path = args[0]
                mode = args[1]
                flags = args[2] if len(args) > 2 else 0
                is_write = False
                if mode is not None and any(m in str(mode) for m in ('w', 'a', '+', 'x')):
                    is_write = True
                elif isinstance(flags, int) and (flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)):
                    is_write = True

                if is_write and file_path and isinstance(file_path, (str, bytes)):
                    if not _is_inside_dir(file_path, sandbox_dir):
                        _SANDBOX_VIOLATIONS.append({
                            "kind": "file_write_outside",
                            "detail": f"open({file_path}, mode={mode})"
                        })
                        raise PermissionError(f"Sandbox security violation: Write outside sandbox directory ({file_path}) is blocked.")

        elif event in ("os.remove", "os.unlink", "os.rmdir", "os.mkdir", "os.rename", "os.replace"):
            for arg in args:
                if isinstance(arg, (str, bytes)) and not _is_inside_dir(arg, sandbox_dir):
                    _SANDBOX_VIOLATIONS.append({
                        "kind": "file_write_outside",
                        "detail": f"{event}({arg})"
                    })
                    raise PermissionError(f"Sandbox security violation: File mutation outside sandbox directory ({arg}) is blocked.")

    sys.addaudithook(_audit_hook)


def _extract_frame_lineno(tb: Any, filename: str = "<string>") -> Optional[int]:
    """Finds the line number of the innermost frame executing the user string code."""
    line_no = None
    curr = tb
    while curr:
        frame = curr.tb_frame
        if frame.f_code.co_filename == filename:
            line_no = curr.tb_lineno
        curr = curr.tb_next
    return line_no


def _format_cleaned_traceback(exc: BaseException) -> str:
    """Formats the traceback starting from the user's <string> frame, omitting wrapper frames."""
    tb = exc.__traceback__
    curr = tb
    while curr and curr.tb_frame.f_code.co_filename != "<string>":
        curr = curr.tb_next
    if curr:
        lines = traceback.format_exception(type(exc), exc, curr)
        return "".join(lines)
    return traceback.format_exc()


def main() -> None:
    global _SANDBOX_DIR

    nonce: Optional[str] = None
    sandbox_dir: str = os.getcwd()
    mode: str = "single"
    code_path: Optional[str] = None

    # Parse arguments
    filtered_argv = []
    for arg in sys.argv[1:]:
        if arg.startswith("--nonce="):
            nonce = arg.split("=", 1)[1]
        elif arg.startswith("--sandbox-dir="):
            sandbox_dir = arg.split("=", 1)[1]
        elif arg.startswith("--mode="):
            mode = arg.split("=", 1)[1]
        elif arg.startswith("--code-file="):
            code_path = arg.split("=", 1)[1]
        else:
            filtered_argv.append(arg)

    # Sanitize sys.argv and environment
    sys.argv = ["<string>"] + filtered_argv
    _SANDBOX_DIR = sandbox_dir

    if not nonce:
        sys.stderr.write("Fatal: Missing sandbox nonce.\n")
        sys.exit(1)

    # Read user code
    code = ""
    if code_path and os.path.exists(code_path):
        try:
            with open(code_path, "r", encoding="utf-8", errors="replace") as f:
                code = f.read()
        except Exception as e:
            code = ""
    elif filtered_argv:
        try:
            with open(filtered_argv[0], "r", encoding="utf-8", errors="replace") as f:
                code = f.read()
        except Exception:
            code = ""

    if code.startswith("\ufeff"):
        code = code[1:]

    # Register linecache for <string> so tracebacks contain the source line text
    code_lines = [l + "\n" for l in code.splitlines()]
    linecache.cache["<string>"] = (len(code), None, code_lines, "<string>")

    # Install audit hooks before executing any user code
    _install_audit_hooks(sandbox_dir)

    status = "ok"
    error_dict: Optional[Dict[str, Any]] = None

    # Phase 1: Compile check for SyntaxError
    compiled_code = None
    try:
        compiled_code = compile(code, "<string>", "exec")
    except SyntaxError as e:
        status = "error"
        error_dict = {
            "error_type": type(e).__name__,
            "error_message": str(e),
            "line_number": e.lineno,
            "traceback": traceback.format_exc()
        }
    except Exception as e:
        status = "error"
        error_dict = {
            "error_type": type(e).__name__,
            "error_message": str(e),
            "line_number": None,
            "traceback": traceback.format_exc()
        }

    # Phase 2: Runtime execution if syntax is valid
    if compiled_code is not None:
        user_globals = {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
            "__builtins__": __builtins__
        }
        _install_canary_traps()
        try:
            exec(compiled_code, user_globals)
        except SystemExit as e:
            if e.code not in (0, None):
                status = "error"
                error_dict = {
                    "error_type": "SystemExit",
                    "error_message": str(e.code),
                    "line_number": _extract_frame_lineno(e.__traceback__, "<string>"),
                    "traceback": _format_cleaned_traceback(e)
                }
        except PermissionError as e:
            if _SANDBOX_VIOLATIONS:
                status = "violation"
            else:
                status = "error"
            error_dict = {
                "error_type": type(e).__name__,
                "error_message": str(e),
                "line_number": _extract_frame_lineno(e.__traceback__, "<string>"),
                "traceback": _format_cleaned_traceback(e)
            }
        except BaseException as e:
            status = "error"
            line_no = _extract_frame_lineno(e.__traceback__, "<string>")
            if line_no is None:
                tb_lines = [l for l in traceback.format_exc().splitlines() if '<string>' in l and "line" in l]
                if tb_lines:
                    m = re.search(r"line\s+(\d+)", tb_lines[-1])
                    if m:
                        line_no = int(m.group(1))

            err_cls = type(e)
            if err_cls.__module__ and err_cls.__module__ not in ("builtins", "__main__", "exceptions"):
                err_type_str = f"{err_cls.__module__}.{err_cls.__qualname__}"
            else:
                err_type_str = err_cls.__name__

            error_dict = {
                "error_type": err_type_str,
                "error_message": str(e),
                "line_number": line_no,
                "traceback": _format_cleaned_traceback(e)
            }

    # Construct report
    if any(v.get("kind") == "canary_trap_triggered" for v in _SANDBOX_VIOLATIONS):
        status = "violation"

    report = {
        "status": status,
        "mode": mode,
        "exit_code": 0 if status == "ok" else 1,
        "error": error_dict,
        "violations": list(_SANDBOX_VIOLATIONS)
    }

    # Transmit result via nonce-delimited channel on stderr
    try:
        json_output = json.dumps(report, ensure_ascii=False)
        sys.stderr.write(f"\n---SANDBOX_RESULT_{nonce}---\n{json_output}\n---SANDBOX_RESULT_{nonce}---\n")
        sys.stderr.flush()
    except Exception as e:
        sys.stderr.write(f"Fatal error encoding sandbox result: {e}\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
