"""tests_offline.py – Unit tests for the deterministic Offline Guide tier.

Tests real records from dataset/data.jsonl, verifies slot extractions,
package alias suggestions, granular JSON causes, unknown exception handling,
and NLPExplainer integration.
"""

import json
import os
import unittest
from collections import defaultdict

import offline_guide
from nlp_explainer import NLPExplainer


class TestOfflineGuide(unittest.TestCase):
    def setUp(self):
        from unittest.mock import patch
        self.env_patcher = patch.dict(os.environ, {"LLM_DISABLED": "1", "AUTOFIX_AI": "0"})
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)

    @classmethod
    def setUpClass(cls):
        cls.data_path = os.path.join(os.path.dirname(__file__), "dataset", "data.jsonl")
        cls.samples = defaultdict(list)
        if os.path.exists(cls.data_path):
            with open(cls.data_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        rec = json.loads(line)
                        err_t = rec.get("error_type")
                        if len(cls.samples[err_t]) < 2:
                            cls.samples[err_t].append(rec)

    def test_all_dataset_error_types_two_records_each(self):
        """Test 2 records for every error type in data.jsonl."""
        self.assertGreaterEqual(len(self.samples), 20, "Expected at least 20 error types in data.jsonl")

        for err_type, records in self.samples.items():
            for i, rec in enumerate(records):
                msg = rec.get("actual_msg", "")
                code = rec.get("orig_code", "")
                res = offline_guide.guide(err_type, msg, line_no=1, offending_line="", code=code)

                self.assertTrue(res and isinstance(res, str), f"Result empty for {err_type} sample {i}")
                self.assertIn("[Offline guide - no AI used]", res, f"Missing label for {err_type}")

                m_pos = res.find("Mistake:")
                r_pos = res.find("Reason:")
                f_pos = res.find("Fix:")
                self.assertTrue(m_pos != -1 and r_pos > m_pos and f_pos > r_pos,
                                f"Invalid Mistake/Reason/Fix ordering in {err_type}: {res}")

                # 4. No template placeholder tokens left unformatted
                for token in ["{module}", "{variable}", "{path}", "{table}", "{column}", "{pypi_package}"]:
                    self.assertNotIn(token, res, f"Unformatted placeholder {token} in {err_type}: {res}")


                if "No module named '" in msg:
                    mod_name = msg.split("'")[1]
                    self.assertIn(mod_name, res, f"Module slot '{mod_name}' missing from output: {res}")
                if "local variable '" in msg and "' referenced before assignment" in msg:
                    var_name = msg.split("'")[1]
                    self.assertIn(var_name, res, f"Variable slot '{var_name}' missing from output: {res}")

    def test_package_aliases_mapping(self):
        """Test all 10 required package aliases."""
        alias_tests = [
            ("cv2", "opencv-python"),
            ("PIL", "Pillow"),
            ("sklearn", "scikit-learn"),
            ("yaml", "PyYAML"),
            ("bs4", "beautifulsoup4"),
            ("dateutil", "python-dateutil"),
            ("dotenv", "python-dotenv"),
            ("skimage", "scikit-image"),
            ("Crypto", "pycryptodome"),
            ("serial", "pyserial"),
        ]
        for import_name, pypi_name in alias_tests:
            res = offline_guide.guide("ModuleNotFoundError", f"No module named '{import_name}'", line_no=1)
            self.assertIn(pypi_name, res, f"Expected PyPI package {pypi_name} for import {import_name}")
            self.assertIn(import_name, res)

    def test_module_not_found_slot(self):
        res = offline_guide.guide("ModuleNotFoundError", "No module named 'pandas'", line_no=1, offending_line="import pandas")
        self.assertIn("pandas", res)
        self.assertIn("pip install pandas", res)
        self.assertIn("[Offline guide - no AI used]", res)

    def test_import_error_slot(self):
        res = offline_guide.guide("ImportError", "cannot import name 'nonexistent' from 'math'", line_no=1)
        self.assertIn("nonexistent", res)
        self.assertIn("math", res)

    def test_unbound_local_error_slot(self):
        res = offline_guide.guide("UnboundLocalError", "local variable 'counter' referenced before assignment", line_no=4)
        self.assertIn("counter", res)
        self.assertIn("global counter", res)

    def test_permission_error_slot(self):
        res = offline_guide.guide("PermissionError", "[Errno 13] Permission denied: '/root/secret.txt'", line_no=2)
        self.assertIn("/root/secret.txt", res)

    def test_sqlite_slots(self):
        res_table = offline_guide.guide("sqlite3.OperationalError", "no such table: users", line_no=1)
        self.assertIn("users", res_table)
        res_col = offline_guide.guide("sqlite3.OperationalError", "no such column: age", line_no=1)
        self.assertIn("age", res_col)

    def test_recursion_error(self):
        res = offline_guide.guide("RecursionError", "maximum recursion depth exceeded in comparison", line_no=2)
        self.assertIn("recursion", res.lower())
        self.assertIn("base", res.lower())

    def test_json_decode_error_causes(self):
        res_empty = offline_guide.guide("json.decoder.JSONDecodeError", "Expecting value: line 1 column 1 (char 0)", line_no=1)
        self.assertIn("line 1 column 1 (char 0)", res_empty)
        self.assertIn("empty", res_empty.lower())

        res_quotes = offline_guide.guide("json.decoder.JSONDecodeError", "Expecting property name enclosed in double quotes: line 1 column 2 (char 1)", line_no=1)
        self.assertIn("double quotes", res_quotes)

        res_comma = offline_guide.guide("json.decoder.JSONDecodeError", "Expecting ',' delimiter: line 1 column 10 (char 9)", line_no=1)
        self.assertIn("missing comma", res_comma.lower())

    def test_assertion_error_expression(self):
        code = "a = 5\nassert a == 10"
        res = offline_guide.guide("AssertionError", "", line_no=2, code=code)
        self.assertIn("a == 10", res)
        self.assertIn("Assertion condition failed", res)


    def test_unknown_error_type(self):
        res = offline_guide.guide("CustomUnseenError", "something strange happened", line_no=5)
        self.assertIn("[Offline guide - no AI used]", res)
        self.assertIn("Mistake:", res)
        self.assertIn("Reason:", res)
        self.assertIn("Fix:", res)
        self.assertIn("CustomUnseenError", res)

    def test_empty_message_and_none(self):
        res1 = offline_guide.guide("RuntimeError", "", line_no=None)
        self.assertIn("[Offline guide - no AI used]", res1)
        self.assertIn("Mistake:", res1)

        res2 = offline_guide.guide("OSError", None, line_no=10)
        self.assertIn("[Offline guide - no AI used]", res2)
        self.assertIn("Mistake:", res2)

    def test_nlp_explainer_integration_offline(self):
        explainer = NLPExplainer()
        ir_rule = {
            "error_type": "ZeroDivisionError",
            "error_message": "division by zero",
            "line_number": 1,
            "traceback": 'File "<string>", line 1, in <module>\n1 / 0'
        }
        res_rule = explainer.explain(ir_rule, code="1 / 0")
        self.assertEqual(explainer.last_source, "rule")
        self.assertNotIn("[Offline guide", res_rule)

        import nlp_explainer
        orig_use_llm = nlp_explainer.USE_LLM
        try:
            nlp_explainer.USE_LLM = False
            ir_unrec = {
                "error_type": "RecursionError",
                "error_message": "maximum recursion depth exceeded",
                "line_number": 2,
                "traceback": 'File "<string>", line 2, in f\nreturn f()'
            }
            res_unrec = explainer.explain(ir_unrec, code="def f():\n    return f()\nf()")
            self.assertEqual(explainer.last_source, "offline_guide")
            self.assertIn("[Offline guide - no AI used]", res_unrec)
        finally:
            nlp_explainer.USE_LLM = orig_use_llm


if __name__ == "__main__":
    unittest.main()
