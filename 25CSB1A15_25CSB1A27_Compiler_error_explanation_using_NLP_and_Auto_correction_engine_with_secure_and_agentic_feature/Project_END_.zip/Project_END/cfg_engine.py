"""cfg_engine.py – Control Flow Graph (CFG) & Cyclomatic Complexity Engine.

Builds a CFG from Python source code using the standard AST library,
computes McCabe cyclomatic complexity, generates Mermaid flowchart diagrams,
and produces heatmap data for per-function complexity visualisation.

Standard library only: ast, collections, dataclasses, textwrap, re
"""

import ast
import re
import textwrap
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Any


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class BasicBlock:
    """A maximal sequence of statements with no internal branches.

    Attributes:
        id:           Unique integer identifier for this block.
        stmts:        The AST statement nodes contained in this block.
        start_line:   Source line number of the first statement.
        end_line:     Source line number of the last statement.
        predecessors: IDs of blocks that have an edge *into* this block.
        successors:   IDs of blocks that have an edge *out of* this block.
        block_type:   "normal" | "decision" | "return" | "entry" | "exit"
    """
    id: int
    stmts: List[ast.stmt] = field(default_factory=list)
    start_line: int = 0
    end_line: int = 0
    predecessors: List[int] = field(default_factory=list)
    successors: List[int] = field(default_factory=list)
    block_type: str = "normal"


@dataclass
class CFGResult:
    """The result of building a Control Flow Graph.

    Attributes:
        blocks:      All basic blocks in the CFG.
        edges:       Directed edges as (from_id, to_id) pairs.
        entry_block: ID of the entry (start) block.
        exit_blocks: IDs of blocks that represent exits (return / fall-off).
    """
    blocks: List[BasicBlock] = field(default_factory=list)
    edges: List[Tuple[int, int]] = field(default_factory=list)
    entry_block: int = 0
    exit_blocks: List[int] = field(default_factory=list)


# ---------------------------------------------------------------------------
# CFG Builder
# ---------------------------------------------------------------------------

class _CFGBuilder:
    """Internal class that walks an AST body and builds a CFG."""

    def __init__(self):
        self._next_id: int = 0
        self.blocks: Dict[int, BasicBlock] = {}
        self.edges: List[Tuple[int, int]] = []
        self._break_targets: List[int] = []     # stack of loop-exit blocks
        self._continue_targets: List[int] = []  # stack of loop-header blocks

    # ------------------------------------------------------------------
    # Helper: block management
    # ------------------------------------------------------------------

    def _new_block(self, block_type: str = "normal") -> BasicBlock:
        """Allocate and register a fresh BasicBlock."""
        blk = BasicBlock(id=self._next_id, block_type=block_type)
        self.blocks[self._next_id] = blk
        self._next_id += 1
        return blk

    def _add_edge(self, src: int, dst: int) -> None:
        """Record a directed edge and update predecessor/successor lists."""
        if (src, dst) not in self.edges:
            self.edges.append((src, dst))
        if dst not in self.blocks[src].successors:
            self.blocks[src].successors.append(dst)
        if src not in self.blocks[dst].predecessors:
            self.blocks[dst].predecessors.append(src)

    def _seal_block(self, blk: BasicBlock) -> None:
        """Set start/end line numbers from the block's statements."""
        if blk.stmts:
            blk.start_line = getattr(blk.stmts[0], "lineno", 0)
            last = blk.stmts[-1]
            # Use end_lineno when available (Python ≥ 3.8)
            blk.end_line = getattr(last, "end_lineno",
                                   getattr(last, "lineno", blk.start_line))

    # ------------------------------------------------------------------
    # Core: process a list of statements into blocks
    # ------------------------------------------------------------------

    def _process_stmts(
        self,
        stmts: List[ast.stmt],
        current: BasicBlock,
    ) -> List[BasicBlock]:
        """Process *stmts* starting from *current* block.

        Returns the list of "live" exit blocks after the last statement
        (blocks whose control flow falls off the end without a terminator).
        """
        live: List[BasicBlock] = [current]

        for stmt in stmts:
            # Every iteration starts with one or more *live* blocks that need
            # to receive the next statement or sub-graph.

            if isinstance(stmt, (ast.If,)):
                live = self._process_if(stmt, live)

            elif isinstance(stmt, (ast.For, ast.While)):
                live = self._process_loop(stmt, live)

            elif isinstance(stmt, ast.Try):
                live = self._process_try(stmt, live)

            elif isinstance(stmt, (ast.Return,)):
                # Append the return to whichever live blocks exist, then stop.
                for blk in live:
                    blk.stmts.append(stmt)
                    blk.block_type = "return"
                    self._seal_block(blk)
                live = []  # no fall-through

            elif isinstance(stmt, ast.Break):
                for blk in live:
                    blk.stmts.append(stmt)
                    self._seal_block(blk)
                    if self._break_targets:
                        self._add_edge(blk.id, self._break_targets[-1])
                live = []

            elif isinstance(stmt, ast.Continue):
                for blk in live:
                    blk.stmts.append(stmt)
                    self._seal_block(blk)
                    if self._continue_targets:
                        self._add_edge(blk.id, self._continue_targets[-1])
                live = []

            elif isinstance(stmt, ast.FunctionDef):
                # Nested function: treat as opaque statement in the outer CFG.
                for blk in live:
                    blk.stmts.append(stmt)
                # Do NOT recurse into it for the outer CFG.

            else:
                # Plain statement: append to every live block.
                for blk in live:
                    blk.stmts.append(stmt)

        # Seal all still-live blocks.
        for blk in live:
            self._seal_block(blk)

        return live

    # ------------------------------------------------------------------
    # if / elif / else
    # ------------------------------------------------------------------

    def _process_if(
        self,
        node: ast.If,
        live: List[BasicBlock],
    ) -> List[BasicBlock]:
        """Build if/elif/else sub-graph and return exit blocks."""
        merge = self._new_block()  # block after all branches converge

        all_exits: List[BasicBlock] = []

        # We may have a chain of elif nodes embedded as nested ast.If in
        # the orelse.  Process each condition block separately.
        def _handle_if_node(if_node: ast.If, incoming: List[BasicBlock]):
            # Create a decision block containing just the test statement.
            decision = self._new_block(block_type="decision")
            decision.stmts.append(if_node)
            decision.start_line = if_node.lineno
            decision.end_line = if_node.lineno

            # Connect all incoming live blocks to this decision.
            for blk in incoming:
                self._seal_block(blk)
                self._add_edge(blk.id, decision.id)

            # --- TRUE branch ---
            true_entry = self._new_block()
            self._add_edge(decision.id, true_entry.id)
            true_exits = self._process_stmts(if_node.body, true_entry)
            for ex in true_exits:
                self._add_edge(ex.id, merge.id)
            all_exits.extend(true_exits)

            # --- FALSE / ELIF / ELSE branch ---
            if if_node.orelse:
                if (
                    len(if_node.orelse) == 1
                    and isinstance(if_node.orelse[0], ast.If)
                ):
                    # elif chain
                    _handle_if_node(if_node.orelse[0], [decision])
                else:
                    # else block
                    else_entry = self._new_block()
                    self._add_edge(decision.id, else_entry.id)
                    else_exits = self._process_stmts(if_node.orelse, else_entry)
                    for ex in else_exits:
                        self._add_edge(ex.id, merge.id)
                    all_exits.extend(else_exits)
            else:
                # No else: decision can fall through directly to merge.
                self._add_edge(decision.id, merge.id)

        _handle_if_node(node, live)
        return [merge]

    # ------------------------------------------------------------------
    # for / while loops
    # ------------------------------------------------------------------

    def _process_loop(
        self,
        node: ast.stmt,
        live: List[BasicBlock],
    ) -> List[BasicBlock]:
        """Build for/while sub-graph."""
        # Header block holds the loop condition / iterator.
        header = self._new_block(block_type="decision")
        header.stmts.append(node)
        header.start_line = node.lineno
        header.end_line = node.lineno

        for blk in live:
            self._seal_block(blk)
            self._add_edge(blk.id, header.id)

        # Exit block (loop exit / else)
        loop_exit = self._new_block()

        self._break_targets.append(loop_exit.id)
        self._continue_targets.append(header.id)

        # Body
        body_entry = self._new_block()
        self._add_edge(header.id, body_entry.id)
        body_exits = self._process_stmts(node.body, body_entry)
        for ex in body_exits:
            # Back-edge to header
            self._add_edge(ex.id, header.id)

        self._break_targets.pop()
        self._continue_targets.pop()

        # else clause (if present)
        if node.orelse:
            else_entry = self._new_block()
            self._add_edge(header.id, else_entry.id)
            else_exits = self._process_stmts(node.orelse, else_entry)
            for ex in else_exits:
                self._add_edge(ex.id, loop_exit.id)
        else:
            self._add_edge(header.id, loop_exit.id)

        return [loop_exit]

    # ------------------------------------------------------------------
    # try / except / finally
    # ------------------------------------------------------------------

    def _process_try(
        self,
        node: ast.Try,
        live: List[BasicBlock],
    ) -> List[BasicBlock]:
        """Build try/except/finally sub-graph."""
        try_entry = self._new_block()
        for blk in live:
            self._seal_block(blk)
            self._add_edge(blk.id, try_entry.id)

        try_exits = self._process_stmts(node.body, try_entry)

        merge = self._new_block()

        # Handlers
        handler_exits: List[BasicBlock] = []
        for handler in node.handlers:
            h_entry = self._new_block(block_type="decision")
            h_entry.stmts.append(handler)
            h_entry.start_line = handler.lineno
            h_entry.end_line = handler.lineno
            # Every try block can jump to each handler.
            self._add_edge(try_entry.id, h_entry.id)
            h_body = self._new_block()
            self._add_edge(h_entry.id, h_body.id)
            h_exits = self._process_stmts(handler.body, h_body)
            handler_exits.extend(h_exits)

        # Else clause (runs when no exception)
        if node.orelse:
            orelse_entry = self._new_block()
            for ex in try_exits:
                self._add_edge(ex.id, orelse_entry.id)
            try_exits = self._process_stmts(node.orelse, orelse_entry)

        # Finally
        if node.finalbody:
            fin_entry = self._new_block()
            for ex in try_exits + handler_exits:
                self._add_edge(ex.id, fin_entry.id)
            fin_exits = self._process_stmts(node.finalbody, fin_entry)
            for ex in fin_exits:
                self._add_edge(ex.id, merge.id)
        else:
            for ex in try_exits + handler_exits:
                self._add_edge(ex.id, merge.id)

        return [merge]

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def build(self, stmts: List[ast.stmt]) -> CFGResult:
        """Build a CFG for the given list of AST statements."""
        entry = self._new_block(block_type="entry")
        exit_blks = self._process_stmts(stmts, entry)

        # Mark exit blocks
        result_exit_ids = []
        for blk in exit_blks:
            if blk.block_type not in ("return",):
                blk.block_type = "exit"
            result_exit_ids.append(blk.id)

        # Also collect any return blocks
        for blk in self.blocks.values():
            if blk.block_type == "return" and blk.id not in result_exit_ids:
                result_exit_ids.append(blk.id)

        return CFGResult(
            blocks=list(self.blocks.values()),
            edges=self.edges,
            entry_block=entry.id,
            exit_blocks=result_exit_ids,
        )


# ---------------------------------------------------------------------------
# Public API: build_cfg
# ---------------------------------------------------------------------------

def build_cfg(code: str) -> CFGResult:
    """Parse *code* and build a CFG for the first function definition found,
    or for top-level statements if no function is defined.

    Args:
        code: Python source code as a string.

    Returns:
        A :class:`CFGResult` describing the control flow graph.
    """
    code = textwrap.dedent(code)
    try:
        tree = ast.parse(code)
    except SyntaxError:
        # Return a minimal single-block CFG for unparseable code.
        blk = BasicBlock(id=0, block_type="entry", start_line=1, end_line=1)
        return CFGResult(blocks=[blk], edges=[], entry_block=0, exit_blocks=[0])

    # Prefer the first function definition for the CFG.
    target_stmts = tree.body
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            target_stmts = node.body
            break

    builder = _CFGBuilder()
    return builder.build(target_stmts)


# ---------------------------------------------------------------------------
# Cyclomatic Complexity
# ---------------------------------------------------------------------------

class _ComplexityVisitor(ast.NodeVisitor):
    """Counts decision nodes to compute McCabe cyclomatic complexity."""

    # Node types that each add 1 to the decision count.
    _DECISION_TYPES = (
        ast.If,
        ast.For,
        ast.While,
        ast.ExceptHandler,
        ast.Assert,
        ast.comprehension,
    )

    def __init__(self):
        self.decision_count: int = 0
        self.decision_points: List[Dict[str, Any]] = []

    def _record(self, node: ast.AST, kind: str) -> None:
        self.decision_count += 1
        line = getattr(node, "lineno", 0)
        # Extract first line text from the node where possible.
        text = kind
        if isinstance(node, ast.If):
            text = f"if {ast.unparse(node.test)}" if hasattr(ast, "unparse") else "if ..."
        elif isinstance(node, ast.For):
            text = (
                f"for {ast.unparse(node.target)} in {ast.unparse(node.iter)}"
                if hasattr(ast, "unparse") else "for ..."
            )
        elif isinstance(node, ast.While):
            text = f"while {ast.unparse(node.test)}" if hasattr(ast, "unparse") else "while ..."
        elif isinstance(node, ast.ExceptHandler):
            text = "except" + (f" {ast.unparse(node.type)}" if node.type else "")
        elif isinstance(node, ast.Assert):
            text = f"assert {ast.unparse(node.test)}" if hasattr(ast, "unparse") else "assert ..."
        self.decision_points.append({"line": line, "type": kind, "text": text})

    def visit_If(self, node):
        self._record(node, "if")
        self.generic_visit(node)

    def visit_For(self, node):
        self._record(node, "for")
        self.generic_visit(node)

    def visit_While(self, node):
        self._record(node, "while")
        self.generic_visit(node)

    def visit_ExceptHandler(self, node):
        self._record(node, "except")
        self.generic_visit(node)

    def visit_Assert(self, node):
        self._record(node, "assert")
        self.generic_visit(node)

    def visit_BoolOp(self, node):
        # Each `and`/`or` with more than 2 values adds n-1 decision points.
        extra = len(node.values) - 1
        for _ in range(extra):
            kind = "and" if isinstance(node.op, ast.And) else "or"
            self.decision_count += 1
            self.decision_points.append({
                "line": getattr(node, "lineno", 0),
                "type": kind,
                "text": kind,
            })
        self.generic_visit(node)

    def visit_comprehension(self, node):
        # Each comprehension with an `if` clause counts.
        for _ in node.ifs:
            self.decision_count += 1
            self.decision_points.append({
                "line": getattr(node, "lineno", 0),
                "type": "comprehension_if",
                "text": "comprehension if",
            })
        self.generic_visit(node)


def _complexity_for_stmts(stmts: List[ast.stmt]) -> Tuple[int, List[Dict]]:
    """Return (complexity, decision_points) for a list of statements."""
    module = ast.Module(body=stmts, type_ignores=[])
    visitor = _ComplexityVisitor()
    visitor.visit(module)
    return visitor.decision_count + 1, visitor.decision_points


def _complexity_label(m: int) -> Tuple[str, str]:
    """Return (label, color) for a McCabe complexity value *m*."""
    if m <= 5:
        return "LOW", "#4CAF50"
    elif m <= 10:
        return "MEDIUM", "#FF9800"
    elif m <= 20:
        return "HIGH", "#F44336"
    else:
        return "VERY_HIGH", "#B71C1C"


def compute_complexity(code: str) -> Dict[str, Any]:
    """Compute cyclomatic complexity for all functions in *code*.

    Returns a dict with:
        functions:          per-function heatmap data
        overall_complexity: int
        complexity_summary: "LOW" / "MEDIUM" / "HIGH" / "VERY_HIGH"
        decision_points:    list of {line, type, text}
    """
    code = textwrap.dedent(code)
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return {
            "functions": [],
            "overall_complexity": 1,
            "complexity_summary": "LOW",
            "decision_points": [],
        }

    functions = []
    all_decision_points: List[Dict] = []

    # Walk the top-level for function definitions.
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            m, dps = _complexity_for_stmts(node.body)
            label, color = _complexity_label(m)
            end_line = getattr(node, "end_lineno", node.lineno)
            functions.append({
                "name": node.name,
                "start_line": node.lineno,
                "end_line": end_line,
                "complexity": m,
                "complexity_label": label,
                "color": color,
            })
            all_decision_points.extend(dps)

    # Overall: treat the whole module as one unit.
    overall, top_dps = _complexity_for_stmts(tree.body)
    if not all_decision_points:
        all_decision_points = top_dps
    if not functions:
        # Script-level code – use module-level complexity.
        pass

    overall_label, _ = _complexity_label(overall)

    return {
        "functions": functions,
        "overall_complexity": overall,
        "complexity_summary": overall_label,
        "decision_points": all_decision_points,
    }


# ---------------------------------------------------------------------------
# Mermaid diagram generator
# ---------------------------------------------------------------------------

def _stmt_summary(stmt: ast.stmt) -> str:
    """Return a short, human-readable summary of an AST statement."""
    if hasattr(ast, "unparse"):
        try:
            raw = ast.unparse(stmt)
            # Truncate long lines.
            if len(raw) > 50:
                raw = raw[:47] + "..."
            return raw
        except Exception:
            pass

    # Fallback for older Python versions.
    t = type(stmt).__name__
    if isinstance(stmt, ast.If):
        return "if ..."
    elif isinstance(stmt, ast.For):
        return "for ..."
    elif isinstance(stmt, ast.While):
        return "while ..."
    elif isinstance(stmt, ast.Return):
        return "return ..."
    elif isinstance(stmt, ast.Assign):
        return "assign"
    elif isinstance(stmt, ast.Expr):
        return "expr"
    return t


def _escape_mermaid(text: str) -> str:
    """Escape characters that would break Mermaid node labels."""
    text = text.replace('"', "'")
    text = text.replace("<", "&lt;")
    text = text.replace(">", "&gt;")
    text = text.replace("{", "(")
    text = text.replace("}", ")")
    text = text.replace("[", "(")
    text = text.replace("]", ")")
    text = text.replace("#", "")
    text = text.replace("\\n", " ")
    return text


def cfg_to_mermaid(cfg_result: CFGResult, code_lines: List[str] = None) -> str:
    """Generate a Mermaid flowchart TD string from a :class:`CFGResult`.

    Decision blocks are coloured orange, return/exit blocks red, and normal
    blocks blue.

    Args:
        cfg_result:  The CFG to visualise.
        code_lines:  Optional list of source code lines (for richer labels).

    Returns:
        A Mermaid ``flowchart TD`` diagram string.
    """
    lines = ["flowchart TD"]

    block_map = {blk.id: blk for blk in cfg_result.blocks}

    # Node definitions
    for blk in cfg_result.blocks:
        label_parts = []
        if blk.stmts:
            label_parts.append(_escape_mermaid(_stmt_summary(blk.stmts[0])))
            if len(blk.stmts) > 1:
                label_parts.append(f"... +{len(blk.stmts) - 1} stmt(s)")
        elif blk.block_type == "entry":
            label_parts.append("ENTRY")
        elif blk.block_type in ("exit",):
            label_parts.append("EXIT")
        else:
            label_parts.append(f"Block {blk.id}")

        label = "\\n".join(label_parts)

        # Shape: decision = {}, return/exit = ([...])
        if blk.block_type == "decision":
            node_def = f'    B{blk.id}{{"{label}"}}'
        elif blk.block_type in ("return", "exit"):
            node_def = f'    B{blk.id}(["{label}"])'
        else:
            node_def = f'    B{blk.id}["{label}"]'

        lines.append(node_def)

    # Edge definitions
    for src_id, dst_id in cfg_result.edges:
        lines.append(f"    B{src_id} --> B{dst_id}")

    # Style definitions (colour by block type)
    style_map = {
        "decision": "fill:#FF9800,stroke:#E65100,color:#fff",
        "return":   "fill:#F44336,stroke:#B71C1C,color:#fff",
        "exit":     "fill:#F44336,stroke:#B71C1C,color:#fff",
        "entry":    "fill:#2196F3,stroke:#0D47A1,color:#fff",
        "normal":   "fill:#2196F3,stroke:#1565C0,color:#fff",
    }

    for blk in cfg_result.blocks:
        style = style_map.get(blk.block_type, style_map["normal"])
        lines.append(f"    style B{blk.id} {style}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Top-level analysis function
# ---------------------------------------------------------------------------

def analyze_code(code: str) -> Dict[str, Any]:
    """Perform a full CFG and complexity analysis of *code*.

    Args:
        code: Python source code as a string.

    Returns:
        A dictionary with keys:
            functions          – per-function heatmap data
            overall_complexity – int
            cfg                – serialisable CFG representation
            mermaid_diagram    – Mermaid flowchart string
            decision_points    – list of {line, type, text}
            complexity_summary – "LOW" / "MEDIUM" / "HIGH" / "VERY_HIGH"
    """
    if not code or not code.strip():
        blk = BasicBlock(id=0, block_type="entry", start_line=1, end_line=1)
        empty_cfg = CFGResult(blocks=[blk], edges=[], entry_block=0, exit_blocks=[0])
        return {
            "functions": [],
            "overall_complexity": 1,
            "cfg": _cfg_to_dict(empty_cfg),
            "mermaid_diagram": cfg_to_mermaid(empty_cfg),
            "decision_points": [],
            "complexity_summary": "LOW",
        }

    cfg_result = build_cfg(code)
    complexity_data = compute_complexity(code)
    code_lines = code.splitlines()
    mermaid = cfg_to_mermaid(cfg_result, code_lines)

    return {
        "functions": complexity_data["functions"],
        "overall_complexity": complexity_data["overall_complexity"],
        "cfg": _cfg_to_dict(cfg_result),
        "mermaid_diagram": mermaid,
        "decision_points": complexity_data["decision_points"],
        "complexity_summary": complexity_data["complexity_summary"],
    }


def _cfg_to_dict(cfg: CFGResult) -> Dict[str, Any]:
    """Convert a :class:`CFGResult` to a JSON-serialisable dictionary."""
    blocks_list = []
    for blk in cfg.blocks:
        blocks_list.append({
            "id": blk.id,
            "start_line": blk.start_line,
            "end_line": blk.end_line,
            "predecessors": blk.predecessors,
            "successors": blk.successors,
            "block_type": blk.block_type,
            "stmt_count": len(blk.stmts),
        })
    return {
        "blocks": blocks_list,
        "edges": cfg.edges,
        "entry_block": cfg.entry_block,
        "exit_blocks": cfg.exit_blocks,
    }
