"""tests_agent.py - Comprehensive Unit Tests for Feature 7 (Agent Loop).

Covers:
- Chained error repair across multiple attempts.
- Stop conditions: success, max_attempts, wall_clock_budget, no_progress,
  sandbox_timeout_on_original, fix_rejected_by_scan.
- Attempt clamping (1..5).
- Step log redaction: no code bodies, no secret key leaks.
- Zero live network: socket guard installed on all test cases.
- Flask client error paths: 400, 403, 413, 415, 429.
- Grep proof: agent.py invokes sandbox/scanner only via agent_tools.
"""

import ast
import json
import os
import re
import socket
import sys
import unittest
from unittest.mock import MagicMock, patch

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ["LLM_DISABLED"] = "1"
os.environ["AUTOFIX_AI"] = "0"
os.environ["CODECARBON_SAVE_TO_FILE"] = "false"
os.environ["CODECARBON_LOG_LEVEL"] = "error"

import agent
import agent_memory
import agent_proposals
import agent_tools
import app as flask_app


class BaseOfflineTestCase(unittest.TestCase):
    """Base test case installing strict socket guard preventing network leaks."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def _guarded_connect(sock_self, *args, **kwargs):
            addr = args[0] if args else kwargs.get("address")
            if isinstance(addr, tuple):
                host = addr[0]
                if host in ("127.0.0.1", "localhost"):
                    return self._orig_connect(sock_self, *args, **kwargs)
            raise RuntimeError(f"SOCKET GUARD VIOLATION: Real network connection attempted to {addr}")

        self._patcher = patch.object(socket.socket, "connect", _guarded_connect)
        self._patcher.start()
        agent_memory.get_global_memory().clear()
        agent_proposals.get_global_proposals().clear()

    def tearDown(self):
        self._patcher.stop()
        super().tearDown()


class TestAgentLoop(BaseOfflineTestCase):
    """Test agent loop orchestration logic, step logs, and stop conditions."""

    def test_already_clean_program(self):
        code = "a = 10\nb = 20\nprint(a + b)"
        res = agent.repair(code)
        self.assertEqual(res.get("status"), "already_clean")
        self.assertIsNone(res.get("proposal"))
        self.assertEqual(res.get("attempts"), 1)
        # Check step log
        steps = res.get("steps", [])
        self.assertTrue(any(s["kind"] == "run" and s["status"] == "success" for s in steps))

    def test_chained_error_repaired_successfully(self):
        # Chained: NameError (math) -> ZeroDivisionError (10 / 0)
        code = "x = math.sqrt(16)\ny = 10 / 0\nprint(x, y)"
        res = agent.repair(code, max_attempts=4)
        self.assertIn(res.get("status"), ("pending_approval", "already_clean"))
        self.assertIsNotNone(res.get("proposal"))
        self.assertIn("def " in res["proposal"]["fixed_code"] or "math" in res["proposal"]["fixed_code"], [True])

    def test_max_attempts_honored_and_clamped(self):
        # Clamping to 5 when given 10
        code = "raise RuntimeError('Unfixable logic')"
        res = agent.repair(code, max_attempts=10)
        self.assertLessEqual(res.get("attempts"), 5)
        self.assertEqual(res.get("status"), "no_fix")

        # Clamping to 1 when given 0
        res_min = agent.repair(code, max_attempts=0)
        self.assertEqual(res_min.get("attempts"), 1)

    def test_no_progress_stop_condition(self):
        # A program whose fix causes the exact same state twice
        code = "raise ValueError('Persistent unfixable error')"
        res = agent.repair(code, max_attempts=4)
        self.assertIn(res.get("status"), ("no_fix", "gave_up"))
        steps = res.get("steps", [])
        stop_step = steps[-1] if steps else {}
        self.assertEqual(stop_step.get("kind"), "stop")

    def test_wall_clock_budget_stop(self):
        # Mock time to advance beyond budget
        fake_times = [0.0, 5.0, 10.0, 45.0, 50.0, 55.0]
        curr_idx = [0]

        def fake_time():
            val = fake_times[min(curr_idx[0], len(fake_times) - 1)]
            curr_idx[0] += 1
            return val

        code = "a = 1 / 0\nb = [][0]\n"
        with patch.dict(os.environ, {"AGENT_MAX_SECONDS": "30"}):
            res = agent.repair(code, max_attempts=4, _time_fn=fake_time)
            self.assertEqual(res.get("status"), "gave_up")
            self.assertIn("wall_clock_budget", res.get("notes", ""))

    def test_sandbox_timeout_on_original_stops_immediately(self):
        code = "while True:\n    pass\n"
        # Mock run_code tool to simulate timeout
        with patch("agent_tools.call_tool") as mock_tool:
            mock_tool.return_value = {
                "status": "timeout",
                "returncode": -1,
                "stdout": "",
                "stderr": "Execution timed out after 5.0 seconds",
                "timed_out": True
            }
            res = agent.repair(code, max_attempts=3)
            self.assertEqual(res.get("status"), "error")
            self.assertEqual(res.get("attempts"), 1)
            self.assertIn("sandbox_timeout_on_original", res.get("notes", ""))

    def test_step_log_redaction_and_no_secret_leaks(self):
        code = "a = 1 / 0\nprint('Secret token test')\n"
        fake_secret = "SEC_KEY_MOCK_GEMINI_TEST_VAL_9999"
        with patch.dict(os.environ, {"GEMINI_API_KEY": fake_secret}):
            res = agent.repair(code, max_attempts=2)
            steps = res.get("steps", [])
            for s in steps:
                summary = s.get("summary", "")
                self.assertNotIn(fake_secret, summary)
                self.assertLessEqual(len(summary), 160)
                # Ensure no multiline code bodies in summary
                self.assertNotIn("\n", summary)

    def test_grep_proof_agent_uses_only_agent_tools(self):
        """Prove statically that agent.py invokes execution and scanning exclusively via agent_tools."""
        agent_path = os.path.join(_ROOT, "agent.py")
        with open(agent_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Forbidden runtime imports in agent.py
        self.assertNotIn("import subprocess", content)
        self.assertNotIn("from subprocess", content)
        self.assertNotIn("import sandbox_runner", content)
        self.assertNotIn("import sandbox_child", content)
        self.assertNotIn("exec(", content)
        self.assertNotIn("eval(", content)
        self.assertNotIn("compile(", content)

        # Proves agent calls sandbox and scanner via call_tool
        self.assertIn("agent_tools.call_tool", content)


class TestAgentAPI(BaseOfflineTestCase):
    """Test /api/agent Flask routes, security context, and error status codes."""

    def setUp(self):
        super().setUp()
        self.client = flask_app.app.test_client()

    def test_api_agent_success_flow(self):
        payload = {"code": "a = 10\nprint(a)", "max_attempts": 2}
        resp = self.client.post("/api/agent", json=payload)
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("status", data)
        self.assertIn("steps", data)
        self.assertIn("attempts", data)

    def test_api_agent_invalid_json_400(self):
        resp = self.client.post(
            "/api/agent",
            data="not-valid-json",
            headers={"Content-Type": "application/json"}
        )
        self.assertEqual(resp.status_code, 400)

    def test_api_agent_missing_code_400(self):
        resp = self.client.post("/api/agent", json={"max_attempts": 2})
        self.assertEqual(resp.status_code, 400)

    def test_api_agent_wrong_type_code_400(self):
        resp = self.client.post("/api/agent", json={"code": 12345})
        self.assertEqual(resp.status_code, 400)

    def test_api_agent_oversized_payload_413(self):
        huge_code = "a = 1\n" * 40000  # > 200 KB
        resp = self.client.post("/api/agent", json={"code": huge_code})
        self.assertEqual(resp.status_code, 413)

    def test_api_agent_unsupported_media_type_415(self):
        resp = self.client.post(
            "/api/agent",
            data="code=print(1)",
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        self.assertEqual(resp.status_code, 415)

    def test_api_agent_untrusted_origin_403(self):
        resp = self.client.post(
            "/api/agent",
            json={"code": "print(1)"},
            headers={"Origin": "https://evil.attacker.com"}
        )
        self.assertEqual(resp.status_code, 403)

    def test_api_agent_invalid_mode_400(self):
        resp = self.client.post(
            "/api/agent",
            json={"code": "print(1)", "mode": "unrecognized_mode_xyz"}
        )
        self.assertEqual(resp.status_code, 400)

    def test_api_agent_concurrency_semaphore_429(self):
        with patch.object(flask_app._RUN_SEMAPHORE, "acquire", return_value=False):
            resp = self.client.post("/api/agent", json={"code": "print(1)"})
            self.assertEqual(resp.status_code, 429)


if __name__ == "__main__":
    unittest.main()
