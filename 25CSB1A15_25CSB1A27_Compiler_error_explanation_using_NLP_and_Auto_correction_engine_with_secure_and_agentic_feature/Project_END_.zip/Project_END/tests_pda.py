"""tests_pda.py - Unit & Integration Tests for Formal Pushdown Automaton (Feature 2).

Validates:
1. Formal 7-tuple PDA specification M = (Q, Sigma, Gamma, delta, q0, Z0, F).
2. Clean Dyck language acceptance (parentheses, brackets, braces) reaching q_accept.
3. Instantaneous Description (ID) generation (q, w, gamma) and step-by-step tape/stack consistency.
4. Mismatched delimiter detection and transition to q_reject.
5. Unmatched closing delimiter (stack underflow) detection and transition to q_reject.
6. Unclosed opening delimiter detection at tape exhaustion.
7. Immunity to brackets inside string literals and comments.
8. Mermaid flowchart generation with acceptance and rejection styling.
9. Deterministic bracket repair integration.
10. Flask API endpoints: /api/pda/trace, /api/pda/repair, and /api/pda/definition.
"""

import unittest
import pda_engine
import app as flask_app


class TestPDACore(unittest.TestCase):
    """Core tests for the formal Pushdown Automaton engine."""

    def setUp(self):
        self.pda = pda_engine.PushdownAutomaton()

    def test_formal_7_tuple_definition(self):
        """PDA exposes standard 7-tuple definition."""
        defn = self.pda.get_definition()
        self.assertIn("Q", defn)
        self.assertIn("Sigma", defn)
        self.assertIn("Gamma", defn)
        self.assertIn("q0", defn)
        self.assertIn("Z0", defn)
        self.assertIn("F", defn)
        self.assertEqual(defn["q0"], "q0")
        self.assertEqual(defn["Z0"], "Z0")
        self.assertIn("q_accept", defn["F"])

    def test_clean_balanced_brackets(self):
        """Balanced expressions successfully transition to q_accept."""
        cases = [
            "()",
            "([])",
            "{[()]}",
            "()[]{}",
            "x = [1, 2, {'a': (3, 4)}]",
            "def foo(x): return (x + [1, 2])\n",
            ""
        ]
        for expr in cases:
            res = pda_engine.animate_pda(expr)
            self.assertTrue(res["accepted"], f"Expected accepted for: '{expr}'")
            self.assertEqual(res["final_state"], "q_accept")
            self.assertEqual(len(res["problems"]), 0)

    def test_instantaneous_descriptions(self):
        """Instantaneous Descriptions (IDs) are formatted as (q, w, gamma) at each step."""
        res = pda_engine.animate_pda("([{}])")
        self.assertTrue(res["accepted"])
        steps = res["steps"]
        self.assertGreater(len(steps), 1)

        for s in steps:
            self.assertIn("id", s)
            self.assertIn("stack", s)
            self.assertIn("remaining_tape", s)
            self.assertIn("action", s)
            self.assertTrue(s["id"].startswith("("))
            self.assertTrue(s["id"].endswith(")"))

        # Verify initial ID
        self.assertIn("q0", steps[0]["id"])
        # Verify final ID
        self.assertIn("q_accept", steps[-1]["id"])

    def test_mismatched_brackets_rejected(self):
        """Mismatched closing brackets halt in q_reject."""
        mismatched_cases = [
            "(]",
            "{)",
            "[}",
            "x = (1 + [2, 3))",
        ]
        for expr in mismatched_cases:
            res = pda_engine.animate_pda(expr)
            self.assertFalse(res["accepted"], f"Expected reject for: '{expr}'")
            self.assertEqual(res["final_state"], "q_reject")
            self.assertTrue(any(p["kind"] == "mismatched" for p in res["problems"]))

    def test_unmatched_closing_brackets_rejected(self):
        """Unmatched closing delimiters without opening brackets trigger q_reject."""
        stray_cases = [
            ")",
            "]",
            "}",
            "def f(): return 1)\n",
        ]
        for expr in stray_cases:
            res = pda_engine.animate_pda(expr)
            self.assertFalse(res["accepted"], f"Expected reject for: '{expr}'")
            self.assertEqual(res["final_state"], "q_reject")
            self.assertTrue(any(p["kind"] == "unmatched_closing" for p in res["problems"]))

    def test_unclosed_opening_brackets_rejected(self):
        """Unclosed opening brackets when tape is exhausted trigger q_reject."""
        unclosed_cases = [
            "(",
            "([",
            "def f(x: return x\n",
        ]
        for expr in unclosed_cases:
            res = pda_engine.animate_pda(expr)
            self.assertFalse(res["accepted"], f"Expected reject for: '{expr}'")
            self.assertEqual(res["final_state"], "q_reject")
            self.assertTrue(any(p["kind"] == "unclosed" for p in res["problems"]))

    def test_brackets_in_literals_and_comments_ignored(self):
        """Brackets in comments and strings must not trigger PDA stack operations."""
        code = (
            "# Unmatched comment brackets: ) ] }\n"
            "msg = 'String brackets: ( [ {'\n"
            "actual = (1 + 2)\n"
        )
        res = pda_engine.animate_pda(code)
        self.assertTrue(res["accepted"])
        self.assertEqual(res["final_state"], "q_accept")
        # Only actual (1 + 2) brackets should be processed (1 open, 1 close + init + accept = 4 steps)
        bracket_steps = [s for s in res["steps"] if s["consumed_char"] in ("(", ")")]
        self.assertEqual(len(bracket_steps), 2)

    def test_mermaid_diagram_generation(self):
        """Mermaid diagram is produced with valid flowchart LR syntax."""
        res_ok = pda_engine.animate_pda("()")
        self.assertIn("flowchart LR", res_ok["mermaid_diagram"])
        self.assertIn("q_accept", res_ok["mermaid_diagram"])
        self.assertIn("fill:#4CAF50", res_ok["mermaid_diagram"])

        res_err = pda_engine.animate_pda("(]")
        self.assertIn("flowchart LR", res_err["mermaid_diagram"])
        self.assertIn("q_reject", res_err["mermaid_diagram"])
        self.assertIn("fill:#F44336", res_err["mermaid_diagram"])

    def test_deterministic_repair_integration(self):
        """Broken code offers a deterministic repaired candidate."""
        res = pda_engine.animate_pda("print(1 + 2")
        self.assertFalse(res["accepted"])
        self.assertIsNotNone(res["repaired_code"])
        self.assertTrue(res["repaired_code"].endswith(")"))


class TestPDAFlaskAPI(unittest.TestCase):
    """API endpoint tests for PDA trace and repair."""

    def setUp(self):
        flask_app.app.config["TESTING"] = True
        self.client = flask_app.app.test_client()

    def test_get_pda_definition_endpoint(self):
        """GET /api/pda/definition returns 7-tuple definition."""
        resp = self.client.get("/api/pda/definition")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["status"], "success")
        self.assertIn("definition", data)
        self.assertIn("Q", data["definition"])
        self.assertIn("Gamma", data["definition"])

    def test_post_pda_trace_endpoint(self):
        """POST /api/pda/trace returns animation steps and IDs."""
        resp = self.client.post("/api/pda/trace", json={"expression": "(1 + [2, 3])"})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertTrue(data["accepted"])
        self.assertEqual(data["final_state"], "q_accept")
        self.assertIn("steps", data)
        self.assertIn("mermaid_diagram", data)

    def test_post_pda_repair_endpoint(self):
        """POST /api/pda/repair returns repaired bracket code."""
        resp = self.client.post("/api/pda/repair", json={"code": "x = (1 + 2"})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertTrue(data["fixed"])
        self.assertTrue(data["repaired_code"].endswith(")"))


if __name__ == "__main__":
    unittest.main()
