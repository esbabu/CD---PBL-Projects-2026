"""tokenizer.py - Deterministic Lexical Analyzer for IntelliFix.

Implements Feature 5 (TOC Week 3):
- Regular expression-based tokenizer with prioritized pattern specifications.
- Longest-match rule with comments and strings prioritized over operators and identifiers.
- Keyword recognition separated from identifier lexical analysis.
- Explicit Token representation (type, text, line, col, end_line, end_col, subtype).
- Robust error handling (unterminated strings, invalid numbers, unknown characters)
  without raising exceptions.
- Linear-time single pass guaranteed without catastrophic backtracking.
- INDENT/DEDENT handling is intentionally out of scope (syntax parser's responsibility).
"""

from __future__ import annotations

import keyword
import re
from typing import Any, Dict, List, Optional, Tuple

# Python keywords list (kwlist). Soft keywords (match, case, type, _) remain NAME tokens.
SOFT_KEYWORDS = {"match", "case", "type", "_"}
STANDARD_KEYWORDS = set(keyword.kwlist) - SOFT_KEYWORDS

# Multi-character and single-character operators ordered longest-first
OPERATORS_ORDERED = [
    "**=", "//=", ">>=", "<<=", "->", ":=", "...",
    "!=", "==", "<=", ">=", "**", "//", "<<", ">>",
    "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "@=",
    "+", "-", "*", "/", "%", "&", "|", "^", "~",
    "<", ">", "=", ".", ",", ":", ";", "@"
]

BRACKETS = {"(", ")", "[", "]", "{", "}"}

# Precompiled regex components (strictly non-catastrophic backtracking)
# String prefix pattern: r, u, b, f, br, rb, fr, rf in any case
PREFIX_PAT = r"(?:[rRbBuU]|[bB][rR]|[rR][bB]|[fF][rR]|[rR][fF]|[fF])?"

# Hex, oct, bin, float, dec number patterns
NUM_HEX = r"0[xX](?:_?[0-9a-fA-F])+"
NUM_BIN = r"0[bB](?:_?[01])+"
NUM_OCT = r"0[oO](?:_?[0-7])+"
NUM_FLOAT = r"(?:\d(?:_?\d)*\.(?:\d(?:_?\d)*)?|\.\d(?:_?\d)*)(?:[eE][+-]?\d(?:_?\d)*)?[jJ]?|\d(?:_?\d)*[eE][+-]?\d(?:_?\d)*[jJ]?|\d(?:_?\d)*[jJ]"
NUM_DEC = r"\d(?:_?\d)*[jJ]?"

# Master regex for initial chunk matching at position
# Notice: Comments and strings matched first.
# Triple quotes must be checked before single quotes, and single quotes must NOT match triple quote delimiters.
MASTER_PATTERNS = [
    # Comment
    ("COMMENT", r"#[^\r\n]*"),
    # Triple-quoted strings (raw/prefixed)
    ("TRIPLE_STRING", PREFIX_PAT + r'(?:"""[\s\S]*?"""|\'\'\'[\s\S]*?\'\'\')'),
    # Unterminated triple-quoted strings (starts with triple quote and has no closing triple quote)
    ("UNTERM_TRIPLE", PREFIX_PAT + r'(?:"""[\s\S]*|\'\'\'[\s\S]*)'),
    # Single-quoted strings (handling escaped newlines \n or \r\n and escaped chars)
    # Ensure they do NOT match triple quotes
    ("SINGLE_STRING", PREFIX_PAT + r'(?:(?<!")"(?!"")(?:[^"\\\r\n]|\\(?:\r\n|[\s\S]))*"|(?<!\')\'(?!\'\')(?:[^\'\\\r\n]|\\(?:\r\n|[\s\S]))*\')'),
    # Unterminated single-line string
    ("UNTERM_SINGLE", PREFIX_PAT + r'(?:(?<!")"(?!"")(?:[^"\\\r\n]|\\(?:\r\n|[^\r\n]))*|(?<!\')\'(?!\'\')(?:[^\'\\\r\n]|\\(?:\r\n|[^\r\n]))*)'),
    # Numbers
    ("NUM_HEX", NUM_HEX),
    ("NUM_BIN", NUM_BIN),
    ("NUM_OCT", NUM_OCT),
    ("NUM_FLOAT", NUM_FLOAT),
    # Invalid number literal: e.g. 12ab, 0xZZ, 1if (digits followed by letter chars not being a standalone j/J)
    ("INVALID_NUM", r"\d(?:_?\d)*(?:\.(?:\d(?:_?\d)*)?)?(?:[eE][+-]?\d(?:_?\d)*)?(?!(?:[jJ]\b))[A-Za-z]\w*"),
    ("NUM_DEC", NUM_DEC),
    # Identifiers: unicode-aware [^\W\d]\w*
    ("NAME", r"[^\W\d]\w*"),
    # Newline
    ("NEWLINE", r"\r\n|\r|\n"),
    # Brackets
    ("BRACKET", r"[\(\)\[\]\{\}]"),
    # Operators (longest first)
    ("OP", r"|".join(re.escape(op) for op in OPERATORS_ORDERED)),
    # Line continuation: backslash followed by newline
    ("LINECONT", r"\\(?:\r\n|\r|\n)"),
    # Whitespace (spaces, tabs, form feeds - skipped)
    ("WHITESPACE", r"[ \t\f]+"),
    # Fallback error token (any single character not matched)
    ("ERRORTOKEN", r"."),
]

# Compile master regex once
_MASTER_REGEX = re.compile(
    "|".join(f"(?P<{name}>{pattern})" for name, pattern in MASTER_PATTERNS)
)


def _compute_end_pos(text: str, start_line: int, start_col: int) -> Tuple[int, int]:
    """Calculate the 1-based end_line and 0-based end_col after consuming text."""
    lines = text.splitlines(keepends=True)
    if not lines:
        return start_line, start_col
    if len(lines) == 1:
        return start_line, start_col + len(lines[0])
    end_line = start_line + len(lines) - 1
    last_line = lines[-1]
    if last_line.endswith(("\r", "\n")):
        end_col = len(last_line.rstrip("\r\n"))
    else:
        end_col = len(last_line)
    return end_line, end_col


def tokenize(code: str, max_tokens: int = 20000) -> Dict[str, Any]:
    """Tokenize Python source code deterministically.

    Args:
        code: Input string containing Python source code.
        max_tokens: Maximum tokens to emit before truncation flag is set.

    Returns:
        Dictionary with keys:
            tokens: List of token dicts {type, text, line, col, end_line, end_col, subtype}
            errors: List of error dicts {kind, message, line, col}
            partial: Boolean indicating whether unclosed constructs remain
            truncated: Boolean indicating whether max_tokens limit was hit
    """
    if not isinstance(code, str):
        return {"tokens": [], "errors": [{"kind": "type_error", "message": "Expected string input", "line": 1, "col": 0}], "partial": False, "truncated": False}

    # Handle leading Byte Order Mark (BOM)
    if code.startswith("\ufeff"):
        code = code[1:]

    tokens: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    truncated = False
    partial = False

    pos = 0
    line = 1
    col = 0
    length = len(code)

    while pos < length:
        if len(tokens) >= max_tokens:
            truncated = True
            break

        match = _MASTER_REGEX.match(code, pos)
        if not match:
            # Should not happen because ERRORTOKEN matches any single char
            ch = code[pos]
            errors.append({
                "kind": "unknown_character",
                "message": f"Unexpected character {ascii(ch)}",
                "line": line,
                "col": col,
            })
            pos += 1
            col += 1
            continue

        kind = match.lastgroup
        text = match.group()
        span_len = len(text)

        if kind == "WHITESPACE":
            pos += span_len
            col += span_len
            continue

        elif kind == "LINECONT":
            # Backslash followed by newline
            pos += span_len
            line += 1
            col = 0
            continue

        elif kind == "NEWLINE":
            end_line = line + 1
            end_col = 0
            tokens.append({
                "type": "NEWLINE",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })
            pos += span_len
            line += 1
            col = 0
            continue

        end_line, end_col = _compute_end_pos(text, line, col)

        if kind == "COMMENT":
            tokens.append({
                "type": "COMMENT",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind in ("TRIPLE_STRING", "SINGLE_STRING"):
            tokens.append({
                "type": "STRING",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "UNTERM_TRIPLE":
            # Unterminated triple-quoted string
            partial = True
            errors.append({
                "kind": "unterminated_triple_string",
                "message": f"Unterminated triple-quoted string literal starting at line {line}, col {col}",
                "line": line,
                "col": col,
            })
            tokens.append({
                "type": "ERRORTOKEN",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "UNTERM_SINGLE":
            # Unterminated single-line string
            partial = True
            errors.append({
                "kind": "unterminated_string",
                "message": f"Unterminated string literal at line {line}, col {col}",
                "line": line,
                "col": col,
            })
            tokens.append({
                "type": "ERRORTOKEN",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind in ("NUM_HEX", "NUM_BIN", "NUM_OCT", "NUM_FLOAT", "NUM_DEC"):
            tokens.append({
                "type": "NUMBER",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "INVALID_NUM":
            # e.g. 12ab or 1if
            # Check if trailing letters form a python keyword
            # Find the split between leading digits and trailing identifier
            split_idx = 0
            for i, c in enumerate(text):
                if c.isalpha() or c == "_":
                    split_idx = i
                    break
            trailing = text[split_idx:]
            if trailing in STANDARD_KEYWORDS or trailing in SOFT_KEYWORDS:
                # Warning-level note, but still valid token split or noted
                errors.append({
                    "kind": "invalid_number_warning",
                    "message": f"Digits directly followed by keyword '{trailing}' at line {line}, col {col}",
                    "line": line,
                    "col": col,
                })
            else:
                errors.append({
                    "kind": "invalid_number_literal",
                    "message": f"Invalid number literal '{text}' at line {line}, col {col}",
                    "line": line,
                    "col": col,
                })
            tokens.append({
                "type": "ERRORTOKEN",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "NAME":
            if text in STANDARD_KEYWORDS:
                tok_type = "KEYWORD"
            else:
                tok_type = "NAME"
            tokens.append({
                "type": tok_type,
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "BRACKET":
            tokens.append({
                "type": "BRACKET",
                "text": text,
                "subtype": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "OP":
            tokens.append({
                "type": "OP",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        elif kind == "ERRORTOKEN":
            errors.append({
                "kind": "unknown_character",
                "message": f"Unexpected character {ascii(text)} at line {line}, col {col}",
                "line": line,
                "col": col,
            })
            tokens.append({
                "type": "ERRORTOKEN",
                "text": text,
                "line": line,
                "col": col,
                "end_line": end_line,
                "end_col": end_col,
            })

        pos += span_len
        line = end_line
        col = end_col

    return {
        "tokens": tokens,
        "errors": errors,
        "partial": partial,
        "truncated": truncated,
    }
