"""tests_agent_tools.py - Comprehensive Unit Tests for Feature 8 (Tool Registry).

Covers:
- Unknown tool invocation refused.
- Schema violations: unexpected extra keys, missing required parameters, wrong types, oversize strings.
- read_file path traversal, ADS, device names, NUL byte, workspace boundary confinement.
- run_code enforces security scan_gate before sandbox invocation.
- apply_patch creates in-memory proposal ONLY and NEVER writes to disk.
- Tool discovery manifest (/api/agent/tools).
- Socket guard installed on all test cases.
"""

import os
import socket
import sys
import unittest
from unittest.mock import MagicMock, patch

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ["LLM_DISABLED"] = "1"
os.environ["AUTOFIX_AI"] = "0"
os.environ["CODECARBON_SAVE_TO_FILE"] = "false"
os.environ["CODECARBON_LOG_LEVEL"] = "error"

import agent_proposals
import agent_tools
import app as flask_app


class TestAgentTools(unittest.TestCase):
    """Test tool registry validation, execution boundaries, and schema enforcement."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def _guarded_connect(sock_self, *args, **kwargs):
            addr = args[0] if args else kwargs.get("address")
            if isinstance(addr, tuple) and addr[0] in ("127.0.0.1", "localhost"):
                return self._orig_connect(sock_self, *args, **kwargs)
            raise RuntimeError(f"SOCKET GUARD VIOLATION: Unexpected connection to {addr}")

        self._patcher = patch.object(socket.socket, "connect", _guarded_connect)
        self._patcher.start()
        agent_proposals.get_global_proposals().clear()

    def tearDown(self):
        self._patcher.stop()
        super().tearDown()

    def test_unknown_tool_refused(self):
        res = agent_tools.call_tool("nonexistent_tool_xyz", {"code": "print(1)"})
        self.assertEqual(res.get("status"), "error")
        self.assertIn("Unknown tool", res.get("error", ""))

    def test_schema_violation_extra_key(self):
        res = agent_tools.call_tool("run_code", {"code": "print(1)", "malicious_extra_key": True})
        self.assertEqual(res.get("status"), "error")
        self.assertIn("Unexpected arguments", res.get("error", ""))

    def test_schema_violation_missing_required_key(self):
        res = agent_tools.call_tool("run_code", {"timeout": 5.0})
        self.assertEqual(res.get("status"), "error")
        self.assertIn("Missing required argument 'code'", res.get("error", ""))

    def test_schema_violation_wrong_type(self):
        res = agent_tools.call_tool("run_code", {"code": 12345})
        self.assertEqual(res.get("status"), "error")
        self.assertIn("expected type", res.get("error", ""))

    def test_schema_violation_oversize_code(self):
        huge_code = "x = 1\n" * 40000
        res = agent_tools.call_tool("run_code", {"code": huge_code})
        self.assertEqual(res.get("status"), "error")
        self.assertIn("exceeds", res.get("error", ""))

    def test_read_file_traversal_refused(self):
        traversals = [
            "../../etc/passwd",
            "..\\..\\Windows\\win.ini",
            "test1.py:ads_stream",
            "NUL",
            "CON.py",
            "aux",
            "test\0evil.py",
            "test1.py.",
            "test1.py "
        ]
        for bad_name in traversals:
            res = agent_tools.call_tool("read_file", {"filename": bad_name})
            self.assertEqual(res.get("status"), "error", f"Allowed invalid path: {bad_name}")

    def test_read_file_legitimate_workspace_file(self):
        res = agent_tools.call_tool("read_file", {"filename": "test1.py"})
        self.assertEqual(res.get("status"), "success")
        self.assertIn("content", res)
        self.assertGreater(res.get("size", 0), 0)

    def test_run_code_blocks_security_gate_violations(self):
        malicious_code = "import os\nos.system('echo pwned')\n"
        res = agent_tools.call_tool("run_code", {"code": malicious_code})
        self.assertEqual(res.get("status"), "security_blocked")
        self.assertTrue(res.get("blocked"))
        self.assertIn("reasons", res)

    def test_apply_patch_creates_proposal_and_writes_no_file(self):
        # Watch workspace before and after
        before_files = set(os.listdir(_ROOT))
        orig_code = "a = 10 / 0"
        fixed_code = "a = 10 / 1"
        import hashlib
        orig_hash = hashlib.sha256(orig_code.encode("utf-8")).hexdigest()

        res = agent_tools.call_tool("apply_patch", {
            "original_code": orig_code,
            "fixed_code": fixed_code,
            "original_hash": orig_hash,
            "filename": "test_watch.py"
        })
        self.assertEqual(res.get("status"), "pending_approval")
        self.assertIn("proposal_id", res)

        after_files = set(os.listdir(_ROOT))
        # PROVE THAT ZERO FILES WERE WRITTEN TO WORKSPACE
        self.assertEqual(before_files, after_files)

    def test_get_tools_manifest_endpoint(self):
        client = flask_app.app.test_client()
        resp = client.get("/api/agent/tools")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        tools = data.get("tools", [])
        tool_names = {t["name"] for t in tools}
        self.assertEqual(tool_names, {"run_code", "scan_security", "read_file", "apply_patch"})
        # Only apply_patch requires human approval
        for t in tools:
            if t["name"] == "apply_patch":
                self.assertTrue(t["requires_approval"])
            else:
                self.assertFalse(t["requires_approval"])


if __name__ == "__main__":
    unittest.main()
