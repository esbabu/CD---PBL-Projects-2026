"""agent_tools.py - Fixed Tool Registry and Validation Engine for IntelliFix Agent.

Provides an immutable allow-list of exactly four tools (Feature 8):
1. run_code: Executes user code in sandbox AFTER passing security scan_gate.
2. scan_security: Runs static security analyzer and returns rule findings.
3. read_file: Strict workspace-only file reader reusing Week 2 path protections.
4. apply_patch: Generates an in-memory pending proposal ONLY; NEVER writes to disk.

All tool invocations go through call_tool(name, args) which enforces strict
schema validation, type checks, boundary caps, and no-extra-key rules.
"""

import hashlib
import os
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
MAX_CODE_SIZE_BYTES = 204800  # 200 KB
MAX_FILENAME_LEN = 100

WINDOWS_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
    "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
}


def _validate_workspace_filename(filename: str) -> Tuple[bool, Optional[str]]:
    """Strictly validates that filename does not escape the workspace root."""
    if not filename or not isinstance(filename, str):
        return False, "Filename must be a non-empty string"
    if len(filename) > MAX_FILENAME_LEN:
        return False, f"Filename exceeds maximum length limit of {MAX_FILENAME_LEN} characters"
    if not filename.isascii():
        return False, "Filename must contain only ASCII characters"
    if filename.endswith(".") or filename.endswith(" "):
        return False, "Filename cannot end with dots or whitespace"
    if any(ch in filename for ch in ["/", "\\", ":", "\0"]):
        return False, "Filename contains invalid path separators or forbidden characters"
    if ".." in filename:
        return False, "Path traversal sequences ('..') are strictly prohibited"

    stem = filename.split(".")[0].upper()
    if stem in WINDOWS_RESERVED_NAMES or filename.upper() in WINDOWS_RESERVED_NAMES:
        return False, f"'{filename}' is a reserved Windows device name"

    # Workspace confinement check
    try:
        target_path = Path(WORKSPACE_DIR, filename).resolve()
        workspace_path = Path(WORKSPACE_DIR).resolve()
        if target_path != workspace_path and workspace_path not in target_path.parents:
            return False, "Path resolution escapes workspace directory"
        if target_path.is_symlink() or os.path.islink(str(target_path)):
            return False, "Symlinks and junctions are strictly prohibited"
        if target_path.exists():
            try:
                attrs = os.lstat(str(target_path)).st_file_attributes
                if attrs & 0x400:  # Reparse point / junction
                    return False, "Reparse points are strictly prohibited"
            except Exception:
                pass
    except Exception as e:
        return False, f"Path resolution failed: {e}"

    return True, None


# ==============================================================================
# TOOL HANDLERS
# ==============================================================================

def _handle_run_code(args: Dict[str, Any]) -> Dict[str, Any]:
    """Execute code in sandbox runner AFTER passing security scan_gate."""
    code = args["code"]
    timeout = float(args.get("timeout", 5.0))

    # Pre-execution security scan gate
    try:
        import security_analyzer
        gate = security_analyzer.scan_gate(code)
        if not gate.get("allowed", True):
            return {
                "status": "security_blocked",
                "returncode": -1,
                "stdout": "",
                "stderr": f"Security scan blocked execution: {', '.join(gate.get('reasons', []))}",
                "blocked": True,
                "reasons": gate.get("reasons", [])
            }
    except Exception as e:
        return {"status": "error", "error": f"Security scan failed: {e}"}

    # Sandboxed execution
    try:
        import sandbox_runner
        res = sandbox_runner.run_in_sandbox(code, timeout=timeout)
        exit_code = res.get("exit_code", res.get("returncode", 0))
        raw_status = res.get("status", "ok")
        error_info = res.get("error")
        stderr_msg = res.get("stderr", "")
        if not stderr_msg and isinstance(error_info, dict):
            stderr_msg = error_info.get("error_message", "")
        return {
            "status": raw_status,
            "exit_code": exit_code,
            "returncode": exit_code,
            "stdout": res.get("stdout", ""),
            "stderr": stderr_msg,
            "error": error_info,
            "timed_out": raw_status == "timeout",
            "duration_ms": int(res.get("duration_ms", 0))
        }
    except Exception as e:
        return {"status": "sandbox_failure", "exit_code": -1, "returncode": -1, "error": str(e)}


def _handle_scan_security(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run static AST / regex scanner against code and return security findings."""
    code = args["code"]
    try:
        import security_analyzer
        gate = security_analyzer.scan_gate(code)
        findings = security_analyzer.scan_code(code)
        return {
            "status": "success",
            "allowed": gate.get("allowed", True),
            "findings_count": len(findings),
            "findings": findings,
            "reasons": gate.get("reasons", [])
        }
    except Exception as e:
        return {"status": "error", "error": f"Scanner failed: {e}"}


def _handle_read_file(args: Dict[str, Any]) -> Dict[str, Any]:
    """Strictly confined workspace file reader."""
    filename = args["filename"]
    is_valid, err_msg = _validate_workspace_filename(filename)
    if not is_valid:
        return {"status": "error", "error": err_msg or "Invalid filename"}

    target_path = os.path.join(WORKSPACE_DIR, filename)
    if not os.path.exists(target_path):
        return {"status": "error", "error": f"File '{filename}' not found"}

    try:
        with open(target_path, "r", encoding="utf-8", errors="replace") as fp:
            content = fp.read(MAX_CODE_SIZE_BYTES + 1)
        if len(content.encode("utf-8")) > MAX_CODE_SIZE_BYTES:
            return {"status": "error", "error": "File exceeds maximum 200 KB size limit"}
        return {
            "status": "success",
            "filename": filename,
            "content": content,
            "size": len(content)
        }
    except Exception as e:
        return {"status": "error", "error": f"Failed to read file: {e}"}


def _handle_apply_patch(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a pending proposal in memory only; NEVER writes to disk."""
    import agent_proposals
    original_code = args.get("original_code", "")
    fixed_code = args["fixed_code"]
    filename = args.get("filename")
    tier = args.get("tier", "rules")
    findings = args.get("findings", [])

    proposals = agent_proposals.get_global_proposals()
    prop = proposals.create(
        original_code=original_code,
        fixed_code=fixed_code,
        filename=filename,
        tier=tier,
        findings=findings
    )
    return {
        "status": "pending_approval",
        "proposal_id": prop["id"],
        "diff": prop["diff"],
        "original_hash": prop["original_hash"],
        "fixed_code_hash": prop["fixed_code_hash"],
        "expires_at": prop["expires_at"]
    }


# ==============================================================================
# TOOL REGISTRY DEFINITION
# ==============================================================================

TOOL_REGISTRY: Dict[str, Dict[str, Any]] = {
    "run_code": {
        "name": "run_code",
        "description": "Execute Python code in sandbox runner after scan_gate verification.",
        "requires_approval": False,
        "handler": _handle_run_code,
        "schema": {
            "code": {"type": str, "max_bytes": MAX_CODE_SIZE_BYTES, "required": True},
            "timeout": {"type": (int, float), "min": 0.1, "max": 10.0, "required": False}
        }
    },
    "scan_security": {
        "name": "scan_security",
        "description": "Scan Python source code using static AST and regex security rules.",
        "requires_approval": False,
        "handler": _handle_scan_security,
        "schema": {
            "code": {"type": str, "max_bytes": MAX_CODE_SIZE_BYTES, "required": True}
        }
    },
    "read_file": {
        "name": "read_file",
        "description": "Read file contents safely from within the workspace directory.",
        "requires_approval": False,
        "handler": _handle_read_file,
        "schema": {
            "filename": {"type": str, "max_len": MAX_FILENAME_LEN, "required": True}
        }
    },
    "apply_patch": {
        "name": "apply_patch",
        "description": "Create an in-memory pending patch proposal requiring human approval.",
        "requires_approval": True,
        "handler": _handle_apply_patch,
        "schema": {
            "fixed_code": {"type": str, "max_bytes": MAX_CODE_SIZE_BYTES, "required": True},
            "original_hash": {"type": str, "regex": r"^[a-fA-F0-9]{64}$", "required": True},
            "original_code": {"type": str, "max_bytes": MAX_CODE_SIZE_BYTES, "required": False},
            "filename": {"type": (str, type(None)), "required": False},
            "tier": {"type": str, "required": False},
            "findings": {"type": list, "required": False}
        }
    }
}


def call_tool(name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Invoke a registered tool with strict allow-list and schema enforcement.

    Rejects unknown tool names, unexpected keys, missing required arguments,
    incorrect argument types, or payloads exceeding buffer limits.
    """
    if not isinstance(name, str) or name not in TOOL_REGISTRY:
        return {
            "status": "error",
            "error": f"Unknown tool '{name}'. Allowed tools: {sorted(list(TOOL_REGISTRY.keys()))}"
        }

    if not isinstance(args, dict):
        return {"status": "error", "error": f"Tool arguments for '{name}' must be a dictionary"}

    tool_def = TOOL_REGISTRY[name]
    schema = tool_def["schema"]

    # 1. Reject unexpected / extra keys
    extra_keys = set(args.keys()) - set(schema.keys())
    if extra_keys:
        return {
            "status": "error",
            "error": f"Schema violation for tool '{name}': Unexpected arguments {sorted(list(extra_keys))}"
        }

    # 2. Validate expected parameters
    for param_name, rules in schema.items():
        if rules.get("required", False) and param_name not in args:
            return {
                "status": "error",
                "error": f"Schema violation for tool '{name}': Missing required argument '{param_name}'"
            }

        if param_name in args:
            val = args[param_name]
            expected_type = rules["type"]
            if not isinstance(val, expected_type):
                return {
                    "status": "error",
                    "error": f"Schema violation for tool '{name}': Argument '{param_name}' expected type {expected_type}, got {type(val)}"
                }

            if isinstance(val, str):
                if "max_bytes" in rules and len(val.encode("utf-8")) > rules["max_bytes"]:
                    return {
                        "status": "error",
                        "error": f"Schema violation for tool '{name}': Argument '{param_name}' exceeds {rules['max_bytes']} bytes limit"
                    }
                if "max_len" in rules and len(val) > rules["max_len"]:
                    return {
                        "status": "error",
                        "error": f"Schema violation for tool '{name}': Argument '{param_name}' exceeds {rules['max_len']} chars limit"
                    }
                if "regex" in rules and not re.match(rules["regex"], val):
                    return {
                        "status": "error",
                        "error": f"Schema violation for tool '{name}': Argument '{param_name}' does not match required format"
                    }

            if isinstance(val, (int, float)):
                if "min" in rules and val < rules["min"]:
                    return {"status": "error", "error": f"Argument '{param_name}' below minimum {rules['min']}"}
                if "max" in rules and val > rules["max"]:
                    return {"status": "error", "error": f"Argument '{param_name}' above maximum {rules['max']}"}

    # 3. Call tool handler
    return tool_def["handler"](args)


def get_tools_manifest() -> List[Dict[str, Any]]:
    """Return lightweight tool descriptors for API discovery."""
    manifest = []
    for tool_name in sorted(TOOL_REGISTRY.keys()):
        t = TOOL_REGISTRY[tool_name]
        manifest.append({
            "name": t["name"],
            "description": t["description"],
            "requires_approval": t["requires_approval"]
        })
    return manifest
