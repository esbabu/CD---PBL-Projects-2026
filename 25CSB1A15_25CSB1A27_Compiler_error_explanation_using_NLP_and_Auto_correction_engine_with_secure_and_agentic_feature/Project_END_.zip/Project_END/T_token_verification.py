#use this to check the token verifier
# T1 - Expect: NAME, OP, NUMBER, COMMENT tokens
x = 3.14 + y_2  # note

# T2 - Expect: Five NUMBER tokens; none split in the middle
a = 0x1F + 0b101 + 1_000 + 1e-3 + 2j

# T3 - Expect: Triple-quoted text is one STRING token across two lines;
# u must be reported at line 4
s = f"hi {name}" + r'\d' + b"x"
t = '''line one
line two'''
u = 5

# T4 - Expect: //=, >>=, **=, and := each appear as one OP token
a //= 2
b >>= 1
c **= 3
if (n := 10) > 5:
    pass

# T5 - Expect: match and type are NAME; if is KEYWORD
match = 1
type = 2
if match:
    pass

# T6 - Expect: café is one NAME token
café = 1

# T7 - Expect: Lexical error for $ with line and column
x = 5 $ 3

# T8 - Expect: Unterminated string error at line 1
s = "never closed

# T9 - Expect: Invalid number error
y = 12ab

# T10 - Expect: Unterminated triple-quoted string reported at its starting line (line 1)
z = '''still open
more text

# T11 - Expect: At most a warning-level note, not a hard error
n = 1if True else 2
