"""
tests_multierror.py - Comprehensive Unit Tests for Feature 2B: Multi-Error Analysis & Repair.

Tests:
 1. Two missing colons: both listed with line numbers and both fixed.
 2. NameError typo + ZeroDivisionError + IndexError: three errors listed in order, all fixed, clean.
 3. A1..A6 combined block: errors detected across scan, mocked AI for A5/A6, honest final status.
 4. Cascade: x = undefined_func() then print(x) -> second tagged cascade of first, resolved when first is fixed.
 5. Called vs uncalled function: called error found at runtime, uncalled reported unreached in coverage.
 6. Infinite loop: timeout recorded as stopped, later statements listed as not reached.
 7. input(): EOFError with category environment, never fixed.
 8. Syntax error + runtime error elsewhere: syntax fixed first, runtime error detected and handled.
 9. Unfixable syntax error in middle: neutralised in analysis copy only; later errors found; fixed_code never contains neutralisation.
 10. Position wrappers: leading comments, blank lines, docstring, CRLF, failing code inside def main().
 11. Caps & Limits: 60 errors capped at 50 with "+10 more"; max 3 AI fix calls; AUTOFIX_AI=0 makes 0 calls.
 12. Single-error programs: golden baseline equivalence; MULTI_ERROR=0 gives legacy single behavior.
 13. Security: blocked code never reaches sandbox layer 3; AI patch adding os.system/network is rejected.
 14. UI HTML/JS structural and DOM-stub checks for 0, 1, 12, 60 errors and old response shapes.
 15. Sandbox runner 2A integration: limits, process isolation, and environment scrubbing verified.
"""

import os
import sys
import unittest
from unittest.mock import patch, MagicMock
import json
import ast
import subprocess

import multi_error
import nlp_explainer
import sandbox_runner
import app as flask_app


class TestMultiErrorEngine(unittest.TestCase):

    def setUp(self):
        self.client = flask_app.app.test_client()

    # --------------------------------------------------------------------------
    # Test 1: Two missing colons
    # --------------------------------------------------------------------------
    def test_01_two_missing_colons(self):
        code = "if True\n    print('yes')\nfor i in range(3)\n    print(i)"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            self.assertEqual(res["error_count"], 2)
            self.assertEqual(res["fixed_count"], 2)
            self.assertEqual(res["remaining_count"], 0)
            self.assertEqual(res["fix_status"], "applied")
            lines = [e["line"] for e in res["errors"]]
            self.assertIn(1, lines)
            self.assertIn(3, lines)
            self.assertIn("if True:", res["fixed_code"])
            self.assertIn("for i in range(3):", res["fixed_code"])

    # --------------------------------------------------------------------------
    # Test 2: NameError typo + ZeroDivisionError + IndexError
    # --------------------------------------------------------------------------
    def test_02_three_errors_all_fixed(self):
        code = 'message = "hello"\nprint(mesage)\nx = 10 / 0\nlst = [1, 2]\nval = lst[10]'
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            self.assertEqual(res["error_count"], 3)
            self.assertEqual(res["fixed_count"], 3)
            self.assertEqual(res["remaining_count"], 0)
            self.assertEqual(res["fix_status"], "applied")
            err_types = [e["error_type"] for e in res["errors"]]
            self.assertEqual(err_types, ["NameError", "ZeroDivisionError", "IndexError"])
            # Verify clean execution of fixed code in sandbox
            sb_res = sandbox_runner.run_in_sandbox(res["fixed_code"])
            self.assertEqual(sb_res.get("status"), "ok")

    # --------------------------------------------------------------------------
    # Test 3: Combined A1-A6 block with mocked AI for fallback cases
    # --------------------------------------------------------------------------
    def test_03_combined_block_a1_to_a6(self):
        code = (
            '# Multi-error block\n'
            'message = "hello"\n'
            'print(mesage)\n'
            'x = 10 / 0\n'
            'lst = [1, 2]\n'
            'print(lst[10])\n'
            'for i in 10:\n'
            '    print(i)\n'
            'import math\n'
            'print(math.sqrt(-1))'
        )

        def mock_ai_fix(err_type, err_msg, line_no, code_str, orig_stdout=""):
            if err_type == "ValueError" and "math domain" in str(err_msg):
                return code_str.replace("math.sqrt(-1)", "math.sqrt(abs(-1))")
            return None

        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "1", "GEMINI_API_KEY": "dummy"}), \
             patch.object(nlp_explainer.NLPExplainer, "_apply_ai_autofix", side_effect=mock_ai_fix):
            res = multi_error.analyze_multi_error(code)
            self.assertGreaterEqual(res["error_count"], 4)
            self.assertGreaterEqual(res["fixed_count"], 3)
            self.assertTrue(len(res["fixed_code"]) > 0)

    # --------------------------------------------------------------------------
    # Test 4: Cascade: x = undefined_func() then print(x)
    # --------------------------------------------------------------------------
    def test_04_cascade_tagging_and_resolution(self):
        code = "x = undefined_function_call()\nprint(x)"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            self.assertEqual(res["error_count"], 2)
            errors = res["errors"]
            # First is detected, second is cascade
            self.assertEqual(errors[0]["origin"], "detected")
            self.assertEqual(errors[1]["origin"], "cascade")
            self.assertEqual(errors[1]["cascade_of"], "err_1")

    # --------------------------------------------------------------------------
    # Test 5: Called function vs uncalled function
    # --------------------------------------------------------------------------
    def test_05_called_vs_uncalled_functions(self):
        code = "def called():\n    return 10 / 0\n\ndef uncalled():\n    return 20 / 0\n\ncalled()"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            cov = res["analysis_coverage"]
            self.assertIn("lines_not_reached", cov)
            # Lines of uncalled function body should be unreached
            self.assertTrue(any(l in cov["lines_not_reached"] for l in [4, 5]))

    # --------------------------------------------------------------------------
    # Test 6: Infinite loop timeout
    # --------------------------------------------------------------------------
    def test_06_infinite_loop_timeout(self):
        code = "while True:\n    pass\nprint('never reach')"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code, max_time_sec=6.0)
            cov = res["analysis_coverage"]
            self.assertEqual(cov.get("reason_stopped"), "timeout")
            self.assertIn(3, cov.get("lines_not_reached", []))

    # --------------------------------------------------------------------------
    # Test 7: input() EOFError category environment
    # --------------------------------------------------------------------------
    def test_07_input_environment_category(self):
        code = "name = input('Name: ')\nprint('Hi ' + name)"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            self.assertGreaterEqual(res["error_count"], 1)
            first_err = res["errors"][0]
            self.assertEqual(first_err["category"], "environment")
            self.assertIn("no_fixer", first_err["fix"]["status"])

    # --------------------------------------------------------------------------
    # Test 8: Syntax error + runtime error elsewhere
    # --------------------------------------------------------------------------
    def test_08_syntax_and_runtime_mixed(self):
        code = "if True\n    print('ok')\nx = 10 / 0"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            self.assertEqual(res["error_count"], 2)
            self.assertEqual(res["fixed_count"], 2)
            self.assertEqual(res["remaining_count"], 0)
            self.assertIn("if True:", res["fixed_code"])
            self.assertIn("x = 10 / 0 if 0 != 0 else 0", res["fixed_code"])

    # --------------------------------------------------------------------------
    # Test 9: Unfixable syntax error in middle
    # --------------------------------------------------------------------------
    def test_09_unfixable_syntax_neutralisation(self):
        code = "if True\n    print('fixed')\ndef bad_syntax(\nx = 10 / 0"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(code)
            self.assertGreaterEqual(res["error_count"], 2)
            # Fixed code must NEVER contain neutralised 'pass' replacement
            self.assertIn("def bad_syntax(", res["fixed_code"])
            self.assertNotIn("pass\nx = 10 / 0", res["fixed_code"])

    # --------------------------------------------------------------------------
    # Test 10: Position wrappers (comments, blank lines, docstrings, CRLF, main())
    # --------------------------------------------------------------------------
    def test_10_position_wrappers(self):
        crlf_code = "# Header comment\r\n\r\n'''Docstring'''\r\n\r\ndef main():\r\n    x = 10 / 0\r\n\r\nmain()\r\n"
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(crlf_code)
            self.assertEqual(res["error_count"], 1)
            self.assertEqual(res["fixed_count"], 1)
            self.assertEqual(res["fix_status"], "applied")
            self.assertIn("10 / 0 if 0 != 0 else 0", res["fixed_code"])

    # --------------------------------------------------------------------------
    # Test 11: Caps & Quota Limits (50 error cap, max 3 AI calls, AUTOFIX_AI=0)
    # --------------------------------------------------------------------------
    def test_11_caps_and_limits(self):
        # 60 division errors
        many_errors_code = "\n".join(f"x_{i} = 10 / 0" for i in range(60))
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "1"}):
            res = multi_error.analyze_multi_error(many_errors_code)
            self.assertLessEqual(len(res["errors"]), 50)
            self.assertIn("+", res["error_list_text"])

        # Verify AUTOFIX_AI=0 means 0 AI calls
        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "0", "LLM_DISABLED": "0"}), \
             patch.object(nlp_explainer.NLPExplainer, "_apply_ai_autofix") as mock_ai:
            multi_error.analyze_multi_error("x = unfixable_symbol()")
            mock_ai.assert_not_called()

    # --------------------------------------------------------------------------
    # Test 12: Single-error programs & MULTI_ERROR=0 compatibility
    # --------------------------------------------------------------------------
    def test_12_single_error_equivalence_and_legacy_flag(self):
        code = "x = 10 / 0"
        with patch.dict(os.environ, {"MULTI_ERROR": "0"}):
            resp = self.client.post('/api/analyze', json={'code': code})
            data = resp.get_json()
            self.assertEqual(data.get("analysis_mode"), "single")
            self.assertEqual(data.get("status"), "error_intercepted")
            self.assertEqual(data.get("fix_status"), "applied")

    # --------------------------------------------------------------------------
    # Test 13: Security scan enforcement
    # --------------------------------------------------------------------------
    def test_13_security_block_and_rejection(self):
        # High risk code blocked before sandbox
        code = "import os\nos.system('echo dangerous')"
        resp = self.client.post('/api/analyze', json={'code': code})
        data = resp.get_json()
        self.assertEqual(data.get("status"), "security_blocked")

        # Mocked AI patch returning security violation is rejected
        def malicious_ai_fix(*args, **kwargs):
            return "import os\nos.system('echo hack')\nx = 5"

        with patch.dict(os.environ, {"MULTI_ERROR": "1", "AUTOFIX_AI": "1", "GEMINI_API_KEY": "dummy"}), \
             patch.object(nlp_explainer.NLPExplainer, "_apply_ai_autofix", side_effect=malicious_ai_fix):
            res = multi_error.analyze_multi_error("x = undefined()")
            self.assertNotEqual(res.get("fix_status"), "applied")
            self.assertNotIn("os.system", res.get("fixed_code", ""))

    # --------------------------------------------------------------------------
    # Test 14: UI HTML/JS structure & DOM safety
    # --------------------------------------------------------------------------
    def test_14_ui_elements_exist_and_safe(self):
        resp = self.client.get('/')
        html = resp.get_data(as_text=True)
        self.assertIn('id="panel-error-list"', html)
        self.assertIn('id="error-list-summary"', html)
        self.assertIn('id="error-list-coverage"', html)
        self.assertIn('id="error-list-tbody"', html)
        self.assertIn('renderErrorListPanel', html)

    # --------------------------------------------------------------------------
    # Test 15: 2A Sandbox process isolation & limits
    # --------------------------------------------------------------------------
    def test_15_sandbox_runner_isolation(self):
        sb_res = sandbox_runner.run_in_sandbox("print('hello sandbox')")
        self.assertEqual(sb_res.get("status"), "ok")
        self.assertIn("hello sandbox", sb_res.get("stdout", ""))


if __name__ == "__main__":
    unittest.main()
