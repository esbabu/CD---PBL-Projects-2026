import os
import sys
import json
import re
import socket
import subprocess
import time
import urllib.request
import urllib.error
import tempfile

# Ensure clean UTF-8
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def get_free_port():
    for p in range(5100, 5200):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('127.0.0.1', p))
                return p
            except OSError:
                continue
    return 5150

# 1. Routes
import app
routes = []
for rule in app.app.url_map.iter_rules():
    routes.append({
        'rule': str(rule),
        'methods': sorted(list(rule.methods)),
        'endpoint': rule.endpoint
    })

# 2. Frontend HTML parsing
def audit_template(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find all id="..." in HTML
    html_ids = set(re.findall(r'id=["\']([a-zA-Z0-9_\-]+)["\']', content))

    # Extract JS inside <script> tags
    scripts = re.findall(r'<script(?:\s+[^>]*)?>(.*?)</script>', content, flags=re.DOTALL)
    js_code = "\n".join(scripts)

    # Referenced IDs
    by_id = set(re.findall(r'getElementById\(["\']([a-zA-Z0-9_\-]+)["\']\)', js_code))
    query_id = set(re.findall(r'querySelector\(["\']#([a-zA-Z0-9_\-]+)["\']\)', js_code))
    query_all_id = set(re.findall(r'querySelectorAll\(["\']#([a-zA-Z0-9_\-]+)["\']\)', js_code))
    referenced_ids = by_id | query_id | query_all_id

    missing_ids = sorted(list(referenced_ids - html_ids))

    # Fetches
    # fetch('/api/...', { method: 'POST' ... })
    fetch_calls = []
    for match in re.finditer(r'fetch\(["\']([^"\']+)["\'](?:\s*,\s*\{([^}]*)\})?', js_code):
        url = match.group(1)
        opts = match.group(2) or ""
        method_match = re.search(r'method\s*:\s*["\']([A-Z]+)["\']', opts, flags=re.IGNORECASE)
        method = method_match.group(1).upper() if method_match else "GET"
        fetch_calls.append({"url": url, "method": method})

    # Data property reads: data.foo, res.foo, result.foo
    data_props = sorted(list(set(re.findall(r'\b(?:data|result|res|json)\.([a-zA-Z0-9_]+)', js_code))))

    return {
        "html_ids": sorted(list(html_ids)),
        "referenced_ids": sorted(list(referenced_ids)),
        "missing_ids": missing_ids,
        "fetch_calls": fetch_calls,
        "data_properties_read": data_props
    }

index_audit = audit_template('templates/index.html')
analytics_audit = audit_template('templates/analytics.html')

# 3. Start server on free port 5100-5199 for golden behavior testing
port = get_free_port()
base_url = f"http://127.0.0.1:{port}"

env = os.environ.copy()
env["AUTOFIX_AI"] = "0"
env["LLM_DISABLED"] = "1"
env["CODECARBON_SAVE_TO_FILE"] = "false"
env["CODECARBON_LOG_LEVEL"] = "error"
env["PYTHONUTF8"] = "1"

server_code = f"""
import app, sys, os
from app import app as flask_app
flask_app.run(host="127.0.0.1", port={port}, debug=False, use_reloader=False)
"""

proc = subprocess.Popen(
    [r"C:\Users\lsrin\venvs\toc_project\Scripts\python.exe", "-c", server_code],
    cwd=os.path.dirname(os.path.abspath(__file__)),
    env=env,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    encoding="utf-8"
)

# Wait for /api/version
time.sleep(2)
started = False
for _ in range(30):
    try:
        req = urllib.request.Request(f"{base_url}/api/version")
        with urllib.request.urlopen(req, timeout=1.0) as resp:
            if resp.status == 200:
                started = True
                break
    except Exception:
        time.sleep(0.2)

if not started:
    proc.kill()
    raise RuntimeError(f"Server failed to start on port {port}")

def post_json(endpoint, payload):
    req = urllib.request.Request(
        f"{base_url}{endpoint}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15.0) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))

def get_json(endpoint):
    req = urllib.request.Request(f"{base_url}{endpoint}")
    with urllib.request.urlopen(req, timeout=5.0) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))

# Test route keys
status_files, files_res = get_json("/api/files")
status_version, version_res = get_json("/api/version")
status_analyze, analyze_res = post_json("/api/analyze", {"code": "print('hello')"})

# For /api/save, test on temporary file name to never overwrite existing files
tmp_test_name = "test_tmp_contract_save.py"
status_save, save_res = post_json("/api/save", {"filename": tmp_test_name, "code": "print('test save')"})
if os.path.exists(tmp_test_name):
    os.remove(tmp_test_name)
if os.path.exists("test_tmp_contract_save_fixed.py"):
    os.remove("test_tmp_contract_save_fixed.py")

route_keys = {
    "/api/files": sorted(list(files_res.keys())),
    "/api/version": sorted(list(version_res.keys())),
    "/api/analyze": sorted(list(analyze_res.keys())),
    "/api/save": sorted(list(save_res.keys()))
}

# 4. Golden Cases (18 snippets)
cases = [
    ("A1", 'message = "hello"\nprint(mesage)'),
    ("A2", 'def greet(name)\n    print("Hi", name)\ngreet("Sam")'),
    ("A3", 'print("Total: " + 5)'),
    ("A4", 'nums = [3, 1, 2]\nnums.apend(4)'),
    ("A5", 'import math\nprint(math.sqrt(-1))'),
    ("A6", 'for x in 100:\n    print(x)'),
    ("B1", 'def f():\n    return f()\nf()'),
    ("B2", 'count = 0\ndef add():\n    count = count + 1\nadd()'),
    ("B3", 'import json\njson.loads("")'),
    ("B4", 'import jsno\nprint("ok")'),
    ("B5", 'import some_missing_package'),
    ("B6", 'it = iter([])\nprint(next(it))'),
    ("C1", 'print("hello")'),
    ("C2", ''),
    ("C3", 'while True:\n    pass'),
    ("C4", 'import os\nos.system("echo hi")'),
    ("C5a", 'print("héllo ✓")'),
    ("C5b", 'print("héllo ✓")\nx = [1, 2, 3'),
]

golden_cases = {}
for cid, code in cases:
    status_code, body = post_json("/api/analyze", {"code": code})
    fixed_code = body.get("fixed_code", "")
    differs = (fixed_code != code) if fixed_code is not None else False

    # Execute fixed_code in sandbox to record result
    sandbox_result = {"exit_code": None, "stdout": "", "stderr": "", "runs_clean": False}
    if fixed_code and differs:
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w", encoding="utf-8", delete=False) as tf:
            tf.write(fixed_code)
            tf_path = tf.name
        try:
            r = subprocess.run(
                [r"C:\Users\lsrin\venvs\toc_project\Scripts\python.exe", tf_path],
                capture_output=True,
                text=True,
                timeout=5
            )
            sandbox_result = {
                "exit_code": r.returncode,
                "stdout": r.stdout.strip(),
                "stderr": r.stderr.strip(),
                "runs_clean": (r.returncode == 0)
            }
        except subprocess.TimeoutExpired:
            sandbox_result = {"exit_code": -1, "stdout": "", "stderr": "TimeoutExpired", "runs_clean": False}
        except Exception as ex:
            sandbox_result = {"exit_code": -1, "stdout": "", "stderr": str(ex), "runs_clean": False}
        finally:
            if os.path.exists(tf_path):
                os.remove(tf_path)

    golden_cases[cid] = {
        "input_code": code,
        "http_status": status_code,
        "status": body.get("status"),
        "explanation_source": body.get("explanation_source"),
        "fix_source": body.get("fix_source"),
        "fix_status": body.get("fix_status"),
        "fixed_code": fixed_code,
        "fixed_code_differs": differs,
        "raw_text": body.get("raw_text"),
        "sandbox_result": sandbox_result
    }

# 5. Pipeline on test files
from error_extractor import extract_error
from nlp_explainer import NLPExplainer
explainer = NLPExplainer()

test_files_list = [
    "test1.py", "test2.py", "test3.py", "test4.py", "test5.py",
    "test6.py", "test7.py", "test8.py", "test_case_large.py", "test_case_new.py"
]

test_file_results = {}
for fname in test_files_list:
    if os.path.exists(fname):
        with open(fname, "r", encoding="utf-8") as f:
            code_content = f.read()
        
        ir = extract_error(code_content)
        explanation = explainer.explain(ir, code_content)
        fix_info = explainer.generate_fixed_code(ir, code_content)
        
        test_file_results[fname] = {
            "error_type": ir.get("error_type") if ir else None,
            "error_message": ir.get("error_message") if ir else None,
            "explanation": explanation,
            "explanation_source": explainer.last_source,
            "fixed_code": fix_info.get("fixed_code") if isinstance(fix_info, dict) else fix_info,
            "fix_status": fix_info.get("fix_status") if isinstance(fix_info, dict) else None,
            "fix_source": fix_info.get("fix_source") if isinstance(fix_info, dict) else None
        }

# Shut down test server
proc.terminate()
try:
    proc.wait(timeout=3)
except Exception:
    proc.kill()

golden_data = {
    "routes": routes,
    "route_keys": route_keys,
    "frontend_audit": {
        "index.html": index_audit,
        "analytics.html": analytics_audit
    },
    "golden_cases": golden_cases,
    "test_files": test_file_results
}

os.makedirs("benchmark", exist_ok=True)
with open("benchmark/golden_before.json", "w", encoding="utf-8") as f:
    json.dump(golden_data, f, indent=2, ensure_ascii=False)

print("Generated benchmark/golden_before.json successfully!")
