# Reconstructed data_model.py for INTELLIFIX
# Purpose: Defines the CompilerError data container used by main.py, error_extractor, and ir_generator.

class CompilerError:
    def __init__(self, error_type, message, line_number, category, traceback_info):
        self.error_type = error_type
        self.message = message
        self.line_number = line_number
        self.category = category
        self.traceback_info = traceback_info

    def __repr__(self):
        return f"<CompilerError {self.error_type} at line {self.line_number}: {self.message}>"
