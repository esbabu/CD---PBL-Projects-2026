"""tests_metrics.py - Unit Tests for Security Metrics Engine & API.

Verifies:
- Confusion matrix arithmetic (Standard and Strict variants)
- Wilson 95% Confidence Interval accuracy against known statistical values
- Attack Success Rate (ASR) off vs on and ASR reduction arithmetic
- ROC Curve generation and trapezoid AUC on synthetic ranking
- Latest-run selection from multi-run CSV
- Backward-compatibility parser for old-format CSV (no run_id column)
- Read-only API endpoint GET /api/security/metrics (POST/PUT/DELETE return 405)
- Strict socket guard preventing any outbound non-local network traffic
"""

import csv
import json
import os
import socket
import tempfile
import unittest
from unittest.mock import patch

from security import metrics
import app as flask_app


class TestSecurityMetrics(unittest.TestCase):
    """Unit test suite for security/metrics.py and GET /api/security/metrics."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1", "testserver"):
                raise AssertionError(f"Outbound network call to {address} attempted during metrics test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect

        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy",
            "LLM_DISABLED": "1",
            "AUTOFIX_AI": "0"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_wilson_score_interval(self):
        """Tests Wilson 95% confidence interval calculations against statistical benchmarks."""
        # Edge case: n = 0
        self.assertEqual(metrics.wilson_score_interval(0, 0), (0.0, 0.0))

        # Benchmark: x = 5, n = 10 (p = 0.5)
        # Expected Wilson 95% interval ~ [0.2366, 0.7634]
        low, high = metrics.wilson_score_interval(5, 10)
        self.assertAlmostEqual(low, 0.2366, places=3)
        self.assertAlmostEqual(high, 0.7634, places=3)

        # Boundary: x = 0, n = 20
        low0, high0 = metrics.wilson_score_interval(0, 20)
        self.assertEqual(low0, 0.0)
        self.assertGreater(high0, 0.0)
        self.assertLess(high0, 0.20)

        # Boundary: x = 20, n = 20
        low20, high20 = metrics.wilson_score_interval(20, 20)
        self.assertGreater(low20, 0.80)
        self.assertEqual(high20, 1.0)

    def test_confusion_matrix_arithmetic(self):
        """Verifies confusion matrix arithmetic on a hand-crafted dataset."""
        toy_rows = [
            # 3 Attacks detected via BLOCK
            {"ground_truth": "attack", "decision": "BLOCK", "category": "AT-01"},
            {"ground_truth": "attack", "decision": "BLOCK", "category": "AT-02"},
            {"ground_truth": "attack", "decision": "BLOCK", "category": "AT-03"},
            # 2 Attacks detected via WARN (Standard = TP, Strict = FN)
            {"ground_truth": "attack", "decision": "WARN", "category": "AT-04"},
            {"ground_truth": "attack", "decision": "WARN", "category": "AT-05"},
            # 1 Attack detected via REDACT on AT-15 (Standard = TP, Strict = FN)
            {"ground_truth": "attack", "decision": "REDACT", "category": "AT-15"},
            # 2 Attacks missed (ALLOW)
            {"ground_truth": "attack", "decision": "ALLOW", "category": "AT-06"},
            {"ground_truth": "attack", "decision": "ALLOW", "category": "AT-07"},
            # 4 Benign correctly allowed
            {"ground_truth": "benign", "decision": "ALLOW", "category": "BENIGN"},
            {"ground_truth": "benign", "decision": "ALLOW", "category": "BENIGN"},
            {"ground_truth": "benign", "decision": "ALLOW", "category": "BENIGN"},
            {"ground_truth": "benign", "decision": "ALLOW", "category": "BENIGN"},
            # 1 Benign wrongly blocked (FP)
            {"ground_truth": "benign", "decision": "BLOCK", "category": "BENIGN"},
        ]

        # Standard Confusion Matrix:
        # Attacks = 8: TP = 6 (3 BLOCK + 2 WARN + 1 REDACT), FN = 2
        # Benign = 5: FP = 1 (1 BLOCK), TN = 4 (4 ALLOW)
        std = metrics.compute_confusion_matrix(toy_rows, strict=False)
        self.assertEqual(std["tp"], 6)
        self.assertEqual(std["fn"], 2)
        self.assertEqual(std["fp"], 1)
        self.assertEqual(std["tn"], 4)
        self.assertEqual(std["recall"], 6 / 8)
        self.assertAlmostEqual(std["precision"], 6 / 7, places=3)
        self.assertEqual(std["fpr"], 1 / 5)

        # Strict Confusion Matrix (Only BLOCK is positive):
        # Attacks = 8: TP = 3 (3 BLOCK), FN = 5
        # Benign = 5: FP = 1, TN = 4
        strict = metrics.compute_confusion_matrix(toy_rows, strict=True)
        self.assertEqual(strict["tp"], 3)
        self.assertEqual(strict["fn"], 5)
        self.assertEqual(strict["fp"], 1)
        self.assertEqual(strict["tn"], 4)
        self.assertEqual(strict["recall"], 3 / 8)

    def test_asr_reduction_calculation(self):
        """Verifies Attack Success Rate and ASR reduction formulas."""
        off_rows = [
            {"ground_truth": "attack", "attack_succeeded": "true"},
            {"ground_truth": "attack", "attack_succeeded": "true"},
            {"ground_truth": "attack", "attack_succeeded": "true"},
            {"ground_truth": "attack", "attack_succeeded": "false"},  # 3 of 4 succeeded (75%)
        ]
        on_rows = [
            {"ground_truth": "attack", "attack_succeeded": "true"},
            {"ground_truth": "attack", "attack_succeeded": "false"},
            {"ground_truth": "attack", "attack_succeeded": "false"},
            {"ground_truth": "attack", "attack_succeeded": "false"},  # 1 of 4 succeeded (25%)
        ]

        res = metrics.compute_asr(off_rows, on_rows)
        self.assertEqual(res["asr_off_pct"], 75.0)
        self.assertEqual(res["asr_on_pct"], 25.0)
        # Reduction: (0.75 - 0.25) / 0.75 = 0.50 / 0.75 = 66.67%
        self.assertAlmostEqual(res["asr_reduction_pct"], 66.67, places=2)

    def test_auc_toy_ranking(self):
        """Verifies pure Python trapezoid AUC on separable and inverted rankings."""
        # Perfect separation: Attacks have scores >= 50, Benign have scores <= 10
        perfect_rows = [
            {"ground_truth": "attack", "risk_score": 90},
            {"ground_truth": "attack", "risk_score": 70},
            {"ground_truth": "attack", "risk_score": 50},
            {"ground_truth": "benign", "risk_score": 10},
            {"ground_truth": "benign", "risk_score": 0},
            {"ground_truth": "benign", "risk_score": 0},
        ]
        _, auc_perf = metrics.compute_roc_auc(perfect_rows)
        self.assertEqual(auc_perf, 1.0)

        # Inverted separation (worst classifier):
        inverted_rows = [
            {"ground_truth": "attack", "risk_score": 0},
            {"ground_truth": "attack", "risk_score": 10},
            {"ground_truth": "benign", "risk_score": 80},
            {"ground_truth": "benign", "risk_score": 90},
        ]
        _, auc_inv = metrics.compute_roc_auc(inverted_rows)
        self.assertEqual(auc_inv, 0.0)

    def test_latest_run_selection(self):
        """Tests that load_attack_run_csv correctly distinguishes runs and returns ordered runs."""
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
            writer = csv.writer(f)
            writer.writerow(["run_id", "sample_id", "category", "channel", "ground_truth", "mode", "risk_score", "decision", "attack_succeeded", "blocked_wrongly", "time_ms"])
            writer.writerow(["run_1", "S1", "AT-01", "c1", "attack", "off", "0", "ALLOW", "true", "false", "10"])
            writer.writerow(["run_1", "S1", "AT-01", "c1", "attack", "on", "40", "BLOCK", "false", "false", "5"])
            writer.writerow(["run_2", "S1", "AT-01", "c1", "attack", "off", "0", "ALLOW", "true", "false", "10"])
            writer.writerow(["run_2", "S1", "AT-01", "c1", "attack", "on", "80", "BLOCK", "false", "false", "3"])
            temp_path = f.name

        try:
            runs, ordered_ids = metrics.load_attack_run_csv(temp_path)
            self.assertEqual(ordered_ids, ["run_1", "run_2"])
            self.assertEqual(len(runs["run_1"]), 2)
            self.assertEqual(len(runs["run_2"]), 2)

            # Specific run selection
            r2, o2 = metrics.load_attack_run_csv(temp_path, target_run_id="run_2")
            self.assertEqual(o2, ["run_2"])
            self.assertEqual(r2["run_2"][1]["risk_score"], "80")
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    def test_old_format_csv_backward_compatibility(self):
        """Tests handling of legacy CSV files lacking the run_id column."""
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, suffix=".csv") as f:
            writer = csv.writer(f)
            writer.writerow(["sample_id", "category", "channel", "ground_truth", "mode", "risk_score", "decision", "attack_succeeded", "blocked_wrongly", "time_ms"])
            # Earlier duplicate row
            writer.writerow(["S1", "AT-01", "c1", "attack", "on", "20", "ALLOW", "true", "false", "10"])
            # Later updated row (should overwrite)
            writer.writerow(["S1", "AT-01", "c1", "attack", "on", "40", "BLOCK", "false", "false", "4"])
            temp_path = f.name

        try:
            runs, ordered_ids = metrics.load_attack_run_csv(temp_path)
            self.assertEqual(len(ordered_ids), 1)
            legacy_key = ordered_ids[0]
            self.assertEqual(len(runs[legacy_key]), 1)
            # Must keep the latest row
            self.assertEqual(runs[legacy_key][0]["risk_score"], "40")
            self.assertEqual(runs[legacy_key][0]["decision"], "BLOCK")
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    def test_endpoint_read_only_and_methods(self):
        """Verifies GET /api/security/metrics returns 200 and POST/PUT/DELETE return 405."""
        client = flask_app.app.test_client()

        # GET request succeeds
        res_get = client.get("/api/security/metrics")
        self.assertEqual(res_get.status_code, 200)
        data = res_get.get_json()
        self.assertEqual(data.get("status"), "success")
        self.assertIn("metrics", data)
        self.assertIn("charts", data)

        # Mutating methods return 405 Method Not Allowed
        res_post = client.post("/api/security/metrics")
        self.assertEqual(res_post.status_code, 405)

        res_put = client.put("/api/security/metrics")
        self.assertEqual(res_put.status_code, 405)

        res_delete = client.delete("/api/security/metrics")
        self.assertEqual(res_delete.status_code, 405)


if __name__ == "__main__":
    unittest.main()
