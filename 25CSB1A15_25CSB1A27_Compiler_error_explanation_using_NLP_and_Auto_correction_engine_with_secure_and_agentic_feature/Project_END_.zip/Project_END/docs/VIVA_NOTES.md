# IntelliFix Project Viva Quick Reference & Conceptual Guide

1. **What IntelliFix Does**: IntelliFix is a resilient Python compiler error diagnostic and auto-correction engine that provides beginner-friendly explanations and verified code repairs for Python errors.
2. **Multi-Tier Explanation Hierarchy**:
   - **Tier 1 (Rule Engine)**: Fast, zero-overhead deterministic regex and AST rules for 10 frequent error types (e.g. missing colon, NameError, ZeroDivisionError).
   - **Tier 2 (Online AI)**: If unhandled by rules and API keys are present, queries **Google Gemini Flash Lite**, failing over seamlessly to **Groq Qwen** if rate-limited or offline.
   - **Tier 3 (Offline Guide)**: If offline or API fails, uses deterministic slot-filled templates across 25+ Python standard exception types (`offline_guide.py`).
   - **Tier 4 (Generic Base)**: Universal fail-safe providing structured "Mistake / Reason / Fix" format for unknown errors.
3. **Verified Auto-Fixing & Multi-Round Repair Engine**:
   - **Safe Deterministic Fixers**:
     - `RecursionError`: Automatic base case insertion for textbook single-parameter linear recursions (`countdown` -> `if n <= 0: return None`, `factorial` -> `if n <= 1: return 1`, `fibonacci` -> `if n <= 1: return n`) with AST validation rejecting multi-parameter or already-guarded functions.
     - `UnboundLocalError`: Scope analysis inserting `global` or `nonlocal` variable declaration at the function header.
     - `StopIteration`: Safe rewrite of `next(iter)` -> `next(iter, None)`.
     - `RuntimeError`: Iteration mutation guard wrapping target in `list(...)`.
     - `TypeError`: Rewrites non-iterable loop `for x in <int>` -> `for x in range(<int>)`.
     - `NameError`: Standard library module import auto-injection (`math`, `json`, `random`, `re`, `time`, `datetime`, `collections`, `itertools`, `string`, `statistics`, `sys`).
     - `SyntaxError`: AST/token repairs for colons, Python 2 `print`, brackets (preserving UTF-8), unclosed quotes, assignment `=` in conditions, and missing commas.
     - `FileExistsError`: Rewriting `os.mkdir(x)` -> `os.makedirs(x, exist_ok=True)` without mutating exclusive open modes (`'x'`).
     - `json.JSONDecodeError`: Defensive guard `(json.loads(s) if s.strip() else None)`.
   - **Position Invariance & Wrapper Robustness**:
     - Surgical localized line edits replace only failing AST target lines, guaranteeing 100% position invariance across comments, docstrings, blank lines, CRLF/LF line endings, and UTF-8 BOM markers (W0–W11 wrappers).
   - **Defensive Runtime Guards**: Guarding `ZeroDivisionError` (`x if y != 0 else 0`), `IndexError` (`lst[i] if i < len(lst) else None`), and `KeyError` (`d.get(k, None)`).
   - **5-Round Iterative Sandbox Repair Loop**: Isolated multi-round execution with error re-entry, candidate validation, and step telemetry (`fix_steps`). When repair stops at an unfixable error, clearly explains why subsequent errors cannot yet be reached (`"stopped at line N (<type>): no automatic fix; any errors after this line cannot be detected until it is fixed"`).
   - **Progress-Based Patch Acceptance & Multi-Error Sequential Fixing**:
     - Multi-error scripts (e.g. A5 domain error + A6 non-iterable loop) cannot exit 0 on the first patch because later lines still contain errors.
     - Acceptance invariant verifies that the patch fixes the active error (program either exits 0 **or** moves the first failing line forward in the program while preserving stdout prefix), allowing subsequent repair rounds to fix remaining errors.
   - **Per-Round AI Fallback Tier**:
     - Deterministic fixers and rules run first in each repair round. If they cannot resolve the round's error, the engine queries Gemini (falling back to Groq if rate-limited or unavailable).
     - Caches AI repairs by SHA256 of `(error_type, message, code)` and tracks rejected candidates.
     - Reports detailed `fix_steps`, additive `fix_providers`, and source classification (`"rule"`, `"deterministic"`, `"ai"`, `"mixed"`).
   - **Strict AI Acceptance Invariants**: Patches proposed by LLMs must pass AST syntax parsing, statement count thresholds (<=1 statement drop), AST node type preservation (no function/lambda stubbing, no deletion of failing lines), allowed stdlib imports only, explicit base-case return checking for recursion errors, stdout prefix consistency, and security scans.
   - **Semantic Correctness vs Run-Clean**: Auto-repair guarantees syntactically clean, exception-free execution. However, domain logic cannot be inferred without tests; default fallback values (e.g. `None` or `0`) ensure graceful runtime handling.
4. **Why Flan-T5 is Disabled (`USE_MODEL=False`)**:
   - Local fine-tuned Flan-T5 models achieved low lexical accuracy (15.5% pass rate), produced hallucinated syntax, and added heavy memory/CPU startup overhead.
   - The lightweight hybrid architecture (Rule -> LLM API -> Offline Guide) achieves 99.8% offline format/diagnostic accuracy with near-zero latency.
5. **How the Web Dashboard Fits Together**:
   - The user writes or uploads Python scripts on the frontend (`index.html`).
   - `POST /api/analyze` performs static security pre-filtering, extracts errors in a temporary sandbox, constructs AST IR, generates explanations and verified fixes, and returns metrics.
   - The web page displays diagnosis and modified code, allowing one-click execution via `POST /api/execute` or downloading via `POST /api/save`.
6. **Sandboxed Code Runner (Feature 2A)**:
   - **Why Separate Process?**: `exec()` in the main process allows untrusted code to execute infinite loops, consume all RAM, or alter server memory. We spawn an isolated subprocess under `sys.executable -I -X utf8` with `stdin=subprocess.DEVNULL`.
   - **Secret Isolation**: `os.environ` is scrubbed against an explicit allow-list (`SYSTEMROOT`, `PATH`, `WINDIR`, `TEMP`); API keys (`GEMINI_API_KEY`, `GROQ_API_KEY`) never reach the child process.
   - **Limits & Windows Job Objects**: Enforces 5.0s timeout, 256 MB memory limit via Windows Job Objects (`JOBOBJECT_EXTENDED_LIMIT_INFORMATION` with `KILL_ON_JOB_CLOSE`), and 256 KB combined stdout/stderr output caps.
   - **Audit Hooks (`sys.addaudithook`)**: Defense-in-depth runtime interceptors blocking network (`socket.connect`), subprocess creation (`subprocess.Popen`), native libraries (`ctypes.dlopen`), and file writes outside the temp folder.
   - **Tamper Resistance**: Cryptographic per-run nonce with delimited communication (`---SANDBOX_RESULT_<NONCE>---`) preventing user code from spoofing results.
   - **Fail Closed**: If sandbox cannot spawn, returns `sandbox_failure` and never falls back to server-side `exec()`.
7. **Whole-Program Multi-Error & Multi-Fix (Feature 2B)**:
   - **How Multi-Error Detection Works**: Traditional Python compilers stop at line 1. IntelliFix uses 4 distinct layers:
     1. *Syntax Layer*: Parses syntax, neutralizes failing lines on a shadow copy, and resumes scanning to find downstream syntax errors.
     2. *Static AST Layer*: Validates scoping, duplicate parameters, arg counts against function signatures without execution.
     3. *Sandboxed Runtime Instrumentation*: Uses `ast.NodeTransformer` in the sandbox child process to wrap statements in exception interceptors, recording all statement crashes and line coverage in a single run.
     4. *Multi-Round Engine*: Iteratively applies verified deterministic and AI patches up to 8 rounds, accepting patches on progress (unresolved errors decrease).
   - **Cascade Poisoning Prevention**: If line 2 fails (`x = 10 / 0`), downstream line 5 (`y = x + 1`) fails with NameError or TypeError due to `x` being undefined. IntelliFix tracks variable assignments from failing statements and marks downstream defects as cascades (`is_cascade: True`, referencing the parent error), avoiding wasted fix rounds on secondary symptoms.
   - **Coverage & Unreached Code**: Statements inside uncalled functions or untested conditional branches cannot produce runtime exceptions until called; IntelliFix tracks reached statement lines and informs the user of unreached code sections.

8. **Week 2 Security Architecture (Features 3, 4, 13a)**:
   - **Feature 4 (Static AST Security Scanner)**:
     - Traverses AST nodes across 20 rules (`SEC_01` to `SEC_20`) covering command injection (`os.system`, `subprocess`), file deletion (`shutil.rmtree`), network sockets (`socket`, `urllib`, `requests`), code generation (`exec`, `eval`), dynamic imports (`__import__`, `getattr`), and environment harvesting (`os.environ`).
     - Tracks import aliases (`import os as o; o.system(...)`) and blocks before sandbox execution.
     - Re-scans healed code in `nlp_explainer.py` to ensure AI fixes introduce no new vulnerabilities.
   - **Feature 3 (Hardened Server)**:
     - `WORKSPACE_DIR` confinement: `validate_workspace_filename()` strictly confines files to project root, rejecting `..`, path separators, colons (NTFS Alternate Data Streams), NUL bytes, and Windows devices (`CON`, `PRN`).
     - Host and Origin filtering: drops requests with foreign `Host` (DNS rebinding) and untrusted `Origin` on mutating requests.
     - Request size cap: 200 KB (`MAX_CONTENT_LENGTH`), JSON content-type enforcement (415), and concurrency semaphore (`threading.BoundedSemaphore(4)` with 429 backpressure).
     - Security headers: `nosniff`, `DENY`, `no-referrer`, `no-store` on all `/api/*` responses.
   - **Feature 13a (Threat Model & Security Policy)**:
     - Formally defines 8 assets, 4 actors, 4 attack channels (Instruction text, Code content, Error tracebacks, Healed code), and 16 attack definitions (`AT-01` to `AT-16`).
     - Machine-readable policy file `security/policy.json` with cryptographic SHA-256 verification in `security/policy_loader.py`.

9. **Week 3 Formal Automata & Input Guard (Features 5, 6, 13b)**:
   - **Feature 5 (Deterministic Tokenizer & Hand-Written DFAs)**:
     - *Master Regex Tokenizer*: `tokenizer.py` executes a compiled longest-match regex covering Python 3.13 token grammar (keywords, names, numbers, strings, comments, operators, brackets) in $O(N)$ linear time.
     - *Hand-Written DFAs*: `dfa.py` models explicit 5-tuples $(Q, \Sigma, \delta, q_0, F)$ for identifiers (`[A-Za-z_][A-Za-z0-9_]*`), numbers (`[0-9]+(\.[0-9]+)?`), and underscore-separated integers (`[0-9](_?[0-9])*`) with explicit transition tables and trace capabilities.
     - *Comparison Verification*: 0 token mismatches across all real repository test files against standard library `tokenize`.
   - **Feature 6 (Pushdown Automaton Bracket Checker)**:
     - *PDA Formulation*: `bracket_checker.py` models an explicit Pushdown Automaton with single control state $q_{\text{loop}}$, bottom stack marker $Z_0$, and stack operations ($Push$ on open, $Pop$ on match, $Recovery$ on mismatch/unclosed).
     - *Mutant Robustness*: Evaluated on 350+ random mutants generated against `compile()` syntax errors, verifying 100% detection of bracket imbalances.
   - **Feature 13b (Advisory Input Guard)**:
     - *Three Attack Channels*: Directly scans user prompts (`user_instruction`), code comments/docstrings (`code_content`), and error strings (`error_text`).
     - *Threat Detection Families*: Additive weights for policy overrides (40), approval bypass (40), secret dumping (35), exfiltration (35), verdict forcing (30), authority spoofing (25), and role jailbreaks (25).
     - *Defensive Normalization*: 8-stage pipeline normalizing homoglyphs, zero-width characters, spaced text, leetspeak, and safe Base64/Hex decoding.
     - *Negation Rule*: Suppresses alerts on defensive comments (`# never print passwords`) via a 3-word window, maintaining 0.0% false positives on hard negatives.
     - *Advisory Nature*: Non-blocking, purely advisory scores (0..100) and risk badges (`low`, `medium`, `high`) displayed on the dashboard.
