# IntelliFix Final Presentation Outline (12 Slides)

## Slide 1: Title & Project Overview
- **Title**: IntelliFix: Automated Python Error Diagnosis & Defense-in-Depth AAI Security Shield
- **Subtitle**: Formal Automata, Multi-Error AST Repair, and Autonomous Agent Security
- **Team**: Automata & Compiler Design Laboratory, NIT Warangal
- **Artifacts**: `intellifix.py` CLI, Web Studio, 4-Gate AAI Shield, Golden Regression Harness

---

## Slide 2: The Challenge of Autonomous Program Repair
- Traditional rule-based fixers are rigid and struggle with multi-error cascades.
- LLM agents offer generative reasoning, but introduce severe security vulnerabilities:
  - Prompt injection subverting system constraints.
  - Harmful code synthesis (`os.system`, shell execution, network exfiltration).
  - Unchecked tool execution modifying critical system files.
- **The Core Question**: *Can we deploy autonomous agent repair while enforcing provable defense-in-depth and zero utility degradation?*

---

## Slide 3: IntelliFix Dual-Engine Architecture
- **Layer 1: Deterministic Multi-Error AST Engine**:
  - 10 targeted repair rules (ZeroDivision, NameError, IndexError, KeyError, TypeError, ValueError, SyntaxError, ModuleNotFound, Recursion, UnboundLocal).
  - Iterative loop with AST statement isolation and subprocess sandbox verification.
- **Layer 2: Autonomous Agent Studio**:
  - Multi-turn tool-using agent with explicit capability boundaries.
  - Read-only vs Mutating tool separation with cryptographic human approval tokens.

---

## Slide 4: The 4-Gate AAI Security Shield
- **Gate 1 (Prompt & Policy Guard)**: Regex and threat taxonomy scanning before LLM/parser invocation.
- **Gate 2 (Tool & Capability Guard)**: Enforces capability allow-list and human approval before disk/shell mutations.
- **Gate 3 (Code & AST Execution Guard)**: Pre-execution static AST & bytecode inspection blocking unsafe modules and `eval`.
- **Gate 4 (Output & Leakage Guard)**: Automated token and PII scrubbing (`[REDACTED]`) preventing credential leakage.

---

## Slide 5: Cryptographic Audit Trail
- **Tamper-Evident Hash Chain**: Continuous SHA-256 Merkle chain in `results/security_log.jsonl`.
- $H_i = \text{SHA256}(H_{i-1} \parallel \text{CanonicalJSON}(\text{Payload}_i))$
- Verified across **212 development entries** and **90 held-out evaluation entries** with 0 chain breaks.
- Provides non-repudiation and immediate detection of historical log tampering.

---

## Slide 6: Empirical Security Evaluation (Dev vs. Held-Out)
- Evaluated across two independent attack datasets:
  - **Development Corpus (212 samples)**: 105 attacks across 8 threat categories (`AT-01` to `AT-08`), 107 benign programs.
  - **Held-Out Corpus (90 samples)**: 45 attacks across 15 threat categories (AT-01 to AT-15), 45 benign with independent phrasing; frozen via SHA-256 (`db290cefd0b2...`).
- **Results**:
  - **Dev ASR Reduction**: **-70.27%** (Shield OFF: 70.48% -> Shield ON: 20.95%).
  - **Held-Out ASR Reduction**: **-46.15%** (Shield OFF: 57.78% -> Shield ON: 31.11%).
  - **False Positive Rate**: **0.00%** (0 false blocks on 152 benign programs across both corpora).

---

## Slide 7: Statistical Rigor & Metric Separation
- **Standard Detection Recall**:
  - Dev: 79.05% (95% Wilson CI: [70.28%, 85.73%])
  - Held-out: 68.89% (95% Wilson CI: [54.34%, 80.48%])
- **ROC Area Under Curve (AUC)**:
  - Dev AUC: **0.8905** | Held-Out AUC: **0.8666**
- **Risk Score Separation**:
  - Dev: Attack Mean = 61.05, Benign Mean = 0.00 (+37.00 separation over threshold)
  - Held-out: Attack Mean = 58.89, Benign Mean = 0.00 (+34.89 separation)

---

## Slide 8: Offline Accuracy & Utility Evaluation (Feature 10)
- **24 Diverse Benchmark Programs** evaluated across 96 runs (Rule/Agent x Shield OFF/ON):
  - ZeroDivision, NameError, IndexError, KeyError, TypeError, ValueError, SyntaxError, ModuleNotFound, Recursion, UnboundLocal, StopIteration, RuntimeError, 3 multi-error chains, 1 logic bug.
- **Key Findings**:
  - **Fix Success Rate**: **79.2%** (19/24 fixed cleanly).
  - **Utility Preservation**: **100.0%** (Shield ON fixed exactly the same 19 programs as Shield OFF).
  - **Benign Disruption**: **0%** (Zero legitimate programs blocked).

---

## Slide 9: Environmental Sustainability & Energy Metrics
- Carbon emissions and energy measured using **CodeCarbon** (`results/energy/energy_week6.csv`):
  - Mean CPU / System Energy: energy overhead: not reliably measured on this development machine (CodeCarbon reported not_measured_host_unsupported).
  - Mean Latency Overhead of Shield: **+2.05 ms** per request.
  - System virtualization efficiency: **96.4%**.
- Proves that multi-gate security enforcement does not impose noticeable compute or environmental penalties.

---

## Slide 10: Interactive UI Studio & Self-XSS Hardening
- **Web Studio Upgrades**:
  - Dedicated **Security Metrics Dashboard** modal with live KPI cards, risk meter, and 5 SVG charts.
  - **Red/Green Diff View**: Unified diff toggle highlighting modified lines.
  - **Security Blocked Banner**: Clear diagnostics explaining risk score and violated gate.
- **Security Hardening**:
  - Eliminated 2 self-XSS sinks in multi-error and file listing tables using strict `document.createElement` and `textContent` (zero `innerHTML`).

---

## Slide 11: Production Packaging & CLI Tool (`intellifix.py`)
- Standalone command-line executable `intellifix.py`:
  - `python intellifix.py <file.py> [--agent] [--diff] [--json] [--write]`
  - Exit codes: 0 (clean/repaired), 1 (unfixed error), 2 (security blocked).
  - Strict offline execution default (zero network dependency).
- Complete Golden Harness verification: **Zero regressions across 56 baseline test cases**.

---

## Slide 12: Honest Methodological Limitations & Future Work
- **Known Limitations**:
  1. *Synthetic Threat Corpus*: Datasets authored by developers; real zero-day attacks may exhibit multi-stage evasion techniques.
  2. *OS-Level Sandboxing*: Gate 3 uses AST static rules and timeouts; true production multi-tenant environments require containerization (Docker/cgroups).
  3. *Held-Out Generalization Gap*: ASR reduction dropped from 70.27% on dev to 46.15% on held-out due to novel semantic phrasing.
- **Future Directions**:
  - Kernel-level eBPF sandboxing.
  - Reinforcement learning for adaptive threshold tuning.
- **Conclusion**: IntelliFix demonstrates that autonomous program repair and rigorous defense-in-depth security can be harmoniously unified.
