# IntelliFix Feature 4: AST-Based Static Security Scanner

## 1. Overview
The IntelliFix static security scanner (`security_analyzer.py`) provides pre-execution whole-program analysis to intercept dangerous patterns before Python code is ever executed or sent to a sandbox runner. It operates exclusively via Abstract Syntax Tree (AST) analysis and safe lexical fallback, guaranteeing that the scanner itself **never executes, imports, or dynamic-evaluates** the code under review.

---

## 2. Complete Rule Catalog

| Rule ID | Severity | Default Block | What It Detects | Safer Alternative |
|---|---|---|---|---|
| `SEC_01_CMD_INJECTION` | **CRITICAL** | `True` | Direct shell command execution via `os.system()` or resolved aliases | Use `subprocess.run(["cmd", "arg"], shell=False)` |
| `SEC_02_CODE_EXECUTION` | **HIGH** | `True` | Dynamic evaluation via built-in `eval()` or `exec()` | Use `ast.literal_eval()` or structured parser |
| `SEC_03_INSECURE_TEMP` | **MEDIUM** | `False` | Creation of race-condition-vulnerable temporary files via `tempfile.mktemp()` | Use `tempfile.NamedTemporaryFile()` or `tempfile.mkstemp()` |
| `SEC_04_HARDCODED_SECRET` | **LOW** | `False` | Plaintext API keys, passwords, or tokens in source assignments | Load credentials securely from environment variables |
| `SEC_05_SUBPROCESS_CALL` | **HIGH** | `False` | Standard subprocess invocations (`subprocess.run`, `call`, `Popen`) | Validate argument lists and avoid invoking host commands |
| `SEC_06_SUBPROCESS_SHELL_TRUE` | **CRITICAL** | `True` | Subprocess execution with explicit `shell=True` parameter | Set `shell=False` and pass arguments as an explicit list |
| `SEC_07_OS_EXEC_SPAWN_POPEN` | **CRITICAL** | `True` | Process spawning via `os.popen`, `os.exec*`, or `os.spawn*` | Use isolated workers or sandboxed subprocess execution |
| `SEC_08_UNSAFE_DESERIALIZATION` | **HIGH** | `False` | Arbitrary object deserialization via `pickle.loads`, `marshal`, `shelve` | Use safe serialization formats such as JSON or Protocol Buffers |
| `SEC_09_NETWORK_CALL` | **HIGH** | `False` | Raw sockets or HTTP client calls (`socket`, `requests`, `urllib`, `http.client`) | Use authenticated API clients with strict timeout controls |
| `SEC_10_SQL_INJECTION` | **MEDIUM** | `False` | Dynamic SQL queries constructed using f-strings, `%`, or string concatenation | Use parameterized queries (e.g. `cursor.execute("SELECT ... WHERE id = ?", (val,))`) |
| `SEC_11_RISKY_FILE_OPS` | **HIGH** | `False` | Destructive file deletion (`os.remove`, `os.unlink`, `shutil.rmtree`) on non-literal paths | Validate paths against an allow-listed workspace sandbox |
| `SEC_12_OPEN_ABSOLUTE_OR_TRAVERSAL` | **MEDIUM** | `False` | `open()` calls in write mode targeting absolute paths, drive roots, or containing `..` | Confine file writes strictly to relative paths within the workspace |
| `SEC_13_ENV_READ` | **MEDIUM** | `False` | Inspecting process environment variables via `os.environ` or `os.getenv` | Provide explicit, sanitized configuration objects |
| `SEC_14_HOME_SECRETS_PATH` | **HIGH** | `False` | Path literals referencing home secret folders (`.ssh`, `.aws`, `.gnupg`, `id_rsa`) | Do not access user credential or system configuration paths |
| `SEC_15_DYNAMIC_IMPORT` | **HIGH** | `False` | Dynamic module imports via `__import__(var)` with non-literal arguments | Use standard, static top-level import statements |
| `SEC_16_DYNAMIC_GETATTR` | **MEDIUM** | `False` | Attribute resolution on modules using constructed/variable attribute names | Use direct, static dotted attribute access |
| `SEC_17_DECODE_EXEC` | **CRITICAL** | `True` | Encoded/decoded payloads (e.g., base64, zlib) directly reaching `exec` or `eval` | Execute plain, transparent source code only |
| `SEC_18_OBFUSCATED_STRING` | **HIGH** | `False` | Strings constructed dynamically using `chr()` or `join()` reaching execution sinks | Use plain string literals without dynamic character decoding |
| `SEC_19_CTYPES` | **HIGH** | `False` | Direct native library invocation via `ctypes` | Use pure Python modules conforming to runtime safety boundaries |
| `SEC_20_EXFILTRATION` | **CRITICAL** | `True` | Co-occurrence of environment/credential reads AND network transmission in one program | Decouple local environment management from network egress routines |

---

## 3. Alias and Import Resolution
Attackers frequently disguise dangerous calls by renaming imports:
```python
import os as o
o.system("malicious_command")

from os import system as sys_exec
sys_exec("malicious_command")
```
The scanner implements an AST-based canonical alias tracker:
1. It traverses all `ast.Import` and `ast.ImportFrom` nodes before inspecting expressions.
2. It constructs an alias table mapping local identifiers (e.g., `o` -> `os`, `sys_exec` -> `os.system`).
3. When analyzing call nodes, method receivers are resolved through this map. A call to `system()` only triggers `SEC_01_CMD_INJECTION` if the receiver resolves to `os`. Calls on user-defined objects (e.g. `user_object.system()`) are correctly recognized as safe hard negatives.

---

## 4. Blocking Policy and `SCAN_BLOCK_LEVEL`
The scanner enforces a strict, backward-compatible dual-tier blocking policy:
1. **Default Blocking (`default_block=True`)**:
   - Only CRITICAL rules (`SEC_01`, `SEC_02`, `SEC_06`, `SEC_07`, `SEC_17`, `SEC_20`) block execution by default.
   - MEDIUM and HIGH rules report findings for diagnostic visibility without blocking runnable student programs.
2. **Configurable Threshold (`SCAN_BLOCK_LEVEL`)**:
   - If the environment variable `SCAN_BLOCK_LEVEL` is set (e.g., `SCAN_BLOCK_LEVEL=HIGH` or `SCAN_BLOCK_LEVEL=MEDIUM`), any finding with severity meeting or exceeding that rank will block execution.
   - Evaluated dynamically via `get_scan_block_level()` without import-time side effects.

---

## 5. Public API Contracts
- `scan_code(code: str) -> List[Dict[str, Any]]`: Parses source code into structured findings containing `rule_id`, `type`, `severity`, `line`, `column`, `evidence`, `confidence`, `safer_alternative`, and `default_block`.
- `scan_summary(findings: List[Dict[str, Any]]) -> Dict[str, Any]`: Computes max severity, counts by severity, and blocking verdict.
- `scan_gate(code: str, block_level=None, enforce=True) -> Dict[str, Any]`: Main execution gateway returning `allowed`, `blocked`, `findings`, `summary`, and human-friendly `message`.
- Line-based fallback: On `SyntaxError`, the scanner falls back to regex pattern scanning of high-risk signatures, tagging findings with `partial_scan: True`.

---

## 6. Honest Limitations
1. **Evadable via Indirection**: Static analysis cannot resolve complex runtime reflection (e.g., `getattr(__builtins__, "".join(['e','v','a','l']))(...)`).
2. **False Positives**: Benign data-science code reading an environment key or using `subprocess` with trusted inputs will generate advisory findings.
3. **Not a Sandbox Replacement**: Static scanning is a lightweight first line of defense; OS-level containerization and child-process sandboxing remain essential for untrusted execution.

---

## 7. Viva Questions and Answers

**Q1: Why does IntelliFix use AST analysis instead of simple regex keyword matching?**
*Answer:* AST analysis understands code semantics. Keyword search falsely flags strings, variable names, and comments (e.g., `# os.system is slow` or `model.eval()`). AST analysis verifies the syntactic context, ensuring only actual function invocations on target modules trigger alerts.

**Q2: How does the scanner handle alias imports such as `import os as my_os`?**
*Answer:* The scanner maintains an import alias table populated during initial traversal. When resolving calls, it resolves aliases back to their canonical module and function paths before checking against rules.

**Q3: What happens if a user submits code with broken syntax? Does scanning fail?**
*Answer:* If `ast.parse()` raises `SyntaxError`, the scanner falls back to `_line_based_fallback_scan()` which searches for CRITICAL patterns (e.g., raw `os.system` strings) and tags findings with `partial_scan: True`, ensuring no crashes occur.

**Q4: Why are some rules configured with `default_block=False`?**
*Answer:* To avoid breaking valid educational programs that use benign features like reading environment variables or using `tempfile`. Only truly high-risk CRITICAL rules block by default, while others provide advisory feedback unless `SCAN_BLOCK_LEVEL` is explicitly tightened.

**Q5: How does the healed-code scanner prevent AI repair loops from introducing vulnerabilities?**
*Answer:* In `nlp_explainer.py`, every candidate fix is scanned with `scan_gate()`. If a candidate fix introduces *new* blocking findings not present in the original code, the patch is rejected and logged.

**Q6: Does the static scanner execute or import the code it scans?**
*Answer:* Never. The scanner strictly operates on AST structures via Python's `ast` module. The code is never compiled, imported, or executed during scanning.
