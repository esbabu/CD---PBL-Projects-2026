# IntelliFix Feature 3: Server Hardening & Attack Surface Reduction

## 1. Executive Summary
This document specifies the defensive hardening measures applied to the IntelliFix Flask server (`app.py` and `gui.py`). The objective is to confine all file and execution operations to the project workspace, protect local endpoints from cross-origin and DNS-rebinding attacks, enforce robust payload limits, prevent server-side information leakage, and provide concurrency boundaries without breaking existing contracts or UI operations.

---

## 2. Before / After Attack Surface Comparison

| Attack Vector / Surface | Before Hardening (Vulnerable State) | After Hardening (Defended State) | Protection Mechanism |
|---|---|---|---|
| **Path Traversal / Arbitrary File Read** | `filename` parameter read directly without traversal check; allowed `../`, absolute paths | Strict regex check (`^(test\|sample).*\.py$`), `pathlib.Path.resolve()` workspace confinement, rejection of `..`, UNC, ADS (`:`), NUL bytes | `validate_workspace_filename()` in `app.py` |
| **Arbitrary File Overwrite** | `/api/save` allowed writing to arbitrary names and paths directly via `open(new_filename, "w")` | Rejection of non-`_fixed.py` targets, protection of core files, atomic write to `.tmp` followed by `os.replace` | Atomic file write with protected file blacklist in `/api/save` |
| **Windows Reserved Devices / ADS** | Requests for `CON.py`, `NUL`, `test1.py:stream` could freeze server or access alternate streams | Rejection of `CON`, `PRN`, `AUX`, `NUL`, `COM1..9`, `LPT1..9` and `:` | Stem lookup against `WINDOWS_RESERVED_NAMES` |
| **Denial of Service via Payload Size** | No `MAX_CONTENT_LENGTH`; potential memory exhaustion via oversized POST bodies | Enforced 200 KB cap (`MAX_CONTENT_LENGTH = 200 * 1024`); returns HTTP 413 | Flask config & payload length check in route handlers |
| **DNS Rebinding Attack** | Any `Host` header accepted by Werkzeug; allowed foreign domains pointing to 127.0.0.1 | `Host` header strictly checked against `127.0.0.1`, `localhost`, `testserver`; returns HTTP 400 | `@app.before_request` host header validation |
| **Cross-Origin Post (CSRF / Drive-by)** | Permissive `CORS(app)` allowed arbitrary foreign origins to make cross-origin POST calls | Mutating methods (POST/PUT/PATCH/DELETE) reject untrusted `Origin` headers with HTTP 403; CORS response restricted to localhost | `@app.before_request` and `@app.after_request` filters |
| **Network Exposure** | `app.run(host="0.0.0.0", debug=True)` exposed server to local area network | Strict loopback binding `host="127.0.0.1"`, `debug=False` | Loopback binding invariant in `app.py` and `gui.py` |
| **Traceback / Information Leakage** | Default 500 errors could expose Python stack traces and file paths | JSON error handler logs details server-side only; returns clean `{"error": "Internal Server Error"}` | `@app.errorhandler(500)` in `app.py` |
| **Sandbox Concurrency Exhaustion** | Unbounded simultaneous analysis runs could exhaust memory and CPU | Bounded semaphore (`MAX_CONCURRENT_RUNS = 4`) with 2.0s acquisition timeout; returns HTTP 429 | `_RUN_SEMAPHORE` in `/api/analyze` and `/api/execute` |
| **Missing HTTP Security Headers** | Default Flask responses had no protective browser headers | Added `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`, `Cache-Control: no-store` | `@app.after_request` header injection |

---

## 3. Detailed Protections in Plain Language

### 3.1 Workspace Confinement (`WORKSPACE_DIR`)
All file interactions are restricted to `WORKSPACE_DIR` (the project directory). The validator resolves paths using `pathlib.Path.resolve()`, checks that the resolved path is a child of `WORKSPACE_DIR`, and rejects:
- Relative navigation (`..`)
- Path separators (`/`, `\`)
- NTFS Alternate Data Streams (`:`)
- Windows reserved device names (`CON`, `PRN`, `AUX`, `NUL`, `COM1..9`, `LPT1..9`)
- NUL bytes (`\0`) and non-ASCII character look-alikes
- Symlinks, junctions, and directory reparse points.

### 3.2 Atomic Saving (`/api/save`)
When saving modified code:
1. Target filename is required to end with `_fixed.py` derived from a validated base name.
2. Core source files (`app.py`, `security_analyzer.py`, `multi_error.py`, etc.) are protected from being overwritten.
3. Code is written to a unique temporary file (`.tmp_save_<pid>_<ts>.tmp`), flushed and fsync'd, then atomically moved into place using `os.replace()`.

### 3.3 DNS Rebinding & Origin Protection
- **DNS Rebinding Defense**: An attacker configuring `malicious.com` to resolve to `127.0.0.1` cannot execute commands because the server checks the `Host` header against `127.0.0.1` and `localhost`. Any foreign host receives HTTP 400.
- **Origin Filtering**: Web browsers executing JavaScript on external websites send an `Origin` header. If a POST request originates from an untrusted origin, the server immediately returns HTTP 403 Forbidden.

### 3.4 Concurrency Boundaries
A bounded semaphore (`MAX_CONCURRENT_RUNS = 4`) gates entry to `/api/analyze` and `/api/execute`. If 4 analyses are actively running, additional incoming requests wait up to 2.0 seconds. If a slot does not become available, HTTP 429 (Too Many Requests) is returned rather than hanging or exhausting host system resources.

### 3.5 Runtime Hash Integrity
In addition to the legacy `build_marker`, `/api/version` now returns `runtime_hash`: the first 12 hex characters of the SHA-256 digest computed across the 10 core runtime modules (`app.py`, `nlp_explainer.py`, `error_extractor.py`, `security_analyzer.py`, `multi_error.py`, `sandbox_runner.py`, `sandbox_child.py`, `llm_explainer.py`, `llm_calls.py`, `offline_guide.py`).

---

## 4. Honest Limitations

1. **Localhost-Only Scope**: The server is designed for a single developer or student running locally. It does not provide multi-tenant user authentication, user sessions, or role-based access control.
2. **Plaintext HTTP (No TLS)**: Because the server is bound strictly to `127.0.0.1`, traffic does not leave the local loopback adapter. TLS/HTTPS is omitted to avoid certificate management overhead for local student labs.
3. **No Content-Security-Policy (CSP) in this Stage**: The web studio frontend (`templates/index.html`) relies on inline event handlers and scripts. Implementing strict CSP without refactoring frontend JavaScript into external bundles would break UI functionality. CSP remains future work.
4. **Basic Concurrency Limiting**: The semaphore is in-memory and per-process; it is not a distributed rate-limiter (such as Redis token-bucket).

---

## 5. Viva Questions and Answers

**Q1: What is DNS rebinding, and how does checking the Host header defend against it?**
*Answer:* In a DNS rebinding attack, an attacker controls a domain whose DNS TTL is short. The browser visits `attacker.com`, which later resolves to `127.0.0.1`. The browser considers it same-origin and sends requests to the local Flask server. By validating that the `Host` header is explicitly `127.0.0.1` or `localhost`, the server detects that the request was addressed to `attacker.com` and rejects it with HTTP 400.

**Q2: Why does `/api/save` write to a temporary file before renaming it?**
*Answer:* To ensure atomic file writes. If the server process crashes or power fails while writing directly to the target file, the file could be corrupted or truncated. Writing to a temporary file and using `os.replace()` guarantees that the file transition is atomic on the filesystem.

**Q3: Why was binding to `0.0.0.0` changed to `127.0.0.1`?**
*Answer:* Binding to `0.0.0.0` exposes the server to all network interfaces, including public Wi-Fi or LAN networks. Since this educational tool is designed for local development and lacks user authentication, binding to `0.0.0.0` would allow unauthorized devices on the local network to invoke endpoints. `127.0.0.1` restricts access strictly to the local machine.

**Q4: How does the server prevent path traversal using Windows NTFS alternate data streams (ADS)?**
*Answer:* Windows NTFS allows attaching secondary data streams to files using colons (e.g., `test1.py:stream`). The filename validator explicitly rejects any colon (`:`) character, preventing attackers from accessing or hiding content in alternate streams.

**Q5: What happens when 5 users send code to `/api/analyze` simultaneously?**
*Answer:* The server uses a bounded semaphore initialized to `MAX_CONCURRENT_RUNS` (default 4). Four requests will acquire the semaphore and execute; the 5th request will wait up to 2 seconds. If a running job finishes within 2 seconds, it executes; otherwise, it returns HTTP 429 Too Many Requests, protecting the machine from CPU and memory exhaustion.

**Q6: Why are 500 Internal Server Error tracebacks hidden from the HTTP response?**
*Answer:* Full tracebacks reveal internal file paths, operating system versions, library versions, and potentially sensitive environment variables. Returning a generic JSON error while logging the details server-side prevents attackers from gathering reconnaissance information about the host environment.
