# Pushdown Automata (PDA) Bracket Checker Specification

This document details the formal language theory, 7-tuple specification, transition table, Mermaid diagrams, trace walkthroughs, and viva questions for `bracket_checker.py` (Feature 6, Week 3).

---

## 1. Formal 7-Tuple Definition of the PDA

The bracket validator is modeled as a deterministic Pushdown Automaton (DPDA) accepting balanced parentheses, square brackets, and curly braces:

$$M_{\text{pda}} = (Q, \Sigma, \Gamma, \delta, q_0, Z_0, F)$$

- **$Q$ (Finite set of states)**: $\{q_{\text{loop}}, q_{\text{accept}}, q_{\text{reject}}\}$
- **$\Sigma$ (Input Alphabet)**: Delimiter terminals $\{\text{'('}, \text{')'}, \text{'['}, \text{']'}, \text{'\{'}, \text{'\}'}\}$ (other tokens from `tokenizer.py` are discarded before reaching the PDA).
- **$\Gamma$ (Stack Alphabet)**: $\{Z_0, \text{'('}, \text{'['}, \text{'\{'}\}$ where $Z_0$ represents the bottom-of-stack marker.
- **$q_0$ (Start state)**: $q_{\text{loop}}$
- **$Z_0$ (Initial stack symbol)**: $Z_0$
- **$F$ (Set of accepting states)**: $\{q_{\text{accept}}\}$
- **Acceptance Condition**: Acceptance by entering state $q_{\text{accept}}$ with stack containing only $Z_0$ upon consuming end-of-input ($\epsilon$).

---

## 2. Transition Function Table ($\delta: Q \times (\Sigma \cup \{\epsilon\}) \times \Gamma \to Q \times \Gamma^*$)

| State | Input Symbol | Top of Stack | Next State | Stack Operation | Meaning |
| :--- | :--- | :--- | :--- | :--- | :--- |
| $q_{\text{loop}}$ | `(` | $X \in \Gamma$ | $q_{\text{loop}}$ | $\text{PUSH}('(')$ | Open parenthesis pushed to stack |
| $q_{\text{loop}}$ | `[` | $X \in \Gamma$ | $q_{\text{loop}}$ | $\text{PUSH}('[')$ | Open bracket pushed to stack |
| $q_{\text{loop}}$ | `{` | $X \in \Gamma$ | $q_{\text{loop}}$ | $\text{PUSH}('\{')$ | Open brace pushed to stack |
| $q_{\text{loop}}$ | `)` | `(` | $q_{\text{loop}}$ | $\text{POP}()$ | Matching parenthesis matched and popped |
| $q_{\text{loop}}$ | `]` | `[` | $q_{\text{loop}}$ | $\text{POP}()$ | Matching bracket matched and popped |
| $q_{\text{loop}}$ | `}` | `{` | $q_{\text{loop}}$ | $\text{POP}()$ | Matching brace matched and popped |
| $q_{\text{loop}}$ | `)` / `]` / `}` | $Z_0$ | $q_{\text{loop}}$ | REJECT | Unmatched closing bracket |
| $q_{\text{loop}}$ | `)` | `[` or `{` | $q_{\text{loop}}$ | RECOVER | Mismatched closing delimiter |
| $q_{\text{loop}}$ | `]` | `(` or `{` | $q_{\text{loop}}$ | RECOVER | Mismatched closing delimiter |
| $q_{\text{loop}}$ | `}` | `(` or `[` | $q_{\text{loop}}$ | RECOVER | Mismatched closing delimiter |
| $q_{\text{loop}}$ | $\epsilon$ (EOF) | $Z_0$ | $q_{\text{accept}}$ | ACCEPT | Stack clean; all brackets balanced |
| $q_{\text{loop}}$ | $\epsilon$ (EOF) | $X \neq Z_0$ | $q_{\text{reject}}$ | REJECT | Unclosed opening brackets remaining |

---

## 3. Mermaid State and Transition Diagram

```mermaid
stateDiagram-v2
    [*] --> q_loop: Push Z0 onto stack
    
    q_loop --> q_loop: Input in '(', '[', '{' / PUSH to stack
    q_loop --> q_loop: Input in ')', ']', '}' / POP matching opener
    q_loop --> q_loop: Mismatch or Unmatched / Emit Diagnostic & Recover
    
    q_loop --> q_accept: EOF (epsilon) & Stack == [Z0]
    q_loop --> q_reject: EOF (epsilon) & Stack != [Z0] (Unclosed)
    
    q_accept --> [*]
    q_reject --> [*]
```

---

## 4. Worked Step-by-Step Trace for `( [ ] ) }`

Input Token Sequence: `[ '(', '[', ']', ')', '}' ]`

| Step | Current State | Input Symbol | Stack Before Step | Action Taken | Stack After Step | Diagnostic Emitted |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **0** | $q_{\text{loop}}$ | - | $[Z_0]$ | Initialize | $[Z_0]$ | None |
| **1** | $q_{\text{loop}}$ | `(` | $[Z_0]$ | PUSH(`(`) | $[Z_0, '(']$ | None |
| **2** | $q_{\text{loop}}$ | `[` | $[Z_0, '(']$ | PUSH(`[`) | $[Z_0, '(', '[']$ | None |
| **3** | $q_{\text{loop}}$ | `]` | $[Z_0, '(', '[']$ | POP(`[`) | $[Z_0, '(']$ | None |
| **4** | $q_{\text{loop}}$ | `)` | $[Z_0, '(']$ | POP(`(`) | $[Z_0]$ | None |
| **5** | $q_{\text{loop}}$ | `}` | $[Z_0]$ | REJECT | $[Z_0]$ | `Unmatched '}' at line 1, col 10 (nothing is open)` |
| **End**| $q_{\text{loop}}$ | $\epsilon$ | $[Z_0]$ | Check Stack | $[Z_0]$ | Final Verdict: `ok = False` (1 error) |

---

## 5. Why a DFA Cannot Validate Arbitrary Bracket Nesting

### Theoretical Proof Sketch
1. **The Language**: The language of balanced parentheses $L = \{ (^n )^n \mid n \ge 0 \}$ is a classic non-regular context-free language.
2. **Pumping Lemma for Regular Languages**:
   - Suppose $L$ is regular with pumping length $p$.
   - Choose the string $w = (^p )^p \in L$.
   - By the lemma, $w = xyz$ where $|xy| \le p$ and $|y| \ge 1$.
   - Therefore, $y$ consists entirely of open parentheses: $y = (^k$ for some $k \ge 1$.
   - Pumping with $i=2$ gives $x y^2 z = (^{p+k} )^p$.
   - The number of open and close parentheses is unequal ($p+k \neq p$), so $x y^2 z \notin L$, creating a contradiction.
3. **Conclusion**: A DFA possesses only a finite number of states $k$ and cannot store an arbitrary, unbounded count of open brackets. A Pushdown Automaton equipped with a Last-In First-Out (LIFO) stack is strictly necessary.

---

## 6. Viva Examination Questions & Answers

1. **Q: What is the formal difference between a DFA and a PDA?**  
   **A:** A DFA has only finite state memory $Q$. A PDA enhances the finite control with an unbounded Last-In First-Out (LIFO) stack memory $\Gamma$, allowing recognition of Context-Free Languages (Chomsky Type-2).

2. **Q: Why is bottom marker $Z_0$ needed in a PDA?**  
   **A:** $Z_0$ provides a deterministic sentinel to detect when the stack is empty without throwing an underflow error. If a closing bracket appears when $Z_0$ is on top, the PDA immediately identifies an unmatched closing delimiter.

3. **Q: How does `bracket_checker.py` avoid getting confused by brackets inside quotes or comments?**  
   **A:** It consumes tokens produced by `tokenizer.py`. Because `tokenizer.py` classifies string literals as `STRING` and comments as `COMMENT`, `bracket_checker.py` filters for `tok["type"] == "BRACKET"` and completely ignores strings and comments.

4. **Q: What is panic-mode / sync recovery in bracket checking?**  
   **A:** When a mismatched delimiter is encountered, instead of crashing or stopping analysis, the checker reports the mismatch, resynchronizes the stack (by popping or discarding), and continues to find any subsequent bracket errors in the file.

5. **Q: Why does the bracket checker enforce a maximum stack depth of 10,000?**  
   **A:** To defend against stack-exhaustion Denial of Service (DoS) attacks from deeply nested adversary code (e.g. 100,000 open brackets) while staying well above any legitimate source file nesting depth.

6. **Q: How does Python 3.13 report bracket errors?**  
   **A:** Python 3.13 uses enhanced PEG parser diagnostics with messages such as `"'(' was never closed"`, `"unmatched ')'"`, and `"closing parenthesis ')' does not match opening parenthesis '['"`.

7. **Q: What is an unclosed bracket vs an unmatched bracket?**  
   **A:** An unclosed bracket is an opening delimiter that was never shut by EOF (`stack != [Z_0]`). An unmatched bracket is an unexpected closing delimiter when nothing or a different delimiter is open.

8. **Q: Can a PDA check context-sensitive constraints like variable declarations before use?**  
   **A:** No. Variable scoping and type declarations form context-sensitive languages (Chomsky Type-1) requiring symbol tables or Linear Bounded Automata / Turing Machines.
