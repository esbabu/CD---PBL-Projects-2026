# Deterministic Lexical Analyzer (Tokenizer) Specification

This document provides technical documentation, regular expression specifications, operational rules, and viva examination preparation for `tokenizer.py` (Feature 5, Week 3).

---

## 1. Token Taxonomy and Classification Table

| Token Type | Category | Description | Examples |
| :--- | :--- | :--- | :--- |
| `KEYWORD` | Reserved words | Python language keywords (`keyword.kwlist`) | `def`, `class`, `return`, `if`, `while`, `import` |
| `NAME` | Identifiers | Variables, function names, soft keywords | `x`, `total_sum`, `match`, `case`, `type`, `_` |
| `NUMBER` | Numeric literals | Decimals, floats, scientific, hex, oct, bin, imag | `42`, `3.14`, `1e-5`, `0xFF`, `0b101`, `2j` |
| `STRING` | String literals | Single, double, and triple-quoted strings | `'hello'`, `"world"`, `r"raw\n"`, `f"val={x}"` |
| `COMMENT` | Comments | Single-line comments to end of line | `# this is a comment` |
| `OP` | Operators & Delimiters | Arithmetic, bitwise, assignment, punctuation | `+`, `-=`, `**`, `//`, `->`, `:=`, `...`, `==` |
| `BRACKET` | Grouping delimiters | Parentheses, brackets, and braces | `(`, `)`, `[`, `]`, `{`, `}` |
| `NEWLINE` | Line terminators | Physical and logical newline tokens | `\n`, `\r\n` |
| `ERRORTOKEN` | Lexical errors | Stray characters, unterminated strings, bad literals | `$`, `?`, `'unterminated`, `12ab` |

---

## 2. Regular Expression Architecture

The lexical analyzer compiles a single prioritized master regular expression containing named capturing groups.

```python
# Priority order:
1. COMMENT:         #[^\r\n]*
2. TRIPLE_STRING:   PREFIX?"""[\s\S]*?""" | PREFIX?'''[\s\S]*?'''
3. UNTERM_TRIPLE:   PREFIX?"""[\s\S]*     | PREFIX?'''[\s\S]*
4. SINGLE_STRING:   PREFIX?"(?:[^"\\\r\n]|\\.)*" | PREFIX?'(?:[^'\\\r\n]|\\.)*'
5. UNTERM_SINGLE:   PREFIX?"(?:[^"\\\r\n]|\\.)*  | PREFIX?'(?:[^'\\\r\n]|\\.)*
6. NUM_HEX:         0[xX](?:_?[0-9a-fA-F])+
7. NUM_BIN:         0[bB](?:_?[01])+
8. NUM_OCT:         0[oO](?:_?[0-7])+
9. NUM_FLOAT:       (?:\d(?:_?\d)*\.(?:\d(?:_?\d)*)?|\.\d(?:_?\d)*)(?:[eE][+-]?\d(?:_?\d)*)?[jJ]?
10. INVALID_NUM:    \d+(?:\.\d+)?[A-Za-z]\w*  (e.g., 12ab, 1if)
11. NUM_DEC:        \d(?:_?\d)*[jJ]?
12. NAME:           [^\W\d]\w*
13. BRACKET:        [\(\)\[\]\{\}]
14. OP:             **= | //= | >>= | <<= | -> | := | ... | == | <= | >= | + | - | * | ...
15. WHITESPACE:     [ \t\f]+
16. LINECONT:       \\(?:\r\n|\r|\n)
17. ERRORTOKEN:     .
```

---

## 3. The Longest-Match Rule (Maximal Munch)

### Explanation for Beginners
When scanning code like `>>=`, a lexical analyzer could theoretically match `>` (greater than), `>>` (right shift), or `>>=` (in-place right shift).
Under the **Longest-Match Rule** (also known as *Maximal Munch*):
1. The lexer always consumes the longest contiguous sequence of characters that satisfies any valid token pattern.
2. Therefore, `>>=` is greedily recognized as a single 3-character operator rather than three 1-character tokens.
3. In `tokenizer.py`, multi-character operators are ordered strictly longest-first in the regular expression to guarantee deterministic greedy matching.

---

## 4. Key Architectural Limitations

1. **INDENT / DEDENT**:
   - Python's indentation tokens require tracking an indentation stack (a context-sensitive state machine). In standard compiler architecture, indentation token generation is the responsibility of the syntax parser layer; `tokenizer.py` tracks lines, columns, and newlines without synthesizing indentation tokens.
2. **f-string Expressions**:
   - In Python 3.12+, Python's standard `tokenize` parses internal expressions within `{...}` inside f-strings into nested tokens. `tokenizer.py` treats formatted strings as single complete `STRING` literal tokens.
3. **Identifier Unicode Handling**:
   - The master regex uses `[^\W\d]\w*` which supports Unicode identifiers per PEP 3131. The accompanying theoretical model in `dfa.py` models ASCII identifiers `[A-Za-z_][A-Za-z0-9_]*`.

---

## 5. Viva Examination Questions & Answers

1. **Q: What is the primary role of a lexical analyzer in a compiler pipeline?**  
   **A:** To convert a raw stream of characters into a structured sequence of tokens with classified types, source positions, and metadata, discarding irrelevant whitespace and comments.

2. **Q: How does the tokenizer differentiate between keywords and identifiers?**  
   **A:** Both follow identifier lexical syntax (`[^\W\d]\w*`). The tokenizer matches the token as a name first, then looks up the text in `keyword.kwlist` (excluding soft keywords like `match` and `case`) to classify it as `KEYWORD` or `NAME`.

3. **Q: How does `tokenizer.py` ensure immunity against Regular Expression Denial of Service (ReDoS)?**  
   **A:** Patterns avoid nested unbounded quantifiers (e.g., `(a+)+`). All loops are bounded or possess mutually exclusive delimiters, guaranteeing linear-time $O(N)$ execution.

4. **Q: How are lexical errors reported without raising exceptions?**  
   **A:** Lexical errors (unknown characters, unterminated strings, malformed numbers) are collected into an `errors` list with line and column data, while emitting an `ERRORTOKEN` to allow subsequent analysis.

5. **Q: Why are comments and strings matched before operators?**  
   **A:** String literals and comments can contain characters like `#`, `+`, `*`, `(`, `"`. Prioritizing strings and comments prevents those characters from being misparsed as operators or delimiters.

6. **Q: What is a soft keyword in Python 3.10+?**  
   **A:** Words like `match`, `case`, and `type` that act as keywords only in specific structural contexts (pattern matching, type aliases) but remain valid variable names elsewhere. In `tokenizer.py`, they are classified as `NAME`.

7. **Q: How are multi-line triple-quoted string positions tracked?**  
   **A:** The tokenizer calculates `start_line`, `start_col`, `end_line`, and `end_col` by splitting internal line breaks, ensuring accurate spans for multi-line docstrings.

8. **Q: Why does the tokenizer handle Byte Order Marks (BOM)?**  
   **A:** Windows UTF-8 files often contain a leading `\ufeff` character. Stripping it gracefully prevents spurious syntax errors on line 1 column 0.
