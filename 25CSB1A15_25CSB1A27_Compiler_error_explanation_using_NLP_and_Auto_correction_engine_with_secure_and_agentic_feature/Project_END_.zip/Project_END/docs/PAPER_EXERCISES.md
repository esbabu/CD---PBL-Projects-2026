# Paper-and-Pencil Automata Exercises for IntelliFix

This document lists the formal automata designs corresponding to the lexical and syntactic analysis engines implemented in Week 3 of the IntelliFix project.

> **Note for Viva / Lab Evaluation**:
> Per academic requirements, the state transition diagrams and formal 5-tuple / 7-tuple specifications must be drawn and completed by hand on paper. The sections below provide the problem definitions, alphabet constraints, blank template tables, and targeted viva questions for evaluation.

---

## Exercise 1: ASCII Identifier Deterministic Finite Automaton (DFA)

### 1.1 Specification
Design a Deterministic Finite Automaton $M_{\text{ident}}$ that accepts valid ASCII Python identifiers matching the regular expression `[A-Za-z_][A-Za-z0-9_]*`.

- **Input Alphabet ($\Sigma$)**: ASCII letters (`[A-Za-z]`), digits (`[0-9]`), underscore (`_`), and invalid symbols.
- **Constraints**:
  - Must begin with a letter or underscore.
  - Digits are allowed strictly after the first character.
  - Any invalid character transitions to a dead/trap state $q_{\text{trap}}$.

### 1.2 Formal 5-Tuple Definition (Fill in by hand)
$$M_{\text{ident}} = (Q, \Sigma, \delta, q_0, F)$$
- $Q$ (Set of states): `[                                                     ]`
- $\Sigma$ (Alphabet): `[ A-Za-z, 0-9, _, other                               ]`
- $q_0$ (Start state): `[                                                     ]`
- $F$ (Accepting states): `[                                                  ]`

### 1.3 Transition Table (Complete on paper)
| State | Input: `[A-Za-z_]` | Input: `[0-9]` | Input: Other |
| :--- | :--- | :--- | :--- |
| $q_0$ (Start) | | | |
| $q_1$ (Accepting) | | | |
| $q_{\text{trap}}$ (Dead) | | | |

### 1.4 State Diagram Drawing
*(Draw the 3-state transition graph with circles, double circles for accepting states, and labeled directed edges here)*

```
[ Draw by hand on paper: q0 -> q1 (accept) via letter/_, q1 loop via letter/digit/_, q0/q1 -> q_trap via other ]
```

### 1.5 Viva Defense Question
**Q:** Why can an identifier recognizer be implemented strictly using a Deterministic Finite Automaton (DFA) without requiring stack memory?  
**A:** (Student to state): *Identifiers form a regular language described by regular expressions; recognizing them requires remembering only finite history (whether we have seen a valid start symbol vs inside the body vs invalid), which requires only $O(1)$ states and zero stack memory.*

---

## Exercise 2: Unsigned Decimal & Float DFA

### 2.1 Specification
Design a DFA $M_{\text{num}}$ that accepts unsigned decimal integers and decimal floats with an optional fractional part, matching the language `[0-9]+(\.[0-9]+)?`.

- **Alphabet ($\Sigma$)**: Digits `[0-9]`, decimal point `.`, and other characters.
- **Rules**:
  - Must start with at least one digit.
  - A decimal point must be followed by at least one digit to be accepted as a float (or specify standard fractional rule).
  - Trailing symbols transition to trap.

### 2.2 Formal 5-Tuple Definition (Fill in by hand)
$$M_{\text{num}} = (Q, \Sigma, \delta, q_0, F)$$
- $Q$: `[                                                                     ]`
- $\Sigma$: `[ 0-9, '.', other                                                ]`
- $q_0$: `[                                                                   ]`
- $F$: `[                                                                     ]`

### 2.3 Transition Table (Complete on paper)
| State | Input: `[0-9]` | Input: `.` | Input: Other |
| :--- | :--- | :--- | :--- |
| $q_0$ (Start) | | | |
| $q_{\text{int}}$ (Integer Accept) | | | |
| $q_{\text{dot}}$ (Seen Dot) | | | |
| $q_{\text{float}}$ (Float Accept) | | | |
| $q_{\text{trap}}$ (Dead) | | | |

### 2.4 State Diagram Drawing
```
[ Draw by hand on paper: q0 -> q_int via digit; q_int loop on digit; q_int -> q_dot on '.'; q_dot -> q_float on digit; q_float loop on digit ]
```

### 2.5 Viva Defense Question
**Q:** What distinguishes a token like `12ab` from a valid number, and how does the lexical analyzer report it?  
**A:** (Student to state): *`12ab` starts matching number digits but is immediately followed by identifier characters without a delimiter. A DFA for numbers enters trap on `a`; the tokenizer flags an `invalid_number_literal` error token rather than crashing.*

---

## Exercise 3: Bracket Matching Pushdown Automaton (PDA)

### 3.1 Specification
Design a deterministic Pushdown Automaton $M_{\text{pda}}$ that verifies balanced and properly nested brackets: parentheses `()`, square brackets `[]`, and curly braces `{}`.

- **Input Alphabet ($\Sigma$)**: `(`, `)`, `[`, `]`, `{`, `}`, and non-bracket tokens (which are skipped/ignored).
- **Stack Alphabet ($\Gamma$)**: `Z_0` (bottom marker), `(`, `[`, `{`.
- **Acceptance Condition**: Acceptance by empty stack or by entering an accepting state with stack containing only $Z_0$.

### 3.2 Formal 7-Tuple Definition (Fill in by hand)
$$M_{\text{pda}} = (Q, \Sigma, \Gamma, \delta, q_0, Z_0, F)$$
- $Q$: `[ q_loop, q_accept, q_reject                                          ]`
- $\Sigma$: `[ '(', ')', '[', ']', '{', '}'                                  ]`
- $\Gamma$: `[ Z_0, '(', '[', '{'                                            ]`
- $q_0$: `[ q_loop                                                           ]`
- $Z_0$: `[ Z_0                                                              ]`
- $F$: `[ q_accept                                                           ]`

### 3.3 Stack Transition Rules ($\delta(q, a, X) = (p, \gamma)$)
Complete the table for representative transitions:
1. $\delta(q_{\text{loop}}, '(', X) = (q_{\text{loop}}, \dots)$ (Push `(`)
2. $\delta(q_{\text{loop}}, '[', X) = (q_{\text{loop}}, \dots)$ (Push `[`)
3. $\delta(q_{\text{loop}}, '{', X) = (q_{\text{loop}}, \dots)$ (Push `{`)
4. $\delta(q_{\text{loop}}, ')', '(') = (q_{\text{loop}}, \dots)$ (Pop `(`)
5. $\delta(q_{\text{loop}}, ']', '[') = (q_{\text{loop}}, \dots)$ (Pop `[`)
6. $\delta(q_{\text{loop}}, '}', '{') = (q_{\text{loop}}, \dots)$ (Pop `{`)
7. $\delta(q_{\text{loop}}, \epsilon, Z_0) = (q_{\text{accept}}, \dots)$

### 3.4 Trace Exercise
Trace the stack configuration for the input string `( [ ] ) }`:
1. Initial: `(q_loop, "( [ ] ) }", Z_0)`
2. Read `(`: `(q_loop, "[ ] ) }", ( Z_0)`
3. Read `[`: `(q_loop, "] ) }", [ ( Z_0)`
4. Read `]`: `(q_loop, ") }", ( Z_0)`
5. Read `)`: `(q_loop, "}", Z_0)`
6. Read `}`: Stack top is $Z_0 \implies$ **REJECT / UNMATCHED CLOSING BRACKET**.

### 3.5 Viva Defense Question
**Q:** Why is a DFA fundamentally incapable of validating arbitrary nested brackets such as $a^n b^n$?  
**A:** (Student to state): *Arbitrary nesting requires keeping track of an unbounded count of open brackets. A DFA has a fixed finite number of states $|Q| = k$ and by the Pumping Lemma for Regular Languages cannot maintain unbounded counting/stack memory. A PDA with a LIFO stack provides the necessary context-free capability.*
