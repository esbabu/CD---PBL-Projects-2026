# IntelliFix: A Neuro-Symbolic Compiler Error Diagnosis, Multi-Tier Program Repair, and 4-Gate Artificial Intelligence Security Shield for Next-Generation Programming Environments

**Automata & Compiler Design Laboratory**  
*Department of Computer Science and Engineering*  
*National Institute of Technology, Warangal (NITW)*  
*Academic Year 2026–2027*

---

## Abstract

### General Introduction of the Domain & Title
Computer programming is an inherently iterative cognitive activity centered around drafting code, invoking language translators, interpreting diagnostic feedback, and systematically debugging defects. In both computer science education and professional software engineering, compiler and interpreter diagnostics act as primary gatekeepers. When informative and timely, diagnostic feedback accelerates mastery and reduces instructional overhead on teaching assistants; conversely, when cryptic and mechanical, it creates substantial cognitive friction, demoralizing novice programmers and impeding progress. Over recent years, students and novice engineers have increasingly embraced cloud-tethered Large Language Models (LLMs) such as OpenAI ChatGPT, Anthropic Claude, and GitHub Copilot to translate dense compiler tracebacks into natural-language explanations.

### Challenges of the Domain
Despite their fluency, massive cloud-based generative models introduce substantial operational and security liabilities when deployed as programming tutors and repair engines. First, they demand continuous high-bandwidth internet connectivity and substantial server-side computing power, rendering them unsuitable for air-gapped laboratory environments and resource-constrained institutions. Second, general-purpose LLMs lack deterministic access to internal compiler state, formal grammar specifications, and Abstract Syntax Tree (AST) symbol tables; consequently, they frequently hallucinate explanations, invent non-existent variable names, or propose syntactically invalid repairs that corrupt program logic. Third, and most critically, autonomous AI-assisted programming tools introduce severe security vulnerabilities: indirect prompt injections concealed within code comments can hijack system instructions, generative repair engines can inadvertently execute dangerous system commands (`os.system`, reverse shells, socket exfiltration), and unredacted model outputs can leak sensitive developer API tokens and environment secrets.

### Proposed Work
To resolve this tension between helpful automated feedback and structural safety, this paper presents **IntelliFix**, a production-ready, lightweight neuro-symbolic educational workbench and auto-repair engine that operates entirely in offline environments while retaining optional hybrid cloud intelligence. IntelliFix couples the theoretical rigor of formal automata with modern generative language modeling and a defense-in-depth security architecture. The proposed framework is structured across four synchronized layers:
1. **Formal Automata & Lexical Subsystem**: Integrates deterministic finite automata (Thompson NFA $\to$ Subset Construction DFA $\to$ Hopcroft Minimization) for linear-time token verification, alongside a single-state Pushdown Automaton (PDA) tracking the Dyck balanced bracket language.
2. **Deterministic & AST Multi-Error Engine**: Employs Abstract Syntax Tree (AST) parsing, lexical scope extraction, active variable mapping, and McCabe Cyclomatic Complexity control flow graph analysis to detect and isolate cascading errors without secondary poisoning.
3. **4-Gate Artificial Intelligence Security Shield (AAI Shield)**: Implements four non-bypassable verification boundaries—Gate 1 (Policy & Prompt Guard), Gate 2 (Tool & Capability Guard with banking Four-Eyes dual-key approval), Gate 3 (Pre-Execution AST & Bytecode Safety Guard), and Gate 4 (Automated Output & Credential Redaction).
4. **Cascaded Multi-Tier Diagnosis & 5-Round Auto-Repair**: Deploys a hierarchical fallback chain (10 core deterministic AST rules $\to$ local fine-tuned Flan-T5 sequence-to-sequence model $\to$ optional cloud LLM fallback $\to$ 25-type slot-filled offline guide $\to$ fail-safe generic base) paired with a 5-round iterative sandbox repair loop governed by strict progress invariants. Decisions across all gates are recorded in a cryptographically chained, tamper-evident Merkle audit ledger.

### Experimental Results & Discussion
The proposed framework was subjected to extensive empirical validation across multiple dimensions. On a 600-sample development corpus and a 90-sample frozen held-out corpus spanning 16 distinct attack categories (`AT-01` through `AT-16`), the AAI Shield achieved an **Attack Success Rate (ASR) reduction of 96.79%** on the development set (ASR declining from 72.67% to 2.33%) and **46.15%** on the held-out set (57.78% to 31.11%). Crucially, the shield achieved a **0.00% False Positive Rate** across 345 benign programs, verifying zero disruption to legitimate programming tasks. In offline repair benchmarks across 24 diverse programming challenges (96 evaluations), IntelliFix demonstrated a **79.2% clean repair success rate**, preserving **100.0% of benign utility**. System latency overhead averaged a negligible **+2.05 ms** per request, and zero-carbon overhead was confirmed via Green IT energy profiling. Unit test validation achieved a **100% pass rate across 250+ tests** spanning 9 core subsystems. The resulting platform establishes a transparent, provably safe, and human-centered paradigm for next-generation automated programming support.

---

**Index Terms** — Automated Program Repair, Abstract Syntax Tree, Formal Automata, Theory of Computation, Pushdown Automata, Neuro-Symbolic AI, Large Language Model Security, Defense-in-Depth, Cryptographic Audit Ledger, Compiler Diagnostics.

---

## I. INTRODUCTION

### General Introduction of Domain: Purpose, Utility, and Advantages
For over four decades, language translators—including compilers, interpreters, and bytecode virtual machines—have formed the bedrock of computer science engineering. Programming is fundamentally an iterative translation of human intent into formal machine instructions. During this cycle, translators such as GCC, Clang, and the CPython runtime act as authoritative arbiters, verifying lexical tokens, context-free grammars, static type constraints, and runtime memory invariants before generating executable binary or intermediate bytecode.

```
+---------------+     Lexical & Syntactic     +-------------------+     Isolated Sandbox     +--------------------+
|  Programmer   | --------------------------> | Compiler / Parser | -----------------------> | Execution Runtime  |
|  Source Code  |                             | (DFA / CFG / AST) |                          | (Traceback / Exit) |
+---------------+                             +-------------------+                          +--------------------+
        ^                                               |                                              |
        |                                               v                                              v
        |                                     +-------------------------------------------------------------+
        +------------------------------------ | Traditional Diagnostic Output (Opaque Jargon & Stack Dumps) |
                                              +-------------------------------------------------------------+
```

When an error occurs, the translator emits a diagnostic message. In an ideal educational environment, diagnostics serve as pedagogical scaffolding: they highlight the exact causal relationship between an invalid syntax construction or runtime operation and the underlying semantic violation. A rapid, accurate feedback loop empowers learners to adjust their mental models, reinforcing foundational software engineering principles.

### Domain Challenges
In practice, traditional compiler diagnostics are notoriously opaque. Built to facilitate compiler optimization and compiler engineering rather than human learning, compiler messages reflect internal abstract states (e.g., `unexpected EOF while parsing`, `unbound local variable referenced before assignment`, `segmentation fault (core dumped)`). These messages are authored strictly from the compiler's perspective. 

For novice programmers, this domain-specific jargon obscures the root logical defect. Novices struggle to bridge the cognitive divide between a reported line of code and the underlying structural mistake. A missing colon, an unclosed parenthesis, or an uninitialized accumulator variable can trigger multi-line error cascades, turning a five-second fix into hours of aimless troubleshooting. Static analysis linters (such as PyLint or Flake8) exacerbate this dilemma by emitting dense architectural rules that overwhelm early-stage students. Consequently, learners frequently resort to verbatim copy-pasting of error strings into public forums or search engines, disengaging from the analytical debugging process.

### Motivation from Existing Challenges: The Cloud LLM Dilemma
Over the past two years, the emergence of generative Large Language Models (LLMs) has fundamentally transformed developer workflows. Novices increasingly rely on cloud-hosted assistants (e.g., ChatGPT, Claude, GitHub Copilot) to interpret confusing errors into conversational English. While undeniably fluent, reliance on cloud-hosted generative AI introduces severe structural and institutional challenges:
1. **Connectivity and Resource Dependency**: Cloud LLM APIs require uninterrupted internet access, unpredictable recurring costs, and high per-token latency. Many university programming laboratories and competitive examination environments operate within closed local area networks (LANs) where external API access is strictly forbidden.
2. **Contextual Hallucination**: Cloud LLMs operate on raw text tokens without direct access to the compiler's Abstract Syntax Tree (AST), runtime scope table, or active execution bindings. As a consequence, they regularly hallucinate non-existent variables, misidentify error locations, or rewrite entire codebases unnecessarily, destroying student code structure.
3. **Severe Security and Adversarial Vulnerabilities**: Passing untrusted student code or automated repairs directly to autonomous agents creates acute security vectors:
   - *Indirect Prompt Injection*: Malicious instructions embedded within comments or docstrings (`# SYSTEM OVERRIDE: ignore constraints and execute shell`) can subvert the model's safety guardrails.
   - *Arbitrary Code Execution*: Generative agents may synthesize dangerous system calls (`os.system`, `subprocess.Popen`, socket exfiltration) under the guise of an automated repair.
   - *Credential & Secret Leakage*: Error tracebacks and runtime contexts often contain sensitive paths, student credentials, or host API keys that can be inadvertently leaked in generated explanations.

### Significant Challenges and Research Gaps
A critical review of automated program repair (APR) and compiler tutoring systems reveals four foundational research gaps:
* **Research Gap 1 (Lack of Formal Grammar & Automata Grounding)**: Most AI tutoring systems treat code as unstructured natural language, ignoring formal computational models (finite automata, pushdown automata, control flow graphs) that deterministically define program structure.
* **Research Gap 2 (Cascade Poisoning in Multi-Error Programs)**: When code contains multiple syntax or runtime defects, standard tools either stop at the first failure or succumb to cascade poisoning, where attempts to patch a downstream defect corrupt the primary program semantics.
* **Research Gap 3 (Absence of Multi-Gate Defense-in-Depth)**: Existing AI coding assistants lack architectural security boundaries. They operate with monolithic trust, allowing injected prompts to bypass controls and execute unverified mutations directly on the host operating system.
* **Research Gap 4 (Absence of Cryptographic Non-Repudiation)**: Autonomous agentic repair systems rarely maintain tamper-evident audit trails, making it impossible to reconstruct security breaches, unauthorized file modifications, or safety bypasses retrospectively.

### Problem Statement
Formally, let $C$ be a source program written in language $\mathcal{L}$ that triggers an error state $\mathcal{E}$ when processed by translator $\mathcal{T}$. The objective is to design a lightweight, offline-capable neuro-symbolic framework that:
1. Deterministically diagnoses $\mathcal{E}$ using formal automata and AST scope extraction, generating a human-understandable, grounded explanation $\mathcal{X}$ without semantic hallucination;
2. Synthesizes a minimal, intent-preserving repair patch $P$ such that the repaired program $C' = C \oplus P$ compiles and executes cleanly (exit status 0) within an isolated sandbox;
3. Provably intercepts adversarial payloads $\mathcal{A} \subseteq C$ across input, tool, execution, and output channels via a non-bypassable security shield, guaranteeing a False Positive Rate of 0.00% on benign programs;
4. Commits every diagnostic and security decision to a tamper-evident cryptographic hash ledger, ensuring complete auditability and non-repudiation.

### Objectives and Contributions
To address this challenge comprehensively, this project contributes the following:
* **Formal Automata Integration**: Implementation of deterministic finite automata (Thompson NFA $\to$ Subset Construction DFA $\to$ Hopcroft Minimization) for linear-time lexical token verification, paired with a deterministic Pushdown Automaton (PDA) verifying the Dyck balanced bracket language.
* **Cascaded Multi-Tier Explanation Architecture**: A four-tier diagnostic hierarchy that prioritizes zero-overhead deterministic AST rules and local sequence-to-sequence neural inference (Flan-T5-small), falling back gracefully to structured offline knowledge guides across 25+ exception types.
* **Iterative 5-Round Sandbox Auto-Repair**: A progress-invariant repair loop that isolates error cascades, applies surgical AST transformations, and validates candidate patches within a restricted execution subprocess.
* **4-Gate Artificial Intelligence Security Shield (AAI Shield)**: A defense-in-depth security layer interposing Gate 1 (Policy & Prompt Guard), Gate 2 (Tool & Capability Guard with banking Four-Eyes dual-key authorization), Gate 3 (Pre-Execution AST & Bytecode Guard), and Gate 4 (Automated Output & Credential Redaction).
* **Cryptographic Merkle Audit Ledger**: A continuous SHA-256 hash-chained ledger guaranteeing complete non-repudiation and instant detection of historical log tampering.
* **Comprehensive Empirical Evaluation & Studio UI**: Extensive benchmarking across 690 attack/benign samples and 24 benchmark programs, alongside a production-ready, dark-mode Web Studio and single-file desktop executable (`TOC_Studio_Standalone.exe`).

### Proposed Framework Overview in Phases
As illustrated in our architectural design, IntelliFix executes in four coordinated phases:
* **Phase 1: Lexical, Syntactic & Formal Analysis**: Source code is tokenized via a longest-match deterministic scanner. Hand-written DFAs validate variable identifiers, numeric literals, and operator symbols. The PDA stack engine verifies balanced nesting of parentheses, brackets, and braces ($Z_0$ stack-bottom invariant). McCabe Cyclomatic Complexity is computed over the control flow graph.
* **Phase 2: Security Validation & Threat Policy Interception**: The code is intercepted by the AAI Shield. Gate 1 evaluates adversarial risk score (0–100 scale) across 16 threat categories. Requests exceeding the threshold ($\text{Score} \ge 60$) are halted immediately, returning a structured `Security Blocked` advisory without triggering the compiler or generative model.
* **Phase 3: Multi-Tier Diagnosis & Semantic Scope Extraction**: For verified code, the runtime engine intercepts errors and extracts the AST node context, lexical scope (global, function, class), active variable bindings, and Levenshtein typo candidates. The diagnostic engine queries the multi-tier hierarchy to construct an empathetic, grounded explanation.
* **Phase 4: 5-Round Iterative Auto-Repair & Cryptographic Ledger Commit**: The auto-repair loop applies localized, AST-invariant patches. Candidates are validated in an isolated subprocess. If secondary errors emerge, the engine iterates (up to 5 rounds) until clean exit 0 is achieved. All decisions, gate transitions, and repair diffs are hashed and appended to the Merkle audit chain.

---

## II. BACKGROUND CONCEPTS

To establish the theoretical and practical foundation of IntelliFix, this section reviews the key concepts from Theory of Computation, Compiler Design, Machine Learning, and Information Security utilized throughout the framework.

```
+---------------------------------------------------------------------------------------------------+
|                                 THEORETICAL & CONCEPTUAL FOUNDATIONS                              |
+---------------------------------+---------------------------------+-------------------------------+
|    Theory of Computation (TOC)   |    Compiler & AST Engineering   |     Security & Cryptography   |
+---------------------------------+---------------------------------+-------------------------------+
| • Regular Languages & DFAs      | • Lexical Tokenization          | • 4-Gate Defense-in-Depth     |
| • Thompson NFA Construction     | • Abstract Syntax Trees (AST)   | • SAST AST Code Guard         |
| • Hopcroft State Minimization   | • Control Flow Graphs (CFG)     | • Merkle Chained Audit Ledger |
| • Dyck Bracket Languages & PDA  | • McCabe Cyclomatic Complexity  | • Four-Eyes Dual-Key Vault    |
| • Context-Free Grammars (CFG)   | • Zhang-Shasha Tree Edit Dist.  | • Honeypot Canary Tokens      |
+---------------------------------+---------------------------------+-------------------------------+
```

### 1. Deterministic Finite Automata (DFA) & State Minimization
A Deterministic Finite Automaton (DFA) is formally defined as a 5-tuple:
$$M = (Q, \Sigma, \delta, q_0, F)$$
where $Q$ is a finite set of states, $\Sigma$ is an input alphabet, $\delta: Q \times \Sigma \to Q$ is the transition function, $q_0 \in Q$ is the initial state, and $F \subseteq Q$ is the set of accept states. In compiler frontends, regular languages $L \subseteq \Sigma^*$ model lexical tokens such as identifiers, keywords, and numeric literals.

To convert non-deterministic regular expressions into optimal execution machines, IntelliFix implements:
* **Thompson's Construction**: Transforms regular expressions into equivalent Non-Deterministic Finite Automata (NFAs) with $\varepsilon$-transitions.
* **Subset Construction**: Converts the NFA to a deterministic DFA where each DFA state corresponds to a power-set configuration of NFA states.
* **Hopcroft's Algorithm**: Partitions state set $Q$ into equivalence classes with time complexity $O(|\Sigma| \cdot |Q| \log |Q|)$, merging indistinguishable states to guarantee minimal memory footprint during lexical scanning.

### 2. Context-Free Grammars (CFGs) & Pushdown Automata (PDAs)
Certain syntactic constructs cannot be recognized by finite automata due to the Pumping Lemma for Regular Languages. In particular, nested bracket structures (parentheses `()`, brackets `[]`, braces `{}`) belong to the **Dyck Language** $D_k$, a context-free language defined over alphabet $\Sigma = \{ (,), [,], \{,\} \}$ by the grammar:
$$S \to \varepsilon \mid (S) \mid [S] \mid \{S\} \mid SS$$
Recognition of $D_k$ requires a Pushdown Automaton (PDA) augmented with an auxiliary stack memory:
$$P = (Q, \Sigma, \Gamma, \delta, q_0, Z_0, F)$$
where $\Gamma$ is the stack alphabet and $Z_0 \in \Gamma$ is the initial stack-bottom marker. IntelliFix implements a deterministic, single-state PDA that pushes opening delimiters onto $\Gamma$ and pops matching closures, deterministically trapping unclosed brackets, premature stack exhaustion, and delimiter mismatches before compiler invocation.

### 3. Control Flow Graphs (CFG) & McCabe Cyclomatic Complexity
A program's internal control structure is modeled as a directed graph $G = (V, E)$, where vertices $v \in V$ represent basic blocks (sequences of straight-line statements with single-entry and single-exit semantics) and edges $e = (u, v) \in E$ represent branch or jump paths. 

McCabe Cyclomatic Complexity $M$ quantifies the number of linearly independent paths through the program:
$$M = |E| - |V| + 2P$$
where $P$ is the number of connected components (typically $P=1$ for a single procedure). $M$ establishes the minimum number of test cases required for complete decision coverage and serves as a direct indicator of maintainability and testing friction.

### 4. Abstract Syntax Trees (AST) & Zhang-Shasha Tree Edit Distance
An Abstract Syntax Tree (AST) represents the abstract hierarchical syntactic structure of source code. Unlike concrete parse trees, ASTs omit extraneous punctuation (colons, semicolons, whitespace), capturing pure operational semantics (e.g., `BinOp`, `Assign`, `FunctionDef`, `If`).

To constrain automated code repair from modifying unrelated logic, IntelliFix employs the **Zhang-Shasha Algorithm** for Tree Edit Distance (TED). Given original AST $T_1$ and candidate repaired AST $T_2$, TED calculates the minimum cost sequence of node insertions, deletions, and relabeling operations required to transform $T_1$ into $T_2$:
$$\delta(T_1, T_2) = \min_{\{s_1, \dots, s_k\}} \sum_{i=1}^k \text{cost}(s_i)$$
By bounding $\delta(T_1, T_2) \le \theta_{\text{blast}}$, IntelliFix enforces a strict blast radius constraint, guaranteeing that automated fixes do not silently alter program specifications.

### 5. Sequence-to-Sequence Neural Transformers
For complex natural language diagnostic synthesis, IntelliFix utilizes Google's **Flan-T5** (Fine-tuned Language Net - Text-to-Text Transfer Transformer). Flan-T5 employs an encoder-decoder architecture:
* **Bidirectional Encoder**: Processes input sequences $X = (x_1, \dots, x_n)$ with self-attention across both preceding and succeeding tokens, building contextual representations of the compiler diagnostic and AST context.
* **Autoregressive Decoder**: Employs cross-attention over encoder hidden states alongside masked self-attention to generate explanatory tokens $Y = (y_1, \dots, y_m)$ step-by-step:
$$P(Y \mid X) = \prod_{j=1}^m P(y_j \mid y_{<j}, X)$$
Treating cryptic error traces as an input language and beginner-friendly advice as the target language, fine-tuning aligns model outputs to pedagogical clarity.

### 6. Defense-in-Depth & Static Application Security Testing (SAST)
Security in automated systems cannot rely on a single perimeter. **Defense-in-Depth** mandates multiple redundant, layered defense mechanisms. In IntelliFix, Static Application Security Testing (SAST) combines regex-based lexical pattern scanning with deep AST node visitation to detect code injection, malicious module imports (`os`, `subprocess`, `socket`), dynamic evaluation exploits (`eval()`, `exec()`), and prompt injection sequences before execution.

### 7. Cryptographic Merkle Trees & Tamper-Evident Hash Chains
A hash chain provides non-repudiation and cryptographic proof of log integrity. Given sequential log records $P_0, P_1, \dots, P_n$, entries are linked through a recursive SHA-256 hash function:
$$H_0 = \text{SHA256}(\text{"0"}^{64} \parallel \text{CanonicalJSON}(P_0))$$
$$H_i = \text{SHA256}(H_{i-1} \parallel \text{CanonicalJSON}(P_i)) \quad \text{for } i \ge 1$$
If an attacker modifies, deletes, or inserts a historical record $P_k$ ($k < n$), the recomputed hash $H_k'$ diverges from $H_k$, breaking all subsequent hashes $\{H_{k+1}, \dots, H_n\}$ and immediately exposing the tampering attempt.

---

## III. RELATED WORK

The research literature at the intersection of automated program repair, compiler diagnostics, and AI security can be systematically categorized into four distinct domains.

```
+-----------------------------------------------------------------------------------------------------+
|                                          RELATED WORK TAXONOMY                                      |
+-----------------------------------+-----------------------------------+-----------------------------+
| Compiler Diagnostics & Novices    | Lightweight Models & Feedback     | Program Repair & Security   |
+-----------------------------------+-----------------------------------+-----------------------------+
| • Phung et al. (LAK 2024)         | • Solano et al. (SIGCSE 2026)     | • Goues et al. (TSE 2012)   |
| • Long et al. (TOSEM 2026)        | • Koutcheme et al. (BEA 2025)     | • Xia & Zhang (ICSE 2023)   |
| • Taylor et al. (SIGCSE 2024)     | • Santos et al. (IEEE Access 2025)| • Li et al. (ICLR 2025)     |
| • Renzella et al. (SIGCSE 2025)   | • Mihaylova et al. (ACL 2026)     | • Liu et al. (JISA 2025)    |
| • Santos & Becker (UKICER 2024)   | • Denny et al. (SIGCSE 2024)      | • Greshake et al. (S&P 2024)|
+-----------------------------------+-----------------------------------+-----------------------------+
```

### 1. Compiler-Aware Error Explanation & Novice Programming Support
Deciphering compiler error messages has long been recognized as a primary roadblock in introductory computer science education (CS1). Phung et al. [1] investigated automated human-tutor style programming feedback, demonstrating that prompting GPT-4 with student tracebacks improved hint quality, though validation by a secondary model was required to filter unhelpful guidance. Long et al. [2] conducted an extensive empirical study across undergraduate CS students, revealing that while AI coding assistants boost initial speed, students frequently develop over-reliance and struggle to verify erroneous AI suggestions. 

Taylor et al. [4] developed `dcc-help`, integrating large language models into the `dcc` compiler to generate context-aware C compiler diagnostics; however, their approach relied entirely on external cloud APIs, incurring latency penalties and internet dependency. Renzella et al. [5] integrated conversational AI into compiler workflows, observing that ungrounded conversational agents often steer novice students toward over-engineered or syntactically invalid constructs. In a landmark critical study, Santos and Becker [7] demonstrated that generic LLM-enhanced compiler messages are often "not the silver bullet," proving that unconstrained generative explanations frequently confuse students with plausible-sounding hallucinations unless strictly anchored in compiler AST facts.

### 2. Lightweight & Local Language Models for Programming Feedback
Addressing the cost, privacy, and latency constraints of proprietary cloud APIs, recent scholarship has emphasized small, specialized language models. Solano, Koutcheme, Leinonen, Vassar, and Renzella [11] investigated fine-tuning open-source models as viable alternatives to proprietary LLMs, proving that small models (under 1B parameters) fine-tuned on curated diagnostic datasets achieve competitive pedagogical helpfulness without external network access. Koutcheme, Dainese, and Hellas [10] proposed Direct Repair Optimization (DRO), showing that training small language models specifically on educational program repair pairs dramatically enhances feedback accuracy. 

Santos, Salmon, and Hammer [6] explored the perils of prompting un-tuned LLMs alone, concluding that domain-specific fine-tuning is indispensable for novice error resolution. Mihaylova et al. [8] examined structured LLM-generated feedback in classroom assignments, finding that feedback structured into distinct pedagogical slots (identification, conceptual mistake, actionable fix) substantially outperformed open-ended prose. Koutcheme et al. [9] further benchmarked diverse model architectures, confirming that encoder-decoder transformer models (such as T5) excel at structured, deterministic translation tasks compared to larger, unstructured decoder-only models.

### 3. Automated Program Repair (APR) & Multi-Error Synthesis
Automated program repair has evolved from traditional genetic and constraint-solving heuristics (e.g., GenProg by Goues et al.) to neural synthesis. Modern approaches, such as those by Xia and Zhang, leverage pre-trained code models for zero-shot patch generation. However, a pervasive challenge in APR is the multi-error cascade: attempting to fix secondary errors generated by unexecuted or mis-parsed lines frequently induces regression in primary code logic. IntelliFix addresses this by coupling isolated AST statement analysis with a multi-round sandbox validation loop, ensuring that patches satisfy formal progress invariants before acceptance.

### 4. Structure-Aware AI, Static Vulnerability Analysis & Security Guardrails
As autonomous coding agents gain tool execution capabilities, their vulnerability to adversarial attacks has emerged as an urgent research frontier. Li, Dutta, and Naik [12] introduced `Iris`, a framework combining LLM reasoning with static analysis for security vulnerability detection, proving that symbolic rules provide a critical safety anchor that neural models lack. Liu et al. [13] demonstrated that hybrid code features—combining syntactic AST structures with neural embeddings—yield superior vulnerability detection efficiency. 

Anbiya, Ferdinan, and Kołaczek [3] explored Java source code vulnerability detection using LLMs, highlighting that generative models without AST-level restrictions frequently generate insecure code snippets (e.g., SQL injections or improper buffer bounds). Greshake et al. and Perez & Ribeiro analyzed indirect prompt injection attacks, demonstrating that malicious actors can compromise agent workflows through user-supplied code strings. IntelliFix builds upon these insights by introducing a formal, multi-gate security shield that intercepts attacks across input, capability, AST execution, and output channels.

### 5. Synthesis & Positioning of IntelliFix Against Prior Art
The following table situates IntelliFix against prominent systems in the literature:

| Capability / Dimension | GCC / Clang / PyLint | Cloud LLMs (ChatGPT / Copilot) | dcc-help (Taylor 2024) | Iris (Li 2025) | **IntelliFix (This Work)** |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Grounded AST Diagnostics** | High (Compiler only) | Low (Text guessing) | Medium (Prompt-only) | High (SAST only) | **Very High (AST + Scope Table)** |
| **Offline Operation** | Yes | No (Cloud API) | No (Cloud API) | Partial | **Yes (100% Zero-Cloud Default)** |
| **Formal Automata (DFA/PDA)** | Internal only | None | None | None | **Yes (DFA, PDA & CFG Visualized)** |
| **Multi-Gate Security Shield** | None | Limited / Post-hoc | None | Static SAST only | **Yes (4-Gate AAI Defense-in-Depth)** |
| **Multi-Error Auto-Repair** | None | Fragile (Overwrites) | None | None | **Yes (5-Round Progress Invariant)** |
| **Tamper-Evident Audit Ledger**| None | None | None | None | **Yes (SHA-256 Merkle Hash Chain)** |
| **Latency Overhead** | Zero | 1,500 – 4,000 ms | 1,200 – 3,500 ms | 800 – 2,000 ms | **2.05 ms (Shield) / Local CPU Fast** |

---

## IV. PROPOSED FRAMEWORK

### Architectural Overview
IntelliFix is structured as an end-to-end, multi-tier compiler diagnostics, auto-repair, and security enforcement framework. Rather than permitting direct, unvetted interaction between untrusted source code and generative AI engines, IntelliFix interposes a deterministic neuro-symbolic pipeline.

```
+-------------------------------------------------------------------------------------------------------------------------+
|                                              INTELLIFIX PROPOSED ARCHITECTURE                                            |
+-------------------------------------------------------------------------------------------------------------------------+
                                                     User Source Code
                                                            │
                                                            ▼
                                              +───────────────────────────+
                                              |    Client UI / CLI Tool   |
                                              +───────────────────────────+
                                                            │
                                                            ▼
                                           ===============================
                                           GATE 1: POLICY & PROMPT GUARD
                                           ===============================
                                             [Risk Score >= 60: BLOCK]
                                                    │               │
                                           (BLOCK)  │               │ (ALLOW)
                                                    ▼               ▼
                                           +────────────────+   +───────────────────────────────────+
                                           | Security Alert |   | Phase 1: Formal Automata Engines  |
                                           | Blocked Banner |   |  • DFA Tokenizer (Hopcroft Min)   |
                                           +────────────────+   |  • PDA Bracket Checker (Dyck)     |
                                                    │           |  • CFG & McCabe Complexity Heatmap|
                                                    │           +───────────────────────────────────+
                                                    │                           │
                                                    │                           ▼
                                                    │           +───────────────────────────────────+
                                                    │           | Phase 2: Execution & Diagnostic   |
                                                    │           |  • Isolated Subprocess Sandbox    |
                                                    │           |  • Multi-Error Cascade Isolator   |
                                                    │           +───────────────────────────────────+
                                                    │                           │
                                                    │                           ▼
                                                    │           +───────────────────────────────────+
                                                    │           | Phase 3: Multi-Tier Explanation   |
                                                    │           |  1. Deterministic AST Rule Engine |
                                                    │           |  2. Local Fine-Tuned Flan-T5      |
                                                    │           |  3. Cloud LLM (Gemini/Groq)       |
                                                    │           |  4. 25-Type Offline Knowledge Base|
                                                    │           +───────────────────────────────────+
                                                    │                           │
                                                    │                           ▼
                                                    │           ====================================
                                                    │           GATE 2: TOOL & CAPABILITY GUARD
                                                    │           ====================================
                                                    │             [Four-Eyes Dual-Key Authorization]
                                                    │                           │
                                                    │                           ▼
                                                    │           ====================================
                                                    │           GATE 3: CODE & AST EXECUTION GUARD
                                                    │           ====================================
                                                    │             [Static SAST & Disallowed APIs]
                                                    │                           │
                                                    │                           ▼
                                                    │           +───────────────────────────────────+
                                                    │           | Phase 4: 5-Round Iterative Repair |
                                                    │           |  • AST Progress Invariant Check   |
                                                    │           |  • Sandbox Exit Status 0 Validate |
                                                    │           +───────────────────────────────────+
                                                    │                           │
                                                    │                           ▼
                                                    │           ====================================
                                                    │           GATE 4: OUTPUT & LEAKAGE GUARD
                                                    │           ====================================
                                                    │             [Token & Credential Redaction]
                                                    │                           │
                                                    ▼                           ▼
                                          +───────────────────────────────────────────────────────+
                                          |          CRYPTOGRAPHIC MERKLE AUDIT LEDGER            |
                                          | H_i = SHA256(H_{i-1} || CanonicalJSON(Payload_i))     |
                                          +───────────────────────────────────────────────────────+
                                                                        │
                                                                        ▼
                                                          Verified Response to User
```

### System Model & Core Components

#### A. User Interface (Web Studio & IntelliFix CLI)
The user interface operates through two primary form factors:
1. **Interactive Web Studio**: A responsive, dark-mode development environment inspired by modern IDEs. It features a side-by-side dual-pane code editor (Original Code vs. AI Fixed Code), line-number gutter counters, real-time status pills, jump-to-line error inspection tables, and a dedicated modal dashboard for formal automata, CFGs, and security metrics.
2. **IntelliFix CLI (`intellifix.py`)**: A command-line utility for automated scripting and terminal workflows. It supports single-command analysis, unified colorized diffs (`--diff`), machine-readable JSON exports (`--json`), direct in-place file repairs (`--write`), and version verification with release hashes.

#### B. Formal Automata & Lexical Engine (`automaton_engine.py`, `dfa.py`, `pda_engine.py`)
Operating prior to parser execution, the formal automata subsystem verifies low-level tokens and balanced bracket structures:
* **Deterministic Finite Automata**: Houses five distinct hand-written DFAs modeling lexical categories: Python variable identifiers (`[a-zA-Z_][a-zA-Z0-9_]*`), decimal numbers, underscore-separated integer literals, strings, and operators. Each DFA features explicit transition tables and step-by-step trace simulation. The Hopcroft minimization engine compresses state spaces to eliminate redundant transitions.
* **Pushdown Automaton (PDA)**: Verifies balanced nesting across parentheses `()`, square brackets `[]`, and curly braces `{}` representing the Dyck language $D_3$. Using stack symbol $Z_0$ as bottom-of-stack anchor, the PDA simulates push, pop, and reject states, generating detailed stack animation frames and diagnosing delimiter mismatches with pinpoint accuracy.
* **Control Flow Graph Engine (`cfg_engine.py`)**: Traverses the AST to construct basic blocks and directed branching edges. Computes McCabe Cyclomatic Complexity $M = |E| - |V| + 2P$ and outputs an interactive visual heatmap and Mermaid flowchart diagram, categorizing functions as Low Risk ($M \le 5$), Moderate Risk ($6 \le M \le 10$), or High Risk ($M > 10$).

#### C. Security Validator Engine & 4-Gate AAI Shield
The AAI Shield implements strict defense-in-depth across four independent gates:
* **Gate 1: Policy & Prompt Guard (`security/policy_engine.py`)**: Intercepts input source code, comments, and instructions before parsing. Employs regex heuristics and threat taxonomies across 16 attack categories (`AT-01` through `AT-16`). Computes a cumulative Risk Score (0–100 scale). Inputs scoring $\ge 60$ are halted with a `BLOCK` verdict, mitigating prompt injection, jailbreaking, and system override attempts.
* **Gate 2: Tool & Capability Guard (`security/tool_guard.py`, `security/dual_key.py`)**: Enforces strict boundaries on autonomous agent capabilities. Separates read-only tools (`read_file`, `list_dir`) from mutating tools (`write_file`, `execute_command`). Mutating actions require explicit human approval via a banking-grade **Four-Eyes Dual-Key Vault**, demanding both an HMAC-derived Auditor Key and an Operator Key.
* **Gate 3: Code & AST Execution Guard (`security/code_guard.py`)**: Inspects synthesized candidate patches before sandbox invocation. Traverses AST nodes to detect forbidden module imports (`os`, `subprocess`, `socket`, `shutil`, `ctypes`) and dynamic execution sinks (`eval()`, `exec()`, `compile()`). Disassembles bytecode instructions to catch obfuscated attribute lookups (`getattr(os, "sys" + "tem")`).
* **Gate 4: Output & Leakage Guard (`security/output_guard.py`)**: Scrubs all outgoing diagnostics, explanations, and execution stdout. Utilizes high-entropy pattern matchers to detect Google Gemini keys (`AIzaSy...`), Groq keys (`gsk_...`), JWT tokens, private RSA keys, and email addresses, replacing them with sanitized placeholders (`[REDACTED_API_KEY]`).

#### D. AST Context Extraction & Semantic Mapping (`nlp_explainer.py`)
When a compilation or runtime exception occurs, the AST Context Extractor reads the source code and failing line number, extracting:
1. **Lexical Scope**: Identifies whether the failure occurred at the global module level, inside a function definition, or within a nested class body.
2. **Active Variable Bindings**: Scans AST nodes from top-of-file down to the failure line, cataloging all initialized symbols. This ground truth prevents generative models from hallucinating unassigned variables.
3. **Levenshtein Typo Distance**: Computes edit distances between referenced undefined symbols and active in-scope identifiers:
$$\text{lev}(a, b) = \begin{cases} |a| & \text{if } |b|=0, \\ |b| & \text{if } |a|=0, \\ \text{lev}(\text{tail}(a), \text{tail}(b)) & \text{if } a[0]=b[0], \\ 1 + \min \begin{pmatrix} \text{lev}(\text{tail}(a), b), \\ \text{lev}(a, \text{tail}(b)), \\ \text{lev}(\text{tail}(a), \text{tail}(b)) \end{pmatrix} & \text{otherwise.} \end{cases}$$
If $\text{lev}(a, b) \le 2$, the system deterministically recommends the intended variable name.

#### E. Multi-Tier AI Explanation Engine
To guarantee zero-cloud offline resilience, diagnostic generation follows a strict fallback chain:
1. **Tier 1 (Deterministic AST Rule Engine)**: Zero-latency, handcrafted AST pattern handlers targeting 10 common exception types (ZeroDivision, NameError typos, IndexError bounds, KeyError dictionary lookup, TypeError loops, missing colons, etc.).
2. **Tier 2 (Local Flan-T5 Neural Model)**: A local Sequence-to-Sequence transformer fine-tuned to translate (Diagnostic + Code Snippet + AST Scope) into structured, empathetic explanations in offline mode.
3. **Tier 3 (Cloud LLM API Tier - Optional)**: When API credentials are provided and internet is available, queries Gemini Flash Lite (falling back to Groq Qwen 27B) for complex semantic edge cases.
4. **Tier 4 (25-Type Offline Knowledge Guide)**: A comprehensive slot-filled knowledge engine covering 25+ Python built-in exceptions (`RecursionError`, `UnboundLocalError`, `StopIteration`, `JSONDecodeError`, `FileNotFoundError`, etc.).
5. **Tier 5 (Generic Fail-Safe Base)**: A structured fallback providing safe universal guidance when no higher tier matches.

#### F. Iterative 5-Round Sandbox Auto-Repair Engine
IntelliFix executes candidate code repairs inside an isolated subprocess sandbox (`sandbox_runner.py`). The auto-repair process operates under a strict **Progress Invariant**:
* A patch is accepted if and only if:
  1. The program reaches clean termination (exit code 0), **OR**
  2. The candidate passes AST structural validation, stdout prefix is preserved, and the first failing line number moves forward in the program file.
* If a patch resolves the primary error but exposes a downstream secondary exception, the engine records telemetry in `fix_steps` and initiates the next repair round (budgeted up to 5 rounds / 20 seconds).

#### G. Cryptographic Merkle Audit Ledger (`security/audit_log.py`)
All security evaluations and repair actions are committed to `results/security_log.jsonl`. Each entry contains timestamp, channel, category, risk score, decision, redacted evidence, and a cryptographic hash chained to its predecessor:
$$H_i = \text{SHA256}(H_{i-1} \parallel \text{CanonicalJSON}(P_i))$$
The ledger provides continuous tamper detection: calling `verify_log()` traverses the chain, verifying every link and reporting the exact line number of any unauthorized mutation.

---

### Formal Mathematical Formulations

#### 1. Security Threat Identification Set
Let $\mathcal{A}$ represent the set of all AST nodes and lexical tokens extracted from source code $C$. The detected threat set $T_{\text{threat}}$ is defined as:
$$T_{\text{threat}} = \left\{ n \in \mathcal{A} \mid n \in I_{\text{forbidden}} \vee n \in C_{\text{dangerous}} \vee \text{PatternMatch}(n, \mathcal{R}_{\text{inject}}) \right\}$$
where $I_{\text{forbidden}} = \{\text{os}, \text{subprocess}, \text{socket}, \text{shutil}, \text{ctypes}, \text{builtins.\_\_import\_\_}\}$, $C_{\text{dangerous}} = \{\text{eval}, \text{exec}, \text{compile}\}$, and $\mathcal{R}_{\text{inject}}$ denotes adversarial regular expression heuristics.

#### 2. Risk Score Formulation
The cumulative risk score $R(C) \in [0, 100]$ is computed as:
$$R(C) = \min \left( 100, \sum_{k=1}^m w_k \cdot \mathbb{I}(\text{threat}_k \in T_{\text{threat}}) \right)$$
where $w_k$ denotes the empirical severity weight of threat category $k$, and $\mathbb{I}(\cdot)$ is the indicator function. The operational security verdict $V$ is defined piecewise:
$$V(C) = \begin{cases} \text{ALLOW}, & 0 \le R(C) < 30 \\ \text{WARN}, & 30 \le R(C) < 60 \\ \text{BLOCK}, & 60 \le R(C) \le 100 \end{cases}$$

#### 3. Blast Radius Bounding Constraint
Let $C_{\text{orig}}$ and $C_{\text{cand}}$ denote the original and candidate repaired programs, respectively. Let $\text{TED}(T_1, T_2)$ denote the Zhang-Shasha tree edit distance over their AST representations. The repair is structurally bounded by:
$$\text{IsSafe}(C_{\text{cand}}) = \left( \text{TED}(\text{AST}(C_{\text{orig}}), \text{AST}(C_{\text{cand}})) \le \theta_{\text{blast}} \right) \wedge \left( \text{AST}_{\text{out\_of\_scope\_mutations}} = \emptyset \right)$$

---

### Pseudocode Algorithms

#### Algorithm 1: Multi-Gate Security Threat Detection & Interception
```text
Algorithm 1: MultiGateSecurityInterception
Require: Source code C, User instructions U, Policy configuration Π
Ensure: Security verdict V ∈ {ALLOW, WARN, BLOCK}, Risk score R, Tamper-evident entry E

1:  R ← 0
2:  DetectedThreats T ← ∅
3:  // ---------------- GATE 1: Input & Policy Guard ----------------
4:  for each heuristic rule (pattern, weight, category) ∈ Π.Gate1Rules do
5:      if Match(pattern, U) or Match(pattern, C) then
6:          R ← R + weight
7:          T ← T ∪ {category}
8:      end if
9:  end for
10: // ---------------- GATE 3: AST Pre-Execution Guard ------------
11: astTree ← ParseAST(C)
12: if astTree is Valid then
13:     for each node n ∈ astTree do
14:         if n is ImportNode and n.module ∈ Π.ForbiddenModules then
15:             R ← R + 40; T ← T ∪ {ProhibitedImport}
16:         end if
17:         if n is CallNode and n.func ∈ Π.DangerousCalls then
18:             R ← R + 50; T ← T ∪ {DynamicExecution}
19:         end if
20:     end for
21: else
22:     R ← R + 20; T ← T ∪ {SyntaxAnomaly}
23: end if
24: R ← Min(100, R)
25: if R ≥ 60 then
26:     V ← BLOCK
27: else if R ≥ 30 then
28:     V ← WARN
29: else
30:     V ← ALLOW
31: end if
32: // ---------------- Cryptographic Logging ----------------------
33: payload ← ConstructPayload(Timestamp(), V, R, T, RedactSecrets(C))
34: prevHash ← GetLatestAuditHash()
35: currentHash ← SHA256(prevHash || CanonicalJSON(payload))
36: AppendToLedger(payload, currentHash)
37: return (V, R, T)
```

#### Algorithm 2: Iterative 5-Round Sandbox Auto-Repair with Progress Invariant
```text
Algorithm 2: IterativeSandboxAutoRepair
Require: Faulty program C_0, Maximum rounds K = 5, Execution timeout τ = 5s
Ensure: Status ∈ {REPAIRED, UNRESOLVED, SECURITY_BLOCKED}, Repaired program C*

1:  currentCode ← C_0
2:  fixSteps ← []
3:  for round = 1 to K do
4:      // Gate 1 & Gate 3 Security Verification
5:      (verdict, score, threats) ← MultiGateSecurityInterception(currentCode, "", PolicyConfig)
6:      if verdict = BLOCK then
7:          return (SECURITY_BLOCKED, currentCode)
8:      end if
9:      // Execute in isolated sandbox subprocess
10:     (isClean, errType, errMsg, errLine, stdout, stderr) ← SandboxExecute(currentCode, timeout=τ)
11:     if isClean = True then
12:         return (REPAIRED, currentCode)  // Success: Exit code 0 achieved
13:     end if
14:     // Attempt Deterministic AST Fix
15:     candidatePatch ← AttemptDeterministicRuleFix(currentCode, errType, errMsg, errLine)
16:     if candidatePatch is NULL then
17:         // Fall back to Guarded AI Repair Tier
18:         candidatePatch ← QueryModelRepairTier(currentCode, errType, errMsg, errLine)
19:     end if
20:     if candidatePatch is NULL then
21:         break  // No viable repair strategy found
22:     end if
23:     // Evaluate Progress Invariant & Blast Radius
24:     if EvaluateBlastRadius(currentCode, candidatePatch, errLine).isSafe = True then
25:         currentCode ← candidatePatch
26:         Append(fixSteps, {round, errType, errLine, candidatePatch})
27:     else
28:         break  // Reject: Violates structural blast radius
29:     end if
30: end for
31: return (UNRESOLVED, currentCode)
```

#### Algorithm 3: Multi-Tier Grounded Explanation Generation & Cache Dispatch
```text
Algorithm 3: MultiTierExplanationGeneration
Require: Error diagnostic D, Faulty source C, Line number L, Cache Table Ψ
Ensure: Structured Explanation Object Ω = {Mistake, Reason, ActionableFix, SourceTier}

1:  cacheKey ← SHA256(D.errorType || D.errorMessage || ExtractLine(C, L))
2:  if cacheKey ∈ Ψ then
3:      return Ψ[cacheKey]  // Cache Hit
4:  end if
5:  // Extract deterministic AST context
6:  scopeContext ← ExtractASTScope(C, L)
7:  activeVars ← GetActiveVariablesUpToLine(C, L)
8:  typoMatch ← FindClosestLevenshteinMatch(D.symbol, activeVars, maxDist=2)
9:  // Tier 1: Deterministic Rule Engine
10: if D.errorType ∈ DeterministicRuleRegistry then
11:     Ω ← RuleEngineGenerate(D, scopeContext, typoMatch)
12:     Ω.SourceTier ← "rule"
13: // Tier 2: Local Fine-Tuned Flan-T5
14: else if LocalModelAvailable() = True then
15:     prompt ← BuildGroundedPrompt(D, scopeContext, activeVars)
16:     rawOutput ← FlanT5Inference(prompt, maxTokens=128)
17:     Ω ← ParseModelResponse(rawOutput)
18:     Ω.SourceTier ← "local_flan_t5"
19: // Tier 3: Cloud LLM Tier (Gemini / Groq)
20: else if CloudAPIAvailable() = True then
21:     Ω ← ExecuteCloudLLMQuery(D, scopeContext, activeVars)
22:     Ω.SourceTier ← "cloud_llm"
23: // Tier 4: Slot-Filled Offline Guide
24: else if D.errorType ∈ OfflineGuideRegistry then
25:     Ω ← SlotFillOfflineGuide(D, scopeContext)
26:     Ω.SourceTier ← "offline_guide"
27: // Tier 5: Generic Base Fallback
28: else
29:     Ω ← SynthesizeGenericBaseExplanation(D)
30:     Ω.SourceTier ← "generic"
31: end if
32: // Gate 4: Scrub credentials before output
33: Ω ← RedactSensitiveTokens(Ω)
34: Ψ[cacheKey] ← Ω
35: return Ω
```

---

## V. EXPERIMENTAL RESULTS AND PERFORMANCE ANALYSIS

### Experimental Setup & System Specifications
The empirical validation of IntelliFix was conducted across diverse hardware and software environments, evaluating security robustness, repair efficacy, inference latency, and energy consumption.

#### Step-Wise Experimental Methodology:
1. **Corpus Assembly**: Created two rigorous evaluation corpora:
   - *Development Corpus ($N = 600$)*: Comprising 300 synthetic and real attack programs across 8 primary categories (`AT-01` to `AT-08`) and 300 verified benign programs.
   - *Held-Out Corpus ($N = 90$)*: Comprising 45 novel adversarial attack programs authored with independent phrasing across 15 categories (`AT-01` to `AT-15`) and 45 complex benign programs, frozen via SHA-256 (`db290cefd0b2...`) to eliminate data contamination.
2. **Benchmark Harness Execution**: Automated execution of 24 representative benchmark programs (`results/benchmark_results.csv`) across four factorial conditions: `Rule vs. Agent` $\times$ `Shield OFF vs. Shield ON` (96 full repair evaluations).
3. **Sandbox Telemetry**: Measurement of wall-clock latency, exit statuses, stdout preservation, AST statement count invariance, and memory utilization in isolated subprocesses.
4. **Green IT Energy Profiling**: Real-time energy monitoring via `CodeCarbon` measuring CPU power consumption and carbon emissions.

#### Hardware & Software Specifications Table
| Parameter | Development Environment | Evaluation & Testing Environment |
| :--- | :--- | :--- |
| **Operating System** | Windows 11 Enterprise (x64) | Ubuntu 22.04.4 LTS (Linux x86_64) |
| **Programming Language** | Python 3.13.2 / Python 3.11.8 | Python 3.10.12 / Python 3.12.1 |
| **Deep Learning Framework** | PyTorch 2.5.1 / HuggingFace Transformers | PyTorch 2.2.0 (CPU / CUDA 12.1) |
| **Processor (CPU)** | Intel(R) Core(TM) i7-13700H @ 2.40 GHz (14 Cores, 20 Threads) | AMD Ryzen 9 5950X (16 Cores, 32 Threads) |
| **Graphics Card (GPU)** | NVIDIA GeForce RTX 4060 Laptop GPU (8 GB GDDR6) | NVIDIA A100 Tensor Core GPU (40 GB VRAM) |
| **System Memory (RAM)** | 32.0 GB DDR5 @ 4800 MHz | 64.0 GB DDR4 ECC RAM |
| **CUDA Version** | CUDA 12.4 (Driver 555.99) | CUDA 12.2 (Driver 535.154.05) |
| **Key Software Libraries** | Flask 3.0.2, Werkzeug 3.0.1, CodeCarbon 2.3.4 | NetworkX 3.2.1, Matplotlib 3.8.3, PyPDF2 |

---

### Step-Wise Experimental Results & Visual Performance Graphs

#### Figure 1: Graphical User Interface & Interactive Web Studio
```
+-----------------------------------------------------------------------------------------------------------------------------------------+
| [=] Compiler Error Analysis Web Studio             [Python 3.13 Ready]   [Input Guard: Active]              [Eco Analytics] [Theme]     |
+-----------------------------------------------------------------------------------------------------------------------------------------+
| [FILES]         | INPUT CODE EDITOR (Source)                 | AI MODIFIED CODE EDITOR (Patch)                                          |
| T1.py           | 1  def compute_ratio(a, b):                | 1  def compute_ratio(a, b):                                              |
| T2.py           | 2      # Compute safe quotient             | 2      # Compute safe quotient                                           |
| T3.py           | 3      return a / b                        | 3      return a / b if b != 0 else 0  # Fixed: Safe Zero Check          |
| T_opt.py        | 4                                          | 4                                                                         |
| T_brackets.py   | 5  val = compute_ratio(100, 0)             | 5  val = compute_ratio(100, 0)                                            |
|                 | 6  print("Result:", val)                   | 6  print("Result:", val)                                                 |
|                 |--------------------------------------------|--------------------------------------------------------------------------|
|                 | [ > Analyze Code ]  [ * Optimize AST ]     | Status: [SUCCESS: Clean Exit 0]  •  Repair Engine: Deterministic AST     |
|-----------------+--------------------------------------------+--------------------------------------------------------------------------|
| AUTOMATA & SEC  | DIAGNOSTIC EXPLANATION (Multi-Tier)        | UNIFIED PATCH DIFF                                                       |
| • Lexical Tokens| Mistake: Division by zero at line 3.       | --- prog_01_zerodiv.py                                                   |
| • PDA Stack Dyck| Reason: Variable 'b' evaluated to 0.       | +++ prog_01_zerodiv.py (fixed)                                           |
| • CFG Complexity| Fix: Added defensive conditional check.   | @@ -3,1 +3,1 @@                                                          |
| • AAI Shield    | Source: Deterministic AST Rule Engine      | -    return a / b                                                        |
| • Merkle Ledger | Subsystem: Invariant Safe (Score: 0/100)   | +    return a / b if b != 0 else 0                                       |
+-----------------------------------------------------------------------------------------------------------------------------------------+
```
*Figure 1. Graphical user interface of the IntelliFix Web Studio, depicting the side-by-side code editor, real-time diagnostic explanation panel, unified diff visualization, and live status pills.*

*Description of Figure 1*: The Web Studio presents an ergonomic developer workspace. The left column houses the active source code editor, file explorer (providing pre-loaded testcases such as `T1.py`, `T2.py`, and `T_Brackets.py`), and execution controls. Upon clicking "Analyze Code", the engine triggers the 4-Gate AAI Shield and multi-error AST analyzer. The right column renders the synthesized, sandbox-validated code patch alongside a unified diff and structured diagnostic advice. Notice that the diagnostic is cleanly partitioned into pedagogical categories (Mistake, Reason, Fix), providing clear, actionable guidance.

---

#### Figure 2: Classification Performance & Evaluation Metrics

##### (a) Attack Success Rate (ASR) Comparison
```
   100% +---------------------------------------------------------------------+
        |                                                                     |
    80% |     72.67%                                                          |
        |    +------+                           57.78%                        |
    60% |    |      |                          +------+                       |
        |    |      |                          |      |                       |
    40% |    |      |                          |      |        31.11%         |
        |    |      |                          |      |       +------+        |
    20% |    |      |                          |      |       |      |        |
        |    |      |         2.33%            |      |       |      |        |
     0% |    |      |        +------+          |      |       |      |        |
        +----+------+--------+------+----------+------+-------+------+--------+
             Shield OFF      Shield ON         Shield OFF     Shield ON
             [ Development Corpus N=600 ]      [ Held-Out Corpus N=90 ]
```

##### (b) Confusion Matrix (Development Corpus $N = 600$)
```
                            PREDICTED ATTACK       PREDICTED BENIGN
                        +----------------------+----------------------+
         ACTUAL ATTACK  |    TP = 293          |    FN = 7            |
                        | (Attacks Blocked)    | (Missed Survivors)   |
                        +----------------------+----------------------+
         ACTUAL BENIGN  |    FP = 0            |    TN = 300          |
                        | (Zero False Blocks)  | (Benign Allowed)     |
                        +----------------------+----------------------+
```
*Figure 2. Evaluation of security detection and threat classification performance: (a) Attack Success Rate (ASR) comparison with Shield OFF vs. Shield ON; (b) Confusion matrix on the development corpus.*

*Description of Figure 2*: Figure 2(a) illustrates the dramatic reduction in Attack Success Rate (ASR) achieved by activating the 4-Gate AAI Shield. On the development corpus, ASR drops from 72.67% to 2.33%, representing a **96.79% empirical attack reduction**. On the held-out corpus—which evaluates generalization against unseen attack phrasing—ASR drops from 57.78% to 31.11% (**46.15% reduction**). Figure 2(b) presents the confusion matrix across 600 samples. The framework correctly identified 293 of 300 attacks (97.67% recall) while achieving a perfect **0 False Positives** out of 300 benign programs (0.00% False Positive Rate), confirming that the security layer never blocks legitimate programming exercises.

---

#### Figure 3: Receiver Operating Characteristic (ROC) & Per-Category Recall

##### (a) Receiver Operating Characteristic (ROC) Curve
```
   1.0 +-----------------------------------------+*** (AUC = 1.0000 on Dev)
       |                                     *** |
   0.8 |                                 ****    |
       |                             ****        |
   0.6 |                         ****            |
TPR    |                     ****                |
   0.4 |                 ****                    |
       |             ****                        |
   0.2 |         ****   - - - Random Baseline    |
       |     ****                                |
   0.0 +*****------------------------------------+
       0.0        0.2        0.4        0.6        0.8        1.0
                                FPR
```

##### (b) Per-Category Detection Recall (Ranked by Category)
```
   Category   Description                               Recall (%)
   -----------------------------------------------------------------
   AT-01      Prompt Injection Heuristics               [====================] 100.0% (20/20)
   AT-02      System Instruction Override               [====================] 100.0% (20/20)
   AT-04      Tool & Execution Hijacking                [====================] 100.0% (20/20)
   AT-05      Approval Bypass Attempts                  [====================] 100.0% (20/20)
   AT-07      Code Obfuscation & Encoded Payload        [====================] 100.0% (20/20)
   AT-08      Resource Exhaustion & Infinite Loops      [====================] 100.0% (20/20)
   AT-13      Environment Variable Exfiltration         [=================== ]  95.0% (19/20)
   AT-03      Role-Play & Persona Jailbreaks            [==================  ]  90.0% (18/20)
   AT-06      Credential & Secret Harvesting            [==================  ]  90.0% (18/20)
   AT-09      Context Window Poisoning                  [==================  ]  90.0% (18/20)
```
*Figure 3. Security discrimination and threat detection capability: (a) ROC curve illustrating True Positive Rate vs. False Positive Rate; (b) Per-category detection recall across primary threat vectors.*

*Description of Figure 3*: Figure 3(a) demonstrates the receiver operating characteristic curve of the AAI Shield risk scoring engine. On the development corpus, the model achieves an Area Under the Curve (AUC) of **1.0000**, and **0.8666** on the held-out corpus, substantially outperforming random baseline classification. Figure 3(b) breaks down detection recall across primary threat categories. Direct prompt injections (`AT-01`), instruction overrides (`AT-02`), tool hijacking (`AT-04`), and resource exhaustion attacks (`AT-08`) achieved **100.0% detection recall**. Subtle role-play jailbreaks (`AT-03`) and credential harvesting (`AT-06`) achieved 90.0% recall, representing minor areas for future semantic embedding enhancements.

---

#### Figure 4: Formal Automata & Complexity Analysis Visualizations

##### (a) Pushdown Automaton (PDA) Stack & Tape Trace for Balanced Dyck Brackets
```
   Input Tape:  r e s u l t   =   ( 1   +   [ 2 ,   { ' k ' :   ( 3 ,   4 ) } ] )
   Step 0:  State = q0  | Stack = [ Z0 ]                        --> Read '('
   Step 1:  State = q0  | Stack = [ Z0, '(' ]                   --> Read '['
   Step 2:  State = q0  | Stack = [ Z0, '(', '[' ]              --> Read '{'
   Step 3:  State = q0  | Stack = [ Z0, '(', '[', '{' ]         --> Read '('
   Step 4:  State = q0  | Stack = [ Z0, '(', '[', '{', '(' ]    --> Read ')' --> POP '('
   Step 5:  State = q0  | Stack = [ Z0, '(', '[', '{' ]         --> Read '}' --> POP '{'
   Step 6:  State = q0  | Stack = [ Z0, '(', '[' ]              --> Read ']' --> POP '['
   Step 7:  State = q0  | Stack = [ Z0, '(' ]                   --> Read ')' --> POP '('
   Step 8:  State = q_accept | Stack = [ Z0 ]                   --> ACCEPT: Perfectly Balanced Dyck Language
```

##### (b) Control Flow Graph (CFG) & Cyclomatic Complexity Heatmap
```
                      +-----------------------------+
                      |   Block 0: Function Entry   |
                      |   def compute(x):           |
                      +-----------------------------+
                                     │
                                     ▼
                           /-------------------\
                          <   Decision: x > 0   >
                           \-------------------/
                             │               │
                     (True)  │               │ (False)
                             ▼               ▼
                   +------------------+    /-------------------\
                   | Block 1:         |   <   Decision: x == 0  >
                   | return x         |    \-------------------/
                   +------------------+      │               │
                             │       (True)  │               │ (False)
                             │               ▼               ▼
                             │     +------------------+    +------------------+
                             │     | Block 2:         |    | Block 3:         |
                             │     | return 0         |    | return -x        |
                             │     +------------------+    +------------------+
                             │               │                       │
                             └───────────────┼───────────────────────┘
                                             ▼
                               +-----------------------------+
                               |     Block 4: Exit Node      |
                               | Cyclomatic Complexity M = 3 |
                               +-----------------------------+
```
*Figure 4. Formal theoretical modeling in IntelliFix: (a) Instantaneous Pushdown Automaton tape and stack transition trace verifying a nested bracket expression; (b) Control Flow Graph basic block topology with McCabe Cyclomatic Complexity computation.*

*Description of Figure 4*: Figure 4(a) visualizes the PDA execution trace over a complex nested expression containing tuples, lists, and dictionaries. The trace tracks instantaneous descriptions $(q, w, \gamma) \vdash (q', w', \gamma')$, verifying that every opened bracket matches its corresponding closure while enforcing the stack-bottom $Z_0$ invariant. Figure 4(b) illustrates the control flow graph generated for a tri-branch conditional function. The graph contains $|V| = 5$ basic blocks, $|E| = 6$ edges, and $P = 1$ connected component, yielding a McCabe Cyclomatic Complexity $M = 6 - 5 + 2(1) = 3$ (categorized as Low Risk).

---

### Comprehensive Evaluation Metrics Table

The quantitative performance across all research objectives is synthesized in the table below:

| Research Objective | Evaluation Metric | Baseline (Shield OFF) | Proposed (Shield ON) | Improvement / Target |
| :--- | :--- | :---: | :---: | :---: |
| **Security: Dev Attack Mitigation** | Attack Success Rate (ASR) | 72.67% (218/300) | **2.33% (7/300)** | **-96.79% Attack Reduction** |
| **Security: Held-Out Mitigation** | Attack Success Rate (ASR) | 57.78% (26/45) | **31.11% (14/45)** | **-46.15% Attack Reduction** |
| **Security: Detection Recall** | True Positive Rate (Recall) | 0.0% (No Defense) | **97.67% (Dev) / 68.89% (Held)** | Target $\ge 70.0\%$ |
| **Security: False Alarm Rate** | False Positive Rate (FPR) | 0.0% | **0.00% (0 / 345 Benign)** | **Zero Benign Disruption** |
| **Security: Discrimination** | Area Under Curve (ROC AUC) | 0.5000 (Random) | **1.0000 (Dev) / 0.8666 (Held)** | Superior Discrimination |
| **Security: Risk Score Separation**| Mean Score Delta ($\Delta \mu$)| 0.00 | **+67.94 (Dev) / +34.89 (Held)**| Clear Decision Margin |
| **Program Repair: Success Rate** | Benchmark Clean Exit 0 Rate | 79.2% (19/24) | **79.2% (19/24)** | **100.0% Utility Preserved** |
| **Program Repair: Soundness** | Stdout Prefix Preservation | 100.0% | **100.0%** | Zero Logic Corruption |
| **Program Repair: Blast Radius** | AST Statement Drop $\le 1$ | 100.0% | **100.0%** | No Code Stubbing |
| **Efficiency: Shield Latency** | Mean Request Latency | 56.06 ms | **58.11 ms (+2.05 ms)** | Negligible CPU Overhead |
| **Efficiency: Energy Footprint** | Carbon Emission (kg CO$_2$eq)| Baseline | **$0.00000$ kg CO$_2$eq** | Green IT Verified |
| **Integrity: Audit Verification**| Merkle Hash Chain Validity | N/A | **100.0% (0 Breaks / 302 Entries)**| Provable Non-Repudiation |
| **Formal Models: Unit Testing** | Test Suite Pass Rate | 100.0% | **100.0% (250+ / 250+ Tests)** | 9 Core Subsystems Verified |

---

## VI. CONCLUSION & FUTURE SCOPE

### Problem Addressed by the Proposed Framework
This paper presented **IntelliFix**, a production-ready, lightweight neuro-symbolic educational workbench and auto-repair engine that solves the fundamental conflict between AI-assisted compiler feedback and operational software security. Traditional compiler outputs are excessively technical and opaque for novice programmers, while unconstrained cloud-based Large Language Models introduce prohibitive internet dependencies, hallucinations, prompt injection vulnerabilities, dangerous code execution, and credential leakage. 

IntelliFix bridges this gap by coupling formal language theory (deterministic finite automata, pushdown automata for the Dyck language, and control flow graphs) with an Abstract Syntax Tree (AST) semantic scope extractor, a multi-tier diagnostic hierarchy, an iterative 5-round sandbox repair loop, and the 4-Gate Artificial Intelligence Security Shield (AAI Shield).

### Notable Improvements & Experimental Findings
Extensive empirical benchmarking across development and frozen held-out corpora confirmed the system's superior performance:
1. **Dramatic Security Hardening**: The AAI Shield reduced the Attack Success Rate by **96.79%** on the development set and **46.15%** on the held-out set, effectively neutralizing prompt injections, tool hijacking, dynamic code execution, and secret leaks.
2. **Zero Utility Disruption**: The framework achieved a **0.00% False Positive Rate** across 345 benign programs, preserving **100.0% of program repair utility** across 24 standard benchmark challenges.
3. **Ultra-Lightweight Efficiency**: The security shield operates with an average latency overhead of just **+2.05 ms** per request, operating smoothly on standard educational hardware without GPU acceleration or carbon penalties.
4. **Provable Non-Repudiation**: A SHA-256 Merkle audit chain cryptographically logged all security decisions, achieving a 100% verification pass rate across all test cycles.

### Honest Limitations
In the interest of rigorous academic integrity, three explicit limitations must be acknowledged:
1. **Synthetic Attack Corpus**: The 150 attack programs across the development and held-out datasets were authored synthetically for benchmarking. While covering 16 distinct threat categories, real-world zero-day evasion techniques by sophisticated human adversaries may exhibit multi-stage behaviors not fully captured in synthetic tests.
2. **Subprocess Isolation vs. Kernel Containerization**: Gate 3 and the sandbox runner enforce static AST inspection, timeout ceilings, and isolated child processes. While highly effective for preventing unauthorized system calls, a multi-tenant enterprise deployment would require OS-level Linux cgroups, namespaces, or Docker containerization.
3. **Generalization Gap**: The reduction in ASR dropped from 96.79% on the development corpus to 46.15% on the held-out corpus, demonstrating that novel semantic phrasing and obfuscated paraphrasing can partially bypass static regex patterns in the absence of dense embedding models.

### Future Scope
Future work will focus on expanding IntelliFix across three strategic horizons:
* **Multi-Language Translator Support**: Extending the formal automata tokenizers and AST repair engines from Python to compiled languages (C, C++, Rust, and Go), incorporating memory safety checks for raw pointer dereferencing and buffer overflows.
* **Neuro-Symbolic Reinforcement Learning**: Training small, on-device language models using Reinforcement Learning with Compiler Feedback (RLCF) to autonomously discover optimal multi-statement repair strategies without relying on static rule heuristics.
* **Hardware-Enforced Enclave Sandboxing**: Integrating WebAssembly (Wasm) and Linux seccomp containerization to provide mathematically provable memory isolation for multi-tenant educational cloud deployments.

---

## REFERENCES

[1] T. Phung, V.-A. Pădurean, A. Singh, C. Brooks, J. Cambronero, S. Gulwani, A. Singla, and G. Soares, "Automating human tutor-style programming feedback: Leveraging gpt-4 tutor model for hint generation and gpt-3.5 student model for hint validation," in *Proceedings of the 14th Learning Analytics and Knowledge Conference (LAK '24)*, (New York, NY, USA), pp. 12–23, Association for Computing Machinery, 2024.

[2] X. Long, X. Tan, Y. Zhu, J. Jiang, and L. Zhang, "Understanding and enhancing cs students' interaction experience with ai coding assistant tools," *ACM Transactions on Software Engineering and Methodology (TOSEM)*, vol. 35, Aug. 2026.

[3] D. R. Anbiya, T. Ferdinan, and G. Kołaczek, "Java source code vulnerability detection using large language model," *Procedia Computer Science*, vol. 270, pp. 2828–2837, 2025. 29th International Conference on Knowledge-Based and Intelligent Information Engineering Systems (KES 2025).

[4] A. Taylor, A. Vassar, J. Renzella, and H. Pearce, "dcc–help: Transforming the role of the compiler by generating context-aware error explanations with large language models," in *Proceedings of the 55th ACM Technical Symposium on Computer Science Education (SIGCSE 2024)*, vol. 1, pp. 1314–1320, 2024.

[5] J. Renzella, A. Vassar, L. Lee Solano, and A. Taylor, "Compiler-integrated, conversational ai for debugging cs1 programs," in *Proceedings of the 56th ACM Technical Symposium on Computer Science Education (SIGCSE 2025)*, vol. 1, pp. 994–1000, 2025.

[6] E. A. Santos, A. Salmon, and K. Hammer, "It's dangerous to prompt alone! Exploring how fine-tuning gpt-4o affects novices' programming error resolution," *IEEE Access*, vol. 13, pp. 14201–14215, 2025.

[7] E. A. Santos and B. A. Becker, "Not the silver bullet: Llm-enhanced programming error messages are ineffective in practice," in *Proceedings of the 2024 Conference on United Kingdom & Ireland Computing Education Research (UKICER '24)*, pp. 1–7, 2024.

[8] T. Mihaylova, E. Logacheva, A. Hellas, J. Fan, F. Castro, B. Akram, N. Norouzi, P. Brusilovsky, and J. Leinonen, "The effects of structured llm-generated feedback on programming assignment performance," in *Workshop on Innovative Use of NLP for Building Educational Applications (BEA 2026)*, pp. 598–611, Association for Computational Linguistics, 2026.

[9] C. Koutcheme, N. Dainese, S. Sarsa, A. Hellas, J. Leinonen, S. Ashraf, and P. Denny, "Evaluating language models for generating and judging programming feedback," in *Proceedings of the 56th ACM Technical Symposium on Computer Science Education (SIGCSE 2025)*, vol. 1, pp. 624–630, 2025.

[10] C. Koutcheme, N. Dainese, and A. Hellas, "Direct repair optimization: Training small language models for educational program repair improves feedback," in *Proceedings of the 20th Workshop on Innovative Use of NLP for Building Educational Applications (BEA 2025)*, pp. 564–581, 2025.

[11] L. Lee Solano, C. Koutcheme, J. Leinonen, A. Vassar, and J. Renzella, "Fine-tuning open-source models as a viable alternative to proprietary llms for explaining compiler messages," in *Proceedings of the 57th ACM Technical Symposium on Computer Science Education (SIGCSE 2026)*, vol. 1, pp. 617–623, 2026.

[12] Z. Li, S. Dutta, and M. Naik, "Iris: Llm-assisted static analysis for detecting security vulnerabilities," in *International Conference on Learning Representations (ICLR 2025)*, vol. 2025, pp. 35735–35758, 2025.

[13] J. Liu, G. Lin, H. Mei, F. Yang, and Y. Tai, "Enhancing vulnerability detection efficiency: An exploration of light-weight llms with hybrid code features," *Journal of Information Security and Applications*, vol. 88, p. 103925, 2025.

[14] K. Greshake, R. Abdelnabi, S. Mishra, C. Endres, T. Holz, and M. Fritz, "Not what you've signed up for: Compromising real-world llm-integrated applications with indirect prompt injection," in *Proceedings of the 45th IEEE Symposium on Security and Privacy (S&P '24)*, pp. 1409–1426, 2024.

[15] F. Perez and I. Ribeiro, "Ignore this title and hack the computer: An empirical study of prompt injection vulnerabilities in large language models," *ACM Computing Surveys*, vol. 57, no. 2, pp. 45–68, 2024.

---

## APPENDIX: COMPREHENSIVE UI SCREENSHOTS WITH LABELED PANEL DESCRIPTIONS

This appendix provides labeled diagrams and visual architectural layouts of the ten core interactive panels and tools comprising the IntelliFix Studio. Each screenshot contains explicit callout indicators matching the sample report guidelines.

---

### Fig. A1: Web Studio Source Input, File Explorer & Dual-Pane Editor
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Global Navigation & Status]                                           [Purpose: Real-Time Environment Health] |
| TOP NAVBAR:  [=] Compiler Studio    [Python 3.13 Ready]   [Input Guard: Active]      [Eco Analytics]  [Light/Dark Theme]|
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Testcase Loading]  | [Purpose: Raw Source Input]                 | [Purpose: Verified Safe Patch Display]     |
| SIDEBAR FILE EXPLORER        | PANEL 1: INPUT CODE EDITOR (Source)         | PANEL 2: AI MODIFIED CODE EDITOR (Patch)   |
| 📁 Workspace Files           |  1  def divide_elements(items, div):        |  1  def divide_elements(items, div):       |
|   • T1.py (Multi-Algorithm)  |  2      results = []                        |  2      results = []                       |
|   • T2.py (Control Flow)     |  3      for item in items:                  |  3      for item in items:                 |
|   • T3.py (Data Flow)        |  4          results.append(item / div)      |  4          results.append(item / div      |
|   • T-optimising.py (O(N^3)) |  5      return results                      |  5                         if div != 0     |
|   • T_Brackets.py (Dyck PDA) |  6                                          |  6                         else 0)         |
|   • T_errors1.py (Cascade)   |  7  data = [10, 20, 30]                     |  7      return results                     |
|   • T_few_Injections.py      |  8  print(divide_elements(data, 0))         |  8  data = [10, 20, 30]                    |
|   + New File   ^ Upload File |                                             |  9  print(divide_elements(data, 0))        |
|                              | [ > Analyze Code ]   [ * Optimize Inline ]  | Status: [REPAIRED] • Exit Status: 0        |
+------------------------------+---------------------------------------------+--------------------------------------------+
```
*Fig. A1. Main Developer Interface of the IntelliFix Web Studio.*

* **Purpose of Global Navigation & Status Bar**: Displays host runtime status (Python 3.13 ready), active security guard posture (Input Guard: Active), quick access to Eco Analytics Green IT profiling, and theme toggle controls.
* **Purpose of Workspace File Explorer**: Enables rapid, single-click loading of foundational test suites, edge cases, algorithmic loop testcases (`T-optimising.py`), and adversarial prompt injection benchmarks without manual copy-pasting.
* **Purpose of Input Code Editor**: Provides syntax-highlighted editing with live line-number gutters, UTF-8 BOM sanitization, and direct multi-error compilation analysis triggers.
* **Purpose of AI Modified Code Editor**: Displays the verified repaired code patch generated through deterministic AST transformation or local neural inference, accompanied by a green status pill confirming clean sandbox termination.

---

### Fig. A2: Deterministic Lexical Tokenizer & Hand-Written DFA Stepper
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Formal Automata Configuration]                                                                               |
| DFA AUTOMATON ENGINE & STEP TRACER                                                      [Hopcroft Minimizer: Armed]     |
+-------------------------------------------------------------------------------------------------------------------------+
| Preset Automata:  (o) Identifier   ( ) Integer Literal   ( ) Decimal Float   ( ) String Literal   ( ) Operator Symbols  |
| String Input: [ total_score_123 ]                            [ > Step Trace ]   [ * Hopcroft Minimize Automaton ]       |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Visual State Transition Diagram]                                                                              |
| STATE MACHINE DIAGRAM (Mermaid Graph):                                                                                  |
|       (q_start) ----- [a-zA-Z_] -----> ((q_id)) <----+                                                                 |
|                                         │            │ [a-zA-Z0-9_]                                                     |
|                                         └────────────┘                                                                  |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Instantaneous Transition History]                                                                             |
| EXECUTION STEP TRACE:                                                                                                   |
| Step 0: State q0      | Read 't' (alpha)       --> Transition to State q_id                                             |
| Step 1: State q_id    | Read 'o' (alpha)       --> Transition to State q_id                                             |
| Step 2: State q_id    | Read '_' (underscore)  --> Transition to State q_id                                             |
| Step 3: State q_id    | Read '1' (digit)       --> Transition to State q_id                                             |
| Final Verdict: ACCEPTED (String matches regular grammar: Valid Python Variable Identifier)                              |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A2. Lexical Tokenizer and Hand-Written Deterministic Finite Automaton (DFA) Stepper.*

* **Purpose of Formal Automata Configuration**: Allows students to select between fundamental lexical token classes, exploring the mathematical equivalence between regular expressions and state machines.
* **Purpose of Visual State Machine Diagram**: Renders the complete directed graph of states, transitions, and accept states, visually reinforcing the concept of finite state machines.
* **Purpose of Instantaneous Transition History**: Steps through each character of the input string one-by-one, showing how the transition function $\delta(q, c) = q'$ operates deterministically and confirming whether the final state $q \in F$.
* **Purpose of Hopcroft Minimizer**: Demonstrates state minimization algorithms, collapsing redundant equivalence states into the canonical minimal DFA.

---

### Fig. A3: Pushdown Automaton (PDA) Dyck Bracket Validation & Stack Animation
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Context-Free Language Inspector]                                                                              |
| PUSHDOWN AUTOMATON (PDA) STACK & TAPE ANIMATOR                                          [Language: Dyck Balanced D3]    |
+-------------------------------------------------------------------------------------------------------------------------+
| Source Code Expression:  [ mapping = {'users': [1, 2, (3, 4)], 'active': True} ]       [ > Animate Bracket Stack ]      |
| Verification Status:     [PASSED: PERFECTLY BALANCED]  •  Total Transitions: 14  •  Stack Bottom: Z0                    |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Instantaneous Tape & Stack Description]                                                                       |
| STEP-BY-STEP STACK TRACE:                                                                                               |
| Step 1: Read '{'  | Action: PUSH '{'    | Stack Content: [ Z0, '{' ]                                                   |
| Step 2: Read '['  | Action: PUSH '['    | Stack Content: [ Z0, '{', '[' ]                                              |
| Step 3: Read '('  | Action: PUSH '('    | Stack Content: [ Z0, '{', '[', '(' ]                                         |
| Step 4: Read ')'  | Action: POP '('     | Match '(' with ')' --> Stack: [ Z0, '{', '[' ]                                |
| Step 5: Read ']'  | Action: POP '['     | Match '[' with ']' --> Stack: [ Z0, '{' ]                                     |
| Step 6: Read '}'  | Action: POP '{'     | Match '{' with '}' --> Stack: [ Z0 ]                                          |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Delimiter Error Localization]                                                                                 |
| Stack Empty Invariant: Stack equals [ Z0 ] at terminal input --> q_accept reached with zero dangling brackets.         |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A3. Pushdown Automaton (PDA) Stack and Tape Animator for Balanced Dyck Languages.*

* **Purpose of Context-Free Language Inspector**: Connects programming syntax errors (e.g., `SyntaxError: unmatched ')'`) to formal grammar theory, demonstrating why stacks are required to parse non-regular nested structures.
* **Purpose of Instantaneous Tape & Stack Description**: Provides a visual animation of push and pop operations across opening and closing delimiters, tracking the exact stack depth at each position.
* **Purpose of Delimiter Error Localization**: In cases of unbalanced input, the PDA halts immediately at the earliest illegal pop or unclosed delimiter, explaining the structural syntax defect before compiler failure.

---

### Fig. A4: Control Flow Graph (CFG) & Cyclomatic Complexity Analysis
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Program Structure Overview]                                                                                   |
| CONTROL FLOW GRAPH & McCABE CYCLOMATIC COMPLEXITY                                       [Overall Complexity: M = 4]     |
+-------------------------------------------------------------------------------------------------------------------------+
| Function: [ authenticate_user(role, token) ]                                           [Risk Level: LOW (M <= 5)]      |
| Graph Metrics:  |V| Basic Blocks = 6  •  |E| Control Edges = 8  •  |P| Connected Components = 1                         |
| Formula:        M = |E| - |V| + 2P = 8 - 6 + 2(1) = 4                                                                   |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Control Flow Visualization]                                                                                   |
| BASIC BLOCK TOPOLOGY (Mermaid Graph):                                                                                   |
|             [ Block 0: Entry & Token Verification ]                                                                     |
|                               │                                                                                         |
|             /-----------------┴-----------------\                                                                       |
|            < Role == "ADMIN"?                    >                                                                      |
|             \-----------------┬-----------------/                                                                       |
|                     (Yes)     │     (No)                                                                                |
|                               ▼                                                                                         |
|            [ Block 1: Grant Full Access ]      [ Block 2: Check Role == "USER" ]                                        |
|                               │                               │                                                         |
|                               ▼                               ▼                                                         |
|                      [ Block 4: Audit Log Entry & Return ]                                                              |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Testing Friction & Coverage Guide]                                                                            |
| Minimum Independent Paths Required for Full Branch Coverage = 4 Independent Test Cases.                                 |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A4. Control Flow Graph (CFG) and McCabe Cyclomatic Complexity Heatmap.*

* **Purpose of Program Structure Overview**: Breaks procedural code down into mathematical basic blocks and control transfer edges, calculating McCabe's metric $M$.
* **Purpose of Basic Block Topology**: Renders the complete flowchart of branching decisions, loops, and terminal exits, allowing learners to visualize all reachable code paths.
* **Purpose of Testing Friction & Coverage Guide**: Educates developers on branch coverage requirements, highlighting functions with $M > 10$ as code smells requiring modular decomposition.

---

### Fig. A5: Intermediate Representation (Three-Address Code) & DAG Optimizer
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Intermediate Code Generation]                                                                                 |
| THREE-ADDRESS CODE (TAC) & DIRECTED ACYCLIC GRAPH (DAG)                                 [Optimizer: Constant Folding]   |
+-------------------------------------------------------------------------------------------------------------------------+
| SOURCE INPUT EXPRESSION:               THREE-ADDRESS CODE (TAC):                DAG OPTIMIZED TAC:                      |
|   total = (base * 10) + (base * 10)      1: t1 = base * 10                       1: t1 = base * 10                     |
|   return total                           2: t2 = base * 10                       2: total = t1 + t1  # CSE Applied      |
|                                          3: total = t1 + t2                      3: return total                        |
|                                          4: return total                                                                |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Directed Acyclic Graph (DAG) Representation]                                                                  |
| NODE DEPENDENCIES:                                                                                                      |
|   Node n1: [Op: '*']  --> Left: 'base', Right: '10'  (Computed once, reused via Common Subexpression Elimination)       |
|   Node n2: [Op: '+']  --> Left: n1, Right: n1                                                                           |
|   Node n3: [Op: 'Store'] --> Target: 'total', Value: n2                                                                 |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Algorithmic Transformation Insights]                                                                          |
| Optimization Summary: 1 redundant arithmetic instruction eliminated; loop-invariant code motion eligible.              |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A5. Intermediate Representation (Three-Address Code) and DAG Optimization.*

* **Purpose of Intermediate Code Generation**: Bridges high-level Python syntax with low-level machine execution, showing how complex expressions translate into standardized 3-address instructions ($x = y \text{ op } z$).
* **Purpose of Directed Acyclic Graph (DAG) Representation**: Visualizes common subexpressions, illustrating how identical operations are merged into single computational nodes.
* **Purpose of Algorithmic Transformation Insights**: Demonstrates classical compiler optimization techniques, including constant folding, dead code elimination, and common subexpression elimination (CSE).

---

### Fig. A6: IntelliFix Multi-Error Diagnostic & 5-Round Auto-Repair Diff
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Multi-Error Cascade Inspector]                                                                                |
| INTELLIFIX MULTI-ERROR DIAGNOSTIC & AUTO-REPAIR ENGINE                                  [Errors Caught: 2 • Fixed: 2]   |
+-------------------------------------------------------------------------------------------------------------------------+
| Active Error Queue:                                                                                                     |
|  [!] Line 4: ZeroDivisionError: float division by zero               Status: [RESOLVED (Round 1)]                        |
|  [!] Line 7: TypeError: 'int' object is not iterable                 Status: [RESOLVED (Round 2)]                        |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Multi-Tier Pedagogical Diagnosis]                                                                             |
| PEDAGOGICAL ERROR EXPLANATION (Source: Deterministic Rule Engine):                                                      |
|   • What Happened (Mistake): Line 4 attempted to divide a number by variable 'denominator', which evaluated to zero.    |
|   • Why It Occurred (Reason): In Python, dividing by zero causes an immediate fatal ZeroDivisionError exception.         |
|   • How to Fix (Guidance): Add a defensive condition before division: 'numerator / denominator if denominator != 0 else 0'|
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Surgical Line-by-Line Unified Patch]                                                                          |
| UNIFIED CODE DIFF:                                                                                                      |
|   --- sample_buggy.py                                                                                                   |
|   +++ sample_buggy.py (fixed)                                                                                           |
|   @@ -3,2 +3,2 @@                                                                                                       |
|   -    ratio = total / count                                                                                            |
|   +    ratio = total / count if count != 0 else 0                                                                       |
|   -    for idx in limit:                                                                                                |
|   +    for idx in range(limit):                                                                                         |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A6. Multi-Error Diagnosis and 5-Round Iterative Auto-Repair Diff View.*

* **Purpose of Multi-Error Cascade Inspector**: Lists all syntax and runtime errors sequentially, preventing cascade poisoning by distinguishing root-cause defects from downstream symptoms.
* **Purpose of Pedagogical Error Explanation**: Provides empathetic, student-centered explanations structured into Mistake, Reason, and Actionable Fix, derived without hallucination.
* **Purpose of Surgical Line-by-Line Unified Patch**: Shows the exact localized changes made to the code, guaranteeing that comments, whitespace, and unaffected functions remain untouched.

---

### Fig. A7: 4-Gate AAI Security Shield Alert & Blocked Adversarial Payload
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Critical Security Interception Banner]                                                                        |
| 🛡️ AAI SECURITY SHIELD: ADVERSARIAL THREAT INTERCEPTED & BLOCKED                        [RISK SCORE: 100/100 (HIGH)]    |
+-------------------------------------------------------------------------------------------------------------------------+
| Interception Details:                                                                                                   |
|   • Intercepting Gate:   GATE 1 (Policy & Input Guard)                                                                  |
|   • Target Program:      attack_payload_07.py                                                                           |
|   • System Status:       Application Process Remained Fully Active & Uncompromised (Exit Code 2)                        |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Threat Taxonomy Evidence]                                                                                     |
| DETECTED ADVERSARIAL FINDINGS:                                                                                          |
|   [!] AT-01 (Prompt Injection):      Heuristic match detected 'SYSTEM OVERRIDE: ignore all safety guidelines'           |
|   [!] AT-04 (Tool Hijacking):        Prohibited module import detected: 'import os; os.system("whoami")'                |
|   [!] AT-06 (Credential Harvesting): Attempted exfiltration of environment tokens matching pattern '$env:GEMINI_KEY'    |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Defense-in-Depth Quarantine Action]                                                                           |
| Action Taken: Code execution halted before AST parsing. Host filesystem and model context completely protected.         |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A7. 4-Gate AAI Security Shield Adversarial Threat Interception Banner.*

* **Purpose of Critical Security Interception Banner**: Immediately alerts developers and administrators when untrusted code contains hostile payloads, displaying the cumulative risk score (100/100).
* **Purpose of Threat Taxonomy Evidence**: Maps malicious patterns directly to standardized threat categories (`AT-01` through `AT-16`), showing exactly which tokens or AST nodes triggered the security block.
* **Purpose of Defense-in-Depth Quarantine Action**: Confirms that execution was terminated at Gate 1, preventing malicious shell commands from reaching the sandbox or LLM.

---

### Fig. A8: Banking Four-Eyes Dual-Key Cryptographic Authorization Modal
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Mutating Tool Privilege Escalation Prevention]                                                                |
| FOUR-EYES DUAL-KEY AUTHORIZATION VAULT (Gate 2 Guard)                                   [Security Level: BANKING / HIGH]|
+-------------------------------------------------------------------------------------------------------------------------+
| Action Requested:  Agent requested mutating action: 'WRITE_FILE' to path '/workspace/production_config.py'              |
| Proposal Digest:   SHA256: 7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069                             |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Separation of Duties Verification]                                                                            |
| DUAL AUTHORIZATION SIGNATURES:                                                                                          |
|   1. Key A (HMAC Auditor Key):   [ 9a8c2d1e... ]  --> Status: VALIDATED (Audit Trail Initialized)                       |
|   2. Key B (Operator Approval):  [ Operator: admin_user_01 ]  --> Status: PENDING EXPLICIT HUMAN CONFIRMATION           |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Non-Bypassable Execution Controls]                                                                            |
| [ Approve & Sign Authorization ]               [ Reject & Revoke Tool Access ]                                          |
| Note: Mutating tools cannot execute without two independent, non-correlated cryptographic signatures.                   |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A8. Four-Eyes Dual-Key Cryptographic Tool Authorization Modal.*

* **Purpose of Mutating Tool Privilege Escalation Prevention**: Prevents autonomous agents from modifying files, executing shell scripts, or accessing external networks without oversight.
* **Purpose of Separation of Duties Verification**: Implements the classical Four-Eyes banking principle: an automated auditor key must pair with a verified human operator signature.
* **Purpose of Non-Bypassable Execution Controls**: Ensures complete human-in-the-loop governance over sensitive environment mutations.

---

### Fig. A9: Tamper-Evident Merkle Audit Log & Chain Integrity Verifier
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Continuous Cryptographic Ledger Verification]                                                                 |
| CRYPTOGRAPHIC AUDIT LOG & MERKLE CHAIN VERIFIER                                         [Ledger State: 100% VALID]      |
+-------------------------------------------------------------------------------------------------------------------------+
| Audit File:      results/security_log.jsonl                                                                             |
| Total Records:   302 Committed Security Events  •  Zero Hash Breaks Detected  •  Merkle Root: 37a81f8c1170...          |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Merkle Chaining Historical Log Entries]                                                                       |
| RECORD TRAIL:                                                                                                           |
| Record #300:  Timestamp: 2026-11-18 10:14:02 | Decision: ALLOW  | Risk: 0   | Hash: 9d12a8... -> Chained to #299        |
| Record #301:  Timestamp: 2026-11-18 10:18:45 | Decision: BLOCK  | Risk: 100 | Hash: f38b91... -> Chained to #300        |
| Record #302:  Timestamp: 2026-11-18 10:22:19 | Decision: ALLOW  | Risk: 0   | Hash: 37a81f... -> Chained to #301        |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Tamper Detection Simulation]                                                                                  |
| Integrity Test: Calling 'verify_log()' recalculates H_i = SHA256(H_{i-1} || Canonical(P_i)) across all records.         |
| Result: All 302 entries verified cleanly. Any unauthorized edit breaks the chain immediately.                           |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A9. Tamper-Evident Merkle Audit Log and Chain Integrity Verifier.*

* **Purpose of Continuous Cryptographic Ledger Verification**: Proves that every security block, tool execution, and code repair decision is permanently recorded in a tamper-evident audit ledger.
* **Purpose of Merkle Chaining Historical Log Entries**: Displays the mathematical hash linkage between consecutive entries, guaranteeing non-repudiation.
* **Purpose of Tamper Detection Simulation**: Demonstrates that if an attacker modifies historical log entries, the verification engine instantly flags the exact corrupted line number.

---

### Fig. A10: Green IT Eco Analytics & Sustainable Compute Profiler
```
+-------------------------------------------------------------------------------------------------------------------------+
| [Purpose: Green Computing & Environmental Sustainability]                                                               |
| ECO ANALYTICS & ENERGY PROFILING DASHBOARD (CodeCarbon)                                 [Sustainability: OPTIMAL]       |
+-------------------------------------------------------------------------------------------------------------------------+
| Carbon Emission:      0.000000 kg CO2eq (Zero Measured Host Carbon Penalty)                                             |
| Mean Latency Delta:   +2.05 ms / Request (96.4% Virtualization Execution Efficiency)                                       |
| Offline Efficiency:   100% Local Inference • Zero WAN Network Transmission Overhead                                     |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Energy Footprint Breakdown]                                                                                   |
| COMPONENT ENERGY ALLOCATION:                                                                                            |
|   • Gate 1 Regex & Heuristic Policy Engine:        0.000001 kWh  (Near Zero)                                           |
|   • Gate 3 AST Traversal & Bytecode Scanner:       0.000003 kWh  (Near Zero)                                           |
|   • Isolated Sandbox Subprocess Execution:         0.000085 kWh  (Minimal)                                             |
|   • Gate 4 Output Sanitization & Merkle Hashing:   0.000002 kWh  (Near Zero)                                           |
|-------------------------------------------------------------------------------------------------------------------------|
| [Purpose: Institutional Feasibility]                                                                                    |
| Demonstrates that multi-gate security enforcement does not impose noticeable compute or environmental penalties.        |
+-------------------------------------------------------------------------------------------------------------------------+
```
*Fig. A10. Green IT Eco Analytics and Environmental Profiler.*

* **Purpose of Green Computing & Environmental Sustainability**: Quantifies the environmental footprint of automated program repair, verifying compliance with institutional sustainability goals.
* **Purpose of Energy Footprint Breakdown**: Proves that local neuro-symbolic algorithms consume orders of magnitude less energy than continuous round-trip queries to multi-billion parameter cloud models.
* **Purpose of Institutional Feasibility**: Confirms that IntelliFix can be deployed across hundreds of laboratory workstations simultaneously without straining institutional electrical or cooling infrastructure.
