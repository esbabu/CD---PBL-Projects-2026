# Deterministic Finite Automata (DFA) Specification

This document provides the formal theory, 5-tuple specifications, transition tables, state diagrams, and viva notes for the hand-written DFAs implemented in `dfa.py` for IntelliFix (Week 3, Feature 5).

---

## 1. ASCII Identifier DFA (`IDENT_DFA`)

### 1.1 Formal 5-Tuple Definition
$$M_{\text{ident}} = (Q, \Sigma, \delta, q_0, F)$$

- **$Q$ (State set)**: $\{q_0, q_{\text{accept}}, \text{DEAD}\}$
- **$\Sigma$ (Alphabet)**: ASCII characters categorized into symbol classes:
  - $\text{LETTER\_OR\_UNDERSCORE} = [A-Za-z\_]$
  - $\text{DIGIT} = [0-9]$
  - $\text{OTHER} = \Sigma \setminus (\text{LETTER\_OR\_UNDERSCORE} \cup \text{DIGIT})$
- **$q_0$ (Start state)**: $q_0$
- **$F$ (Accepting states)**: $\{q_{\text{accept}}\}$
- **$\delta$ (Transition Function)**: Defined in the transition table below.

### 1.2 Transition Table
| Current State | Input Class: `LETTER_OR_UNDERSCORE` | Input Class: `DIGIT` | Input Class: `OTHER` |
| :--- | :--- | :--- | :--- |
| **$q_0$ (Start)** | $q_{\text{accept}}$ | DEAD | DEAD |
| **$q_{\text{accept}}$ (Accept)** | $q_{\text{accept}}$ | $q_{\text{accept}}$ | DEAD |
| **DEAD (Trap)** | DEAD | DEAD | DEAD |

### 1.3 State Diagram

#### ASCII Diagram
```
        [A-Za-z_]           [A-Za-z0-9_]
  (q0) ------------> (( q_accept )) <----\
   |                      |               |
   | [0-9, other]         | [other]       |
   v                      v               |
  [      DEAD (Trap)     ] <--------------/
```

#### Mermaid Diagram
```mermaid
stateDiagram-v2
    [*] --> q0
    q0 --> q_accept: [A-Za-z_]
    q0 --> DEAD: [0-9, other]
    q_accept --> q_accept: [A-Za-z0-9_]
    q_accept --> DEAD: other
    DEAD --> DEAD: any
```

### 1.4 The Unicode Limitation
- **Theoretical Bound**: The hand-written DFA in `dfa.py` explicitly operates over ASCII character classes `[A-Za-z_]` and `[0-9]`.
- **Full Python Standard**: Under PEP 3131, Python allows arbitrary Unicode letters and numbers in identifiers (e.g., `ñ`, `alpha_α`, `π`).
- **Implementation Strategy**: In `tokenizer.py`, the master lexical analyzer utilizes the Unicode-aware character class `[^\W\d]\w*` to conform with Python 3 language rules, while `dfa.py` serves as the rigorous, verifiable theoretical foundation for ASCII identifier recognition.

---

## 2. Decimal & Float Number DFA (`NUMBER_DFA`)

### 2.1 Formal 5-Tuple Definition
$$M_{\text{num}} = (Q, \Sigma, \delta, q_0, F)$$

- **$Q$**: $\{q_0, q_{\text{int}}, q_{\text{dot}}, q_{\text{float}}, \text{DEAD}\}$
- **$\Sigma$**: Classes $\{\text{DIGIT}, \text{DOT}, \text{OTHER}\}$ where $\text{DIGIT} = [0-9]$, $\text{DOT} = \{.\}$
- **$q_0$**: $q_0$
- **$F$**: $\{q_{\text{int}}, q_{\text{float}}\}$
- **$\delta$**: Transition function mapping $(q, \text{class}) \to q'$.

### 2.2 Transition Table
| State | Input: `DIGIT` | Input: `DOT` (`.`) | Input: `OTHER` |
| :--- | :--- | :--- | :--- |
| **$q_0$** | $q_{\text{int}}$ | DEAD | DEAD |
| **$q_{\text{int}}$ (Accept)** | $q_{\text{int}}$ | $q_{\text{dot}}$ | DEAD |
| **$q_{\text{dot}}$** | $q_{\text{float}}$ | DEAD | DEAD |
| **$q_{\text{float}}$ (Accept)**| $q_{\text{float}}$ | DEAD | DEAD |
| **DEAD** | DEAD | DEAD | DEAD |

### 2.3 Mermaid Diagram
```mermaid
stateDiagram-v2
    [*] --> q0
    q0 --> q_int: [0-9]
    q_int --> q_int: [0-9]
    q_int --> q_dot: .
    q_dot --> q_float: [0-9]
    q_float --> q_float: [0-9]
    q0 --> DEAD: other
    q_dot --> DEAD: other / .
    q_float --> DEAD: other / .
```

---

## 3. Decimal Integer with Underscores DFA (`INT_UNDERSCORE_DFA`)

### 3.1 Formal 5-Tuple Definition
$$M_{\text{under}} = (Q, \Sigma, \delta, q_0, F)$$

- **$Q$**: $\{q_0, q_{\text{digit}}, q_{\text{under}}, \text{DEAD}\}$
- **$\Sigma$**: $\{\text{DIGIT}, \text{UNDERSCORE}, \text{OTHER}\}$
- **$q_0$**: $q_0$
- **$F$**: $\{q_{\text{digit}}\}$
- **Language**: $[0-9](\_?[0-9])*$ (PEP 515 literal syntax where an underscore must be followed by a digit and cannot be trailing).

### 3.2 Transition Table
| State | Input: `DIGIT` | Input: `UNDERSCORE` (`_`) | Input: `OTHER` |
| :--- | :--- | :--- | :--- |
| **$q_0$** | $q_{\text{digit}}$ | DEAD | DEAD |
| **$q_{\text{digit}}$ (Accept)** | $q_{\text{digit}}$ | $q_{\text{under}}$ | DEAD |
| **$q_{\text{under}}$** | $q_{\text{digit}}$ | DEAD | DEAD |
| **DEAD** | DEAD | DEAD | DEAD |

---

## 4. Viva Examination Questions & Answers

1. **Q: What is the formal definition of a Deterministic Finite Automaton?**  
   **A:** A 5-tuple $M = (Q, \Sigma, \delta, q_0, F)$ where $Q$ is a finite set of states, $\Sigma$ is a finite input alphabet, $\delta: Q \times \Sigma \to Q$ is the transition function, $q_0 \in Q$ is the start state, and $F \subseteq Q$ is the set of accepting states.

2. **Q: How does the DFA ensure determinism?**  
   **A:** For every state $q \in Q$ and input symbol $a \in \Sigma$, there is exactly one next state $\delta(q, a)$. There are no $\epsilon$-transitions or ambiguous transitions.

3. **Q: Why are identifiers and numbers regular languages?**  
   **A:** They can be described by regular expressions without requiring stack storage or unbounded recursive memory; a finite set of states suffices to track validity.

4. **Q: What is the difference between a DFA and an NFA in expressive power and time complexity?**  
   **A:** By the subset construction algorithm (Rabin-Scott theorem), DFAs and NFAs recognize the exact same class of languages (the regular languages). However, a DFA processes an input of length $n$ in $O(n)$ strictly deterministic time with $O(1)$ space per step, whereas an NFA may require state tracking across multiple active branches.

5. **Q: How does the `INT_UNDERSCORES` DFA enforce Python PEP 515 literal syntax without backtracking?**  
   **A:** It transitions from $q_{\text{digit}}$ to $q_{\text{under}}$ upon encountering `_`, strictly requiring the immediate next symbol to be a `DIGIT` to return to accepting state $q_{\text{digit}}$. If another underscore, delimiter, or EOF occurs while in $q_{\text{under}}$, it transitions to DEAD, disallowing consecutive or trailing underscores.

6. **Q: Why cannot a DFA recognize arbitrary balanced parentheses $a^n b^n$?**  
   **A:** By the Pumping Lemma for Regular Languages, tracking an arbitrary number of opened parentheses $n$ requires unbounded memory. Because a DFA has a strictly finite state set $|Q| = k$, for $n > k$ the pigeonhole principle guarantees a cycle, making exact counter-matching impossible without a stack.

7. **Q: How does input symbol partitioning into equivalence classes optimize the DFA?**  
   **A:** Rather than maintaining a transition entry for all 256 ASCII bytes or 1,114,112 Unicode points, characters are partitioned into equivalence classes (`ALPHA`, `DIGIT`, `UNDERSCORE`, `DOT`, `OTHER`). A fast $O(1)$ classification maps each char to its class, keeping the transition table compact and cache-friendly.

8. **Q: What is a dead/trap state in a DFA and how does the scanner leverage it?**  
   **A:** A dead (trap) state is a non-accepting sink state where $\delta(\text{DEAD}, a) = \text{DEAD}$ for all $a \in \Sigma$. Once entered, the DFA cannot accept; in a lexical scanner, transitioning to DEAD signals the maximal munch boundary where the current token candidate can no longer be extended.
