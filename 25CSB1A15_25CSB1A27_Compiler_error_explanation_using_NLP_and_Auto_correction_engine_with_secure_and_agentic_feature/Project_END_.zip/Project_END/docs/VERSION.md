# IntelliFix v1.0.0 Release Notes

**Release Date**: October 22, 2026  
**Final Verification Hash (`week6_hash`)**: Computed over `security/metrics.py`, `run_benchmark.py`, `intellifix.py`  
**Status**: Production / Submission Ready

---

## What's New in Version 1.0.0

### 1. 4-Gate AAI Security Shield
- **Gate 1 (Prompt & Policy Guard)**: Real-time detection of prompt injections, role jailbreaks, and system overrides across 15 threat taxonomy categories (AT-01 through AT-15).
- **Gate 2 (Tool & Capability Guard)**: Strict separation of read-only vs mutating capabilities with cryptographic human-in-the-loop approval tokens.
- **Gate 3 (Code & AST Execution Guard)**: Pre-execution static AST analysis and bytecode disassembly preventing malicious imports (`os.system`, `subprocess`) and dynamic code execution (`eval`).
- **Gate 4 (Output & Leakage Guard)**: Automated redaction and regex scrubbing of API credentials, Bearer tokens, and PII.

### 2. Standalone CLI Utility (`intellifix.py`)
- Direct command-line interface for diagnosing and repairing Python code:
  - `python intellifix.py <file.py> [options]`
  - Options: `--agent`, `--diff`, `--json`, `--write`, `--in-place`, `--shield-off`, `--version`.
  - Deterministic offline execution default (zero network required).
  - Exit codes: 0 (clean/repaired), 1 (unfixed errors), 2 (security blocked).

### 3. Empirical Security Evaluation & Metrics Engine
- Comprehensive statistical evaluation engine in `security/metrics.py`:
  - Standard & Strict Confusion Matrices with 95% Wilson Score Confidence Intervals.
  - Empirical Attack Success Rate (ASR) reduction: -70.27% (Dev) / -46.15% (Held-out).
  - ROC Curve generation with trapezoidal AUC computation (Dev: 0.8905, Held-out: 0.8666).
  - Risk score separation metrics (+37.00 Dev, +34.89 Held-out).
  - Read-only API endpoint `GET /api/security/metrics` (POST/PUT/DELETE return 405).
  - 5 standalone vector graphics charts in `results/charts/`.

### 4. Offline Utility Benchmark (24 Programs, 96 Evaluations)
- 24 diverse benchmark programs covering 10 Python exception categories and multi-error chains.
- Demonstrates **79.2% repair success rate** and **100.0% utility preservation** with zero false blocks on benign code.
- Carbon emissions and energy consumption quantified via CodeCarbon (~0.00010 kWh / evaluation).

### 5. Web Studio Hardening & Security Panel
- Added interactive **Security Evaluation Dashboard** modal (`#w6_modal_security`) with live KPI cards, risk meter, and cryptographic audit log viewer.
- Real-time **Red/Green Diff View** for inspectable code repairs via `POST /api/diff`.
- Mitigated 2 self-XSS sinks in multi-error and file listing tables using strict `document.createElement` and `textContent`.

### 6. Cryptographic Audit Chain
- Continuous SHA-256 Merkle hash chain in `results/security_log.jsonl`.
- Fully verifiable via `verify_log()`; guarantees tamper evidence across all security events.

---

## Golden Regression Equivalency
- Evaluated against baseline golden test harness: **Zero regressions across all 56 golden programs and API contracts**.
