# INTELLIFIX AGENT ARCHITECTURE (WEEK 4 SPECIFICATION)

## 1. System Overview & Plain-Words Architecture

The IntelliFix Agent (`agent.py`) is an autonomous, multi-step error diagnostic and repair system built on top of the deterministic analysis pipeline of Weeks 1–3. Unlike simple one-shot repair scripts, the agent executes an iterative feedback loop:
1. It inspects source code and diagnostics.
2. It interacts with an environment via a strictly confined, closed tool registry (`agent_tools.py`).
3. It retains short-term observation memory with bounded LRU eviction (`agent_memory.py`).
4. When a patch is synthesized and verified in an isolated sandbox, the agent **never applies modifications silently**. Instead, it stages a proposal (`agent_proposals.py`) requiring explicit, out-of-band human approval before any file on disk is written.

### Core Architecture Principles
- **Closed Tool Registry**: The agent only has access to 4 safe tools (`run_code`, `scan_security`, `read_file`, `apply_patch`). No arbitrary shell, network, or file deletion capabilities exist.
- **Strict Budget & Capped Resources**: The agent loop is hard-capped at 5 iterations, 15.0 seconds total wall-clock runtime, and 5 tool calls maximum per repair session.
- **Determinism First (Offline-Capable)**: In evaluation and offline mode, the agent relies on deterministic rule-based tool driving. When AI assistance is enabled, prompts are strictly isolated and responses are post-filtered.
- **Mandatory Human-in-the-Loop**: All file alterations yield proposal tokens (`prop_...`). The proposal engine requires explicit user confirmation via `/api/agent/approve`, re-scanning code through `scan_gate` at approval time to prevent time-of-check to time-of-use (TOCTOU) attacks.
- **Instruction Post-Filtering**: Natural language directives from developers (e.g., `"explain only"`, `"keep my variable names"`) are validated post-hoc against synthesized patches; if violated, the patch is rejected or downgraded.

---

## 2. Architecture Diagrams

### 2.1 Mermaid Architecture Diagram

```mermaid
flowchart TD
    User([Developer / UI Client]) -->|POST /api/agent| AgentRouter[app.py /api/agent]
    AgentRouter --> AgentLoop[agent.repair]

    subgraph Agent_Core ["IntelliFix Autonomous Agent Loop"]
        AgentLoop --> MemoryCheck{"Check Memory\nagent_memory.py"}
        MemoryCheck --> ToolExecution["Execute Tool Step\nagent_tools.py"]
        ToolExecution --> ToolGate{"4 Closed Tools Only"}
        ToolGate -->|run_code| Sandbox[sandbox_runner.py]
        ToolGate -->|scan_security| Scanner[security_analyzer.scan_gate]
        ToolGate -->|read_file| WorkspaceRead[Confined Read]
        ToolGate -->|apply_patch| CandidateVerify[Sandbox & Scanner Verify]
        CandidateVerify --> LoopCondition{"Bug Resolved or\nBudget Exhausted?"}
        LoopCondition -->|No| ToolExecution
        LoopCondition -->|Yes| PostFilter{"Instruction Post-Filter\n(explain only / naming)"}
    end

    PostFilter -->|Violated| RejectPatch["Reject / Diagnostic Only"]
    PostFilter -->|Clean & Healed| ProposalEngine["Stage Proposal\nagent_proposals.create_proposal"]

    ProposalEngine --> ClientResponse["Return Step Trace & Proposal ID"]
    ClientResponse --> UIModal["UI Proposal Modal (Diff View)"]

    UIModal -->|POST /api/agent/approve| ApprovalGate{"Approval Gate\nRe-scan AST with scan_gate"}
    ApprovalGate -->|Clean AST & Confined| DiskWrite["Atomic Write to *_fixed.py"]
    ApprovalGate -->|Tampered or Malicious| BlockApproval["400 Blocked"]
    UIModal -->|POST /api/agent/reject| DiscardProposal["Drop Proposal"]
```

### 2.2 ASCII Architecture Diagram

```text
+-----------------------------------------------------------------------------------+
|                                 DEVELOPER UI CLIENT                               |
+-----------------------------------------------------------------------------------+
                                         |
                                         | POST /api/agent {filename, code, instruction}
                                         v
+-----------------------------------------------------------------------------------+
|                         FLASK API ROUTE (/api/agent)                              |
|  - Host & Origin checks                                                           |
|  - Concurrency Semaphore (Cap 4, Timeout 2.0s)                                    |
|  - Advisory Input Guard scan                                                      |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
|                            AGENT CORE LOOP (agent.py)                             |
|  - Budget Enforcer: Max 5 iterations, Max 15.0s, Max 5 tool calls                 |
|  - Memory Lookup: agent_memory.py (LRU capacity 500, hash keys only)              |
|  - Step Trace Logger: records tool, args, returncode, elapsed_ms                  |
+-----------------------------------------------------------------------------------+
             |                            ^                         ^
             v                            |                         |
+--------------------------+  +-----------------------+  +--------------------------+
|       TOOL REGISTRY      |  |     AST SCANNER       |  |     EXECUTION RUNNER     |
|     (agent_tools.py)     |  | (security_analyzer.py)|  |   (sandbox_runner.py)    |
| - run_code               |  | - Rejects SEC_01..20  |  | - Subprocess 2A          |
| - scan_security          |  | - AST static visitor  |  | - 5.0s timeout cap       |
| - read_file (confined)   |  +-----------------------+  +--------------------------+
| - apply_patch            |
+--------------------------+
             |
             v (If repaired & passes tests)
+-----------------------------------------------------------------------------------+
|                    INSTRUCTION CHANNEL POST-FILTER                                |
|  - "explain only" -> Drops patch candidate, returns step log + explanation only   |
|  - "keep my variable names" -> Verifies original identifiers preserved in AST     |
+-----------------------------------------------------------------------------------+
             |
             v
+-----------------------------------------------------------------------------------+
|                         PROPOSAL STAGING (agent_proposals.py)                     |
|  - Generates cryptographically random UUID proposal_id (prop_...)                |
|  - Stores in LRU cache (Capacity 50, TTL 30 minutes)                              |
|  - NO disk write performed at this stage                                          |
+-----------------------------------------------------------------------------------+
                                         |
                                         v (Returns to Client: trace, diff, proposal_id)
+-----------------------------------------------------------------------------------+
|                         HUMAN APPROVAL GATE (/api/agent/approve)                  |
|  - Validates proposal_id in active cache                                          |
|  - Re-scans proposed code with security_analyzer.scan_gate() (Anti-TOCTOU)        |
|  - Confines target filename to workspace (*_fixed.py)                             |
|  - Writes file to disk atomically                                                 |
+-----------------------------------------------------------------------------------+
```

---

## 3. Tool Specifications & Confinement

All tools are exposed through `agent_tools.py` via `execute_tool(tool_name, tool_args)` and validated against `TOOL_SCHEMAS`:

| Tool Name | Parameters | Purpose | Confinement & Security Guarantees |
|---|---|---|---|
| `run_code` | `code: str`, `timeout: float` (default 5.0s, max 10.0s) | Runs code candidate in sandboxed subprocess | Runs via `sandbox_runner.py` with process isolation and timeout; does not touch disk. |
| `scan_security` | `code: str` | Statically checks AST against SEC_01–SEC_20 rules | Read-only in-memory AST parse. Returns safe/blocked with violations list. |
| `read_file` | `filename: str` | Reads source code from workspace | Confined by `validate_workspace_filename`. Rejects absolute paths, traversals (`..`), NTFS ADS (`:`), and non-whitelisted names. |
| `apply_patch` | `original_code: str`, `patch: str` | Validates and verifies patched candidate | Re-scans with `scan_gate`, executes in sandbox. Does NOT save to disk. Returns `{success, patched_code, test_passed}`. |

---

## 4. Memory Model (`agent_memory.py`)

- **Design**: Thread-safe bounded LRU cache with capacity 500 entries.
- **Key Strategy**: Keys are computed strictly as SHA-256 hashes of input code and error signatures:
  $$\text{Key} = \text{SHA256}(\text{code\_content} + \text{error\_signature})$$
- **Privacy Guarantee**: No raw source code, developer identifiers, or environment strings are stored as raw dictionary keys.
- **Eviction**: When entry count exceeds 500, least-recently-used entries are evicted in $O(1)$ time.

---

## 5. Human-in-the-Loop Approval Workflow (`agent_proposals.py`)

1. **Proposal Generation**: The agent generates a candidate fix. Instead of writing directly, it stages a proposal:
   ```json
   {
     "proposal_id": "prop_a1b2c3d4e5f67890",
     "target_file": "sample1_fixed.py",
     "diff": "--- original\n+++ fixed\n@@ ... @@",
     "created_at": 1776312000.0
   }
   ```
2. **Approval Verification**: When the user clicks "Approve Patch" (`/api/agent/approve`):
   - Proposal existence and 30-minute TTL are checked.
   - Code is re-scanned via `scan_gate(healed_code)`. If security rules are violated, approval is aborted with HTTP 400.
   - Target filename is re-validated to prevent directory traversal.
   - File is written to disk safely.
3. **Rejection Handling**: Clicking "Reject" (`/api/agent/reject`) immediately purges the proposal from the LRU cache without disk operations.

---

## 6. Honest Limitations & Failure Modes

1. **Deterministic Fallback Scope**: In pure offline/mock mode (`LLM_DISABLED=1`), multi-file or novel semantic bugs requiring domain reasoning cannot be solved; the agent relies on deterministic rule-based fixers and AST transformations.
2. **5-Iteration Cap**: Complex chained errors requiring more than 5 distinct edit-execute cycles will terminate with `resolved=False` and report a budget exhaustion status.
3. **Subprocess Isolation on Windows**: Subprocesses run under standard user permissions. File write restrictions rely on Python logic and workspace confinement rather than kernel-level filesystem namespaces.

---

## 7. Viva Voce Questions & Answers (12 Q&As)

### Q1: What makes the IntelliFix Agent an "agent" rather than a simple script?
**A**: A script executes a linear, hard-coded sequence of actions. The IntelliFix Agent implements an autonomous closed loop: it queries its environment via tools (`run_code`, `read_file`), observes outputs (tracebacks, exit codes), maintains state across iterations, and dynamically selects corrective actions until the bug is resolved or the resource budget is exhausted.

### Q2: Why is the tool registry strictly closed to 4 tools?
**A**: To eliminate the attack surface of arbitrary agent behavior. Exposing general-purpose tools like bash/cmd shells, network requests, or arbitrary file deletion allows prompt-injection payloads to weaponize the agent. The 4 tools (`run_code`, `scan_security`, `read_file`, `apply_patch`) provide the exact minimal surface needed for repair while denying all lateral movement.

### Q3: How does IntelliFix prevent an LLM from writing directly to the codebase?
**A**: Through `agent_proposals.py`. The agent has no write-to-disk tool. Any patch candidate only generates an in-memory proposal token (`prop_...`). File writes are only possible via an out-of-band user action hitting `/api/agent/approve`.

### Q4: What is the Time-of-Check to Time-of-Use (TOCTOU) defense in the approval flow?
**A**: Even though the agent scans code during proposal synthesis, the proposed code could theoretically be tampered with or policy rules updated. At approval time (`/api/agent/approve`), the system runs a mandatory second `scan_gate()` AST scan before writing to disk.

### Q5: How is memory protected against poisoning and memory exhaustion?
**A**: `AgentMemory` uses a fixed-capacity (500) LRU cache that evicts old entries in $O(1)$. Furthermore, keys are SHA-256 hashes rather than raw text, preventing memory injection attacks or leakage of private student code in diagnostic logs.

### Q6: What happens if a user instructs: "explain only, do not touch code"?
**A**: The agent's instruction post-filter inspects the user instruction. If an "explain only" intent is recognized, any synthesized patch candidate is discarded, `proposal_id` is set to `null`, and only the diagnostic explanation and step trace are returned.

### Q7: What happens if an instruction says "keep my variable names"?
**A**: The post-filter compares the AST identifiers of the original code against the patched code. If original variable names were renamed or discarded by the fixer, the patch fails post-filtering and is rejected.

### Q8: How does the agent enforce resource caps?
**A**: Three strict caps are checked on every loop iteration:
1. Maximum 5 iterations.
2. Maximum 15.0 seconds total elapsed wall-clock time.
3. Maximum 5 tool calls total.
If any boundary is exceeded, the loop terminates immediately with `status: "budget_exhausted"`.

### Q9: Can an attacker supply `../../etc/passwd` to `read_file`?
**A**: No. `read_file` delegates path resolution to `validate_workspace_filename()`, which rejects paths containing `..`, `/`, `\`, colons, null bytes, or non-whitelisted characters, returning an invalid path error.

### Q10: Why are the proposal IDs cryptographically random UUIDs?
**A**: Sequential or predictable proposal IDs would allow an attacker to guess pending proposal tokens and approve uninspected or unauthorized patches via brute force. Random UUID4 tokens prevent ID enumeration.

### Q11: How is offline deterministic evaluation verified?
**A**: `tests/agent/eval_agent.py` benchmarks 12 dev and 8 heldout fixtures without network calls or API keys (`LLM_DISABLED=1`). The heldout dataset hash is cryptographically frozen in `tests/agent/heldout_freeze.json`.

### Q12: How does the agent handle untrusted input in tracebacks?
**A**: Traceback strings are passed through the advisory Input Guard (`security/input_guard.py`) to detect prompt-injection attempts inside exception messages, and the agent treats all execution output as data rather than instructions.
