# IntelliFix Feature 2B: Whole-Program Multi-Error Detection & Multi-Fix Engine

## 1. Overview & Motivation
Standard Python compilers and runtime interpreters halt at the very first fatal defect encountered (e.g., stopping at line 2 and discarding line 15's syntax error and line 42's division by zero). Feature 2B enables IntelliFix to scan across the entire program, detect all distinct errors spanning multiple compiler/runtime layers simultaneously, and repair them iteratively across deterministic and AI stages without halting on the first failure.

---

## 2. Multi-Error Architecture Layers

```
                                +---------------------------+
                                |      Raw Python Code      |
                                +-------------+-------------+
                                              |
                                              v
             +-----------------------------------------------------------------+
             | Layer 1: Syntax Analysis (Incremental Loop + Missing Delimiters) |
             +--------------------------------+--------------------------------+
                                              |
                                              v
             +-----------------------------------------------------------------+
             | Layer 2: Static Analysis (Pure AST Scoping, ArgCount, Invariants)|
             +--------------------------------+--------------------------------+
                                              |
                                              v
             +-----------------------------------------------------------------+
             | Layer 3: Sandboxed AST Runtime Instrumentation & Cascade Poison  |
             +--------------------------------+--------------------------------+
                                              |
                                              v
             +-----------------------------------------------------------------+
             | Layer 4: Multi-Round Fix Engine (Deterministic + AI Fallback)   |
             +-----------------------------------------------------------------+
```

### Layer 1: Syntax Analysis
- Performs an incremental parse-and-neutralize scanning loop.
- Uses token-level heuristics and regex scans to pinpoint missing colons (`if`, `for`, `while`, `def`, `class`, `with`, `try`, `except`, `finally`, `elif`), unmatched delimiters (`(`, `[`, `{`), unclosed string literals, and indentation issues.
- Neutralizes detected syntax lines on a shadow copy to discover downstream syntax errors across the file.

### Layer 2: Static Analysis (AST Scoping & Call Validation)
- Scans valid AST subtrees for semantic errors that do not require runtime execution.
- Checks:
  - Global, local, and class-level variable scoping and reading before assignment (`NameError`).
  - Function definition argument counts vs invocation arguments (`TypeError`).
  - Duplicate parameter names in function signatures (`SyntaxError`).
  - Duplicate dictionary keys with conflicting literal values (`SyntaxError` / warning).
  - Break/continue outside loop contexts.
  - Return statements outside function bodies.

### Layer 3: Sandboxed Runtime Execution & Statement Instrumentation
- Runs code inside an isolated child process via `sandbox_runner.py` with resource caps (Job Objects, memory limits, timeouts).
- Uses `ast.NodeTransformer` to instrument top-level and function body statements inside safe `try...except` blocks in `mode="multi"`.
- Records:
  - Reached statement count and statement line numbers.
  - Runtime exceptions per line with actual runtime traceback information.
  - Cascade poisoning tracking: when an expression fails and assigns to a variable `v`, downstream statements reading `v` are tagged with `is_cascade: True` and `parent_error_id` referencing the original culprit.
  - Statement coverage: flags unreached functions, unreachable dead code branches, and execution stops.

### Layer 4: Multi-Round Repair Engine
- Orchestrates multi-pass iterative repairs up to `MAX_ROUNDS=8`.
- Rounds prioritize deterministic fixes first (e.g. colon restoration, regex/AST replacements, dictionary key repairs, math fixes).
- If deterministic fixes leave errors unresolved and AI is enabled, activates `NLPExplainer._apply_ai_autofix` (up to 3 LLM calls).
- Verification & Progress Acceptance:
  - Patches are verified in the sandbox after each round.
  - A round is accepted only if `unresolved_count_new < unresolved_count_old` or verified clean.
  - Backs out safely if a candidate patch introduces regressions or syntax errors.

---

## 3. UI Panel & Visualization
- Dedicated **Error List Panel** (`#panel-error-list`) in the frontend UI.
- Summary bar: Total Detected (`#stat-errors-total`), Total Fixed (`#stat-errors-fixed`), Remaining (`#stat-errors-remaining`).
- Coverage banner: Displays executed vs total statements, warning of unreached branches or functions.
- Interactive Table:
  - Columns: `#`, `Line`, `Layer`, `Error Type`, `Message`, `Fix Status`, `Action`.
  - Jump buttons (`.btn-jump-error`) smoothly scroll to and highlight the offending line in the code editor.
  - Badges color-code error severity and fix status (`fixed`, `resolved_by_parent`, `pending`, `no_fixer`).

---

## 4. API Contract & Schema Additions

The `/api/analyze` endpoint seamlessly extends the JSON payload while maintaining full backward compatibility:

| JSON Key | Type | Description |
|---|---|---|
| `errors` | `List[Dict]` | List of all detected errors with line, column, type, layer, message, fix_status, is_cascade, parent_error_id. |
| `error_count` | `int` | Total count of defects detected across all layers. |
| `fixed_count` | `int` | Number of defects resolved across repair rounds. |
| `remaining_count` | `int` | Number of unresolved defects remaining. |
| `analysis_mode` | `str` | `"multi"` when whole-program engine is active, `"single"` when `MULTI_ERROR=0`. |
| `analysis_coverage`| `Dict` | Statement coverage dictionary with reached counts, total statements, unreached lines, and stop reasons. |
| `error_list_text` | `str` | Formatted multi-line text listing detected errors and fix outcomes. |
| `fix_status` | `str` | `"applied"`, `"partially_fixed"`, `"already_clean"`, or informative stopped message. |
| `fix_source` | `str` | `"deterministic"`, `"ai"`, `"hybrid"`, `"already_clean"`, or `"none"`. |

---

## 5. Backward Compatibility & Single-Error Fallback
- Setting `MULTI_ERROR=0` instantly reverts the backend to single-error mode, matching 100% of legacy contracts, exit codes, and golden baseline responses.
- The UI safely handles responses with or without the new multi-error keys without throwing exceptions.
