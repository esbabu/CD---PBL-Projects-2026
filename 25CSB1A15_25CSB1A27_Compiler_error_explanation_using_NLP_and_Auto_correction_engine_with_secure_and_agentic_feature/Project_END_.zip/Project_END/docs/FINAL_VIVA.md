# IntelliFix Final Viva Questions & Answers

This document provides rigorous, empirical answers to anticipated examiner questions for the final defense of **IntelliFix: Automated Python Compiler Error Diagnosis & Repair Engine**.

---

### Q1: What is the primary novelty of IntelliFix compared to standard program repair tools?
**Answer**:  
Traditional automated program repair tools (e.g., GenProg, Angelix, or basic LLM fixers) either rely strictly on rigid genetic/search heuristics or pass untrusted code directly to generative models without guardrails. IntelliFix introduces a **hybrid dual-engine architecture**:
1. A **deterministic AST multi-error engine** that isolates cascades and repairs common syntax and runtime errors with 100% predictability.
2. A **4-Gate Artificial Intelligence Security Shield (AAI Shield)** that intercepts prompt injections, tool abuse, harmful code execution, and data leakage across every step of the repair pipeline.
3. A **cryptographic audit ledger** with continuous SHA-256 hash chaining, guaranteeing non-repudiation.

---

### Q2: What are the exact empirical results of your security evaluation?
**Answer**:  
We evaluated our security defense across two independent datasets:
- **Development Corpus (212 samples)**:
  - Shield OFF Attack Success Rate: **70.48%** (74/105 attacks succeeded).
  - Shield ON Attack Success Rate: **20.95%** (22/105 attacks succeeded).
  - Attack Success Rate Reduction: **-70.27%**.
  - Standard Detection Recall: **79.05%** (95% Wilson CI: [70.28%, 85.73%]).
  - ROC AUC: **0.8905**.
  - False Positive Rate: **0.00%** (0 false blocks on 107 benign programs).
- **Held-Out Corpus (90 samples)**:
  - Shield OFF ASR: **57.78%** -> Shield ON ASR: **31.11%** (**-46.15% reduction**).
  - Standard Recall: **68.89%** (95% Wilson CI: [54.34%, 80.48%]).
  - ROC AUC: **0.8666**.
  - False Positive Rate: **0.00%** (0 false blocks on 45 benign programs).

---

### Q3: Why does Shield ON still have a 20.95% (Dev) / 31.11% (Held-Out) Attack Success Rate?
**Answer**:  
This reflects the fundamental defense-in-depth design and threat model:
1. **Multi-Stage / Stealthy Phrasing**: Certain attacks in categories like `AT-08` (Resource Exhaustion) or subtly phrased obfuscations (`AT-07`) do not trigger regex prompt patterns at Gate 1 without semantic embeddings.
2. **Conservative Benign Utility Guarantee**: To ensure a **0.00% False Positive Rate** on benign programs, our Gate 1 decision threshold was set conservatively at $\text{Risk Score} \ge 60$. Lowering the threshold to 30 would block more attacks but would cause false alarms on legitimate code.
3. **Defense at Gate 3 & Sandbox**: Even if an injection slips past Gate 1, Gate 3 (Code Guard) and the subprocess sandbox prevent actual system compromise.

---

### Q4: Does the Security Shield degrade repair accuracy on benign code?
**Answer**:  
**No, zero utility degradation was observed.**  
In our 24-program offline accuracy benchmark (`results/benchmark_results.csv` across 96 evaluations):
- **Repair Success Rate**: **79.2%** (19 of 24 diverse benchmark programs repaired cleanly).
- **Utility Preserved**: **100.0%**. The programs repaired with Shield ON matched the programs repaired with Shield OFF exactly.
- **Benign Disruption**: **0%**. No benign program was falsely blocked or rejected by the shield.

---

### Q5: What is the performance and environmental overhead of your security layer?
**Answer**:  
- **Latency Overhead**: The 4-gate shield adds an average of **+2.05 ms** per request (Gate 1 regex matching, Gate 3 AST traversal, Gate 4 redaction).
- **Energy Overhead**: Measured via **CodeCarbon** (`results/energy/energy_week6.csv`), energy overhead: not reliably measured on this development machine (CodeCarbon reported not_measured_host_unsupported).

---

### Q6: How does your cryptographic audit log work?
**Answer**:  
The audit log in `results/security_log.jsonl` implements a continuous Merkle/HMAC-style hash chain:
$$H_0 = \text{SHA256}(\text{"0"}^{64} \parallel \text{CanonicalJSON}(P_0))$$
$$H_i = \text{SHA256}(H_{i-1} \parallel \text{CanonicalJSON}(P_i))$$
Where $P_i$ contains the timestamp, channel, category, risk score, decision, and redacted evidence.
If an attacker or insider edits, deletes, or inserts any entry in the file, `verify_log()` detects the discrepancy immediately at the exact line number. In our integration tests, 100% of audit entries verified cleanly with 0 breaks.

---

### Q7: What are the primary limitations of your research?
**Answer**:  
We maintain complete methodological honesty regarding three key limitations:
1. **Synthetic Attack Corpus**: All 150 attack samples across the dev and held-out corpora were authored synthetically for this project. They do not fully capture zero-day evasion techniques used by sophisticated human red teams.
2. **Subprocess Isolation vs. Kernel Containerization**: Gate 3 uses AST inspection and Python subprocess timeouts. While effective for preventing unauthorized system calls, a production multi-tenant deployment would require Linux kernel cgroups, namespaces, or Docker containers.
3. **Generalization Gap**: ASR reduction dropped from 70.27% on the development corpus to 46.15% on the held-out corpus, illustrating that novel phrasing and paraphrasing can partially evade static regex and heuristic rules.
