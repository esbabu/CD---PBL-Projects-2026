# TOC_PROJECT Architecture & File Map

**Project**: Compiler Error Explanation Using NLP & Auto-Correction Engine (INTELLIFIX)  
**Target Platform**: Python 3.10+ / 3.13 / Windows 11 / Flask  

---

## 1. End-to-End System Workflow

```
[User Python Code / File]
          │
          ▼
┌─────────────────────────────────┐
│ 1. Security Analyzer            │ ──(High Risk System Call / Shell Injection)──► Blocked (`security_blocked`)
│    (security_analyzer.py)       │
└─────────┬───────────────────────┘
          │ (Safe)
          ▼
┌─────────────────────────────────┐
│ 2. Sandbox Error Extraction     │ ──► Executes code in isolated temp directory;
│    (error_extractor.py)         │     captures stdout, stderr, traceback, AST info, and metrics.
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│ 3. IR Generation                │ ──► Constructs Intermediate Representation (IR) dict
│    (ir_generator.py)            │     including tokens, AST parent/child context, and scope variables.
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│ 4. Multi-Tier Explainer         │ ──► 1. Rule Engine (10 deterministic types)
│    (nlp_explainer.py)           │     2. Online AI Tier (Gemini Flash Lite -> Groq Qwen)
│                                 │     3. Offline Guide (25+ slot-filled error templates)
│                                 │     4. Generic Fallback
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│ 5. Auto-Correction Engine       │ ──► 1. Deterministic Fixers (Syntax, Name, Type, Attr, Import, Div, Index, Key)
│    (nlp_explainer.py)           │     2. AI-Assisted Verified Fix (if enabled)
│                                 │     3. Sandbox Verification Loop (must exit code 0)
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│ 6. Evaluation & Telemetry       │ ──► Measures execution latency, CodeCarbon/TDP energy,
│    (evaluation.py & app.py)     │     and formats results for Web Dashboard & API clients.
└─────────────────────────────────┘
```

---

## 2. File & Directory Inventory

### 2.1 Core Application Modules
| File | Role & Responsibilities |
|---|---|
| `app.py` | Flask backend application server. Exposes `/api/analyze`, `/api/files`, `/api/save`, `/api/execute`, and diagnostic `/api/version` endpoints (returning `build_marker`, `budget_enforced`, `calls_logged`, etc.). |
| `nlp_explainer.py` | Multi-tier explanation and auto-repair engine. Coordinates rule matching, LLM fallback, offline guide, deterministic AST guards, and sandbox validation. |
| `error_extractor.py` | Subprocess error extraction interface delegating to `sandbox_runner.py`. Captures raw traceback, line numbers, error types, and CodeCarbon energy metrics. |
| `sandbox_runner.py` | Unified isolated sandbox runner managing process isolation, Windows Job Objects (memory limits), timeouts, output caps, secret scrubbing, and process tree termination. |
| `sandbox_child.py` | Child process execution wrapper running under `-I -X utf8`, installing audit hooks (network, process, native code, out-of-sandbox file writes), linecache registration, and nonce reporting channel. |
| `ir_generator.py` | Converts extracted errors and AST data into a standardized JSON Intermediate Representation (IR). |
| `data_model.py` | Defines `CompilerError` data container used across pipeline stages. |
| `security_analyzer.py` | AST-based static security scanner intercepting dangerous syscalls (`os.system`, `subprocess`, socket connections). |
| `evaluation.py` | Evaluates format compliance and lexical similarity of explanations against ground-truth references. |
| `main.py` | Standalone CLI runner demonstrating pipeline analysis across benchmark test files. |
| `offline_guide.py` | Structured, offline slot-filling guide providing grounded explanations across 25+ Python error types without network access. |
| `llm_explainer.py` | LLM adapter handling prompt formatting, response parsing, and error normalization. |
| `llm_calls.py` | Centralized gateway for all external AI model calls (Gemini & Groq), managing rate limiting, quota tracking, logging, and selective budget enforcement (`LLM_BUDGET_ENFORCE=1` for benchmarks). |
| `llm_config.py` | Configuration settings, model identifiers, API keys, and provider fallback order. |
| `tokenizer.py` | Longest-match master regex lexical tokenizer covering Python 3.13 token grammar deterministically. |
| `dfa.py` | Explicit 5-tuple deterministic finite automata implementation with transition tables for identifiers, numbers, and integers. |
| `bracket_checker.py` | Pushdown Automaton (PDA) bracket checker validating (), [], {} nesting with stack bottom symbol $Z_0$ and recovery. |
| `security/input_guard.py` | Advisory prompt-injection and policy-bypass detector evaluating text across 3 channels against 5 threat families. |
| `start_app.ps1` | Managed PowerShell starter script for discovering running processes, stopping stale instances older than `app.py`, launching server, and verifying `/api/version`. |

### 2.2 Templates & Static Assets
| File / Directory | Description |
|---|---|
| `templates/index.html` | Interactive web dashboard featuring Monaco-style editor, real-time error diagnosis, AST viewer, and one-click auto-repair. |
| `templates/analytics.html` | Deep-dive telemetry dashboard displaying latency, carbon emissions, energy profiling, and security healing metrics. |
| `docs/architecture.png` | Visual system architecture diagram. |

### 2.3 Test Suites
| File | Test Focus & Scope |
|---|---|
| `tests_contract.py` | End-to-end regression harness verifying routes, JSON response keys, frontend HTML element IDs, and golden test cases. |
| `tests_server.py` | Subprocess HTTP integration tests running against a real Flask server process. |
| `tests_pagefix.py` | Unit tests for live page route error interception, UTF-8 integrity, and fixer integration. |
| `tests_autofix.py` | Unit tests for deterministic fixers (Syntax, Name, Type, Attr, Import, ZeroDivision, Index, Key) and AI safety filters. |
| `tests_autofix_more.py` | Comprehensive test suite (42 tests) for safe deterministic fixers, recursion base cases, 5-round iterative loop, stoppage messages, secondary exception handling, and strict AI acceptance invariants. |
| `tests_position.py` | Position invariance test suite (15 tests) verifying 13 core error snippets across all 14 wrappers (W0..W11), multi-error combined blocks, and AI provider fallback. |
| `tests_ai_fallback.py` | Comprehensive Phase 4 auto-fix AI fallback test suite (19 tests) verifying per-round fallback (Gemini -> Groq), 3-call cap, progress-based patch acceptance, multi-error programs (A5+A6, A6+A5), wrappers W0..W8, sha256 caching, AST invariant rejections, and excluded error stoppage. |
| `tests_llm.py` | Unit tests for AI provider failover, caching, prompt construction, tolerant parser, and selective budget enforcement. |
| `tests_offline.py` | Unit tests for offline slot-filled explanations across 25+ exception types. |
| `tests_rules.py` | Unit tests for deterministic rule engine pattern matching. |
| `tests_ui.py` | Automated browser UI and endpoint interaction test suite verifying Monaco editor and panel updates. |
| `tests_sandbox.py` | Unit and integration test suite (23 tests) for Feature 2A isolated sandbox runner, Job Objects, process cleanup, and security runtime hooks. |
| `tests_multierror.py` | Feature 2B multi-error test suite (15 tests) verifying 4-layer detection, multi-round repairs, cascade poisoning, unreached coverage, and UI contract rendering. |
| `multi_error.py` | Whole-program multi-error detection and multi-fix engine coordinating Syntax, Static AST, Sandboxed AST Instrumentation, and Multi-Round verification loops. |
| `tests_scanner.py` | AST Security Scanner test suite (29 tests) verifying Rules A–H (SEC_01 to SEC_20), alias resolution, hard negatives, and marker invariants. |
| `tests_server_hardening.py` | Server hardening test suite (17 tests) verifying WORKSPACE_DIR confinement, traversal rejection, size caps, host/origin validation, and concurrency semaphore. |
| `tests_policy.py` | Feature 13a security policy test suite (12 tests) verifying schema validation, cryptographic hash matching, copy tampering failure, and threat model integrity. |
| `tests_tokenizer.py` | Feature 5 tokenizer test suite (14 tests) verifying lexical token generation, indentation, line/col numbers, and comparison with Python's `tokenize`. |
| `tests_dfa.py` | Feature 5 DFA test suite (5 tests) verifying IDENT, NUMBER, INT_UNDERSCORES against regex matches across 89,000+ test strings. |
| `tests_bracket.py` | Feature 6 PDA bracket test suite (7 tests) verifying balance, recovery, and 350+ random mutants against compile() syntax errors. |
| `tests_input_guard.py` | Feature 13b Input Guard test suite (10 tests) verifying 5 threat families, negation suppression, obfuscation recovery, and ReDoS immunity. |
| `tests_week3_integration.py` | Week 3 full integration suite (10 tests) verifying all Week 3 components and API routes end-to-end. |
| `security/policy.json` | Machine-readable security policy file specifying immutable rules, action tiers, and risk weight placeholders. |
| `security/policy_loader.py` | Clean policy loader and SHA-256 integrity verifier with zero import-time side effects. |
| `test_case_large.py` | Performance and resilience test for large-scale Python code bases. |

### 2.4 Audit & Benchmarking Tools
| Directory / File | Description |
|---|---|
| `audit/self_check.py` | Automated compliance audit evaluating all 29 strict project acceptance criteria. |
| `audit/SERVERCHECK.md` | Forensic audit log and evidence comparing live server processes against test client. |
| `audit/MULTI_ERROR_ADDENDUM.md` | Feature 2B empirical benchmark evaluation across 200 composed programs, 20 cascades, and 20 unreached code snippets. |
| `audit/FINAL_REPORT.md` | Comprehensive evaluation report with historical benchmark metrics and delivery sign-offs. |
| `audit/WEEK3_PROGRESS.md` | Incremental execution and verification log for all Week 3 stages. |
| `audit/WEEK3_REPORT.md` | Final forensic evaluation report and proof matrix for Week 3 delivery. |
| `benchmark/run_benchmark.py` | Offline and online benchmark runner evaluating accuracy and auto-repair across 580 test cases. |
| `benchmark/run_multierror_benchmark.py` | Benchmark runner evaluating whole-program multi-error detection and multi-fix accuracy vs single-error baselines. |
| `benchmark/multierror_results.json` | Benchmark metrics data for Feature 2B multi-error evaluation. |
| `benchmark/golden_before.json` | Snapshot of golden system behaviors across routes, HTML IDs, and standard error snippets. |
| `benchmark/golden_f2b_before.json` | Snapshot of golden baseline responses before Feature 2B whole-program multi-error implementation. |
| `docs/MULTI_ERROR.md` | Architectural specification and implementation details for Feature 2B whole-program multi-error engine. |
| `docs/SCANNER.md` | Complete rule catalog, alias handling guide, limitations, and viva Q&A for Feature 4 AST Security Scanner. |
| `docs/SERVER_HARDENING.md` | Attack surface matrix, protections, limitations, and viva Q&A for Feature 3 Server Hardening. |
| `docs/THREAT_MODEL.md` | Formal threat model detailing 8 assets, 4 actors, 4 attack channels, AT-01..AT-16 attack catalog, and coverage matrix. |
| `docs/WEEK2_DEMO.md` | 5-minute live demonstration script with exact inputs and 10 viva exam Q&As. |
| `docs/TOKENIZER.md` | Feature 5 Lexical Tokenizer specification, limitations, and 8 viva Q&As. |
| `docs/DFA.md` | Feature 5 Deterministic Finite Automata 5-tuple specs, transition tables, diagrams, and 8 viva Q&As. |
| `docs/PDA.md` | Feature 6 Pushdown Automaton bracket checker specification, transitions, and 8 viva Q&As. |
| `docs/INPUT_GUARD.md` | Feature 13b Advisory Input Guard specification, threat model, evaluation tables, and 8 viva Q&As. |
| `docs/WEEK3_DEMO.md` | Step-by-step 5-minute live demonstration script for Week 3 features. |
| `ROLLBACK.md` | Complete inventory of all archived `*_before_*` backup files with PowerShell restoration commands. |

### 2.5 Backup Files (`*_before_*`)
Every file modified during enhancement phases is strictly preserved under `<name>_before_<phase>.<ext>` (e.g. `app_before_capfix.py`, `app_before_f2b.py`) to provide a verifiable audit trail and instant rollback capability.

