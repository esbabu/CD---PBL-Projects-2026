# Feature 2A: Sandboxed Code Runner

## Overview & Architecture

The **IntelliFix Sandboxed Code Runner** (`sandbox_runner.py` and `sandbox_child.py`) provides an isolated, resource-constrained, and unified execution environment for running untrusted user Python scripts and candidate patch fixes.

Every component in the project that requires code execution—the error extractor, auto-fix verification loop, live API runner, and benchmarking suite—routes exclusively through the sandbox runner instead of executing untrusted code directly inside the Flask server process.

```
+-------------------------------------------------------------------------+
|                              FLASK SERVER                               |
|   /api/analyze  |  /api/execute  |  nlp_explainer.py  |  run_benchmark   |
+------------------------------------+------------------------------------+
                                     |
                                     v run_in_sandbox(code, limits)
+-------------------------------------------------------------------------+
|                    PARENT PROCESS (sandbox_runner.py)                   |
|  * Clean minimal environment (no secrets/API keys passed)               |
|  * Per-run isolated temp directory (TEMP/TMP set to sandbox)           |
|  * Cryptographic nonce generation for secure result channel             |
|  * Windows Job Object resource limits (Memory / Kill-on-close)          |
|  * Threaded pipe readers with combined output byte limits               |
|  * Process tree termination watchdog (zero orphan processes)            |
+------------------------------------+------------------------------------+
                                     |
                                     v sys.executable -I -X utf8
+-------------------------------------------------------------------------+
|                     CHILD PROCESS (sandbox_child.py)                    |
|  * Runs under isolated mode (-I) ignoring user site-packages/PYTHON*    |
|  * Installs runtime audit hooks (sys.addaudithook)                      |
|      - Blocks socket connect/bind/send (violation: network)             |
|      - Blocks subprocess / os.system / spawn (violation: process)       |
|      - Blocks ctypes / dlopen (violation: native_code)                  |
|      - Blocks file mutations outside temp folder (file_write_outside)   |
|  * linecache source registration: tracebacks show offending lines       |
|  * Reports structured JSON via ---SANDBOX_RESULT_<NONCE>--- channel     |
+-------------------------------------------------------------------------+
```

---

## 10-Line Beginner Explanation (Viva Ready)

1. When a student submits Python code or our engine verifies an auto-fix patch, we must never run untrusted code directly inside the web server.
2. The sandbox runner spawns a separate child Python process with isolated flags (`-I -X utf8`) and a clean environment.
3. Host secrets like `GEMINI_API_KEY` and `GROQ_API_KEY` are scrubbed and never passed to the child process.
4. Each execution runs inside a fresh, temporary working folder that is deleted immediately after execution completes.
5. We set a 5-second wall-clock timeout and kill the entire process tree if the code contains an infinite loop.
6. On Windows, we assign the child process to a Windows Job Object configured to enforce a 256 MB memory limit and kill-on-job-close.
7. Output stream readers terminate the child if cumulative stdout/stderr output exceeds 256 KB, preventing memory flooding.
8. Python audit hooks (`sys.addaudithook`) intercept unauthorized actions like network connections, process spawns, and writing outside the sandbox.
9. Execution results are transmitted back to the parent through a tamper-resistant channel using a per-run cryptographic nonce.
10. The sandbox fails closed: if process creation fails, it returns `sandbox_failure` and never falls back to server-side `exec()`.

---

## Sandbox Limits & Defaults

| Limit | Environment Variable | Default Value | Description |
|---|---|---|---|
| **Execution Timeout** | `SANDBOX_TIMEOUT` | `5.0` seconds | Hard wall-clock limit; terminates process tree on expiration (`status: timeout`). |
| **Memory Limit** | `SANDBOX_MEMORY_MB` | `256` MB | Enforced via Windows Job Object (`JOBOBJECT_EXTENDED_LIMIT_INFORMATION`) and psutil RSS watchdog (`status: memory_exceeded`). |
| **Output Cap** | `SANDBOX_MAX_OUTPUT_KB` | `256` KB | Combined stdout and stderr byte limit to prevent buffer exhaustion (`status: output_limit`). |
| **CPU Time** | Optional parameter | `None` | User-mode CPU execution time limit configured in Job Object. |

---

## Windows Job Objects in Simple Words

A Windows **Job Object** is an operating system kernel construct that groups one or more processes together so they can be managed and constrained as a single unit.

In IntelliFix:
- We create a Job Object using Windows `kernel32.CreateJobObjectW`.
- We configure `JOBOBJECT_EXTENDED_LIMIT_INFORMATION` to set `ProcessMemoryLimit` and `JobMemoryLimit` to 256 MB.
- We set the `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` flag, guaranteeing that if the parent terminates or closes the job handle, all child processes in the job are automatically terminated by the Windows kernel.
- When the child process starts, we assign its handle via `AssignProcessToJobObject`.

---

## Blocked Behaviors & Runtime Guards

Python 3 runtime audit hooks (`sys.addaudithook`) provide defense-in-depth inside the child process:

1. **Network Activity (`violation: network`)**:
   - Blocks `socket.connect`, `socket.bind`, `socket.sendto`, `socket.connect_ex`.
   - Raises `PermissionError` and records security violation.
2. **Process Spawning (`violation: process`)**:
   - Blocks `subprocess.Popen`, `os.system`, `os.posix_spawn`, `os.spawn*`, `os.startfile`, `os.exec*`.
3. **Native Code Loading (`violation: native_code`)**:
   - Blocks `ctypes.dlopen`, `ctypes.dlsym`, `_ctypes.dlopen`.
4. **File Mutation Outside Directory (`violation: file_write_outside`)**:
   - Blocks `open(..., 'w'|'a'|'+')`, `os.remove`, `os.unlink`, `os.rmdir`, `os.mkdir`, `os.rename`, `os.replace` targeting any path outside the temporary sandbox directory.
   - Writes and mutations *inside* the temporary sandbox directory remain permitted.

---

## Honest Limitations

> [!IMPORTANT]
> **Defense-in-Depth vs. Kernel Security Boundary**:
> 1. **Not a Full Kernel Sandbox**: User-space Python audit hooks and Job Objects provide practical defense-in-depth for educational and benchmarking usage, but do not provide hypervisor-level isolation.
> 2. **Audit Hook Bypassability**: Extremely sophisticated native exploits or direct memory manipulation could theoretically alter Python runtime structures.
> 3. **No Kernel-Level Network Packet Filter**: Network blocking is enforced at the Python standard library audit layer, not via Windows Firewall / eBPF kernel packet filters.
> 4. **Disk Quotas**: Disk space usage inside the temporary directory is cleaned upon exit, but not strictly quota-limited during active execution.
> 5. **Recommended Production Step**: For commercial multi-tenant hosting, the recommended next step is running code inside Linux microVMs (e.g. AWS Firecracker) or secure containers (Docker with gVisor/seccomp).

---

## 8 Likely Viva Questions & Short Answers

**Q1: Why can't we just use Python's built-in `exec()` with a restricted dictionary?**
*Answer:* `exec()` runs inside the server process. A user script could execute an infinite loop, allocate all server RAM, crash the Flask server, or escape the namespace through object traversal (`().__class__.__bases__[0].__subclasses__()`). Process isolation is mandatory.

**Q2: How does the sandbox guarantee that API keys are not leaked?**
*Answer:* The parent process constructs an explicit allow-list environment containing only standard OS system paths (`SYSTEMROOT`, `PATH`, `WINDIR`, `TEMP`). It does not copy `os.environ`, so `GEMINI_API_KEY` and `GROQ_API_KEY` never enter the child process.

**Q3: How does the parent process prevent output injection or result forgery?**
*Answer:* The parent generates a 32-character cryptographic random hex nonce for each execution. The child outputs structured JSON wrapped in unique delimiters containing this nonce. The child clears the nonce from `sys.argv` and `os.environ` so user code cannot discover or forge the delimiters.

**Q4: How are infinite loops handled?**
*Answer:* The parent monitors the child with `proc.wait(timeout=5.0)`. If expired, it triggers `_kill_process_tree` which terminates all child and descendant processes using `psutil`, preventing orphan processes.

**Q5: How does the sandbox preserve the failing line in tracebacks?**
*Answer:* `sandbox_child.py` registers the user source code in Python's `linecache.cache["<string>"]`. When an exception is formatted, Python uses linecache to fetch and display the exact offending source line and carets.

**Q6: What happens if user code calls `input()`?**
*Answer:* The child process is spawned with `stdin=subprocess.DEVNULL`. Calling `input()` raises an immediate `EOFError` instead of blocking or hanging the server.

**Q7: How is memory limited on Windows?**
*Answer:* We use Windows Job Objects via `ctypes` (`JOBOBJECT_EXTENDED_LIMIT_INFORMATION`) with `JOB_OBJECT_LIMIT_PROCESS_MEMORY` and `JOB_OBJECT_LIMIT_JOB_MEMORY` set to 256 MB, supplemented by a 50ms psutil RSS watchdog thread.

**Q8: What is the difference between the Static Security Analyzer and Sandbox Runtime Guards?**
*Answer:* The Static Security Analyzer (`security_analyzer.py`) scans code AST before execution and blocks known unsafe patterns like `os.system` without running the code (`security_blocked`). Sandbox Runtime Guards (`sandbox_child.py` audit hooks) catch dynamic and runtime violations during execution (`violation`).
