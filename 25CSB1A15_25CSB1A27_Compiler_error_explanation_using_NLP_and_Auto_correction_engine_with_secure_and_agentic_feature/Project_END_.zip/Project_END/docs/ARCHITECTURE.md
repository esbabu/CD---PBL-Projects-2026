# IntelliFix System Architecture: Multi-Gate AAI Security Shield

## 1. Executive Summary & Problem Formulation

Modern automated program repair engines increasingly rely on Large Language Models (LLMs) and autonomous agents to diagnose and fix compilation and runtime errors. While powerful, autonomous agentic systems introduce severe security vulnerabilities:
1. **Prompt Injection & Jailbreaks**: Attacker code or comments can subvert system instructions and force the agent to ignore safety policies.
2. **Arbitrary Code Execution**: Fixes proposed by agents or synthesizers can contain malicious payloads (`os.system`, reverse shells, socket exfiltration).
3. **Privilege Escalation via Tool Abuse**: Agent tool access can be abused to overwrite critical system files or exfiltrate environment secrets.
4. **Secret Exfiltration in Model Output**: Error messages or explanations can inadvertently reveal developer credentials, API tokens, or internal paths.

**IntelliFix** solves this dilemma by coupling a deterministic multi-error AST repair engine with an autonomous **4-Gate Artificial Intelligence Security Shield (AAI Shield)** and a cryptographic audit trail.

---

## 2. Existing vs. Proposed Architecture

### 2.1 Baseline Architecture (Pre-Shield)
Prior to Week 5, compiler repair engines operated with minimal defense boundaries:
- **Input Flow**: User code passed directly to parser and sandbox without intent scanning.
- **Agent Capabilities**: LLM was invoked with open-ended tool definitions; tools executed immediately without capability gates or human approval.
- **Repair Verification**: Generated code was written directly to disk or executed in basic subprocesses without static AST restriction.
- **Output Channel**: Diagnostics and stdout were returned verbatim to the UI.

### 2.2 Proposed 4-Gate AAI Shield Architecture
The AAI Shield implements strict **defense-in-depth**, interposing four independent verification gates across every phase of the repair lifecycle:

![IntelliFix 4-Gate Architecture](diagrams/architecture_overview.svg)

```
[Client (UI / CLI)]
       │
       ▼
 [GATE 1: Policy & Input Guard] ──(Risk Score > 60: BLOCK)──► [Audit Log (Chain)]
       │ (ALLOW)
       ▼
 [Orchestration: Multi-Error Engine / Agent Studio]
       │
       ├─► [GATE 2: Tool & Capability Guard] ──(Mutating tool / unapproved)──► [Human Approval]
       │
       ├─► [GATE 3: Code & AST Safety Guard] ──(Disallowed imports / eval)──► [Block Sandbox]
       │
       ▼
 [Sandbox Execution: Isolated Subprocess]
       │
       ▼
 [GATE 4: Output & Leakage Guard] ──(API Keys / Tokens / PII)──► [Redaction Scrubbing]
       │
       ▼
[Response to User / IDE]
```

---

## 3. Detailed Gate Specifications

### Gate 1: Input & Policy Guard (`security/policy_engine.py`)
- **Mission**: Detect adversarial intent before prompt reaches the LLM or AST parser.
- **Techniques**:
  - Regular expression heuristic patterns for prompt injection (`SYSTEM OVERRIDE`, `DAN Mode`, `ignore previous instructions`).
  - Threat taxonomy categories: `AT-01` (Prompt Injection), `AT-02` (System Instruction Override), `AT-03` (Role Jailbreak), `AT-04` (Tool Hijacking), `AT-05` (Approval Bypass), `AT-06` (Secret Exfiltration), `AT-07` (Code Obfuscation), `AT-08` (Resource Exhaustion).
  - Risk engine score aggregation (0–100 scale). Verdict threshold:
    - **Score 0–29**: `ALLOW`
    - **Score 30–59**: `WARN` (Logged to audit trail; execution permitted with monitored constraints)
    - **Score 60–100**: `BLOCK` (Request rejected immediately with HTTP 200/CLI exit code 2)

### Gate 2: Tool & Capability Guard (`security/tool_guard.py`)
- **Mission**: Prevent privilege escalation and unapproved mutating actions by LLM agents.
- **Techniques**:
  - Tool permission matrix: Read-only tools (`read_file`, `list_workspace`) vs. Mutating tools (`write_file`, `execute_command`).
  - Cryptographic one-time approval token: Any mutating tool invocation requires explicit human approval via `/api/agent/approve`.
  - Directory boundary containment: Prevents directory traversal (`..`), symlink attacks, and access outside `WORKSPACE_DIR`.

### Gate 3: Code & AST Execution Guard (`security/code_guard.py`)
- **Mission**: Ensure generated or repaired Python code is safe prior to sandbox execution.
- **Techniques**:
  - Abstract Syntax Tree (AST) node visitor inspecting all `Import`, `ImportFrom`, `Call`, and attribute accesses.
  - Forbidden API blacklist: `os.system`, `subprocess.Popen`, `socket`, `shutil.rmtree`, `ctypes`, `builtins.__import__`.
  - Dynamic execution blocker: Rejects `eval()`, `exec()`, `compile()`, and base64-encoded string execution.
  - Bytecode disassembler analysis (`dis.get_instructions`) to catch obfuscated attribute lookups (`getattr(os, "sys"+"tem")`).

### Gate 4: Output & Leakage Guard (`security/output_guard.py`)
- **Mission**: Prevent sensitive data leakage in model diagnostics, explanations, and tool outputs.
- **Techniques**:
  - High-entropy pattern matching for API credentials:
    - Google Gemini keys (`AIzaSy...`)
    - Groq API keys (`gsk_...`)
    - Generic Bearer tokens, JWT headers, and private SSH/RSA keys
  - Personal Identifiable Information (PII) filters: Email addresses, IP addresses, credit card formats.
  - In-place sanitization: Sensitive substrings are replaced with `[REDACTED_API_KEY]` or `[REDACTED_SECRET]` without breaking response formatting.

---

## 4. Cryptographic Audit Log Chain (`security/audit_log.py`)

All security decisions across all four gates are committed to an append-only, tamper-evident log in `results/security_log.jsonl`.

### Mathematical Construction:
$$\text{Entry}_0: \text{hash}_0 = \text{SHA256}(\text{GENESIS} \parallel \text{Payload}_0)$$
$$\text{Entry}_i: \text{hash}_i = \text{SHA256}(\text{hash}_{i-1} \parallel \text{Payload}_i)$$

Where:
- $\text{GENESIS} = \text{"0"}^{64}$
- $\text{Payload}_i$ is the canonical, sorted, unspaced JSON serialization of `{timestamp, channel, category, risk_score, decision, evidence, action_attempted}`.

### Properties:
1. **Append-Only**: Modifying, inserting, or deleting any historical line invalidates all subsequent hashes.
2. **Non-Repudiation**: Decisions can be verified programmatically at runtime using `verify_log()`.
3. **Zero Secrets in Evidence**: Evidence strings are scrubbed by Gate 4 before being committed to disk.

---

## 5. Architectural Performance & Empirical Trade-Offs

| Dimension | Shield OFF | Shield ON | Impact / Trade-off |
| :--- | :---: | :---: | :--- |
| **Attack Success Rate (Dev)** | 70.48% (74/105) | 20.95% (22/105) | **-70.27% attack reduction** |
| **Attack Success Rate (Held-out)** | 57.78% (26/45) | 31.11% (14/45) | **-46.15% attack reduction** |
| **Benign Repair Success** | 79.2% (19/24) | 79.2% (19/24) | **100.0% utility preserved** |
| **False Positive Rate** | 0.0% (0/107) | 0.0% (0/107) | **Zero benign code blocked** |
| **Mean Latency Overhead** | Baseline | +2.05 ms / request | Minimal CPU impact |
| **Energy Consumption** | ~0.00010 kWh | ~0.00010 kWh | No perceptible carbon overhead |

---

## 6. Honest Limitations & Grounding

1. **Single-Author Synthetic Attack Corpus**: Attacks were authored by the project developers for testing purposes. While comprehensive across 15 attack categories (AT-01 through AT-15), real-world zero-day attacks may exhibit multi-stage evasion techniques not present in synthetic benchmarks.
2. **Subprocess Isolation vs. Kernel Containerization**: Gate 3 relies on AST/bytecode static guards and Python subprocess timeouts. It does not replace OS-level kernel cgroups, Docker, or seccomp isolation in high-concurrency production deployments.
3. **Commercial LLM Prompt Robustness**: Live prompts with live commercial APIs were evaluated under offline snapshot conditions; live multi-turn jailbreaking attacks against commercial endpoints may exhibit model-specific non-determinism.
