"""tests_scanner.py - Comprehensive Unit & Integration Tests for Feature 4 Security Scanner.

Tests:
1. Malicious Fixtures (all rule families A-H, verifying rule_id, severity, line)
2. Alias & Import Resolution (import as, from import, shadowed names)
3. Hard Negatives (valid constructs that must yield 0 findings)
4. Combined Exfiltration Rule (fires only when both personal read & network call are present)
5. Unparseable Code Fallback (SyntaxError yields partial_scan, no crash)
6. Non-Execution Invariant Proof (scanner never executes user code)
7. scan_gate Policy & SCAN_BLOCK_LEVEL Thresholds
8. Healed-Code Scan in Repair Loop & Multi-Error Engine
9. Flask API Endpoints (/api/analyze, /api/execute security gating)
10. UI Contract Validation (index.html compatibility)
"""

import os
import sys
import unittest
from unittest.mock import patch, MagicMock

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import security_analyzer
import app as flask_app
import nlp_explainer
import multi_error

FIXTURES_DIR = os.path.join(_ROOT, "tests", "security", "scanner")


class TestSecurityScannerFixtures(unittest.TestCase):
    """Verifies that all 20 rule families detect their target vulnerabilities."""

    def _read_fixture(self, name: str) -> str:
        with open(os.path.join(FIXTURES_DIR, name), "r", encoding="utf-8") as f:
            return f.read()

    def test_rule_01_command_injection(self):
        code = self._read_fixture("fixture_01_cmd_inj.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_01_CMD_INJECTION", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_01_CMD_INJECTION")
        self.assertEqual(target["severity"], "CRITICAL")
        self.assertEqual(target["line"], 2)

    def test_rule_02_eval_exec(self):
        code = self._read_fixture("fixture_02_eval_exec.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_02_CODE_EXECUTION", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_02_CODE_EXECUTION")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 2)

    def test_rule_03_mktemp(self):
        code = self._read_fixture("fixture_03_mktemp.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_03_INSECURE_TEMP", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_03_INSECURE_TEMP")
        self.assertEqual(target["severity"], "MEDIUM")
        self.assertEqual(target["line"], 2)

    def test_rule_04_hardcoded_secret(self):
        code = self._read_fixture("fixture_04_secret.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_04_HARDCODED_SECRET", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_04_HARDCODED_SECRET")
        self.assertEqual(target["severity"], "LOW")
        self.assertEqual(target["line"], 1)
        # Ensure secret value is NOT leaked in evidence
        self.assertNotIn("super_secret_token", target["evidence"])

    def test_rule_05_subprocess_call(self):
        code = self._read_fixture("fixture_05_subprocess.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_05_SUBPROCESS_CALL", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_05_SUBPROCESS_CALL")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 2)

    def test_rule_06_subprocess_shell_true(self):
        code = self._read_fixture("fixture_06_subprocess_shell.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_06_SUBPROCESS_SHELL_TRUE", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_06_SUBPROCESS_SHELL_TRUE")
        self.assertEqual(target["severity"], "CRITICAL")
        self.assertEqual(target["line"], 2)

    def test_rule_07_os_popen_exec_spawn(self):
        code = self._read_fixture("fixture_07_popen.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_07_OS_EXEC_SPAWN_POPEN", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_07_OS_EXEC_SPAWN_POPEN")
        self.assertEqual(target["severity"], "CRITICAL")
        self.assertEqual(target["line"], 2)

    def test_rule_08_unsafe_deserialization(self):
        code = self._read_fixture("fixture_08_pickle.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_08_UNSAFE_DESERIALIZATION", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_08_UNSAFE_DESERIALIZATION")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 2)

    def test_rule_09_network_access(self):
        code = self._read_fixture("fixture_09_network.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_09_NETWORK_CALL", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_09_NETWORK_CALL")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 2)

    def test_rule_10_sql_injection(self):
        code = self._read_fixture("fixture_10_sql.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_10_SQL_INJECTION", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_10_SQL_INJECTION")
        self.assertEqual(target["severity"], "MEDIUM")
        self.assertEqual(target["line"], 2)

    def test_rule_11_destructive_file_ops(self):
        code = self._read_fixture("fixture_11_destructive_file.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_11_RISKY_FILE_OPS", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_11_RISKY_FILE_OPS")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 2)

    def test_rule_12_unsafe_file_open(self):
        code = self._read_fixture("fixture_12_unsafe_open.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_12_OPEN_ABSOLUTE_OR_TRAVERSAL", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_12_OPEN_ABSOLUTE_OR_TRAVERSAL")
        self.assertEqual(target["severity"], "MEDIUM")
        self.assertEqual(target["line"], 1)

    def test_rule_13_env_read(self):
        code = self._read_fixture("fixture_13_env_read.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_13_ENV_READ", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_13_ENV_READ")
        self.assertEqual(target["severity"], "MEDIUM")
        self.assertEqual(target["line"], 2)

    def test_rule_14_home_secret(self):
        code = self._read_fixture("fixture_14_home_secret.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_14_HOME_SECRETS_PATH", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_14_HOME_SECRETS_PATH")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 1)

    def test_rule_15_dynamic_import(self):
        code = self._read_fixture("fixture_15_dynamic_import.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_15_DYNAMIC_IMPORT", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_15_DYNAMIC_IMPORT")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 1)

    def test_rule_16_dynamic_getattr(self):
        code = self._read_fixture("fixture_16_dynamic_getattr.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_16_DYNAMIC_GETATTR", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_16_DYNAMIC_GETATTR")
        self.assertEqual(target["severity"], "MEDIUM")
        self.assertEqual(target["line"], 2)

    def test_rule_17_decode_exec(self):
        code = self._read_fixture("fixture_17_decode_exec.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_17_DECODE_EXEC", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_17_DECODE_EXEC")
        self.assertEqual(target["severity"], "CRITICAL")
        self.assertEqual(target["line"], 2)

    def test_rule_18_obfuscated_string(self):
        code = self._read_fixture("fixture_18_obfuscated_str.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_18_OBFUSCATED_STRING", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_18_OBFUSCATED_STRING")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 1)

    def test_rule_19_ctypes(self):
        code = self._read_fixture("fixture_19_ctypes.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_19_CTYPES", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_19_CTYPES")
        self.assertEqual(target["severity"], "HIGH")
        self.assertEqual(target["line"], 1)

    def test_rule_20_exfiltration(self):
        code = self._read_fixture("fixture_20_exfiltration.py")
        findings = security_analyzer.scan_code(code)
        rule_ids = [f["rule_id"] for f in findings]
        self.assertIn("SEC_20_EXFILTRATION", rule_ids)
        target = next(f for f in findings if f["rule_id"] == "SEC_20_EXFILTRATION")
        self.assertEqual(target["severity"], "CRITICAL")
        self.assertTrue(target["default_block"])


class TestSecurityScannerAdvanced(unittest.TestCase):
    """Tests alias resolution, hard negatives, invariants, and fallback parsing."""

    def test_alias_resolution(self):
        # 1. import os as o; o.system(...)
        code1 = "import os as o\no.system('id')\n"
        findings1 = security_analyzer.scan_code(code1)
        self.assertTrue(any(f["rule_id"] == "SEC_01_CMD_INJECTION" for f in findings1))

        # 2. from os import system as s; s(...)
        code2 = "from os import system as s\ns('id')\n"
        findings2 = security_analyzer.scan_code(code2)
        self.assertTrue(any(f["rule_id"] == "SEC_01_CMD_INJECTION" for f in findings2))

        # 3. import subprocess as sp; sp.run(..., shell=True)
        code3 = "import subprocess as sp\nsp.run('whoami', shell=True)\n"
        findings3 = security_analyzer.scan_code(code3)
        self.assertTrue(any(f["rule_id"] == "SEC_06_SUBPROCESS_SHELL_TRUE" for f in findings3))

    def test_hard_negatives(self):
        """Hard negatives must produce ZERO security findings."""
        with open(os.path.join(FIXTURES_DIR, "fixture_hard_negative.py"), "r", encoding="utf-8") as f:
            code = f.read()
        findings = security_analyzer.scan_code(code)
        self.assertEqual(findings, [], f"Expected 0 findings for hard negatives, got: {findings}")

    def test_exfiltration_requires_both_parts(self):
        """Rule 20 should only trigger if BOTH environment read and network call exist."""
        env_only = "import os\nx = os.environ.get('KEY')\n"
        f_env = security_analyzer.scan_code(env_only)
        self.assertFalse(any(f["rule_id"] == "SEC_20_EXFILTRATION" for f in f_env))
        self.assertTrue(any(f["rule_id"] == "SEC_13_ENV_READ" for f in f_env))

        net_only = "import requests\nrequests.get('https://google.com')\n"
        f_net = security_analyzer.scan_code(net_only)
        self.assertFalse(any(f["rule_id"] == "SEC_20_EXFILTRATION" for f in f_net))
        self.assertTrue(any(f["rule_id"] == "SEC_09_NETWORK_CALL" for f in f_net))

    def test_unparseable_code_fallback(self):
        """SyntaxError fallback performs line-based check and sets partial_scan."""
        with open(os.path.join(FIXTURES_DIR, "fixture_unparseable.py"), "r", encoding="utf-8") as f:
            code = f.read()
        findings = security_analyzer.scan_code(code)
        self.assertTrue(len(findings) > 0)
        self.assertTrue(any(f.get("partial_scan") is True for f in findings))
        self.assertTrue(any(f["rule_id"] == "SEC_01_CMD_INJECTION" for f in findings))

    def test_scanner_never_executes_code(self):
        """Proves that scanning malicious code never executes it."""
        marker_file = os.path.join(_ROOT, "MARKER_EXECUTED.txt")
        if os.path.exists(marker_file):
            os.remove(marker_file)

        with open(os.path.join(FIXTURES_DIR, "fixture_never_executes.py"), "r", encoding="utf-8") as f:
            code = f.read()

        _ = security_analyzer.scan_code(code)
        _ = security_analyzer.scan_gate(code)

        self.assertFalse(
            os.path.exists(marker_file),
            "CRITICAL SECURITY FAILURE: Scanner executed the code being scanned!"
        )

    def test_scan_gate_and_scan_block_level(self):
        """Tests scan_gate default blocking and configurable threshold."""
        # 1. Critical blocks by default
        gate_crit = security_analyzer.scan_gate("import os\nos.system('whoami')\n")
        self.assertFalse(gate_crit["allowed"])
        self.assertTrue(gate_crit["blocked"])

        # 2. Medium (env read) does NOT block by default
        gate_med = security_analyzer.scan_gate("import os\nx = os.environ.get('USER')\n")
        self.assertTrue(gate_med["allowed"])
        self.assertFalse(gate_med["blocked"])

        # 3. Setting SCAN_BLOCK_LEVEL=MEDIUM blocks Medium findings
        with patch.dict(os.environ, {"SCAN_BLOCK_LEVEL": "MEDIUM"}):
            gate_med_blocked = security_analyzer.scan_gate("import os\nx = os.environ.get('USER')\n")
            self.assertFalse(gate_med_blocked["allowed"])
            self.assertTrue(gate_med_blocked["blocked"])


class TestSecurityScannerIntegration(unittest.TestCase):
    """Tests integration of scanner into repair loop, multi-error engine, and Flask server."""

    def test_repair_loop_rejects_malicious_fix(self):
        """_validate_patch_acceptance must reject candidate introducing security vulnerability."""
        orig_code = "x = 10\nprint(y)\n"
        malicious_cand = "x = 10\nimport os\nos.system('calc')\nprint(10)\n"
        clean_cand = "x = 10\ny = 20\nprint(y)\n"

        is_valid_mal, reason_mal = nlp_explainer._validate_patch_acceptance(
            orig_code, malicious_cand, "NameError", "name 'y' is not defined", 2
        )
        self.assertFalse(is_valid_mal)
        self.assertIn("security risk", reason_mal.lower())

        is_valid_clean, _ = nlp_explainer._validate_patch_acceptance(
            orig_code, clean_cand, "NameError", "name 'y' is not defined", 2
        )
        self.assertTrue(is_valid_clean)

    def test_flask_api_blocks_critical_code(self):
        """Flask /api/analyze and /api/execute must block critical code without running sandbox."""
        client = flask_app.app.test_client()
        bad_code = "import os\nos.system('rm -rf /')\n"

        # 1. /api/analyze
        resp_analyze = client.post("/api/analyze", json={"code": bad_code})
        self.assertEqual(resp_analyze.status_code, 200)
        data_analyze = resp_analyze.get_json()
        self.assertEqual(data_analyze["status"], "security_blocked")
        self.assertTrue(data_analyze.get("scan_blocked"))
        self.assertTrue(len(data_analyze.get("scan_findings", [])) > 0)

        # 2. /api/execute
        resp_exec = client.post("/api/execute", json={"code": bad_code})
        self.assertEqual(resp_exec.status_code, 200)
        data_exec = resp_exec.get_json()
        self.assertEqual(data_exec["status"], "security_blocked")
        self.assertEqual(data_exec["sandbox_status"], "blocked")
        self.assertTrue(data_exec.get("scan_blocked"))

    def test_ui_contract_handling(self):
        """Ensures templates/index.html contains expected elements and no broken references."""
        idx_path = os.path.join(_ROOT, "templates", "index.html")
        with open(idx_path, "r", encoding="utf-8") as f:
            html = f.read()
        self.assertIn("security_blocked", html)
        self.assertIn("btn-analyze", html)
        self.assertIn("btn-execute", html)


if __name__ == "__main__":
    unittest.main()
