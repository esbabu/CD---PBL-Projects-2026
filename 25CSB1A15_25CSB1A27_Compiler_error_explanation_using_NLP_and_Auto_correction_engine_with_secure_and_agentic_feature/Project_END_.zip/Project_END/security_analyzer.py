"""security_analyzer.py - AST-based Static Security Scanner for IntelliFix.

Implements whole-program static security analysis with alias tracking,
granular rule families (A through H), confidence scoring, and configurable
gating (scan_gate) without executing or importing user code.
"""

import ast
import os
import re
from typing import Dict, Any, List, Optional, Set, Tuple

SEVERITY_RANKS = {
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4
}


def get_scan_block_level() -> Optional[str]:
    """Retrieves active threshold from environment without import-time side effects."""
    lvl = os.environ.get("SCAN_BLOCK_LEVEL")
    if lvl and lvl.upper() in SEVERITY_RANKS:
        return lvl.upper()
    return None


class SecurityAnalyzer:
    """Static AST security scanner for Python source code."""

    def __init__(self):
        pass

    def scan_code(self, code_string: str) -> List[Dict[str, Any]]:
        """Parses the code string and returns a list of detected vulnerabilities."""
        return scan_code(code_string)


MAX_SAFE_NESTING_DEPTH: int = 128


def check_nesting_depth(code: str, max_depth: int = MAX_SAFE_NESTING_DEPTH) -> bool:
    """Returns True if nesting of brackets does not exceed safe parser limit."""
    depth = 0
    for ch in code:
        if ch in "([{":
            depth += 1
            if depth > max_depth:
                return False
        elif ch in ")]}":
            if depth > 0:
                depth -= 1
    return True


def scan_code(code_string: str) -> List[Dict[str, Any]]:
    """Analyzes Python source code and returns structured security findings."""
    vulnerabilities: List[Dict[str, Any]] = []

    if not check_nesting_depth(code_string):
        return [{
            "rule": "SEC_18_RESOURCE_EXHAUSTION",
            "category": "DoS",
            "severity": "CRITICAL",
            "line": 1,
            "message": f"Excessive syntactic nesting depth exceeds safe compiler limit ({MAX_SAFE_NESTING_DEPTH} levels), potential parser stack exhaustion DoS."
        }]

    try:
        tree = ast.parse(code_string)
    except (SyntaxError, RecursionError, MemoryError):
        # Fall back to safe line-based scan of highest-risk patterns on broken syntax or recursion overflow
        return _line_based_fallback_scan(code_string)

    # Phase 1: Alias & Import Resolution
    # Maps local alias -> canonical module or module.function
    # e.g. 'o' -> 'os', 's' -> 'os.system', 'sp' -> 'subprocess'
    aliases: Dict[str, str] = {}
    
    # Track assigned variables to prevent false positives when locals shadow modules
    assigned_locals: Set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                asname = alias.asname or alias.name
                aliases[asname] = alias.name
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            for alias in node.names:
                asname = alias.asname or alias.name
                aliases[asname] = f"{mod}.{alias.name}" if mod else alias.name
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    assigned_locals.add(t.id)

    def resolve_receiver(node: ast.AST) -> Optional[str]:
        """Resolves receiver AST node to canonical module or variable name."""
        if isinstance(node, ast.Name):
            return aliases.get(node.id, node.id)
        if isinstance(node, ast.Attribute):
            parent = resolve_receiver(node.value)
            if parent:
                return f"{parent}.{node.attr}"
        return None

    def get_node_evidence(node: ast.AST, default: str = "") -> str:
        """Extracts short snippet evidence without exposing secret values."""
        lineno = getattr(node, "lineno", None)
        if lineno is not None:
            lines = code_string.splitlines()
            if 0 < lineno <= len(lines):
                return lines[lineno - 1].strip()[:100]
        return default

    # Track components for Exfiltration Rule (Family H)
    has_personal_data_read = False
    has_network_call = False
    personal_data_nodes: List[ast.AST] = []
    network_nodes: List[ast.AST] = []

    for node in ast.walk(tree):
        lineno = getattr(node, "lineno", "Unknown")
        col_offset = getattr(node, "col_offset", 0)

        # -------------------------------------------------------------
        # Vulnerability 1: Command Injection (os.system)
        # -------------------------------------------------------------
        if isinstance(node, ast.Call):
            is_cmd_inj = False
            # Direct os.system or alias
            if isinstance(node.func, ast.Attribute) and node.func.attr == "system":
                rec = resolve_receiver(node.func.value)
                # Ensure receiver is os or unresolved (hard negative: user object system)
                if rec == "os" or (rec and rec.startswith("os")):
                    is_cmd_inj = True
            elif isinstance(node.func, ast.Name):
                canonical = aliases.get(node.func.id)
                if canonical == "os.system":
                    is_cmd_inj = True

            if is_cmd_inj:
                vulnerabilities.append({
                    "rule_id": "SEC_01_CMD_INJECTION",
                    "type": "Command Injection",
                    "severity": "CRITICAL",
                    "message": "os.system() detected. Risk of shell command injection.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, "os.system(...)"),
                    "confidence": "certain",
                    "safer_alternative": "Use subprocess.run() with explicit argument lists instead of raw shell strings.",
                    "default_block": True
                })

        # -------------------------------------------------------------
        # Vulnerability 2: Arbitrary Code Execution (eval, exec)
        # -------------------------------------------------------------
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in ["eval", "exec"] and node.func.id not in assigned_locals:
                vulnerabilities.append({
                    "rule_id": "SEC_02_CODE_EXECUTION",
                    "type": "Arbitrary Code Execution",
                    "severity": "HIGH",
                    "message": f"{node.func.id}() detected. Risk of running untrusted code.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, f"{node.func.id}(...)"),
                    "confidence": "certain",
                    "safer_alternative": "Use ast.literal_eval() for safe literal parsing or avoid dynamic code execution.",
                    "default_block": True
                })

        # -------------------------------------------------------------
        # Vulnerability 3: Insecure Temporary Files (tempfile.mktemp)
        # -------------------------------------------------------------
        if isinstance(node, ast.Call):
            is_mktemp = False
            if isinstance(node.func, ast.Attribute) and node.func.attr == "mktemp":
                rec = resolve_receiver(node.func.value)
                if rec in [None, "tempfile"] or (rec and "tempfile" in rec):
                    is_mktemp = True
            elif isinstance(node.func, ast.Name):
                canonical = aliases.get(node.func.id)
                if canonical == "tempfile.mktemp":
                    is_mktemp = True

            if is_mktemp:
                vulnerabilities.append({
                    "rule_id": "SEC_03_INSECURE_TEMP",
                    "type": "Insecure Temp File",
                    "severity": "MEDIUM",
                    "message": "mktemp() is insecure. Use tempfile.mkstemp() instead.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, "tempfile.mktemp()"),
                    "confidence": "certain",
                    "safer_alternative": "Use tempfile.NamedTemporaryFile() or tempfile.mkstemp() instead.",
                    "default_block": False
                })

        # -------------------------------------------------------------
        # Vulnerability 4: Hardcoded Secrets
        # -------------------------------------------------------------
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    var_name = target.id.lower()
                    if any(secret in var_name for secret in ["password", "secret", "api_key", "token"]):
                        # Do not leak secret value in evidence!
                        ev = f"{target.id} = '***'"
                        vulnerabilities.append({
                            "rule_id": "SEC_04_HARDCODED_SECRET",
                            "type": "Hardcoded Secret",
                            "severity": "LOW",
                            "message": f"Potential hardcoded secret detected in variable '{target.id}'.",
                            "line": getattr(target, "lineno", lineno),
                            "column": getattr(target, "col_offset", col_offset),
                            "evidence": ev,
                            "confidence": "certain",
                            "safer_alternative": "Load credentials securely from environment variables or a secrets manager.",
                            "default_block": False
                        })

        # -------------------------------------------------------------
        # Family A: Process and shell
        # -------------------------------------------------------------
        if isinstance(node, ast.Call):
            func_name = ""
            receiver = ""
            if isinstance(node.func, ast.Attribute):
                func_name = node.func.attr
                receiver = resolve_receiver(node.func.value) or ""
            elif isinstance(node.func, ast.Name):
                canonical = aliases.get(node.func.id, node.func.id)
                if "." in canonical:
                    receiver, func_name = canonical.rsplit(".", 1)
                else:
                    func_name = node.func.id

            # Subprocess calls
            if receiver == "subprocess" or (receiver.startswith("subprocess") and receiver != "subprocess.check_call"):
                has_shell_true = False
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        has_shell_true = True
                        break

                if has_shell_true:
                    vulnerabilities.append({
                        "rule_id": "SEC_06_SUBPROCESS_SHELL_TRUE",
                        "type": "Shell Injection Risk",
                        "severity": "CRITICAL",
                        "message": "subprocess call with shell=True detected. High risk of shell injection.",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, f"subprocess.{func_name}(..., shell=True)"),
                        "confidence": "certain",
                        "safer_alternative": "Pass command arguments as a list with shell=False (default).",
                        "default_block": True
                    })
                else:
                    vulnerabilities.append({
                        "rule_id": "SEC_05_SUBPROCESS_CALL",
                        "type": "Subprocess Execution",
                        "severity": "HIGH",
                        "message": f"subprocess.{func_name}() detected. Process creation carries execution risk.",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, f"subprocess.{func_name}(...)"),
                        "confidence": "certain",
                        "safer_alternative": "Validate arguments strictly and use timeouts and input limits.",
                        "default_block": False
                    })

            # os.popen, os.exec*, os.spawn*
            if receiver == "os" and (func_name == "popen" or func_name.startswith("exec") or func_name.startswith("spawn")):
                vulnerabilities.append({
                    "rule_id": "SEC_07_OS_EXEC_SPAWN_POPEN",
                    "type": "Process Spawn Risk",
                    "severity": "CRITICAL",
                    "message": f"os.{func_name}() detected. Direct process execution carries high risk.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, f"os.{func_name}(...)"),
                    "confidence": "certain",
                    "safer_alternative": "Use subprocess.run() without shell=True.",
                    "default_block": True
                })

        # -------------------------------------------------------------
        # Family B: Unsafe deserialization
        # -------------------------------------------------------------
        if isinstance(node, ast.Call):
            callee = resolve_receiver(node.func)
            if callee in ["pickle.load", "pickle.loads", "marshal.load", "marshal.loads", "shelve.open"]:
                vulnerabilities.append({
                    "rule_id": "SEC_08_UNSAFE_DESERIALIZATION",
                    "type": "Unsafe Deserialization",
                    "severity": "HIGH",
                    "message": f"{callee}() detected. Deserializing untrusted data can lead to arbitrary code execution.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, f"{callee}(...)"),
                    "confidence": "certain",
                    "safer_alternative": "Use json.loads() or a safe schema-validated serializer.",
                    "default_block": False
                })

        # -------------------------------------------------------------
        # Family C: Network calls
        # -------------------------------------------------------------
        if isinstance(node, ast.Call):
            callee = resolve_receiver(node.func)
            is_net = False
            if callee and any(callee.startswith(p) for p in [
                "socket.socket", "socket.create_connection", "requests.",
                "urllib.request.", "urllib.", "http.client.", "ftplib.", "smtplib."
            ]):
                is_net = True
            elif isinstance(node.func, ast.Attribute) and node.func.attr in ["connect", "send", "sendall"]:
                rec = resolve_receiver(node.func.value)
                if rec and ("socket" in rec or "sock" in rec or "s" in rec):
                    is_net = True

            if is_net:
                has_network_call = True
                network_nodes.append(node)
                vulnerabilities.append({
                    "rule_id": "SEC_09_NETWORK_CALL",
                    "type": "Network Access",
                    "severity": "HIGH",
                    "message": f"Network call via {callee or 'socket method'} detected.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, "network_call(...)"),
                    "confidence": "certain" if callee else "possible",
                    "safer_alternative": "Perform network interactions through validated clients with timeout limits.",
                    "default_block": False
                })

        # -------------------------------------------------------------
        # Family D: SQL built by string formatting
        # -------------------------------------------------------------
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr in ["execute", "executemany"] and node.args:
                first_arg = node.args[0]
                is_dynamic_sql = False
                if isinstance(first_arg, ast.JoinedStr):  # f-string
                    is_dynamic_sql = True
                elif isinstance(first_arg, ast.BinOp) and isinstance(first_arg.op, (ast.Mod, ast.Add)):  # % or +
                    is_dynamic_sql = True
                elif isinstance(first_arg, ast.Name):
                    for subnode in ast.walk(tree):
                        if isinstance(subnode, ast.Assign):
                            for tgt in subnode.targets:
                                if isinstance(tgt, ast.Name) and tgt.id == first_arg.id:
                                    if isinstance(subnode.value, ast.JoinedStr) or (isinstance(subnode.value, ast.BinOp) and isinstance(subnode.value.op, (ast.Mod, ast.Add))):
                                        is_dynamic_sql = True

                if is_dynamic_sql:
                    vulnerabilities.append({
                        "rule_id": "SEC_10_SQL_INJECTION",
                        "type": "SQL Injection Risk",
                        "severity": "MEDIUM",
                        "message": "SQL query constructed with string formatting detected. Risk of SQL injection.",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, "cursor.execute(...)"),
                        "confidence": "certain",
                        "safer_alternative": "Use parameterized queries (e.g. cursor.execute('SELECT ... WHERE id = ?', (val,))).",
                        "default_block": False
                    })

        # -------------------------------------------------------------
        # Family E: Risky file operations
        # -------------------------------------------------------------
        if isinstance(node, ast.Call):
            callee = resolve_receiver(node.func)
            if callee in ["os.remove", "os.unlink", "os.rmdir", "shutil.rmtree"] and node.args:
                # Flag if target path is non-literal
                if not isinstance(node.args[0], ast.Constant):
                    vulnerabilities.append({
                        "rule_id": "SEC_11_RISKY_FILE_OPS",
                        "type": "Risky File Operation",
                        "severity": "HIGH",
                        "message": f"Destructive file operation {callee}() with non-literal path detected.",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, f"{callee}(path)"),
                        "confidence": "certain",
                        "safer_alternative": "Restrict file modifications to safe workspace paths with path validation.",
                        "default_block": False
                    })

            # open for write with absolute path or '..'
            if (callee == "open" or (isinstance(node.func, ast.Name) and node.func.id == "open")) and node.args:
                path_node = node.args[0]
                mode_str = "r"
                if len(node.args) >= 2 and isinstance(node.args[1], ast.Constant):
                    mode_str = str(node.args[1].value)
                for kw in node.keywords:
                    if kw.arg == "mode" and isinstance(kw.value, ast.Constant):
                        mode_str = str(kw.value.value)

                is_write_mode = any(m in mode_str for m in ["w", "a", "x", "+"])
                if is_write_mode and isinstance(path_node, ast.Constant) and isinstance(path_node.value, str):
                    path_val = path_node.value
                    if ".." in path_val or os.path.isabs(path_val) or path_val.startswith(("/", "\\")) or (len(path_val) > 1 and path_val[1] == ":"):
                        vulnerabilities.append({
                            "rule_id": "SEC_12_OPEN_ABSOLUTE_OR_TRAVERSAL",
                            "type": "Path Traversal Risk",
                            "severity": "MEDIUM",
                            "message": f"open() for write with absolute path or '..' detected ('{path_val}').",
                            "line": lineno,
                            "column": col_offset,
                            "evidence": get_node_evidence(node, f"open('{path_val}', '{mode_str}')"),
                            "confidence": "certain",
                            "safer_alternative": "Use relative paths confined to the application workspace.",
                            "default_block": False
                        })

        # -------------------------------------------------------------
        # Family F: Personal data & Environment Access
        # -------------------------------------------------------------
        # Reading os.environ or os.getenv
        is_env_read = False
        if isinstance(node, ast.Attribute) and node.attr == "environ":
            rec = resolve_receiver(node.value)
            if rec == "os":
                is_env_read = True
        elif isinstance(node, ast.Call):
            callee = resolve_receiver(node.func)
            if callee in ["os.getenv", "os.environ.get"]:
                is_env_read = True

        if is_env_read:
            has_personal_data_read = True
            personal_data_nodes.append(node)
            vulnerabilities.append({
                "rule_id": "SEC_13_ENV_READ",
                "type": "Environment Access",
                "severity": "MEDIUM",
                "message": "Accessing os.environ or os.getenv detected.",
                "line": lineno,
                "column": col_offset,
                "evidence": get_node_evidence(node, "os.environ / os.getenv"),
                "confidence": "certain",
                "safer_alternative": "Read configuration from a dedicated configuration object or sanitized parameters.",
                "default_block": False
            })

        # Paths touching home secrets
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            s_val = node.value.lower()
            sensitive_patterns = [".ssh", ".aws", ".gnupg", "/etc/passwd", "id_rsa", "credentials", "chrome/user data", "firefox/profiles"]
            if any(sp in s_val for sp in sensitive_patterns):
                has_personal_data_read = True
                personal_data_nodes.append(node)
                vulnerabilities.append({
                    "rule_id": "SEC_14_HOME_SECRETS_PATH",
                    "type": "Sensitive Path Access",
                    "severity": "HIGH",
                    "message": f"Path referencing sensitive user secret or configuration directory ('{node.value}').",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, node.value),
                    "confidence": "certain",
                    "safer_alternative": "Restrict file access exclusively to project workspace files.",
                    "default_block": False
                })

        # -------------------------------------------------------------
        # Family G: Obfuscation
        # -------------------------------------------------------------
        # __import__ with non-literal argument
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "__import__":
            if node.args and not isinstance(node.args[0], ast.Constant):
                vulnerabilities.append({
                    "rule_id": "SEC_15_DYNAMIC_IMPORT",
                    "type": "Dynamic Import",
                    "severity": "HIGH",
                    "message": "__import__() with non-literal argument detected. Risk of arbitrary module loading.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, "__import__(...)"),
                    "confidence": "certain",
                    "safer_alternative": "Use standard top-level import statements.",
                    "default_block": False
                })

        # getattr on module with non-literal name
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "getattr":
            if len(node.args) >= 2:
                receiver = resolve_receiver(node.args[0])
                attr_arg = node.args[1]
                if receiver:
                    if not isinstance(attr_arg, ast.Constant):
                        vulnerabilities.append({
                            "rule_id": "SEC_16_DYNAMIC_GETATTR",
                            "type": "Dynamic Attribute Access",
                            "severity": "MEDIUM",
                            "message": f"getattr() on module '{receiver}' with constructed attribute name detected.",
                            "line": lineno,
                            "column": col_offset,
                            "evidence": get_node_evidence(node, f"getattr({receiver}, ...)"),
                            "confidence": "certain",
                            "safer_alternative": "Access module attributes directly using dotted attribute notation.",
                            "default_block": False
                        })

        # Obfuscated string reaching exec/eval/open/__import__
        if isinstance(node, ast.Call):
            caller_name = ""
            if isinstance(node.func, ast.Name):
                caller_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                caller_name = node.func.attr
            if caller_name in ["exec", "eval", "open", "__import__"] and node.args:
                arg0 = node.args[0]
                is_obf_str = False
                if isinstance(arg0, ast.Call):
                    sub_name = ""
                    if isinstance(arg0.func, ast.Attribute):
                        sub_name = arg0.func.attr
                    elif isinstance(arg0.func, ast.Name):
                        sub_name = arg0.func.id
                    if sub_name in ["join", "chr"]:
                        is_obf_str = True
                elif isinstance(arg0, ast.BinOp) and isinstance(arg0.op, ast.Add):
                    for sub_b in ast.walk(arg0):
                        if isinstance(sub_b, ast.Call) and isinstance(sub_b.func, ast.Name) and sub_b.func.id == "chr":
                            is_obf_str = True
                            break

                if is_obf_str:
                    vulnerabilities.append({
                        "rule_id": "SEC_18_OBFUSCATED_STRING",
                        "type": "Obfuscated String Construction",
                        "severity": "HIGH",
                        "message": f"Obfuscated string constructed via join/chr reaching {caller_name}().",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, f"{caller_name}(...)"),
                        "confidence": "certain",
                        "safer_alternative": "Use plain string literals without dynamic character concatenation.",
                        "default_block": False
                    })

        # Decode reaching exec/eval/compile
        if isinstance(node, ast.Call):
            caller_name = ""
            if isinstance(node.func, ast.Name):
                caller_name = node.func.id
            if caller_name in ["exec", "eval", "compile"] and node.args:
                arg0 = node.args[0]
                is_decode_exec = False
                if isinstance(arg0, ast.Call):
                    sub_callee = resolve_receiver(arg0.func) or ""
                    if any(dec in sub_callee for dec in ["b64decode", "decode", "decompress", "fromhex", "base64", "codecs", "zlib"]):
                        is_decode_exec = True
                elif isinstance(arg0, ast.Name):
                    # Check if arg0 was assigned from a decode call earlier
                    for subnode in ast.walk(tree):
                        if isinstance(subnode, ast.Assign):
                            for tgt in subnode.targets:
                                if isinstance(tgt, ast.Name) and tgt.id == arg0.id:
                                    if isinstance(subnode.value, ast.Call):
                                        sub_callee = resolve_receiver(subnode.value.func) or ""
                                        if any(dec in sub_callee for dec in ["b64decode", "decode", "decompress", "fromhex", "base64", "codecs", "zlib"]):
                                            is_decode_exec = True

                if is_decode_exec:
                    vulnerabilities.append({
                        "rule_id": "SEC_17_DECODE_EXEC",
                        "type": "Obfuscated Code Execution",
                        "severity": "CRITICAL",
                        "message": "Decoded payload reaching exec/eval/compile detected. High risk of payload obfuscation.",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, f"{caller_name}(decode(...))"),
                        "confidence": "certain",
                        "safer_alternative": "Execute plain, unencoded source code only.",
                        "default_block": True
                    })

        # ctypes usage
        if isinstance(node, ast.Import):
            for n in node.names:
                if n.name == "ctypes":
                    vulnerabilities.append({
                        "rule_id": "SEC_19_CTYPES",
                        "type": "Native Library Access",
                        "severity": "HIGH",
                        "message": "ctypes usage detected. Native memory and system library calls bypass Python safety.",
                        "line": lineno,
                        "column": col_offset,
                        "evidence": get_node_evidence(node, "import ctypes"),
                        "confidence": "certain",
                        "safer_alternative": "Use pure Python standard library modules.",
                        "default_block": False
                    })
        elif isinstance(node, ast.ImportFrom):
            if node.module == "ctypes":
                vulnerabilities.append({
                    "rule_id": "SEC_19_CTYPES",
                    "type": "Native Library Access",
                    "severity": "HIGH",
                    "message": "ctypes usage detected. Native memory and system library calls bypass Python safety.",
                    "line": lineno,
                    "column": col_offset,
                    "evidence": get_node_evidence(node, f"from ctypes import ..."),
                    "confidence": "certain",
                    "safer_alternative": "Use pure Python standard library modules.",
                    "default_block": False
                })

    # -------------------------------------------------------------
    # Family H: Combined (Exfiltration Pattern)
    # -------------------------------------------------------------
    if has_personal_data_read and has_network_call:
        line_ref = getattr(personal_data_nodes[0], "lineno", "Unknown") if personal_data_nodes else "Unknown"
        vulnerabilities.append({
            "rule_id": "SEC_20_EXFILTRATION",
            "type": "Possible Exfiltration Pattern",
            "severity": "CRITICAL",
            "message": "Personal data or environment read combined with network communication in the same program.",
            "line": line_ref,
            "column": 0,
            "evidence": "Data read + Network call in same module",
            "confidence": "certain",
            "safer_alternative": "Separate local configuration and data storage from network communication routines.",
            "default_block": True
        })

    # Phase: CFG Dataflow Taint Tracking (Source -> Propagation -> Dangerous Sink)
    try:
        from dataflow_engine import analyze_dataflow
        df_res = analyze_dataflow(code_string)
        for tf in df_res.get("taint_findings", []):
            vulnerabilities.append({
                "rule_id": "SEC_TAINT_FLOW",
                "type": f"Tainted {tf.get('type', 'Injection')}",
                "severity": tf.get("severity", "CRITICAL"),
                "message": tf.get("explanation", "Untrusted input flows to dangerous sink"),
                "line": tf.get("sink_line", 0),
                "column": 0,
                "evidence": tf.get("sink_expr") or f"{tf.get('sink')}({tf.get('tainted_variable')})",
                "confidence": "certain",
                "risk_score": tf.get("risk_score", 95),
                "path": tf.get("path", []),
                "path_explanation": tf.get("explanation"),
                "safer_alternative": "Sanitize or validate untrusted input before passing to execution sinks.",
                "default_block": True
            })
    except Exception:
        pass

    return vulnerabilities


def _line_based_fallback_scan(code_string: str) -> List[Dict[str, Any]]:
    """Line-based regex fallback for unparseable syntax."""
    findings = []
    lines = code_string.splitlines()
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith("#"):
            continue

        if re.search(r'\bos\.system\s*\(', stripped):
            findings.append({
                "rule_id": "SEC_01_CMD_INJECTION",
                "type": "Command Injection",
                "severity": "CRITICAL",
                "message": "os.system() detected. Risk of shell command injection. (Partial Scan)",
                "line": idx,
                "column": 0,
                "evidence": stripped[:80],
                "confidence": "possible",
                "safer_alternative": "Use subprocess.run() without shell=True.",
                "default_block": True,
                "partial_scan": True
            })

        if re.search(r'\b(eval|exec)\s*\(', stripped):
            findings.append({
                "rule_id": "SEC_02_CODE_EXECUTION",
                "type": "Arbitrary Code Execution",
                "severity": "HIGH",
                "message": "eval() or exec() detected. Risk of running untrusted code. (Partial Scan)",
                "line": idx,
                "column": 0,
                "evidence": stripped[:80],
                "confidence": "possible",
                "safer_alternative": "Avoid dynamic code execution.",
                "default_block": True,
                "partial_scan": True
            })

        if re.search(r'\bsubprocess\.\w+\s*\(.*shell\s*=\s*True', stripped):
            findings.append({
                "rule_id": "SEC_06_SUBPROCESS_SHELL_TRUE",
                "type": "Shell Injection Risk",
                "severity": "CRITICAL",
                "message": "subprocess with shell=True detected. (Partial Scan)",
                "line": idx,
                "column": 0,
                "evidence": stripped[:80],
                "confidence": "possible",
                "safer_alternative": "Use subprocess.run() with shell=False.",
                "default_block": True,
                "partial_scan": True
            })

    return findings


def scan_summary(findings: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Computes max severity, counts, and default blocking decision from findings."""
    counts = {"LOW": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0}
    max_rank = 0
    max_sev = "NONE"
    is_blocked = False

    active_block_level = get_scan_block_level()
    block_rank_threshold = SEVERITY_RANKS.get(active_block_level, 999) if active_block_level else None

    for f in findings:
        sev = f.get("severity", "LOW")
        counts[sev] = counts.get(sev, 0) + 1
        rank = SEVERITY_RANKS.get(sev, 0)
        if rank > max_rank:
            max_rank = rank
            max_sev = sev

        if block_rank_threshold is not None:
            if rank >= block_rank_threshold:
                is_blocked = True
        else:
            if f.get("default_block", False):
                is_blocked = True

    return {
        "max_severity": max_sev,
        "counts_by_severity": counts,
        "blocked": is_blocked
    }


def scan_gate(code: str, block_level: Optional[str] = None, enforce: bool = True) -> Dict[str, Any]:
    """
    Main security gateway before code execution or patch acceptance.
    Returns gating decision, structured findings, and summary.
    """
    findings = scan_code(code)
    
    # Determine threshold
    active_level = block_level or get_scan_block_level()
    block_rank_thresh = SEVERITY_RANKS.get(active_level) if active_level else None

    blocked = False
    first_blocking_finding = None

    for f in findings:
        sev = f.get("severity", "LOW")
        rank = SEVERITY_RANKS.get(sev, 0)
        should_block = False

        if block_rank_thresh is not None:
            if rank >= block_rank_thresh:
                should_block = True
        else:
            if f.get("default_block", False):
                should_block = True

        if should_block:
            blocked = True
            if not first_blocking_finding:
                first_blocking_finding = f

    summary = scan_summary(findings)
    summary["blocked"] = blocked

    if blocked and first_blocking_finding:
        rule_desc = first_blocking_finding.get("evidence") or first_blocking_finding.get("type")
        msg = f"Blocked before running: this code uses {rule_desc} ({first_blocking_finding.get('severity')})"
    else:
        msg = "Code passed static security scan."

    return {
        "allowed": (not blocked) if enforce else True,
        "blocked": blocked,
        "findings": findings,
        "summary": summary,
        "message": msg
    }
