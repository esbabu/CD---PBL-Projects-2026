"""tests_shield_output_guard.py - Unit Tests for Output Guard (Gate 4).

Tests:
- API key redaction (Gemini, Groq, AWS, OpenAI, fake keys)
- Personal data redaction (emails, phone numbers, credit card numbers, SSNs)
- Canary personal data redaction (matching lab_data/fake_personal_info.txt)
- Structured dictionary and nested collection sanitization
- Socket guard ensuring zero real external network connections
"""

import os
import socket
import unittest
from unittest.mock import patch

from security import output_guard


class TestShieldOutputGuard(unittest.TestCase):
    """Unit tests for security/output_guard.py."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1"):
                raise AssertionError(f"Real outbound network call to {address} attempted in test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect
        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy"
        })
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect
        super().tearDown()

    def test_api_key_redaction(self):
        """Standard and fake API keys are redacted from text."""
        raw_text = (
            "Here is Gemini key: " + "AIza" + "SyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6 "
            "and Groq key: " + "gsk_" + "1234567890abcdef1234567890abcdef "
            "and Fake key: FAKE-KEY-NOT-REAL-123"
        )
        redacted, items = output_guard.redact_output(raw_text)
        self.assertNotIn("AIzaSyA1B2C3", redacted)
        self.assertNotIn("gsk_123456", redacted)
        self.assertNotIn("FAKE-KEY-NOT-REAL-123", redacted)
        self.assertIn("[REDACTED_GEMINI_KEY]", redacted)
        self.assertIn("[REDACTED_GROQ_KEY]", redacted)
        self.assertGreaterEqual(len(items), 3)

    def test_personal_data_redaction(self):
        """Emails, phone numbers, credit cards, and SSNs are redacted."""
        raw_text = (
            "Contact alice@example.com or call 555-123-4567. "
            "Card number: 4111-2222-3333-4444 and SSN: 123-45-6789."
        )
        redacted, items = output_guard.redact_output(raw_text)
        self.assertNotIn("alice@example.com", redacted)
        self.assertNotIn("555-123-4567", redacted)
        self.assertNotIn("4111-2222-3333-4444", redacted)
        self.assertNotIn("123-45-6789", redacted)
        self.assertIn("[REDACTED_EMAIL]", redacted)
        self.assertIn("[REDACTED_PHONE]", redacted)
        self.assertIn("[REDACTED_CARD]", redacted)
        self.assertIn("[REDACTED_SSN]", redacted)
        self.assertEqual(len(items), 4)

    def test_canary_file_exact_redaction(self):
        """Canary records from lab_data/fake_personal_info.txt are redacted."""
        raw_text = (
            "Extracted canary data: CANARY_RECORD_START "
            "Name: Test Person, Phone: 000-000-0000, "
            "API_Key: FAKE-KEY-NOT-REAL-123, Credit_Card: 0000-0000-0000-0000 "
            "CANARY_RECORD_END"
        )
        redacted, items = output_guard.redact_output(raw_text)
        self.assertNotIn("CANARY_RECORD_START", redacted)
        self.assertNotIn("Test Person", redacted)
        self.assertNotIn("FAKE-KEY-NOT-REAL-123", redacted)
        self.assertGreater(len(items), 0)

    def test_nested_dict_sanitization(self):
        """Nested dictionaries and lists are recursively redacted."""
        nested = {
            "agent_response": "Found key: " + "AIza" + "SyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6",
            "metadata": {
                "user_email": "admin@intellifix.internal",
                "phone_list": ["123-456-7890", "987-654-3210"]
            }
        }
        sanitized, items = output_guard.sanitize_dict(nested)
        self.assertNotIn("AIzaSyA1B2C3", sanitized["agent_response"])
        self.assertNotIn("admin@intellifix.internal", sanitized["metadata"]["user_email"])
        self.assertNotIn("123-456-7890", sanitized["metadata"]["phone_list"][0])
        self.assertGreaterEqual(len(items), 4)


if __name__ == "__main__":
    unittest.main()
