"""tests_ai_fallback.py

Comprehensive unit tests for the multi-round AI fallback engine with progress-based acceptance:
1. Multi-error composition (A5+A6, A6+A5) with mixed AI + deterministic fixes running clean under W0, W1, W2, W3, W8.
2. Provider failover (Gemini 429/timeout -> Groq fallback), overall AI failure ("AI fix unavailable: <reason>").
3. Per-request AI call budget cap (max 3 calls) and SHA256 request caching.
4. Progress-based patch validation and rejection invariant checks (stubs, lambdas, deletions, earlier errors, no progress, illegal imports, >6 changed lines, wrong line numbers).
5. Error exclusion filters (non-stdlib ImportError, while True: pass, security blocked).
6. AUTOFIX_AI=0 zero-call guarantees and deterministic bypass.

All tests use mocks only with zero real LLM API calls and strict patch.dict environment isolation.
"""

import unittest
from unittest.mock import patch, MagicMock
import os
import sys

from nlp_explainer import NLPExplainer, _run_in_sandbox_full, _validate_patch_acceptance


class TestAIFallbackMultiError(unittest.TestCase):
    def setUp(self):
        self.explainer = NLPExplainer()

    def _mock_ai_patch_a5(self, prompt, **kwargs):
        # Deterministically patch print(math.sqrt(-1)) -> print(math.sqrt(abs(-1)))
        lines = prompt.splitlines()
        for l in lines:
            if "math.sqrt(-1)" in l and "|" in l:
                line_no = int(l.split("|")[0].strip())
                return f"Replace line {line_no} with:\n    print(math.sqrt(abs(-1)))", None, False
        return "Replace line 2 with:\n    print(math.sqrt(abs(-1)))", None, False

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "fake-key"})
    def test_a5_plus_a6_combined_repair(self):
        # A5 (math domain error unfixable deterministically) + A6 (for x in 100: fixable deterministically)
        code = "import math\nprint(math.sqrt(-1))\nfor x in 100:\n    print(x)"
        with patch("llm_calls.call_gemini", side_effect=self._mock_ai_patch_a5):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertEqual(self.explainer.last_fix_status, "applied")
            self.assertEqual(self.explainer.last_fix_source, "mixed")
            self.assertEqual(self.explainer.last_fix_providers, ["gemini"])
            self.assertEqual(len(self.explainer.last_fix_steps), 2)
            self.assertEqual(self.explainer.last_fix_steps[0]["source"], "ai")
            self.assertEqual(self.explainer.last_fix_steps[0]["provider"], "gemini")
            self.assertEqual(self.explainer.last_fix_steps[1]["source"], "deterministic")
            clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
            self.assertTrue(clean)
            self.assertIn("1.0", stdout)
            self.assertIn("0", stdout)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "fake-key"})
    def test_a6_plus_a5_combined_repair(self):
        # A6 first, then A5
        code = "import math\nfor x in 100:\n    print(x)\nprint(math.sqrt(-1))"
        with patch("llm_calls.call_gemini", side_effect=self._mock_ai_patch_a5):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertEqual(self.explainer.last_fix_status, "applied")
            self.assertEqual(self.explainer.last_fix_source, "mixed")
            self.assertEqual(len(self.explainer.last_fix_steps), 2)
            self.assertEqual(self.explainer.last_fix_steps[0]["source"], "deterministic")
            self.assertEqual(self.explainer.last_fix_steps[1]["source"], "ai")
            clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
            self.assertTrue(clean)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "fake-key"})
    def test_a5_plus_a6_across_wrappers(self):
        base_a5_a6 = "import math\nprint(math.sqrt(-1))\nfor x in 100:\n    print(x)"
        wrappers = {
            "W1_comment": f"# leading comment\n{base_a5_a6}",
            "W2_blank_lines": f"\n\n{base_a5_a6}",
            "W3_statement": f"x_init = 10\n{base_a5_a6}",
            "W8_main_func": f"import math\ndef main():\n    print(math.sqrt(-1))\n    for x in 100:\n        print(x)\nmain()",
        }
        for w_name, wrapped_code in wrappers.items():
            with patch("llm_calls.call_gemini", side_effect=self._mock_ai_patch_a5):
                fixed = self.explainer.generate_fixed_code(wrapped_code)
                self.assertEqual(self.explainer.last_fix_status, "applied", f"Failed on {w_name}")
                self.assertEqual(self.explainer.last_fix_source, "mixed", f"Source mismatch on {w_name}")
                clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
                self.assertTrue(clean, f"Not clean on {w_name}")


class TestProviderFailoverAndBudget(unittest.TestCase):
    def setUp(self):
        self.explainer = NLPExplainer()

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1", "GROQ_API_KEY": "key2"})
    def test_gemini_429_failover_to_groq(self):
        code = "import math\nprint(math.sqrt(-1))"
        groq_patch = "Replace line 2 with:\n    print(math.sqrt(abs(-1)))"
        with patch("llm_calls.call_gemini", return_value=(None, "429 Rate Limit Exceeded", True)) as mock_gemini:
            with patch("llm_calls.call_groq", return_value=(groq_patch, None, False)) as mock_groq:
                fixed = self.explainer.generate_fixed_code(code)
                mock_gemini.assert_called_once()
                mock_groq.assert_called_once()
                self.assertEqual(self.explainer.last_fix_status, "applied")
                self.assertEqual(self.explainer.last_fix_source, "ai")
                self.assertEqual(self.explainer.last_fix_providers, ["groq"])

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1", "GROQ_API_KEY": "key2"})
    def test_gemini_timeout_failover_to_groq(self):
        code = "import math\nprint(math.sqrt(-1))"
        groq_patch = "Replace line 2 with:\n    print(math.sqrt(abs(-1)))"
        with patch("llm_calls.call_gemini", return_value=(None, "TimeoutExpired after 12.0s", True)):
            with patch("llm_calls.call_groq", return_value=(groq_patch, None, False)):
                fixed = self.explainer.generate_fixed_code(code)
                self.assertEqual(self.explainer.last_fix_status, "applied")
                self.assertEqual(self.explainer.last_fix_source, "ai")
                self.assertEqual(self.explainer.last_fix_providers, ["groq"])

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1", "GROQ_API_KEY": "key2"})
    def test_both_providers_fail_reports_reason(self):
        code = "import math\nprint(math.sqrt(-1))"
        with patch("llm_calls.call_gemini", return_value=(None, "429 Rate Limit", True)):
            with patch("llm_calls.call_groq", return_value=(None, "429 Quota Exceeded", True)):
                fixed = self.explainer.generate_fixed_code(code)
                self.assertEqual(fixed, code)
                self.assertIn("AI fix unavailable", self.explainer.last_fix_status)
                self.assertEqual(self.explainer.last_fix_source, "none")

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_ai_calls_capped_at_three_per_request(self):
        # 5 separate AI-unfixable errors
        code = "import math\nprint(math.sqrt(-1))\nprint(math.sqrt(-2))\nprint(math.sqrt(-3))\nprint(math.sqrt(-4))\nprint(math.sqrt(-5))"
        call_count = 0
        def counting_gemini(prompt, **kwargs):
            nonlocal call_count
            call_count += 1
            return None, "rejected", False

        with patch("llm_calls.call_gemini", side_effect=counting_gemini):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertLessEqual(call_count, 3)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_request_level_sha256_cache_prevents_duplicate_calls(self):
        code = "import math\nprint(math.sqrt(-1))"
        gemini_calls = 0
        def mock_call(prompt, **kwargs):
            nonlocal gemini_calls
            gemini_calls += 1
            return "Replace line 2 with:\n    pass", None, False  # Deletion patch will be rejected

        with patch("llm_calls.call_gemini", side_effect=mock_call):
            self.explainer.generate_fixed_code(code)
            # Should only call Gemini once for the exact same error & code
            self.assertEqual(gemini_calls, 1)


class TestAIPatchValidationRejections(unittest.TestCase):
    def setUp(self):
        self.explainer = NLPExplainer()

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_stub_replacement(self):
        code = "import math\ndef compute(x):\n    return math.sqrt(x)\nprint(compute(-1))"
        stub_patch = "Replace lines 2-3 with:\n    def compute(x):\n        pass"
        with patch("llm_calls.call_gemini", return_value=(stub_patch, None, False)):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertNotEqual(fixed, stub_patch)
            self.assertIn("rejected", getattr(self.explainer, "last_ai_unavailable_reason", ""))

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_lambda_replacement(self):
        code = "import math\ndef compute(x):\n    return math.sqrt(x)\nprint(compute(-1))"
        lambda_patch = "Replace lines 2-3 with:\n    compute = lambda x: 0"
        with patch("llm_calls.call_gemini", return_value=(lambda_patch, None, False)):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertNotEqual(fixed, lambda_patch)
            self.assertIn("rejected", getattr(self.explainer, "last_ai_unavailable_reason", ""))

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_failing_line_deletion(self):
        code = "import math\nprint(math.sqrt(-1))\nprint('Done')"
        del_patch = "Replace line 2 with:\n    pass"
        with patch("llm_calls.call_gemini", return_value=(del_patch, None, False)):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertNotEqual(fixed, "import math\npass\nprint('Done')")
            self.assertIn("rejected", getattr(self.explainer, "last_ai_unavailable_reason", ""))

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_patch_causing_earlier_error(self):
        code = "import math\nval = 10\nprint(val)\nprint(math.sqrt(-1))"
        bad_patch = "Replace line 2 with:\n    val = 1 / 0"
        with patch("llm_calls.call_gemini", return_value=(bad_patch, None, False)):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertEqual(fixed, code)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_forbidden_imports(self):
        code = "import math\nprint(math.sqrt(-1))"
        for bad_mod in ["os", "subprocess", "socket", "ctypes"]:
            bad_patch = f"Replace line 2 with:\n    import {bad_mod}\n    print(1)"
            with patch("llm_calls.call_gemini", return_value=(bad_patch, None, False)):
                fixed = self.explainer.generate_fixed_code(code)
                self.assertNotIn(bad_mod, fixed)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_patch_touching_too_many_lines(self):
        code = "import math\nprint(math.sqrt(-1))"
        # Patch adding > 6 lines
        huge_patch = "Replace line 2 with:\n    a = 1\n    b = 2\n    c = 3\n    d = 4\n    e = 5\n    f = 6\n    g = 7\n    print(a)"
        with patch("llm_calls.call_gemini", return_value=(huge_patch, None, False)):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertEqual(fixed, code)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_reject_wrong_line_number_patch(self):
        code = "import math\nprint(math.sqrt(-1))"
        wrong_line_patch = "Replace line 99 with:\n    pass"
        with patch("llm_calls.call_gemini", return_value=(wrong_line_patch, None, False)):
            fixed = self.explainer.generate_fixed_code(code)
            self.assertEqual(fixed, code)


class TestExclusionRules(unittest.TestCase):
    def setUp(self):
        self.explainer = NLPExplainer()

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_missing_non_stdlib_package_makes_no_ai_call(self):
        code = "import imaginary_uninstalled_pkg_12345"
        with patch("llm_calls.call_gemini") as mock_ai:
            fixed = self.explainer.generate_fixed_code(code)
            mock_ai.assert_not_called()
            self.assertEqual(fixed, code)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_infinite_loop_timeout_makes_no_ai_call(self):
        code = "while True:\n    pass"
        with patch("llm_calls.call_gemini") as mock_ai:
            fixed = self.explainer.generate_fixed_code(code)
            mock_ai.assert_not_called()
            self.assertEqual(fixed, code)

    @patch.dict(os.environ, {"AUTOFIX_AI": "0", "LLM_DISABLED": "1"})
    def test_autofix_ai_zero_makes_zero_calls(self):
        code = "import math\nprint(math.sqrt(-1))"
        with patch("llm_calls.call_gemini") as mock_ai:
            fixed = self.explainer.generate_fixed_code(code)
            mock_ai.assert_not_called()
            self.assertEqual(fixed, code)
            self.assertIn("stopped at line 2", self.explainer.last_fix_status)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0", "GEMINI_API_KEY": "key1"})
    def test_deterministic_fix_bypasses_ai(self):
        # A6 is fixable deterministically -> AI should not be called
        code = "for x in 100:\n    print(x)"
        with patch("llm_calls.call_gemini") as mock_ai:
            fixed = self.explainer.generate_fixed_code(code)
            mock_ai.assert_not_called()
            self.assertEqual(self.explainer.last_fix_status, "applied")
            self.assertEqual(self.explainer.last_fix_source, "deterministic")


if __name__ == "__main__":
    unittest.main()
