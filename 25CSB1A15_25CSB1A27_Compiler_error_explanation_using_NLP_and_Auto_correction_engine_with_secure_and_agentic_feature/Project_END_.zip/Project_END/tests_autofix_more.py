"""tests_autofix_more.py

Comprehensive tests for extended deterministic auto-fixers (Phase 3),
iterative repair loop (Phase 4), and stricter AI-fix acceptance invariants (Phase 5).
"""

import unittest
import os
import sys
import tempfile
import subprocess
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nlp_explainer import NLPExplainer, _run_in_sandbox, _run_in_sandbox_full


class TestDeterministicFixersPositives(unittest.TestCase):
    """Positives for all 8 deterministic fixers."""

    def setUp(self):
        self.patcher = patch.dict(os.environ, {"AUTOFIX_AI": "0", "LLM_DISABLED": "1"})
        self.patcher.start()
        self.explainer = NLPExplainer()

    def tearDown(self):
        self.patcher.stop()

    def test_fixer_1_unbound_local_global(self):
        code = "count = 0\ndef add():\n    count = count + 1\nadd()"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("global count", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_1_unbound_local_nonlocal(self):
        code = "def outer():\n    val = 10\n    def inner():\n        val = val + 5\n    inner()\nouter()"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("nonlocal val", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_2_stop_iteration(self):
        code = "it = iter([])\nres = next(it)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("next(it, None)", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_3_runtime_dict_size_changed(self):
        code = "d = {'a': 1, 'b': 2}\nfor k in d:\n    del d[k]"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("list(d)", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_3_runtime_dict_items_changed(self):
        code = "d = {'a': 1, 'b': 2}\nfor k, v in d.items():\n    del d[k]"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("list(d.items())", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_4_typeerror_int_iterable_literal(self):
        code = "for x in 5:\n    print(x)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("range(5)", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_4_typeerror_int_iterable_var(self):
        code = "n = 5\nfor x in n:\n    print(x)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("range(n)", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_5_nameerror_stdlib_import(self):
        code = "val = math.sqrt(25)\nprint(val)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertTrue(fixed.startswith("import math"))
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(stdout.strip(), "5.0")
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_6a_syntaxerror_unclosed_brackets_unicode(self):
        code = 'print("héllo ✓")\nx = [1, 2, 3'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertTrue(fixed.endswith("]"))
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertIn("héllo ✓", stdout)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_6b_syntaxerror_unterminated_string(self):
        code = 'msg = "hello'
        fixed = self.explainer.generate_fixed_code(code)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_6c_syntaxerror_python2_print(self):
        code = 'print "hello world"'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn('print("hello world")', fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(stdout.strip(), "hello world")
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_6d_syntaxerror_assign_in_if(self):
        code = 'x = 10\nif x = 10:\n    print("match")'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if x == 10:", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(stdout.strip(), "match")
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_6e_syntaxerror_missing_comma(self):
        code = 'items = [1, 2 3]'
        fixed = self.explainer.generate_fixed_code(code)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_7_file_exists_mkdir(self):
        code = 'import os\nos.mkdir("test_dir")\nos.mkdir("test_dir")'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("os.makedirs", fixed)
        self.assertIn("exist_ok=True", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_fixer_8_json_decode_empty(self):
        code = 'import json\nres = json.loads("")\nprint(res)'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("None", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(stdout.strip(), "None")
        self.assertEqual(self.explainer.last_fix_status, "applied")


class TestDeterministicFixersNegatives(unittest.TestCase):
    """Negatives and unfixable error invariants."""

    def setUp(self):
        self.patcher = patch.dict(os.environ, {"AUTOFIX_AI": "0", "LLM_DISABLED": "1"})
        self.patcher.start()
        self.explainer = NLPExplainer()

    def tearDown(self):
        self.patcher.stop()

    def test_unbound_local_parameter_not_modified(self):
        code = "def foo(x):\n    x = x + 1\nfoo(5)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertNotIn("global x", fixed)
        self.assertNotIn("nonlocal x", fixed)

    def test_unbound_local_not_in_outer_scope(self):
        code = "def foo():\n    y = y + 1\nfoo()"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertTrue("stopped at line" in self.explainer.last_fix_status)

    def test_stop_iteration_with_existing_default(self):
        code = "it = iter([])\nres = next(it, 42)"
        clean, _, _, _ = _run_in_sandbox(code)
        self.assertTrue(clean)

    def test_file_exists_open_x_never_modified(self):
        code = 'with open("test.txt", "x") as f:\n    f.write("a")'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertNotIn("makedirs", fixed)

    def test_json_decode_non_empty_malformed_not_modified(self):
        code = 'import json\njson.loads("{bad: 1}")'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertTrue("stopped at line" in self.explainer.last_fix_status)

    def test_unfixable_math_domain_error(self):
        code = "import math\nprint(math.sqrt(-1))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertTrue("stopped at line" in self.explainer.last_fix_status)

    def test_unfixable_missing_third_party_package(self):
        code = "import nonexistent_package_xyz_999"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertTrue("stopped at line" in self.explainer.last_fix_status)

    def test_unfixable_assertion_error(self):
        code = "assert 1 == 2, 'Invariant failed'"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertTrue("stopped at line" in self.explainer.last_fix_status)

    def test_unfixable_not_implemented_error(self):
        code = "raise NotImplementedError('TODO')"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertTrue("stopped at line" in self.explainer.last_fix_status)


class TestIterativeRepairLoop(unittest.TestCase):
    """Phase 4 Iterative Repair Loop tests."""

    def setUp(self):
        self.patcher = patch.dict(os.environ, {"AUTOFIX_AI": "0", "LLM_DISABLED": "1"})
        self.patcher.start()
        self.explainer = NLPExplainer()

    def tearDown(self):
        self.patcher.stop()

    def test_combined_multi_error_sequential_repair(self):
        combined = """message = "hello"
print(mesage)
def greet(name)
    print("Hi", name)
greet("Sam")
print("Total: " + 5)
nums = [3, 1, 2]
nums.apend(4)
for x in 100:
    print(x)
"""
        fixed = self.explainer.generate_fixed_code(combined)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertEqual(self.explainer.last_fix_source, "deterministic")
        self.assertGreaterEqual(len(self.explainer.last_fix_steps), 4)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertIn("hello", stdout)
        self.assertIn("Hi Sam", stdout)
        self.assertIn("Total: 5", stdout)

    def test_timeout_terminates_round_1(self):
        code = "while True: pass"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertEqual(self.explainer.last_fix_status, "no_fixer")
        self.assertEqual(len(self.explainer.last_fix_steps), 0)

    def test_already_clean_code(self):
        code = 'print("All clean")'
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertEqual(self.explainer.last_fix_status, "already_clean")
        self.assertEqual(self.explainer.last_fix_source, "none")
        self.assertEqual(len(self.explainer.last_fix_steps), 0)

    def test_partial_repair_reports_remaining_error(self):
        code = """def greet(name)
    print("Hello", name)
greet("Alice")
import nonexistent_pkg_98765
"""
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("def greet(name):", fixed)
        self.assertTrue(self.explainer.last_fix_status.startswith("fixed 1; stopped at line"))
        self.assertIn("ModuleNotFoundError", self.explainer.last_fix_status)


class TestMockedAIAcceptanceInvariants(unittest.TestCase):
    """Phase 5 Stricter AI-fix acceptance tests with mocked LLM calls."""

    def setUp(self):
        self.explainer = NLPExplainer()

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0"})
    @patch("llm_calls.call_gemini")
    def test_ai_accepts_valid_recursion_base_case(self, mock_gemini):
        orig_code = "def factorial(n):\n    return n * factorial(n - 1)\nprint(factorial(4))"
        patch_text = "Replace line 2 with:\n    if n <= 1: return 1\n    return n * factorial(n - 1)"
        mock_gemini.return_value = (patch_text, None, 0.001)

        fixed = self.explainer.generate_fixed_code(orig_code)
        self.assertIn("if n <= 1:", fixed)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0"})
    @patch("llm_calls.call_gemini")
    @patch("llm_calls.call_groq")
    def test_ai_rejects_lambda_stub_replacement(self, mock_groq, mock_gemini):
        orig_code = "def compute_value(x):\n    return x + 10\nprint(compute_value('bad'))"
        stub_patch = "Replace lines 1-2 with:\n    compute_value = lambda x: None"
        mock_gemini.return_value = (stub_patch, None, 0.001)
        mock_groq.return_value = (None, "failed", 0.001)

        fixed = self.explainer.generate_fixed_code(orig_code)
        self.assertNotIn("lambda", fixed)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0"})
    @patch("llm_calls.call_gemini")
    @patch("llm_calls.call_groq")
    def test_ai_rejects_deleted_function(self, mock_groq, mock_gemini):
        orig_code = "def worker():\n    print('working')\nworker()"
        del_patch = "Replace lines 1-2 with:\n    pass"
        mock_gemini.return_value = (del_patch, None, 0.001)
        mock_groq.return_value = (None, "failed", 0.001)

        fixed = self.explainer.generate_fixed_code(orig_code)
        self.assertNotIn(del_patch, fixed)

    @patch.dict(os.environ, {"AUTOFIX_AI": "1", "LLM_DISABLED": "0"})
    @patch("llm_calls.call_gemini")
    @patch("llm_calls.call_groq")
    def test_ai_rejects_forbidden_import(self, mock_groq, mock_gemini):
        orig_code = "def run():\n    x = 1 / 0\nrun()"
        bad_import_patch = "Add before line 1:\n    import socket"
        mock_gemini.return_value = (bad_import_patch, None, 0.001)
        mock_groq.return_value = (None, "failed", 0.001)

        fixed = self.explainer.generate_fixed_code(orig_code)
        self.assertNotIn("import socket", fixed)


class TestDeterministicRecursionFixer(unittest.TestCase):
    """6 positives and 4 negatives for narrow textbook recursion fixer."""

    def setUp(self):
        self.patcher = patch.dict(os.environ, {"AUTOFIX_AI": "0", "LLM_DISABLED": "1"})
        self.patcher.start()
        self.explainer = NLPExplainer()

    def tearDown(self):
        self.patcher.stop()

    # 6 Positives
    def test_positive_1_countdown_return(self):
        code = "def countdown(n):\n    return countdown(n - 1)\ncountdown(5)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if n <= 0:", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_positive_2_countdown_stmt(self):
        code = "def countdown(n):\n    print(n)\n    countdown(n - 1)\ncountdown(3)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if n <= 0:", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_positive_3_factorial_shape(self):
        code = "def fact(n):\n    return n * fact(n - 1)\nprint(fact(5))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if n <= 1:\n        return 1", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertIn("120", stdout)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_positive_4_factorial_reversed_mult(self):
        code = "def factorial(x):\n    return factorial(x - 1) * x\nprint(factorial(4))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if x <= 1:\n        return 1", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertIn("24", stdout)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_positive_5_fibonacci_shape(self):
        code = "def fib(n):\n    return fib(n - 1) + fib(n - 2)\nprint(fib(6))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if n <= 1:\n        return n", fixed)
        clean, _, _, _, stdout, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertIn("8", stdout)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    def test_positive_6_countdown_wrapped_comment_and_blank_lines(self):
        code = "# recursion test\n\n\ndef countdown(n):\n    return countdown(n - 1)\n\ncountdown(5)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("if n <= 0:", fixed)
        self.assertIn("# recursion test", fixed)
        clean, _, _, _, _, _ = _run_in_sandbox_full(fixed)
        self.assertTrue(clean)
        self.assertEqual(self.explainer.last_fix_status, "applied")

    # 4 Negatives (must remain unfixed)
    def test_negative_1_no_parameter_function(self):
        code = "def loop_forever():\n    return loop_forever()\nloop_forever()"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertNotEqual(self.explainer.last_fix_status, "applied")

    def test_negative_2_mutual_recursion(self):
        code = "def func_a(n):\n    return func_b(n - 1)\ndef func_b(n):\n    return func_a(n - 1)\nfunc_a(5)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertNotEqual(self.explainer.last_fix_status, "applied")

    def test_negative_3_multiple_parameters(self):
        code = "def ackermann(m, n):\n    return ackermann(m, n - 1)\nackermann(2, 3)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertNotEqual(self.explainer.last_fix_status, "applied")

    def test_negative_4_existing_base_case_still_recursing(self):
        code = "def buggy(n):\n    if n == -999:\n        return 0\n    return buggy(n - 1)\nbuggy(5)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(fixed, code)
        self.assertNotEqual(self.explainer.last_fix_status, "applied")


if __name__ == "__main__":
    unittest.main()
