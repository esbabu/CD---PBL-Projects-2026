# ATTACK CORPUS & SIMULATOR HARNESS

## DEFENSIVE TESTING ONLY

This directory contains defensive red-teaming test fixtures, an attack corpus, a local mock exfiltration receiver, and an automated attack simulator for the **IntelliFix AAI Shield**.

### Strict Safety Constraints:
1. **Defensive Evaluation Only**: All attack payloads are harmless stand-ins designed exclusively to test defensive boundaries, prompt injection filtering, tool guard path checks, code guard AST inspections, and output redaction.
2. **Fake Data Exclusively**: Payloads interact only with fake mock data (`lab_data/fake_personal_info.txt`). No real files, host environment variables, personal credentials, or live accounts are touched.
3. **Local Mock Receiver Confinement**: Any network interaction is strictly confined to `127.0.0.1` on an ephemeral local port managed by `mock_receiver.py`. No external internet traffic is ever initiated.
4. **Isolated Process Flag**: Attack lab simulation modes run only within their own dedicated process environments using `INTELLIFIX_ATTACK_LAB=1` and `SHIELD_ENABLED=0|1`. They never modify global or persistent configuration files.
