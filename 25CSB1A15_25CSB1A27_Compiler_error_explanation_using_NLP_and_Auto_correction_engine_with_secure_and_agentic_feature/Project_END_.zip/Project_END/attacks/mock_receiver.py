"""attacks/mock_receiver.py - Harmless Local Mock Receiver for Defensive Exfiltration Testing.

Binds strictly to 127.0.0.1 on a dynamic ephemeral port.
Logs and records all incoming test payloads in memory for defensive verification.
Never contacts external servers or networks.
"""

import http.server
import socket
import threading
import time
from typing import Any, Dict, List, Optional, Tuple


class MockReceiverHandler(http.server.BaseHTTPRequestHandler):
    """Local HTTP handler recording incoming requests in memory."""

    def log_message(self, format, *args):
        """Suppress default console logging during automated test runs."""
        pass

    def do_GET(self):
        self.server.record_request("GET", self.path, self.headers, b"")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"status":"received","receiver":"mock_127.0.0.1"}')

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else b""
        self.server.record_request("POST", self.path, self.headers, body)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"status":"exfiltration_simulated","received_bytes":' + str(len(body)).encode("ascii") + b'}')


class MockReceiverServer(http.server.HTTPServer):
    """Threaded HTTPServer binding strictly to 127.0.0.1."""

    def __init__(self, host: str = "127.0.0.1", port: int = 0):
        # Force 127.0.0.1 loopback only
        if host not in ("127.0.0.1", "localhost"):
            raise ValueError(f"Mock receiver cannot bind to non-loopback interface: {host}")
        super().__init__((host, port), MockReceiverHandler)
        self.received_requests: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def record_request(self, method: str, path: str, headers: Any, body: bytes):
        with self._lock:
            self.received_requests.append({
                "timestamp": time.time(),
                "method": method,
                "path": path,
                "headers": dict(headers),
                "body": body.decode("utf-8", errors="replace"),
                "raw_bytes": body
            })


class LocalMockReceiver:
    """Manages the background execution of the local mock receiver."""

    def __init__(self, host: str = "127.0.0.1", port: int = 0):
        self.host = host
        self.requested_port = port
        self.server: Optional[MockReceiverServer] = None
        self.thread: Optional[threading.Thread] = None
        self.actual_port: int = 0

    def start(self) -> int:
        """Starts the server in a background daemon thread and returns assigned port."""
        self.server = MockReceiverServer(self.host, self.requested_port)
        self.actual_port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self.actual_port

    def stop(self):
        """Shuts down and cleans up the server."""
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)
            self.thread = None

    @property
    def url(self) -> str:
        """Returns base URL of the active receiver."""
        return f"http://{self.host}:{self.actual_port}"

    @property
    def requests(self) -> List[Dict[str, Any]]:
        """Returns list of recorded requests."""
        if self.server:
            return list(self.server.received_requests)
        return []

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
