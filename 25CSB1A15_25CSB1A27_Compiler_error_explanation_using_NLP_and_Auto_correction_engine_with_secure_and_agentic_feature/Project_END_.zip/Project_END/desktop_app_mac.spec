# -*- mode: python ; coding: utf-8 -*-
# macOS .app bundle spec for TOC Studio

import sys
import os
import glob
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# ── Data files to bundle ─────────────────────────────────────────────────────
datas = [
    ('templates', 'templates'),
]

for optional_dir in ['results', 'attacks', 'benchmark', 'lab_data', 'docs']:
    # Skip 'security' — it's a Python package, PyInstaller collects it automatically.
    # Including it as datas causes a symlink conflict on macOS.
    if os.path.exists(optional_dir):
        datas.append((optional_dir, optional_dir))

for optional_file in ['data.json', 'emissions.csv']:
    if os.path.exists(optional_file):
        datas.append((optional_file, '.'))

# Bundle all .py source files (needed for runtime hash/introspection)
for py_file in glob.glob('*.py'):
    datas.append((py_file, '.'))

# Bundle .env so API keys work inside the .app
if os.path.exists('.env'):
    datas.append(('.env', '.'))

datas += collect_data_files('webview')
datas += collect_data_files('flask')
datas += collect_data_files('jinja2')

# ── Hidden imports ────────────────────────────────────────────────────────────
hiddenimports = [
    'webview',
    'webview.platforms.cocoa',   # macOS WKWebView backend
    'flask',
    'flask_cors',
    'jinja2',
    'jinja2.ext',
    'werkzeug',
    'werkzeug.serving',
    'werkzeug.debug',
    'psutil',
    'requests',
    'urllib3',
    'dotenv',
    'google.genai',
    'groq',
    'code_quality',
    'sandbox_child',
    'sandbox_runner',
    'multi_error',
    'error_extractor',
    'nlp_explainer',
    'ir_generator',
    'llm_calls',
    'llm_config',
    'llm_explainer',
    'intellifix',
]
hiddenimports += collect_submodules('webview')
hiddenimports += collect_submodules('flask')

# ── Analysis ──────────────────────────────────────────────────────────────────
a = Analysis(
    ['desktop_app.py'],
    pathex=['.'],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'torch', 'transformers', 'matplotlib', 'scipy',
        'IPython', 'jupyter', 'notebook', 'tkinter',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ── Executable ────────────────────────────────────────────────────────────────
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='TOC_Studio',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,          # UPX not needed on macOS
    console=False,      # No terminal window
    disable_windowed_traceback=False,
    argv_emulation=True,  # Required for macOS open-with / file-drop support
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

# ── Collect all binaries/datas into the .app bundle ──────────────────────────
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='TOC_Studio',
)

# ── macOS .app Bundle ─────────────────────────────────────────────────────────
app = BUNDLE(
    coll,
    name='TOC Studio.app',
    icon=None,                     # Set to 'icon.icns' if you have one
    bundle_identifier='com.tocstudio.app',
    info_plist={
        'NSPrincipalClass': 'NSApplication',
        'NSAppleScriptEnabled': False,
        'CFBundleName': 'TOC Studio',
        'CFBundleDisplayName': 'TOC Studio',
        'CFBundleShortVersionString': '3.2.0',
        'CFBundleVersion': '3.2.0',
        'NSHighResolutionCapable': True,
        'LSMinimumSystemVersion': '11.0',
    },
)
