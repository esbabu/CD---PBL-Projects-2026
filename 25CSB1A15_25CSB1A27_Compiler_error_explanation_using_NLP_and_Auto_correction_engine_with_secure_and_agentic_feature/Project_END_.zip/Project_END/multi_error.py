"""
multi_error.py - Whole-program multi-error detection and multi-fix engine for IntelliFix.

Layers:
  Layer 1: Syntax Analysis (incremental loop, missing colons/delimiters, neutralisation for scan copy)
  Layer 2: Static Analysis (pure AST, scoping, arg count, duplicate parameters, compile invariants)
  Layer 3: Runtime Execution & Instrumentation (sandboxed, statement try-wrapping, cascade poisoning, coverage)
  Layer 4: Fix All Multi-Round Engine (deterministic + AI fallback, bottom-up application, progress acceptance)
"""

import os
import sys
import json
import builtins
import ast
import re
import io
import time
import copy
import tokenize
import difflib
import hashlib
from typing import Dict, Any, List, Tuple, Optional, Set

from sandbox_runner import run_in_sandbox
import nlp_explainer

DEFAULT_MAX_ERRORS = 50
DEFAULT_MAX_ROUNDS = 20
DEFAULT_MAX_TIME_SEC = 60.0
DEFAULT_MAX_AI_CALLS = 3

_BUILTIN_NAMES = set(dir(builtins)) | {
    "__name__", "__doc__", "__file__", "__package__", "__annotations__", "__builtins__"
}


def is_multi_error_enabled() -> bool:
    """Returns True unless explicitly disabled via MULTI_ERROR=0."""
    return os.environ.get("MULTI_ERROR", "1") != "0"


class MultiErrorItem:
    """Structured representation of a detected code defect."""
    def __init__(
        self,
        err_id: str,
        line: Optional[int],
        column: Optional[int],
        error_type: str,
        message: str,
        category: str,  # "syntax", "static", "runtime", "environment"
        origin: str = "detected",  # "detected", "cascade"
        cascade_of: Optional[str] = None,
        reached: bool = True,
        explanation: str = "",
        fix_status: str = "no_fixer",  # "fixed", "suggested", "no_fixer", "rejected: <reason>"
        fix_source: Optional[str] = None,  # "rule", "deterministic", "ai", None
        fix_provider: Optional[str] = None,
        traceback_str: str = "",
        bracket_hint: Optional[Dict[str, Any]] = None
    ):
        self.id = err_id
        self.line = line
        self.column = column
        self.error_type = error_type
        self.message = message
        self.category = category
        self.origin = origin
        self.cascade_of = cascade_of
        self.reached = reached
        self.explanation = explanation
        self.fix_status = fix_status
        self.fix_source = fix_source
        self.fix_provider = fix_provider
        self.traceback_str = traceback_str
        self.bracket_hint = bracket_hint

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "id": self.id,
            "line": self.line,
            "column": self.column,
            "error_type": self.error_type,
            "message": self.message,
            "category": self.category,
            "origin": self.origin,
            "cascade_of": self.cascade_of,
            "reached": self.reached,
            "explanation": self.explanation,
            "fix": {
                "status": self.fix_status,
                "source": self.fix_source,
                "provider": self.fix_provider
            }
        }
        if self.bracket_hint is not None:
            d["bracket_hint"] = self.bracket_hint
        return d


# ==============================================================================
# DETERMINISTIC & RULE FIXERS
# ==============================================================================

def fix_missing_colon(err_type: str, err_msg: str, line_no: Optional[int], code_str: str) -> Optional[str]:
    """Adds missing colon to control headers (if/elif/else/for/while/def/class/with/try/except/finally)."""
    if not line_no or line_no <= 0:
        return None
    lines = code_str.splitlines()
    if line_no > len(lines):
        return None
    idx = line_no - 1
    target_line = lines[idx]
    stripped = target_line.rstrip()
    if not stripped.endswith(":"):
        if re.match(r"^\s*(?:if|elif|else|for|while|def|class|with|try|except|finally)\b", stripped):
            if "#" in target_line:
                code_p, comm_p = target_line.split("#", 1)
                if not code_p.rstrip().endswith(":"):
                    lines[idx] = f"{code_p.rstrip()}: # AUTO-FIX #{comm_p}"
            else:
                lines[idx] = stripped + ":"
            newline_sep = "\r\n" if "\r\n" in code_str else "\n"
            return newline_sep.join(lines)
    return None


def get_deterministic_fix(err_type: str, err_msg: str, line_no: Optional[int], code_str: str) -> Optional[Tuple[str, str, str]]:
    """
    Attempts all deterministic and rule fixers on code_str for the given error.
    Returns (fixed_code, fix_source, fixer_name) or None.
    """
    explainer = nlp_explainer.NLPExplainer()

    # 1. Missing colon
    colon_cand = fix_missing_colon(err_type, err_msg, line_no, code_str)
    if colon_cand and colon_cand != code_str:
        return colon_cand, "rule", "missing_colon"

    # 2. Explainer's built-in rule / deterministic fixers
    cand = explainer._apply_deterministic_fix(err_type, err_msg, line_no, code_str)
    if cand and cand != code_str:
        src = getattr(explainer, "last_fix_source", "rule") or "rule"
        name = getattr(explainer, "last_fixer_name", "rule") or "rule"
        return cand, src, name

    return None


# ==============================================================================
# LAYER 1: SYNTAX ANALYSIS & NEUTRALISATION
# ==============================================================================

def scan_syntax_errors(code_str: str, max_syntax_errors: int = DEFAULT_MAX_ERRORS, generate_explanations: bool = True) -> Tuple[List[MultiErrorItem], str, str]:
    """
    Scans for multiple syntax errors iteratively.
    Attempts syntax fixers on a working copy; if unfixable, neutralises the offending
    statement only in the analysis copy to continue scanning subsequent code.
    Returns: (list_of_syntax_errors, analysis_scan_code, verified_fixed_syntax_code)
    """
    errors: List[MultiErrorItem] = []
    analysis_code = code_str
    fixed_syntax_code = code_str
    seen_errors = set()
    explainer = nlp_explainer.NLPExplainer()

    for iteration in range(max_syntax_errors):
        try:
            ast.parse(analysis_code)
            # Clean AST reached
            break
        except SyntaxError as e:
            lineno = e.lineno or 1
            col = e.offset
            err_msg = e.msg or str(e)
            err_type = type(e).__name__
            err_key = (lineno, col, err_msg)

            if err_key in seen_errors:
                break
            seen_errors.add(err_key)

            err_id = f"err_{len(errors) + 1}"
            
            # Form explanation
            ir_dict = {
                "error_type": err_type,
                "error_message": err_msg,
                "line_number": lineno,
                "traceback": f'File "<string>", line {lineno}\n    {e.text or ""}\n{err_type}: {err_msg}',
                "code": code_str
            }
            if generate_explanations:
                try:
                    expl = explainer.explain(ir_dict, code_str)
                except Exception:
                    expl = f"Mistake: Syntax error at line {lineno}. Reason: {err_msg}. Fix: Check syntax on line {lineno}."
            else:
                expl = f"SyntaxError at line {lineno}: {err_msg}"

            # Check for bracket-related syntax error hint
            bracket_hint = None
            if any(p in err_msg.lower() for p in ["was never closed", "unmatched", "does not match opening parenthesis"]):
                try:
                    import bracket_checker
                    b_check = bracket_checker.check_brackets(code_str)
                    if b_check.get("problems"):
                        # Match problem by line number if possible
                        matched_prob = next((p for p in b_check["problems"] if p.get("line") == lineno), b_check["problems"][0])
                        bracket_hint = matched_prob
                except Exception:
                    pass

            item = MultiErrorItem(
                err_id=err_id,
                line=lineno,
                column=col,
                error_type=err_type,
                message=err_msg,
                category="syntax",
                origin="detected",
                explanation=expl,
                traceback_str=ir_dict["traceback"],
                bracket_hint=bracket_hint
            )

            # Try applying deterministic syntax fix on working copy
            fix_res = get_deterministic_fix(err_type, err_msg, lineno, analysis_code)
            if fix_res:
                fixed_cand, src, name = fix_res
                # Also update fixed_syntax_code
                fix_fixed_res = get_deterministic_fix(err_type, err_msg, lineno, fixed_syntax_code)
                if fix_fixed_res:
                    fixed_syntax_code = fix_fixed_res[0]
                else:
                    fixed_syntax_code = fixed_cand

                try:
                    ast.parse(fixed_cand)
                    item.fix_status = "fixed"
                    item.fix_source = src
                    analysis_code = fixed_cand
                    errors.append(item)
                    continue
                except SyntaxError as next_e:
                    if (next_e.lineno or 1) > lineno:
                        item.fix_status = "fixed"
                        item.fix_source = src
                        analysis_code = fixed_cand
                        errors.append(item)
                        continue

            # Unfixable syntax error -> neutralise in analysis copy only to scan remaining lines
            item.fix_status = "no_fixer"
            errors.append(item)
            analysis_code = _neutralise_statement_at_line(analysis_code, lineno)

    return errors, analysis_code, fixed_syntax_code


def _neutralise_statement_at_line(code_str: str, target_line: int) -> str:
    """
    Neutralises the statement at target_line in analysis copy by replacing it with `pass`
    at the same indentation level, preserving exact total line count and line numbers.
    """
    lines = code_str.splitlines()
    if not (1 <= target_line <= len(lines)):
        return code_str

    idx = target_line - 1
    orig_line = lines[idx]
    indent_len = len(orig_line) - len(orig_line.lstrip())
    indent = orig_line[:indent_len] if indent_len > 0 else ""

    lines[idx] = f"{indent}pass"

    stripped = orig_line.strip()
    if stripped.endswith(":") or any(stripped.startswith(k) for k in ("def ", "class ", "if ", "elif ", "else:", "for ", "while ", "try:", "except", "finally:", "with ")):
        i = idx + 1
        while i < len(lines):
            next_line = lines[i]
            if not next_line.strip():
                i += 1
                continue
            next_indent_len = len(next_line) - len(next_line.lstrip())
            if next_indent_len > indent_len:
                lines[i] = f"{next_line[:next_indent_len]}pass"
                i += 1
            else:
                break

    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    return newline_sep.join(lines)


# ==============================================================================
# LAYER 2: STATIC ANALYSIS (PURE AST, SCOPING, ARG COUNT)
# ==============================================================================

class ScopeContext:
    def __init__(self, parent=None, scope_type="module"):
        self.parent = parent
        self.scope_type = scope_type
        self.defined_names: Set[str] = set()
        self.global_names: Set[str] = set()
        self.nonlocal_names: Set[str] = set()
        self.referenced_names: List[Tuple[str, int, int]] = []
        self.functions: Dict[str, Tuple[int, int, bool]] = {}


class StaticASTScanner(ast.NodeVisitor):
    def __init__(self, raw_code: str):
        self.raw_code = raw_code
        self.errors: List[MultiErrorItem] = []
        self.has_dynamic_scope = False
        self.global_scope = ScopeContext(scope_type="module")
        self.current_scope = self.global_scope
        self.defined_functions: Dict[str, Dict[str, Any]] = {}
        self.lines = raw_code.splitlines()

    def _enter_scope(self, scope_type: str) -> ScopeContext:
        new_scope = ScopeContext(parent=self.current_scope, scope_type=scope_type)
        self.current_scope = new_scope
        return new_scope

    def _exit_scope(self) -> None:
        if self.current_scope.parent:
            self.current_scope = self.current_scope.parent

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.asname or alias.name.split('.')[0]
            self.current_scope.defined_names.add(name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module and node.names and node.names[0].name == '*':
            if node.module not in nlp_explainer.ALLOWED_STDLIB_MODULES:
                self.has_dynamic_scope = True
        else:
            for alias in node.names:
                name = alias.asname or alias.name
                self.current_scope.defined_names.add(name)
        self.generic_visit(node)

    def visit_Global(self, node: ast.Global) -> None:
        for name in node.names:
            self.current_scope.global_names.add(name)

    def visit_Nonlocal(self, node: ast.Nonlocal) -> None:
        for name in node.names:
            self.current_scope.nonlocal_names.add(name)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.current_scope.defined_names.add(node.name)
        
        seen_args = set()
        for a in node.args.args + getattr(node.args, 'posonlyargs', []) + node.args.kwonlyargs:
            if a.arg in seen_args:
                self.errors.append(MultiErrorItem(
                    err_id=f"static_{len(self.errors)+1}",
                    line=node.lineno,
                    column=node.col_offset,
                    error_type="SyntaxError",
                    message=f"duplicate argument '{a.arg}' in function definition",
                    category="static",
                    origin="detected",
                    explanation=f"Mistake: Duplicate argument '{a.arg}' in function '{node.name}'. Reason: Function parameters must have distinct names. Fix: Rename or remove the duplicate parameter."
                ))
            seen_args.add(a.arg)

        pos_args = len(node.args.args) + len(getattr(node.args, 'posonlyargs', []))
        defaults = len(node.args.defaults)
        min_args = pos_args - defaults
        max_args = pos_args
        has_varargs = node.args.vararg is not None
        has_kwargs = node.args.kwarg is not None
        self.defined_functions[node.name] = {
            "min_args": min_args,
            "max_args": max_args,
            "has_varargs": has_varargs,
            "has_kwargs": has_kwargs,
            "lineno": node.lineno
        }

        self._enter_scope("function")
        for a in seen_args:
            self.current_scope.defined_names.add(a)
        if node.args.vararg:
            self.current_scope.defined_names.add(node.args.vararg.arg)
        if node.args.kwarg:
            self.current_scope.defined_names.add(node.args.kwarg.arg)

        for stmt in node.body:
            self.visit(stmt)
        self._exit_scope()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.visit_FunctionDef(node)  # type: ignore

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.current_scope.defined_names.add(node.name)
        self._enter_scope("class")
        for stmt in node.body:
            self.visit(stmt)
        self._exit_scope()

    def visit_Assign(self, node: ast.Assign) -> None:
        self.visit(node.value)
        for target in node.targets:
            for t_node in ast.walk(target):
                if isinstance(t_node, ast.Name) and isinstance(t_node.ctx, ast.Store):
                    if t_node.id in self.current_scope.global_names:
                        self.global_scope.defined_names.add(t_node.id)
                    else:
                        self.current_scope.defined_names.add(t_node.id)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self.visit(node.value)
        if isinstance(node.target, ast.Name):
            self.visit_Name(node.target)
            self.current_scope.defined_names.add(node.target.id)

    def visit_NamedExpr(self, node: ast.NamedExpr) -> None:
        self.visit(node.value)
        if isinstance(node.target, ast.Name):
            curr = self.current_scope
            while curr.parent and curr.scope_type in ("comprehension", "lambda"):
                curr = curr.parent
            curr.defined_names.add(node.target.id)

    def visit_For(self, node: ast.For) -> None:
        self.visit(node.iter)
        for t_node in ast.walk(node.target):
            if isinstance(t_node, ast.Name):
                self.current_scope.defined_names.add(t_node.id)
        for stmt in node.body:
            self.visit(stmt)
        for stmt in node.orelse:
            self.visit(stmt)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            if node.id in ("globals", "exec", "setattr", "eval", "locals"):
                self.has_dynamic_scope = True
            self.current_scope.referenced_names.append((node.id, node.lineno, node.col_offset))

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Name):
            fn_name = node.func.id
            if fn_name in self.defined_functions:
                sig = self.defined_functions[fn_name]
                if not sig["has_varargs"] and not sig["has_kwargs"]:
                    num_pos_given = len(node.args)
                    if num_pos_given < sig["min_args"] or num_pos_given > sig["max_args"]:
                        exp_str = f"{sig['min_args']}" if sig["min_args"] == sig["max_args"] else f"{sig['min_args']} to {sig['max_args']}"
                        self.errors.append(MultiErrorItem(
                            err_id=f"static_{len(self.errors)+1}",
                            line=node.lineno,
                            column=node.col_offset,
                            error_type="TypeError",
                            message=f"{fn_name}() takes {exp_str} positional arguments but {num_pos_given} were given",
                            category="static",
                            origin="detected",
                            explanation=f"Mistake: Wrong number of arguments passed to function '{fn_name}'. Reason: Function expected {exp_str} arguments but received {num_pos_given}. Fix: Update the call to '{fn_name}' with the correct parameters."
                        ))
        self.generic_visit(node)


def scan_static_errors(code_str: str) -> List[MultiErrorItem]:
    """
    Performs conservative AST-based static error detection (scoping, duplicate args, arg count).
    """
    try:
        tree = ast.parse(code_str)
    except Exception:
        return []

    scanner = StaticASTScanner(code_str)
    try:
        scanner.visit(tree)
    except Exception:
        return []

    errors = list(scanner.errors)

    if not scanner.has_dynamic_scope:
        explainer = nlp_explainer.NLPExplainer()
        def check_scope_names(scope: ScopeContext):
            for name, lineno, col in scope.referenced_names:
                if name in _BUILTIN_NAMES or name in nlp_explainer.ALLOWED_STDLIB_MODULES:
                    continue
                curr = scope
                found = False
                while curr:
                    if name in curr.defined_names or name in curr.global_names:
                        found = True
                        break
                    curr = curr.parent
                if not found:
                    ir_dict = {
                        "error_type": "NameError",
                        "error_message": f"name '{name}' is not defined",
                        "line_number": lineno,
                        "code": code_str
                    }
                    try:
                        expl = explainer.explain(ir_dict, code_str)
                    except Exception:
                        expl = f"Mistake: Using undefined name '{name}'. Reason: Name '{name}' is referenced before definition. Fix: Define '{name}' before using it."

                    errors.append(MultiErrorItem(
                        err_id=f"static_{len(errors)+1}",
                        line=lineno,
                        column=col,
                        error_type="NameError",
                        message=f"name '{name}' is not defined",
                        category="static",
                        origin="detected",
                        explanation=expl
                    ))

        check_scope_names(scanner.global_scope)

    return errors


# ==============================================================================
# LAYER 3: RUNTIME EXECUTION & INSTRUMENTATION
# ==============================================================================

def instrument_ast_for_multi_runtime(code_str: str) -> Tuple[str, Dict[int, List[str]]]:
    """
    Wraps module and block simple statements (assignments, expressions, imports, deletes, etc.)
    in try-except blocks capturing exceptions into `__intelli_errors__`, poisoning assigned
    variables on failure, and recording line execution markers.
    """
    try:
        tree = ast.parse(code_str)
    except Exception:
        return code_str, {}

    stmt_targets: Dict[int, List[str]] = {}

    class StatementInstrumenter(ast.NodeTransformer):
        def __init__(self):
            self.in_function = False

        def _make_mark_stmt(self, lineno: int) -> ast.Expr:
            return ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='__intelli_mark_line__', ctx=ast.Load()),
                    args=[ast.Constant(value=lineno)],
                    keywords=[]
                )
            )

        def _make_record_handler(self, lineno: int, targets: List[str]) -> List[ast.stmt]:
            return [
                ast.Expr(
                    value=ast.Call(
                        func=ast.Name(id='__intelli_record_error__', ctx=ast.Load()),
                        args=[
                            ast.Constant(value=lineno),
                            ast.Call(
                                func=ast.Attribute(
                                    value=ast.Name(id='sys', ctx=ast.Load()),
                                    attr='exc_info',
                                    ctx=ast.Load()
                                ),
                                args=[],
                                keywords=[]
                            ),
                            ast.List(
                                elts=[ast.Constant(value=t) for t in targets],
                                ctx=ast.Load()
                            )
                        ],
                        keywords=[]
                    )
                )
            ]

        def _instrument_stmt_list(self, stmts: List[ast.stmt]) -> List[ast.stmt]:
            new_stmts = []
            for stmt in stmts:
                lineno = getattr(stmt, 'lineno', 0)
                targets = []
                for n in ast.walk(stmt):
                    if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                        targets.append(n.id)
                if lineno > 0 and targets:
                    stmt_targets[lineno] = targets

                if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    mark_stmt = self._make_mark_stmt(lineno)
                    stmt.body = self._instrument_stmt_list(stmt.body)
                    new_stmts.append(mark_stmt)
                    new_stmts.append(stmt)
                elif isinstance(stmt, ast.ClassDef):
                    mark_stmt = self._make_mark_stmt(lineno)
                    stmt.body = self._instrument_stmt_list(stmt.body)
                    new_stmts.append(mark_stmt)
                    new_stmts.append(stmt)
                elif isinstance(stmt, (ast.For, ast.AsyncFor, ast.While)):
                    stmt.body = self._instrument_stmt_list(stmt.body)
                    stmt.orelse = self._instrument_stmt_list(stmt.orelse)
                    mark_stmt = self._make_mark_stmt(lineno)
                    handler_ast = self._make_record_handler(lineno, targets)
                    try_node = ast.Try(
                        body=[mark_stmt, stmt],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id='BaseException', ctx=ast.Load()),
                                name=None,
                                body=handler_ast
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )
                    new_stmts.append(try_node)
                elif isinstance(stmt, ast.If):
                    stmt.body = self._instrument_stmt_list(stmt.body)
                    stmt.orelse = self._instrument_stmt_list(stmt.orelse)
                    mark_stmt = self._make_mark_stmt(lineno)
                    handler_ast = self._make_record_handler(lineno, [])
                    try_node = ast.Try(
                        body=[mark_stmt, stmt],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id='BaseException', ctx=ast.Load()),
                                name=None,
                                body=handler_ast
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )
                    new_stmts.append(try_node)
                elif isinstance(stmt, (ast.With, ast.AsyncWith)):
                    stmt.body = self._instrument_stmt_list(stmt.body)
                    mark_stmt = self._make_mark_stmt(lineno)
                    handler_ast = self._make_record_handler(lineno, [])
                    try_node = ast.Try(
                        body=[mark_stmt, stmt],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id='BaseException', ctx=ast.Load()),
                                name=None,
                                body=handler_ast
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )
                    new_stmts.append(try_node)
                elif isinstance(stmt, (ast.Return, ast.Yield, ast.YieldFrom, ast.Raise)):
                    mark_stmt = self._make_mark_stmt(lineno)
                    handler_ast = self._make_record_handler(lineno, [])
                    try_node = ast.Try(
                        body=[mark_stmt, stmt],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id='BaseException', ctx=ast.Load()),
                                name=None,
                                body=handler_ast
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )
                    new_stmts.append(try_node)
                elif isinstance(stmt, (ast.Assign, ast.AugAssign, ast.AnnAssign, ast.Expr, ast.Delete, ast.Assert, ast.Pass, ast.Import, ast.ImportFrom, ast.Global, ast.Nonlocal)):
                    mark_stmt = self._make_mark_stmt(lineno)
                    handler_ast = self._make_record_handler(lineno, targets)
                    try_node = ast.Try(
                        body=[mark_stmt, stmt],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id='BaseException', ctx=ast.Load()),
                                name=None,
                                body=handler_ast
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )
                    new_stmts.append(try_node)
                elif isinstance(stmt, ast.Try):
                    stmt.body = self._instrument_stmt_list(stmt.body)
                    for h in stmt.handlers:
                        h.body = self._instrument_stmt_list(h.body)
                    stmt.orelse = self._instrument_stmt_list(stmt.orelse)
                    stmt.finalbody = self._instrument_stmt_list(stmt.finalbody)
                    new_stmts.append(stmt)
                else:
                    new_stmts.append(stmt)
            return new_stmts

        def visit_Module(self, node: ast.Module) -> ast.AST:
            node.body = self._instrument_stmt_list(node.body)
            return node

    new_tree = StatementInstrumenter().visit(tree)
    ast.fix_missing_locations(new_tree)

    harness_preamble = (
        "import sys, traceback\n"
        "__intelli_errors__ = []\n"
        "__intelli_executed_lines__ = set()\n"
        "__intelli_poisoned_vars__ = {}\n\n"
        "def __intelli_mark_line__(lineno):\n"
        "    if lineno:\n"
        "        __intelli_executed_lines__.add(lineno)\n\n"
        "def __intelli_record_error__(lineno, exc_info, targets):\n"
        "    exc_type, exc_val, tb = exc_info\n"
        "    if exc_type is None or exc_type is SystemExit:\n"
        "        return\n"
        "    err_name = getattr(exc_type, '__name__', str(exc_type))\n"
        "    err_msg = str(exc_val)\n"
        "    tb_str = ''.join(traceback.format_exception(exc_type, exc_val, tb))\n"
        "    __intelli_errors__.append({\n"
        "        'line': lineno,\n"
        "        'error_type': err_name,\n"
        "        'message': err_msg,\n"
        "        'traceback': tb_str,\n"
        "        'targets': targets\n"
        "    })\n"
        "    for t in targets:\n"
        "        __intelli_poisoned_vars__[t] = len(__intelli_errors__)\n\n"
    )

    harness_postamble = (
        "\n\n# --- INTELLIFIX RUNTIME MULTI EMIT ---\n"
        "import json\n"
        "print('---INTELLI_MULTI_REPORT_START---')\n"
        "print(json.dumps({\n"
        "    'errors': __intelli_errors__, \n"
        "    'executed_lines': list(__intelli_executed_lines__), \n"
        "    'poisoned_vars': __intelli_poisoned_vars__\n"
        "}))\n"
        "print('---INTELLI_MULTI_REPORT_END---')\n"
    )

    unparsed = ast.unparse(new_tree)
    full_instrumented = harness_preamble + unparsed + harness_postamble
    return full_instrumented, stmt_targets


def execute_sandboxed_multi_runtime(
    code_str: str,
    timeout: float = 5.0
) -> Tuple[List[Dict[str, Any]], Set[int], Dict[str, int], Optional[str]]:
    """
    Runs AST-instrumented code in the isolated sandbox.
    """
    instrumented_code, _ = instrument_ast_for_multi_runtime(code_str)

    res = run_in_sandbox(instrumented_code, timeout=timeout)
    status = res.get("status", "ok")
    stdout = res.get("stdout", "")
    stderr = res.get("stderr", "")

    stopped_reason = None
    if status == "timeout":
        stopped_reason = "timeout"
    elif status == "memory_exceeded":
        stopped_reason = "memory limit exceeded"
    elif status == "violation":
        stopped_reason = "security violation"
    elif status == "output_limit":
        stopped_reason = "output limit exceeded"

    raw_errors: List[Dict[str, Any]] = []
    executed_lines: Set[int] = set()
    poisoned_vars: Dict[str, int] = {}

    if "---INTELLI_MULTI_REPORT_START---" in stdout:
        try:
            part = stdout.split("---INTELLI_MULTI_REPORT_START---", 1)[1]
            json_part = part.split("---INTELLI_MULTI_REPORT_END---", 1)[0].strip()
            payload = json.loads(json_part)
            raw_errors = payload.get("errors", [])
            executed_lines = set(payload.get("executed_lines", []))
            poisoned_vars = payload.get("poisoned_vars", {})
        except Exception:
            pass

    if not raw_errors and res.get("error"):
        err = res["error"]
        raw_errors.append({
            "line": err.get("line_number"),
            "error_type": err.get("error_type"),
            "message": err.get("error_message"),
            "traceback": err.get("traceback", ""),
            "targets": []
        })

    user_stdout = ""
    if "---INTELLI_MULTI_REPORT_START---" in stdout:
        user_stdout = stdout.split("---INTELLI_MULTI_REPORT_START---", 1)[0].rstrip("\r\n")
    else:
        user_stdout = stdout.rstrip("\r\n")

    return raw_errors, executed_lines, poisoned_vars, stopped_reason, user_stdout


# ==============================================================================
# WHOLE-PROGRAM SCAN & DEDUPLICATION
# ==============================================================================

def scan_all_errors(code_str: str, generate_explanations: bool = True) -> Tuple[List[MultiErrorItem], Dict[str, Any], str]:
    """
    Executes Layers 1, 2, and 3, deduplicating across layers and tagging cascade errors.
    """
    all_errors: List[MultiErrorItem] = []
    seen_keys: Set[Tuple[Optional[int], str]] = set()

    statements_total = 0
    total_statement_lines: Set[int] = set()
    try:
        tree = ast.parse(code_str)
        for node in ast.walk(tree):
            if isinstance(node, ast.stmt):
                statements_total += 1
                if hasattr(node, 'lineno'):
                    total_statement_lines.add(node.lineno)
    except Exception:
        pass

    # 1. Layer 1: Syntax
    syntax_errors, clean_ast_code, fixed_syntax_code = scan_syntax_errors(code_str, generate_explanations=generate_explanations)
    for err in syntax_errors:
        key = (err.line, err.error_type)
        if key not in seen_keys:
            seen_keys.add(key)
            all_errors.append(err)

    scan_code = clean_ast_code if syntax_errors else code_str

    # 2. Layer 2: Static Analysis
    static_errors = scan_static_errors(scan_code)
    for err in static_errors:
        key = (err.line, err.error_type)
        if key not in seen_keys:
            seen_keys.add(key)
            all_errors.append(err)

    # 3. Layer 3: Runtime Execution
    is_sec_blocked = False
    try:
        import security_analyzer
        gate = security_analyzer.scan_gate(scan_code)
        if not gate["allowed"]:
            is_sec_blocked = True
    except Exception:
        pass

    executed_lines: Set[int] = set()
    poisoned_vars: Dict[str, int] = {}
    stopped_reason: Optional[str] = None

    user_stdout = ""
    if not is_sec_blocked:
        raw_runtime, executed_lines, poisoned_vars, stopped_reason, user_stdout = execute_sandboxed_multi_runtime(scan_code)
        explainer = nlp_explainer.NLPExplainer()

        for err_idx, r_err in enumerate(raw_runtime, 1):
            line_no = r_err.get("line")
            err_type = r_err.get("error_type") or "RuntimeError"
            err_msg = r_err.get("message") or ""
            tb_str = r_err.get("traceback") or ""

            origin = "detected"
            cascade_of = None
            if err_type in ("NameError", "UnboundLocalError", "AttributeError", "TypeError"):
                for p_var, parent_err_idx in poisoned_vars.items():
                    if parent_err_idx < err_idx and p_var and re.search(r'\b' + re.escape(p_var) + r'\b', err_msg):
                        origin = "cascade"
                        cascade_of = f"err_{parent_err_idx}"
                        break

            category = "runtime"
            if err_type in ("EOFError", "KeyboardInterrupt") or "input" in err_msg.lower():
                category = "environment"

            ir_dict = {
                "error_type": err_type,
                "error_message": err_msg,
                "line_number": line_no,
                "traceback": tb_str,
                "code": code_str
            }
            if generate_explanations:
                try:
                    expl = explainer.explain(ir_dict, code_str)
                except Exception:
                    expl = f"Mistake: {err_type} at line {line_no}. Reason: {err_msg}."
            else:
                expl = f"Mistake: {err_type} at line {line_no}. Reason: {err_msg}."

            key = (line_no, err_type)
            if key not in seen_keys:
                seen_keys.add(key)
                item = MultiErrorItem(
                    err_id=f"err_{len(all_errors)+1}",
                    line=line_no,
                    column=None,
                    error_type=err_type,
                    message=err_msg,
                    category=category,
                    origin=origin,
                    cascade_of=cascade_of,
                    explanation=expl,
                    traceback_str=tb_str
                )
                all_errors.append(item)

    all_errors.sort(key=lambda e: (e.line or 0, e.column or 0))

    for idx, err in enumerate(all_errors, 1):
        err.id = f"err_{idx}"

    lines_not_reached = sorted(list(total_statement_lines - executed_lines))
    coverage = {
        "statements_total": statements_total,
        "statements_executed": len(executed_lines),
        "lines_not_reached": lines_not_reached,
        "reason_stopped": stopped_reason
    }

    return all_errors, coverage, user_stdout


# ==============================================================================
# LAYER 4: MULTI-ROUND REPAIR ENGINE
# ==============================================================================

def fix_all_errors(
    code_str: str,
    max_rounds: int = DEFAULT_MAX_ROUNDS,
    max_time_sec: float = DEFAULT_MAX_TIME_SEC,
    max_ai_calls: int = DEFAULT_MAX_AI_CALLS
) -> Dict[str, Any]:
    """
    Multi-round iterative repair engine.
    Scans whole program, repairs non-cascade errors in order, verifies progress,
    and returns complete error items with their final fix status.
    """
    start_time = time.time()
    current_code = code_str
    ai_calls_made = 0
    fix_providers: List[str] = []
    fix_sources_used: Set[str] = set()
    fix_steps: List[str] = []

    explainer = nlp_explainer.NLPExplainer()

    # Initial scan of the whole program (fast pass without blocking on AI explanations)
    initial_errors, initial_coverage, initial_stdout = scan_all_errors(current_code, generate_explanations=False)
    
    # Keep master list of all detected errors for reporting
    master_errors: List[MultiErrorItem] = [
        copy.deepcopy(e) for e in initial_errors
    ]

    line_count = len(code_str.splitlines())
    is_large_input = (line_count > 500 or len(initial_errors) > 35)
    if is_large_input:
        max_rounds = min(max_rounds, 5)
        max_time_sec = min(max_time_sec, 10.0)
        max_ai_calls = 0

    if not initial_errors:
        return {
            "errors": [],
            "error_count": 0,
            "fixed_count": 0,
            "remaining_count": 0,
            "analysis_mode": "multi",
            "analysis_coverage": initial_coverage,
            "error_list_text": "No errors detected. Code executes cleanly.",
            "fixed_code": current_code,
            "stdout": initial_stdout,
            "fix_status": "already_clean",
            "fix_source": "none",
            "fix_providers": [],
            "fix_steps": [],
            "primary_error": None
        }

    fixed_keys: Dict[Tuple[Optional[int], str], Tuple[str, Optional[str], Optional[str]]] = {}
    successful_fixes: List[Dict[str, Any]] = []

    # Check if initial syntax fixes apply cleanly
    syntax_errs, _, fixed_syntax = scan_syntax_errors(code_str)
    if fixed_syntax != code_str:
        for se in syntax_errs:
            if se.fix_status == "fixed":
                src = se.fix_source or "rule"
                fixed_keys[(se.line, se.error_type)] = ("fixed", src, se.fix_provider)
                successful_fixes.append({
                    "error_type": se.error_type,
                    "message": se.message,
                    "line": se.line,
                    "source": src,
                    "provider": se.fix_provider
                })
                fix_sources_used.add(src)
                fix_steps.append(f"Round 1: Fixed {se.error_type} at line {se.line} via {src}")
        current_code = fixed_syntax
        current_errors, current_coverage, current_stdout = scan_all_errors(current_code, generate_explanations=False)
    else:
        current_errors = list(initial_errors)
        current_coverage = initial_coverage
        current_stdout = initial_stdout

    for round_idx in range(1, max_rounds + 1):
        if time.time() - start_time > max_time_sec:
            break

        if not current_errors:
            break

        round_progress = False

        # Fast batch pass: try applying non-conflicting deterministic fixes bottom-to-top
        non_cascade_items = [
            it for it in current_errors
            if it.origin != "cascade" and it.category != "environment"
        ]
        if len(non_cascade_items) >= 2 and (time.time() - start_time <= max_time_sec):
            sorted_items = sorted(non_cascade_items, key=lambda x: (x.line or 1), reverse=True)
            working_code = current_code
            batch_applied = []
            for b_item in sorted_items:
                if time.time() - start_time > max_time_sec:
                    break
                b_line = b_item.line or 1
                b_res = get_deterministic_fix(b_item.error_type, b_item.message, b_line, working_code)
                if b_res:
                    b_cand, b_src, b_name = b_res
                    if b_cand and b_cand != working_code:
                        b_valid, _ = nlp_explainer._validate_patch_acceptance(
                            working_code, b_cand, b_item.error_type, b_item.message, b_line,
                            allow_earlier_failure=True, skip_sandbox=True
                        )
                        if b_valid:
                            working_code = b_cand
                            batch_applied.append((b_item, b_src, b_name))

            if batch_applied:
                new_errors, new_cov, new_out = scan_all_errors(working_code, generate_explanations=False)
                if len(new_errors) < len(current_errors):
                    current_code = working_code
                    current_errors = new_errors
                    current_coverage = new_cov
                    current_stdout = new_out
                    for a_item, a_src, a_name in batch_applied:
                        a_key = (a_item.line or 1, a_item.error_type)
                        fixed_keys[a_key] = ("fixed", a_src, a_name)
                        successful_fixes.append({
                            "error_type": a_item.error_type,
                            "message": a_item.message,
                            "line": a_item.line,
                            "source": a_src,
                            "provider": a_name
                        })
                        if a_src:
                            fix_sources_used.add(a_src)
                        fix_steps.append(f"Round {round_idx}: Batched fix for {a_item.error_type} at line {a_item.line} via {a_src}")
                    round_progress = True
                    continue

        # Attempt fix for each non-cascade error
        for item in list(current_errors):
            if time.time() - start_time > max_time_sec:
                break
            if item.origin == "cascade" or item.category == "environment":
                continue

            line_no = item.line or 1
            err_type = item.error_type
            err_msg = item.message
            err_key = (line_no, err_type)

            cand_fixed = None
            fix_src = None
            prov = None

            # 1. Deterministic / Rule fixer
            fix_res = get_deterministic_fix(err_type, err_msg, line_no, current_code)
            if fix_res:
                cand_fixed, fix_src, name = fix_res

            # 2. AI Fallback (if enabled & under quota)
            if not cand_fixed and os.environ.get("AUTOFIX_AI", "1") != "0" and os.environ.get("LLM_DISABLED") != "1":
                if ai_calls_made < max_ai_calls:
                    try:
                        ai_cand = explainer._apply_ai_autofix(
                            err_type=err_type,
                            err_msg=err_msg,
                            line_no=line_no,
                            code_str=current_code
                        )
                        if ai_cand and ai_cand != current_code:
                            ai_calls_made += 1
                            cand_fixed = ai_cand
                            fix_src = "ai"
                            prov = getattr(explainer, "last_ai_autofix_provider", "AI")
                            if prov and prov not in fix_providers:
                                fix_providers.append(prov)
                    except Exception:
                        pass

            if cand_fixed and cand_fixed != current_code:
                is_valid, reason = nlp_explainer._validate_patch_acceptance(
                    current_code, cand_fixed, err_type, err_msg, line_no,
                    allow_earlier_failure=True, skip_sandbox=True
                )
                if is_valid:
                    new_errors, new_cov, new_out = scan_all_errors(cand_fixed, generate_explanations=False)
                    
                    new_keys = {(e.line, e.error_type) for e in new_errors}
                    if len(new_errors) < len(current_errors) or (
                        err_key not in new_keys and len(new_errors) <= len(current_errors)
                    ):
                        current_code = cand_fixed
                        current_errors = new_errors
                        current_coverage = new_cov
                        current_stdout = new_out
                        fixed_keys[err_key] = ("fixed", fix_src, prov)
                        successful_fixes.append({
                            "error_type": err_type,
                            "message": err_msg,
                            "line": line_no,
                            "source": fix_src,
                            "provider": prov
                        })
                        if fix_src:
                            fix_sources_used.add(fix_src)
                        fix_steps.append(f"Round {round_idx}: Fixed {err_type} at line {line_no} via {fix_src}")
                        round_progress = True
                        break
                    else:
                        item.fix_status = "rejected: no error count reduction"
                else:
                    item.fix_status = f"rejected: {reason}"

        if not round_progress:
            break

    # Reconcile master error statuses
    unresolved_indices = set()
    used_current = set()

    # Pass 1: exact match on (line, error_type, message)
    for m_idx, m in enumerate(master_errors):
        for c_idx, c in enumerate(current_errors):
            if c_idx not in used_current and m.line == c.line and m.error_type == c.error_type and m.message == c.message:
                unresolved_indices.add(m_idx)
                used_current.add(c_idx)
                break

    # Pass 2: match on (error_type, message) regardless of line shift
    for m_idx, m in enumerate(master_errors):
        if m_idx in unresolved_indices:
            continue
        for c_idx, c in enumerate(current_errors):
            if c_idx not in used_current and m.error_type == c.error_type and m.message == c.message:
                unresolved_indices.add(m_idx)
                used_current.add(c_idx)
                break

    # Pass 3: match on error_type alone (order-preserving greedy match)
    for m_idx, m in enumerate(master_errors):
        if m_idx in unresolved_indices:
            continue
        for c_idx, c in enumerate(current_errors):
            if c_idx not in used_current and m.error_type == c.error_type:
                unresolved_indices.add(m_idx)
                used_current.add(c_idx)
                break

    for m_idx, item in enumerate(master_errors):
        if m_idx not in unresolved_indices:
            if item.origin == "cascade":
                item.fix_status = f"resolved_by_fixing_{item.cascade_of}" if item.cascade_of else "resolved_by_fixing_parent"
            else:
                item.fix_status = "fixed"
                matched_fix = None
                for fix_info in successful_fixes:
                    if not fix_info.get("used") and fix_info.get("error_type") == item.error_type:
                        matched_fix = fix_info
                        fix_info["used"] = True
                        break
                if matched_fix:
                    item.fix_source = matched_fix.get("source") or "rule"
                    item.fix_provider = matched_fix.get("provider")
                else:
                    item.fix_source = "rule"
        else:
            if item.category == "environment":
                item.fix_status = "no_fixer (environment)"
            elif item.origin == "cascade":
                item.fix_status = f"cascade_of_{item.cascade_of}"
            elif item.fix_status == "no_fixer":
                item.fix_status = "no_fixer"

    total_detected = len(master_errors)
    unresolved_count = sum(1 for e in master_errors if e.fix_status not in ("fixed", "resolved_by_fixing_parent") and not str(e.fix_status).startswith("resolved_by_fixing_"))
    resolved_count = total_detected - unresolved_count

    first_unresolved = None
    for e in master_errors:
        if e.fix_status not in ("fixed", "resolved_by_fixing_parent") and not str(e.fix_status).startswith("resolved_by_fixing_"):
            first_unresolved = e
            break

    # Determine overall fix status & source
    if unresolved_count == 0:
        overall_fix_status = "applied"
        if "ai" in fix_sources_used:
            overall_fix_source = "ai"
        elif "rule" in fix_sources_used and "deterministic" not in fix_sources_used:
            overall_fix_source = "rule"
        elif fix_sources_used:
            overall_fix_source = "rule" if "rule" in fix_sources_used else "deterministic"
        else:
            overall_fix_source = "already_clean"
    elif resolved_count > 0:
        if first_unresolved:
            stop_line = first_unresolved.line or 1
            stop_type = first_unresolved.error_type or "Error"
            overall_fix_status = f"fixed {resolved_count}; stopped at line {stop_line} ({stop_type}): no automatic fix; any errors after this line cannot be detected until it is fixed"
        else:
            overall_fix_status = f"partially_fixed ({resolved_count}/{total_detected} errors resolved)"
        overall_fix_source = "hybrid"
    else:
        if first_unresolved:
            stop_line = first_unresolved.line or 1
            stop_type = first_unresolved.error_type or "Error"
            overall_fix_status = f"stopped at line {stop_line} ({stop_type}): no automatic fix; any errors after this line cannot be detected until it is fixed"
        else:
            overall_fix_status = "no_safe_autofix"
        overall_fix_source = "none"

    # Populate explanations for master errors
    for err in master_errors[:DEFAULT_MAX_ERRORS]:
        if not err.explanation or err.explanation.startswith("Mistake:"):
            ir_dict = {
                "error_type": err.error_type,
                "error_message": err.message,
                "line_number": err.line,
                "traceback": err.traceback_str,
                "code": code_str
            }
            try:
                err.explanation = explainer.explain(ir_dict, code_str)
            except Exception:
                pass

    # Construct formatted error list text
    list_lines = []
    for err in master_errors[:DEFAULT_MAX_ERRORS]:
        loc = f"Line {err.line}" if err.line else "Module"
        list_lines.append(f"- [{err.id.upper()}] {loc}: {err.error_type} - {err.message} (Status: {err.fix_status})")
    
    if len(master_errors) > DEFAULT_MAX_ERRORS:
        list_lines.append(f"+{len(master_errors) - DEFAULT_MAX_ERRORS} more errors detected.")

    if current_coverage.get("lines_not_reached"):
        unreached_str = ", ".join(str(l) for l in current_coverage["lines_not_reached"][:10])
        if len(current_coverage["lines_not_reached"]) > 10:
            unreached_str += f" (+{len(current_coverage['lines_not_reached'])-10} more)"
        list_lines.append(f"Coverage Notice: Statements on lines [{unreached_str}] were not reached during execution.")

    if current_coverage.get("reason_stopped"):
        list_lines.append(f"Execution Notice: Execution stopped ({current_coverage['reason_stopped']}).")

    error_list_text = "\n".join(list_lines) if list_lines else "No errors detected."

    primary_error = master_errors[0].to_dict() if master_errors else None

    return {
        "errors": [e.to_dict() for e in master_errors[:DEFAULT_MAX_ERRORS]],
        "error_count": total_detected,
        "fixed_count": resolved_count,
        "remaining_count": unresolved_count,
        "analysis_mode": "multi",
        "analysis_coverage": current_coverage,
        "error_list_text": error_list_text,
        "fixed_code": current_code,
        "stdout": current_stdout,
        "fix_status": overall_fix_status,
        "fix_source": overall_fix_source,
        "fix_providers": fix_providers,
        "fix_steps": fix_steps,
        "primary_error": primary_error
    }


def analyze_multi_error(
    code_str: str,
    max_errors: int = DEFAULT_MAX_ERRORS,
    max_rounds: int = DEFAULT_MAX_ROUNDS,
    max_time_sec: float = DEFAULT_MAX_TIME_SEC
) -> Dict[str, Any]:
    """
    Main entry point for multi-error analysis and repair engine.
    """
    return fix_all_errors(code_str, max_rounds=max_rounds, max_time_sec=max_time_sec)
