"""tests_automaton.py - Pytest suite for Feature 1: automaton_engine + Flask API.

Covers:
  - Preset DFA accept/reject correctness
  - Step-trace structure and content
  - Mermaid diagram generation
  - Hopcroft minimization (minimized ≤ original)
  - Flask API endpoints (/api/automaton/*)
  - Edge cases: empty string, single char, 200-char string
"""

from __future__ import annotations

import sys
import os
import pytest

# ---------------------------------------------------------------------------
# Make sure project root is importable
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from automaton_engine import (
    get_preset_dfa,
    step_trace,
    dfa_to_mermaid,
    minimize_dfa,
    list_presets,
    compile_regex,
    _PRESET_BUILDERS,
    BuiltDFA,
)


# ===========================================================================
# Helpers
# ===========================================================================

def _accepts(preset: str, s: str) -> bool:
    return get_preset_dfa(preset).accepts(s)


# ===========================================================================
# 1. Preset DFA – accept / reject
# ===========================================================================

class TestIdentifierDFA:
    def test_simple_identifier(self):
        assert _accepts("identifier", "hello") is True

    def test_underscore_prefix(self):
        assert _accepts("identifier", "_foo") is True

    def test_alphanumeric(self):
        assert _accepts("identifier", "my_var123") is True

    def test_capital_letters(self):
        assert _accepts("identifier", "MyClass") is True

    def test_starts_with_digit_rejected(self):
        assert _accepts("identifier", "1bad") is False

    def test_empty_rejected(self):
        assert _accepts("identifier", "") is False

    def test_space_rejected(self):
        assert _accepts("identifier", "my var") is False

    def test_single_char(self):
        assert _accepts("identifier", "x") is True


class TestFloatDFA:
    def test_integer(self):
        assert _accepts("float", "123") is True

    def test_float(self):
        assert _accepts("float", "3.14") is True

    def test_leading_dot_rejected(self):
        assert _accepts("float", ".5") is False

    def test_trailing_dot_rejected(self):
        assert _accepts("float", "3.") is False

    def test_empty_rejected(self):
        assert _accepts("float", "") is False

    def test_letters_rejected(self):
        assert _accepts("float", "abc") is False

    def test_single_digit(self):
        assert _accepts("float", "0") is True

    def test_double_dot_rejected(self):
        assert _accepts("float", "1.2.3") is False


class TestIntUnderscoreDFA:
    def test_simple(self):
        assert _accepts("int_underscore", "12345") is True

    def test_with_underscore(self):
        assert _accepts("int_underscore", "1_000_000") is True

    def test_leading_underscore_rejected(self):
        assert _accepts("int_underscore", "_123") is False

    def test_trailing_underscore_rejected(self):
        assert _accepts("int_underscore", "123_") is False

    def test_double_underscore_rejected(self):
        assert _accepts("int_underscore", "1__2") is False

    def test_empty_rejected(self):
        assert _accepts("int_underscore", "") is False

    def test_single_digit(self):
        assert _accepts("int_underscore", "7") is True


class TestEmailSimpleDFA:
    def test_valid_email(self):
        assert _accepts("email_simple", "user@example.com") is True

    def test_valid_all_digits(self):
        assert _accepts("email_simple", "user123@domain99.org") is True

    def test_no_at_rejected(self):
        assert _accepts("email_simple", "nodomain.com") is False

    def test_no_tld_rejected(self):
        assert _accepts("email_simple", "user@domain") is False

    def test_empty_rejected(self):
        assert _accepts("email_simple", "") is False

    def test_double_at_rejected(self):
        assert _accepts("email_simple", "a@b@c.com") is False

    def test_uppercase_rejected(self):
        # Preset is lowercase-only
        assert _accepts("email_simple", "User@Example.com") is False


class TestHexDFA:
    def test_lowercase(self):
        assert _accepts("hex", "0xff") is True

    def test_uppercase_x(self):
        assert _accepts("hex", "0Xff") is True

    def test_uppercase_digits(self):
        assert _accepts("hex", "0xDEADBEEF") is True

    def test_no_prefix_rejected(self):
        assert _accepts("hex", "ff") is False

    def test_empty_rejected(self):
        assert _accepts("hex", "") is False

    def test_only_prefix_rejected(self):
        assert _accepts("hex", "0x") is False

    def test_invalid_hex_char_rejected(self):
        assert _accepts("hex", "0xGG") is False

    def test_single_hex_digit(self):
        assert _accepts("hex", "0x0") is True


# ===========================================================================
# 2. Step trace structure
# ===========================================================================

class TestStepTrace:
    def test_empty_string(self):
        dfa = get_preset_dfa("identifier")
        result = step_trace(dfa, "")
        assert result["accepted"] is False
        assert result["steps"] == []

    def test_single_accepted_char(self):
        dfa = get_preset_dfa("identifier")
        result = step_trace(dfa, "a")
        assert result["accepted"] is True
        assert len(result["steps"]) == 1
        step = result["steps"][0]
        assert step["step"] == 0
        assert step["char"] == "a"
        assert step["from_state"] == "START"
        assert step["to_state"] == "IDENT"
        assert step["is_accepting"] is True
        assert step["is_dead"] is False

    def test_step_count_matches_input_length(self):
        dfa = get_preset_dfa("float")
        s = "3.14"
        result = step_trace(dfa, s)
        assert result["accepted"] is True
        assert len(result["steps"]) == len(s)

    def test_reject_stops_at_dead(self):
        dfa = get_preset_dfa("identifier")
        result = step_trace(dfa, "1bad")
        assert result["accepted"] is False
        # Should stop after first character hits dead
        assert result["steps"][-1]["is_dead"] is True

    def test_contains_required_keys(self):
        dfa = get_preset_dfa("hex")
        result = step_trace(dfa, "0xa1")
        for key in ("accepted", "steps", "total_states", "minimized_states", "name"):
            assert key in result

    def test_each_step_has_required_keys(self):
        dfa = get_preset_dfa("float")
        result = step_trace(dfa, "42")
        for step in result["steps"]:
            for key in ("step", "char", "from_state", "to_state", "is_accepting", "is_dead"):
                assert key in step

    def test_total_states_positive(self):
        dfa = get_preset_dfa("email_simple")
        result = step_trace(dfa, "a@b.c")
        assert result["total_states"] > 0

    def test_minimized_lte_total(self):
        dfa = get_preset_dfa("float")
        result = step_trace(dfa, "1.0")
        assert result["minimized_states"] <= result["total_states"]

    def test_very_long_string(self):
        dfa = get_preset_dfa("identifier")
        s = "a" * 200
        result = step_trace(dfa, s)
        assert result["accepted"] is True
        assert len(result["steps"]) == 200

    def test_long_reject_string(self):
        dfa = get_preset_dfa("hex")
        s = "0x" + "z" * 150   # invalid hex chars
        result = step_trace(dfa, s)
        assert result["accepted"] is False


# ===========================================================================
# 3. Mermaid diagram
# ===========================================================================

class TestMermaidDiagram:
    def test_non_empty(self):
        dfa = get_preset_dfa("identifier")
        mermaid = dfa_to_mermaid(dfa)
        assert len(mermaid) > 0

    def test_contains_flowchart(self):
        dfa = get_preset_dfa("float")
        mermaid = dfa_to_mermaid(dfa)
        assert "flowchart LR" in mermaid

    def test_contains_state_names(self):
        dfa = get_preset_dfa("float")
        mermaid = dfa_to_mermaid(dfa)
        # At minimum the start state should appear
        assert dfa.start_state in mermaid

    def test_highlight_path(self):
        dfa = get_preset_dfa("identifier")
        path = ["START", "IDENT"]
        mermaid = dfa_to_mermaid(dfa, highlight_path=path)
        # Highlight class should be present
        assert "highlight" in mermaid

    def test_no_highlight(self):
        dfa = get_preset_dfa("identifier")
        mermaid = dfa_to_mermaid(dfa, highlight_path=None)
        assert "flowchart LR" in mermaid

    def test_all_presets_produce_mermaid(self):
        for name in _PRESET_BUILDERS:
            dfa = get_preset_dfa(name)
            mermaid = dfa_to_mermaid(dfa)
            assert "flowchart LR" in mermaid, f"Preset {name} Mermaid missing flowchart LR"


# ===========================================================================
# 4. Hopcroft minimization
# ===========================================================================

class TestMinimization:
    def test_minimized_le_original(self):
        for name in _PRESET_BUILDERS:
            dfa = get_preset_dfa(name)
            min_dfa = minimize_dfa(dfa)
            assert len(min_dfa.states) <= len(dfa.states), (
                f"Preset {name}: minimized {len(min_dfa.states)} > original {len(dfa.states)}"
            )

    def test_minimized_accepts_same_strings(self):
        """Minimized DFA must accept/reject same strings as original."""
        test_cases = {
            "identifier": (["hello", "_x", "my_var123"], ["1bad", "", "my var"]),
            "float": (["3.14", "0", "100"], [".5", "abc", ""]),
            "hex": (["0xff", "0x0"], ["ff", "0x", ""]),
        }
        for name, (pos, neg) in test_cases.items():
            dfa = get_preset_dfa(name)
            min_dfa = minimize_dfa(dfa)
            for s in pos:
                assert min_dfa.accepts(s) is True, f"{name}: minimized rejected '{s}'"
            for s in neg:
                assert min_dfa.accepts(s) is False, f"{name}: minimized accepted '{s}'"

    def test_minimized_has_name(self):
        dfa = get_preset_dfa("identifier")
        min_dfa = minimize_dfa(dfa)
        assert len(min_dfa.name) > 0

    def test_original_dfa_minimized_field_updated(self):
        dfa = get_preset_dfa("float")
        orig_states = len(dfa.states)
        minimize_dfa(dfa)
        assert dfa.minimized_states <= orig_states


# ===========================================================================
# 5. compile_regex (Thompson → DFA pipeline)
# ===========================================================================

class TestCompileRegex:
    def test_simple_literal(self):
        dfa = compile_regex("ab")
        assert dfa.accepts("ab") is True
        assert dfa.accepts("a") is False
        assert dfa.accepts("abc") is False

    def test_star(self):
        dfa = compile_regex("a*")
        assert dfa.accepts("") is True
        assert dfa.accepts("aaa") is True
        assert dfa.accepts("b") is False

    def test_plus(self):
        dfa = compile_regex("a+")
        assert dfa.accepts("") is False
        assert dfa.accepts("a") is True
        assert dfa.accepts("aaa") is True

    def test_question(self):
        dfa = compile_regex("ab?")
        assert dfa.accepts("a") is True
        assert dfa.accepts("ab") is True
        assert dfa.accepts("abb") is False

    def test_union(self):
        dfa = compile_regex("a|b")
        assert dfa.accepts("a") is True
        assert dfa.accepts("b") is True
        assert dfa.accepts("c") is False

    def test_char_class(self):
        dfa = compile_regex("[0-9]+")
        assert dfa.accepts("123") is True
        assert dfa.accepts("") is False
        assert dfa.accepts("abc") is False

    def test_digit_escape(self):
        dfa = compile_regex(r"\d+")
        assert dfa.accepts("42") is True
        assert dfa.accepts("abc") is False

    def test_grouping(self):
        dfa = compile_regex("(ab)+")
        assert dfa.accepts("ab") is True
        assert dfa.accepts("abab") is True
        assert dfa.accepts("a") is False

    def test_empty_string_star(self):
        dfa = compile_regex("a*")
        assert dfa.accepts("") is True


# ===========================================================================
# 6. list_presets
# ===========================================================================

class TestListPresets:
    def test_returns_list(self):
        result = list_presets()
        assert isinstance(result, list)

    def test_all_presets_present(self):
        result = list_presets()
        names = {p["name"] for p in result}
        assert names == set(_PRESET_BUILDERS.keys())

    def test_each_has_description(self):
        for p in list_presets():
            assert "name" in p
            assert "description" in p
            assert len(p["description"]) > 0


# ===========================================================================
# 7. Flask API endpoints
# ===========================================================================

@pytest.fixture(scope="module")
def flask_client():
    """Create a Flask test client for the app."""
    # Minimal environment to avoid side-effects of full app startup
    os.environ.setdefault("FLASK_TESTING", "1")
    import app as flask_app
    flask_app.app.config["TESTING"] = True
    with flask_app.app.test_client() as client:
        yield client


class TestFlaskPresets:
    def test_get_presets_200(self, flask_client):
        resp = flask_client.get("/api/automaton/presets")
        assert resp.status_code == 200

    def test_get_presets_returns_list(self, flask_client):
        resp = flask_client.get("/api/automaton/presets")
        data = resp.get_json()
        assert isinstance(data, list)
        assert len(data) == len(_PRESET_BUILDERS)

    def test_get_presets_has_name_desc(self, flask_client):
        resp = flask_client.get("/api/automaton/presets")
        for item in resp.get_json():
            assert "name" in item
            assert "description" in item


class TestFlaskTrace:
    def test_trace_identifier_valid(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            json={"regex_or_preset": "identifier", "input": "my_var123"},
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["accepted"] is True
        assert "steps" in data
        assert "mermaid_diagram" in data
        assert "minimized_states" in data
        assert "total_states" in data

    def test_trace_identifier_invalid(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            json={"regex_or_preset": "identifier", "input": "1bad"},
        )
        assert resp.status_code == 200
        assert resp.get_json()["accepted"] is False

    def test_trace_float_valid(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            json={"regex_or_preset": "float", "input": "3.14"},
        )
        assert resp.status_code == 200
        assert resp.get_json()["accepted"] is True

    def test_trace_empty_input(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            json={"regex_or_preset": "identifier", "input": ""},
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["accepted"] is False
        assert data["steps"] == []

    def test_trace_mermaid_contains_flowchart(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            json={"regex_or_preset": "hex", "input": "0xff"},
        )
        assert resp.status_code == 200
        assert "flowchart LR" in resp.get_json()["mermaid_diagram"]

    def test_trace_bad_body(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            data="not json",
            content_type="text/plain",
        )
        # Flask may return 400 (bad JSON) or 415 (unsupported media type)
        assert resp.status_code in (400, 415)

    def test_trace_very_long_input(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/trace",
            json={"regex_or_preset": "identifier", "input": "a" * 200},
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["accepted"] is True
        assert len(data["steps"]) == 200

    def test_trace_all_presets(self, flask_client):
        for name in _PRESET_BUILDERS:
            resp = flask_client.post(
                "/api/automaton/trace",
                json={"regex_or_preset": name, "input": ""},
            )
            assert resp.status_code == 200, f"Preset {name} returned {resp.status_code}"


class TestFlaskMinimize:
    def test_minimize_float_200(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            json={"preset": "float"},
        )
        assert resp.status_code == 200

    def test_minimize_returns_expected_fields(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            json={"preset": "identifier"},
        )
        data = resp.get_json()
        for field in ("states", "transitions", "accepting_states",
                      "mermaid_diagram", "minimized_states", "total_states"):
            assert field in data, f"Missing field: {field}"

    def test_minimize_states_list(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            json={"preset": "hex"},
        )
        data = resp.get_json()
        assert isinstance(data["states"], list)
        assert len(data["states"]) > 0

    def test_minimize_minimized_le_total(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            json={"preset": "email_simple"},
        )
        data = resp.get_json()
        assert data["minimized_states"] <= data["total_states"]

    def test_minimize_bad_preset(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            json={"preset": "not_a_real_preset"},
        )
        assert resp.status_code == 400

    def test_minimize_bad_body(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            data="bad",
            content_type="text/plain",
        )
        # Flask may return 400 (bad JSON) or 415 (unsupported media type)
        assert resp.status_code in (400, 415)

    def test_minimize_mermaid_non_empty(self, flask_client):
        resp = flask_client.post(
            "/api/automaton/minimize",
            json={"preset": "int_underscore"},
        )
        data = resp.get_json()
        assert len(data["mermaid_diagram"]) > 10
