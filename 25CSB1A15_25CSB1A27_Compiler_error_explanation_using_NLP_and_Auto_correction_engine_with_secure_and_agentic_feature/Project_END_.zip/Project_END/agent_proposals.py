"""agent_proposals.py - Bounded in-memory proposal store and human approval flow.

Implements human-in-the-loop approval (Feature 8) for code patches.
Proposals expire after 30 minutes (TTL) and are kept in a bounded LRU structure (max 50).
Guarantees:
- Single-use approval transitions.
- Protected files (including startup snapshot of existing *_fixed.py) are never overwritten.
- Atomic safe-save writing only to validated <base>_fixed.py.
- Re-scans fixed code with scan_gate before file write.
- Reject stores only reason length, never raw untrusted text.
"""

import collections
import difflib
import hashlib
import os
import re
import secrets
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))

PROPOSALS_MAX_CAPACITY = 50
PROPOSAL_TTL_SECONDS = 1800.0  # 30 minutes
MAX_DIFF_SIZE_BYTES = 204800   # 200 KB

# Take a startup snapshot of existing *_fixed.py and protected files in workspace root
_STARTUP_FIXED_FILES: Set[str] = set()
for fname in os.listdir(WORKSPACE_DIR):
    if fname.endswith("_fixed.py") and os.path.isfile(os.path.join(WORKSPACE_DIR, fname)):
        _STARTUP_FIXED_FILES.add(fname)

PROTECTED_NAMES: Set[str] = {
    "app.py", "nlp_explainer.py", "error_extractor.py", "security_analyzer.py",
    "multi_error.py", "sandbox_runner.py", "sandbox_child.py", "llm_explainer.py",
    "llm_calls.py", "offline_guide.py", "tokenizer.py", "dfa.py", "bracket_checker.py",
    "agent.py", "agent_tools.py", "agent_memory.py", "agent_proposals.py",
    "test3_fixed.py", "test_case_large_fixed.py", "data.jsonl", "emissions.csv"
} | _STARTUP_FIXED_FILES


def compute_unified_diff(orig_code: str, fixed_code: str, filename: Optional[str] = None) -> str:
    """Generate clean unified diff representation, capped at 200 KB."""
    from_file = f"a/{filename or 'original.py'}"
    to_file = f"b/{filename or 'fixed.py'}"
    diff_lines = list(difflib.unified_diff(
        orig_code.splitlines(keepends=True),
        fixed_code.splitlines(keepends=True),
        fromfile=from_file,
        tofile=to_file
    ))
    diff_text = "".join(diff_lines)

    # Sanitize bidirectional control characters to protect human reviewer against Trojan Source (CVE-2021-42574)
    for bidi in ("\u202a", "\u202b", "\u202c", "\u202d", "\u202e", "\u2066", "\u2067", "\u2068", "\u2069", "\u200e", "\u200f"):
        if bidi in diff_text:
            diff_text = diff_text.replace(bidi, f"[U+{ord(bidi):04X}:BIDI_OVERRIDE]")

    diff_bytes = diff_text.encode("utf-8")
    if len(diff_bytes) > MAX_DIFF_SIZE_BYTES:
        truncated = diff_bytes[:MAX_DIFF_SIZE_BYTES].decode("utf-8", errors="ignore")
        return truncated + "\n... [diff truncated at 200 KB limit]"
    return diff_text


class ProposalStore:
    """Bounded, thread-safe in-memory store for patch proposals."""

    def __init__(self, capacity: int = PROPOSALS_MAX_CAPACITY, time_fn: Callable[[], float] = time.time):
        self.capacity = max(5, capacity)
        self.time_fn = time_fn
        self._lock = threading.Lock()
        self._proposals: collections.OrderedDict[str, Dict[str, Any]] = collections.OrderedDict()

    def create(
        self,
        original_code: str,
        fixed_code: str,
        filename: Optional[str] = None,
        tier: str = "rules",
        findings: Optional[List[Dict[str, Any]]] = None,
        requires_dual_key: bool = False
    ) -> Dict[str, Any]:
        """Create a new pending proposal and store it in memory/persistent store."""
        with self._lock:
            # Evict oldest if reached capacity
            while len(self._proposals) >= self.capacity:
                self._proposals.popitem(last=False)

            proposal_id = secrets.token_urlsafe(24)
            orig_hash = hashlib.sha256(original_code.encode("utf-8")).hexdigest()
            fixed_hash = hashlib.sha256(fixed_code.encode("utf-8")).hexdigest()
            diff = compute_unified_diff(original_code, fixed_code, filename)

            now = self.time_fn()

            # Semantic & Control Flow Integrity Audit (Anti-Trojan Human Protection)
            cfi_status = "CLEAN"
            cfi_notices: List[str] = []
            try:
                from security import code_guard
                cg_res = code_guard.inspect_healed_code(original_code, fixed_code)
                for sig in cg_res.get("signals", []):
                    if sig.get("name") in ("trojan_guard_mutation", "exception_silencing"):
                        cfi_status = "CRITICAL"
                        cfi_notices.append(sig.get("evidence", "Critical semantic logic alteration"))
                    elif sig.get("name") in ("obfuscation", "patch_scope_anomaly"):
                        if cfi_status != "CRITICAL":
                            cfi_status = "SUSPICIOUS"
                        cfi_notices.append(sig.get("evidence", "Suspicious patch alteration"))
            except Exception:
                pass

            if cfi_status == "CRITICAL":
                requires_dual_key = True

            proposal = {
                "id": proposal_id,
                "original_hash": orig_hash,
                "fixed_code_hash": fixed_hash,
                "diff": diff,
                "findings": findings or [],
                "filename": filename,
                "tier": tier,
                "status": "pending",
                "created_at": now,
                "expires_at": now + PROPOSAL_TTL_SECONDS,
                "_original_code": original_code,
                "_fixed_code": fixed_code,
                "rejected_reason_length": 0,
                "requires_dual_key": requires_dual_key,
                "semantic_audit": {
                    "status": cfi_status,
                    "notices": cfi_notices
                }
            }
            self._proposals[proposal_id] = proposal
            return proposal

    def get(self, proposal_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a proposal, checking for TTL expiry."""
        with self._lock:
            if proposal_id not in self._proposals:
                return None
            prop = self._proposals[proposal_id]
            now = self.time_fn()
            if prop["status"] == "pending" and now > prop["expires_at"]:
                prop["status"] = "expired"
            return prop

    def approve(self, proposal_id: str, key_a: Optional[str] = None, key_b: Optional[str] = None) -> Tuple[int, Dict[str, Any]]:
        """
        Approve proposal: returns (http_status, result_dict).
        Status codes:
        - 404: Unknown proposal
        - 410: Proposal expired
        - 409: Already decided or security re-scan violation
        - 403: Dual-Key / Four-Eyes verification failed
        - 200: Approved and safely saved (if filename present)
        """
        with self._lock:
            if proposal_id not in self._proposals:
                return 404, {"error": "Proposal not found", "status": 404}

            prop = self._proposals[proposal_id]
            now = self.time_fn()

            if prop["status"] == "pending" and now > prop["expires_at"]:
                prop["status"] = "expired"
                return 410, {"error": "Proposal has expired", "status": 410}

            if prop["status"] != "pending":
                return 409, {"error": f"Proposal is already {prop['status']}", "status": 409}

            # Security re-scan at approval time
            fixed_code = prop["_fixed_code"]
            orig_code = prop.get("_original_code", "")

            # Four-Eyes / Dual-Key verification
            dual_key_required = (
                os.environ.get("DUAL_KEY_ENFORCE", "0") == "1"
                or prop.get("requires_dual_key", False)
                or (key_a is not None or key_b is not None)
            )
            if dual_key_required:
                from security import dual_key
                ok, msg, voucher = dual_key.verify_dual_key_authorization(
                    proposal_id=proposal_id,
                    fixed_code=fixed_code,
                    key_a=key_a or "",
                    key_b=key_b or ""
                )
                if not ok:
                    return 403, {"error": msg, "status": 403, "dual_key_violation": True}
                prop["dual_key_voucher"] = voucher
            try:
                import security_analyzer
                gate = security_analyzer.scan_gate(fixed_code)
                if not gate.get("allowed", True):
                    return 409, {
                        "error": "Approval rejected: fixed code introduces security violations upon re-scan",
                        "status": 409,
                        "reasons": gate.get("reasons", [])
                    }
            except Exception as e:
                return 500, {"error": f"Security re-scan failed: {e}", "status": 500}

            # Mark approved
            prop["status"] = "approved"

            target_filename = None
            if prop.get("filename"):
                # Safe save flow
                fn = prop["filename"]
                stem = fn[:-3] if fn.endswith(".py") else fn
                fixed_filename = f"{stem}_fixed.py" if not stem.endswith("_fixed") else f"{stem}.py"
                
                # Check protected names & startup snapshot
                if fixed_filename in PROTECTED_NAMES or fn in PROTECTED_NAMES:
                    return 403, {"error": f"Target file '{fixed_filename}' is protected and cannot be overwritten", "status": 403}

                # Safe atomic write to workspace
                target_path = os.path.join(WORKSPACE_DIR, fixed_filename)
                temp_path = os.path.join(WORKSPACE_DIR, f".tmp_prop_{os.getpid()}_{int(time.time()*1000)}.tmp")
                try:
                    with open(temp_path, "w", encoding="utf-8") as fp:
                        fp.write(fixed_code)
                        fp.flush()
                        os.fsync(fp.fileno())
                    os.replace(temp_path, target_path)
                    target_filename = fixed_filename
                except Exception as e:
                    if os.path.exists(temp_path):
                        try:
                            os.remove(temp_path)
                        except Exception:
                            pass
                    return 500, {"error": f"Failed to write fixed file atomically: {e}", "status": 500}

            return 200, {
                "status": "approved",
                "proposal_id": proposal_id,
                "saved_filename": target_filename,
                "fixed_code": fixed_code,
                "fixed_code_hash": prop["fixed_code_hash"]
            }

    def reject(self, proposal_id: str, reason: Optional[str] = None) -> Tuple[int, Dict[str, Any]]:
        """
        Reject proposal: returns (http_status, result_dict).
        Reason text is bounded to 200 chars, stripped of control chars, and NEVER stored.
        Only its length is recorded in memory.
        """
        with self._lock:
            if proposal_id not in self._proposals:
                return 404, {"error": "Proposal not found", "status": 404}

            prop = self._proposals[proposal_id]
            now = self.time_fn()

            if prop["status"] == "pending" and now > prop["expires_at"]:
                prop["status"] = "expired"
                return 410, {"error": "Proposal has expired", "status": 410}

            if prop["status"] != "pending":
                return 409, {"error": f"Proposal is already {prop['status']}", "status": 409}

            clean_len = 0
            if reason and isinstance(reason, str):
                sanitized = "".join(c for c in reason if c.isprintable())[:200]
                clean_len = len(sanitized)

            prop["status"] = "rejected"
            prop["rejected_reason_length"] = clean_len

            return 200, {
                "status": "rejected",
                "proposal_id": proposal_id,
                "reason_length": clean_len
            }

    def clear(self) -> None:
        """Clear all stored proposals (used in tests)."""
        with self._lock:
            self._proposals.clear()


# Global runtime singleton
_GLOBAL_PROPOSALS = ProposalStore()


def get_global_proposals() -> ProposalStore:
    """Return the global runtime proposals store."""
    return _GLOBAL_PROPOSALS
