"""llm_config.py – Gemini and Groq LLM tier configuration constants."""
import os

DEFAULT_MODEL = "gemini-3.5-flash-lite"
MODEL = os.environ.get("GEMINI_MODEL", DEFAULT_MODEL)

GROQ_DEFAULT_MODEL = "qwen/qwen3.8-27b"
GROQ_MODEL = os.environ.get("GROQ_MODEL", GROQ_DEFAULT_MODEL)

DEFAULT_PROVIDER_ORDER = "gemini,groq"
PROVIDER_ORDER = os.environ.get("LLM_PROVIDER_ORDER", DEFAULT_PROVIDER_ORDER)

TIMEOUT_SECONDS = 12         # per-request timeout for Gemini (min allowed is 10s)
GROQ_TIMEOUT_SECONDS = 8     # per-request timeout for Groq
OVERALL_TIMEOUT_SECONDS = 20 # maximum time per overall explanation request

TEMPERATURE = 0.2
MAX_OUTPUT_TOKENS = 4096
MAX_CODE_LINES = 1200         # max lines of code supported for analysis and prompt context
MAX_CODE_CHARS = 65000        # max characters of code supported (~1000-1200 lines)
THINKING_BUDGET = 0          # disable thinking tokens for predictable latency

LLM_DISABLED = os.environ.get("LLM_DISABLED", "0") == "1"
AUTOFIX_AI = os.environ.get("AUTOFIX_AI", "1") == "1"
OPTIMIZE_AI = os.environ.get("OPTIMIZE_AI", os.environ.get("AUTOFIX_AI", "1")) == "1"
