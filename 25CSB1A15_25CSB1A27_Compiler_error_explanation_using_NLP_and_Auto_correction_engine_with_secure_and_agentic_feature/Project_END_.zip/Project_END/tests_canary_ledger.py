"""tests_canary_ledger.py - Unit & Integration Tests for Canary Traps & Merkle Audit Ledger.

Validates:
1. Canary honeypot environment variable tripwires inside sandbox execution.
2. Canary honeypot file tripwires inside sandbox execution.
3. Canary token leak detection in process stdout/stderr.
4. Normal non-malicious code execution without canary false positives.
5. Merkle Tree root generation over cryptographic audit ledger entries.
6. Merkle proof generation and cryptographic verification.
7. Tampered leaf rejection by Merkle proof verifier.
8. Flask API endpoints for audit ledger verification and Merkle proofs.
"""

import json
import os
import tempfile
import unittest
from unittest.mock import patch

from security import audit_log, canary
import sandbox_runner


class TestCanaryHoneypot(unittest.TestCase):
    """Tests for canary honeypot token detection and tripwires."""

    def test_canary_env_var_detection(self):
        """Reading decoy canary environment variables trips the sandbox honeypot."""
        code = (
            "import os\n"
            "secret = os.environ.get('AWS_SECRET_ACCESS_KEY')\n"
            "print('Got secret:', secret)\n"
        )
        res = sandbox_runner.run_in_sandbox(code, timeout=4.0)
        self.assertEqual(res["status"], "violation")
        violations = [v.get("kind") for v in res.get("violations", [])]
        self.assertIn("canary_trap_triggered", violations)

    def test_canary_env_dict_lookup_detection(self):
        """Direct dictionary indexing of canary keys trips the honeypot."""
        code = (
            "import os\n"
            "key = os.environ['DATABASE_ADMIN_PASSWORD']\n"
        )
        res = sandbox_runner.run_in_sandbox(code, timeout=4.0)
        self.assertEqual(res["status"], "violation")
        violations = [v.get("kind") for v in res.get("violations", [])]
        self.assertIn("canary_trap_triggered", violations)

    def test_canary_file_read_detection(self):
        """Attempting to open or read a decoy canary file trips the honeypot."""
        code = (
            "with open('.env.canary', 'r') as f:\n"
            "    data = f.read()\n"
        )
        res = sandbox_runner.run_in_sandbox(code, timeout=4.0)
        self.assertEqual(res["status"], "violation")
        violations = [v.get("kind") for v in res.get("violations", [])]
        self.assertIn("canary_trap_triggered", violations)

    def test_canary_token_leak_in_stdout(self):
        """Exfiltrating or printing a canary token string is caught by the output scanner."""
        canary_token = canary.DEFAULT_CANARY_ENV_VARS["INTELLIFIX_CANARY_TOKEN"]
        code = f"print('{canary_token}')\n"
        res = sandbox_runner.run_in_sandbox(code, timeout=4.0)
        self.assertEqual(res["status"], "violation")
        violations = [v.get("kind") for v in res.get("violations", [])]
        self.assertIn("canary_trap_triggered", violations)

    def test_clean_code_no_canary_false_positive(self):
        """Standard safe computation does not trigger any canary alarms."""
        code = (
            "def fib(n):\n"
            "    return n if n <= 1 else fib(n - 1) + fib(n - 2)\n"
            "print('Result:', fib(6))\n"
        )
        res = sandbox_runner.run_in_sandbox(code, timeout=4.0)
        self.assertEqual(res["status"], "ok")
        self.assertIn("Result: 8", res["stdout"])
        violations = res.get("violations", [])
        self.assertEqual(len(violations), 0)


class TestMerkleAuditLedger(unittest.TestCase):
    """Tests for Merkle Tree computation, audit proofs, and cryptographic ledger verification."""

    def test_merkle_root_empty_log(self):
        """Empty log returns GENESIS_HASH with 0 leaves."""
        with tempfile.TemporaryDirectory() as tmpdir:
            empty_path = os.path.join(tmpdir, "empty_log.jsonl")
            root, count = audit_log.compute_merkle_root(empty_path)
            self.assertEqual(root, audit_log.GENESIS_HASH)
            self.assertEqual(count, 0)

    def test_merkle_root_and_proof_lifecycle(self):
        """Constructs an audit log, computes Merkle root, generates and verifies proofs."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_p = os.path.join(tmpdir, "test_merkle.jsonl")

            # Create 5 distinct audit log entries
            entries = []
            for i in range(5):
                e = audit_log.log_event(
                    channel="test_channel",
                    decision="BLOCK" if i % 2 == 0 else "ALLOW",
                    risk_score=20 * (i + 1),
                    action_attempted=f"action_{i}",
                    category=f"CAT-{i}",
                    log_path=log_p
                )
                entries.append(e)

            # 1. Compute Merkle Root
            root, total = audit_log.compute_merkle_root(log_p)
            self.assertEqual(total, 5)
            self.assertTrue(isinstance(root, str))
            self.assertEqual(len(root), 64)

            # 2. Linear hash chain integrity should also pass
            is_valid, tampered_line, msg = audit_log.verify_log(log_p)
            self.assertTrue(is_valid)
            self.assertIsNone(tampered_line)

            # 3. Generate Merkle Proof for each leaf and verify it
            for idx, entry in enumerate(entries):
                proof_data = audit_log.generate_merkle_proof(idx, log_p)
                self.assertEqual(proof_data["leaf_hash"], entry["hash"])
                self.assertEqual(proof_data["merkle_root"], root)

                verified = audit_log.verify_merkle_proof(
                    proof_data["leaf_hash"],
                    proof_data["proof"],
                    root
                )
                self.assertTrue(verified, f"Proof verification failed for leaf index {idx}")

            # 4. Tampered leaf hash must fail verification against the valid root
            tampered_hash = "f" * 64
            proof_data = audit_log.generate_merkle_proof(0, log_p)
            tampered_verified = audit_log.verify_merkle_proof(
                tampered_hash,
                proof_data["proof"],
                root
            )
            self.assertFalse(tampered_verified)

    def test_canary_alert_logged_to_audit_ledger(self):
        """Triggering a canary alert records a block event to the audit ledger."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_p = os.path.join(tmpdir, "canary_audit.jsonl")
            entry = canary.trigger_canary_alert(
                event_type="UnauthorizedEnvRead",
                detail="Attacker attempted to read AWS_SECRET_ACCESS_KEY",
                evidence="os.environ['AWS_SECRET_ACCESS_KEY']",
                log_path=log_p
            )
            self.assertEqual(entry["category"], "CANARY_TRIPWIRE")
            self.assertEqual(entry["decision"], "BLOCK")
            self.assertEqual(entry["risk_score"], 100)

            # Check that hash chain verifies
            is_valid, _, _ = audit_log.verify_log(log_p)
            self.assertTrue(is_valid)


class TestAuditAPIEndpoints(unittest.TestCase):
    """Tests for Flask API endpoints verifying the cryptographic audit log."""

    def setUp(self):
        import app as flask_app
        flask_app.app.config["TESTING"] = True
        self.client = flask_app.app.test_client()

    def test_verify_audit_endpoint(self):
        """GET /api/security/audit/verify returns valid integrity status and Merkle root."""
        resp = self.client.get("/api/security/audit/verify")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["status"], "success")
        self.assertIn("valid", data)
        self.assertIn("merkle_root", data)
        self.assertIn("total_entries", data)


if __name__ == "__main__":
    unittest.main()
