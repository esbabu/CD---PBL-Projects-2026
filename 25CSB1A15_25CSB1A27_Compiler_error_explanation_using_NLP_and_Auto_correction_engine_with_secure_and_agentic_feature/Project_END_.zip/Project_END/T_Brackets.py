# B1 - Expect: OK, no problems
print((1 + [2, 3]) * {4: 5}[4])

# B2 - Expect: Unclosed '(' at column 4
x = (1 + 2

# B3 - Expect: Unmatched ')' because nothing is open
y = 1 + 2)

# B4 - Expect: '[' was closed by ')'; expected ']'
z = [1, 2)

# B5 - Expect: All three problems reported in one pass:
# Line 1: Mismatched closing bracket; expected ')' but found ']'
# Line 2: Unmatched ')' because nothing is open
# Line 3: Unclosed '{'
a = (1 + 2]
b = 5)
c = {3: 4

# B6 - Expect: OK; brackets inside strings and comments are ignored
s = "([{"  # ) ] }

# B7 - Expect: Unclosed '(' reported at line 1
total = compute(1,
                2,
                3
print(total)

# B8 - Expect: Unmatched '}'; PDA trace should show the stack at each step
( [ ] ) }

# B9 - Expect: Usual SyntaxError explanation unchanged from before Week 3;
# the analyze response in F12 -> Network includes a new bracket_hint field
print("hi"

# B10 - Expect: Bracket check says OK (documented limitation: f-string contents
# are not checked); Python's normal explanation still reports a SyntaxError
print(f"{(1+2}")
