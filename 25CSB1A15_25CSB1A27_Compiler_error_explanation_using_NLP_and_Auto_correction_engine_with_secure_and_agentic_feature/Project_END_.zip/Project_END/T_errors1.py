message = "hello"
print(mesage)
x = 10 / 0
lst = [1, 2]
print(lst[10])
def greet(name)
    print("Hi", name)
greet("Sam")
print("Total: " + 5)
nums = [3, 1, 2]
nums.apend(4)
import math
print(math.sqrt(-1))
for x in 100:
    print(x)
