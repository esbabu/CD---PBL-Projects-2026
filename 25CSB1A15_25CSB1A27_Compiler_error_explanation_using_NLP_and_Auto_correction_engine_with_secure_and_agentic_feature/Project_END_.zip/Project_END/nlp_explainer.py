# nlp_explainer.py
# Conservative Hybrid NLP diagnostic & auto-fix engine with sandbox verification and intent-preserving fixes.

import os
import sys
import json
import re
import time
import ast
import difflib
import tempfile
import subprocess
import requests
import tokenize
import io
import textwrap
import hashlib

# Flag to enable/disable neural transformer model
USE_MODEL = False

# Flag to enable/disable Gemini/Groq LLM explanation tier
USE_LLM = bool(os.environ.get("GEMINI_API_KEY") or os.environ.get("GROQ_API_KEY"))

# Suppress noisy tokenizers parallelism warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

ALLOWED_STDLIB_MODULES = {
    "math", "json", "random", "re", "time", "datetime",
    "collections", "itertools", "string", "statistics", "sys"
}

from sandbox_runner import run_in_sandbox

def _run_in_sandbox_full(code_str, timeout=5):
    """
    Runs code in an isolated sandbox child process.
    Returns: (is_clean_exit, error_type, error_message, line_number, stdout, stderr)
    """
    if isinstance(code_str, str) and code_str.startswith("\ufeff"):
        code_str = code_str[1:]

    res = run_in_sandbox(code_str, timeout=timeout)
    is_clean = (res.get("status") == "ok")
    err_type = None
    err_msg = None
    line_no = None
    if res.get("error"):
        err_type = res["error"].get("error_type")
        err_msg = res["error"].get("error_message")
        line_no = res["error"].get("line_number")
    elif not is_clean:
        err_type = res.get("status")
        err_msg = res.get("stderr") or res.get("status")

    return is_clean, err_type, err_msg, line_no, res.get("stdout", ""), res.get("stderr", "")


def _run_in_sandbox(code_str, timeout=5):
    """
    Runs code in an isolated subprocess inside a fresh sandbox.
    Returns: (is_clean_exit, error_type, error_message, line_number)
    """
    clean, err_type, err_msg, line_no, _, _ = _run_in_sandbox_full(code_str, timeout=timeout)
    return clean, err_type, err_msg, line_no

def _extract_source_line_from_traceback(tb_str, line_no=None):
    """Extracts the exact offending source line from the traceback string."""
    if not tb_str:
        return ""
    tb_lines = tb_str.strip().split("\n")
    for i, line in enumerate(tb_lines):
        if 'File "<string>"' in line or (line_no and f"line {line_no}" in line):
            if i + 1 < len(tb_lines):
                candidate = tb_lines[i + 1].strip()
                if not candidate.startswith("File ") and not any(candidate.startswith(err) for err in [
                    "ZeroDivisionError", "NameError", "IndexError", "TypeError",
                    "ValueError", "SyntaxError", "KeyError", "AttributeError",
                    "IndentationError", "FileNotFoundError", "RecursionError",
                    "StopIteration", "ModuleNotFoundError", "Exception", "[Previous line"
                ]):
                    return candidate
    return ""

def _clean_error_message(msg):
    """Cleans up internal exception noise from error message."""
    if not msg:
        return ""
    clean = str(msg).strip()
    return clean

def _collect_defined_symbols(code_str):
    """Parses code AST safely to collect all defined variable and function names in local scope using the symbol table."""
    try:
        from semantic_analyzer import SemanticAnalyzer
        sem = SemanticAnalyzer(code_str)
        res = sem.analyze()
        if res.get("success"):
            syms = {s["name"] for s in res.get("symbol_table", []) if s.get("name")}
            if syms:
                return syms
    except Exception:
        pass

    symbols = set()
    try:
        tree = ast.parse(code_str)
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Param)):
                symbols.add(node.id)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                symbols.add(node.name)
            elif isinstance(node, ast.arg):
                symbols.add(node.arg)
    except Exception:
        pass
    return symbols


class NLPExplainer:
    """
    Diagnostic explainer integrating deterministic rule-based error diagnostics,
    an online multi-provider AI tier (Gemini / Groq), and an offline deterministic guide.
    """

    def __init__(self, model_dir=None, ollama_url="http://localhost:11434/api/generate"):
        self.ollama_url = ollama_url
        self.model_loaded = False
        self.model = None
        self.tokenizer = None
        self.device = "cpu"
        self.last_fix_status = "no_safe_autofix"
        self.last_fix_suggestion = ""
        self.last_source = "rule"
        self.last_ai_provider = ""
        self.last_fix_steps = []
        self.last_fixer_name = ""

        # Recognized error types for primary deterministic rule engine
        self.recognized_error_types = {
            "ZeroDivisionError",
            "NameError",
            "IndexError",
            "TypeError",
            "ValueError",
            "SyntaxError",
            "IndentationError",
            "KeyError",
            "AttributeError",
            "FileNotFoundError"
        }

        # Determine model path
        if model_dir is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            model_dir = os.path.join(base_dir, "trained_model")
        self.model_dir = model_dir

        # Load transformer model if flag is enabled
        if USE_MODEL:
            self._load_transformer_model()

    def _load_transformer_model(self):
        """Attempts to load the Flan-T5 model and tokenizer from trained_model folder."""
        if not os.path.exists(self.model_dir):
            self.model_loaded = False
            return

        try:
            import torch
            from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

            self.tokenizer = AutoTokenizer.from_pretrained(self.model_dir)
            self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_dir)
            self.model.eval()
            self.model_loaded = True
        except Exception:
            self.model_loaded = False
            self.model = None
            self.tokenizer = None

    def explain(self, ir, code=""):
        """
        Hybrid explanation generator:
        1. Recognized error types -> Deterministic rule-based engine quoting offending code & concrete fixes.
        2. Unrecognized error types -> Gemini/Groq LLM tier (labeled AI-generated).
        3. Unrecognized error types -> Offline guide (deterministic, labeled offline guide).
        4. Generic rule fallback (last resort only).
        """
        if isinstance(ir, str):
            try:
                ir = json.loads(ir)
            except Exception:
                ir = {}

        error_type = ir.get("error_type", "") if ir else ""
        error_msg = ir.get("error_message", "") if ir else ""
        error_var = ir.get("error_variable", "") if ir else ""
        line_no = ir.get("line_number", "") if ir else ""
        traceback_str = ir.get("traceback", "") if ir else ""
        code = code or (ir.get("code", "") if isinstance(ir, dict) else "")

        offending_line = _extract_source_line_from_traceback(traceback_str, line_no)

        # --- Rule-First Strategy (10 recognized error types) ---
        if error_type in self.recognized_error_types:
            self.last_source = "rule"
            self.last_ai_provider = ""
            return self._explain_recognized(error_type, error_msg, error_var, line_no, offending_line)

        # --- Fallback for Unrecognized Error Types: Try Flan-T5 Model if explicitly enabled ---
        if USE_MODEL and self.model_loaded and self.model is not None and self.tokenizer is not None:
            ai_explanation = self._explain_with_model(error_type, error_msg, line_no, offending_line)
            if ai_explanation:
                self.last_source = "ai"
                self.last_ai_provider = "Flan-T5"
                return ai_explanation

        # --- Online LLM Tier (Gemini / Groq with automatic failover) ---
        # Skip AI if LLM_DISABLED is set
        llm_disabled = (os.environ.get("LLM_DISABLED") == "1")
        if USE_LLM and not llm_disabled:
            try:
                from llm_explainer import LLMExplainer as _LLMExplainer
                if not hasattr(self, "_llm"):
                    self._llm = _LLMExplainer()
                llm_text = self._llm.explain(
                    error_type,
                    error_msg,
                    line_no,
                    code,
                )
                if llm_text:
                    self.last_source = "ai"
                    self.last_ai_provider = getattr(self._llm, "last_provider", "") or "AI"
                    return f"[AI-generated via {self.last_ai_provider} (may be inaccurate)] {llm_text}"
            except Exception:
                pass  # fall through to offline guide

        # --- Offline Guide (Deterministic, no AI, no network) ---
        try:
            import offline_guide
            guide_text = offline_guide.guide(
                error_type,
                error_msg,
                line_no,
                offending_line,
                code
            )
            if guide_text:
                self.last_source = "offline_guide"
                self.last_ai_provider = ""
                return guide_text
        except Exception:
            pass

        # --- Generic Rule Fallback (last resort only) ---
        self.last_source = "generic"
        self.last_ai_provider = ""
        return self._explain_generic_rule(error_type, error_msg, error_var, line_no, offending_line)

    def _explain_recognized(self, error_type, error_msg, error_var, line_no, offending_line=""):
        """Generates high-precision rule-based diagnostic containing source quote & concrete fixes."""
        line_info = f" at line {line_no}" if line_no else ""
        source_quote = f" (Offending line: `{offending_line}`)" if offending_line else ""
        clean_msg = _clean_error_message(error_msg)

        if error_type == "ZeroDivisionError":
            return (
                f"Mistake: Division by zero{line_info}{source_quote}. "
                f"Reason: Denominator evaluated to zero at runtime. "
                f"Fix: Guard the division with an 'if' check (e.g., `if divisor != 0:`) before dividing."
            )

        elif error_type == "NameError":
            var_name = error_var or "undefined variable"
            if "name '" in clean_msg:
                m = re.search(r"name\s+'([^']+)'", clean_msg)
                if m:
                    var_name = m.group(1)
            return (
                f"Mistake: Using undefined variable '{var_name}'{line_info}{source_quote}. "
                f"Reason: Variable '{var_name}' is referenced before being assigned or defined. "
                f"Fix: Define or initialize variable '{var_name}' in the enclosing scope before using it."
            )

        elif error_type == "TypeError":
            # Issue 3: Non-iterable in a for loop
            m_not_iter = re.search(r"'([^']+)' object is not iterable", clean_msg)
            if m_not_iter:
                t_name = m_not_iter.group(1)
                return (
                    f"Mistake: Attempting to iterate over non-iterable '{t_name}' object{line_info}{source_quote}. "
                    f"Reason: The object does not support iteration because it lacks an __iter__ or sequence method. "
                    f"Fix: Use `range({offending_line.split('in')[-1].strip() if 'in' in offending_line else t_name})` if looping over numbers, or wrap in a collection."
                )

            # Issue 4: Non-iterable unpacking
            m_unpack_noniter = re.search(r"cannot unpack non-iterable\s+([^\s]+)\s+object", clean_msg)
            if m_unpack_noniter:
                t_name = m_unpack_noniter.group(1)
                return (
                    f"Mistake: Attempting to unpack non-iterable scalar {t_name} object{line_info}{source_quote}. "
                    f"Reason: Multi-variable assignment requires an iterable collection (such as a list or tuple) on the right side. "
                    f"Fix: Assign the scalar value directly to a single variable, or wrap it in a sequence."
                )

            # Issue 5: Wrong number of arguments
            m_args = re.search(r"([a-zA-Z0-9_\.]+)\(\)\s+takes\s+([^()]+)\s+\((\d+)\s+given\)", clean_msg)
            if m_args:
                fn_name, expected_args, given_args = m_args.group(1), m_args.group(2).strip(), m_args.group(3)
                return (
                    f"Mistake: Wrong number of arguments passed to function '{fn_name}'{line_info}{source_quote}. "
                    f"Reason: Function '{fn_name}' expected {expected_args} but received {given_args} given. "
                    f"Fix: Update the call to '{fn_name}' with the correct number of arguments matching its signature."
                )

            # Issue 6: Float used as an index
            m_idx_type = re.search(r"(?:list|tuple|string|sequence)\s+indices must be integers or slices, not\s+([a-zA-Z0-9_]+)", clean_msg)
            if m_idx_type:
                idx_t = m_idx_type.group(1)
                return (
                    f"Mistake: Sequence indexing using non-integer type '{idx_t}'{line_info}{source_quote}. "
                    f"Reason: Sequence indices must be integers or slice objects, not {idx_t} values. "
                    f"Fix: Convert the index to integer using `int()` or use integer division `//`."
                )

            # Additional TypeError sub-cases:
            if "unsupported operand type(s)" in clean_msg:
                return (
                    f"Mistake: Mixing incompatible operand types{line_info}{source_quote}. "
                    f"Reason: Incompatible types cannot be combined directly ({clean_msg}). "
                    f"Fix: Explicitly convert data types using `str()`, `int()`, or `float()` before combining."
                )

            if "'NoneType' object is not subscriptable" in clean_msg:
                return (
                    f"Mistake: Subscripting None object{line_info}{source_quote}. "
                    f"Reason: Attempted to index or access key on None instead of a valid sequence or dictionary. "
                    f"Fix: Verify the object is not None before indexing, or check that previous function calls returned data."
                )

            if "object is not callable" in clean_msg:
                return (
                    f"Mistake: Calling non-callable object{line_info}{source_quote}. "
                    f"Reason: Parentheses `()` were applied to an object that is not a function ({clean_msg}). "
                    f"Fix: Remove parentheses or check that you did not overwrite the function name with a variable."
                )

            detail = f" ({clean_msg})" if clean_msg else ""
            return (
                f"Mistake: Mixing incompatible data types{line_info}{source_quote}. "
                f"Reason: Incompatible types cannot be combined directly{detail}. "
                f"Fix: Explicitly convert data types using `str()`, `int()`, or verify function parameter types."
            )

        elif error_type == "ValueError":
            # Issue 1: Math domain error
            if "math domain error" in clean_msg:
                return (
                    f"Mistake: Mathematical function input outside valid domain{line_info}{source_quote}. "
                    f"Reason: Mathematical functions (such as `math.sqrt` or `math.log`) are undefined for negative inputs in real arithmetic. "
                    f"Fix: Ensure the input value is within the function's valid mathematical domain (e.g. non-negative) or use `cmath` for complex numbers."
                )

            # Issue 2: Sequence unpacking mismatch (too many / not enough values)
            m_unpack_vals = re.search(r"(too many values to unpack \(expected (\d+)\)|not enough values to unpack \(expected (\d+), got (\d+)\))", clean_msg)
            if m_unpack_vals:
                return (
                    f"Mistake: Sequence unpacking count mismatch{line_info}{source_quote}. "
                    f"Reason: {clean_msg}. "
                    f"Fix: Match the number of variables on the left side to the number of elements in the collection, or use starred unpacking `*rest`."
                )

            # Additional ValueError sub-cases:
            if "invalid literal for int()" in clean_msg or "could not convert string to float" in clean_msg:
                return (
                    f"Mistake: Invalid string value for numeric conversion{line_info}{source_quote}. "
                    f"Reason: String contains non-numeric characters that cannot be parsed ({clean_msg}). "
                    f"Fix: Strip invalid characters, validate with `str.isdigit()`, or wrap conversion in a `try/except ValueError` block."
                )

            if "substring not found" in clean_msg:
                return (
                    f"Mistake: Substring not found in target string{line_info}{source_quote}. "
                    f"Reason: `str.index()` was called for a substring that does not exist in the string. "
                    f"Fix: Use `str.find()` which returns -1 on missing substrings, or verify with `if sub in string:`."
                )

            if "not in list" in clean_msg or "not in tuple" in clean_msg:
                return (
                    f"Mistake: Element not found in sequence{line_info}{source_quote}. "
                    f"Reason: Attempted to look up or remove an item that is not present ({clean_msg}). "
                    f"Fix: Check existence with `if item in my_list:` before calling `.index()` or `.remove()`."
                )

            detail = f" ({clean_msg})" if clean_msg else ""
            return (
                f"Mistake: Invalid value conversion{line_info}{source_quote}. "
                f"Reason: Value format does not match expected requirements{detail}. "
                f"Fix: Validate input values before parsing, or enclose conversion in a `try...except ValueError` block."
            )

        elif error_type == "IndexError":
            if "pop from empty list" in clean_msg:
                return (
                    f"Mistake: Popping item from empty list{line_info}{source_quote}. "
                    f"Reason: `list.pop()` was called on a list containing zero elements. "
                    f"Fix: Check that `len(my_list) > 0` before popping."
                )

            if "tuple index out of range" in clean_msg:
                return (
                    f"Mistake: Tuple index out of range{line_info}{source_quote}. "
                    f"Reason: Attempted to access a tuple index that exceeds its length ({clean_msg}). "
                    f"Fix: Verify index bounds `0 <= index < len(my_tuple)` before accessing."
                )

            return (
                f"Mistake: Sequence index out of bounds{line_info}{source_quote}. "
                f"Reason: Attempted to access an element index that exceeds the sequence length ({clean_msg or 'list index out of range'}). "
                f"Fix: Check bounds using `if index < len(sequence):` or iterate with `for item in sequence:`."
            )

        elif error_type == "SyntaxError":
            detail = f" ({clean_msg})" if clean_msg else ""
            return (
                f"Mistake: Syntax structure issue{line_info}{source_quote}. "
                f"Reason: Incorrect Python code structure or missing token{detail}. "
                f"Fix: Correct Python syntax (e.g., add missing colon `:` after control statements or close brackets)."
            )

        elif error_type == "KeyError":
            key_name = error_var or clean_msg.strip("'\"") or "key"
            return (
                f"Mistake: Invalid dictionary key '{key_name}'{line_info}{source_quote}. "
                f"Reason: Key '{key_name}' is not present in the dictionary. "
                f"Fix: Use `dict.get('{key_name}', default)` or verify existence with `if '{key_name}' in dict:`."
            )

        elif error_type == "AttributeError":
            attr_msg = clean_msg if clean_msg else "Object lacks requested attribute"
            return (
                f"Mistake: Attribute not found{line_info}{source_quote}. "
                f"Reason: {attr_msg}. "
                f"Fix: Verify the object has the expected type and methods, and check spelling."
            )

        elif error_type == "IndentationError":
            return (
                f"Mistake: Inconsistent or missing indentation{line_info}{source_quote}. "
                f"Reason: Python requires consistent indentation to define code blocks ({clean_msg}). "
                f"Fix: Indent all lines inside the block consistently with 4 spaces."
            )

        elif error_type == "FileNotFoundError":
            path_str = clean_msg if clean_msg else "specified file path"
            return (
                f"Mistake: File or directory not found{line_info}{source_quote}. "
                f"Reason: {path_str}. "
                f"Fix: Verify the file path exists using `os.path.exists(path)` or check the working directory."
            )

        # Fallback
        return self._explain_generic_rule(error_type, error_msg, error_var, line_no, offending_line)

    def _explain_generic_rule(self, error_type, error_msg, error_var, line_no, offending_line=""):
        """Fallback rule for unmapped errors."""
        line_info = f" at line {line_no}" if line_no else ""
        source_quote = f" (Offending line: `{offending_line}`)" if offending_line else ""
        detail = f": {error_msg}" if error_msg else ""
        return (
            f"Mistake: Runtime {error_type}{line_info}{source_quote}. "
            f"Reason: Unexpected execution condition{detail}. "
            f"Fix: Adjust code logic and handle exception."
        )

    def _explain_with_model(self, error_type, error_msg, line_no, offending_line=""):
        """Generates an explanation using the fine-tuned Flan-T5 model."""
        if not self.model_loaded or self.model is None or self.tokenizer is None:
            return None

        clean_msg = _clean_error_message(error_msg)
        prompt = f"Explain Python error {error_type}: {clean_msg}"
        if line_no:
            prompt += f" at line {line_no}"
        if offending_line:
            prompt += f" in code: {offending_line}"

        try:
            inputs = self.tokenizer(prompt, return_tensors="pt", max_length=128, truncation=True)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            outputs = self.model.generate(
                **inputs,
                max_length=150,
                num_beams=4,
                early_stopping=True,
                no_repeat_ngram_size=2
            )
            explanation = self.tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
            if explanation and len(explanation) > 10:
                return f"[AI-generated (may be inaccurate)] {explanation}"
            return None
        except Exception:
            return None

    def generate_fixed_code(self, arg1, arg2=None):
        """Auto-correction engine that executes candidate fixes and verifies them in a multi-round repair loop."""
        if isinstance(arg1, str):
            code_str = arg1
            ir = arg2
        elif isinstance(arg2, str):
            code_str = arg2
            ir = arg1
        else:
            code_str = str(arg1 or "")
            ir = arg2

        self.last_fix_source = "none"
        self.last_fix_status = "no_fixer"
        self.last_fix_steps = []
        self.last_fix_providers = []
        self.last_fixer_name = ""
        self.last_ai_unavailable_reason = None

        if isinstance(code_str, str) and code_str.startswith("\ufeff"):
            code_str = code_str[1:]

        if not code_str or not code_str.strip():
            self.last_fix_status = "no_fixer"
            return code_str

        # Sandbox pass 0: Confirm original code actually raises an error
        is_clean, init_type, init_msg, init_line, init_stdout, init_stderr = _run_in_sandbox_full(code_str)
        if is_clean:
            self.last_fix_status = "already_clean"
            return code_str

        if init_type == "TimeoutExpired" or "while True" in code_str:
            self.last_fix_status = "no_fixer"
            return code_str

        current_code = code_str
        fix_steps = []
        applied_passes = 0
        max_passes = 5
        start_time = time.time()
        max_total_seconds = 25.0
        max_ai_calls = 3
        ai_calls_made = 0
        rejected_patches = set()
        ai_call_cache = {}
        providers_used = []

        for round_idx in range(1, max_passes + 1):
            if time.time() - start_time > max_total_seconds:
                break

            is_clean, current_err_type, current_err_msg, current_line, current_stdout, current_stderr = _run_in_sandbox_full(current_code)
            if is_clean:
                if applied_passes > 0:
                    self.last_fix_status = "applied"
                break

            if current_err_type == "TimeoutExpired":
                break

            # 1. Deterministic Fixers First
            self.last_fixer_name = ""
            candidate_code = self._apply_deterministic_fix(current_err_type, current_err_msg, current_line, current_code)
            candidate_source = "rule" if getattr(self, "last_fix_source", "") == "rule" else "deterministic"
            candidate_provider = None
            fixer_name = self.last_fixer_name or (current_err_type or "rule_fixer")

            if candidate_code and candidate_code != current_code:
                is_valid, _ = _validate_patch_acceptance(current_code, candidate_code, current_err_type, current_err_msg, current_line, current_stdout)
                if not is_valid:
                    candidate_code = None

            # 2. AI Fallback per round if no deterministic fixer applied
            if (not candidate_code or candidate_code == current_code) and ai_calls_made < max_ai_calls:
                if os.environ.get("AUTOFIX_AI", "1") != "0" and os.environ.get("LLM_DISABLED") != "1":
                    excluded_types = {
                        "security_blocked", "TimeoutError", "TimeoutExpired", "MemoryError",
                        "KeyboardInterrupt", "SystemExit", "ModuleNotFoundError", "ImportError",
                        "PermissionError", "FileNotFoundError", "IsADirectoryError", "NotADirectoryError", "OSError"
                    }
                    if current_err_type not in excluded_types:
                        ai_cand = self._apply_ai_autofix(
                            current_err_type, current_err_msg, current_line, current_code,
                            orig_stdout=current_stdout,
                            rejected_patches=rejected_patches,
                            call_cache=ai_call_cache
                        )
                        ai_prov = getattr(self, "last_ai_autofix_provider", None)
                        ai_calls_made += 1
                        if ai_cand and ai_cand != current_code:
                            candidate_code = ai_cand
                            candidate_source = "ai"
                            candidate_provider = ai_prov
                            fixer_name = "ai_fixer"
                            if ai_prov and ai_prov not in providers_used:
                                providers_used.append(ai_prov)

            if not candidate_code or candidate_code == current_code:
                if applied_passes > 0:
                    self.last_fix_status = f"fixed {applied_passes}; stopped at line {current_line or 1} ({current_err_type}): no automatic fix; any errors after this line cannot be detected until it is fixed"
                else:
                    if getattr(self, "last_ai_unavailable_reason", None) and getattr(self, "last_ai_unavailable_reason") in ("no key", "quota or rate limit", "timeout"):
                        self.last_fix_status = f"AI fix unavailable: {self.last_ai_unavailable_reason}"
                    else:
                        self.last_fix_status = f"stopped at line {current_line or 1} ({current_err_type}): no automatic fix; any errors after this line cannot be detected until it is fixed"
                break

            # Applied successfully in this round
            applied_passes += 1
            fix_steps.append({
                "round": round_idx,
                "error_type": current_err_type,
                "line": current_line or 0,
                "fixer": fixer_name,
                "source": candidate_source,
                "provider": candidate_provider,
                "status": "applied"
            })
            current_code = candidate_code

            # Check if this round resulted in a completely clean run
            cand_clean, _, _, _, _, _ = _run_in_sandbox_full(current_code)
            if cand_clean:
                self.last_fix_status = "applied"
                break

        self.last_fix_steps = fix_steps
        self.last_fix_providers = providers_used
        used_sources = set(s["source"] for s in fix_steps)
        if "ai" in used_sources and len(used_sources) > 1:
            self.last_fix_source = "mixed"
        elif len(used_sources) == 1:
            self.last_fix_source = list(used_sources)[0]
        elif len(used_sources) > 1 and "ai" not in used_sources:
            self.last_fix_source = "deterministic"
        else:
            self.last_fix_source = "none"

        final_clean, final_type, _, final_line, _, _ = _run_in_sandbox_full(current_code)
        if final_clean:
            if applied_passes > 0:
                self.last_fix_status = "applied"
        elif applied_passes > 0:
            if not self.last_fix_status.startswith("fixed"):
                self.last_fix_status = f"fixed {applied_passes}; stopped at line {final_line or 1} ({final_type}): no automatic fix; any errors after this line cannot be detected until it is fixed"
        elif not self.last_fix_status.startswith("rejected") and not self.last_fix_status.startswith("stopped") and not self.last_fix_status.startswith("AI fix unavailable"):
            self.last_fix_status = f"stopped at line {final_line or 1} ({final_type}): no automatic fix; any errors after this line cannot be detected until it is fixed"

        return current_code

    def _apply_deterministic_fix(self, err_type, err_msg, line_no, code_str):
        """Generates candidate fixed code for deterministic fixable error types."""
        if not line_no or line_no <= 0:
            line_no = 1

        newline_sep = "\r\n" if "\r\n" in code_str else "\n"
        lines = code_str.splitlines()
        target_idx = min(max(0, line_no - 1), len(lines) - 1)
        target_line = lines[target_idx] if lines else ""

        # Fix 0: RecursionError deterministic textbook fixer
        if err_type == "RecursionError":
            fixed = _fix_recursion_error(err_type, err_msg, line_no, code_str)
            if fixed and fixed != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "recursion_pattern_fixer"
                return fixed

        # Fix 1: SyntaxError
        if err_type in ("SyntaxError", "IndentationError"):
            # Missing colon
            stripped = target_line.strip()
            if ("expected ':'" in str(err_msg) or "invalid syntax" in str(err_msg) or not target_line.rstrip().endswith(":")):
                if any(stripped.startswith(kw) for kw in ["if", "elif", "else", "for", "while", "def", "class", "try", "except", "finally", "with", "async def", "async for", "async with"]):
                    if "#" in target_line:
                        code_part, comment_part = target_line.split("#", 1)
                        if not code_part.rstrip().endswith(":"):
                            lines[target_idx] = f"{code_part.rstrip()}: # AUTO-FIX #{comment_part}"
                            self.last_fix_source = "rule"
                            self.last_fixer_name = "missing_colon"
                            return newline_sep.join(lines)
                    else:
                        if not stripped.endswith(":"):
                            lines[target_idx] = target_line + ": # AUTO-FIX"
                            self.last_fix_source = "rule"
                            self.last_fixer_name = "missing_colon"
                            return newline_sep.join(lines)

            # Other syntax errors (unclosed brackets, unterminated strings, print2, =, commas)
            syntax_fix = _fix_syntax_error(err_type, err_msg, line_no, code_str)
            if syntax_fix and syntax_fix != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "syntax_error_fixer"
                return syntax_fix

        # Fix 2: UnboundLocalError
        if err_type == "UnboundLocalError":
            fixed = _fix_unbound_local(err_type, err_msg, line_no, code_str)
            if fixed and fixed != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "unbound_local_fixer"
                return fixed

        # Fix 3: StopIteration
        if err_type == "StopIteration":
            fixed = _fix_stop_iteration(err_type, err_msg, line_no, code_str)
            if fixed and fixed != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "stop_iteration_fixer"
                return fixed

        # Fix 4: RuntimeError dict/set size
        if err_type == "RuntimeError":
            fixed = _fix_runtime_dict_size_changed(err_type, err_msg, line_no, code_str)
            if fixed and fixed != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "runtime_dict_size_fixer"
                return fixed

        # Fix 5: TypeError
        if err_type == "TypeError":
            # (a) int not iterable in for loop
            range_fix = _fix_typeerror_int_iterable(err_type, err_msg, line_no, code_str)
            if range_fix and range_fix != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "typeerror_range_fixer"
                return range_fix

            # (b) str + non-str concatenation
            if "can only concatenate str" in str(err_msg) or "must be str" in str(err_msg):
                m = re.search(r'(\+\s*)([a-zA-Z_][a-zA-Z0-9_]*|\d+)', target_line)
                if m:
                    op, operand = m.group(1), m.group(2)
                    if not operand.startswith("str(") and operand != "str":
                        fixed_line = target_line[:m.start()] + f"{op}str({operand})" + target_line[m.end():]
                        lines[target_idx] = fixed_line
                        self.last_fix_source = "deterministic"
                        self.last_fixer_name = "typeerror_str_concat"
                        return newline_sep.join(lines)

        # Fix 6: NameError
        if err_type == "NameError":
            # (a) stdlib module import
            import_fix = _fix_nameerror_stdlib_import(err_type, err_msg, line_no, code_str)
            if import_fix and import_fix != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "stdlib_import_fixer"
                return import_fix

            # (b) variable name typo
            var_name = None
            if "'" in str(err_msg):
                var_name = str(err_msg).split("'")[1]
            elif "name " in str(err_msg):
                parts = str(err_msg).split()
                if len(parts) >= 2:
                    var_name = parts[1].strip("'\"")

            if var_name:
                # 1. Check Python's compiler hint: Did you mean: '...'
                hint_m = re.search(r"Did you mean: ['\"]([a-zA-Z0-9_]+)['\"]", str(err_msg))
                top_match = None
                if hint_m:
                    top_match = hint_m.group(1)
                else:
                    # Grounded symbol lookup via semantic analyzer symbol table
                    try:
                        from semantic_analyzer import suggest_symbol_hint
                        sym_hint = suggest_symbol_hint(code_str, var_name, line_no or 0)
                        if sym_hint and sym_hint.get("name"):
                            top_match = sym_hint["name"]
                    except Exception:
                        pass

                if not top_match:
                    defined_symbols = _collect_defined_symbols(code_str)
                    common_builtins = [
                        "print", "len", "range", "input", "str", "int", "float", "bool",
                        "list", "dict", "set", "tuple", "open", "enumerate", "zip", "sum",
                        "min", "max", "abs", "round", "sorted", "reversed", "map", "filter",
                        "any", "all", "isinstance", "issubclass", "type", "id", "hash", "repr", "dir", "help"
                    ]
                    candidates = [s for s in list(dict.fromkeys(list(defined_symbols) + common_builtins)) if s != var_name]
                    matches = difflib.get_close_matches(var_name, candidates, n=3, cutoff=0.7)
                    if matches:
                        m_cand = matches[0]
                        m_ratio = difflib.SequenceMatcher(None, var_name, m_cand).ratio()
                        other_candidates = [c for c in candidates if c != m_cand]
                        runner_up_ratio = max(
                            [difflib.SequenceMatcher(None, var_name, c).ratio() for c in other_candidates],
                            default=0.0
                        )
                        if m_ratio >= 0.7 and (m_ratio - runner_up_ratio >= 0.05):
                            top_match = m_cand

                if top_match:
                    closest_name = top_match
                    pattern = r'\b' + re.escape(var_name) + r'\b'
                    fixed_line = re.sub(pattern, closest_name, target_line)
                    if fixed_line != target_line:
                        lines[target_idx] = fixed_line
                        self.last_fix_source = "rule"
                        self.last_fixer_name = "name_error_typo"
                        return newline_sep.join(lines)

        # Fix 7: AttributeError typo
        if err_type == "AttributeError":
            m = re.search(r"'([a-zA-Z_][a-zA-Z0-9_]*)' object has no attribute '([a-zA-Z_][a-zA-Z0-9_]*)'", str(err_msg))
            if m:
                type_name, bad_attr = m.group(1), m.group(2)
                builtin_types = {
                    "list": list, "dict": dict, "str": str, "set": set,
                    "tuple": tuple, "int": int, "float": float, "bytes": bytes
                }
                if type_name in builtin_types:
                    candidates = [a for a in dir(builtin_types[type_name]) if not a.startswith("_")]
                    hint_m = re.search(r"Did you mean: '([a-zA-Z0-9_]+)'", str(err_msg))
                    top_match = None
                    if hint_m and hint_m.group(1) in candidates:
                        top_match = hint_m.group(1)
                    else:
                        matches = difflib.get_close_matches(bad_attr, candidates, n=3, cutoff=0.6)
                        if matches:
                            cand_match = matches[0]
                            cand_ratio = difflib.SequenceMatcher(None, bad_attr, cand_match).ratio()
                            other_candidates = [c for c in candidates if c != cand_match]
                            runner_up_ratio = max(
                                [difflib.SequenceMatcher(None, bad_attr, c).ratio() for c in other_candidates],
                                default=0.0
                            )
                            if cand_ratio >= 0.6 and (cand_ratio - runner_up_ratio >= 0.05 or len(matches) == 1):
                                top_match = cand_match
                    if top_match:
                        fixed_line = re.sub(r'\b' + re.escape(bad_attr) + r'\b', top_match, target_line)
                        if fixed_line != target_line:
                            lines[target_idx] = fixed_line
                            self.last_fix_source = "deterministic"
                            self.last_fixer_name = "attribute_error_typo"
                            return newline_sep.join(lines)

        # Fix 8: ModuleNotFoundError stdlib module typo
        if err_type in ("ModuleNotFoundError", "ImportError"):
            m = re.search(r"No module named '([a-zA-Z0-9_]+)'", str(err_msg))
            if m:
                bad_mod = m.group(1)
                stdlib_names = getattr(sys, "stdlib_module_names", set())
                if not stdlib_names:
                    stdlib_names = {"math", "json", "os", "sys", "re", "time", "random", "datetime", "collections", "itertools", "functools", "urllib", "sqlite3", "csv", "pathlib", "subprocess", "typing", "string", "io", "copy", "hashlib"}
                hint_m = re.search(r"Did you mean: '([a-zA-Z0-9_]+)'", str(err_msg))
                top_match = None
                if hint_m and hint_m.group(1) in stdlib_names:
                    top_match = hint_m.group(1)
                else:
                    matches = difflib.get_close_matches(bad_mod, list(stdlib_names), n=3, cutoff=0.6)
                    if matches:
                        cand_match = matches[0]
                        cand_ratio = difflib.SequenceMatcher(None, bad_mod, cand_match).ratio()
                        other_candidates = [c for c in stdlib_names if c != cand_match]
                        runner_up_ratio = max(
                            [difflib.SequenceMatcher(None, bad_mod, c).ratio() for c in other_candidates],
                            default=0.0
                        )
                        if cand_ratio >= 0.6 and (cand_ratio - runner_up_ratio >= 0.05 or len(matches) == 1):
                            top_match = cand_match
                if top_match:
                    fixed_line = re.sub(r'\b' + re.escape(bad_mod) + r'\b', top_match, target_line)
                    if fixed_line != target_line:
                        lines[target_idx] = fixed_line
                        self.last_fix_source = "deterministic"
                        self.last_fixer_name = "modulenotfound_typo"
                        return newline_sep.join(lines)

        # Fix 9: IndentationError / TabError convert tabs to 4 spaces
        if err_type in ("IndentationError", "TabError") or "tab" in str(err_msg).lower():
            if "\t" in code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "tab_to_spaces"
                return code_str.replace("\t", "    ")

        # Fix 10: FileExistsError os.mkdir -> os.makedirs(exist_ok=True)
        if err_type == "FileExistsError":
            fixed = _fix_file_exists_mkdir(err_type, err_msg, line_no, code_str)
            if fixed and fixed != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "file_exists_mkdir_fixer"
                return fixed

        # Fix 11: json.JSONDecodeError empty input guard
        if err_type in ("json.decoder.JSONDecodeError", "JSONDecodeError") or "Expecting value" in str(err_msg):
            fixed = _fix_json_decode_empty(err_type, err_msg, line_no, code_str)
            if fixed and fixed != code_str:
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "json_empty_guard"
                return fixed

        # Fix 12: Defensive Guards (ZeroDivision, IndexError, KeyError)
        if err_type == "ZeroDivisionError":
            fixed_line = _guard_zerodivision(target_line)
            if fixed_line and fixed_line != target_line:
                lines[target_idx] = fixed_line
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "zerodivision_guard"
                return newline_sep.join(lines)

        if err_type == "IndexError":
            fixed_line = _guard_indexerror(target_line)
            if fixed_line and fixed_line != target_line:
                lines[target_idx] = fixed_line
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "indexerror_guard"
                return newline_sep.join(lines)

        if err_type == "KeyError":
            fixed_line = _guard_keyerror(target_line)
            if fixed_line and fixed_line != target_line:
                lines[target_idx] = fixed_line
                self.last_fix_source = "deterministic"
                self.last_fixer_name = "keyerror_guard"
                return newline_sep.join(lines)

        return None

    def _apply_ai_autofix(self, err_type, err_msg, line_no, code_str, orig_stdout="", rejected_patches=None, call_cache=None):
        """Ask LLM chain (Gemini then Groq) for strict patch, validate with progress rule, and apply safely."""
        import llm_calls

        self.last_ai_autofix_provider = None

        if os.environ.get("AUTOFIX_AI", "1") == "0" or os.environ.get("LLM_DISABLED") == "1":
            self.last_ai_unavailable_reason = "AUTOFIX_AI=0"
            return None

        has_key = bool(os.environ.get("GEMINI_API_KEY")) or bool(os.environ.get("GROQ_API_KEY"))
        if not has_key:
            self.last_ai_unavailable_reason = "no key"
            return None

        excluded_types = {
            "security_blocked", "TimeoutError", "TimeoutExpired", "MemoryError",
            "KeyboardInterrupt", "SystemExit", "ModuleNotFoundError", "ImportError",
            "PermissionError", "FileNotFoundError", "IsADirectoryError", "NotADirectoryError", "OSError"
        }
        if err_type in excluded_types:
            self.last_ai_unavailable_reason = f"excluded: {err_type}"
            return None

        cache_key = hashlib.sha256(f"{err_type}:{err_msg}:{code_str}".encode("utf-8")).hexdigest()
        if call_cache is not None and cache_key in call_cache:
            cached_code, cached_prov = call_cache[cache_key]
            self.last_ai_autofix_provider = cached_prov
            return cached_code

        numbered_code = "\n".join(f"{i+1:3d} | {line}" for i, line in enumerate(code_str.splitlines()))
        prompt = (
            f"Fix this Python error:\n"
            f"Error: {err_type} at line {line_no}: {err_msg}\n\n"
            f"Code (with original 1-based line numbers):\n{numbered_code}\n\n"
            f"Keep the intent, do not replace functions with stubs or lambdas, make a minimal patch.\n"
            f"Propose ONLY a code patch starting with exactly one of: 'Replace line N with:', 'Replace lines N-M with:', 'Add before line N:', or 'Add after line N:'. Show the 4-space indented code."
        )

        providers = ["gemini", "groq"]
        if os.environ.get("LLM_PROVIDER_ORDER"):
            providers = [p.strip().lower() for p in os.environ["LLM_PROVIDER_ORDER"].split(",") if p.strip()]

        raw_patch = None
        used_provider = None
        last_error = None

        for prov in providers:
            if prov == "gemini" and bool(os.environ.get("GEMINI_API_KEY")):
                raw_patch, err, _ = llm_calls.call_gemini(
                    prompt=prompt,
                    system_instruction="You are a precise automated code repair assistant. Output only the patch line and indented code without Markdown fences.",
                    purpose="autofix",
                    timeout=12.0
                )
                if raw_patch:
                    used_provider = "gemini"
                    break
                else:
                    last_error = err
            elif prov == "groq" and bool(os.environ.get("GROQ_API_KEY")):
                raw_patch, err, _ = llm_calls.call_groq(
                    prompt=prompt,
                    system_instruction="You are a precise automated code repair assistant. Output only the patch line and indented code without Markdown fences.",
                    purpose="autofix",
                    timeout=8.0
                )
                if raw_patch:
                    used_provider = "groq"
                    break
                else:
                    last_error = err

        if not raw_patch:
            if last_error and ("quota" in str(last_error).lower() or "429" in str(last_error) or "rate" in str(last_error).lower()):
                self.last_ai_unavailable_reason = "quota or rate limit"
            elif last_error and ("timeout" in str(last_error).lower() or "timeoutexpired" in str(last_error).lower()):
                self.last_ai_unavailable_reason = "timeout"
            else:
                self.last_ai_unavailable_reason = last_error or "no response"
            if call_cache is not None:
                call_cache[cache_key] = (None, None)
            return None

        if rejected_patches is not None and raw_patch in rejected_patches:
            self.last_ai_unavailable_reason = "repeated rejected patch"
            if call_cache is not None:
                call_cache[cache_key] = (None, None)
            return None

        patched_code = _apply_raw_patch(code_str, raw_patch)
        if not patched_code or patched_code == code_str:
            if rejected_patches is not None:
                rejected_patches.add(raw_patch)
            self.last_ai_unavailable_reason = "rejected: cannot apply patch"
            if call_cache is not None:
                call_cache[cache_key] = (None, None)
            return None

        is_ok, reason = _validate_patch_acceptance(code_str, patched_code, err_type, err_msg, line_no, orig_stdout)
        if not is_ok:
            if rejected_patches is not None:
                rejected_patches.add(raw_patch)
            self.last_ai_unavailable_reason = f"rejected: {reason}"
            if call_cache is not None:
                call_cache[cache_key] = (None, None)
            return None

        self.last_ai_autofix_provider = used_provider
        if call_cache is not None:
            call_cache[cache_key] = (patched_code, used_provider)

        return patched_code


_ALLOWED_STDLIB_IMPORTS = {
    "math", "json", "random", "re", "time", "datetime",
    "collections", "itertools", "string", "statistics", "sys"
}


def _validate_patch_acceptance(orig_code, patched_code, err_type, err_msg, line_no, orig_stdout="", allow_earlier_failure: bool = False, skip_sandbox: bool = False):
    """Validates patch acceptance per Step B rules (syntax, security, AST invariants, <=6 lines, no line deletion, allowed stdlib imports, progress invariant)."""
    if not patched_code or patched_code == orig_code:
        return False, "no change"

    try:
        cand_tree = ast.parse(patched_code)
    except Exception:
        return False, "invalid syntax"

    try:
        orig_tree = ast.parse(orig_code)
    except Exception:
        orig_tree = None

    try:
        import security_analyzer
        orig_findings = security_analyzer.scan_code(orig_code)
        orig_rule_ids = {f.get("rule_id") for f in orig_findings}

        cand_gate = security_analyzer.scan_gate(patched_code)
        active_block_level = security_analyzer.get_scan_block_level()
        rank_thresh = security_analyzer.SEVERITY_RANKS.get(active_block_level) if active_block_level else None

        new_blocking = []
        for f in cand_gate.get("findings", []):
            if f.get("rule_id") not in orig_rule_ids:
                if rank_thresh is not None:
                    if security_analyzer.SEVERITY_RANKS.get(f.get("severity", "LOW"), 0) >= rank_thresh:
                        new_blocking.append(f)
                else:
                    if f.get("default_block", False):
                        new_blocking.append(f)

        if new_blocking:
            return False, f"security risk: introduces {new_blocking[0].get('rule_id')} ({new_blocking[0].get('severity')})"
    except Exception:
        pass


    orig_lines = orig_code.splitlines()
    patch_lines = patched_code.splitlines()
    if abs(len(patch_lines) - len(orig_lines)) > 6:
        return False, "changed lines > 6"

    if orig_tree is not None:
        orig_funcs = {n.name for n in ast.walk(orig_tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        cand_funcs = {n.name for n in ast.walk(cand_tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        orig_classes = {n.name for n in ast.walk(orig_tree) if isinstance(n, ast.ClassDef)}
        cand_classes = {n.name for n in ast.walk(cand_tree) if isinstance(n, ast.ClassDef)}
        if not orig_funcs.issubset(cand_funcs) or not orig_classes.issubset(cand_classes):
            return False, "function/class deleted"

        for node in ast.walk(cand_tree):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id in orig_funcs:
                        if isinstance(node.value, (ast.Lambda, ast.Constant)):
                            return False, "def replaced by lambda or constant"
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in orig_funcs:
                if len(node.body) == 1:
                    stmt = node.body[0]
                    is_stub = isinstance(stmt, ast.Pass) or (isinstance(stmt, ast.Return) and (stmt.value is None or (isinstance(stmt.value, ast.Constant) and stmt.value.value is None)))
                    if is_stub:
                        for onode in ast.walk(orig_tree):
                            if isinstance(onode, (ast.FunctionDef, ast.AsyncFunctionDef)) and onode.name == node.name:
                                if len(onode.body) > 1 or (not isinstance(onode.body[0], ast.Pass) and not (isinstance(onode.body[0], ast.Return) and onode.body[0].value is None)):
                                    return False, "def replaced by stub"

        orig_stmts = sum(1 for n in ast.walk(orig_tree) if isinstance(n, ast.stmt))
        cand_stmts = sum(1 for n in ast.walk(cand_tree) if isinstance(n, ast.stmt))
        if cand_stmts < orig_stmts - 1:
            return False, "statement count dropped > 1"

        orig_imports = set()
        for node in ast.walk(orig_tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    orig_imports.add(alias.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    orig_imports.add(node.module.split('.')[0])

        cand_imports = set()
        for node in ast.walk(cand_tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    cand_imports.add(alias.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    cand_imports.add(node.module.split('.')[0])

        new_imports = cand_imports - orig_imports
        for imp in new_imports:
            if imp not in _ALLOWED_STDLIB_IMPORTS:
                return False, f"forbidden import '{imp}'"
    else:
        # Orig had syntax error: ensure candidate has no forbidden imports
        cand_imports = set()
        for node in ast.walk(cand_tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    cand_imports.add(alias.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    cand_imports.add(node.module.split('.')[0])
        for imp in cand_imports:
            if imp not in _ALLOWED_STDLIB_IMPORTS and imp not in orig_code:
                return False, f"forbidden import '{imp}'"

    if err_type == "RecursionError":
        valid_rec = False
        for node in ast.walk(cand_tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                has_self_call = any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == node.name for c in ast.walk(node))
                has_base_case = (
                    any(isinstance(if_node, ast.If) and any(isinstance(r, ast.Return) for r in ast.walk(if_node)) for if_node in ast.walk(node))
                    or any(isinstance(if_exp, ast.IfExp) for if_exp in ast.walk(node))
                )
                if has_self_call and has_base_case:
                    valid_rec = True
                    break
        if not valid_rec:
            return False, "recursion without base case"

    target_orig = orig_lines[line_no - 1].strip() if (line_no and line_no <= len(orig_lines)) else ""
    target_cand = patch_lines[line_no - 1].strip() if (line_no and line_no <= len(patch_lines)) else ""
    if target_orig and target_orig not in ("pass", "...", ""):
        if target_cand in ("pass", "...", ""):
            return False, "deletion of failing line"

    orig_non_empty = [l.strip() for l in orig_lines if l.strip()]
    cand_non_empty = [l.strip() for l in patch_lines if l.strip()]
    if len(cand_non_empty) < len(orig_non_empty) and not any(l not in orig_non_empty for l in cand_non_empty):
        return False, "deletion of failing line"

    if skip_sandbox:
        return True, "static invariants satisfied"

    cand_clean, cand_type, cand_msg, cand_line, cand_stdout, cand_stderr = _run_in_sandbox_full(patched_code)
    
    if cand_clean:
        return True, "runs clean"

    if cand_type == "TimeoutExpired":
        return False, "timeout"

    if orig_stdout and not cand_stdout.startswith(orig_stdout):
        return False, "stdout prefix mismatch"

    if cand_type == err_type and cand_line == line_no and cand_msg == err_msg:
        return False, f"still raises {err_type} at line {line_no}"

    if err_type in ("SyntaxError", "IndentationError", "TabError") and cand_type not in ("SyntaxError", "IndentationError", "TabError"):
        return True, f"syntax fixed; runtime error at line {cand_line} ({cand_type})"

    line_delta = len(patch_lines) - len(orig_lines)
    mapped_orig_line = cand_line if cand_line <= line_no else cand_line - line_delta
    if mapped_orig_line > line_no or cand_line > line_no:
        return True, f"progress to line {cand_line} ({cand_type})"
    if allow_earlier_failure and (cand_line < line_no or mapped_orig_line < line_no):
        return True, f"progress (validated with earlier error at line {cand_line})"
    return False, f"no progress: fails at line {cand_line} ({cand_type})"


def _apply_raw_patch(orig_code, fix_text):
    """Parses standard patch formats and applies them to original code with preserved indentation."""
    if not fix_text or not fix_text.strip():
        return None

    newline_sep = "\r\n" if "\r\n" in orig_code else "\n"
    lines = orig_code.splitlines()
    patched_lines = None

    cleaned_fix = fix_text.strip()
    if cleaned_fix.startswith("```"):
        cleaned_fix = re.sub(r"^```[a-zA-Z]*\r?\n?", "", cleaned_fix)
        cleaned_fix = re.sub(r"\r?\n?```$", "", cleaned_fix)

    m1 = re.search(r"Replace line (\d+) with:[ \t]*\r?\n?(.*)", cleaned_fix, re.DOTALL | re.IGNORECASE)
    m2 = re.search(r"Replace lines? (\d+)\s*[-–to]\s*(\d+) with:[ \t]*\r?\n?(.*)", cleaned_fix, re.DOTALL | re.IGNORECASE)
    m3 = re.search(r"Add before line (\d+):[ \t]*\r?\n?(.*)", cleaned_fix, re.DOTALL | re.IGNORECASE)
    m4 = re.search(r"Add after line (\d+):[ \t]*\r?\n?(.*)", cleaned_fix, re.DOTALL | re.IGNORECASE)

    def extract_patch_code(raw_block):
        raw_lines = raw_block.splitlines()
        code_lines = []
        for l in raw_lines:
            if l.strip().startswith("```"):
                break
            if not l.startswith(" ") and not l.startswith("\t") and code_lines and not any(l.strip().startswith(kw) for kw in ("def ", "class ", "return ", "if ", "elif ", "else ", "for ", "while ", "try ", "except ", "finally ", "with ", "import ", "from ", "pass", "raise", "yield")):
                if any(phrase in l.lower() for phrase in ("this will", "this fixes", "explanation:", "note:", "the error")):
                    break
            code_lines.append(l)
        while code_lines and not code_lines[-1].strip():
            code_lines.pop()
        return "\n".join(code_lines)

    if m1:
        line_num = int(m1.group(1)) - 1
        rep_code = extract_patch_code(m1.group(2))
        if 0 <= line_num < len(lines):
            orig_indent = lines[line_num][:len(lines[line_num]) - len(lines[line_num].lstrip())]
            rep_dedent = textwrap.dedent(rep_code)
            rep_lines = [(orig_indent + l if l.strip() else "") for l in rep_dedent.splitlines()]
            patched_lines = lines[:line_num] + rep_lines + lines[line_num + 1:]
    elif m2:
        start_line = int(m2.group(1)) - 1
        end_line = int(m2.group(2))
        rep_code = extract_patch_code(m2.group(3))
        if 0 <= start_line < len(lines) and end_line <= len(lines):
            orig_indent = lines[start_line][:len(lines[start_line]) - len(lines[start_line].lstrip())]
            rep_dedent = textwrap.dedent(rep_code)
            rep_lines = [(orig_indent + l if l.strip() else "") for l in rep_dedent.splitlines()]
            patched_lines = lines[:start_line] + rep_lines + lines[end_line:]
    elif m3:
        line_num = int(m3.group(1)) - 1
        rep_code = extract_patch_code(m3.group(2))
        if 0 <= line_num <= len(lines):
            ref_idx = min(line_num, len(lines) - 1) if lines else 0
            orig_indent = lines[ref_idx][:len(lines[ref_idx]) - len(lines[ref_idx].lstrip())] if lines else ""
            rep_dedent = textwrap.dedent(rep_code)
            rep_lines = [(orig_indent + l if l.strip() else "") for l in rep_dedent.splitlines()]
            patched_lines = lines[:line_num] + rep_lines + lines[line_num:]
    elif m4:
        line_num = int(m4.group(1))
        rep_code = extract_patch_code(m4.group(2))
        if 0 <= line_num <= len(lines):
            ref_idx = max(0, line_num - 1) if lines else 0
            orig_indent = lines[ref_idx][:len(lines[ref_idx]) - len(lines[ref_idx].lstrip())] if lines else ""
            rep_dedent = textwrap.dedent(rep_code)
            rep_lines = [(orig_indent + l if l.strip() else "") for l in rep_dedent.splitlines()]
            patched_lines = lines[:line_num] + rep_lines + lines[line_num:]

    if patched_lines is None:
        fence_m = re.search(r"```(?:python)?\s*\n(.*?)```", fix_text, re.DOTALL)
        if fence_m:
            candidate = fence_m.group(1).strip()
            try:
                ast.parse(candidate)
                return candidate
            except Exception:
                pass
        return None
    return newline_sep.join(patched_lines)


def _fix_recursion_error(err_type, err_msg, line_no, code_str):
    """Deterministic fixer for textbook single-parameter recursion without base cases."""
    if err_type != "RecursionError":
        return None
    try:
        tree = ast.parse(code_str)
    except Exception:
        return None

    # AST verification: find recursive function
    functions = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    target_func = None
    if len(functions) == 1:
        target_func = functions[0]
    else:
        if line_no and line_no > 0:
            for n in functions:
                if hasattr(n, "lineno") and hasattr(n, "end_lineno"):
                    if n.lineno <= line_no <= n.end_lineno:
                        target_func = n
                        break
        if not target_func:
            recursive_funcs = [
                n for n in functions
                if any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == n.name for c in ast.walk(n))
            ]
            if len(recursive_funcs) == 1:
                target_func = recursive_funcs[0]
    if not target_func:
        return None
    func = target_func

    # Precondition: exactly 1 positional parameter, no defaults, no kwonly, no vararg, no kwarg
    args = func.args
    total_params = len(args.args) + len(getattr(args, "posonlyargs", []))
    if total_params != 1 or args.kwonlyargs or args.vararg or args.kwarg or args.defaults or args.kw_defaults:
        return None
    param_name = (args.args[0] if args.args else args.posonlyargs[0]).arg

    # Precondition: no existing conditional return or guard
    for n in ast.walk(func):
        if isinstance(n, ast.If):
            if any(isinstance(child, (ast.Return, ast.Raise, ast.Break)) for child in ast.walk(n)):
                return None

    # Check recursive calls inside function
    calls = [n for n in ast.walk(func) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == func.name]
    if not calls:
        return None

    # Verify every recursive call passes param_name - k (k positive int)
    k_val = None
    for c in calls:
        if len(c.args) != 1:
            return None
        arg = c.args[0]
        if not (isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Sub) and isinstance(arg.left, ast.Name) and arg.left.id == param_name and isinstance(arg.right, ast.Constant) and isinstance(arg.right.value, int) and arg.right.value > 0):
            return None
        k_val = arg.right.value

    # Classify shape:
    # 1. Countdown shape:
    #    return f(P - k) or f(P - k) as statement
    #    base case: if P <= 0: return None
    # 2. Factorial shape:
    #    return P * f(P - 1) or return f(P - 1) * P
    #    base case: if P <= 1: return 1
    # 3. Fibonacci shape:
    #    return f(P - 1) + f(P - 2)
    #    base case: if P <= 1: return P

    base_case = None
    if len(calls) == 2:
        returns = [n for n in ast.walk(func) if isinstance(n, ast.Return)]
        if returns and isinstance(returns[0].value, ast.BinOp) and isinstance(returns[0].value.op, ast.Add):
            base_case = f"if {param_name} <= 1:\n    return {param_name}"
    elif len(calls) == 1:
        returns = [n for n in ast.walk(func) if isinstance(n, ast.Return)]
        if returns and isinstance(returns[0].value, ast.BinOp) and isinstance(returns[0].value.op, ast.Mult):
            base_case = f"if {param_name} <= 1:\n    return 1"
        else:
            base_case = f"if {param_name} <= 0:\n    return None"

    if not base_case:
        return None

    first_stmt = func.body[0]
    insert_line_idx = first_stmt.lineno - 1

    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    if insert_line_idx >= len(lines):
        return None

    first_line = lines[insert_line_idx]
    indent = first_line[:len(first_line) - len(first_line.lstrip())]
    if not indent:
        indent = "    "

    base_case_lines = [f"{indent}{l}" if l.strip() else "" for l in base_case.splitlines()]
    new_lines = lines[:insert_line_idx] + base_case_lines + lines[insert_line_idx:]
    return newline_sep.join(new_lines)


def _fix_unbound_local(err_type, err_msg, line_no, code_str):
    """Inserts 'global NAME' (or 'nonlocal NAME') as first statement of enclosing function."""
    if err_type != "UnboundLocalError":
        return None
    m = re.search(r"cannot access local variable '([a-zA-Z_][a-zA-Z0-9_]*)'|local variable '([a-zA-Z_][a-zA-Z0-9_]*)' referenced before assignment", str(err_msg))
    if not m:
        return None
    var_name = m.group(1) or m.group(2)
    if not var_name:
        return None

    try:
        tree = ast.parse(code_str)
    except Exception:
        return None

    class ScopeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.stack = []
            self.matching_func = None
            self.scope_stack = []

        def visit_FunctionDef(self, node):
            self.stack.append(node)
            if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                if node.lineno <= line_no <= node.end_lineno:
                    self.matching_func = node
                    self.scope_stack = list(self.stack)
            self.generic_visit(node)
            self.stack.pop()

        def visit_AsyncFunctionDef(self, node):
            self.visit_FunctionDef(node)

    visitor = ScopeVisitor()
    visitor.visit(tree)

    if not visitor.matching_func:
        return None

    func_node = visitor.matching_func
    func_params = {a.arg for a in func_node.args.args}
    func_params.update(a.arg for a in getattr(func_node.args, "posonlyargs", []))
    func_params.update(a.arg for a in func_node.args.kwonlyargs)
    if func_node.args.vararg:
        func_params.add(func_node.args.vararg.arg)
    if func_node.args.kwarg:
        func_params.add(func_node.args.kwarg.arg)

    if var_name in func_params:
        return None

    scope_hierarchy = visitor.scope_stack
    is_nonlocal = False
    is_global = False

    for enclosing in reversed(scope_hierarchy[:-1]):
        for node in ast.walk(enclosing):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store) and node.id == var_name:
                is_nonlocal = True
                break
        if is_nonlocal:
            break

    if not is_nonlocal:
        for node in tree.body:
            if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                for target in ast.walk(node):
                    if isinstance(target, ast.Name) and isinstance(target.ctx, ast.Store) and target.id == var_name:
                        is_global = True
                        break
            elif isinstance(node, ast.NamedExpr):
                if isinstance(node.target, ast.Name) and node.target.id == var_name:
                    is_global = True
                    break

    if not is_global and not is_nonlocal:
        return None

    kw = "nonlocal" if is_nonlocal else "global"
    declaration = f"{kw} {var_name}"

    first_stmt = func_node.body[0]
    insert_line_idx = first_stmt.lineno - 1

    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    if insert_line_idx >= len(lines):
        return None

    first_line = lines[insert_line_idx]
    indent = first_line[:len(first_line) - len(first_line.lstrip())]
    if not indent:
        indent = "    "

    new_line = f"{indent}{declaration}"
    lines.insert(insert_line_idx, new_line)
    return newline_sep.join(lines)


def _fix_stop_iteration(err_type, err_msg, line_no, code_str):
    """Rewrites single next(x) call on line as next(x, None)."""
    if err_type != "StopIteration":
        return None
    if not line_no or line_no <= 0:
        return None
    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    if line_no > len(lines):
        return None

    target_idx = line_no - 1
    target_line = lines[target_idx]

    try:
        tree = ast.parse(target_line.strip())
        next_calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'next']
        if len(next_calls) == 1 and len(next_calls[0].args) == 1:
            class NextLineTransformer(ast.NodeTransformer):
                def visit_Call(self, node):
                    if node is next_calls[0]:
                        node.args.append(ast.Constant(value=None))
                    return self.generic_visit(node)
            new_tree = NextLineTransformer().visit(tree)
            ast.fix_missing_locations(new_tree)
            indent = target_line[:len(target_line) - len(target_line.lstrip())]
            lines[target_idx] = indent + ast.unparse(new_tree)
            return newline_sep.join(lines)
    except Exception:
        pass

    try:
        full_tree = ast.parse(code_str)
        calls = [n for n in ast.walk(full_tree) if isinstance(n, ast.Call) and getattr(n, 'lineno', None) == line_no]
        next_calls = [c for c in calls if isinstance(c.func, ast.Name) and c.func.id == 'next']
        if len(next_calls) == 1 and len(next_calls[0].args) == 1:
            class NextTransformer(ast.NodeTransformer):
                def visit_Call(self, node):
                    if node is next_calls[0]:
                        node.args.append(ast.Constant(value=None))
                    return self.generic_visit(node)
            new_tree = NextTransformer().visit(full_tree)
            ast.fix_missing_locations(new_tree)
            return ast.unparse(new_tree)
    except Exception:
        pass

    return None


def _fix_runtime_dict_size_changed(err_type, err_msg, line_no, code_str):
    """Wraps iterable of failing for loop in list(...)."""
    if err_type != "RuntimeError":
        return None
    msg_str = str(err_msg).lower()
    if "dictionary changed size during iteration" not in msg_str and "set changed size during iteration" not in msg_str:
        return None

    try:
        tree = ast.parse(code_str)
    except Exception:
        return None

    for_nodes = []
    for node in ast.walk(tree):
        if isinstance(node, ast.For):
            if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                if node.lineno <= line_no <= node.end_lineno:
                    for_nodes.append(node)

    if not for_nodes:
        for_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.For)]

    if not for_nodes:
        return None

    target_for = max(for_nodes, key=lambda n: getattr(n, 'lineno', 0))

    if isinstance(target_for.iter, ast.Call) and isinstance(target_for.iter.func, ast.Name) and target_for.iter.func.id == 'list':
        return None

    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    for_lineno = target_for.lineno
    if not (1 <= for_lineno <= len(lines)):
        return None

    target_line = lines[for_lineno - 1]
    m = re.match(r"^(\s*for\s+[a-zA-Z0-9_,\s\(\)]+\s+in\s+)(.+?)(:.*)$", target_line)
    if m:
        prefix, iter_expr, suffix = m.group(1), m.group(2), m.group(3)
        if not iter_expr.strip().startswith("list("):
            new_line = f"{prefix}list({iter_expr.strip()}){suffix}"
            lines[for_lineno - 1] = new_line
            return newline_sep.join(lines)

    return None


def _fix_typeerror_int_iterable(err_type, err_msg, line_no, code_str):
    """Rewrites for x in <int> to for x in range(<int>), supporting inline and multi-block code."""
    if err_type != "TypeError":
        return None
    if "'int' object is not iterable" not in str(err_msg):
        return None

    try:
        tree = ast.parse(code_str)
    except Exception:
        return None

    target_for = None
    if line_no is not None:
        for node in ast.walk(tree):
            if isinstance(node, ast.For):
                if getattr(node, 'lineno', None) == line_no:
                    target_for = node
                    break
                elif getattr(node, 'lineno', 0) <= line_no <= getattr(node, 'end_lineno', getattr(node, 'lineno', 0)):
                    target_for = node

    if not target_for:
        for_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.For)]
        if len(for_nodes) == 1:
            target_for = for_nodes[0]
        elif line_no is not None:
            for_nodes.sort(key=lambda n: abs(getattr(n, 'lineno', 0) - line_no))
            if for_nodes:
                target_for = for_nodes[0]

    if not target_for:
        return None

    for_lineno = getattr(target_for, 'lineno', line_no)
    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    if not for_lineno or not (1 <= for_lineno <= len(lines)):
        return None

    target_line = lines[for_lineno - 1]
    m = re.match(r"^(\s*for\s+[a-zA-Z0-9_,\s\(\)]+\s+in\s+)(.+?)(:.*)$", target_line)
    if m:
        prefix, iter_expr, suffix = m.group(1), m.group(2), m.group(3)
        if not iter_expr.strip().startswith("range("):
            new_line = f"{prefix}range({iter_expr.strip()}){suffix}"
            lines[for_lineno - 1] = new_line
            return newline_sep.join(lines)

    return None


def _fix_nameerror_stdlib_import(err_type, err_msg, line_no, code_str):
    """Inserts import NAME for allowed stdlib modules used as NAME.attr."""
    if err_type != "NameError":
        return None
    m = re.search(r"name '([a-zA-Z_][a-zA-Z0-9_]*)' is not defined", str(err_msg))
    if not m:
        return None
    mod_name = m.group(1)
    if mod_name not in ALLOWED_STDLIB_MODULES:
        return None

    try:
        tree = ast.parse(code_str)
    except Exception:
        return None

    is_attribute_access = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == mod_name:
            is_attribute_access = True
            break

    if not is_attribute_access:
        return None

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == mod_name:
                    return None
        elif isinstance(node, ast.ImportFrom):
            if node.module == mod_name:
                return None

    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    insert_idx = 0

    if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(tree.body[0].value, ast.Constant) and isinstance(tree.body[0].value.value, str):
        insert_idx = tree.body[0].end_lineno

    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            if node.end_lineno > insert_idx:
                insert_idx = node.end_lineno

    lines.insert(insert_idx, f"import {mod_name}")
    return newline_sep.join(lines)


def _fix_syntax_error(err_type, err_msg, line_no, code_str):
    """Deterministic fixes for common syntax errors."""
    if err_type not in ("SyntaxError", "IndentationError"):
        return None

    msg = str(err_msg).lower()
    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()

    # (a) Unclosed brackets at end of source
    bracket_fixed = _fix_unclosed_brackets(code_str)
    if bracket_fixed and bracket_fixed != code_str:
        try:
            ast.parse(bracket_fixed)
            return bracket_fixed
        except Exception:
            pass

    # (a2) PDA bracket fixer (mismatched, unmatched closing, unclosed)
    try:
        import bracket_checker
        pda_bracket_fixed = bracket_checker.fix_brackets(code_str)
        if pda_bracket_fixed and pda_bracket_fixed != code_str:
            try:
                ast.parse(pda_bracket_fixed)
                return pda_bracket_fixed
            except Exception:
                chk_orig = bracket_checker.check_brackets(code_str)
                chk_new = bracket_checker.check_brackets(pda_bracket_fixed)
                if len(chk_new.get("problems", [])) < len(chk_orig.get("problems", [])):
                    return pda_bracket_fixed
    except Exception:
        pass

    # (b) Unterminated single-line string literal
    if "unterminated string literal" in msg or "eol while scanning string literal" in msg:
        if line_no and 1 <= line_no <= len(lines):
            target_line = lines[line_no - 1]
            for q in ('"', "'", '"""', "'''"):
                cand_line = target_line + q
                lines[line_no - 1] = cand_line
                cand_code = newline_sep.join(lines)
                try:
                    ast.parse(cand_code)
                    return cand_code
                except Exception:
                    lines[line_no - 1] = target_line

    # (c) Python 2 style print statement
    if line_no and 1 <= line_no <= len(lines):
        target_line = lines[line_no - 1]
        m = re.match(r"^(\s*)print\s+([^()]+.*)$", target_line)
        if m:
            indent, expr = m.group(1), m.group(2)
            if not expr.startswith("(") or not expr.endswith(")"):
                lines[line_no - 1] = f"{indent}print({expr})"
                cand_code = newline_sep.join(lines)
                try:
                    ast.parse(cand_code)
                    return cand_code
                except Exception:
                    lines[line_no - 1] = target_line

    # (d) '=' used instead of '==' in condition
    if "maybe you meant '=='" in msg or "invalid syntax" in msg:
        if line_no and 1 <= line_no <= len(lines):
            target_line = lines[line_no - 1]
            stripped = target_line.strip()
            if any(stripped.startswith(kw) for kw in ("if ", "elif ", "while ")):
                fixed_line = re.sub(r'(?<![<>=!])=(?![=])', '==', target_line)
                if fixed_line != target_line:
                    lines[line_no - 1] = fixed_line
                    cand_code = newline_sep.join(lines)
                    try:
                        ast.parse(cand_code)
                        return cand_code
                    except Exception:
                        lines[line_no - 1] = target_line

    # (e) 'Perhaps you forgot a comma?'
    if "perhaps you forgot a comma" in msg or "invalid syntax" in msg:
        if line_no and 1 <= line_no <= len(lines):
            target_line = lines[line_no - 1]
            fixed_line = re.sub(r'(\d+|[a-zA-Z_][a-zA-Z0-9_]*|\'[^\']*\'|"[^"]*")\s+(\d+|[a-zA-Z_][a-zA-Z0-9_]*|\'[^\']*\'|"[^"]*")', r'\1, \2', target_line)
            if fixed_line != target_line:
                lines[line_no - 1] = fixed_line
                cand_code = newline_sep.join(lines)
                try:
                    ast.parse(cand_code)
                    return cand_code
                except Exception:
                    lines[line_no - 1] = target_line

    return None


def _fix_unclosed_brackets(code_str):
    """Counts unmatched brackets using tokenizer and appends closers."""
    matching = {')': '(', ']': '[', '}': '{'}
    closers = {'(': ')', '[': ']', '{': '}'}
    stack = []

    try:
        for tok in tokenize.tokenize(io.BytesIO(code_str.encode('utf-8')).readline):
            if tok.exact_type in (tokenize.LPAR, tokenize.LSQB, tokenize.LBRACE):
                stack.append((tok.string, tok.start[0]))
            elif tok.exact_type in (tokenize.RPAR, tokenize.RSQB, tokenize.RBRACE):
                if stack and stack[-1][0] == matching.get(tok.string):
                    stack.pop()
    except Exception:
        pass

    if not stack:
        lines = code_str.splitlines()
        for lineno, line in enumerate(lines, 1):
            s_clean = re.sub(r"#[^\n]*", "", line)
            s_clean = re.sub(r"'''[\s\S]*?'''|\"\"\"[\s\S]*?\"\"\"|'[^'\\]*(?:\\.[^'\\]*)*'|\"[^\"\\]*(?:\\.[^\"\\]*)*\"", "", s_clean)
            for ch in s_clean:
                if ch in '([{':
                    stack.append((ch, lineno))
                elif ch in ')]}':
                    if stack and stack[-1][0] == matching.get(ch):
                        stack.pop()

    if stack:
        closing_str = "".join(closers[ch] for ch, _ in reversed(stack))
        newline_sep = "\r\n" if "\r\n" in code_str else "\n"
        lines = code_str.splitlines()

        open_line = stack[-1][1]
        if open_line and 1 <= open_line <= len(lines):
            target_idx = open_line - 1
        else:
            target_idx = len(lines) - 1
            for i in range(len(lines) - 1, -1, -1):
                s = lines[i].strip()
                if s and not s.startswith("#"):
                    target_idx = i
                    break

        if 0 <= target_idx < len(lines):
            target_line = lines[target_idx]
            if "#" in target_line:
                code_p, comm_p = target_line.split("#", 1)
                lines[target_idx] = f"{code_p.rstrip()}{closing_str}  #{comm_p}"
            else:
                lines[target_idx] = lines[target_idx] + closing_str
            return newline_sep.join(lines)
        return code_str + closing_str
    return None


def _fix_file_exists_mkdir(err_type, err_msg, line_no, code_str):
    """Rewrites os.mkdir(x) to os.makedirs(x, exist_ok=True)."""
    if err_type != "FileExistsError":
        return None
    if not line_no or line_no <= 0:
        return None
    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    if line_no > len(lines):
        return None

    target_idx = line_no - 1
    target_line = lines[target_idx]

    if "os.mkdir" in target_line:
        fixed_line = re.sub(r'\bos\.mkdir\((.*?)\)', r'os.makedirs(\1, exist_ok=True)', target_line)
        if fixed_line != target_line:
            lines[target_idx] = fixed_line
            return newline_sep.join(lines)
    return None


def _fix_json_decode_empty(err_type, err_msg, line_no, code_str):
    """Defensive guard for json.loads(S) with empty string."""
    if err_type not in ("json.decoder.JSONDecodeError", "JSONDecodeError") and "Expecting value" not in str(err_msg):
        return None
    if not line_no or line_no <= 0:
        return None
    newline_sep = "\r\n" if "\r\n" in code_str else "\n"
    lines = code_str.splitlines()
    if line_no > len(lines):
        return None

    target_idx = line_no - 1
    target_line = lines[target_idx]

    if "json.loads" not in target_line:
        return None

    m = re.search(r'json\.loads\(\s*([^)]+)\s*\)', target_line)
    if not m:
        return None

    arg_expr = m.group(1).strip()
    is_empty_or_whitespace = False

    if arg_expr in ('""', "''", 'f""', "f''", 'r""', "r''") or (arg_expr.startswith(('"', "'")) and not arg_expr.strip('"\' ')):
        is_empty_or_whitespace = True
    else:
        try:
            tree = ast.parse(code_str)
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for t in node.targets:
                        if isinstance(t, ast.Name) and t.id == arg_expr:
                            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str) and not node.value.value.strip():
                                is_empty_or_whitespace = True
                                break
        except Exception:
            pass

    if not is_empty_or_whitespace:
        return None

    guard_expr = f"(json.loads({arg_expr}) if {arg_expr}.strip() else None)"
    fixed_line = target_line[:m.start()] + guard_expr + target_line[m.end():]
    lines[target_idx] = fixed_line
    return newline_sep.join(lines)


def _guard_zerodivision(line):
    """Rewrites single division/mod on line as (a / b if b != 0 else 0)."""
    indent = line[:len(line) - len(line.lstrip())]
    stripped = line.strip()
    comment = ""
    if "#" in stripped:
        parts = stripped.split("#", 1)
        stripped = parts[0].strip()
        comment = " # " + parts[1].strip()
    try:
        tree = ast.parse(stripped)
    except Exception:
        return None
    div_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.BinOp) and isinstance(n.op, (ast.Div, ast.FloorDiv, ast.Mod))]
    if len(div_nodes) == 1:
        node = div_nodes[0]
        class DivReplacer(ast.NodeTransformer):
            def visit_BinOp(self, n):
                if n is node:
                    left_code = ast.unparse(n.left)
                    right_code = ast.unparse(n.right)
                    op_code = '/' if isinstance(n.op, ast.Div) else ('//' if isinstance(n.op, ast.FloorDiv) else '%')
                    ifexp_tree = ast.parse(f'({left_code} {op_code} {right_code} if {right_code} != 0 else 0)', mode='eval')
                    return ifexp_tree.body
                return self.generic_visit(n)
        new_tree = DivReplacer().visit(tree)
        ast.fix_missing_locations(new_tree)
        return indent + ast.unparse(new_tree) + comment
    return None


def _guard_indexerror(line):
    """Rewrites single subscript on line as (seq[i] if -len(seq) <= i < len(seq) else None)."""
    indent = line[:len(line) - len(line.lstrip())]
    stripped = line.strip()
    comment = ""
    if "#" in stripped:
        parts = stripped.split("#", 1)
        stripped = parts[0].strip()
        comment = " # " + parts[1].strip()
    try:
        tree = ast.parse(stripped)
    except Exception:
        return None
    sub_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.Subscript) and isinstance(n.ctx, ast.Load)]
    if len(sub_nodes) == 1:
        node = sub_nodes[0]
        if isinstance(node.value, (ast.Name, ast.Attribute)):
            class IndexReplacer(ast.NodeTransformer):
                def visit_Subscript(self, n):
                    if n is node:
                        seq_code = ast.unparse(n.value)
                        idx_code = ast.unparse(n.slice)
                        ifexp_tree = ast.parse(f'({seq_code}[{idx_code}] if -len({seq_code}) <= {idx_code} < len({seq_code}) else None)', mode='eval')
                        return ifexp_tree.body
                    return self.generic_visit(n)
            new_tree = IndexReplacer().visit(tree)
            ast.fix_missing_locations(new_tree)
            return indent + ast.unparse(new_tree) + comment
    return None


def _guard_keyerror(line):
    """Rewrites d[k] on line as d.get(k) for plain read, including nested lookups."""
    indent = line[:len(line) - len(line.lstrip())]
    stripped = line.strip()
    comment = ""
    if "#" in stripped:
        parts = stripped.split("#", 1)
        stripped = parts[0].strip()
        comment = " # " + parts[1].strip()
    try:
        tree = ast.parse(stripped)
    except Exception:
        return None
    sub_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.Subscript) and isinstance(n.ctx, ast.Load)]
    if sub_nodes:
        # Pick the outermost subscript (ast.walk visits top-down)
        node = sub_nodes[0]
        class KeyReplacer(ast.NodeTransformer):
            def visit_Subscript(self, n):
                if n is node:
                    dict_code = ast.unparse(n.value)
                    key_code = ast.unparse(n.slice)
                    call_tree = ast.parse(f'{dict_code}.get({key_code})', mode='eval')
                    return call_tree.body
                return self.generic_visit(n)
        new_tree = KeyReplacer().visit(tree)
        ast.fix_missing_locations(new_tree)
        return indent + ast.unparse(new_tree) + comment
    return None


_default_explainer = NLPExplainer()

def generate_explanation(ir, code=""):
    """Module-level alias for NLPExplainer.explain."""
    return _default_explainer.explain(ir, code)

def generate_fixed_code(ir, code=""):
    """Module-level alias for NLPExplainer.generate_fixed_code."""
    return _default_explainer.generate_fixed_code(ir, code)

