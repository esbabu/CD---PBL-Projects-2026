"""tests_dual_key.py - Unit & Integration Tests for Banking "Four-Eyes" Dual-Key Authorization.

Tests:
1. Automated Safety Auditor Key (Key A) issuance for clean code.
2. Safety Auditor Key refusal for code containing static security violations or trojans.
3. Human Operator Key (Key B) issuance and HMAC verification.
4. Dual-Key clearance when BOTH keys are valid and match code content.
5. Rejection when Key A is missing (Human approved, but Auditor rejected).
6. Rejection when Key B is missing (Auditor passed, but Human operator did not authorize).
7. Rejection when fixed code is altered after keys were minted (tamper resistance).
8. Rejection of expired keys.
9. Flask endpoints for Dual-Key attestation, verification, and /api/agent/approve integration.
"""

import os
import tempfile
import time
import unittest

from security import audit_log, dual_key
import agent_proposals
import app as flask_app


class TestDualKeyCore(unittest.TestCase):
    """Core cryptographic and policy tests for security/dual_key.py."""

    def test_auditor_key_granted_for_clean_code(self):
        """Safety auditor grants Key A for clean bugfix."""
        orig = "def add(a, b): return a - b"
        fixed = "def add(a, b): return a + b"
        ok, key_a, report = dual_key.generate_auditor_key(
            proposal_id="prop_clean_001",
            original_code=orig,
            fixed_code=fixed
        )
        self.assertTrue(ok)
        self.assertIsNotNone(key_a)
        self.assertTrue(key_a.startswith("KEY_A:"))
        self.assertTrue(report["static_scan_passed"])
        self.assertTrue(report["blast_radius_passed"])

    def test_auditor_key_refused_for_malicious_code(self):
        """Safety auditor refuses Key A when code contains a command execution sink."""
        orig = "x = 1"
        fixed = "import os\nos.system('echo malicious')\nx = 1"
        ok, key_a, report = dual_key.generate_auditor_key(
            proposal_id="prop_bad_001",
            original_code=orig,
            fixed_code=fixed
        )
        self.assertFalse(ok)
        self.assertIsNone(key_a)
        self.assertFalse(report["static_scan_passed"])
        self.assertTrue(len(report["findings"]) > 0)

    def test_operator_key_minting(self):
        """Human operator mints Key B with valid cryptographic HMAC."""
        fixed = "def f(): return 42"
        key_b = dual_key.generate_operator_key(
            proposal_id="prop_op_001",
            fixed_code=fixed,
            operator_id="admin_alice"
        )
        self.assertTrue(key_b.startswith("KEY_B:"))
        ok, msg = dual_key.verify_key_b(key_b, "prop_op_001", fixed)
        self.assertTrue(ok)
        self.assertIn("admin_alice", msg)

    def test_dual_key_clearance_success(self):
        """When BOTH Key A and Key B turn in the lock, clearance is granted."""
        orig = "x = 10"
        fixed = "x = 20"
        prop_id = "prop_both_001"

        ok_a, key_a, _ = dual_key.generate_auditor_key(prop_id, orig, fixed)
        self.assertTrue(ok_a)
        key_b = dual_key.generate_operator_key(prop_id, fixed, operator_id="lead_reviewer")

        ok, msg, voucher = dual_key.verify_dual_key_authorization(
            proposal_id=prop_id,
            fixed_code=fixed,
            key_a=key_a,
            key_b=key_b,
            log_audit=False
        )
        self.assertTrue(ok)
        self.assertIsNotNone(voucher)
        self.assertEqual(voucher["status"], "DUAL_KEY_AUTHORIZED")
        self.assertEqual(voucher["proposal_id"], prop_id)

    def test_rejection_when_code_tampered_after_key_minting(self):
        """Modifying code after keys were minted invalidates dual-key clearance."""
        orig = "x = 10"
        fixed_orig = "x = 20"
        fixed_tampered = "x = 20\n# secretly injected change"
        prop_id = "prop_tamper_001"

        ok_a, key_a, _ = dual_key.generate_auditor_key(prop_id, orig, fixed_orig)
        key_b = dual_key.generate_operator_key(prop_id, fixed_orig, operator_id="reviewer")

        # Attempt to authorize the tampered code with the old keys
        ok, msg, voucher = dual_key.verify_dual_key_authorization(
            proposal_id=prop_id,
            fixed_code=fixed_tampered,
            key_a=key_a,
            key_b=key_b,
            log_audit=False
        )
        self.assertFalse(ok)
        self.assertIsNone(voucher)
        self.assertIn("hash mismatch", msg.lower())

    def test_rejection_of_expired_key(self):
        """Expired keys are rejected."""
        orig = "x = 10"
        fixed = "x = 20"
        prop_id = "prop_expired_001"

        # Generate Key A that expired 1 second ago
        ok_a, key_a, _ = dual_key.generate_auditor_key(prop_id, orig, fixed, ttl=-1.0)
        key_b = dual_key.generate_operator_key(prop_id, fixed, ttl=300.0)

        ok, msg, voucher = dual_key.verify_dual_key_authorization(
            proposal_id=prop_id,
            fixed_code=fixed,
            key_a=key_a,
            key_b=key_b,
            log_audit=False
        )
        self.assertFalse(ok)
        self.assertIn("expired", msg.lower())


class TestDualKeyAPIAndApproval(unittest.TestCase):
    """Integration tests for Dual-Key Flask endpoints and proposal approvals."""

    def setUp(self):
        flask_app.app.config["TESTING"] = True
        self.client = flask_app.app.test_client()
        agent_proposals.get_global_proposals().clear()

    def test_dual_key_attest_endpoint(self):
        """POST /api/security/dual-key/attest generates Key A for clean proposal."""
        resp = self.client.post("/api/security/dual-key/attest", json={
            "proposal_id": "api_test_001",
            "original_code": "def run(): pass",
            "fixed_code": "def run(): return True"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["status"], "success")
        self.assertIn("key_a", data)

    def test_dual_key_operator_endpoint(self):
        """POST /api/security/dual-key/operator-key mints Key B."""
        resp = self.client.post("/api/security/dual-key/operator-key", json={
            "proposal_id": "api_test_002",
            "fixed_code": "print(1)",
            "operator_id": "auditor_bob"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["status"], "success")
        self.assertIn("key_b", data)

    def test_agent_approve_with_dual_key_enforcement(self):
        """POST /api/agent/approve succeeds when valid Key A and Key B are presented."""
        prop = agent_proposals.get_global_proposals().create(
            original_code="val = 1",
            fixed_code="val = 2",
            filename="dual_key_test_file.py"
        )
        prop_id = prop["id"]

        # Generate both keys
        _, key_a, _ = dual_key.generate_auditor_key(prop_id, "val = 1", "val = 2")
        key_b = dual_key.generate_operator_key(prop_id, "val = 2", operator_id="operator_charlie")

        # Approve with both keys
        resp = self.client.post("/api/agent/approve", json={
            "proposal_id": prop_id,
            "key_a": key_a,
            "key_b": key_b
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data.get("status"), "approved")

        # Clean up created file
        target_fn = os.path.join(agent_proposals.WORKSPACE_DIR, "dual_key_test_file_fixed.py")
        if os.path.exists(target_fn):
            os.remove(target_fn)

    def test_agent_approve_fails_with_invalid_dual_key(self):
        """POST /api/agent/approve fails with 403 when presented with forged or invalid keys."""
        prop = agent_proposals.get_global_proposals().create(
            original_code="val = 1",
            fixed_code="val = 2",
            filename="dual_key_test_file2.py"
        )
        prop_id = prop["id"]

        # Present forged Key A
        resp = self.client.post("/api/agent/approve", json={
            "proposal_id": prop_id,
            "key_a": "KEY_A:fake_id:fake_hash:9999999999:fake_sig",
            "key_b": "KEY_B:fake_id:fake_hash:op:9999999999:fake_sig"
        })
        self.assertEqual(resp.status_code, 403)
        data = resp.get_json()
        self.assertTrue(data.get("dual_key_violation"))


if __name__ == "__main__":
    unittest.main()
