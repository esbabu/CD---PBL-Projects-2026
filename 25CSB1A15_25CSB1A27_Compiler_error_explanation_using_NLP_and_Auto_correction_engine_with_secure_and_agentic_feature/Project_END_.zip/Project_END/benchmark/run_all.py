"""benchmark/run_all.py – Offline benchmark and report runner with zero network calls.
"""

import argparse
import os
import subprocess
import sys

_WORKSPACE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    os.environ.setdefault("LLM_BUDGET_ENFORCE", "1")
    parser = argparse.ArgumentParser(description="TOC_PROJECT Master Benchmark Runner")
    parser.add_argument("--offline", action="store_true", default=True, help="Run full 580 offline benchmark")
    parser.add_argument("--out", type=str, default=None, help="Output JSONL path")
    args = parser.parse_args()

    print("=== Running Complete TOC_PROJECT Master Benchmark Pipeline ===")
    
    # 1. Run offline benchmark
    cmd_bench = [
        sys.executable,
        os.path.join(_WORKSPACE, "benchmark", "run_benchmark.py"),
        "--mode", "offline"
    ]
    if args.out:
        cmd_bench.extend(["--out", args.out])
        
    env = os.environ.copy()
    env["LLM_DISABLED"] = "1"
    
    res = subprocess.run(cmd_bench, env=env, cwd=_WORKSPACE)
    if res.returncode != 0:
        print("Error during benchmark execution.")
        sys.exit(res.returncode)

    # 2. Regenerate RESULTS.md
    cmd_rep = [
        sys.executable,
        os.path.join(_WORKSPACE, "benchmark", "make_report.py")
    ]
    res_rep = subprocess.run(cmd_rep, env=env, cwd=_WORKSPACE)
    if res_rep.returncode != 0:
        print("Error generating RESULTS.md.")
        sys.exit(res_rep.returncode)

    print("Master benchmark run completed successfully.")


if __name__ == "__main__":
    main()
