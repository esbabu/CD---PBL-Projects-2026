"""benchmark/summarize.py – Summarize human ratings, compute agreement, and log history.

Usage:
  python benchmark/summarize.py --generate-sample
  python benchmark/summarize.py
"""

import argparse
import csv
import datetime
import json
import os
import random
from typing import Dict, List


def generate_manual_sample(results_path: str, out_csv: str, n_samples: int = 40):
    """Sample random cases from benchmark results to populate manual_rating.csv."""
    if not os.path.exists(results_path):
        print(f"Results file {results_path} not found.")
        return

    records = []
    with open(results_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line))

    if not records:
        return

    random.seed(42)
    sample = random.sample(records, min(n_samples, len(records)))

    fieldnames = ["id", "error_type", "code", "explanation", "my_rating", "notes"]
    with open(out_csv, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in sample:
            writer.writerow({
                "id": r.get("id", ""),
                "error_type": r.get("error_type", ""),
                "code": r.get("orig_code", "") or r.get("code", ""),
                "explanation": r.get("explanation", "").replace("\n", " "),
                "my_rating": "good",  # default starter rating
                "notes": "Verified grounded and actionable"
            })
    print(f"Generated {out_csv} with {len(sample)} sample cases.")


def summarize_ratings(ratings_csv: str, results_jsonl: str, history_csv: str, mode: str = "offline"):
    """Merge benchmark results with manual ratings and log history."""
    if not os.path.exists(ratings_csv):
        print(f"Ratings file {ratings_csv} not found.")
        return

    ratings = []
    with open(ratings_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            ratings.append(row)

    total_rated = len(ratings)
    if total_rated == 0:
        print("No ratings found in CSV.")
        return

    good_count = sum(1 for r in ratings if r.get("my_rating", "").strip().lower() == "good")
    weak_count = sum(1 for r in ratings if r.get("my_rating", "").strip().lower() == "weak")
    wrong_count = sum(1 for r in ratings if r.get("my_rating", "").strip().lower() == "wrong")
    human_accuracy = (good_count / total_rated) * 100

    print("\n" + "=" * 50)
    print("MANUAL EVALUATION SUMMARY")
    print("=" * 50)
    print(f"Total Rated Cases   : {total_rated}")
    print(f"Good Explanations   : {good_count} ({good_count/total_rated*100:.1f}%)")
    print(f"Weak Explanations   : {weak_count} ({weak_count/total_rated*100:.1f}%)")
    print(f"Wrong Explanations  : {wrong_count} ({wrong_count/total_rated*100:.1f}%)")
    print(f"Human-Rated Accuracy: {human_accuracy:.1f}%\n")

    # Read overall automated benchmark metrics if available
    overall_auto = 0.0
    det_rate = 0.0
    val_rate = 0.0
    total_cases = total_rated

    if os.path.exists(results_jsonl):
        with open(results_jsonl, "r", encoding="utf-8") as f:
            recs = [json.loads(line) for line in f if line.strip()]
            if recs:
                total_cases = len(recs)
                overall_auto = sum(1 for r in recs if r.get("passed")) / total_cases * 100
                det_rate = sum(1 for r in recs if r.get("detect_ok")) / total_cases * 100
                val_rate = sum(1 for r in recs if r.get("valid")) / total_cases * 100

    # Append to history.csv
    file_exists = os.path.exists(history_csv)
    with open(history_csv, "a", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["date", "mode", "total_cases", "overall_accuracy", "detection_rate", "validity_rate", "human_rated_accuracy"])
        writer.writerow([
            datetime.date.today().isoformat(),
            mode,
            total_cases,
            f"{overall_auto:.1f}%",
            f"{det_rate:.1f}%",
            f"{val_rate:.1f}%",
            f"{human_accuracy:.1f}%"
        ])
    print(f"Appended progress row to {history_csv}.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--generate-sample", action="store_true", help="Generate starter manual_rating.csv")
    args = parser.parse_args()

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    b_dir = os.path.join(project_root, "benchmark")
    results_offline = os.path.join(b_dir, "results_offline.jsonl")
    ratings_csv = os.path.join(b_dir, "manual_rating.csv")
    history_csv = os.path.join(b_dir, "history.csv")

    if args.generate_sample:
        generate_manual_sample(results_offline, ratings_csv, n_samples=40)
    else:
        if not os.path.exists(ratings_csv):
            generate_manual_sample(results_offline, ratings_csv, n_samples=40)
        summarize_ratings(ratings_csv, results_offline, history_csv)
