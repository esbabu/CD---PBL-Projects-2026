"""benchmark/novel_cases.py – 12 verified novel error cases outside the offline guide.

Each case specifies:
- error_type (dotted or simple name)
- orig_code (raises the expected error in sandbox)
- fixed_code (executes cleanly with exit code 0)
"""

NOVEL_CASES = [
    {
        "id": "novel_01_re_error",
        "error_type": "re.PatternError",
        "orig_code": "import re\npattern = '['\nre.compile(pattern)",
        "fixed_code": "import re\npattern = r'\\['\nre.compile(pattern)",
        "split": "novel",
        "skeleton_id": "novel_re"
    },
    {
        "id": "novel_02_struct_error",
        "error_type": "struct.error",
        "orig_code": "import struct\nstruct.unpack('i', b'12')",
        "fixed_code": "import struct\nstruct.unpack('i', b'1234')",
        "split": "novel",
        "skeleton_id": "novel_struct"
    },
    {
        "id": "novel_03_zipfile_badzip",
        "error_type": "zipfile.BadZipFile",
        "orig_code": "import zipfile, io\nzipfile.ZipFile(io.BytesIO(b'not_a_valid_zip_archive'))",
        "fixed_code": "import zipfile, io\nbuf = io.BytesIO()\nzf = zipfile.ZipFile(buf, 'w')\nzf.close()",
        "split": "novel",
        "skeleton_id": "novel_zipfile"
    },
    {
        "id": "novel_04_csv_error",
        "error_type": "csv.Error",
        "orig_code": "import csv\nreader = csv.reader(['\"unclosed_quote'], strict=True)\nlist(reader)",
        "fixed_code": "import csv\nreader = csv.reader(['\"closed_quote\"'], strict=True)\nlist(reader)",
        "split": "novel",
        "skeleton_id": "novel_csv"
    },
    {
        "id": "novel_05_queue_empty",
        "error_type": "queue.Empty",
        "orig_code": "import queue\nq = queue.Queue()\nq.get_nowait()",
        "fixed_code": "import queue\nq = queue.Queue()\nq.put(42)\nq.get_nowait()",
        "split": "novel",
        "skeleton_id": "novel_queue"
    },
    {
        "id": "novel_06_decimal_invalidop",
        "error_type": "decimal.InvalidOperation",
        "orig_code": "import decimal\ndecimal.Decimal('invalid_number_string')",
        "fixed_code": "import decimal\ndecimal.Decimal('123.456')",
        "split": "novel",
        "skeleton_id": "novel_decimal"
    },
    {
        "id": "novel_07_configparser_nosection",
        "error_type": "configparser.NoSectionError",
        "orig_code": "import configparser\ncfg = configparser.ConfigParser()\ncfg.get('missing_section', 'key')",
        "fixed_code": "import configparser\ncfg = configparser.ConfigParser()\ncfg.add_section('missing_section')\ncfg.set('missing_section', 'key', 'value')\ncfg.get('missing_section', 'key')",
        "split": "novel",
        "skeleton_id": "novel_configparser"
    },
    {
        "id": "novel_08_tarfile_readerror",
        "error_type": "tarfile.ReadError",
        "orig_code": "import tarfile, io\ntarfile.open(fileobj=io.BytesIO(b'not_a_valid_tar_stream'))",
        "fixed_code": "import tarfile, io\nbuf = io.BytesIO()\ntf = tarfile.open(fileobj=buf, mode='w')\ntf.close()",
        "split": "novel",
        "skeleton_id": "novel_tarfile"
    },
    {
        "id": "novel_09_xml_parseerror",
        "error_type": "xml.etree.ElementTree.ParseError",
        "orig_code": "import xml.etree.ElementTree as ET\nET.fromstring('<root><unclosed>')",
        "fixed_code": "import xml.etree.ElementTree as ET\nET.fromstring('<root><closed/></root>')",
        "split": "novel",
        "skeleton_id": "novel_xml"
    },
    {
        "id": "novel_10_binascii_error",
        "error_type": "binascii.Error",
        "orig_code": "import binascii\nbinascii.a2b_base64('invalid base64 characters!!!')",
        "fixed_code": "import binascii\nbinascii.a2b_base64('aGVsbG8gd29ybGQ=')",
        "split": "novel",
        "skeleton_id": "novel_binascii"
    },
    {
        "id": "novel_11_pickle_unpickling",
        "error_type": "pickle.UnpicklingError",
        "orig_code": "import pickle\npickle.loads(b'not_a_valid_pickle_data_stream')",
        "fixed_code": "import pickle\npickle.loads(pickle.dumps({'status': 'ok'}))",
        "split": "novel",
        "skeleton_id": "novel_pickle"
    },
    {
        "id": "novel_12_zlib_error",
        "error_type": "zlib.error",
        "orig_code": "import zlib\nzlib.decompress(b'corrupted_compressed_data')",
        "fixed_code": "import zlib\nzlib.decompress(zlib.compress(b'clean compressed data stream'))",
        "split": "novel",
        "skeleton_id": "novel_zlib"
    }
]
