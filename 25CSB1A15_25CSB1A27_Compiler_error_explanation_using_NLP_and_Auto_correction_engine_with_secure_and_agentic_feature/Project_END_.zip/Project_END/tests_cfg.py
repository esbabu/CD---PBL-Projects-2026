"""tests_cfg.py – Test suite for cfg_engine and the Flask CFG API routes.

Covers:
  - Linear code has complexity 1
  - if/else raises complexity to >= 2
  - Each if/for/while contributes +1 to complexity
  - CFG edge count correct for simple if/else
  - Mermaid output contains 'flowchart'
  - Heatmap colour codes match spec thresholds
  - Flask API /api/cfg/analyze and /api/cfg/complexity return 200 + expected fields
  - Edge cases: empty code, single function, nested functions
"""

import ast
import json
import pytest

import cfg_engine
from cfg_engine import (
    build_cfg,
    compute_complexity,
    cfg_to_mermaid,
    analyze_code,
    _complexity_label,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _complexity(code: str) -> int:
    return compute_complexity(code)["overall_complexity"]


# ---------------------------------------------------------------------------
# 1. Linear code → complexity == 1
# ---------------------------------------------------------------------------

class TestLinearCode:
    def test_simple_linear(self):
        code = "x = 1\ny = 2\nz = x + y"
        assert _complexity(code) == 1

    def test_single_assignment(self):
        code = "result = 42"
        assert _complexity(code) == 1

    def test_function_no_branches(self):
        code = "def add(a, b):\n    return a + b"
        c = compute_complexity(code)
        assert c["functions"][0]["complexity"] == 1

    def test_function_linear_body(self):
        code = "def foo():\n    x = 1\n    y = 2\n    return x + y"
        c = compute_complexity(code)
        assert c["functions"][0]["complexity"] == 1


# ---------------------------------------------------------------------------
# 2. if/else raises complexity >= 2
# ---------------------------------------------------------------------------

class TestIfElseComplexity:
    def test_if_no_else(self):
        code = "if True:\n    x = 1"
        assert _complexity(code) >= 2

    def test_if_else(self):
        code = "if True:\n    x = 1\nelse:\n    x = 2"
        assert _complexity(code) >= 2

    def test_if_elif_else(self):
        code = (
            "if x == 1:\n    a = 1\n"
            "elif x == 2:\n    a = 2\n"
            "else:\n    a = 3"
        )
        assert _complexity(code) >= 3

    def test_function_with_if(self):
        code = "def f(x):\n    if x > 0:\n        return x\n    return -x"
        c = compute_complexity(code)
        assert c["functions"][0]["complexity"] >= 2


# ---------------------------------------------------------------------------
# 3. Each if/for/while adds +1 to complexity count
# ---------------------------------------------------------------------------

class TestDecisionNodeCount:
    def test_one_if(self):
        code = "if x:\n    pass"
        assert _complexity(code) == 2  # base 1 + 1

    def test_two_ifs(self):
        code = "if a:\n    pass\nif b:\n    pass"
        assert _complexity(code) == 3  # 1 + 2

    def test_one_for(self):
        code = "for i in range(10):\n    pass"
        assert _complexity(code) == 2

    def test_one_while(self):
        code = "while True:\n    break"
        assert _complexity(code) == 2

    def test_if_plus_for(self):
        code = "if x:\n    pass\nfor i in range(5):\n    pass"
        assert _complexity(code) == 3

    def test_nested_if_in_for(self):
        code = "for i in range(10):\n    if i > 5:\n        pass"
        assert _complexity(code) == 3  # 1 for + 1 if + base 1

    def test_per_function_complexity(self):
        code = (
            "def a():\n    if x:\n        pass\n\n"
            "def b():\n    for i in range(5):\n        pass\n"
        )
        c = compute_complexity(code)
        names = {f["name"]: f["complexity"] for f in c["functions"]}
        assert names["a"] == 2
        assert names["b"] == 2


# ---------------------------------------------------------------------------
# 4. CFG edge count for simple if/else
# ---------------------------------------------------------------------------

class TestCFGEdges:
    def test_if_else_edge_count(self):
        """Entry → decision, decision → true-branch, decision → false-branch,
        true-branch → merge, false-branch → merge  =  5 edges minimum."""
        code = "if x:\n    y = 1\nelse:\n    y = 2"
        cfg = build_cfg(code)
        assert len(cfg.edges) >= 3

    def test_if_no_else_edge_count(self):
        """Entry, decision → true, decision → merge, true → merge = 3+ edges."""
        code = "if x:\n    y = 1"
        cfg = build_cfg(code)
        assert len(cfg.edges) >= 2

    def test_linear_has_edges(self):
        """Even linear code with an entry block should produce at least 0 edges
        (single-block – no edges needed)."""
        code = "x = 1"
        cfg = build_cfg(code)
        # single-block linear code: may have 0 internal edges
        assert isinstance(cfg.edges, list)

    def test_for_loop_back_edge(self):
        """A for loop should produce a back-edge to the header."""
        code = "for i in range(10):\n    pass"
        cfg = build_cfg(code)
        assert len(cfg.edges) >= 2

    def test_function_if_else_edges(self):
        code = "def f(x):\n    if x > 0:\n        return x\n    return -x"
        cfg = build_cfg(code)
        # decision → true-return, decision → false-block = at least 3 edges
        assert len(cfg.edges) >= 3

    def test_entry_block_exists(self):
        code = "x = 1"
        cfg = build_cfg(code)
        assert cfg.entry_block == 0

    def test_edges_reference_valid_block_ids(self):
        code = "if a:\n    b = 1\nelse:\n    b = 2\nc = b + 1"
        cfg = build_cfg(code)
        all_ids = {blk.id for blk in cfg.blocks}
        for src, dst in cfg.edges:
            assert src in all_ids, f"src {src} not in blocks"
            assert dst in all_ids, f"dst {dst} not in blocks"


# ---------------------------------------------------------------------------
# 5. Mermaid diagram generation
# ---------------------------------------------------------------------------

class TestMermaidDiagram:
    def test_contains_flowchart(self):
        code = "if x:\n    y = 1"
        cfg = build_cfg(code)
        md = cfg_to_mermaid(cfg)
        assert "flowchart" in md

    def test_contains_arrow(self):
        code = "if x:\n    y = 1\nelse:\n    y = 2"
        cfg = build_cfg(code)
        md = cfg_to_mermaid(cfg)
        assert "-->" in md

    def test_decision_node_shape(self):
        """Decision blocks should use the {} Mermaid shape."""
        code = "if cond:\n    pass"
        cfg = build_cfg(code)
        md = cfg_to_mermaid(cfg)
        assert "{" in md

    def test_analyze_code_mermaid(self):
        code = "def f(x):\n    if x > 0:\n        return x\n    return -x"
        result = analyze_code(code)
        assert "flowchart" in result["mermaid_diagram"]

    def test_mermaid_no_unescaped_quotes(self):
        """Node labels should not contain unescaped double quotes inside."""
        code = 'x = "hello"\nif x:\n    pass'
        cfg = build_cfg(code)
        md = cfg_to_mermaid(cfg)
        # Mermaid labels are wrapped in double quotes; inner quotes are single-quoted.
        assert 'flowchart' in md


# ---------------------------------------------------------------------------
# 6. Heatmap colour codes
# ---------------------------------------------------------------------------

class TestHeatmapColors:
    def test_low_color(self):
        label, color = _complexity_label(1)
        assert label == "LOW"
        assert color == "#4CAF50"

    def test_low_boundary(self):
        label, color = _complexity_label(5)
        assert label == "LOW"
        assert color == "#4CAF50"

    def test_medium_color(self):
        label, color = _complexity_label(6)
        assert label == "MEDIUM"
        assert color == "#FF9800"

    def test_medium_boundary(self):
        label, color = _complexity_label(10)
        assert label == "MEDIUM"
        assert color == "#FF9800"

    def test_high_color(self):
        label, color = _complexity_label(11)
        assert label == "HIGH"
        assert color == "#F44336"

    def test_high_boundary(self):
        label, color = _complexity_label(20)
        assert label == "HIGH"
        assert color == "#F44336"

    def test_very_high_color(self):
        label, color = _complexity_label(21)
        assert label == "VERY_HIGH"
        assert color == "#B71C1C"

    def test_very_high_large(self):
        label, color = _complexity_label(100)
        assert label == "VERY_HIGH"
        assert color == "#B71C1C"

    def test_heatmap_in_analyze(self):
        # Build code with complexity 6+ to get MEDIUM.
        lines = ["def f():"]
        for i in range(6):
            lines.append(f"    if cond{i}:")
            lines.append(f"        pass")
        code = "\n".join(lines)
        result = analyze_code(code)
        fn = result["functions"][0]
        assert fn["complexity"] >= 6
        assert fn["complexity_label"] == "MEDIUM"
        assert fn["color"] == "#FF9800"


# ---------------------------------------------------------------------------
# 7. Flask API routes
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def client():
    import app as flask_app
    flask_app.app.config["TESTING"] = True
    with flask_app.app.test_client() as c:
        yield c


class TestFlaskAPI:
    def test_cfg_analyze_200(self, client):
        resp = client.post(
            "/api/cfg/analyze",
            json={"code": "def f(x):\n    if x > 0:\n        return x\n    return -x"},
        )
        assert resp.status_code == 200

    def test_cfg_analyze_has_expected_fields(self, client):
        resp = client.post(
            "/api/cfg/analyze",
            json={"code": "if x:\n    y = 1"},
        )
        data = resp.get_json()
        for key in ("functions", "overall_complexity", "cfg", "mermaid_diagram",
                    "decision_points", "complexity_summary"):
            assert key in data, f"Missing key: {key}"

    def test_cfg_analyze_bad_body(self, client):
        # Flask may return 400 (bad JSON) or 415 (unsupported media type)
        # when the request body is not valid JSON — both are acceptable errors.
        resp = client.post("/api/cfg/analyze", data="not json",
                           content_type="text/plain")
        assert resp.status_code in (400, 415)

    def test_cfg_analyze_non_string_code(self, client):
        resp = client.post("/api/cfg/analyze", json={"code": 123})
        assert resp.status_code == 400

    def test_cfg_complexity_200(self, client):
        resp = client.post(
            "/api/cfg/complexity",
            json={"code": "def f():\n    if x:\n        pass"},
        )
        assert resp.status_code == 200

    def test_cfg_complexity_has_expected_fields(self, client):
        resp = client.post(
            "/api/cfg/complexity",
            json={"code": "def g(x):\n    for i in range(x):\n        pass"},
        )
        data = resp.get_json()
        assert "functions" in data
        assert "overall_complexity" in data
        assert "complexity_summary" in data

    def test_cfg_complexity_bad_body(self, client):
        resp = client.post("/api/cfg/complexity", json=42)
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# 8. Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_string(self):
        result = analyze_code("")
        assert result["overall_complexity"] == 1
        assert result["functions"] == []
        assert "flowchart" in result["mermaid_diagram"]

    def test_whitespace_only(self):
        result = analyze_code("   \n\n  ")
        assert result["overall_complexity"] == 1

    def test_syntax_error_code(self):
        """Syntactically invalid code should not raise an exception."""
        result = analyze_code("def broken(:\n    pass")
        assert result["overall_complexity"] >= 1

    def test_single_function(self):
        code = "def only_func(x):\n    return x * 2"
        result = analyze_code(code)
        assert len(result["functions"]) == 1
        assert result["functions"][0]["name"] == "only_func"
        assert result["functions"][0]["complexity"] == 1

    def test_nested_functions(self):
        code = (
            "def outer():\n"
            "    def inner(x):\n"
            "        if x:\n"
            "            return x\n"
            "    return inner\n"
        )
        # outer has a nested function and a return; inner has an if.
        result = analyze_code(code)
        # At least outer should appear in functions list.
        names = [f["name"] for f in result["functions"]]
        assert "outer" in names

    def test_multiple_functions(self):
        code = (
            "def a():\n    pass\n\n"
            "def b():\n    if x:\n        pass\n\n"
            "def c():\n    for i in range(10):\n        pass\n"
        )
        result = analyze_code(code)
        names = {f["name"]: f["complexity"] for f in result["functions"]}
        assert names["a"] == 1
        assert names["b"] == 2
        assert names["c"] == 2

    def test_try_except_increases_complexity(self):
        code = (
            "try:\n    x = 1\nexcept ValueError:\n    x = 0"
        )
        assert _complexity(code) >= 2

    def test_decision_points_returned(self):
        code = "if a:\n    pass\nfor i in range(5):\n    pass"
        result = analyze_code(code)
        assert len(result["decision_points"]) >= 2

    def test_complexity_summary_field(self):
        result = analyze_code("x = 1")
        assert result["complexity_summary"] in ("LOW", "MEDIUM", "HIGH", "VERY_HIGH")

    def test_cfg_blocks_are_list(self):
        code = "if x:\n    y = 1"
        result = analyze_code(code)
        assert isinstance(result["cfg"]["blocks"], list)

    def test_cfg_edges_are_list(self):
        code = "if x:\n    y = 1"
        result = analyze_code(code)
        assert isinstance(result["cfg"]["edges"], list)
