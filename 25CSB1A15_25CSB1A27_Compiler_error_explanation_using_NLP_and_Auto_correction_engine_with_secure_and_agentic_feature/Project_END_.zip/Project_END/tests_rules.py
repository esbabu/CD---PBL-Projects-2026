"""tests_rules.py – Unit tests and before/after verification for rule engine accuracy fixes.

Covers the 6 issues in dataset/RULE_ENGINE_ISSUES.md plus IndentationError, AttributeError, FileNotFoundError.
Run with: python -m unittest tests_rules -v
"""

import os
import unittest
from unittest.mock import patch
from nlp_explainer import NLPExplainer


class TestRuleEngineAccuracy(unittest.TestCase):
    def setUp(self):
        self.env_patcher = patch.dict(os.environ, {"LLM_DISABLED": "1", "AUTOFIX_AI": "0"})
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)
        self.explainer = NLPExplainer()

    def test_issue1_math_domain_error(self):
        """ValueError: math domain error should diagnose mathematical domain, not string parsing."""
        ir = {
            "error_type": "ValueError",
            "error_message": "math domain error",
            "line_number": 2,
            "traceback": 'File "<string>", line 2, in <module>\nmath.sqrt(-1)'
        }
        res = self.explainer.explain(ir, code="import math\nmath.sqrt(-1)")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("domain", res.lower())
        self.assertNotIn("parser requirements", res.lower())
        self.assertIn("Mistake:", res)
        self.assertIn("Reason:", res)
        self.assertIn("Fix:", res)

    def test_issue2_unpack_mismatch(self):
        """ValueError: too many values to unpack should diagnose unpacking count mismatch."""
        ir = {
            "error_type": "ValueError",
            "error_message": "too many values to unpack (expected 2)",
            "line_number": 1,
            "traceback": 'File "<string>", line 1, in <module>\na, b = [1, 2, 3]'
        }
        res = self.explainer.explain(ir, code="a, b = [1, 2, 3]")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("unpacking", res.lower())
        self.assertNotIn("parser requirements", res.lower())

    def test_issue3_non_iterable_for_loop(self):
        """TypeError: 'int' object is not iterable should diagnose iteration failure and suggest range()."""
        ir = {
            "error_type": "TypeError",
            "error_message": "'int' object is not iterable",
            "line_number": 1,
            "traceback": 'File "<string>", line 1, in <module>\nfor x in 100: pass'
        }
        res = self.explainer.explain(ir, code="for x in 100: pass")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("non-iterable", res.lower())
        self.assertIn("int", res)
        self.assertNotIn("combined directly", res.lower())

    def test_issue4_non_iterable_unpacking(self):
        """TypeError: cannot unpack non-iterable int object should diagnose scalar unpacking."""
        ir = {
            "error_type": "TypeError",
            "error_message": "cannot unpack non-iterable int object",
            "line_number": 1,
            "traceback": 'File "<string>", line 1, in <module>\na, b = 1'
        }
        res = self.explainer.explain(ir, code="a, b = 1")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("unpack non-iterable", res.lower())
        self.assertNotIn("combined directly", res.lower())

    def test_issue5_function_arg_count(self):
        """TypeError: wrong number of arguments should diagnose signature mismatch."""
        ir = {
            "error_type": "TypeError",
            "error_message": "abs() takes exactly one argument (2 given)",
            "line_number": 1,
            "traceback": 'File "<string>", line 1, in <module>\nabs(1, 2)'
        }
        res = self.explainer.explain(ir, code="abs(1, 2)")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("arguments", res.lower())
        self.assertIn("abs", res)
        self.assertNotIn("combined directly", res.lower())

    def test_issue6_float_sequence_index(self):
        """TypeError: list indices must be integers or slices, not float should diagnose index type."""
        ir = {
            "error_type": "TypeError",
            "error_message": "list indices must be integers or slices, not float",
            "line_number": 2,
            "traceback": 'File "<string>", line 2, in <module>\nlst[1.5]'
        }
        res = self.explainer.explain(ir, code="lst = [1, 2]\nlst[1.5]")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("indexing", res.lower())
        self.assertIn("float", res)
        self.assertNotIn("combined directly", res.lower())

    def test_indentation_error(self):
        ir = {
            "error_type": "IndentationError",
            "error_message": "expected an indented block after 'if' statement on line 1",
            "line_number": 2,
            "traceback": 'File "<string>", line 2\npass'
        }
        res = self.explainer.explain(ir, code="if True:\npass")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("indentation", res.lower())

    def test_attribute_error(self):
        ir = {
            "error_type": "AttributeError",
            "error_message": "'list' object has no attribute 'add'",
            "line_number": 2,
            "traceback": 'File "<string>", line 2\nlst.add(1)'
        }
        res = self.explainer.explain(ir, code="lst = []\nlst.add(1)")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("attribute not found", res.lower())

    def test_file_not_found_error(self):
        ir = {
            "error_type": "FileNotFoundError",
            "error_message": "[Errno 2] No such file or directory: 'data.txt'",
            "line_number": 1,
            "traceback": 'File "<string>", line 1\nopen("data.txt")'
        }
        res = self.explainer.explain(ir, code="open('data.txt')")
        self.assertEqual(self.explainer.last_source, "rule")
        self.assertIn("file or directory not found", res.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
