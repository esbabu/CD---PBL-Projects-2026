"""tests_benchmark.py - Unit Tests for Offline Repair Benchmark Harness (Feature 10).

Verifies:
- Benchmark execution on subset of programs (3 programs across error types)
- Benchmark CSV output schema and required column fields
- Execution duration and attempt bounds
- Zero AI / external network calls made (ledger files monitored and unchanged during test)
- Strict socket guard preventing any outbound network access
"""

import csv
import hashlib
import os
import socket
import tempfile
import unittest
from unittest.mock import patch

import run_benchmark

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


def _sha256(path: str) -> str:
    if not os.path.exists(path):
        return "MISSING"
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


class TestBenchmarkHarness(unittest.TestCase):
    """Unit test suite for run_benchmark.py."""

    def setUp(self):
        super().setUp()
        self._orig_connect = socket.socket.connect

        def guarded_connect(sock_self, address):
            host = address[0] if isinstance(address, tuple) else address
            if host not in ("127.0.0.1", "localhost", "::1", "testserver"):
                raise AssertionError(f"Outbound network call to {address} attempted during benchmark test!")
            return self._orig_connect(sock_self, address)

        socket.socket.connect = guarded_connect

        self.env_patcher = patch.dict(os.environ, {
            "GEMINI_API_KEY": "dummy",
            "GROQ_API_KEY": "dummy",
            "LLM_DISABLED": "1",
            "AUTOFIX_AI": "0"
        })
        self.env_patcher.start()

        self.ledger1 = os.path.join(_ROOT_DIR, "benchmark", "call_log.jsonl")
        self.ledger2 = os.path.join(_ROOT_DIR, "benchmark", ".call_counts.json")
        self.ledger1_sha_before = _sha256(self.ledger1)
        self.ledger2_sha_before = _sha256(self.ledger2)

    def tearDown(self):
        self.env_patcher.stop()
        socket.socket.connect = self._orig_connect

        # Verify ledger unchanged during this test run
        ledger1_sha_after = _sha256(self.ledger1)
        ledger2_sha_after = _sha256(self.ledger2)
        self.assertEqual(
            self.ledger1_sha_before, ledger1_sha_after,
            "benchmark/call_log.jsonl was modified during tests_benchmark!"
        )
        self.assertEqual(
            self.ledger2_sha_before, ledger2_sha_after,
            "benchmark/.call_counts.json was modified during tests_benchmark!"
        )
        super().tearDown()

    def test_run_on_three_programs(self):
        """Runs benchmark evaluation on 3 diverse test programs in temporary directory."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            prog1 = os.path.join(tmp_dir, "prog_zero.py")
            with open(prog1, "w", encoding="utf-8") as f:
                f.write("x = 10 / 0\nprint(x)\n")

            prog2 = os.path.join(tmp_dir, "prog_name.py")
            with open(prog2, "w", encoding="utf-8") as f:
                f.write("res = math.sqrt(16)\nprint(res)\n")

            prog3 = os.path.join(tmp_dir, "prog_unfixable.py")
            with open(prog3, "w", encoding="utf-8") as f:
                f.write("val = float('invalid_number_string')\nprint(val)\n")

            out_csv = os.path.join(tmp_dir, "test_results.csv")
            out_md = os.path.join(tmp_dir, "test_summary.md")

            res = run_benchmark.run_full_benchmark(
                programs_dir=tmp_dir,
                output_csv=out_csv,
                output_md=out_md
            )

            self.assertEqual(res["total_programs"], 3)
            # 3 programs * 2 engines * 2 shield modes = 12 evaluations
            self.assertEqual(res["total_evaluations"], 12)
            self.assertTrue(os.path.exists(out_csv))
            self.assertTrue(os.path.exists(out_md))

            # Validate CSV columns
            with open(out_csv, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                expected_cols = {
                    "program", "category", "engine", "shield_mode", "orig_error",
                    "orig_exit", "fix_produced", "healed_error", "healed_exit",
                    "error_gone", "attempts", "duration_ms", "shield_blocked",
                    "wrongly_blocked", "blocked_reason", "engine_error"
                }
                self.assertTrue(expected_cols.issubset(set(reader.fieldnames or [])))
                rows = list(reader)
                self.assertEqual(len(rows), 12)

                # Check ZeroDivision was fixed
                zero_rows = [r for r in rows if r["program"] == "prog_zero.py"]
                for r in zero_rows:
                    self.assertTrue(r["error_gone"] == "True" or r["fix_produced"] == "True")

    def test_category_extraction(self):
        """Verifies category inference from filename."""
        self.assertEqual(run_benchmark.extract_category_from_filename("prog_01_zerodiv.py"), "ZeroDivisionError")
        self.assertEqual(run_benchmark.extract_category_from_filename("prog_03_name_math.py"), "NameError")
        self.assertEqual(run_benchmark.extract_category_from_filename("prog_05_index_list.py"), "IndexError")
        self.assertEqual(run_benchmark.extract_category_from_filename("prog_21_multierror_chain1.py"), "MultiErrorChain")
        self.assertEqual(run_benchmark.extract_category_from_filename("unknown_file.py"), "Unknown")


if __name__ == "__main__":
    unittest.main()
