"""tests_autofix.py – Unit tests for the upgraded Auto-Correction Engine.

Tests:
1. Legacy rules (SyntaxError missing colon, NameError typo rename)
2. AttributeError on built-in types (e.g. list.append vs appnd)
3. ModuleNotFoundError standard library typo (e.g. import math vs mat)
4. TypeError string + int concatenation wrapping in str()
5. IndentationError / TabError tab-to-space conversion
6. AI-assisted fix safety validation & rejection
7. ZeroDivisionError deterministic guard (5 test cases)
8. IndexError deterministic guard (5 test cases)
9. KeyError deterministic guard (5 test cases)
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

from nlp_explainer import NLPExplainer, _run_in_sandbox


class TestAutoFixEngine(unittest.TestCase):
    def setUp(self):
        self.env_patcher = patch.dict(os.environ, {"LLM_DISABLED": "1", "AUTOFIX_AI": "0"})
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)
        self.explainer = NLPExplainer()

    def test_legacy_syntax_error_missing_colon(self):
        code = "def add(a, b)\n    return a + b"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("def add(a, b):", fixed)

    def test_legacy_name_error_typo(self):
        code = "total_count = 10\nprint(total_cout)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertIn("print(total_count)", fixed)

    def test_attribute_error_builtin_type(self):
        code = "items = [1, 2, 3]\nitems.appnd(4)"
        ir = {"error_type": "AttributeError", "error_message": "'list' object has no attribute 'appnd'", "line_number": 2}
        fixed = self.explainer._apply_deterministic_fix("AttributeError", ir["error_message"], 2, code)
        self.assertIsNotNone(fixed)
        self.assertIn("items.append(4)", fixed)

    def test_module_not_found_stdlib(self):
        code = "import mat\nprint(mat.sqrt(4))"
        ir = {"error_type": "ModuleNotFoundError", "error_message": "No module named 'mat'", "line_number": 1}
        fixed = self.explainer._apply_deterministic_fix("ModuleNotFoundError", ir["error_message"], 1, code)
        self.assertIsNotNone(fixed)
        self.assertIn("import math", fixed)

    def test_type_error_str_concat(self):
        code = 'age = 25\nmsg = "Age: " + age'
        ir = {"error_type": "TypeError", "error_message": 'can only concatenate str (not "int") to str', "line_number": 2}
        fixed = self.explainer._apply_deterministic_fix("TypeError", ir["error_message"], 2, code)
        self.assertIsNotNone(fixed)
        self.assertIn('"Age: " + str(age)', fixed)

    def test_tab_error_conversion(self):
        code = "def f():\n\treturn 1"
        ir = {"error_type": "TabError", "error_message": "inconsistent use of tabs and spaces in indentation", "line_number": 2}
        fixed = self.explainer._apply_deterministic_fix("TabError", ir["error_message"], 2, code)
        self.assertIsNotNone(fixed)
        self.assertNotIn("\t", fixed)
        self.assertIn("    return 1", fixed)

    def test_ai_autofix_safety_rejections(self):
        # 1. Reject malicious imports
        code = "x = 1\ny = 0\nres = x / y"
        bad_patch = "Replace line 3 with:\n    import os\n    os.system('echo dangerous')\n    res = 1"
        with patch("llm_calls.call_gemini", return_value=(bad_patch, None, False)):
            fixed = self.explainer._apply_ai_autofix("ZeroDivisionError", "division by zero", 3, code)
            self.assertIsNone(fixed, "Expected AI fix with 'import os' to be rejected")

        # 2. Reject non-AST parsing code
        syntax_bad_patch = "Replace line 3 with:\n    res = (x /"
        with patch("llm_calls.call_gemini", return_value=(syntax_bad_patch, None, False)):
            fixed = self.explainer._apply_ai_autofix("ZeroDivisionError", "division by zero", 3, code)
            self.assertIsNone(fixed, "Expected syntax-invalid AI fix to be rejected")

    # --- 5 ZeroDivisionError Test Cases ---
    def test_zerodivision_guard_01_var(self):
        code = "a = 10\nb = 0\nres = a / b\nprint(res)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("b != 0 else 0", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_zerodivision_guard_02_literal(self):
        code = "val = 100 / 0\nprint(val)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_zerodivision_guard_03_floordiv(self):
        code = "total = 50\ncount = 0\navg = total // count\nprint(avg)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("count != 0 else 0", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_zerodivision_guard_04_modulo(self):
        code = "num = 15\nden = 0\nrem = num % den\nprint(rem)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_zerodivision_guard_05_in_function(self):
        code = "def calc_ratio(x, y):\n    return x / y\nprint(calc_ratio(5, 0))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    # --- 5 IndexError Test Cases ---
    def test_indexerror_guard_01_constant(self):
        code = "lst = [1, 2, 3]\nprint(lst[10])"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("len(lst)", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_indexerror_guard_02_variable(self):
        code = "items = ['a', 'b']\nidx = 5\nval = items[idx]\nprint(val)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_indexerror_guard_03_negative(self):
        code = "data = [10, 20]\ni = -5\nx = data[i]\nprint(x)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_indexerror_guard_04_empty_list(self):
        code = "empty = []\nfirst = empty[0]\nprint(first)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_indexerror_guard_05_in_function(self):
        code = "def get_elem(arr, pos):\n    return arr[pos]\nprint(get_elem([1], 3))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    # --- 5 KeyError Test Cases ---
    def test_keyerror_guard_01_string_key(self):
        code = "d = {'name': 'Alice'}\nprint(d['age'])"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("d.get(", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_keyerror_guard_02_var_key(self):
        code = "user = {'id': 1}\nk = 'email'\nval = user[k]\nprint(val)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("user.get(", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_keyerror_guard_03_int_key(self):
        code = "table = {1: 'one', 2: 'two'}\nprint(table[99])"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("table.get(", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_keyerror_guard_04_empty_dict(self):
        code = "record = {}\nx = record['missing_key']\nprint(x)"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("record.get(", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)

    def test_keyerror_guard_05_in_function(self):
        code = "def find_setting(cfg, key):\n    return cfg[key]\nprint(find_setting({}, 'theme'))"
        fixed = self.explainer.generate_fixed_code(code)
        self.assertEqual(self.explainer.last_fix_status, "applied")
        self.assertIn("cfg.get(", fixed)
        clean, _, _, _ = _run_in_sandbox(fixed)
        self.assertTrue(clean)


if __name__ == "__main__":
    unittest.main()
