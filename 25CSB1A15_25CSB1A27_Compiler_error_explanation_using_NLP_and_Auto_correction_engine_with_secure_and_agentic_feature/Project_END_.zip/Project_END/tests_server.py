"""tests_server.py

Integration tests running against a REAL Flask server process started on a free TCP port.
Tests HTTP communication, UTF-8 JSON payloads, security interception, deterministic fixes,
and the /api/version diagnostic endpoint.
"""

import unittest
import socket
import subprocess
import sys
import os
import time
import json
import urllib.request
import urllib.error
import hashlib


def get_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def compute_expected_build_marker():
    h = hashlib.sha256()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    for fname in ["app.py", "nlp_explainer.py", "error_extractor.py"]:
        fpath = os.path.join(base_dir, fname)
        if os.path.exists(fpath):
            with open(fpath, "rb") as f:
                h.update(f.read())
    return h.hexdigest()[:12]


class TestRealServerHTTP(unittest.TestCase):
    server_process = None
    port = None
    base_url = None

    @classmethod
    def setUpClass(cls):
        cls.port = get_free_port()
        cls.base_url = f"http://127.0.0.1:{cls.port}"
        
        env = os.environ.copy()
        env["AUTOFIX_AI"] = "0"
        env["LLM_DISABLED"] = "1"
        env["CODECARBON_SAVE_TO_FILE"] = "false"
        env["CODECARBON_LOG_LEVEL"] = "error"
        env["PYTHONUTF8"] = "1"
        
        server_code = f"""
import app, sys, os
from app import app as flask_app
flask_app.run(host="127.0.0.1", port={cls.port}, debug=False, use_reloader=False)
"""
        cls.server_process = subprocess.Popen(
            [sys.executable, "-c", server_code],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8"
        )
        
        # Poll /api/version until server is alive (max 10s)
        started = False
        start_time = time.time()
        while time.time() - start_time < 10.0:
            try:
                req = urllib.request.Request(f"{cls.base_url}/api/version")
                with urllib.request.urlopen(req, timeout=1.0) as resp:
                    if resp.status == 200:
                        data = json.loads(resp.read().decode("utf-8"))
                        if data.get("build_marker"):
                            started = True
                            break
            except Exception:
                time.sleep(0.2)
        
        if not started:
            cls.tearDownClass()
            raise RuntimeError(f"Server on port {cls.port} failed to start within timeout.")

    @classmethod
    def tearDownClass(cls):
        if cls.server_process:
            try:
                cls.server_process.terminate()
                cls.server_process.wait(timeout=3)
            except Exception:
                cls.server_process.kill()
            finally:
                if cls.server_process.stdout:
                    cls.server_process.stdout.close()
                if cls.server_process.stderr:
                    cls.server_process.stderr.close()
            cls.server_process = None

    def post_analyze(self, code_str):
        url = f"{self.base_url}/api/analyze"
        req_data = json.dumps({"code": code_str}).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=req_data,
            headers={"Content-Type": "application/json; charset=utf-8"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5.0) as resp:
            status_code = resp.status
            body = json.loads(resp.read().decode("utf-8"))
            return status_code, body

    def test_01_api_version(self):
        req = urllib.request.Request(f"{self.base_url}/api/version")
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            self.assertEqual(resp.status, 200)
            data = json.loads(resp.read().decode("utf-8"))
            expected_marker = compute_expected_build_marker()
            self.assertEqual(data.get("build_marker"), expected_marker)
            self.assertTrue(data.get("fix_status_supported"))
            self.assertTrue(data.get("utf8_mode"))
            self.assertTrue(data.get("security_scan_enabled"))
            self.assertTrue(os.path.exists(data.get("app_path")))

    def test_02_case_a1_misspelled_variable(self):
        code = 'message = "hello"\nprint(mesage)'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fix_source"), "rule")
        self.assertEqual(res.get("fix_status"), "applied")
        self.assertIn('print(message)', res.get("fixed_code"))

    def test_03_case_a2_missing_colon(self):
        code = 'for i in range(3)\n    print(i)'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fix_source"), "rule")
        self.assertEqual(res.get("fix_status"), "applied")
        self.assertIn('for i in range(3):', res.get("fixed_code"))

    def test_04_case_a3_str_int_concat(self):
        code = 'print("Total: " + 5)'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fix_status"), "applied")
        self.assertEqual(res.get("fixed_code").strip(), 'print("Total: " + str(5))')

    def test_05_case_a4_misspelled_method(self):
        code = 'nums = [3, 1, 2]\nnums.apend(4)'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fix_status"), "applied")
        self.assertIn('nums.append(4)', res.get("fixed_code"))

    def test_06_case_b4_misspelled_import(self):
        code = 'import jsno\nprint("ok")'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fix_status"), "applied")
        self.assertIn('import json', res.get("fixed_code"))

    def test_07_case_c4_security_blocked(self):
        code = 'import os\nos.system("echo hi")'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "security_blocked")
        self.assertIn("SECURITY SCAN - HIGH RISK FINDING DETECTED", res.get("raw_text", ""))
        self.assertNotIn("hi", res.get("raw_text", "").splitlines())

    def test_08_case_c5a_utf8_output(self):
        code = 'print("héllo ✓")'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "success")
        raw_text = res.get("raw_text", "")
        self.assertIn("héllo ✓", raw_text)
        self.assertNotIn("Ã", raw_text)
        self.assertNotIn("â", raw_text)

    def test_09_case_a5_math_domain_unfixable(self):
        code = 'import math\nmath.sqrt(-1)'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fixed_code").strip(), code.strip())
        self.assertIn("ValueError", res.get("raw_text", ""))

    def test_10_case_a6_iteration_int_fixed(self):
        code = 'for x in 42:\n    pass'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fix_status"), "applied")
        self.assertEqual(res.get("fixed_code").strip(), "for x in range(42):\n    pass")
        self.assertIn("TypeError", res.get("raw_text", ""))

    def test_11_case_b5_missing_package_kept(self):
        code = 'import some_missing_package'
        status, res = self.post_analyze(code)
        self.assertEqual(status, 200)
        self.assertEqual(res.get("status"), "error_intercepted")
        self.assertEqual(res.get("fixed_code").strip(), code.strip())
        self.assertIn("ModuleNotFoundError", res.get("raw_text", ""))
        self.assertIn("some_missing_package", res.get("raw_text", ""))


if __name__ == '__main__':
    unittest.main()
