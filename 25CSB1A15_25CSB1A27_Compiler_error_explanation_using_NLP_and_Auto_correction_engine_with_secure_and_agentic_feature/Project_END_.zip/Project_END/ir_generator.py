"""ir_generator.py - Intermediate Representation (TAC & SSA) Lowering Engine for IntelliFix.

Lowers Python Abstract Syntax Trees into Three-Address Code (TAC) and Static Single Assignment (SSA) form.
Provides basic block decomposition, control flow graph edges over TAC, instruction serialization,
and before/after IR comparison for compiler auto-repair and optimizations.

Preserves backward compatibility with legacy IRGenerator(code, error_obj).
"""

import ast
import json
import difflib
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple, Set, Union


# ---------------------------------------------------------------------------
# TAC Instruction Representation
# ---------------------------------------------------------------------------

@dataclass
class TACInstruction:
    """A single Three-Address Code (TAC) instruction.

    Format: [result =] opcode [arg1] [arg2]
    Examples:
        t0 = a + b      -> result='t0', opcode='ADD', arg1='a', arg2='b'
        x = t0          -> result='x', opcode='ASSIGN', arg1='t0', arg2=None
        JUMP_IF_FALSE t0 -> L1 -> result=None, opcode='JUMP_IF_FALSE', arg1='t0', arg2='L1'
        PARAM x         -> result=None, opcode='PARAM', arg1='x', arg2=None
        t1 = CALL f, 1  -> result='t1', opcode='CALL', arg1='f', arg2=1
        RETURN t1       -> result=None, opcode='RETURN', arg1='t1', arg2=None
        LABEL L1        -> result=None, opcode='LABEL', arg1='L1', arg2=None
    """
    opcode: str
    result: Optional[str] = None
    arg1: Any = None
    arg2: Any = None
    source_line: Optional[int] = None
    comment: Optional[str] = None
    is_security_critical: bool = False

    def to_str(self) -> str:
        """Formats instruction as standard human-readable Three-Address Code."""
        op = self.opcode.upper()
        if op == "LABEL":
            return f"{self.arg1}:"
        elif op == "JUMP":
            return f"    JUMP -> {self.arg1}"
        elif op in ("JUMP_IF_TRUE", "JUMP_IF_FALSE"):
            return f"    {op} {self.arg1} -> {self.arg2}"
        elif op == "RETURN":
            val = f" {self.arg1}" if self.arg1 is not None else ""
            return f"    RETURN{val}"
        elif op == "PARAM":
            return f"    PARAM {self.arg1}"
        elif op == "CALL":
            res = f"{self.result} = " if self.result else ""
            return f"    {res}CALL {self.arg1}, {self.arg2}"
        elif op == "PARAM_BIND":
            return f"    PARAM_BIND {self.result}"
        elif op == "ASSIGN":
            return f"    {self.result} = {self.arg1}"
        elif op == "PHI":
            args = ", ".join(str(a) for a in self.arg1) if isinstance(self.arg1, (list, tuple)) else str(self.arg1)
            return f"    {self.result} = PHI({args})"
        elif op in ("LOAD_INDEX", "STORE_INDEX"):
            if op == "LOAD_INDEX":
                return f"    {self.result} = {self.arg1}[{self.arg2}]"
            else:
                return f"    {self.result}[{self.arg1}] = {self.arg2}"
        elif op in ("LOAD_ATTR", "STORE_ATTR"):
            if op == "LOAD_ATTR":
                return f"    {self.result} = {self.arg1}.{self.arg2}"
            else:
                return f"    {self.result}.{self.arg1} = {self.arg2}"
        elif op in ("NOT", "NEG", "INVERT"):
            return f"    {self.result} = {op} {self.arg1}"
        elif op == "SECURITY_CHECK":
            return f"    SECURITY_CHECK {self.arg1} ({self.comment or 'invariant'})"
        elif op == "NOP":
            return f"    NOP"
        else:
            # Binary operations (ADD, SUB, MUL, DIV, EQ, LT, etc.)
            return f"    {self.result} = {self.arg1} {op} {self.arg2}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "opcode": self.opcode,
            "result": self.result,
            "arg1": str(self.arg1) if self.arg1 is not None else None,
            "arg2": str(self.arg2) if self.arg2 is not None else None,
            "source_line": self.source_line,
            "comment": self.comment,
            "is_security_critical": self.is_security_critical,
            "formatted": self.to_str()
        }


@dataclass
class BasicBlockTAC:
    """A maximal sequence of TAC instructions with single entry and single exit."""
    id: int
    label: str
    instructions: List[TACInstruction] = field(default_factory=list)
    predecessors: List[int] = field(default_factory=list)
    successors: List[int] = field(default_factory=list)
    start_line: int = 0
    end_line: int = 0
    is_loop_header: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "label": self.label,
            "predecessors": self.predecessors,
            "successors": self.successors,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "is_loop_header": self.is_loop_header,
            "instruction_count": len(self.instructions),
            "instructions": [inst.to_dict() for inst in self.instructions],
            "text": "\n".join(inst.to_str() for inst in self.instructions)
        }


# ---------------------------------------------------------------------------
# AST to TAC Lowering Visitor
# ---------------------------------------------------------------------------

class ASTToTACLowerer(ast.NodeVisitor):
    """Lowers high-level Python AST into Three-Address Code with explicit temporaries and control flow jumps."""

    BINOP_MAP = {
        ast.Add: "ADD",
        ast.Sub: "SUB",
        ast.Mult: "MUL",
        ast.Div: "DIV",
        ast.FloorDiv: "FLOORDIV",
        ast.Mod: "MOD",
        ast.Pow: "POW",
        ast.LShift: "LSHIFT",
        ast.RShift: "RSHIFT",
        ast.BitOr: "BITOR",
        ast.BitXor: "BITXOR",
        ast.BitAnd: "BITAND",
    }

    CMPOP_MAP = {
        ast.Eq: "EQ",
        ast.NotEq: "NE",
        ast.Lt: "LT",
        ast.LtE: "LE",
        ast.Gt: "GT",
        ast.GtE: "GE",
        ast.Is: "IS",
        ast.IsNot: "IS_NOT",
        ast.In: "IN",
        ast.NotIn: "NOT_IN",
    }

    UNOP_MAP = {
        ast.UAdd: "POS",
        ast.USub: "NEG",
        ast.Not: "NOT",
        ast.Invert: "INVERT",
    }

    def __init__(self):
        self.instructions: List[TACInstruction] = []
        self._temp_counter: int = 0
        self._label_counter: int = 0
        self._current_line: int = 1
        self._loop_exit_stack: List[str] = []
        self._loop_header_stack: List[str] = []

    def _new_temp(self) -> str:
        name = f"t{self._temp_counter}"
        self._temp_counter += 1
        return name

    def _new_label(self, prefix: str = "L") -> str:
        label = f"{prefix}{self._label_counter}"
        self._label_counter += 1
        return label

    def _emit(self, opcode: str, result: Optional[str] = None, arg1: Any = None, arg2: Any = None,
              comment: Optional[str] = None, is_security_critical: bool = False) -> TACInstruction:
        inst = TACInstruction(
            opcode=opcode,
            result=result,
            arg1=arg1,
            arg2=arg2,
            source_line=self._current_line,
            comment=comment,
            is_security_critical=is_security_critical
        )
        self.instructions.append(inst)
        return inst

    def lower(self, tree: ast.AST) -> List[TACInstruction]:
        """Lowers the entire AST into a flat list of TAC instructions."""
        self.instructions = []
        self._temp_counter = 0
        self._label_counter = 0
        self.visit(tree)
        return self.instructions

    # -----------------------------------------------------------------------
    # Expressions: return the temporary name or constant literal holding result
    # -----------------------------------------------------------------------

    def visit_Constant(self, node: ast.Constant) -> Any:
        # For primitive constants, return representation directly
        if node.value is None:
            return "None"
        elif isinstance(node.value, bool):
            return "True" if node.value else "False"
        elif isinstance(node.value, (int, float)):
            return str(node.value)
        elif isinstance(node.value, str):
            return repr(node.value)
        return str(node.value)

    def visit_Name(self, node: ast.Name) -> str:
        return node.id

    def visit_BinOp(self, node: ast.BinOp) -> str:
        left = self.visit(node.left)
        right = self.visit(node.right)
        op_name = self.BINOP_MAP.get(type(node.op), "BINOP")
        t = self._new_temp()
        self._emit(op_name, result=t, arg1=left, arg2=right)
        return t

    def visit_UnaryOp(self, node: ast.UnaryOp) -> str:
        operand = self.visit(node.operand)
        op_name = self.UNOP_MAP.get(type(node.op), "UNOP")
        t = self._new_temp()
        self._emit(op_name, result=t, arg1=operand)
        return t

    def visit_Compare(self, node: ast.Compare) -> str:
        left = self.visit(node.left)
        res = left
        for op, comparator in zip(node.ops, node.comparators):
            right = self.visit(comparator)
            op_name = self.CMPOP_MAP.get(type(op), "CMP")
            t = self._new_temp()
            self._emit(op_name, result=t, arg1=res, arg2=right)
            res = t
        return res

    def visit_BoolOp(self, node: ast.BoolOp) -> str:
        t = self._new_temp()
        op_name = "AND" if isinstance(node.op, ast.And) else "OR"
        val0 = self.visit(node.values[0])
        self._emit("ASSIGN", result=t, arg1=val0)

        for val_node in node.values[1:]:
            next_val = self.visit(val_node)
            self._emit(op_name, result=t, arg1=t, arg2=next_val)
        return t

    def visit_Call(self, node: ast.Call) -> str:
        # Determine function name and whether it is security-critical
        func_name = "unknown_func"
        is_security = False
        is_scrub = False

        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            if func_name in ("zero_memory", "wipe", "scrub", "secure_erase", "check_bounds", "verify_token", "rate_limit"):
                is_security = True
                if func_name in ("zero_memory", "wipe", "scrub", "secure_erase"):
                    is_scrub = True
        elif isinstance(node.func, ast.Attribute):
            receiver = self.visit(node.func.value)
            func_name = f"{receiver}.{node.func.attr}"
            if node.func.attr in ("scrub", "wipe", "erase", "verify_token", "check_bounds"):
                is_security = True

        # Lower arguments
        arg_tmps = []
        for arg in node.args:
            tmp = self.visit(arg)
            arg_tmps.append(tmp)

        # Emit PARAM instructions
        for a in arg_tmps:
            self._emit("PARAM", arg1=a)

        t = self._new_temp()
        comment = "Security invariant: memory scrub" if is_scrub else ("Security check" if is_security else None)
        self._emit("CALL", result=t, arg1=func_name, arg2=len(arg_tmps), comment=comment, is_security_critical=is_security)
        return t

    def visit_Subscript(self, node: ast.Subscript) -> str:
        target = self.visit(node.value)
        slice_idx = self.visit(node.slice)
        t = self._new_temp()
        self._emit("LOAD_INDEX", result=t, arg1=target, arg2=slice_idx)
        return t

    def visit_Attribute(self, node: ast.Attribute) -> str:
        receiver = self.visit(node.value)
        t = self._new_temp()
        self._emit("LOAD_ATTR", result=t, arg1=receiver, arg2=node.attr)
        return t

    def visit_List(self, node: ast.List) -> str:
        t = self._new_temp()
        elems = [self.visit(e) for e in node.elts]
        self._emit("CALL", result=t, arg1="list_alloc", arg2=len(elems), comment=f"[{', '.join(str(e) for e in elems)}]")
        return t

    def visit_Dict(self, node: ast.Dict) -> str:
        t = self._new_temp()
        pairs_count = len(node.keys)
        self._emit("CALL", result=t, arg1="dict_alloc", arg2=pairs_count)
        return t

    # -----------------------------------------------------------------------
    # Statements
    # -----------------------------------------------------------------------

    def visit_Assign(self, node: ast.Assign) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        rhs_val = self.visit(node.value)

        # Check for security-sensitive assignments like scrub or secret erase
        for target in node.targets:
            if isinstance(target, ast.Name):
                is_scrub = (
                    target.id.lower() in ("secret", "token", "password", "key", "auth_token") and
                    (rhs_val in ("''", '""', "None", "0", "b''"))
                )
                self._emit("ASSIGN", result=target.id, arg1=rhs_val,
                           is_security_critical=is_scrub,
                           comment="Security invariant: secret overwrite" if is_scrub else None)
            elif isinstance(target, ast.Subscript):
                obj = self.visit(target.value)
                idx = self.visit(target.slice)
                self._emit("STORE_INDEX", result=obj, arg1=idx, arg2=rhs_val)
            elif isinstance(target, ast.Attribute):
                obj = self.visit(target.value)
                self._emit("STORE_ATTR", result=obj, arg1=target.attr, arg2=rhs_val)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        rhs_val = self.visit(node.value)
        op_name = self.BINOP_MAP.get(type(node.op), "AUGOP")

        if isinstance(node.target, ast.Name):
            t = self._new_temp()
            self._emit(op_name, result=t, arg1=node.target.id, arg2=rhs_val)
            self._emit("ASSIGN", result=node.target.id, arg1=t)

    def visit_If(self, node: ast.If) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        test_val = self.visit(node.test)

        label_else = self._new_label("L_else_")
        label_end = self._new_label("L_endif_")

        has_else = bool(node.orelse)
        false_target = label_else if has_else else label_end

        self._emit("JUMP_IF_FALSE", arg1=test_val, arg2=false_target)

        # Then branch
        for stmt in node.body:
            self.visit(stmt)

        if has_else:
            self._emit("JUMP", arg1=label_end)
            self._emit("LABEL", arg1=label_else)
            for stmt in node.orelse:
                self.visit(stmt)

        self._emit("LABEL", arg1=label_end)

    def visit_While(self, node: ast.While) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        label_header = self._new_label("L_loop_head_")
        label_exit = self._new_label("L_loop_exit_")

        self._loop_header_stack.append(label_header)
        self._loop_exit_stack.append(label_exit)

        self._emit("LABEL", arg1=label_header)
        test_val = self.visit(node.test)
        self._emit("JUMP_IF_FALSE", arg1=test_val, arg2=label_exit)

        for stmt in node.body:
            self.visit(stmt)

        self._emit("JUMP", arg1=label_header)
        self._emit("LABEL", arg1=label_exit)

        self._loop_header_stack.pop()
        self._loop_exit_stack.pop()

    def visit_For(self, node: ast.For) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        iter_tmp = self.visit(node.iter)

        label_header = self._new_label("L_for_head_")
        label_exit = self._new_label("L_for_exit_")

        self._loop_header_stack.append(label_header)
        self._loop_exit_stack.append(label_exit)

        iter_obj = self._new_temp()
        self._emit("CALL", result=iter_obj, arg1="iter", arg2=1, comment=f"iter({iter_tmp})")

        self._emit("LABEL", arg1=label_header)
        elem_tmp = self._new_temp()
        self._emit("CALL", result=elem_tmp, arg1="next", arg2=1, comment="next(iter)")

        if isinstance(node.target, ast.Name):
            self._emit("ASSIGN", result=node.target.id, arg1=elem_tmp)

        for stmt in node.body:
            self.visit(stmt)

        self._emit("JUMP", arg1=label_header)
        self._emit("LABEL", arg1=label_exit)

        self._loop_header_stack.pop()
        self._loop_exit_stack.pop()

    def visit_Break(self, node: ast.Break) -> None:
        if self._loop_exit_stack:
            self._emit("JUMP", arg1=self._loop_exit_stack[-1], comment="break")

    def visit_Continue(self, node: ast.Continue) -> None:
        if self._loop_header_stack:
            self._emit("JUMP", arg1=self._loop_header_stack[-1], comment="continue")

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        label_func = f"FUNC_{node.name}"
        label_end = f"END_FUNC_{node.name}"

        self._emit("LABEL", arg1=label_func)
        # Bind parameters
        for arg in node.args.args:
            self._emit("PARAM_BIND", result=arg.arg)

        for stmt in node.body:
            self.visit(stmt)

        # Ensure return if fall through
        if not (self.instructions and self.instructions[-1].opcode == "RETURN"):
            self._emit("RETURN", arg1="None")

        self._emit("LABEL", arg1=label_end)

    def visit_Return(self, node: ast.Return) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        if node.value:
            val = self.visit(node.value)
            self._emit("RETURN", arg1=val)
        else:
            self._emit("RETURN", arg1="None")

    def visit_Expr(self, node: ast.Expr) -> None:
        self._current_line = getattr(node, "lineno", self._current_line)
        self.visit(node.value)


# ---------------------------------------------------------------------------
# Basic Block Partitioner for TAC
# ---------------------------------------------------------------------------

def partition_tac_into_blocks(instructions: List[TACInstruction]) -> List[BasicBlockTAC]:
    """Partitions a linear list of TAC instructions into Basic Blocks and computes CFG edges."""
    if not instructions:
        return [BasicBlockTAC(id=0, label="B0_entry")]

    # Identify leaders (index in instructions)
    leaders: Set[int] = {0}
    label_to_index: Dict[str, int] = {}

    for i, inst in enumerate(instructions):
        if inst.opcode == "LABEL" and inst.arg1:
            label_to_index[str(inst.arg1)] = i
            leaders.add(i)
        elif inst.opcode in ("JUMP", "JUMP_IF_TRUE", "JUMP_IF_FALSE", "RETURN"):
            if i + 1 < len(instructions):
                leaders.add(i + 1)

    sorted_leaders = sorted(list(leaders))
    blocks: List[BasicBlockTAC] = []
    block_map: Dict[int, BasicBlockTAC] = {}
    inst_to_block_id: Dict[int, int] = {}

    for b_idx, start in enumerate(sorted_leaders):
        end = sorted_leaders[b_idx + 1] if b_idx + 1 < len(sorted_leaders) else len(instructions)
        blk_insts = instructions[start:end]

        label = f"B{b_idx}"
        if blk_insts and blk_insts[0].opcode == "LABEL":
            label = str(blk_insts[0].arg1)

        start_line = min((i.source_line for i in blk_insts if i.source_line), default=0)
        end_line = max((i.source_line for i in blk_insts if i.source_line), default=0)

        blk = BasicBlockTAC(
            id=b_idx,
            label=label,
            instructions=blk_insts,
            start_line=start_line,
            end_line=end_line,
            is_loop_header=("loop_head" in label or "for_head" in label)
        )
        blocks.append(blk)
        block_map[b_idx] = blk
        for inst_idx in range(start, end):
            inst_to_block_id[inst_idx] = b_idx

    # Build CFG edges (predecessors, successors)
    for b_idx, blk in enumerate(blocks):
        if not blk.instructions:
            continue
        last_inst = blk.instructions[-1]
        op = last_inst.opcode

        if op == "JUMP":
            target_label = str(last_inst.arg1)
            target_idx = label_to_index.get(target_label)
            if target_idx is not None and target_idx in inst_to_block_id:
                tgt_bid = inst_to_block_id[target_idx]
                blk.successors.append(tgt_bid)
                blocks[tgt_bid].predecessors.append(b_idx)
        elif op in ("JUMP_IF_TRUE", "JUMP_IF_FALSE"):
            target_label = str(last_inst.arg2)
            target_idx = label_to_index.get(target_label)
            if target_idx is not None and target_idx in inst_to_block_id:
                tgt_bid = inst_to_block_id[target_idx]
                blk.successors.append(tgt_bid)
                blocks[tgt_bid].predecessors.append(b_idx)
            # Also fall-through to next block
            if b_idx + 1 < len(blocks):
                blk.successors.append(b_idx + 1)
                blocks[b_idx + 1].predecessors.append(b_idx)
        elif op == "RETURN":
            # No successors
            pass
        else:
            # Fall through to next block
            if b_idx + 1 < len(blocks):
                blk.successors.append(b_idx + 1)
                blocks[b_idx + 1].predecessors.append(b_idx)

    # Deduplicate edges
    for blk in blocks:
        blk.predecessors = sorted(list(set(blk.predecessors)))
        blk.successors = sorted(list(set(blk.successors)))

    return blocks


# ---------------------------------------------------------------------------
# SSA Form Conversion
# ---------------------------------------------------------------------------

def convert_tac_to_ssa(blocks: List[BasicBlockTAC]) -> List[BasicBlockTAC]:
    """Converts Three-Address Code basic blocks into Static Single Assignment (SSA) form

    with versioned variables (e.g. x_0, x_1) and phi nodes at confluence blocks.
    """
    var_versions: Dict[str, int] = {}
    active_version: Dict[str, str] = {}
    ssa_blocks: List[BasicBlockTAC] = []

    def get_var_read(v: Any) -> Any:
        if isinstance(v, str) and not v.startswith(("L_", "FUNC_", "END_")) and not v.isdigit() and not v.startswith(("'", '"')):
            return active_version.get(v, f"{v}_0")
        return v

    def alloc_var_write(v: str) -> str:
        curr = var_versions.get(v, 0)
        v_ssa = f"{v}_{curr}"
        var_versions[v] = curr + 1
        active_version[v] = v_ssa
        return v_ssa

    # Track block exit variable mappings for phi node placement
    block_exit_env: Dict[int, Dict[str, str]] = {}

    for blk in blocks:
        new_insts: List[TACInstruction] = []

        # If block has multiple predecessors, check if phi nodes are needed
        if len(blk.predecessors) > 1:
            all_vars = set()
            for p in blk.predecessors:
                all_vars.update(block_exit_env.get(p, {}).keys())

            for var in sorted(list(all_vars)):
                pred_versions = [block_exit_env.get(p, {}).get(var, f"{var}_0") for p in blk.predecessors]
                # If predecessors have divergent versions of the variable
                if len(set(pred_versions)) > 1:
                    ssa_result = alloc_var_write(var)
                    phi_inst = TACInstruction(
                        opcode="PHI",
                        result=ssa_result,
                        arg1=pred_versions,
                        source_line=blk.start_line,
                        comment=f"Merge {var} from blocks {blk.predecessors}"
                    )
                    new_insts.append(phi_inst)

        for inst in blk.instructions:
            op = inst.opcode
            arg1_val = inst.arg1
            arg2_val = inst.arg2

            if op not in ("LABEL", "JUMP"):
                arg1_val = get_var_read(inst.arg1)
                arg2_val = get_var_read(inst.arg2)

            res_val = inst.result
            if inst.result and not inst.result.startswith("t"):
                res_val = alloc_var_write(inst.result)

            ssa_inst = TACInstruction(
                opcode=inst.opcode,
                result=res_val,
                arg1=arg1_val,
                arg2=arg2_val,
                source_line=inst.source_line,
                comment=inst.comment,
                is_security_critical=inst.is_security_critical
            )
            new_insts.append(ssa_inst)

        block_exit_env[blk.id] = dict(active_version)

        ssa_blk = BasicBlockTAC(
            id=blk.id,
            label=blk.label,
            instructions=new_insts,
            predecessors=list(blk.predecessors),
            successors=list(blk.successors),
            start_line=blk.start_line,
            end_line=blk.end_line,
            is_loop_header=blk.is_loop_header
        )
        ssa_blocks.append(ssa_blk)

    return ssa_blocks


# ---------------------------------------------------------------------------
# IR Lowering and Diff Comparison Functions
# ---------------------------------------------------------------------------

def generate_ir_for_code(code: str, ssa: bool = False) -> Dict[str, Any]:
    """Generates Three-Address Code (and optional SSA) from Python source code."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return {
            "success": False,
            "error": f"SyntaxError at line {e.lineno}: {e.msg}",
            "tac_text": "",
            "blocks": [],
            "instruction_count": 0
        }

    lowerer = ASTToTACLowerer()
    raw_instructions = lowerer.lower(tree)
    blocks = partition_tac_into_blocks(raw_instructions)

    if ssa:
        blocks = convert_tac_to_ssa(blocks)

    # Format text output
    lines = []
    for b in blocks:
        preds = f" (preds: {b.predecessors})" if b.predecessors else ""
        succs = f" (succs: {b.successors})" if b.successors else ""
        lines.append(f"[{b.label}]{preds}{succs}:")
        for inst in b.instructions:
            lines.append(inst.to_str())
        lines.append("")

    tac_text = "\n".join(lines)

    flat_instructions = []
    for b in blocks:
        flat_instructions.extend(b.instructions)

    return {
        "success": True,
        "is_ssa": ssa,
        "tac_text": tac_text,
        "blocks": [b.to_dict() for b in blocks],
        "block_count": len(blocks),
        "instruction_count": len(flat_instructions)
    }


def compare_code_ir(orig_code: str, fixed_code: str, ssa: bool = False) -> Dict[str, Any]:
    """Computes a structural and textual diff of the Intermediate Representation

    between the original code and the fixed/optimized code.
    """
    ir_orig = generate_ir_for_code(orig_code, ssa=ssa)
    ir_fixed = generate_ir_for_code(fixed_code, ssa=ssa)

    if not ir_orig["success"] or not ir_fixed["success"]:
        return {
            "success": False,
            "error": ir_orig.get("error") or ir_fixed.get("error"),
            "diff_text": "",
            "orig_ir": ir_orig,
            "fixed_ir": ir_fixed
        }

    orig_lines = ir_orig["tac_text"].splitlines(keepends=True)
    fixed_lines = ir_fixed["tac_text"].splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        orig_lines,
        fixed_lines,
        fromfile="Original Code IR (TAC)",
        tofile="Fixed / Optimized Code IR (TAC)"
    ))

    return {
        "success": True,
        "is_ssa": ssa,
        "diff_text": "".join(diff),
        "diff_lines": diff,
        "has_changes": orig_lines != fixed_lines,
        "ir_changed": orig_lines != fixed_lines,
        "original_ir": ir_orig,
        "fixed_ir": ir_fixed,
        "orig_instructions": ir_orig["instruction_count"],
        "fixed_instructions": ir_fixed["instruction_count"],
        "delta_instructions": ir_fixed["instruction_count"] - ir_orig["instruction_count"]
    }


# Convenience alias
generate_ir = generate_ir_for_code


# ---------------------------------------------------------------------------
# Backward Compatibility with legacy IRGenerator
# ---------------------------------------------------------------------------

class IRGenerator:
    """Legacy interface maintained for backward compatibility."""

    def __init__(self, code, error_obj):
        self.code = code
        self.error = error_obj

    def attach_parents(self, tree):
        for parent in ast.walk(tree):
            for child in ast.iter_child_nodes(parent):
                child.parent = parent

    def get_ast_info(self):
        try:
            tree = ast.parse(self.code)
            self.attach_parents(tree)
            for node in ast.walk(tree):
                if hasattr(node, "lineno") and node.lineno == getattr(self.error, "line_number", None):
                    node_name = type(node).__name__
                    parent_name = type(node.parent).__name__ if hasattr(node, "parent") else None
                    return node_name, parent_name
        except Exception:
            pass
        return None, None

    def get_variables(self):
        variables = set()
        try:
            tree = ast.parse(self.code)
            for node in ast.walk(tree):
                if isinstance(node, ast.Name):
                    variables.add(node.id)
        except Exception:
            pass
        return list(variables)

    def extract_error_variable(self):
        msg = getattr(self.error, "message", "")
        if "name '" in msg:
            return msg.split("'")[1]
        if "KeyError" in getattr(self.error, "error_type", "") or "'" in msg:
            return msg.replace("'", "")
        return None

    def get_indentation_level(self):
        try:
            lines = self.code.split("\n")
            line = lines[getattr(self.error, "line_number", 1) - 1]
            return len(line) - len(line.lstrip())
        except Exception:
            return None

    def generate_ir(self):
        ast_node, parent_node = self.get_ast_info()
        ir = {
            "error_type": getattr(self.error, "error_type", "Unknown"),
            "error_message": getattr(self.error, "message", ""),
            "error_category": getattr(self.error, "category", ""),
            "line_number": getattr(self.error, "line_number", 0),
            "ast_node": ast_node,
            "parent_node": parent_node,
            "variables_used": self.get_variables(),
            "error_variable": self.extract_error_variable(),
            "indentation_level": self.get_indentation_level(),
            "traceback": getattr(self.error, "traceback_info", "")
        }
        return json.dumps(ir, indent=4)
