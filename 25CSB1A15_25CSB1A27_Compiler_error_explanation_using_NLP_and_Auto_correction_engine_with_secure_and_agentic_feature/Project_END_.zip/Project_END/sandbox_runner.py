"""
sandbox_runner.py - Hardened, isolated code runner for IntelliFix.

Overview:
1. Unified single-entry-point sandbox runner for user and fixed code execution.
2. Isolates execution in a dedicated subprocess running `sys.executable -I -X utf8`
   with scrubbed environment variables (preventing API keys / host secrets leakage).
3. Enforces strict limits: wall-clock timeout, memory limit via Windows Job Objects
   (plus psutil watchdog fallback), combined stdout/stderr output caps, and CPU time.
4. Uses Python audit hooks in `sandbox_child.py` for defense-in-depth restrictions against
   network access, subprocess spawning, native shared library loading, and out-of-sandbox writes.
5. Communicates execution results via a tamper-resistant per-run cryptographic nonce channel.
6. Automatically and robustly terminates entire process trees to prevent orphan processes.
7. Cleans up per-run temporary directories with retry logic for Windows file locks.
8. Pure library with NO import-time side effects, fail-closed design, and clean typed interface.
"""

import sys
import os
import io
import json
import time
import secrets
import shutil
import tempfile
import threading
import subprocess
import re
import ctypes
from ctypes import wintypes
from typing import Dict, Any, List, Optional, Tuple

import psutil

# Configuration defaults readable from environment without import-time side effects
DEFAULT_TIMEOUT: float = float(os.environ.get("SANDBOX_TIMEOUT", "5.0"))
DEFAULT_MEMORY_MB: int = int(os.environ.get("SANDBOX_MEMORY_MB", "512"))
DEFAULT_MAX_OUTPUT_KB: int = int(os.environ.get("SANDBOX_MAX_OUTPUT_KB", "256"))

# Windows ctypes structures for Job Object limits
_IS_WINDOWS = (os.name == 'nt')

if _IS_WINDOWS:
    class _IO_COUNTERS(ctypes.Structure):
        _fields_ = [
            ('ReadOperationCount', ctypes.c_uint64),
            ('WriteOperationCount', ctypes.c_uint64),
            ('OtherOperationCount', ctypes.c_uint64),
            ('ReadTransferCount', ctypes.c_uint64),
            ('WriteTransferCount', ctypes.c_uint64),
            ('OtherTransferCount', ctypes.c_uint64),
        ]

    class _JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ('PerProcessUserTimeLimit', ctypes.c_int64),
            ('PerJobUserTimeLimit', ctypes.c_int64),
            ('LimitFlags', wintypes.DWORD),
            ('MinimumWorkingSetSize', ctypes.c_size_t),
            ('MaximumWorkingSetSize', ctypes.c_size_t),
            ('ActiveProcessLimit', wintypes.DWORD),
            ('Affinity', ctypes.c_size_t),
            ('PriorityClass', wintypes.DWORD),
            ('SchedulingClass', wintypes.DWORD),
        ]

    class _JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
        _fields_ = [
            ('BasicLimitInformation', _JOBOBJECT_BASIC_LIMIT_INFORMATION),
            ('IoInfo', _IO_COUNTERS),
            ('ProcessMemoryLimit', ctypes.c_size_t),
            ('JobMemoryLimit', ctypes.c_size_t),
            ('PeakProcessMemoryUsed', ctypes.c_size_t),
            ('PeakJobMemoryUsed', ctypes.c_size_t),
        ]

    JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000
    JOB_OBJECT_LIMIT_PROCESS_MEMORY = 0x0100
    JOB_OBJECT_LIMIT_JOB_MEMORY = 0x0200
    JOB_OBJECT_LIMIT_PROCESS_TIME = 0x0002
    JobObjectExtendedLimitInformation = 9


def _kill_process_tree(pid: int) -> None:
    """Terminates an entire process tree (children first, then parent) to prevent orphans."""
    try:
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        for child in children:
            try:
                child.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        try:
            parent.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        psutil.wait_procs(children + [parent], timeout=1.0)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
    except Exception:
        pass


def _cleanup_dir_with_retry(path: str, retries: int = 5, delay: float = 0.05) -> None:
    """Removes a directory with retry logic for Windows file lock delays."""
    if not os.path.exists(path):
        return
    for i in range(retries):
        try:
            shutil.rmtree(path, ignore_errors=False)
            return
        except Exception:
            time.sleep(delay)
    # Final fallback ignoring errors
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


def _create_and_assign_job_object(
    proc_handle: int,
    memory_mb: int,
    cpu_seconds: Optional[float] = None
) -> Tuple[Optional[int], bool, str]:
    """Creates a Windows Job Object, sets memory and CPU limits, and assigns the child process."""
    if not _IS_WINDOWS or not proc_handle:
        return None, False, "Not Windows"
    try:
        kernel32 = ctypes.windll.kernel32
        job = kernel32.CreateJobObjectW(None, None)
        if not job:
            return None, False, "CreateJobObjectW failed"

        limits = _JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        limit_flags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_PROCESS_MEMORY | JOB_OBJECT_LIMIT_JOB_MEMORY
        if cpu_seconds is not None and cpu_seconds > 0:
            limit_flags |= JOB_OBJECT_LIMIT_PROCESS_TIME
            limits.BasicLimitInformation.PerProcessUserTimeLimit = int(cpu_seconds * 10_000_000)

        limits.BasicLimitInformation.LimitFlags = limit_flags
        limit_bytes = memory_mb * 1024 * 1024
        limits.ProcessMemoryLimit = limit_bytes
        limits.JobMemoryLimit = limit_bytes

        set_res = kernel32.SetInformationJobObject(
            job,
            JobObjectExtendedLimitInformation,
            ctypes.byref(limits),
            ctypes.sizeof(limits)
        )
        if not set_res:
            kernel32.CloseHandle(job)
            return None, False, "SetInformationJobObject failed"

        assign_res = kernel32.AssignProcessToJobObject(job, proc_handle)
        if not assign_res:
            kernel32.CloseHandle(job)
            return None, False, "AssignProcessToJobObject failed"

        return job, True, "Windows Job Object active"
    except Exception as e:
        return None, False, f"Job Object exception: {e}"


def run_in_sandbox(
    code: str,
    timeout: float = DEFAULT_TIMEOUT,
    memory_mb: int = DEFAULT_MEMORY_MB,
    max_output_kb: int = DEFAULT_MAX_OUTPUT_KB,
    cpu_seconds: Optional[float] = None,
    _test_python_bin: Optional[str] = None
) -> Dict[str, Any]:
    """
    Executes Python code in a restricted, isolated child process.

    Returns:
        Dict with keys:
            - status: "ok" | "error" | "timeout" | "memory_exceeded" | "output_limit" | "violation" | "sandbox_failure"
            - stdout: str
            - stderr: str
            - exit_code: Optional[int]
            - duration_ms: float
            - peak_memory_mb: float
            - error: Optional[Dict[str, Any]] (error_type, error_message, line_number, traceback)
            - violations: List[Dict[str, str]]
            - sandbox: Dict[str, Any] (platform, limits_applied, notes)
    """
    start_time = time.perf_counter()

    # Pre-clean BOM if present
    if isinstance(code, str) and code.startswith("\ufeff"):
        code = code[1:]

    temp_dir = tempfile.mkdtemp(prefix="sb_run_")
    nonce = secrets.token_hex(16)
    job_handle: Optional[int] = None

    # Flags to record termination causes
    flag_timeout = False
    flag_memory_exceeded = False
    flag_output_limit = False

    limits_applied = {
        "timeout_sec": timeout,
        "memory_mb": memory_mb,
        "max_output_kb": max_output_kb,
        "cpu_seconds": cpu_seconds
    }
    sandbox_notes: List[str] = []

    # Scrubbed environment (NEVER pass host secrets, LLM keys, or arbitrary env)
    sandbox_env = {
        "SYSTEMROOT": os.environ.get("SYSTEMROOT", r"C:\Windows"),
        "PATH": os.environ.get("PATH", r"C:\Windows\System32"),
        "PATHEXT": os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD"),
        "WINDIR": os.environ.get("WINDIR", r"C:\Windows"),
        "TEMP": temp_dir,
        "TMP": temp_dir,
        "PYTHONUNBUFFERED": "1"
    }

    # Inject decoy canary honeypot tokens into sandbox environment and workspace
    active_canaries: Optional[Dict[str, Any]] = None
    try:
        from security import canary
        active_canaries = canary.setup_sandbox_canaries(temp_dir, sandbox_env)
        sandbox_notes.append("Canary honeypot active")
    except Exception:
        pass

    code_file = os.path.join(temp_dir, "user_code.py")
    try:
        with open(code_file, "w", encoding="utf-8", newline="") as f:
            f.write(code)
    except Exception as e:
        _cleanup_dir_with_retry(temp_dir)
        return {
            "status": "sandbox_failure",
            "stdout": "",
            "stderr": f"Failed to write sandbox code file: {e}",
            "exit_code": None,
            "duration_ms": (time.perf_counter() - start_time) * 1000.0,
            "peak_memory_mb": 0.0,
            "error": {
                "error_type": "SandboxFailure",
                "error_message": f"Failed to write sandbox code file: {e}",
                "line_number": None,
                "traceback": ""
            },
            "violations": [],
            "sandbox": {
                "platform": sys.platform,
                "limits_applied": limits_applied,
                "notes": "Failed before process start"
            }
        }

    child_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sandbox_child.py")
    python_exe = _test_python_bin
    is_frozen = getattr(sys, 'frozen', False)

    if not python_exe:
        if is_frozen:
            # Prefer real system Python to bypass PyInstaller startup overhead
            real_python = shutil.which("python") or shutil.which("python3") or shutil.which("py")
            if real_python:
                python_exe = real_python
                cmd = [
                    python_exe,
                    "-I",
                    "-X", "utf8",
                    child_script,
                    f"--nonce={nonce}",
                    f"--sandbox-dir={temp_dir}",
                    f"--mode=single",
                    f"--code-file={code_file}"
                ]
            else:
                # Fallback to frozen executable (handled by fast-path intercept in desktop_app.py)
                python_exe = sys.executable
                cmd = [
                    python_exe,
                    child_script,
                    f"--nonce={nonce}",
                    f"--sandbox-dir={temp_dir}",
                    f"--mode=single",
                    f"--code-file={code_file}"
                ]
        else:
            python_exe = sys.executable
            cmd = [
                python_exe,
                "-I",
                "-X", "utf8",
                child_script,
                f"--nonce={nonce}",
                f"--sandbox-dir={temp_dir}",
                f"--mode=single",
                f"--code-file={code_file}"
            ]
    else:
        cmd = [
            python_exe,
            "-I",
            "-X", "utf8",
            child_script,
            f"--nonce={nonce}",
            f"--sandbox-dir={temp_dir}",
            f"--mode=single",
            f"--code-file={code_file}"
        ]

    proc: Optional[subprocess.Popen] = None
    try:
        creation_flags = 0
        startup_info = None
        if _IS_WINDOWS:
            creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
            startup_info = subprocess.STARTUPINFO()
            startup_info.dwFlags |= getattr(subprocess, "STARTF_USESHOWWINDOW", 0x00000001)
            startup_info.wShowWindow = 0  # SW_HIDE

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            cwd=temp_dir,
            env=sandbox_env,
            creationflags=creation_flags,
            startupinfo=startup_info
        )
    except Exception as e:
        _cleanup_dir_with_retry(temp_dir)
        return {
            "status": "sandbox_failure",
            "stdout": "",
            "stderr": f"Failed to spawn sandbox child: {e}",
            "exit_code": None,
            "duration_ms": (time.perf_counter() - start_time) * 1000.0,
            "peak_memory_mb": 0.0,
            "error": {
                "error_type": "SandboxFailure",
                "error_message": f"Failed to spawn sandbox child: {e}",
                "line_number": None,
                "traceback": ""
            },
            "violations": [],
            "sandbox": {
                "platform": sys.platform,
                "limits_applied": limits_applied,
                "notes": "Child spawn failed"
            }
        }

    # Apply Windows Job Object limits
    if _IS_WINDOWS:
        job_handle, job_ok, job_note = _create_and_assign_job_object(
            int(proc._handle),
            memory_mb,
            cpu_seconds
        )
        sandbox_notes.append(job_note)
    else:
        sandbox_notes.append("POSIX environment")

    # Threaded output readers with capacity caps
    max_bytes = max_output_kb * 1024
    stdout_chunks: List[bytes] = []
    stderr_chunks: List[bytes] = []
    total_bytes_read = [0]
    read_lock = threading.Lock()

    def _reader_thread(pipe: io.RawIOBase, chunk_list: List[bytes]) -> None:
        nonlocal flag_output_limit
        try:
            while True:
                chunk = pipe.read(4096)
                if not chunk:
                    break
                with read_lock:
                    total_bytes_read[0] += len(chunk)
                    if total_bytes_read[0] > max_bytes:
                        flag_output_limit = True
                        if proc and proc.pid:
                            _kill_process_tree(proc.pid)
                        break
                    chunk_list.append(chunk)
        except Exception:
            pass
        finally:
            try:
                pipe.close()
            except Exception:
                pass

    t_out = threading.Thread(target=_reader_thread, args=(proc.stdout, stdout_chunks), daemon=True)
    t_err = threading.Thread(target=_reader_thread, args=(proc.stderr, stderr_chunks), daemon=True)
    t_out.start()
    t_err.start()

    # Memory watchdog thread
    peak_rss_bytes = [0]
    stop_watchdog = threading.Event()

    def _memory_watchdog() -> None:
        nonlocal flag_memory_exceeded
        limit_bytes = memory_mb * 1024 * 1024
        while not stop_watchdog.is_set():
            try:
                if proc and proc.pid:
                    p = psutil.Process(proc.pid)
                    mem_info = p.memory_info()
                    rss = mem_info.rss
                    for ch in p.children(recursive=True):
                        try:
                            rss += ch.memory_info().rss
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass
                    if rss > peak_rss_bytes[0]:
                        peak_rss_bytes[0] = rss
                    if rss > limit_bytes:
                        flag_memory_exceeded = True
                        _kill_process_tree(proc.pid)
                        break
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                break
            except Exception:
                pass
            time.sleep(0.05)

    t_mem = threading.Thread(target=_memory_watchdog, daemon=True)
    t_mem.start()

    # Wait for process completion under timeout
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        flag_timeout = True
        if proc.pid:
            _kill_process_tree(proc.pid)
        try:
            proc.wait(timeout=1.0)
        except Exception:
            pass
    finally:
        stop_watchdog.set()
        t_out.join(timeout=1.0)
        t_err.join(timeout=1.0)
        t_mem.join(timeout=0.5)

    duration_ms = (time.perf_counter() - start_time) * 1000.0
    peak_memory_mb = round(peak_rss_bytes[0] / (1024.0 * 1024.0), 2)

    # Reconstruct stdout and stderr strings
    raw_stdout_bytes = b"".join(stdout_chunks)
    raw_stderr_bytes = b"".join(stderr_chunks)

    stdout_str = raw_stdout_bytes.decode("utf-8", errors="replace")
    stderr_str = raw_stderr_bytes.decode("utf-8", errors="replace")

    # Parse structured result channel from stderr (handling both \n and \r\n)
    child_report: Optional[Dict[str, Any]] = None
    delimiter = f"---SANDBOX_RESULT_{nonce}---"
    pattern = re.compile(rf"(?:\r?\n)?{re.escape(delimiter)}\r?\n(.*?)\r?\n{re.escape(delimiter)}(?:\r?\n)?", re.DOTALL)
    match = pattern.search(stderr_str)

    if match:
        json_payload = match.group(1).strip()
        try:
            child_report = json.loads(json_payload)
            # Remove delimited block from visible stderr
            stderr_str = pattern.sub("", stderr_str).strip()
        except Exception:
            child_report = None

    # Derive final status and error IR
    final_status = "ok"
    error_data: Optional[Dict[str, Any]] = None
    violations_data: List[Dict[str, str]] = []
    exit_code = proc.returncode

    if flag_timeout:
        final_status = "timeout"
        exit_code = None
        error_data = {
            "error_type": "TimeoutError",
            "error_message": f"Execution timed out ({timeout}s limit exceeded)",
            "line_number": None,
            "traceback": f"TimeoutError: Execution timed out ({timeout}s limit exceeded)"
        }
    elif flag_memory_exceeded:
        final_status = "memory_exceeded"
        exit_code = None
        error_data = {
            "error_type": "MemoryError",
            "error_message": f"Memory limit exceeded ({memory_mb} MB limit)",
            "line_number": None,
            "traceback": f"MemoryError: Memory limit exceeded ({memory_mb} MB limit)"
        }
    elif flag_output_limit:
        final_status = "output_limit"
        exit_code = None
        error_data = {
            "error_type": "OutputLimitExceeded",
            "error_message": f"Output limit exceeded ({max_output_kb} KB cap)",
            "line_number": None,
            "traceback": f"OutputLimitExceeded: Output exceeded {max_output_kb} KB limit"
        }
    elif child_report:
        final_status = child_report.get("status", "ok")
        error_data = child_report.get("error")
        violations_data = child_report.get("violations", [])
        exit_code = child_report.get("exit_code", proc.returncode)
    else:
        # Fallback if no child report block was recovered
        if proc.returncode != 0:
            final_status = "error"
            # Extract error information from stderr
            err_type = "Exception"
            err_msg = ""
            non_empty = [l.strip() for l in stderr_str.splitlines() if l.strip()]
            if non_empty:
                exc_idx = len(non_empty) - 1
                for idx, l in enumerate(non_empty):
                    if not l.startswith("File ") and not l.startswith("Traceback") and ":" in l:
                        first_token = l.split(":", 1)[0].strip()
                        if re.match(r"^[a-zA-Z_][a-zA-Z0-9_.]*$", first_token):
                            exc_idx = idx
                            break
                target_line = non_empty[exc_idx]
                if ":" in target_line:
                    parts = target_line.split(":", 1)
                    err_type = parts[0].strip()
                    err_msg = parts[1].strip()
                else:
                    err_type = target_line

            line_no = None
            tb_lines = [l for l in stderr_str.splitlines() if "line" in l]
            if tb_lines:
                m = re.search(r"line\s+(\d+)", tb_lines[-1])
                if m:
                    line_no = int(m.group(1))

            error_data = {
                "error_type": err_type,
                "error_message": err_msg,
                "line_number": line_no,
                "traceback": stderr_str
            }

    # Check for canary honeypot leaks or violations
    canary_leak = None
    if active_canaries:
        try:
            from security import canary
            canary_leak = canary.detect_canary_leak(stdout_str) or canary.detect_canary_leak(stderr_str)
        except Exception:
            pass

    has_canary_violation = any(v.get("kind") == "canary_trap_triggered" for v in violations_data)
    if canary_leak or has_canary_violation:
        final_status = "violation"
        detail_msg = canary_leak["detail"] if canary_leak else "Canary honeypot access detected"
        if not has_canary_violation:
            violations_data.append({
                "kind": "canary_trap_triggered",
                "detail": detail_msg
            })
        try:
            from security import canary
            canary.trigger_canary_alert(
                event_type="SandboxHoneypotTriggered",
                detail=detail_msg,
                evidence=stdout_str[:256] if stdout_str else stderr_str[:256]
            )
        except Exception:
            pass

    # Resource cleanup
    if _IS_WINDOWS and job_handle:
        try:
            ctypes.windll.kernel32.CloseHandle(job_handle)
        except Exception:
            pass

    _cleanup_dir_with_retry(temp_dir)

    return {
        "status": final_status,
        "stdout": stdout_str,
        "stderr": stderr_str,
        "exit_code": exit_code,
        "duration_ms": round(duration_ms, 2),
        "peak_memory_mb": peak_memory_mb,
        "error": error_data,
        "violations": violations_data,
        "sandbox": {
            "platform": sys.platform,
            "limits_applied": limits_applied,
            "notes": "; ".join(sandbox_notes)
        }
    }
