#!/usr/bin/env python3
"""Rebuild Agentic_C 2.0 performance figures from captured strict-run JSON."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
NAMES = ["hft_strategy", "market_maker", "order_book_engine", "enterprise_hft_engine"]
LABELS = {
    "hft_strategy": "HFT strategy",
    "market_maker": "Market maker",
    "order_book_engine": "Order book engine",
    "enterprise_hft_engine": "Enterprise HFT engine",
}
BLUE = "#2367A6"
ORANGE = "#D97729"
GREEN = "#248277"
RED = "#B85050"
INK = "#203040"
MUTED = "#5B6B7A"
GRID = "#D9E0E7"

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": GRID,
    "axes.labelcolor": INK,
    "axes.titlecolor": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "text.color": INK,
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "axes.labelsize": 10,
    "legend.frameon": False,
    "savefig.facecolor": "white",
})


def load_data():
    return {name: json.loads((ROOT / f"{name}.json").read_text(encoding="utf-8")) for name in NAMES}


def measured(data):
    return data.get("measured") or {}


def pct_drop(base, cand):
    return (base - cand) / base * 100 if base else float("nan")


def save(fig, name):
    fig.savefig(ROOT / name, dpi=220, bbox_inches="tight")
    plt.close(fig)


def figure_medians(data):
    fig, ax = plt.subplots(figsize=(11, 6.2))
    y = np.arange(len(NAMES))
    height = 0.34
    for offset, key, color, label in [
        (-height / 2, "baseline_ns", BLUE, "Baseline executable"),
        (height / 2, "candidate_ns", ORANGE, "Accepted candidate"),
    ]:
        vals, low, high, ys, text_x, text_y = [], [], [], [], [], []
        for i, name in enumerate(NAMES):
            if not measured(data[name]):
                continue
            stats = measured(data[name])[key]
            vals.append(stats["median"] / 1e6)
            low.append((stats["median"] - stats["min"]) / 1e6)
            high.append((stats["max"] - stats["median"]) / 1e6)
            ys.append(i + offset)
            text_x.append(stats["max"] / 1e6 + 0.055)
            text_y.append(i + offset)
        marker = "o" if key == "baseline_ns" else "s"
        ax.errorbar(vals, ys, xerr=np.array([low, high]), fmt=marker, color=color, ecolor=INK,
                    markersize=7, capsize=4, elinewidth=1.3, linewidth=1.3, label=label, zorder=3)
        for tx, ty, value in zip(text_x, text_y, vals):
            ax.text(tx, ty, f"median {value:.3f}", va="center", ha="left", fontsize=8.5, color=INK)
    ax.set_yticks(y, [LABELS[n] for n in NAMES])
    ax.invert_yaxis()
    ax.set_xlabel("Process wall time per executable run (ms; includes process launch)")
    ax.set_title("Measured baseline vs accepted candidate (median markers, min–max ranges)")
    ax.set_xlim(0, 3.45)
    ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
    ax.text(0.15, len(NAMES)-1, "No candidate accepted; not measured", va="center", ha="left",
            fontsize=9, color=RED, fontweight="bold")
    fig.text(0.12, 0.015, "Blue circles = baseline; orange squares = accepted candidate. Five trials per version after one warm-up. Enterprise HFT candidates failed validation and were reverted.", ha="left", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "01-measured-before-after.png")


def figure_trial_profiles(data):
    names = [n for n in NAMES if measured(data[n])]
    fig, axes = plt.subplots(1, len(names), figsize=(14, 4.7), sharey=True)
    if len(names) == 1:
        axes = [axes]
    for ax, name in zip(axes, names):
        m = measured(data[name])
        x = np.arange(1, len(m["baseline_ns"]["samples"]) + 1)
        for key, color, label, marker in [
            ("baseline_ns", BLUE, "Baseline", "o"),
            ("candidate_ns", ORANGE, "Candidate", "s"),
        ]:
            samples = np.array(m[key]["samples"]) / 1e6
            ax.plot(x, samples, color=color, marker=marker, linewidth=1.8, markersize=5, label=label)
        ax.set_title(LABELS[name])
        ax.set_xlabel("Sorted sample rank\n(fastest to slowest)")
        ax.set_xticks(x)
        ax.grid(axis="y", color=GRID, linewidth=0.8)
    axes[0].set_ylabel("Executable process time (ms)")
    handles, legend_labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 0.93))
    fig.suptitle("Five measured runs per version", x=0.5, y=1.02, fontsize=14, fontweight="bold")
    fig.text(0.1, -0.04,
             "Samples are sorted before saving by the validator; x-axis is rank, not chronology. The candidate and baseline ranges overlap in every example.",
             ha="left", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.06, 1, 0.85))
    save(fig, "02-five-run-profiles.png")


def figure_observed_delta(data):
    names = [n for n in NAMES if measured(data[n])]
    vals = []
    for name in names:
        m = measured(data[name])
        vals.append(pct_drop(m["baseline_ns"]["median"], m["candidate_ns"]["median"]))
    fig, ax = plt.subplots(figsize=(9, 4.8))
    y = np.arange(len(names))
    colors = [GREEN if v >= 0 else RED for v in vals]
    bars = ax.barh(y, vals, color=colors, height=0.52, zorder=2)
    ax.axvline(0, color=INK, linewidth=1.1)
    for bar, v in zip(bars, vals):
        xpos = v + (0.12 if v >= 0 else -0.12)
        ax.text(xpos, bar.get_y() + bar.get_height()/2, f"{v:+.2f}%", va="center",
                ha="left" if v >= 0 else "right", fontsize=10, fontweight="bold")
    ax.set_yticks(y, [LABELS[n] for n in names])
    ax.invert_yaxis()
    ax.set_xlabel("Observed change in median process time (%)\nPositive = candidate median was faster")
    ax.set_title("Median change by example")
    ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
    fig.text(0.12, 0.015,
             "Descriptive comparison only: five trials per version, overlapping min–max ranges, no significance claim. Enterprise example had no accepted candidate to time.",
             ha="left", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, "03-observed-median-change.png")


def figure_model_estimates(data):
    names = NAMES
    vals = [data[n].get("cost_model_estimate", {}).get("latency_reduction_pct") for n in names]
    fig, ax = plt.subplots(figsize=(9, 4.8))
    y = np.arange(len(names))
    bars = ax.barh(y, vals, color="#8D7AAE", height=0.56)
    for bar, v in zip(bars, vals):
        ax.text(v + 0.6, bar.get_y() + bar.get_height()/2, f"{v:.1f}%", va="center", fontsize=10)
    ax.set_yticks(y, [LABELS[n] for n in names])
    ax.invert_yaxis()
    ax.set_xlim(0, max(vals) + 10)
    ax.set_xlabel("Cost-model latency reduction estimate (%)")
    ax.set_title("Agent cost-model output — estimates only")
    ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
    fig.text(0.12, 0.015,
             "Not measured execution speedup. These model estimates must not be combined with the process-time measurements in Figures 1–3.",
             ha="left", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, "04-cost-model-estimates-only.png")


def figure_pipeline_time(data):
    stages = ["clang_frontend", "security_analysis", "boss_agent", "agent_chains", "policy_gate_validation", "codegen", "experience_store"]
    labels = {
        "clang_frontend": "Clang frontend", "security_analysis": "Security analysis",
        "boss_agent": "Boss agent", "agent_chains": "Agent chains",
        "policy_gate_validation": "Policy + validation", "codegen": "Code generation",
        "experience_store": "Experience store",
    }
    colors = [BLUE, "#76A5C9", "#9C8CBA", ORANGE, RED, GREEN, "#92A65B"]
    fig, ax = plt.subplots(figsize=(11, 5.3))
    y = np.arange(len(NAMES))
    left = np.zeros(len(NAMES))
    for stage, color in zip(stages, colors):
        vals = np.array([data[n].get("stage_times", {}).get(stage, 0.0) / 1000 for n in NAMES])
        ax.barh(y, vals, left=left, color=color, label=labels[stage], height=0.58)
        left += vals
    for i, total in enumerate(left):
        ax.text(total + max(left) * 0.012, i, f"{total:.2f} s", va="center", fontsize=9, color=INK)
    ax.set_yticks(y, [LABELS[n] for n in NAMES])
    ax.invert_yaxis()
    ax.set_xlabel("Pipeline stage wall time (seconds)")
    ax.set_title("End-to-end compilation and agent overhead")
    ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
    ax.legend(loc="lower right", ncol=2, fontsize=8)
    fig.text(0.12, 0.015,
             "Compile-pipeline duration, not executable runtime. Enterprise HFT spent most time in agent/validation retries after candidate behavior mismatches.",
             ha="left", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, "05-pipeline-runtime-breakdown.png")


def figure_gate_counts(data):
    accepted, rejected, unexecuted = [], [], []
    for name in NAMES:
        attempts = data[name].get("optimization_attempts", [])
        accepted.append(sum(bool(a.get("accepted")) for a in attempts))
        rejected.append(sum(bool(a.get("executed")) and not a.get("accepted") for a in attempts))
        unexecuted.append(sum(not a.get("executed") for a in attempts))
    fig, ax = plt.subplots(figsize=(10, 5.0))
    y = np.arange(len(NAMES))
    ax.barh(y, accepted, color=GREEN, label="Accepted and validated", height=0.55)
    ax.barh(y, rejected, left=accepted, color=RED, label="Executed, then rejected", height=0.55)
    ax.barh(y, unexecuted, left=np.array(accepted) + np.array(rejected), color="#A8B2BD", label="Not executed", height=0.55)
    for i, (a, r, u) in enumerate(zip(accepted, rejected, unexecuted)):
        ax.text(a + r + u + 0.15, i, f"{a} accepted | {r} rejected | {u} not run", va="center", fontsize=8.5)
    ax.set_yticks(y, [LABELS[n] for n in NAMES])
    ax.invert_yaxis()
    ax.set_xlabel("Optimization pass attempts")
    ax.set_title("Candidate validation outcomes")
    ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
    ax.set_xlim(0, max(accepted[i] + rejected[i] + unexecuted[i] for i in range(len(NAMES))) + 9)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=3, fontsize=8)
    fig.text(0.12, 0.015,
             "Enterprise HFT: 10 behavior/execution validation rejections plus one LLVM pass failure; no candidate was accepted, so no runtime comparison is reported.",
             ha="left", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    save(fig, "06-candidate-validation-outcomes.png")


def write_csv(data):
    path = ROOT / "timing-samples.csv"
    fields = ["example", "version", "sample_rank_fast_to_slow", "process_time_ns", "process_time_ms", "median_ns", "min_ns", "max_ns", "trials", "warmups", "compiler", "compile_flags"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for name in NAMES:
            m = measured(data[name])
            if not m:
                continue
            env = m.get("environment", {})
            for key, version in [("baseline_ns", "baseline"), ("candidate_ns", "candidate")]:
                s = m[key]
                for rank, ns in enumerate(s["samples"], 1):
                    writer.writerow({
                        "example": name, "version": version, "sample_rank_fast_to_slow": rank,
                        "process_time_ns": ns, "process_time_ms": ns / 1e6,
                        "median_ns": s["median"], "min_ns": s["min"], "max_ns": s["max"],
                        "trials": m.get("trial_runs"), "warmups": m.get("warmup_runs"),
                        "compiler": env.get("compiler_version"),
                        "compile_flags": " ".join(env.get("compile_flags", [])),
                    })


def write_report(data):
    lines = [
        "# AGentic_C 2.0 performance analysis",
        "",
        "Strict real-IR runs across all four C++ examples in `examples/`. This report distinguishes executable measurements from the pipeline's latency cost-model estimates.",
        "",
        "## Measured executable timings",
        "",
        "The validator compiled a baseline executable and an accepted candidate executable, performed one warm-up, then took five wall-clock process timings per version. The current validator sorts the five measurements and reports their median/min/max. Timings include process startup, so they are not nanosecond-level HFT hot-loop timings.",
        "",
        "| Example | Baseline median (ms) | Candidate median (ms) | Candidate median change | Baseline min–max (ms) | Candidate min–max (ms) | Accepted/rejected attempts |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for name in NAMES:
        d = data[name]
        m = measured(d)
        a = sum(bool(x.get("accepted")) for x in d.get("optimization_attempts", []))
        r = sum(bool(x.get("executed")) and not x.get("accepted") for x in d.get("optimization_attempts", []))
        if m:
            b, c = m["baseline_ns"], m["candidate_ns"]
            lines.append(f"| {LABELS[name]} | {b['median']/1e6:.4f} | {c['median']/1e6:.4f} | {pct_drop(b['median'],c['median']):+.2f}% | {b['min']/1e6:.4f}–{b['max']/1e6:.4f} | {c['min']/1e6:.4f}–{c['max']/1e6:.4f} | {a}/{r} |")
        else:
            lines.append(f"| {LABELS[name]} | — | — | Not measured | — | — | {a}/{r} |")
    lines += [
        "",
        "Three examples have accepted candidates with five measured trials. Their median changes are descriptive only, and the observed baseline and candidate ranges overlap. Do not describe these data as a statistically established speedup.",
        "",
        "The enterprise example produced no accepted candidate: ten attempted candidates failed behavior/execution validation and one pass failed in LLVM. The fail-closed pipeline reverted them. Its runtime result is therefore missing by design, not zero and not a valid performance comparison.",
        "",
        "## Cost-model estimates (not measurements)",
        "",
        "| Example | Estimated latency reduction |",
        "|---|---:|",
    ]
    for name in NAMES:
        estimate = data[name].get("cost_model_estimate", {}).get("latency_reduction_pct")
        lines.append(f"| {LABELS[name]} | {estimate:.1f}% |" if estimate is not None else f"| {LABELS[name]} | — |")
    lines += [
        "",
        "These numbers are generated by the agent latency cost model. They are not measured runtime improvements and are intentionally shown in their own figure.",
        "",
        "## Run conditions and interpretation",
        "",
        "- Sources: `examples/hft_strategy.cpp`, `examples/market_maker.cpp`, `examples/order_book_engine.cpp`, and `examples/enterprise_hft_engine.cpp`.",
        "- Each run used real Clang/LLVM IR on macOS Apple M5, Homebrew Clang/LLVM 23.1.5, and the active macOS SDK. The validator reports `-O0` frontend/codegen with individually allowlisted LLVM passes.",
        "- Behavior validation uses configured finite fixtures. Passing those fixtures is not a formal equivalence proof; an enterprise example mismatch prevented timing a candidate.",
        "- End-to-end pipeline time includes agent execution and validation and is not application runtime. It shows the cost of the compiler workflow, not a baseline-vs-candidate execution comparison.",
        "- A previous report's generated chart script contains fixed latency/reward arrays. Those values were not used in these figures.",
        "",
        "## Figures",
        "",
        "1. `01-measured-before-after.png`: median baseline/candidate process times with observed min–max whiskers.",
        "2. `02-five-run-profiles.png`: sorted five-sample profiles by example.",
        "3. `03-observed-median-change.png`: median process-time change per measured example.",
        "4. `04-cost-model-estimates-only.png`: estimated improvements, explicitly separate from measured timings.",
        "5. `05-pipeline-runtime-breakdown.png`: end-to-end pipeline stage durations.",
        "6. `06-candidate-validation-outcomes.png`: pass acceptance/rejection counts.",
        "",
        "## Figure gallery",
        "",
        "### Measured before and after",
        "",
        "![Measured executable before/after medians and observed ranges](01-measured-before-after.png)",
        "",
        "### Five-trial profiles",
        "",
        "![Five trial profiles for the three measured examples](02-five-run-profiles.png)",
        "",
        "### Observed median change",
        "",
        "![Observed median process-time change by example](03-observed-median-change.png)",
        "",
        "### Cost-model estimates",
        "",
        "![Cost-model estimates, not measured runtime speedups](04-cost-model-estimates-only.png)",
        "",
        "### Pipeline time and validation results",
        "",
        "![End-to-end compilation pipeline timing breakdown](05-pipeline-runtime-breakdown.png)",
        "",
        "![Candidate validation outcomes per example](06-candidate-validation-outcomes.png)",
        "",
        "## Security evaluation",
        "",
        "The separate security evaluation, including Attack Lab detection quality, scanner overhead, and fail-closed pass-gate outcomes, is documented in [`security/README.md`](security/README.md). It is a current-prototype evaluation; no pre-enhancement security baseline was recorded.",
        "",
        "Raw measured samples are in `timing-samples.csv`; exact run JSON and logs are kept alongside this report. Rerun `make_figures.py` with Matplotlib to regenerate the PNGs.",
    ]
    (ROOT / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    data = load_data()
    figure_medians(data)
    figure_trial_profiles(data)
    figure_observed_delta(data)
    figure_model_estimates(data)
    figure_pipeline_time(data)
    figure_gate_counts(data)
    write_csv(data)
    write_report(data)
    print("Generated 6 figures, timing-samples.csv, and README.md in", ROOT)


if __name__ == "__main__":
    main()
