#!/usr/bin/env python3
"""Generate security enhancement quality, gate, and overhead figures."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
VISIBLE_PATH = ROOT / "evidence/macos/attack_lab_visible.json"
HELDOUT_PATH = ROOT / "evidence/macos/attack_lab_heldout.json"
EXAMPLES = ["hft_strategy", "market_maker", "order_book_engine", "enterprise_hft_engine"]
LABELS = {
    "hft_strategy": "HFT strategy",
    "market_maker": "Market maker",
    "order_book_engine": "Order book engine",
    "enterprise_hft_engine": "Enterprise HFT engine",
}
PALETTE = {"visible": "#2679A5", "heldout": "#C67634"}
BLUE, ORANGE, GREEN, RED, PURPLE = "#2679A5", "#C67634", "#2B8171", "#B45050", "#8874A8"
INK, MUTED, GRID = "#203040", "#5B6B7A", "#D9E0E7"

plt.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.edgecolor": GRID, "axes.labelcolor": INK, "axes.titlecolor": INK,
    "xtick.color": MUTED, "ytick.color": MUTED, "text.color": INK,
    "font.family": "DejaVu Sans", "font.size": 10,
    "axes.titlesize": 13, "axes.titleweight": "bold",
    "axes.labelsize": 10, "legend.frameon": False, "savefig.facecolor": "white",
})


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(fig, filename):
    fig.savefig(HERE / filename, dpi=220, bbox_inches="tight")
    plt.close(fig)


def make_confusion_matrices(visible, heldout):
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 4.8))
    for ax, label, report in zip(axes, ["Visible demo", "Held-out check"], [visible, heldout]):
        m = report["metrics"]
        matrix = np.array([[m["tp"], m["fn"]], [m["fp"], m["tn"]]])
        ax.imshow(matrix, cmap="Blues", vmin=0, vmax=max(1, int(matrix.max())))
        ax.set_xticks([0, 1], ["Flagged", "No match"])
        ax.set_yticks([0, 1], ["Malicious", "Benign"])
        ax.set_xlabel("Scanner verdict")
        ax.set_ylabel("Expected label")
        ax.set_title(f"{label} (n={m['scenario_count']})")
        for row in range(2):
            for col in range(2):
                text = f"{matrix[row, col]}\n" + [["TP", "FN"], ["FP", "TN"]][row][col]
                color = "white" if matrix[row, col] > matrix.max() * 0.54 else INK
                ax.text(col, row, text, ha="center", va="center", fontsize=12, fontweight="bold", color=color)
    fig.suptitle("Attack Lab classification outcomes", fontsize=14, fontweight="bold")
    fig.text(0.08, 0.015, "Each cell shows count and outcome type. Cases are hand-built; agent actions and blocking are simulated.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 0.94))
    save(fig, "01-attacklab-confusion-matrices.png")


def make_quality_metrics(visible, heldout):
    metrics = ["precision_pct", "recall_pct", "f1_pct"]
    labels = ["Precision", "Recall", "F1"]
    x = np.arange(len(metrics))
    width = 0.33
    fig, ax = plt.subplots(figsize=(9, 5.2))
    for offset, name, report, color in [(-width/2, "Visible (48 cases)", visible, BLUE), (width/2, "Held-out (8 cases)", heldout, ORANGE)]:
        vals = [report["metrics"][key] for key in metrics]
        bars = ax.bar(x + offset, vals, width, color=color, label=name)
        for rect, val, key in zip(bars, vals, metrics):
            m = report["metrics"]
            fraction = {"precision_pct": m["precision_fraction"], "recall_pct": m["recall_fraction"], "f1_pct": "derived"}[key]
            ax.text(rect.get_x()+rect.get_width()/2, val+2.5, f"{val:.1f}%\n{fraction}", ha="center", va="bottom", fontsize=8)
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 125)
    ax.set_ylabel("Percent")
    ax.set_title("Detection quality: visible set vs held-out check")
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.legend(loc="upper right")
    fig.text(0.11, 0.015, "Held-out precision is 1/1 flagged case; recall is 1/7 attacks. The 100% precision result is too small to treat as stable.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "02-detection-quality-metrics.png")


def make_category_recall(visible):
    categories = visible["categories"]
    rows = visible["scenarios"]
    recalls, counts = [], []
    for category in categories:
        attacks = [row for row in rows if row["category"] == category and row["expected_label"] == "malicious"]
        tp = sum(row["outcome"] == "TP" for row in attacks)
        recalls.append(tp / len(attacks) * 100 if attacks else 0)
        counts.append(f"{tp}/{len(attacks)}")
    short_labels = [
        "Benign-but-suspicious", "Dangerous code generation", "Dependency attacks",
        "Indirect prompt injection", "Obfuscated payloads", "Path traversal / file access",
        "Secret / credential exfiltration", "Tool-call / privilege abuse",
    ]
    order = np.argsort(recalls)
    fig, ax = plt.subplots(figsize=(10.2, 6.3))
    y = np.arange(len(categories))
    bars = ax.barh(y, [recalls[i] for i in order], color=[RED if recalls[i] == 0 else BLUE for i in order], height=0.64)
    for bar, i in zip(bars, order):
        ax.text(max(2, recalls[i])+1.5, bar.get_y()+bar.get_height()/2, f"{recalls[i]:.0f}% ({counts[i]})", va="center", fontsize=9)
    ax.set_yticks(y, [short_labels[i] for i in order])
    ax.set_xlim(0, 78)
    ax.set_xlabel("Detected malicious cases / malicious cases in category (%)")
    ax.set_title("Visible-set attack detection by category")
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    fig.text(0.12, 0.015, "Each visible category has four malicious and two benign cases. Zero detection in a category is a concrete coverage gap in this authored set.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "03-visible-category-recall.png")


def make_enforcement(visible, heldout):
    reports = [visible, heldout]
    names = ["Visible demo", "Held-out check"]
    x = np.arange(2)
    detected, blocked, attacks = [], [], []
    for report in reports:
        m = report["metrics"]
        attacks.append(m["attack_count"])
        detected.append(m["tp"])
        blocked.append(int(m["block_fraction"].split("/")[0]))
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    w = 0.34
    for offset, vals, color, label in [(-w/2, detected, BLUE, "Detected (TP)"), (w/2, blocked, RED, "Marked blocked")]:
        bars = ax.bar(x+offset, [v/a*100 for v,a in zip(vals, attacks)], w, color=color, label=label)
        for bar, val, total in zip(bars, vals, attacks):
            pct = val/total*100
            ax.text(bar.get_x()+bar.get_width()/2, pct+1.8, f"{val}/{total}\n{pct:.1f}%", ha="center", va="bottom", fontsize=8.5)
    ax.set_xticks(x, [f"{n}\n(n={a} attacks)" for n,a in zip(names, attacks)])
    ax.set_ylim(0, 50)
    ax.set_ylabel("Share of malicious scenarios (%)")
    ax.set_title("Detection does not always result in a block")
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.legend(loc="upper right")
    fig.text(0.1, 0.015, "Blocking in Attack Lab is simulated for agent traces. The prototype does not provide a general live tool/file/network firewall.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "04-detection-vs-simulated-blocking.png")


def make_scanner_latency(evaluation):
    rows = evaluation["scanner"]
    fig, ax = plt.subplots(figsize=(9.4, 5.2))
    y = np.arange(len(rows))
    med = np.array([row["timing"]["median_ns"]/1000 for row in rows])
    p95 = np.array([row["timing"]["p95_ns"]/1000 for row in rows])
    ax.hlines(y, med, p95, color=GRID, linewidth=6, zorder=1)
    ax.scatter(med, y, color=BLUE, s=70, marker="o", label="Median", zorder=3)
    ax.scatter(p95, y, color=ORANGE, s=70, marker="s", label="95th percentile", zorder=3)
    for i, row in enumerate(rows):
        ax.text(p95[i]+38, i, f"{med[i]:.0f} / {p95[i]:.0f} µs · {row['lines']} lines", va="center", fontsize=8.5)
    ax.set_yticks(y, [LABELS[row["example"].removesuffix(".cpp")] for row in rows])
    ax.invert_yaxis()
    ax.set_xlabel("Source + prompt-directive scan time (microseconds; warm-cache local run)")
    ax.set_title("Security scanner overhead by example")
    ax.set_xlim(0, max(p95)*1.72)
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.legend(loc="lower right")
    fig.text(0.12, 0.015, "100 timed scans per file after 10 warm-ups. Measures source and prompt-rule scans only; LLVM IR analysis and full pipeline are excluded.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "05-security-scanner-overhead.png")


def make_attacklab_cost(evaluation):
    names = ["visible", "heldout"]
    labels = ["Visible demo\n48 scenarios", "Held-out\n8 scenarios"]
    total_ms = [evaluation["attack_lab_execution_time"][name]["timing"]["median_ns"]/1e6 for name in names]
    per_case_us = [evaluation["attack_lab_execution_time"][name]["timing"]["median_ns"]/len(load_json(VISIBLE_PATH if name == "visible" else HELDOUT_PATH)["scenarios"])/1000 for name in names]
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.6))
    for ax, vals, unit, title, scale in [
        (axes[0], total_ms, "milliseconds", "Whole dataset", 1),
        (axes[1], per_case_us, "microseconds", "Per scenario", 1),
    ]:
        bars = ax.bar(np.arange(2), vals, color=[BLUE, ORANGE], width=0.55)
        for bar, value in zip(bars, vals):
            ax.text(bar.get_x()+bar.get_width()/2, value+max(vals)*0.04, f"{value:.2f}", ha="center", fontsize=9)
        ax.set_xticks([0,1], labels)
        ax.set_ylabel(unit)
        ax.set_title(title)
        ax.grid(axis="y", color=GRID, linewidth=0.8)
    fig.suptitle("Inert Attack Lab evaluation cost", fontsize=14, fontweight="bold")
    fig.text(0.1, 0.015, "50 timed evaluations per dataset after five warm-ups. Scenario strings are pattern-matched, never executed.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 0.92))
    save(fig, "06-attacklab-evaluation-time.png")


def make_gate_outcomes():
    data = {name: load_json(ROOT / f"performance_analysis/agentic-c-2.0/{name}.json") for name in EXAMPLES}
    accepted, rejected, not_run = [], [], []
    for name in EXAMPLES:
        attempts = data[name].get("optimization_attempts", [])
        accepted.append(sum(bool(a.get("accepted")) for a in attempts))
        rejected.append(sum(bool(a.get("executed")) and not a.get("accepted") for a in attempts))
        not_run.append(sum(not a.get("executed") for a in attempts))
    fig, ax = plt.subplots(figsize=(9.8, 5.0))
    y = np.arange(len(EXAMPLES))
    ax.barh(y, accepted, color=GREEN, label="Accepted after checks", height=0.56)
    ax.barh(y, rejected, left=accepted, color=RED, label="Executed then rejected", height=0.56)
    ax.barh(y, not_run, left=np.array(accepted)+np.array(rejected), color="#A8B2BD", label="Not executed", height=0.56)
    for i, (a,r,u) in enumerate(zip(accepted,rejected,not_run)):
        ax.text(a+r+u+0.12, i, f"{a} accepted | {r} rejected | {u} not run", va="center", fontsize=8.5)
    ax.set_yticks(y, [LABELS[name] for name in EXAMPLES])
    ax.invert_yaxis()
    ax.set_xlim(0, max(a+r+u for a,r,u in zip(accepted,rejected,not_run))+9)
    ax.set_xlabel("Allowlisted optimizer pass attempts")
    ax.set_title("Fail-closed candidate gate outcomes")
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=3, fontsize=8)
    fig.text(0.12, 0.015, "Enterprise HFT: 10 candidates failed behavior/execution validation and one LLVM pass failed; no candidate was accepted.", fontsize=8.5, color=MUTED)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "07-fail-closed-pass-gate.png")


def write_csv(evaluation):
    with (HERE / "security-scan-timings.csv").open("w", newline="", encoding="utf-8") as f:
        fields = ["example", "source_lines", "source_bytes", "finding_count", "trial", "scan_time_us"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in evaluation["scanner"]:
            for trial, ns in enumerate(row["timing"]["samples_ns"], 1):
                writer.writerow({"example": row["example"], "source_lines": row["lines"], "source_bytes": row["bytes"], "finding_count": row["finding_count"], "trial": trial, "scan_time_us": f"{ns/1000:.3f}"})


def write_readme(visible, heldout, evaluation):
    vm, hm = visible["metrics"], heldout["metrics"]
    lines = [
        "# AGentic_C 2.0 security enhancements: evaluation",
        "",
        "This report evaluates the added source/IR and prompt-directive scanner, Attack Lab, pass-policy gate, and candidate validation behavior. It reports measured scanner cost and scenario classification outcomes separately.",
        "",
        "> These figures are evaluation of the current prototype, not a before/after delta: the available evidence has no pre-enhancement security measurements.",
        "",
        "## Attack Lab quality results",
        "",
        "| Dataset | Cases | Malicious | TP | FP | FN | TN | Precision | Recall | F1 | Marked blocked |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for name, m in [("Visible demo", vm), ("Held-out", hm)]:
        block = m["block_rate_pct"]
        lines.append(f"| {name} | {m['scenario_count']} | {m['attack_count']} | {m['tp']} | {m['fp']} | {m['fn']} | {m['tn']} | {m['precision_pct']:.1f}% ({m['precision_fraction']}) | {m['recall_pct']:.1f}% ({m['recall_fraction']}) | {m['f1_pct']:.1f}% | {block:.1f}% ({m['block_fraction']}) |")
    lines += [
        "",
        "The visible data contains 48 authored scenarios (32 malicious, 16 benign). It detects 10/32 attacks and misses 22; there are seven false positives. The separate held-out set has only eight cases (seven malicious, one benign): the scanner detects one attack and misses six. Held-out precision is 1/1 and should not be read as evidence of reliable precision.",
        "",
        "The Attack Lab is an inert pattern-matching demonstration. Scenario strings are never executed, and agent tool traces/blocking are simulated. The prototype does not provide a general live file, network, or tool firewall.",
        "",
        "## Security scanner cost",
        "",
        "The source and prompt-directive rules were measured on the four bundled example files with 10 warm-ups and 100 timed calls per file. The scan includes local file reads with a warm OS cache and four source patterns plus three prompt-directive patterns. It excludes LLVM IR scanning, Clang, planner agents, subprocess behavior checks, and the dashboard.",
        "",
        "| Example | Source lines | Findings | Median (µs) | P95 (µs) |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in evaluation["scanner"]:
        t = row["timing"]
        lines.append(f"| {row['example']} | {row['lines']} | {row['finding_count']} | {t['median_ns']/1000:.2f} | {t['p95_ns']/1000:.2f} |")
    lines += [
        "",
        "All four files produced zero findings under these limited rules. The timing is a warm-cache local microbenchmark, not full compiler security-stage latency. The earlier end-to-end run recorded security-analysis stage times separately in the main performance report.",
        "",
        "## Attack Lab evaluation cost",
        "",
        "| Dataset | Scenarios | Median evaluation time | P95 | Median per scenario |",
        "|---|---:|---:|---:|---:|",
    ]
    for name, report, count in [("visible", visible, vm["scenario_count"]), ("heldout", heldout, hm["scenario_count"])]:
        t = evaluation["attack_lab_execution_time"][name]["timing"]
        lines.append(f"| {name} | {count} | {t['median_ns']/1e6:.3f} ms | {t['p95_ns']/1e6:.3f} ms | {t['median_ns']/count/1000:.1f} µs |")
    lines += [
        "",
        "Measured with 5 warm-ups and 50 evaluations per dataset. The scenario text is only matched against rules; nothing in the payload is run.",
        "",
        "## Candidate acceptance gate",
        "",
        "Each suggested optimizer pass is constrained by the allowlist and candidate pipeline: execute LLVM pass, verify IR, compile, compare configured behavior fixtures, then accept or fail closed. Across these four runs, 34 pass candidates were accepted and 11 executed candidates were rejected; the enterprise example supplied the 11 rejections and had no accepted candidate. This demonstrates gate behavior for these runs, not a general safety guarantee.",
        "",
        "The visible Attack Lab outcomes and held-out outcomes are separate from the compiler gate counts. Do not combine them into one security score.",
        "",
        "## Limits and evidence",
        "",
        "- The visible corpus is hand-built and small; category recall has four malicious cases per category.",
        "- The held-out set has eight cases and is not large enough to establish generalization. Its results are shown as an evaluation, not used to tune rules.",
        "- Pattern rules can miss indirect calls, obfuscated payloads, data-flow paths, and contextual instructions; false positives also occur.",
        "- No pre-enhancement metric baseline was recorded, so these figures cannot support a numerical claim that security improved by X% versus the seniors' version.",
        "- The existing 17-test suite log includes targeted tests for prompt guard/fail-closed behavior, allowlist rejection, path traversal variants, source rules, and Attack Lab loading. This report uses recorded evidence and does not rerun the suite.",
        "",
        "## Figures",
        "",
        "### Attack Lab outcomes",
        "",
        "![Visible and held-out confusion matrices](01-attacklab-confusion-matrices.png)",
        "",
        "![Precision, recall, and F1 by dataset](02-detection-quality-metrics.png)",
        "",
        "![Visible-set attack recall by category](03-visible-category-recall.png)",
        "",
        "![Attack detection versus simulated blocking](04-detection-vs-simulated-blocking.png)",
        "",
        "### Security processing cost and enforcement",
        "",
        "![Security scanner median and P95 overhead by source file](05-security-scanner-overhead.png)",
        "",
        "![Visible and held-out Attack Lab evaluation runtime](06-attacklab-evaluation-time.png)",
        "",
        "![Fail-closed optimizer pass gate outcomes](07-fail-closed-pass-gate.png)",
        "",
        "Raw timing samples are in `security-scan-timings.csv`; benchmark parameters and full samples are in `security-evaluation.json`. Rerun `benchmark_security.py` and `make_security_figures.py` to regenerate this analysis.",
    ]
    (HERE / "README.md").write_text("\n".join(lines)+"\n", encoding="utf-8")


def main():
    visible, heldout = load_json(VISIBLE_PATH), load_json(HELDOUT_PATH)
    evaluation = load_json(HERE / "security-evaluation.json")
    make_confusion_matrices(visible, heldout)
    make_quality_metrics(visible, heldout)
    make_category_recall(visible)
    make_enforcement(visible, heldout)
    make_scanner_latency(evaluation)
    make_attacklab_cost(evaluation)
    make_gate_outcomes()
    write_csv(evaluation)
    write_readme(visible, heldout, evaluation)
    print("Generated 7 security figures, CSV, and README in", HERE)


if __name__ == "__main__":
    main()
