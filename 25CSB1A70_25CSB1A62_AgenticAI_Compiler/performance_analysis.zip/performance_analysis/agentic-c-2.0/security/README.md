# AGentic_C 2.0 security enhancements: evaluation

This report evaluates the added source/IR and prompt-directive scanner, Attack Lab, pass-policy gate, and candidate validation behavior. It reports measured scanner cost and scenario classification outcomes separately.

> These figures are evaluation of the current prototype, not a before/after delta: the available evidence has no pre-enhancement security measurements.

## Attack Lab quality results

| Dataset | Cases | Malicious | TP | FP | FN | TN | Precision | Recall | F1 | Marked blocked |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Visible demo | 48 | 32 | 10 | 7 | 22 | 9 | 58.8% (10/17) | 31.2% (10/32) | 40.8% | 28.1% (9/32) |
| Held-out | 8 | 7 | 1 | 0 | 6 | 1 | 100.0% (1/1) | 14.3% (1/7) | 25.0% | 0.0% (0/7) |

The visible data contains 48 authored scenarios (32 malicious, 16 benign). It detects 10/32 attacks and misses 22; there are seven false positives. The separate held-out set has only eight cases (seven malicious, one benign): the scanner detects one attack and misses six. Held-out precision is 1/1 and should not be read as evidence of reliable precision.

The Attack Lab is an inert pattern-matching demonstration. Scenario strings are never executed, and agent tool traces/blocking are simulated. The prototype does not provide a general live file, network, or tool firewall.

## Security scanner cost

The source and prompt-directive rules were measured on the four bundled example files with 10 warm-ups and 100 timed calls per file. The scan includes local file reads with a warm OS cache and four source patterns plus three prompt-directive patterns. It excludes LLVM IR scanning, Clang, planner agents, subprocess behavior checks, and the dashboard.

| Example | Source lines | Findings | Median (µs) | P95 (µs) |
|---|---:|---:|---:|---:|
| hft_strategy.cpp | 223 | 0 | 431.35 | 463.62 |
| market_maker.cpp | 347 | 0 | 778.88 | 827.08 |
| order_book_engine.cpp | 370 | 0 | 774.77 | 807.75 |
| enterprise_hft_engine.cpp | 842 | 0 | 1685.02 | 1746.12 |

All four files produced zero findings under these limited rules. The timing is a warm-cache local microbenchmark, not full compiler security-stage latency. The earlier end-to-end run recorded security-analysis stage times separately in the main performance report.

## Attack Lab evaluation cost

| Dataset | Scenarios | Median evaluation time | P95 | Median per scenario |
|---|---:|---:|---:|---:|
| visible | 48 | 8.665 ms | 10.573 ms | 180.5 µs |
| heldout | 8 | 1.978 ms | 2.262 ms | 247.2 µs |

Measured with 5 warm-ups and 50 evaluations per dataset. The scenario text is only matched against rules; nothing in the payload is run.

## Candidate acceptance gate

Each suggested optimizer pass is constrained by the allowlist and candidate pipeline: execute LLVM pass, verify IR, compile, compare configured behavior fixtures, then accept or fail closed. Across these four runs, 34 pass candidates were accepted and 11 executed candidates were rejected; the enterprise example supplied the 11 rejections and had no accepted candidate. This demonstrates gate behavior for these runs, not a general safety guarantee.

The visible Attack Lab outcomes and held-out outcomes are separate from the compiler gate counts. Do not combine them into one security score.

## Limits and evidence

- The visible corpus is hand-built and small; category recall has four malicious cases per category.
- The held-out set has eight cases and is not large enough to establish generalization. Its results are shown as an evaluation, not used to tune rules.
- Pattern rules can miss indirect calls, obfuscated payloads, data-flow paths, and contextual instructions; false positives also occur.
- No pre-enhancement metric baseline was recorded, so these figures cannot support a numerical claim that security improved by X% versus the seniors' version.
- The existing 17-test suite log includes targeted tests for prompt guard/fail-closed behavior, allowlist rejection, path traversal variants, source rules, and Attack Lab loading. This report uses recorded evidence and does not rerun the suite.

## Figures

### Attack Lab outcomes

![Visible and held-out confusion matrices](01-attacklab-confusion-matrices.png)

![Precision, recall, and F1 by dataset](02-detection-quality-metrics.png)

![Visible-set attack recall by category](03-visible-category-recall.png)

![Attack detection versus simulated blocking](04-detection-vs-simulated-blocking.png)

### Security processing cost and enforcement

![Security scanner median and P95 overhead by source file](05-security-scanner-overhead.png)

![Visible and held-out Attack Lab evaluation runtime](06-attacklab-evaluation-time.png)

![Fail-closed optimizer pass gate outcomes](07-fail-closed-pass-gate.png)

Raw timing samples are in `security-scan-timings.csv`; benchmark parameters and full samples are in `security-evaluation.json`. Rerun `benchmark_security.py` and `make_security_figures.py` to regenerate this analysis.
