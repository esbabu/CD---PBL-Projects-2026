#!/usr/bin/env python3
"""Measure the current security-analysis and inert Attack Lab paths."""
from __future__ import annotations

import json
import platform
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from safety.analysis import SecurityAnalyzer  # noqa: E402
from safety.attack_lab import build_report  # noqa: E402


EXAMPLES = [
    "hft_strategy.cpp",
    "market_maker.cpp",
    "order_book_engine.cpp",
    "enterprise_hft_engine.cpp",
]
WARMUPS = 10
TRIALS = 100
LAB_WARMUPS = 5
LAB_TRIALS = 50


def summarize(samples):
    ordered = sorted(samples)
    return {
        "n": len(ordered),
        "median_ns": statistics.median(ordered),
        "p95_ns": ordered[min(len(ordered) - 1, int(0.95 * len(ordered)))],
        "min_ns": ordered[0],
        "max_ns": ordered[-1],
        "samples_ns": ordered,
    }


def time_callable(fn, warmups, trials):
    for _ in range(warmups):
        fn()
    values = []
    for _ in range(trials):
        start = time.perf_counter_ns()
        fn()
        values.append(time.perf_counter_ns() - start)
    return summarize(values)


def main():
    analyzer = SecurityAnalyzer()
    source_results = []
    for filename in EXAMPLES:
        path = ROOT / "examples" / filename
        source_bytes = path.stat().st_size
        source_lines = len(path.read_text(encoding="utf-8", errors="replace").splitlines())
        scan = time_callable(
            lambda p=str(path): analyzer.analyze(p, include_prompt_scan=True),
            WARMUPS,
            TRIALS,
        )
        findings = analyzer.analyze(str(path), include_prompt_scan=True)
        source_results.append({
            "example": filename,
            "bytes": source_bytes,
            "lines": source_lines,
            "finding_count": len(findings),
            "finding_ids": [finding.rule_id for finding in findings],
            "warmup_runs": WARMUPS,
            "timing": scan,
        })

    lab_results = {}
    for name, heldout in [("visible", False), ("heldout", True)]:
        timing = time_callable(lambda h=heldout: build_report(heldout=h), LAB_WARMUPS, LAB_TRIALS)
        lab_results[name] = {
            "warmup_runs": LAB_WARMUPS,
            "timing": timing,
        }

    evaluation = {
        "measurement": {
            "host": platform.platform(),
            "cpu": platform.processor(),
            "python": sys.version.split()[0],
            "clock": "time.perf_counter_ns",
            "scanner_scope": "warm-cache source scan plus prompt-directive scan; no LLVM IR input",
            "attack_lab_scope": "scenario evaluation from inert JSON; payloads are not executed; no report is saved",
        },
        "scanner": source_results,
        "attack_lab_execution_time": lab_results,
        "classification_metrics_source_files": {
            "visible": "../../../../evidence/macos/attack_lab_visible.json",
            "heldout": "../../../../evidence/macos/attack_lab_heldout.json",
        },
    }
    (OUT / "security-evaluation.json").write_text(json.dumps(evaluation, indent=2), encoding="utf-8")
    for item in source_results:
        t = item["timing"]
        print(f"{item['example']}: {t['median_ns']/1000:.2f} us median, {t['p95_ns']/1000:.2f} us p95; {item['lines']} lines, {item['finding_count']} findings")
    for name, data in lab_results.items():
        t = data["timing"]
        print(f"Attack Lab {name}: {t['median_ns']/1e6:.3f} ms median, {t['p95_ns']/1e6:.3f} ms p95; n={t['n']}")


if __name__ == "__main__":
    main()
