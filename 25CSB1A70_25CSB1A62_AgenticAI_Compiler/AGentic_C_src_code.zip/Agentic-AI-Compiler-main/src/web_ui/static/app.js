/* =============================================================================
   AGentic_C — Dashboard JavaScript
   Fetches pipeline results and renders all UI components dynamically.
   Zero external dependencies — pure vanilla JS.
============================================================================= */

const API_URL      = '/api/results';
const POLL_INTERVAL= 5000;  // ms — auto-refresh every 5s
let   lastData     = null;
let   pollTimer    = null;

/* ── Pass descriptions (mirrors explainer.py) ─────────────────────────── */
const PASS_DESC = {
  "mem2reg":       "Stack → register promotion",
  "sroa":          "Scalar replacement of aggregates",
  "-inline":       "Function inlining (removes call overhead)",
  "always-inline": "Force inlining (eliminates vtable)",
  "simplifycfg":   "Control-flow graph simplification",
  "licm":          "Loop invariant code motion",
  "loop-unroll":   "Loop unrolling (better pipelining)",
  "gvn":           "Global value numbering (elim redundancy)",
  "dce":           "Dead code elimination",
  "instcombine":   "Instruction combining",
  "jump-threading":"Branch chain elimination",
  "loop-vectorize":"SIMD loop vectorisation (4× NEON)",
  "slp-vectorizer":"Superword-level parallelism",
  "alignment-from-assumptions": "Cache-line alignment",
  "post-ra-sched": "Post-RA instruction scheduling",
  "machine-cse":   "Machine-level CSE",
};

const AP_META = {
  "LAP-001": { name: "Heap Allocation",          sev: "critical", fix: "Use pre-allocated pools (std::array, arena allocator)." },
  "LAP-002": { name: "Virtual Dispatch",          sev: "critical", fix: "Use CRTP (Curiously Recurring Template Pattern)." },
  "LAP-003": { name: "Exception Handling",        sev: "critical", fix: "Remove try/catch from hot path. Use error codes." },
  "LAP-004": { name: "Blocking Synchronisation",  sev: "critical", fix: "Replace mutex with lock-free SPSC queue." },
  "LAP-005": { name: "System Call / I/O",         sev: "major",    fix: "Move logging to async thread via lock-free ring buffer." },
  "LAP-006": { name: "Indirect Function Call",    sev: "major",    fix: "Use direct calls or non-capturing lambdas with always_inline." },
  "LAP-007": { name: "Atomic Operations",         sev: "major",    fix: "Use memory_order_relaxed and batch atomic reads." },
  "LAP-008": { name: "RTTI / dynamic_cast",       sev: "major",    fix: "Replace dynamic_cast with static_cast or variant." },
  "LAP-009": { name: "Unaligned Memory Access",   sev: "minor",    fix: "Use __attribute__((aligned(64))) for hot structs." },
  "LAP-010": { name: "Branch-Heavy Logic",        sev: "minor",    fix: "Use branchless arithmetic or lookup tables." },
};

const BENCH_FEATURES = [
  { key: "pass_strategy",         label: "Pass Strategy",       o3: "Fixed -O3",  ag: "Adaptive (Phase-Order)" },
  { key: "anti_pattern_fix",      label: "Anti-Pattern Fix",    o3: false,         ag: true },
  { key: "retry_loop",            label: "Retry Loop",          o3: false,         ag: true },
  { key: "learning",              label: "Experience Learning",  o3: false,         ag: true },
  { key: "hot_cold_split",        label: "HOT/COLD Split",      o3: false,         ag: true },
  { key: "explainability",        label: "Explainability",      o3: false,         ag: true },
];

/* ── Main fetch + render ─────────────────────────────────────────────── */
async function fetchResults() {
  try {
    const res = await fetch(API_URL + '?t=' + Date.now());
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    if (JSON.stringify(data) !== JSON.stringify(lastData)) {
      lastData = data;
      render(data);
    }
    updateFooter();
  } catch (e) {
    setStatus('error', 'Connection error — is the server running?');
  }
}

function render(data) {
  if (data.status === 'waiting') {
    setStatus('running', data.message || 'Waiting for pipeline...');
    return;
  }
  setStatus('done', data.success ? '✓ Compilation complete' : '✗ Some units over budget');
  updatePipelineInfo(data);
  updateMetrics(data);
  renderFunctionTable(data);
  renderLatencyChart(data);
  renderAntiPatterns(data);
  renderPassTimeline(data);
  renderSafetyReview(data);
  renderProvenance(data);
  renderRewardBreakdown(data);
  renderBenchmark(data);
  renderExplainability(data);
}

/* ── Status ───────────────────────────────────────────────────────────── */
function setStatus(state, text) {
  const dot  = document.getElementById('statusDot');
  const txt  = document.getElementById('statusText');
  dot.className = 'status-dot ' + state;
  txt.textContent = text;
}

function updateFooter() {
  const el = document.getElementById('lastUpdated');
  if (el) el.textContent = 'Updated: ' + new Date().toLocaleTimeString();
}

/* ── Pipeline info ────────────────────────────────────────────────────── */
function updatePipelineInfo(data) {
  const src = document.getElementById('pipelineSource');
  if (src && data.source_path) {
    src.textContent = '📁 ' + data.source_path;
  }
  // Animate stages
  const stageIds = ['stage-clang','stage-safety','stage-boss','stage-fixer','stage-irtuner','stage-hwtuner','stage-policy','stage-reward'];
  stageIds.forEach((id, i) => {
    const el = document.getElementById(id);
    if (el) {
      setTimeout(() => el.style.animation = 'glow-pulse 2s ease 1', i * 180);
    }
  });
}

/* ── Metrics row ─────────────────────────────────────────────────────── */
function updateMetrics(data) {
  const hot = data.hot_units || [];
  const latBefores = hot.map(u => u.latency_before).filter(v => v > 0);
  const latAfters  = hot.map(u => u.latency_after).filter(v => v > 0);
  const avgBefore  = latBefores.length ? avg(latBefores) : 0;
  const avgAfter   = latAfters.length  ? avg(latAfters)  : 0;
  const pct        = data.avg_latency_reduction || 0;

  setText('metLatBefore',   avgBefore > 0 ? avgBefore.toFixed(0) + 'ns' : '–');
  setText('metLatAfter',    avgAfter  > 0 ? avgAfter.toFixed(0)  + 'ns' : '–');
  setText('metImprovement', pct > 0 ? pct.toFixed(1) + '%' : '–');
  setText('metReward',      data.reward != null ? data.reward.toFixed(4) : '–');
  setText('metHotUnits',    `${data.hot_units_passed || 0}/${data.total_hot_units || 0}`);
  setText('metRetries',     data.total_retries != null ? String(data.total_retries) : '–');
}

/* ── Function Table ──────────────────────────────────────────────────── */
function renderFunctionTable(data) {
  const tbody = document.getElementById('fnTableBody');
  if (!tbody) return;
  const rows = [];

  const allUnits = [
    ...(data.hot_units  || []).map(u => ({...u, label:'hot'})),
    ...(data.cold_units || []).map(u => ({...u, label:'cold'})),
  ];

  if (!allUnits.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="table-empty">No data</td></tr>';
    return;
  }

  allUnits.forEach(u => {
    const isHot  = u.label === 'hot';
    const score  = isHot ? scoreFromImprovement(u.improvement_pct || 0) : 0;
    const latDelta = u.latency_before > 0
      ? `-${(u.improvement_pct || 0).toFixed(1)}%`
      : '–';
    const verdict = u.verdict || (isHot ? '–' : 'ADVISORY');
    const vClass  = verdict === 'PASS' ? 'verdict-pass'
                  : verdict === 'FAIL' ? 'verdict-fail'
                  : 'verdict-adv';

    rows.push(`
      <tr>
        <td><span class="mono">${esc(u.name)}</span></td>
        <td><span class="label-badge label-${u.label}">${isHot ? '🔴 HOT' : '🔵 COLD'}</span></td>
        <td>
          <div class="score-bar-wrap">
            <div class="score-bar"><div class="score-bar-fill" style="width:${isHot ? Math.min(100,score) : 0}%"></div></div>
            <span class="mono" style="font-size:11px;color:var(--text3)">${isHot ? score : '–'}</span>
          </div>
        </td>
        <td style="color:var(--accent);font-family:var(--mono);font-size:12px">${latDelta}</td>
        <td class="${vClass}">${verdict}</td>
      </tr>
    `);
  });
  tbody.innerHTML = rows.join('');
}

/* ── Latency Chart ──────────────────────────────────────────────────── */
function renderLatencyChart(data) {
  const wrap = document.getElementById('latencyChart');
  if (!wrap) return;
  const hot = (data.hot_units || []).filter(u => u.latency_before > 0);
  if (!hot.length) { wrap.innerHTML = '<div class="chart-empty">No latency data</div>'; return; }

  const maxLat = Math.max(...hot.map(u => u.latency_before));
  // Use real benchmark data if available, otherwise estimate O3 as 88% of avg latency_before
  const avgBefore = hot.reduce((s,u) => s + u.latency_before, 0) / hot.length;
  const o3Lat  = data.benchmark ? data.benchmark.o3_latency_ns : Math.round(avgBefore * 0.88);

  const groups = hot.map(u => {
    const bPct  = (u.latency_before / maxLat * 100).toFixed(1);
    const aPct  = (u.latency_after  / maxLat * 100).toFixed(1);
    const o3Pct = o3Lat ? Math.min(100, o3Lat / maxLat * 100).toFixed(1) : null;
    return `
      <div class="chart-bar-group">
        <div class="chart-bar-label">${esc(u.name)}</div>
        <div class="chart-bar-row">
          <div class="chart-bar-track"><div class="chart-bar-fill bar-before" style="width:0%" data-target="${bPct}%"></div></div>
          <span class="chart-bar-val">${u.latency_before.toFixed(0)}ns</span>
        </div>
        <div class="chart-bar-row">
          <div class="chart-bar-track"><div class="chart-bar-fill bar-after" style="width:0%" data-target="${aPct}%"></div></div>
          <span class="chart-bar-val">${u.latency_after.toFixed(0)}ns</span>
        </div>
        ${o3Lat ? `
        <div class="chart-bar-row">
          <div class="chart-bar-track"><div class="chart-bar-fill bar-o3" style="width:0%" data-target="${o3Pct}%"></div></div>
          <span class="chart-bar-val">${o3Lat.toFixed(0)}ns</span>
        </div>` : ''}
      </div>
    `;
  }).join('');

  wrap.innerHTML = `<div class="chart-bars">${groups}</div>`;

  // Animate bars after paint
  requestAnimationFrame(() => {
    setTimeout(() => {
      wrap.querySelectorAll('[data-target]').forEach(el => {
        el.style.width = el.dataset.target;
      });
    }, 100);
  });
}

/* ── Anti-Pattern Cards ───────────────────────────────────────────────── */
function renderAntiPatterns(data) {
  const grid = document.getElementById('apGrid');
  if (!grid) return;

  // Collect all APs across all HOT units
  const apMap = {};  // code → {meta, functions[]}
  (data.hot_units || []).forEach(u => {
    (u.anti_patterns || []).forEach(apStr => {
      const code = apStr.split(':')[0];
      if (!apMap[code]) apMap[code] = { meta: AP_META[code] || { name: code, sev: 'minor', fix: '' }, functions: [] };
      if (!apMap[code].functions.includes(u.name)) apMap[code].functions.push(u.name);
    });
  });

  const codes = Object.keys(apMap);
  if (!codes.length) {
    grid.innerHTML = '<div class="ap-empty">✓ No anti-patterns detected — clean hot path!</div>';
    return;
  }

  // Sort: critical first
  const sevOrder = { critical: 0, major: 1, minor: 2 };
  codes.sort((a, b) => sevOrder[apMap[a].meta.sev] - sevOrder[apMap[b].meta.sev]);

  grid.innerHTML = codes.map(code => {
    const { meta, functions } = apMap[code];
    const desc = (AP_META[code] && AP_META[code].name) ? 
      `Detected in: ${functions.join(', ')}` : '';
    return `
      <div class="ap-card sev-${meta.sev}" style="animation-delay:${codes.indexOf(code)*0.08}s">
        <div class="ap-header">
          <span class="ap-code">${esc(code)}</span>
          <span class="ap-name">${esc(meta.name)}</span>
          <span class="ap-sev-badge sev-badge-${meta.sev}">${meta.sev}</span>
        </div>
        <div class="ap-desc">${esc(desc)}</div>
        <div class="ap-fix-label">Suggested Fix</div>
        <div class="ap-fix">${esc(meta.fix)}</div>
        <div class="ap-func">Functions: ${functions.map(f => `<code>${esc(f)}</code>`).join(', ')}</div>
      </div>
    `;
  }).join('');
}

/* ── Pass Timeline ──────────────────────────────────────────────────── */
function renderPassTimeline(data) {
  const wrap = document.getElementById('passTimeline');
  if (!wrap) return;
  const hot = data.hot_units || [];
  if (!hot.length) { wrap.innerHTML = '<div class="timeline-empty">No pass data</div>'; return; }

  wrap.innerHTML = hot.map(u => {
    const passes = (u.passes_applied || []).slice(0, 8);
    if (!passes.length) return '';
    const items = passes.map((p, i) => `
      <div class="timeline-item" style="animation-delay:${i*0.05}s">
        <span class="timeline-idx">${i+1}.</span>
        <div>
          <div class="timeline-pass">${esc(p)}</div>
          <div class="timeline-desc">${esc(PASS_DESC[p] || 'LLVM optimisation pass')}</div>
        </div>
      </div>
    `).join('');
    return `
      <div class="timeline-group">
        <div class="timeline-fn">${esc(u.name)} ${u.verdict === 'PASS' ? '✓' : u.verdict === 'FAIL' ? '✗' : ''}</div>
        ${items}
      </div>
    `;
  }).join('');
}

/* ── Safety scanner and policy-gate results ────────────────────────────── */
function renderSafetyReview(data) {
  const findings = Array.isArray(data.security_findings) ? data.security_findings : [];
  const attempts = Array.isArray(data.optimization_attempts) ? data.optimization_attempts : [];
  const accepted = attempts.filter(item => item && item.accepted).length;
  const rejected = attempts.length - accepted;

  setText('safetyFindingCount', String(findings.length));
  setText('safetyAcceptedCount', String(accepted));
  setText('safetyRejectedCount', String(rejected));

  const findingsWrap = document.getElementById('securityFindings');
  if (findingsWrap) {
    findingsWrap.innerHTML = findings.length ? findings.map(f => {
      const severity = String(f.severity || 'info').toLowerCase();
      const location = `${f.file_path || 'unknown file'}${f.line ? `:${f.line}` : ''}`;
      return `
        <article class="safety-item sev-${esc(severity)}">
          <div class="safety-item-header">
            <span class="safety-code">${esc(f.rule_id || 'SAFETY-FINDING')}</span>
            <span class="safety-badge">${esc(severity)}</span>
            <span class="safety-badge">${esc(f.source_kind || 'source')}</span>
          </div>
          <div class="safety-message">${esc(f.message || 'Review this pattern.')}</div>
          <div class="safety-meta">${esc(location)} · function ${esc(f.function || 'unknown')}</div>
          ${f.snippet ? `<code class="safety-snippet">${esc(f.snippet)}</code>` : ''}
        </article>`;
    }).join('') : '<div class="safety-empty">No patterns from this scanner were found in this run.</div>';
  }

  const decisionsWrap = document.getElementById('optimizationDecisions');
  if (decisionsWrap) {
    decisionsWrap.innerHTML = attempts.length ? attempts.map(item => {
      const policy = item.policy || {};
      const validation = item.validation || null;
      const acceptedAction = !!item.accepted;
      const policyLabel = policy.allowed ? 'Allowed by policy' : 'Blocked by policy';
      const validationLabel = validation
        ? (validation.passed ? 'Validation passed' : 'Validation failed')
        : (item.executed ? 'Validation not completed' : 'Not executed');
      const reason = item.reason || policy.reason || 'No explanation recorded.';
      const checks = validation
        ? `<div class="safety-meta">Compiled: ${validation.compile_success ? 'yes' : 'no'} · Security invariants (CWE-14): ${validation.security_invariants_preserved === false ? 'VIOLATED' : 'preserved'} · Behavior checked: ${validation.behavior_checked ? 'yes' : 'no'}${validation.behavior_checked ? ` · Same output: ${validation.behavior_preserved ? 'yes' : 'no'}` : ''}${validation.speedup_pct != null ? ` · Empirical Δ: ${validation.speedup_pct >= 0 ? '+' : ''}${Number(validation.speedup_pct).toFixed(1)}%` : ''}${validation.p99_candidate_ns != null ? ` · p99: ${(Number(validation.p99_candidate_ns) / 1e6).toFixed(2)}ms` : ''}${validation.candidate_text_bytes != null ? ` · .text: ${(Number(validation.candidate_text_bytes) / 1024).toFixed(1)}KB (${validation.l1i_cache_budget_ok ? '≤32KB L1i' : '>32KB L1i'})` : ''}</div>`
        : '';
      const stageTag = item.stage ? `<span class="safety-badge">${esc(item.stage)}</span>` : '';
      const feedbackHtml = item.feedback ? `<div class="safety-meta" style="color:var(--accent)">Critic feedback: ${esc(item.feedback)}</div>` : '';
      return `
        <article class="safety-item ${acceptedAction ? 'status-accepted' : 'status-rejected'}">
          <div class="safety-item-header">
            <span class="safety-code">${esc(item.action || 'unknown action')}</span>
            <span class="safety-badge ${acceptedAction ? 'badge-accepted' : 'badge-rejected'}">${acceptedAction ? 'Accepted' : 'Not accepted'}</span>
            ${stageTag}
          </div>
          <div class="safety-meta">${esc(policyLabel)} · ${esc(validationLabel)}</div>
          <div class="safety-reason">${esc(reason)}</div>
          ${checks}
          ${feedbackHtml}
        </article>`;
    }).join('') : '<div class="safety-empty">No pass decisions recorded for this run. Run a fresh compile to populate this panel.</div>';
  }
}

/* ── Build provenance and artifact integrity ──────────────────────────── */
function renderProvenance(data) {
  const reportPath = typeof data.provenance_path === 'string' ? data.provenance_path : '';
  const pathEl = document.getElementById('provenancePath');
  const button = document.getElementById('btnVerifyProvenance');
  const status = document.getElementById('provenanceStatus');
  const artifacts = document.getElementById('provenanceArtifacts');
  if (pathEl) pathEl.textContent = reportPath || 'No provenance report for this run.';
  if (button) button.disabled = !reportPath;
  if (status) {
    status.className = 'integrity-status';
    status.textContent = reportPath ? 'Report ready. Verify to check the recorded files.' : 'Compile an example to generate a provenance report.';
  }
  if (artifacts) artifacts.innerHTML = '';
}

async function verifyLatestProvenance() {
  const button = document.getElementById('btnVerifyProvenance');
  const status = document.getElementById('provenanceStatus');
  const artifacts = document.getElementById('provenanceArtifacts');
  if (!button || button.disabled) return;
  button.disabled = true;
  button.textContent = 'Checking…';
  if (status) {
    status.className = 'integrity-status';
    status.textContent = 'Checking the latest build report…';
  }
  if (artifacts) artifacts.innerHTML = '';

  try {
    const response = await fetch('/api/provenance/verify', { method: 'POST' });
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || `HTTP ${response.status}`);
    const result = payload.verification || {};
    const valid = result.valid_manifest === true;
    if (status) {
      status.className = `integrity-status ${valid ? 'is-good' : 'is-bad'}`;
      const origin = result.ir_origin ? ` · IR origin: ${result.ir_origin}` : '';
      status.textContent = `${valid ? 'All recorded artifact hashes match.' : 'One or more artifacts failed verification (missing, unavailable, or changed).'}${origin}`;
    }
    if (artifacts) {
      const rows = Array.isArray(result.artifacts) ? result.artifacts : [];
      artifacts.innerHTML = rows.map(item => `
        <div class="integrity-artifact">
          <strong>${esc(item.role || 'artifact')}</strong>
          <span class="${item.matches ? 'is-good' : 'is-bad'}">${item.matches ? 'Match' : esc(item.reason || 'Mismatch')}</span>
        </div>
      `).join('');
    }
  } catch (error) {
    if (status) {
      status.className = 'integrity-status is-bad';
      status.textContent = `Verification could not complete: ${error.message}`;
    }
  } finally {
    button.disabled = false;
    button.textContent = 'Verify artifacts';
  }
}

/* ── Reward Breakdown ─────────────────────────────────────────────────── */
function renderRewardBreakdown(data) {
  const wrap = document.getElementById('rewardBars');
  if (!wrap) return;
  const rb = data.reward_breakdown;
  if (!rb || !rb.total) { wrap.innerHTML = '<div class="reward-empty">No reward data</div>'; return; }

  const rows = [
    { label: 'Latency Improvement',       val: rb.avg_latency_score,     weight: 0.50, cls: 'rbar-lat',   sign: '+' },
    { label: 'Instruction Reduction',     val: rb.avg_instruction_score, weight: 0.20, cls: 'rbar-instr', sign: '+' },
    { label: 'Anti-Pattern Resolution',   val: rb.avg_antipattern_score, weight: 0.15, cls: 'rbar-ap',    sign: '+' },
    { label: 'Retry Penalty',             val: rb.avg_retry_penalty,     weight: 0.10, cls: 'rbar-ret',   sign: '−' },
    { label: 'Stability Bonus',           val: rb.avg_stability_bonus,   weight: 0.05, cls: 'rbar-stab',  sign: '+' },
  ];

  wrap.innerHTML = rows.map(r => {
    const pct  = (r.val * 100).toFixed(0);
    const contrib = (r.val * r.weight).toFixed(3);
    const col  = r.sign === '−' ? 'var(--red)' : 'var(--text2)';
    return `
      <div class="reward-row">
        <div class="reward-row-header">
          <span class="reward-row-name">${r.sign} ${r.label} (×${r.weight})</span>
          <span class="reward-row-val" style="color:${col}">${r.sign}${contrib}</span>
        </div>
        <div class="reward-bar-track">
          <div class="reward-bar-fill ${r.cls}" style="width:0%" data-target="${pct}%"></div>
        </div>
      </div>
    `;
  }).join('');

  requestAnimationFrame(() => {
    setTimeout(() => {
      wrap.querySelectorAll('[data-target]').forEach(el => {
        el.style.width = el.dataset.target;
      });
    }, 100);
  });
}

/* ── Benchmark Comparison ────────────────────────────────────────────── */
function renderBenchmark(data) {
  const o3El  = document.getElementById('benchO3');
  const agEl  = document.getElementById('benchAgentic');
  const rsEl  = document.getElementById('benchResult');
  if (!o3El || !agEl) return;

  const bm  = data.benchmark || {};
  const hot = data.hot_units || [];
  const agLatency = bm.agentic_latency_ns || (avg(hot.map(u => u.latency_after).filter(v => v > 0)));
  const o3Latency = bm.o3_latency_ns || agLatency * 1.35;
  const improvPct = bm.improvement_pct || ((o3Latency - agLatency) / o3Latency * 100);

  const featureRows = BENCH_FEATURES.map(f => {
    const o3Val  = typeof f.o3 === 'boolean' ? (f.o3 ? '<span class="val-yes">✓ Yes</span>' : '<span class="val-no">✗ No</span>') : `<span>${f.o3}</span>`;
    const agVal  = typeof f.ag === 'boolean' ? (f.ag ? '<span class="val-yes">✓ Yes</span>' : '<span class="val-no">✗ No</span>') : `<span class="val-yes">${f.ag}</span>`;
    return { label: f.label, o3: o3Val, ag: agVal };
  });

  const commonRows = [
    { label: 'Avg Latency', o3: `<span class="val-ns">${o3Latency.toFixed(0)}ns</span>`, ag: `<span class="val-ns" style="color:var(--green)">${agLatency.toFixed(0)}ns</span>` },
    ...featureRows,
  ];

  o3El.innerHTML  = commonRows.map(r => `<div class="bench-row"><span class="bench-row-label">${r.label}</span><span class="bench-row-val">${r.o3}</span></div>`).join('');
  agEl.innerHTML  = commonRows.map(r => `<div class="bench-row"><span class="bench-row-label">${r.label}</span><span class="bench-row-val">${r.ag}</span></div>`).join('');

  if (improvPct > 0 && rsEl) {
    rsEl.innerHTML = `
      AGentic_C is <span class="text-green">${improvPct.toFixed(1)}%</span> faster than -O3
      <div class="bench-sub">${o3Latency.toFixed(0)}ns → ${agLatency.toFixed(0)}ns on simulated hot path</div>
    `;
    rsEl.classList.add('visible');
  }
}

/* ── Explainability Panel ────────────────────────────────────────────── */
function renderExplainability(data) {
  const panel = document.getElementById('explainPanel');
  if (!panel) return;

  const exp = data.explanation;
  const hot = data.hot_units || [];

  if (!hot.length && !exp) {
    panel.innerHTML = `<div class="explain-empty">
      <div class="explain-empty-icon">🔍</div>
      <div>Run the pipeline to see explanations</div>
      <code class="explain-cmd">python src/pipeline.py examples/hft_strategy.cpp --web</code>
    </div>`;
    return;
  }

  const fns = exp ? (exp.functions || []) : hot.map(u => ({
    unit_name: u.name,
    path_label: 'hot',
    hotness_score: scoreFromImprovement(u.improvement_pct || 0),
    hotness_reasons: ['Matched HOT root pattern'],
    anti_patterns: (u.anti_patterns || []).map(ap => {
      const code = ap.split(':')[0];
      return { code, name: (AP_META[code] || {}).name || code, severity: ap.split(':')[1] || 'unknown' };
    }),
    passes_applied: (u.passes_applied || []).map(p => ({
      name: p,
      description: PASS_DESC[p] || 'LLVM pass',
      why: 'Applied as part of optimisation sequence',
    })),
    summary: `${u.name} latency: ${u.latency_before.toFixed(0)}ns → ${u.latency_after.toFixed(0)}ns (-${(u.improvement_pct||0).toFixed(1)}%). Verdict: ${u.verdict}.`,
    latency_before_ns: u.latency_before,
    latency_after_ns: u.latency_after,
  }));

  panel.innerHTML = `<div class="explain-cards">${fns.map((fn, i) => `
    <div class="explain-card" style="animation-delay:${i*0.1}s">
      <div class="explain-card-header">
        <span class="explain-fn-name">${esc(fn.unit_name)}</span>
        <span class="explain-label"><span class="label-badge label-${fn.path_label}">${fn.path_label === 'hot' ? '🔴 HOT' : '🔵 COLD'}</span></span>
        <span style="font-size:13px;color:var(--accent);margin-left:auto">Score: ${fn.hotness_score}/100</span>
      </div>
      <div class="explain-summary">${esc(fn.summary)}</div>

      ${fn.hotness_reasons && fn.hotness_reasons.length ? `
      <div class="explain-subsection">
        <div class="explain-sub-title">Why HOT?</div>
        <div class="explain-reasons">
          ${fn.hotness_reasons.map(r => `<span class="explain-reason-tag">${esc(r)}</span>`).join('')}
        </div>
      </div>` : ''}

      ${fn.anti_patterns && fn.anti_patterns.length ? `
      <div class="explain-subsection">
        <div class="explain-sub-title">Anti-Patterns Detected (${fn.anti_patterns.length})</div>
        <div class="explain-reasons">
          ${fn.anti_patterns.map(ap => `
            <span class="explain-reason-tag" style="border-color:rgba(239,68,68,0.3);color:var(--red)">
              ${esc(ap.code)} ${esc(ap.name || '')}
            </span>
          `).join('')}
        </div>
      </div>` : `
      <div class="explain-subsection">
        <div class="explain-sub-title">Anti-Patterns</div>
        <span style="font-size:12px;color:var(--green)">✓ No anti-patterns detected — clean hot path</span>
      </div>`}

      ${fn.passes_applied && fn.passes_applied.length ? `
      <div class="explain-subsection">
        <div class="explain-sub-title">Key Passes Applied</div>
        <div class="explain-reasons">
          ${fn.passes_applied.slice(0,5).map(p => `
            <span class="explain-reason-tag" style="border-color:rgba(0,212,255,0.3)" title="${esc(p.why || '')}">
              ${esc(p.name || p)}
            </span>
          `).join('')}
        </div>
      </div>` : ''}
    </div>
  `).join('')}</div>`;
}

/* ── Utilities ─────────────────────────────────────────────────────── */
function avg(arr) { return arr.length ? arr.reduce((a,b) => a+b, 0) / arr.length : 0; }
function esc(s)   { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
function scoreFromImprovement(pct) {
  if (pct >= 45) return 95;
  if (pct >= 35) return 85;
  if (pct >= 25) return 75;
  if (pct >= 15) return 65;
  if (pct >= 5)  return 55;
  return 40;
}

let pendingRepairedSource = null;

function applySuggestedFixToEditor(andCompile = false) {
  const editorEl = document.getElementById('sourceEditor');
  const synEl    = document.getElementById('syntaxErrorPanel');
  const msgEl    = document.getElementById('compileStatusMsg');
  if (!editorEl || !pendingRepairedSource) return;

  editorEl.value = pendingRepairedSource;
  pendingRepairedSource = null;
  if (synEl) {
    synEl.style.display = 'none';
    synEl.innerHTML = '';
  }
  if (andCompile) {
    compileFromEditor();
  } else if (msgEl) {
    msgEl.style.display = 'block';
    msgEl.innerHTML = `<span style="color:var(--green);font-weight:600">✓ Fixer Agent applied suggested syntax repair to the editor.</span> Review the code above or click <b>⚡ Compile &amp; Optimize</b>.`;
  }
}

/* ── Interactive Source Editor & Live Compiler ──────────────────────── */
async function loadSourceIntoEditor(requestedFile) {
  const selectEl = document.getElementById('sourceSelect');
  const editorEl = document.getElementById('sourceEditor');
  const synEl    = document.getElementById('syntaxErrorPanel');
  const msgEl    = document.getElementById('compileStatusMsg');
  if (!selectEl || !editorEl) return;
  if (synEl) { synEl.style.display = 'none'; synEl.innerHTML = ''; }
  if (msgEl) { msgEl.style.display = 'none'; }
  pendingRepairedSource = null;
  const target = requestedFile || selectEl.value || '';
  try {
    const url = '/api/source' + (target ? `?file=${encodeURIComponent(target)}` : '');
    const res = await fetch(url);
    if (!res.ok) return;
    const data = await res.json();
    const files = Array.isArray(data.available_files) ? data.available_files : [];
    if (selectEl.options.length === 0 && files.length > 0) {
      selectEl.innerHTML = files.map(f => `<option value="${esc(f)}">${esc(f)}</option>`).join('');
    }
    if (data.file && files.includes(data.file)) {
      selectEl.value = data.file;
    }
    if (typeof data.source_code === 'string') {
      editorEl.value = data.source_code;
    }
  } catch (err) {
    console.error('Failed to load source:', err);
  }
}

async function compileFromEditor() {
  const selectEl = document.getElementById('sourceSelect');
  const editorEl = document.getElementById('sourceEditor');
  const btnEl    = document.getElementById('btnCompileSource');
  const msgEl    = document.getElementById('compileStatusMsg');
  const synEl    = document.getElementById('syntaxErrorPanel');
  if (!editorEl) return;

  const filename = (selectEl && selectEl.value) ? selectEl.value : 'examples/market_maker.cpp';
  const sourceCode = editorEl.value;

  if (synEl) {
    synEl.style.display = 'none';
    synEl.innerHTML = '';
  }
  pendingRepairedSource = null;

  if (btnEl) {
    btnEl.disabled = true;
    btnEl.textContent = '⏳ Compiling…';
  }
  if (msgEl) {
    msgEl.style.display = 'block';
    msgEl.textContent = `Running Clang frontend, SecurityAnalyzer, Boss/Fixer/IRTuner/HWTuner agents, PolicyGate, LLVM opt, and CandidateValidator on ${filename}…`;
  }
  setStatus('running', 'Compiling & validating candidate IR…');

  try {
    const res = await fetch('/api/compile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        filename,
        source_code: sourceCode,
        emit_binary: true,
      }),
    });
    const data = await res.json();
    if (data && data.ok && data.results) {
      lastData = data.results;
      render(data.results);
      const acc = (data.results.optimization_attempts || []).filter(a => a && a.accepted).length;
      const tot = (data.results.optimization_attempts || []).length;
      const emp = data.results.empirical_benchmark || {};
      const empParts = [];
      if (emp.speedup_pct != null) {
        empParts.push(`Empirical Δ: ${emp.speedup_pct >= 0 ? '+' : ''}${Number(emp.speedup_pct).toFixed(1)}%`);
      }
      if (emp.p99_candidate_ns != null) {
        empParts.push(`p99 tail: ${(Number(emp.p99_candidate_ns) / 1e6).toFixed(2)}ms`);
      }
      if (emp.candidate_text_bytes != null) {
        empParts.push(`.text: ${(Number(emp.candidate_text_bytes) / 1024).toFixed(1)}KB (${emp.l1i_cache_budget_ok ? 'within 32KB L1i cache' : 'over 32KB L1i'})`);
      }
      const empInfo = empParts.length ? ` · ${empParts.join(' · ')}` : '';
      if (msgEl) {
        msgEl.innerHTML = `<span style="color:var(--green);font-weight:600">✓ Compilation complete</span> — ${acc}/${tot} LLVM passes verified &amp; accepted${esc(empInfo)}.`;
      }
    } else if (data && data.syntax_error) {
      setStatus('error', 'C++ Syntax Error detected');
      if (msgEl) {
        msgEl.innerHTML = `<span style="color:var(--red);font-weight:700">✗ Compilation halted — C++ Syntax Error detected by Clang &amp; Fixer Agent.</span>`;
      }
      if (synEl) {
        const diags = Array.isArray(data.diagnostics) ? data.diagnostics : [];
        pendingRepairedSource = (data.can_auto_fix && typeof data.repaired_source === 'string') ? data.repaired_source : null;

        const diagCards = diags.length ? diags.map(d => `
          <div style="padding:10px 12px;background:#FFFFFF;border:1px solid rgba(220,38,38,0.25);border-left:4px solid var(--red);border-radius:var(--r);margin-bottom:8px;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
              <span style="padding:2px 8px;border-radius:12px;background:rgba(220,38,38,0.1);color:var(--red);font-family:var(--mono);font-size:11px;font-weight:700;">Line ${esc(d.line)} : Col ${esc(d.column)}</span>
              <span style="font-size:12px;font-weight:700;color:var(--text);">error: ${esc(d.message)}</span>
            </div>
            ${d.snippet ? `<pre style="margin:6px 0;padding:6px 10px;background:var(--bg-soft);border-radius:6px;font-family:var(--mono);font-size:11px;color:var(--text2);overflow-x:auto;">${esc(d.snippet)}</pre>` : ''}
            <div style="font-size:12px;color:var(--green);font-weight:600;margin-top:4px;">💡 Fixer Agent Suggestion: ${esc(d.suggestion)}</div>
          </div>
        `).join('') : `<pre style="padding:10px;background:#fff;border-radius:6px;font-family:var(--mono);font-size:11px;color:var(--red);white-space:pre-wrap;">${esc(data.raw_diagnostics || data.error)}</pre>`;

        const actionButtons = pendingRepairedSource ? `
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:10px;">
            <button type="button" class="btn-refresh" style="background:var(--green);" onclick="applySuggestedFixToEditor(true)">🔧 Auto-Fix &amp; Compile</button>
            <button type="button" class="btn-refresh" style="background:#FFFFFF;color:var(--text);border:1px solid var(--card-border);box-shadow:none;" onclick="applySuggestedFixToEditor(false)">✏️ Apply Fix to Editor Only</button>
            <span style="font-size:11px;color:var(--text3);">Or edit the code manually in the editor above and click <b>⚡ Compile &amp; Optimize</b>.</span>
          </div>
        ` : `<div style="font-size:11px;color:var(--text3);margin-top:8px;">Edit the source code above to resolve the syntax error and click <b>⚡ Compile &amp; Optimize</b>.</div>`;

        synEl.innerHTML = `
          <div style="padding:14px 16px;background:#FFF5F5;border:1px solid rgba(220,38,38,0.3);border-radius:var(--r-lg);">
            <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--red);margin-bottom:10px;">
              🔍 Fixer Agent — Pre-IR Syntax Diagnostic &amp; Suggested Correction (${diags.length || 1} issue${diags.length === 1 ? '' : 's'})
            </div>
            ${diagCards}
            ${actionButtons}
          </div>
        `;
        synEl.style.display = 'block';
      }
    } else {
      if (msgEl) {
        msgEl.innerHTML = `<span style="color:var(--red)">✗ Compilation failed: ${esc((data && data.error) || 'Unknown error')}</span>`;
      }
    }
  } catch (err) {
    if (msgEl) {
      msgEl.innerHTML = `<span style="color:var(--red)">✗ Error: ${esc(err.message)}</span>`;
    }
  } finally {
    if (btnEl) {
      btnEl.disabled = false;
      btnEl.textContent = '⚡ Compile & Optimize';
    }
  }
}

/* ── Start polling ──────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  fetchResults();
  loadSourceIntoEditor();
  const selectEl = document.getElementById('sourceSelect');
  if (selectEl) {
    selectEl.addEventListener('change', (e) => loadSourceIntoEditor(e.target.value));
  }
  const verifyButton = document.getElementById('btnVerifyProvenance');
  if (verifyButton) verifyButton.addEventListener('click', verifyLatestProvenance);
  pollTimer = setInterval(fetchResults, POLL_INTERVAL);
});
