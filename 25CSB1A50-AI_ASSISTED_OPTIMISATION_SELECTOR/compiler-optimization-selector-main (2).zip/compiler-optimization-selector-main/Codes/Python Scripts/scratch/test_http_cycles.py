import urllib.request
import json
import time

def run_api(mode, sample_name="nested_loops"):
    # First get sample source code
    with urllib.request.urlopen("http://127.0.0.1:8000/api/samples") as r:
        samples = json.loads(r.read().decode())
    sample_code = samples.get(sample_name, {}).get("source_code", "")
    if not sample_code:
        # Fallback to reading file
        with open("Codes/test_cases/nested_loops.c") as f:
            sample_code = f.read()

    payload = {
        "mode": mode,
        "program_id": sample_name,
        "source_code": sample_code,
        "model_family": "dqn"
    }

    t0 = time.time()
    req = urllib.request.Request(
        "http://127.0.0.1:8000/api/run",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req) as r:
        init_data = json.loads(r.read().decode())
    run_id = init_data["run_id"]
    print(f"[{mode.upper()}] Started run {run_id}...")

    # Poll results
    while True:
        time.sleep(0.5)
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:8000/api/results/{run_id}") as r:
                res = json.loads(r.read().decode())
                if res.get("status") in ("completed", "failed", "blocked"):
                    total_elapsed = time.time() - t0
                    view = res.get("view", {})
                    opt_timing = view.get("optimized_timing", {})
                    base_timing = view.get("baseline_timing", {})
                    prod_timing = view.get("production_timing", {})
                    stage_timings = view.get("stage_timings", {})
                    return {
                        "mode": mode,
                        "run_id": run_id,
                        "status": res.get("status"),
                        "total_elapsed_s": total_elapsed,
                        "reported_elapsed_s": res.get("elapsed_s"),
                        "stage_timings": stage_timings,
                        "opt_median_ms": (opt_timing.get("median_s") or 0.0) * 1000.0,
                        "opt_samples": opt_timing.get("samples_ms"),
                        "opt_cpu_ms": opt_timing.get("cpu_median_ms"),
                        "opt_res_ms": opt_timing.get("residual_median_ms"),
                        "base_median_ms": (base_timing.get("median_s") or 0.0) * 1000.0,
                        "base_samples": base_timing.get("samples_ms"),
                    }
        except Exception as e:
            pass

print("=== STARTING REPEATED TEST THROUGH HTTP SERVER ===")
for cycle in range(1, 4):
    print(f"\n--- CYCLE {cycle} ---")
    res_norm = run_api("normal")
    print(f"Normal: Total Wall = {res_norm['total_elapsed_s']:.2f}s (Reported: {res_norm['reported_elapsed_s']}s) | Wall Median = {res_norm['opt_median_ms']:.3f} ms | Samples = {res_norm['opt_samples']} | Stage Timings = {res_norm['stage_timings']}")

    res_ai = run_api("ai")
    print(f"AI:     Total Wall = {res_ai['total_elapsed_s']:.2f}s (Reported: {res_ai['reported_elapsed_s']}s) | Wall Median = {res_ai['opt_median_ms']:.3f} ms | Samples = {res_ai['opt_samples']} | Stage Timings = {res_ai['stage_timings']}")
