// Polybench GEMM benchmark
#include <stdio.h>

#define NI 64
#define NJ 64
#define NK 64

void kernel_gemm(int ni, int nj, int nk,
                 double alpha, double beta,
                 double C[NI][NJ],
                 double A[NI][NK],
                 double B[NK][NJ]) {
  for (int i = 0; i < ni; i++) {
    for (int j = 0; j < nj; j++) {
      C[i][j] *= beta;
    }
    for (int k = 0; k < nk; k++) {
      for (int j = 0; j < nj; j++) {
        C[i][j] += alpha * A[i][k] * B[k][j];
      }
    }
  }
}

int main(void) {
  static double C[NI][NJ];
  static double A[NI][NK];
  static double B[NK][NJ];

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NK; j++)
      A[i][j] = (double)(i * j % 1024) / 1024.0;

  for (int i = 0; i < NK; i++)
    for (int j = 0; j < NJ; j++)
      B[i][j] = (double)(i * j % 512) / 512.0;

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NJ; j++)
      C[i][j] = 0.5;

  for (int iter = 0; iter < 20; iter++) {
    kernel_gemm(NI, NJ, NK, 1.5, 1.2, C, A, B);
  }
  printf("C[0][0] = %f\n", C[0][0]);
  return 0;
}
