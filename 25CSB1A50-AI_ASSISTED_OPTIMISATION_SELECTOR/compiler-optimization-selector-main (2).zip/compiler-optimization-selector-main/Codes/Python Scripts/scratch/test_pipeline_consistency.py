import os, tempfile
from moo.config import CLANG_PATH, OPT_PATH
from moo.pipeline import evaluate_program

gemm_src = os.path.abspath(r'c:\Users\rithv\Desktop\New folder\TOACD\compiler-optimization-selector-main\compiler-optimization-selector-main\Codes\test_cases\gemm.c')

print('=== EVALUATE_PROGRAM TEST: GEMM with warmup=3, measure=5 ===')
res = evaluate_program(
    source_path=gemm_src,
    actions=['mem2reg,instcombine,simplifycfg,gvn,loop-unroll'],
    warmup_runs=3,
    measure_runs=5,
)

base_m = res.baseline.measurement
cand_m = res.candidates[0].measurement

base_t = base_m['timing']
cand_t = cand_m['timing']

base_ms = base_t['median_ns'] / 1e6
cand_ms = cand_t['median_ns'] / 1e6
speedup = base_ms / cand_ms if cand_ms > 0 else 0

base_samples = [round(s / 1e6, 2) for s in base_m['raw_samples_ns']]
cand_samples = [round(s / 1e6, 2) for s in cand_m['raw_samples_ns']]

print(f"Baseline (-O0) : Median={base_ms:.2f} ms | StDev={base_t['stdev_ns']/1e6:.2f} ms | CV={base_t['cv']*100:.1f}% | Samples={base_samples}")
print(f"Candidate      : Median={cand_ms:.2f} ms | StDev={cand_t['stdev_ns']/1e6:.2f} ms | CV={cand_t['cv']*100:.1f}% | Samples={cand_samples}")
print(f"Speedup        : {speedup:.2f}x | Correct: {res.candidates[0].correct}")
print(f"Reliable Base  : {base_m['timing_is_reliable']} | Reliable Cand: {cand_m['timing_is_reliable']}")
