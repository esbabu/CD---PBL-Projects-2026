import os
import sys
import subprocess
import time
import json
import statistics

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from moo.measurement import measure_interleaved
from moo.strategy_diagnostic import _build_executable
from moo.toolchain import CLANG_PATH, OPT_PATH

CLANG = CLANG_PATH or r"C:\Program Files\LLVM\bin\clang.exe"
OPT = OPT_PATH or r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

workdir = os.path.abspath(r"scratch\rigorous_experiment")
os.makedirs(workdir, exist_ok=True)

# ---------------------------------------------------------------------------
# PROGRAM 1: GEMM
# ---------------------------------------------------------------------------
gemm_src_path = os.path.join(workdir, "gemm.c")
with open(gemm_src_path, "w", encoding="utf-8") as f:
    f.write(r"""#include <stdio.h>

#define NI 64
#define NJ 64
#define NK 64

void kernel_gemm(int ni, int nj, int nk,
                 double alpha, double beta,
                 double C[NI][NJ],
                 double A[NI][NK],
                 double B[NK][NJ]) {
  for (int i = 0; i < ni; i++) {
    for (int j = 0; j < nj; j++) {
      C[i][j] *= beta;
    }
    for (int k = 0; k < nk; k++) {
      for (int j = 0; j < nj; j++) {
        C[i][j] += alpha * A[i][k] * B[k][j];
      }
    }
  }
}

int main(void) {
  static double C[NI][NJ];
  static double A[NI][NK];
  static double B[NK][NJ];

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NK; j++)
      A[i][j] = (double)(i * j % 1024) / 1024.0;

  for (int i = 0; i < NK; i++)
    for (int j = 0; j < NJ; j++)
      B[i][j] = (double)(i * j % 512) / 512.0;

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NJ; j++)
      C[i][j] = 0.5;

  for (int iter = 0; iter < 40; iter++) {
    kernel_gemm(NI, NJ, NK, 1.5, 1.2, C, A, B);
  }
  printf("C[0][0] = %f\n", C[0][0]);
  return 0;
}
""")

# ---------------------------------------------------------------------------
# PROGRAM 2: TC1 LOOP HEAVY
# ---------------------------------------------------------------------------
tc1_src_path = os.path.join(workdir, "TC1_loop_heavy.c")
with open(tc1_src_path, "w", encoding="utf-8") as f:
    f.write(r"""#include <stdio.h>

void sink(int x);

int main(void) {
    int arr[512];
    int sum = 0;

    for (int iter = 0; iter < 20000; iter++) {
        for (int i = 0; i < 512; i++) {
            arr[i] = (i * 31) ^ (i >> 3);
        }
        for (int i = 0; i < 512; i++) {
            sum += arr[i] * (i % 7 + 1);
        }
    }

    sink(sum);
    printf("sum = %d\n", sum);
    return 0;
}

__attribute__((noinline)) void sink(int x) { (void)x; }
""")

def run_experiment(prog_name: str, src_path: str, toacd_passes: str):
    print(f"\n=======================================================")
    print(f"=== EXPERIMENT: {prog_name} ===")
    print(f"=======================================================")
    prog_dir = os.path.join(workdir, prog_name.lower())
    os.makedirs(prog_dir, exist_ok=True)

    # 1. Build clang -O0
    dir_o0 = os.path.join(prog_dir, "o0")
    os.makedirs(dir_o0, exist_ok=True)
    ir_o0 = os.path.join(dir_o0, "input_O0.ll")
    cmd_ir_o0 = [CLANG, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src_path, "-o", ir_o0]
    subprocess.run(cmd_ir_o0, check=True)
    exe_o0, _, cmd_exe_o0 = _build_executable(ir_o0, dir_o0, CLANG, "-O0")

    # 2. Build clang -O3
    dir_o3 = os.path.join(prog_dir, "o3")
    os.makedirs(dir_o3, exist_ok=True)
    ir_o3 = os.path.join(dir_o3, "prod_O3.ll")
    cmd_ir_o3 = [CLANG, "-O3", "-S", "-emit-llvm", src_path, "-o", ir_o3]
    subprocess.run(cmd_ir_o3, check=True)
    exe_o3, _, cmd_exe_o3 = _build_executable(ir_o3, dir_o3, CLANG, "-O3")

    # 3. Build TOACD Custom Pipeline (opt -> clang -O2)
    dir_toacd = os.path.join(prog_dir, "toacd")
    os.makedirs(dir_toacd, exist_ok=True)
    ir_opt = os.path.join(dir_toacd, "toacd_opt.ll")
    cmd_opt = [OPT, f"-passes={toacd_passes}", "-S", ir_o0, "-o", ir_opt]
    subprocess.run(cmd_opt, check=True)
    exe_toacd, _, cmd_exe_toacd = _build_executable(ir_opt, dir_toacd, CLANG, "-O2")

    print("\n--- COMPILER COMMANDS INSPECTED ---")
    print(f"[-O0 Baseline]      : {' '.join(cmd_ir_o0)} -> {' '.join(cmd_exe_o0)}")
    print(f"[-O3 Production]    : {' '.join(cmd_ir_o3)} -> {' '.join(cmd_exe_o3)}")
    print(f"[TOACD Custom]      : {' '.join(cmd_opt)} -> {' '.join(cmd_exe_toacd)}")

    # Correctness check
    p_ref = subprocess.run([exe_o0], capture_output=True, text=True, timeout=10)
    p_o3 = subprocess.run([exe_o3], capture_output=True, text=True, timeout=10)
    p_toacd = subprocess.run([exe_toacd], capture_output=True, text=True, timeout=10)

    print("\n--- OUTPUT CORRECTNESS VERIFICATION ---")
    print(f"  Reference -O0 : exit={p_ref.returncode}, stdout={p_ref.stdout.strip()}")
    print(f"  Production -O3: exit={p_o3.returncode}, stdout={p_o3.stdout.strip()}")
    print(f"  TOACD Custom  : exit={p_toacd.returncode}, stdout={p_toacd.stdout.strip()}")
    assert p_o3.stdout == p_ref.stdout and p_o3.returncode == p_ref.returncode, "O3 divergent output!"
    assert p_toacd.stdout == p_ref.stdout and p_toacd.returncode == p_ref.returncode, "TOACD divergent output!"
    print("  => 100% Correctness Match Verified against Reference Baseline.")

    # Interleaved measurement: 2 warmups, 5 timed runs
    targets = [
        ("clang -O0", exe_o0),
        ("clang -O3", exe_o3),
        (f"TOACD ({toacd_passes} -> clang -O2)", exe_toacd),
    ]
    mresults = measure_interleaved(targets, warmup_runs=2, measure_runs=5, timeout_s=10)

    stats_dict = {}
    print("\n--- EMPIRICAL MEASUREMENTS (Paired Interleaved, 2 Warmups, 5 Repetitions) ---")
    for name, mres in mresults.items():
        t = mres.timing
        samples_ms = [round(s / 1e6, 3) for s in mres.raw_samples_ns]
        code_size = mres.code_size.file_size_bytes if mres.code_size else os.path.getsize(mres.exe_path)
        stats_dict[name] = {
            "samples_ms": samples_ms,
            "median_ms": round(t.median_s * 1000, 3),
            "mean_ms": round(t.mean_s * 1000, 3),
            "stdev_ms": round(t.stdev_ns / 1e6, 3),
            "min_ms": round(t.min_ns / 1e6, 3),
            "max_ms": round(t.max_ns / 1e6, 3),
            "cv": round(t.cv, 4),
            "cv_pct": f"{t.cv:.2%}",
            "code_size_bytes": code_size,
            "timing_is_reliable": mres.timing_is_reliable,
        }
        print(f"\n[{name}]")
        print(f"  Raw Samples (ms) : {samples_ms}")
        print(f"  Median           : {stats_dict[name]['median_ms']} ms")
        print(f"  Mean ± StdDev    : {stats_dict[name]['mean_ms']} ms ± {stats_dict[name]['stdev_ms']} ms")
        print(f"  Timing Range     : {stats_dict[name]['min_ms']} ms to {stats_dict[name]['max_ms']} ms")
        print(f"  CV               : {stats_dict[name]['cv_pct']} ({'<=10% Reliable' if t.cv <= 0.10 else '>10% Noisy'})")
        print(f"  Binary Size      : {code_size:,} bytes")
        print(f"  Timing Reliable  : {mres.timing_is_reliable}")

    # Comparative analysis
    base_t = stats_dict["clang -O0"]["median_ms"]
    o3_t = stats_dict["clang -O3"]["median_ms"]
    toacd_name = [k for k in stats_dict if "TOACD" in k][0]
    toacd_t = stats_dict[toacd_name]["median_ms"]

    speedup_o3 = round(base_t / o3_t, 2) if o3_t > 0 else 1.0
    speedup_toacd = round(base_t / toacd_t, 2) if toacd_t > 0 else 1.0

    print("\n--- COMPARATIVE PERFORMANCE vs BASELINE (-O0) ---")
    print(f"  Production -O3 Speedup : {speedup_o3:.2f}x ({base_t} ms -> {o3_t} ms, {((base_t - o3_t)/base_t)*100:.1f}% reduction)")
    print(f"  TOACD Custom Speedup   : {speedup_toacd:.2f}x ({base_t} ms -> {toacd_t} ms, {((base_t - toacd_t)/base_t)*100:.1f}% reduction)")

    return stats_dict

results = {}
results["GEMM"] = run_experiment("GEMM", gemm_src_path, "mem2reg,instcombine,simplifycfg,gvn,loop-unroll")
results["TC1"] = run_experiment("TC1", tc1_src_path, "mem2reg,simplifycfg")

with open(os.path.join(workdir, "final_experiment_results.json"), "w") as f:
    json.dump(results, f, indent=2)
