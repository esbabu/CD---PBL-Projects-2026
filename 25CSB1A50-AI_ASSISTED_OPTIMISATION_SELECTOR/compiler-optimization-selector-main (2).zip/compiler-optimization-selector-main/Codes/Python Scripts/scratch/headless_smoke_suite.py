"""
headless_smoke_suite.py — Automated Headless Smoke Verification for TOACD Stage 15.5.

Architecture Principle: "The LLM Explains. The Compiler Decides."
"""

import os
import sys
import json
import time
import base64
import asyncio
import urllib.request
import subprocess
from typing import Any, Dict, List, Optional

import tornado.websocket

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
BASE_URL = "http://127.0.0.1:8080"
ARTIFACT_DIR = r"C:\Users\rithv\.gemini\antigravity\brain\8ccbacb0-d2dc-43e5-a87e-baec13f3ebbb"
TEMP_USER_DATA = r"C:\Users\rithv\AppData\Local\Temp\chrome_smoke_stage15_5"


class CDPClient:
    def __init__(self, ws):
        self.ws = ws
        self.msg_id = 0
        self.pending = {}
        self.console_messages = []
        self.unhandled_exceptions = []
        self.network_failures = []
        self.network_requests = {}
        self.event_handlers = {}
        self._listener_task = asyncio.create_task(self._listen())

    async def _listen(self):
        try:
            while True:
                raw = await self.ws.read_message()
                if raw is None:
                    break
                data = json.loads(raw)
                if "id" in data:
                    req_id = data["id"]
                    if req_id in self.pending:
                        self.pending[req_id].set_result(data)
                elif "method" in data:
                    method = data["method"]
                    params = data.get("params", {})
                    
                    if method == "Runtime.consoleAPICalled":
                        text = " ".join([str(a.get("value", a.get("description", ""))) for a in params.get("args", [])])
                        msg_type = params.get("type", "log")
                        self.console_messages.append({"type": msg_type, "text": text})
                        if msg_type in ("error", "assert"):
                            print(f"  [BROWSER CONSOLE {msg_type.upper()}]: {text}")
                    elif method == "Runtime.exceptionThrown":
                        details = params.get("exceptionDetails", {})
                        exc_text = details.get("text", "")
                        if "exception" in details:
                            exc_text += " " + str(details["exception"].get("description", ""))
                        self.unhandled_exceptions.append(exc_text)
                        print(f"  [BROWSER UNHANDLED EXCEPTION]: {exc_text}")
                    elif method == "Network.responseReceived":
                        resp = params.get("response", {})
                        status = resp.get("status", 200)
                        url = resp.get("url", "")
                        if status >= 400 and not url.endswith("/favicon.ico"):
                            self.network_failures.append({"url": url, "status": status, "statusText": resp.get("statusText", "")})
                            print(f"  [NETWORK ERROR {status}]: {url}")
                    elif method == "Network.loadingFailed":
                        url = params.get("url", "")
                        err = params.get("errorText", "")
                        if not url.endswith("/favicon.ico"):
                            self.network_failures.append({"url": url, "status": "FAILED", "statusText": err})
                            print(f"  [NETWORK FAILED]: {url} ({err})")

                    if method in self.event_handlers:
                        for handler in self.event_handlers[method]:
                            handler(params)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"CDP listener error: {e}")

    async def send(self, method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.msg_id += 1
        req_id = self.msg_id
        fut = asyncio.get_event_loop().create_future()
        self.pending[req_id] = fut
        payload = {"id": req_id, "method": method, "params": params or {}}
        await self.ws.write_message(json.dumps(payload))
        res = await fut
        del self.pending[req_id]
        if "error" in res:
            raise RuntimeError(f"CDP error in {method}: {res['error']}")
        return res.get("result", {})

    async def evaluate(self, expression: str) -> Any:
        res = await self.send("Runtime.evaluate", {
            "expression": expression,
            "returnByValue": True,
            "awaitPromise": True,
        })
        val = res.get("result", {})
        if "value" in val:
            return val["value"]
        return val

    async def set_viewport(self, width: int, height: int, mobile: bool = False):
        await self.send("Emulation.setDeviceMetricsOverride", {
            "width": width,
            "height": height,
            "deviceScaleFactor": 1 if not mobile else 2,
            "mobile": mobile,
        })
        await self.send("Emulation.setVisibleSize", {"width": width, "height": height})

    async def screenshot(self, filename: str, full_page: bool = False) -> str:
        out_path = os.path.join(ARTIFACT_DIR, filename)
        res = await self.send("Page.captureScreenshot", {
            "format": "png",
            "fromSurface": True,
            "captureBeyondViewport": full_page,
        })
        img_bytes = base64.b64decode(res["data"])
        with open(out_path, "wb") as f:
            f.write(img_bytes)
        print(f"  [SCREENSHOT SAVED]: {filename} ({len(img_bytes):,} bytes)")
        return out_path

    async def wait_for_condition(self, expression: str, timeout: float = 30.0) -> bool:
        start = time.time()
        while time.time() - start < timeout:
            try:
                val = await self.evaluate(expression)
                if val:
                    return True
            except Exception:
                pass
            await asyncio.sleep(0.4)
        return False

    def close(self):
        self._listener_task.cancel()
        self.ws.close()


async def run_smoke_verification():
    print("=" * 75)
    print("  TOACD Stage 15.5: Headless Smoke Verification Suite")
    print("  Architecture Principle: The LLM Explains. The Compiler Decides.")
    print("=" * 75)

    # 1. Check Server Connectivity
    print("\n--- 1. Verifying Web Server Connectivity ---")
    try:
        resp = urllib.request.urlopen(f"{BASE_URL}/api/status", timeout=5)
        status_data = json.loads(resp.read().decode())
        print(f"  [PASS] Server online at {BASE_URL}")
        print(f"  [PASS] Clang version: {status_data.get('clang_version')}")
        print(f"  [PASS] Opt version: {status_data.get('opt_version')}")
        print(f"  [PASS] Toolchain OK: {status_data.get('toolchain_ok')}")
    except Exception as e:
        print(f"  [FAIL] Could not connect to TOACD server at {BASE_URL}: {e}")
        return False

    # 2. Launch Chrome Headless with Remote Debugging
    print("\n--- 2. Launching Headless Chrome via CDP ---")
    os.makedirs(TEMP_USER_DATA, exist_ok=True)
    chrome_proc = subprocess.Popen([
        CHROME_PATH,
        "--headless=new",
        "--remote-debugging-port=9222",
        f"--user-data-dir={TEMP_USER_DATA}",
        "--no-first-run",
        "--disable-gpu",
        "--hide-scrollbars",
        "about:blank",
    ])
    await asyncio.sleep(2)

    results = {
        "passed": [],
        "failed": [],
        "screenshots": [],
    }

    try:
        targets = json.loads(urllib.request.urlopen("http://127.0.0.1:9222/json").read().decode())
        page_target = [t for t in targets if t.get("type") == "page"][0]
        ws_url = page_target["webSocketDebuggerUrl"]
        raw_ws = await tornado.websocket.websocket_connect(ws_url)
        client = CDPClient(raw_ws)

        await client.send("Page.enable")
        await client.send("Runtime.enable")
        await client.send("Console.enable")
        await client.send("Network.enable")
        await client.send("DOM.enable")

        # Set default desktop viewport
        await client.set_viewport(1280, 1000)

        # -------------------------------------------------------------------
        # Test 1: Page Navigation, Asset Loading & Console Integrity
        # -------------------------------------------------------------------
        print("\n--- Test 1: Navigation, Asset Loading & Console Integrity ---")
        await client.send("Page.navigate", {"url": f"{BASE_URL}/"})
        await asyncio.sleep(2)

        title = await client.evaluate("document.title")
        assert "TOACD" in title, f"Unexpected title: {title}"
        print(f"  [PASS] Document loaded with title: '{title}'")

        if client.unhandled_exceptions:
            print(f"  [FAIL] Unhandled JS exceptions found: {client.unhandled_exceptions}")
            results["failed"].append("Test 1: Unhandled JS exceptions")
        else:
            print("  [PASS] Zero unhandled JavaScript exceptions during initial load")
            results["passed"].append("Test 1: Clean JS execution (0 unhandled exceptions)")

        if client.network_failures:
            print(f"  [FAIL] Network failures found: {client.network_failures}")
            results["failed"].append("Test 1: Network resource failures")
        else:
            print("  [PASS] Zero HTTP 4xx/5xx network failures for static assets")
            results["passed"].append("Test 1: Static asset HTTP 200 delivery")

        # -------------------------------------------------------------------
        # Test 2: Toolchain Status & Sample Benchmarks Dropdown
        # -------------------------------------------------------------------
        print("\n--- Test 2: Toolchain Status & Sample Benchmarks Dropdown ---")
        toolchain_engine = await client.evaluate("document.getElementById('toolchain-engine-text') ? document.getElementById('toolchain-engine-text').textContent : ''")
        sidebar_status = await client.evaluate("document.getElementById('sidebar-llvm-status') ? document.getElementById('sidebar-llvm-status').textContent : ''")
        print(f"  [PASS] Toolchain engine badge: '{toolchain_engine.strip()}'")
        print(f"  [PASS] Sidebar toolchain status: '{sidebar_status.strip()}'")
        assert "clang" in toolchain_engine.lower() and "ready" in toolchain_engine.lower(), "Toolchain engine badge mismatch"

        samples_count = await client.evaluate("""
            (function() {
                var select = document.getElementById('benchmark-select');
                return select ? select.options.length : 0;
            })()
        """)
        print(f"  [PASS] Benchmark dropdown populated with {samples_count} sample programs")
        assert samples_count >= 6, f"Expected at least 6 sample benchmarks, found {samples_count}"
        results["passed"].append(f"Test 2: Toolchain status verified and {samples_count} sample benchmarks loaded")

        # -------------------------------------------------------------------
        # Test 3: Theme Switching & Persistence
        # -------------------------------------------------------------------
        print("\n--- Test 3: Dark/Light Theme Switching & Persistence ---")
        is_dark_initial = await client.evaluate("document.documentElement.classList.contains('dark')")
        print(f"  [INFO] Initial theme is dark: {is_dark_initial}")

        # Capture Light Dashboard Screenshot
        s_dash_light = await client.screenshot("stage15_5_dashboard_desktop_light.png")
        results["screenshots"].append(s_dash_light)

        # Click theme toggle button
        await client.evaluate("document.getElementById('theme-toggle-btn').click()")
        await asyncio.sleep(0.5)
        is_dark_after_toggle = await client.evaluate("document.documentElement.classList.contains('dark')")
        print(f"  [PASS] After toggle, theme is dark: {is_dark_after_toggle}")
        assert is_dark_after_toggle != is_dark_initial, "Theme toggle did not flip document dark class"

        # Capture Dark Dashboard Screenshot
        s_dash_dark = await client.screenshot("stage15_5_dashboard_desktop_dark.png")
        results["screenshots"].append(s_dash_dark)

        # Reload to verify persistence
        await client.send("Page.reload")
        await asyncio.sleep(1.5)
        is_dark_after_reload = await client.evaluate("document.documentElement.classList.contains('dark')")
        print(f"  [PASS] After reload, theme persistence verified: is_dark={is_dark_after_reload}")
        assert is_dark_after_reload == is_dark_after_toggle, "Theme preference did not persist after reload"

        # Switch back to light theme
        await client.evaluate("document.getElementById('theme-toggle-btn').click()")
        await asyncio.sleep(0.5)
        results["passed"].append("Test 3: Theme switching and localStorage persistence across reloads")

        # -------------------------------------------------------------------
        # Test 4: Program Categorization Modal Interaction
        # -------------------------------------------------------------------
        print("\n--- Test 4: Program Categorization Modal Interaction ---")
        await client.evaluate("openProgramProfileModal()")
        await asyncio.sleep(0.5)

        is_modal_open = await client.evaluate("!document.getElementById('program-profile-modal').classList.contains('hidden')")
        print(f"  [PASS] Program Categorization modal opened: {is_modal_open}")
        assert is_modal_open, "Modal failed to open"

        modal_title = await client.evaluate("document.getElementById('profile-modal-title').textContent")
        modal_features_count = await client.evaluate("document.getElementById('modal-features-container').children.length")
        print(f"  [PASS] Modal Title: '{modal_title}' | Canonical features rendered: {modal_features_count}")
        assert modal_features_count == 8, f"Expected 8 canonical features, got {modal_features_count}"

        s_modal = await client.screenshot("stage15_5_modal_open.png")
        results["screenshots"].append(s_modal)

        # Close via Escape key
        await client.evaluate("""
            (function() {
                var evt = new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true });
                document.dispatchEvent(evt);
            })()
        """)
        await asyncio.sleep(0.5)
        is_modal_closed = await client.evaluate("document.getElementById('program-profile-modal').classList.contains('hidden')")
        print(f"  [PASS] Modal closed via Escape key: {is_modal_closed}")
        assert is_modal_closed, "Modal failed to close via Escape key"
        results["passed"].append("Test 4: Program Categorization Modal opening, 8 features, and Escape closure")

        # -------------------------------------------------------------------
        # Test 5: Live Multi-Agent Workflow — LinUCB Optimization
        # -------------------------------------------------------------------
        print("\n--- Test 5: Live Multi-Agent Workflow — LinUCB Optimization ---")
        # Load sample tc1_loop_heavy
        await client.evaluate("onSampleSelected('tc1_loop_heavy')")
        await asyncio.sleep(1)

        # Select model family LinUCB
        await client.evaluate("""
            (function() {
                var m = document.getElementById('select-model-family');
                if (m) {
                    m.value = 'linucb';
                    m.dispatchEvent(new Event('change'));
                }
            })()
        """)
        await asyncio.sleep(0.5)

        print("  [INFO] Triggering runAIOptimizedExecution() with LinUCB on tc1_loop_heavy...")
        await client.evaluate("runAIOptimizedExecution()")

        # Wait for workflow completion
        completed_linucb = await client.wait_for_condition("""
            (function() {
                return typeof aiState !== 'undefined' && aiState && (aiState.status === 'succeeded' || aiState.status === 'failed' || aiState.status === 'blocked');
            })()
        """, timeout=45.0)

        assert completed_linucb, f"LinUCB optimization workflow timed out or failed to complete. aiState={await client.evaluate('aiState ? aiState.status : null')}"
        print(f"  [PASS] LinUCB optimization workflow completed with status: {await client.evaluate('aiState.status')}")

        # Verify 6 canonical agents in activity drawer
        agents_found = await client.evaluate("""
            (function() {
                var el = document.getElementById('agent-messages-container');
                var text = (el ? el.textContent : '') + (typeof currentRunMessages !== 'undefined' ? JSON.stringify(currentRunMessages) : '');
                var agents = [
                    'CodeAnalystAgent',
                    'ProgramProfilingAgent',
                    'OptimizationStrategistAgent',
                    'OptimizationReviewerAgent',
                    'FinalDecisionAgent',
                    'BenchmarkAgent'
                ];
                return agents.filter(function(a) { return text.includes(a); });
            })()
        """)
        print(f"  [PASS] Canonical Agents verified in AI Activity log: {agents_found}")
        assert len(agents_found) >= 5, f"Expected all canonical agents, found {agents_found}"

        # Expand Accordion 6: Explainable AI
        await client.evaluate("""
            (function() {
                var sec = document.getElementById('report-sec-6');
                if (sec && (sec.classList.contains('max-h-0') || sec.style.display === 'none')) {
                    var btn = document.querySelector('[onclick*=\"report-sec-6\"]');
                    if (btn) btn.click();
                }
            })()
        """)
        await asyncio.sleep(1)

        linucb_summary_strat = await client.evaluate("document.getElementById('xai-sum-strat') ? document.getElementById('xai-sum-strat').textContent : ''")
        linucb_model_badge = await client.evaluate("document.getElementById('xai-summary-model-badge') ? document.getElementById('xai-summary-model-badge').textContent : ''")
        linucb_feature_count = await client.evaluate("document.getElementById('xai-features-container') ? document.getElementById('xai-features-container').children.length : 0")
        
        print(f"  [PASS] XAI Selected Strategy: '{linucb_summary_strat}'")
        print(f"  [PASS] XAI Model Badge: '{linucb_model_badge}'")
        print(f"  [PASS] Canonical IR features rendered count: {linucb_feature_count}")
        assert linucb_feature_count == 8, f"Expected 8 canonical features, got {linucb_feature_count}"
        assert "LinUCB" in linucb_model_badge or "linucb" in linucb_model_badge, f"Expected LinUCB badge, got: {linucb_model_badge}"

        s_linucb = await client.screenshot("stage15_5_linucb_xai_desktop.png")
        results["screenshots"].append(s_linucb)
        results["passed"].append("Test 5: Live LinUCB Multi-Agent Workflow and XAI Decomposition")

        # -------------------------------------------------------------------
        # Test 6: Live Multi-Agent Workflow — DQN Optimization
        # -------------------------------------------------------------------
        print("\n--- Test 6: Live Multi-Agent Workflow — DQN Optimization ---")
        # Load sample gemm
        await client.evaluate("onSampleSelected('gemm')")
        await asyncio.sleep(1)

        # Select model family DQN
        await client.evaluate("""
            (function() {
                var m = document.getElementById('select-model-family');
                if (m) {
                    m.value = 'dqn';
                    m.dispatchEvent(new Event('change'));
                }
            })()
        """)
        await asyncio.sleep(0.5)

        print("  [INFO] Triggering runAIOptimizedExecution() with DQN on gemm...")
        await client.evaluate("runAIOptimizedExecution()")

        completed_dqn = await client.wait_for_condition("""
            (function() {
                return typeof aiState !== 'undefined' && aiState && (aiState.status === 'succeeded' || aiState.status === 'failed' || aiState.status === 'blocked');
            })()
        """, timeout=45.0)

        assert completed_dqn, f"DQN optimization workflow timed out or failed to complete. aiState={await client.evaluate('aiState ? aiState.status : null')}"
        print(f"  [PASS] DQN optimization workflow completed with status: {await client.evaluate('aiState.status')}")

        # Re-expand Accordion 6
        await client.evaluate("""
            (function() {
                var sec = document.getElementById('report-sec-6');
                if (sec && (sec.classList.contains('max-h-0') || sec.style.display === 'none')) {
                    var btn = document.querySelector('[onclick*=\"report-sec-6\"]');
                    if (btn) btn.click();
                }
            })()
        """)
        await asyncio.sleep(1)

        dqn_model_badge = await client.evaluate("document.getElementById('xai-summary-model-badge') ? document.getElementById('xai-summary-model-badge').textContent : ''")
        has_ucb_table = await client.evaluate("Boolean(document.querySelector('#xai-model-explanation-container table') && document.querySelector('#xai-model-explanation-container').textContent.includes('Exploration Bonus'))")
        
        print(f"  [PASS] DQN Model Badge: '{dqn_model_badge}'")
        print(f"  [PASS] LinUCB Exploration Bonus leaked in DQN view: {has_ucb_table}")
        assert not has_ucb_table, "LinUCB Exploration Bonus leaked into DQN view"
        assert "DQN" in dqn_model_badge or "production_v0" in dqn_model_badge, f"Expected DQN badge, got {dqn_model_badge}"

        s_dqn = await client.screenshot("stage15_5_dqn_xai_desktop.png")
        results["screenshots"].append(s_dqn)
        results["passed"].append("Test 6: Live DQN Multi-Agent Workflow and Q-Value Action Separation")

        # -------------------------------------------------------------------
        # Test 7: Security Gate Evaluation & Fallback/Rejection
        # -------------------------------------------------------------------
        print("\n--- Test 7: Security Gate Verification & Fallback/Rejection ---")
        await client.evaluate("onSampleSelected('tc2_security_bounds')")
        await asyncio.sleep(1)

        print("  [INFO] Running Security Gate evaluation on tc2_security_bounds...")
        await client.evaluate("runAIOptimizedExecution()")

        completed_sec = await client.wait_for_condition("""
            (function() {
                return typeof aiState !== 'undefined' && aiState && (aiState.status === 'succeeded' || aiState.status === 'failed' || aiState.status === 'blocked');
            })()
        """, timeout=45.0)

        assert completed_sec, f"Security evaluation workflow timed out. aiState={await client.evaluate('aiState ? aiState.status : null')}"

        sec_card_text = await client.evaluate("document.getElementById('xai-security-content') ? document.getElementById('xai-security-content').textContent : ''")
        print(f"  [PASS] Security Gate 5-item breakdown verified in live UI")
        assert "Original Recommendation:" in sec_card_text, "Missing Original Recommendation in Security Gate card"
        assert "Gate Decision:" in sec_card_text, "Missing Gate Decision in Security Gate card"
        assert "Candidate IR Verdict:" in sec_card_text, "Missing Candidate IR Verdict in Security Gate card"
        assert "Final Effective Strategy:" in sec_card_text, "Missing Final Effective Strategy in Security Gate card"

        s_sec = await client.screenshot("stage15_5_security_fallback.png")
        results["screenshots"].append(s_sec)
        results["passed"].append("Test 7: Security Gate evaluation & truthful 5-item breakdown")

        # -------------------------------------------------------------------
        # Test 8: Error Handling — Invalid C Source Input
        # -------------------------------------------------------------------
        print("\n--- Test 8: Error Handling — Invalid C Syntax Input ---")
        await client.evaluate("""
            (function() {
                var ta = document.getElementById('editor-textarea');
                ta.value = "int main() { syntax_error_missing_tokens ;;; invalid C code }";
                onEditorContentChanged();
            })()
        """)
        await asyncio.sleep(0.5)

        print("  [INFO] Submitting invalid C code to compiler...")
        await client.evaluate("runNormalExecution()")

        toast_appeared = await client.wait_for_condition("""
            (function() {
                var container = document.getElementById('toast-container');
                return (container && container.children.length > 0) || (typeof normalState !== 'undefined' && normalState && normalState.status === 'failed');
            })()
        """, timeout=20.0)

        print(f"  [PASS] Alert toast notification appeared: {toast_appeared}")
        assert toast_appeared, "Compilation failure toast failed to appear"

        toast_roles = await client.evaluate("""
            (function() {
                var toasts = document.querySelectorAll('#toast-container .toast-item');
                return Array.from(toasts).map(function(t) { return t.getAttribute('role'); });
            })()
        """)
        print(f"  [PASS] Toast accessible roles: {toast_roles} (accessible notification compliance)")
        assert len(toast_roles) > 0, "No toast notifications found"
        assert "alert" in toast_roles or "status" in toast_roles, f"Expected alert or status role, got '{toast_roles}'"

        s_err = await client.screenshot("stage15_5_compilation_error.png")
        results["screenshots"].append(s_err)
        results["passed"].append("Test 8: Honest error handling on invalid C syntax (role=alert toast)")

        # -------------------------------------------------------------------
        # Test 9: Mobile Viewport Responsiveness & Layout
        # -------------------------------------------------------------------
        print("\n--- Test 9: Mobile Viewport Responsiveness (375x812) ---")
        await client.set_viewport(375, 812, mobile=True)
        await asyncio.sleep(1)

        overflow_x = await client.evaluate("""
            (function() {
                return document.documentElement.scrollWidth > window.innerWidth;
            })()
        """)
        print(f"  [PASS] Horizontal page overflow detected: {overflow_x} (Expected: False)")
        assert not overflow_x, "Mobile viewport has unwanted horizontal page overflow"

        s_mob_light = await client.screenshot("stage15_5_mobile_light.png")
        results["screenshots"].append(s_mob_light)

        # Switch to Dark Mode on Mobile
        await client.evaluate("document.getElementById('theme-toggle-btn').click()")
        await asyncio.sleep(0.5)

        s_mob_dark = await client.screenshot("stage15_5_mobile_dark.png")
        results["screenshots"].append(s_mob_dark)
        results["passed"].append("Test 9: Mobile viewport responsiveness and zero page-level overflow")

        # -------------------------------------------------------------------
        # Test 10: AI Assistant Separation Check
        # -------------------------------------------------------------------
        print("\n--- Test 10: AI Assistant Pipeline Separation ---")
        assistant_tab_exists = await client.evaluate("Boolean(document.getElementById('right-tab-btn-assistant'))")
        print(f"  [PASS] AI Assistant navigation tab exists: {assistant_tab_exists}")
        assert assistant_tab_exists, "AI Assistant tab not found"

        await client.evaluate("document.getElementById('right-tab-btn-assistant').click()")
        await asyncio.sleep(0.5)

        assistant_container_visible = await client.evaluate("""
            (function() {
                var el = document.getElementById('right-panel-assistant-content');
                return el && !el.classList.contains('hidden');
            })()
        """)
        print(f"  [PASS] AI Assistant panel displayed independently: {assistant_container_visible}")
        assert assistant_container_visible, "AI Assistant panel failed to toggle"
        results["passed"].append("Test 10: AI Assistant pipeline separation and independent panel")

        client.close()
        print("\n" + "=" * 75)
        print("  SMOKE VERIFICATION RESULTS SUMMARY")
        print("=" * 75)
        print(f"Total Tests Passed: {len(results['passed'])}")
        print(f"Total Tests Failed: {len(results['failed'])}")
        print(f"Screenshots Captured: {len(results['screenshots'])}")
        for p in results["passed"]:
            print(f"  [PASS] {p}")
        for f in results["failed"]:
            print(f"  [FAIL] {f}")
        for s in results["screenshots"]:
            print(f"  [IMG]  {os.path.basename(s)}")
        print("=" * 75)

        return len(results["failed"]) == 0

    finally:
        chrome_proc.terminate()
        try:
            chrome_proc.wait(timeout=3)
        except Exception:
            chrome_proc.kill()


if __name__ == "__main__":
    success = asyncio.run(run_smoke_verification())
    sys.exit(0 if success else 1)
