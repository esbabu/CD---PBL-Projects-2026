import json
import numpy as np
from scipy import stats

res = json.load(open('compiler-optimization-selector-main/data/models/six_way_evaluation_results.json'))

# 1. LinUCB vs DQN (N=22)
lin_dqn = []
for p in res['per_program_results']:
    l = p['methods']['LinUCB']
    d = p['methods']['Historical_DQN']
    if l['status'] == 'VALID_CONCLUSIVE' and d['status'] == 'VALID_CONCLUSIVE':
        lin_dqn.append({
            'prog': p['program_id'],
            'lin_ms': l['median_ms'],
            'dqn_ms': d['median_ms'],
            'lin_sp0': l['speedup_vs_o0'],
            'dqn_sp0': d['speedup_vs_o0']
        })

print('=== LINUCB vs DQN PAIRED DATA (N=22) ===')
for x in lin_dqn:
    print(f"{x['prog']:25s} | LinUCB: {x['lin_ms']:7.2f} ms (sp0={x['lin_sp0']:.3f}) | DQN: {x['dqn_ms']:7.2f} ms (sp0={x['dqn_sp0']:.3f})")

lin_sp0 = np.array([x['lin_sp0'] for x in lin_dqn])
dqn_sp0 = np.array([x['dqn_sp0'] for x in lin_dqn])
lin_ms = np.array([x['lin_ms'] for x in lin_dqn])
dqn_ms = np.array([x['dqn_ms'] for x in lin_dqn])

tt_sp = stats.ttest_rel(lin_sp0, dqn_sp0)
wilc_sp = stats.wilcoxon(lin_sp0 - dqn_sp0)
tt_ms = stats.ttest_rel(lin_ms, dqn_ms)
wilc_ms = stats.wilcoxon(lin_ms - dqn_ms)

print('\nReproduced Stats (LinUCB vs DQN):')
print(f'  Speedup vs O0: t={tt_sp.statistic:.4f}, p={tt_sp.pvalue:.4f} | Wilcoxon W={wilc_sp.statistic:.1f}, p={wilc_sp.pvalue:.4f}')
print(f'  Runtime (ms):  t={tt_ms.statistic:.4f}, p={tt_ms.pvalue:.4f} | Wilcoxon W={wilc_ms.statistic:.1f}, p={wilc_ms.pvalue:.4f}')

# 2. LinUCB vs O3 (N=20)
lin_o3 = []
for p in res['per_program_results']:
    l = p['methods']['LinUCB']
    o = p['methods']['LLVM_O3']
    if l['status'] == 'VALID_CONCLUSIVE' and o['status'] == 'VALID_CONCLUSIVE':
        lin_o3.append({
            'prog': p['program_id'],
            'lin_ms': l['median_ms'],
            'o3_ms': o['median_ms'],
            'lin_sp0': l['speedup_vs_o0'],
            'o3_sp0': o['speedup_vs_o0']
        })

print('\n=== LINUCB vs LLVM -O3 PAIRED DATA (N=20) ===')
for x in lin_o3:
    print(f"{x['prog']:25s} | LinUCB: {x['lin_ms']:7.2f} ms (sp0={x['lin_sp0']:.3f}) | -O3: {x['o3_ms']:7.2f} ms (sp0={x['o3_sp0']:.3f})")

lin_sp0_o = np.array([x['lin_sp0'] for x in lin_o3])
o3_sp0 = np.array([x['o3_sp0'] for x in lin_o3])
lin_ms_o = np.array([x['lin_ms'] for x in lin_o3])
o3_ms = np.array([x['o3_ms'] for x in lin_o3])

tt_sp_o = stats.ttest_rel(lin_sp0_o, o3_sp0)
wilc_sp_o = stats.wilcoxon(lin_sp0_o - o3_sp0)
tt_ms_o = stats.ttest_rel(lin_ms_o, o3_ms)
wilc_ms_o = stats.wilcoxon(lin_ms_o - o3_ms)

print('\nReproduced Stats (LinUCB vs -O3):')
print(f'  Speedup vs O0: t={tt_sp_o.statistic:.4f}, p={tt_sp_o.pvalue:.4f} | Wilcoxon W={wilc_sp_o.statistic:.1f}, p={wilc_sp_o.pvalue:.4f}')
print(f'  Runtime (ms):  t={tt_ms_o.statistic:.4f}, p={tt_ms_o.pvalue:.4f} | Wilcoxon W={wilc_ms_o.statistic:.1f}, p={wilc_ms_o.pvalue:.4f}')
