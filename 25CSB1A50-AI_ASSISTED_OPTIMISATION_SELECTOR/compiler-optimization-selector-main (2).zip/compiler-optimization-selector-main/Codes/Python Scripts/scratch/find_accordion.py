import re

with open(r'compiler-optimization-selector-main\Codes\Python Scripts\web\static\index.html', encoding='utf-8') as f:
    html = f.read()

for m in re.finditer(r'accordion-xai', html, re.I):
    start = max(0, m.start() - 100)
    end = min(len(html), m.end() + 200)
    print("MATCH:\n", html[start:end])
