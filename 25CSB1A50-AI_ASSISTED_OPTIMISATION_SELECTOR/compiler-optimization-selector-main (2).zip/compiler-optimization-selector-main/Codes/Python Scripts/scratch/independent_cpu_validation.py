"""
independent_cpu_validation.py
Performs independent empirical cross-verification of Windows CPU-time accounting.
Evaluates Win32 GetProcessTimes alongside Win32 QueryProcessCycleTime.

TECHNICAL DETAILS & ARCHITECTURAL LIMITATIONS:
1. QueryProcessCycleTime:
   - Defined in realtimeapiset.h / kernel32.dll.
   - Microsoft specification: "Retrieves the cycle time for the sum of all threads
     of the specified process. The cycle time is the number of CPU clock cycles that have
     elapsed. This includes both user mode and kernel mode cycles."
   - Evidence of Activity vs. Computation Correctness: A nonzero process cycle count provides
     empirical evidence of recorded CPU activity associated with the process threads during its
     lifetime. However:
     * It does NOT prove that the target program successfully completed its intended computation.
     * It does NOT prove that the program produced correct or expected output.
     * It should NOT be used as a substitute for reliable elapsed-time measurement.
     * It cannot automatically establish exact CPU execution time in milliseconds.
   - Dynamic Frequency Scaling: Because modern x86_64 processors dynamically adjust clock
     frequency (via ACPI P-states, C-states, Intel Speed Shift, Intel Turbo Boost, and AMD
     Precision Boost), cycle counts cannot be reliably converted into absolute wall-clock
     milliseconds by dividing by a nominal base clock frequency.
   - Relationship with GetProcessTimes: Win32 GetProcessTimes updates thread accounting on
     discrete timer interrupt ticks (typically 15.625 ms quantum). For short processes (< 15.625 ms),
     GetProcessTimes may report 0 ms if no timer interrupt boundary was crossed. In such cases,
     QueryProcessCycleTime provides corroborating evidence that the operating system recorded CPU
     cycles for the process threads, helping distinguish sub-quantum CPU execution from an idle,
     suspended, or un-dispatched process.

2. External / Non-Child-CPU Elapsed-Time Residual:
   - Defined as: T_residual = T_wall - (T_user + T_kernel).
   - Represents the time spent outside child process CPU execution (process creation overhead,
     OS loader, DLL initialization, file system I/O, paging, and scheduler preemption).
   - Note on Timer Quantization: Win32 GetProcessTimes relies on periodic timer interrupts
     (typically 15.625 ms resolution). Because the child's CPU time is updated at discrete
     timer tick boundaries, a process finishing right after a tick may have total CPU time
     that slightly exceeds high-resolution wall time (producing a small negative residual, e.g. -3ms).
   - Linearity of Expectation: To preserve statistical validity (mean(residual) == mean(wall) - mean(total_cpu)),
     residuals MUST NOT be clamped to zero (max(0, ...)).

Tests:
- Test A: Deterministic CPU-bound workload (~250ms computation)
- Test B: Sleeping workload (200ms Sleep)
- Test C: Sub-resolution short workload (~1ms computation < 15.625ms timer quantum)
"""
import ctypes
from ctypes import wintypes
import os
import subprocess
import sys
import time
import json

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INNER_REPO = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

class _FILETIME(ctypes.Structure):
    _fields_ = [
        ("dwLowDateTime", wintypes.DWORD),
        ("dwHighDateTime", wintypes.DWORD),
    ]

kernel32.GetProcessTimes.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(_FILETIME),
    ctypes.POINTER(_FILETIME),
    ctypes.POINTER(_FILETIME),
    ctypes.POINTER(_FILETIME),
]
kernel32.GetProcessTimes.restype = wintypes.BOOL

kernel32.QueryProcessCycleTime.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(ctypes.c_ulonglong),
]
kernel32.QueryProcessCycleTime.restype = wintypes.BOOL

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SYNCHRONIZE = 0x00100000

def get_cpu_info():
    """Estimate nominal CPU clock frequency in Hz using high-resolution counter."""
    freq = ctypes.c_int64()
    kernel32.QueryPerformanceFrequency(ctypes.byref(freq))
    return freq.value

def run_instrumented(exe_path, args=None):
    cmd = [exe_path] + (args or [])
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL)
    
    h_proc = None
    if p.pid:
        h_proc = kernel32.OpenProcess(
            PROCESS_QUERY_INFORMATION | PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE,
            False, p.pid
        )
    
    t0 = time.perf_counter_ns()
    out, err = p.communicate()
    t_wall_ns = time.perf_counter_ns() - t0
    rc = p.returncode

    user_ns = 0
    kernel_ns = 0
    cycle_count = 0
    gpt_status = "UNKNOWN"
    gpt_error = None

    if h_proc:
        try:
            c_time = _FILETIME()
            e_time = _FILETIME()
            k_time = _FILETIME()
            u_time = _FILETIME()
            ok_gpt = kernel32.GetProcessTimes(
                h_proc,
                ctypes.byref(c_time),
                ctypes.byref(e_time),
                ctypes.byref(k_time),
                ctypes.byref(u_time),
            )
            if ok_gpt:
                user_ns = int(((u_time.dwHighDateTime << 32) | u_time.dwLowDateTime) * 100)
                kernel_ns = int(((k_time.dwHighDateTime << 32) | k_time.dwLowDateTime) * 100)
                if user_ns == 0 and kernel_ns == 0:
                    gpt_status = "BELOW_RESOLUTION"
                else:
                    gpt_status = "OK"
            else:
                gpt_status = "API_ERROR"
                gpt_error = f"Win32 error {ctypes.get_last_error()}"

            cycles = ctypes.c_ulonglong(0)
            ok_cycle = kernel32.QueryProcessCycleTime(h_proc, ctypes.byref(cycles))
            if ok_cycle:
                cycle_count = cycles.value
        finally:
            kernel32.CloseHandle(h_proc)

    total_cpu_ns = user_ns + kernel_ns
    # Unclamped residual to preserve linearity of expectation under timer quantization:
    residual_ns = t_wall_ns - total_cpu_ns

    return {
        "return_code": rc,
        "stdout": out.decode("utf-8", errors="replace").strip(),
        "wall_time_ms": round(t_wall_ns / 1e6, 3),
        "user_cpu_ms": round(user_ns / 1e6, 3),
        "kernel_cpu_ms": round(kernel_ns / 1e6, 3),
        "total_cpu_ms": round(total_cpu_ns / 1e6, 3),
        "residual_ms": round(residual_ns / 1e6, 3),
        "residual_pct": round(residual_ns / t_wall_ns * 100.0, 1) if t_wall_ns > 0 else 0.0,
        "cycle_count": cycle_count,
        "gpt_status": gpt_status,
        "gpt_error": gpt_error,
    }

def main():
    print("==================================================================")
    print("INDEPENDENT VALIDATION OF WINDOWS CPU-TIME ACCOUNTING")
    print("Method: Cross-verifying GetProcessTimes against QueryProcessCycleTime")
    print("==================================================================")

    clang = os.path.join(INNER_REPO, "Codes", "test_cases", "clang_check.exe")
    # Locate clang
    clang_exe = "clang"

    test_c_dir = os.path.join(SCRIPT_DIR, "validation_progs")
    os.makedirs(test_c_dir, exist_ok=True)

    # 1. Program A: Sustained CPU-bound workload (deterministic ~200-250ms computation)
    prog_a_c = os.path.join(test_c_dir, "prog_a_cpu.c")
    prog_a_exe = os.path.join(test_c_dir, "prog_a_cpu.exe")
    with open(prog_a_c, "w") as f:
        f.write("""
#include <stdio.h>
int main(void) {
    volatile unsigned long long acc = 0;
    for (unsigned long long i = 0; i < 500000000ULL; i++) {
        acc += (i ^ (i >> 1));
    }
    printf("ACC=%llu\\n", acc);
    return 0;
}
""")
    subprocess.run([clang_exe, "-O0", prog_a_c, "-o", prog_a_exe], check=True)

    # 2. Program B: Sleeping workload (200ms Sleep)
    prog_b_c = os.path.join(test_c_dir, "prog_b_sleep.c")
    prog_b_exe = os.path.join(test_c_dir, "prog_b_sleep.exe")
    with open(prog_b_c, "w") as f:
        f.write("""
#include <stdio.h>
#include <windows.h>
int main(void) {
    Sleep(200);
    printf("SLEEP_DONE\\n");
    return 0;
}
""")
    subprocess.run([clang_exe, "-O0", prog_b_c, "-o", prog_b_exe], check=True)

    # 3. Program C: Short execution workload (~1ms computation < 15.625ms timer quantum)
    prog_c_c = os.path.join(test_c_dir, "prog_c_short.c")
    prog_c_exe = os.path.join(test_c_dir, "prog_c_short.exe")
    with open(prog_c_c, "w") as f:
        f.write("""
#include <stdio.h>
int main(void) {
    volatile int x = 0;
    for (int i = 0; i < 50000; i++) {
        x += (i & 1);
    }
    printf("SHORT_DONE=%d\\n", x);
    return 0;
}
""")
    subprocess.run([clang_exe, "-O0", prog_c_c, "-o", prog_c_exe], check=True)

    # Warmup runs to ensure binaries are scanned and cached by OS loader / Defender
    print("Performing binary warmup executions...")
    run_instrumented(prog_a_exe)
    run_instrumented(prog_b_exe)
    run_instrumented(prog_c_exe)

    results = {}

    # Run Test A (5 runs)
    print("\n--- TEST A: Sustained CPU-Bound Workload ---")
    runs_a = []
    for r in range(5):
        res = run_instrumented(prog_a_exe)
        runs_a.append(res)
        print(f"Run {r+1}: Wall={res['wall_time_ms']:7.2f}ms | UserCPU={res['user_cpu_ms']:6.2f}ms | KernCPU={res['kernel_cpu_ms']:6.2f}ms | TotalCPU={res['total_cpu_ms']:6.2f}ms | Residual={res['residual_ms']:6.2f}ms ({res['residual_pct']:4.1f}%) | Cycles={res['cycle_count']:12,d} | Status={res['gpt_status']}")
    results["Test_A_CPU_Bound"] = runs_a

    # Run Test B (5 runs)
    print("\n--- TEST B: Sleeping Workload (200ms Sleep) ---")
    runs_b = []
    for r in range(5):
        res = run_instrumented(prog_b_exe)
        runs_b.append(res)
        print(f"Run {r+1}: Wall={res['wall_time_ms']:7.2f}ms | UserCPU={res['user_cpu_ms']:6.2f}ms | KernCPU={res['kernel_cpu_ms']:6.2f}ms | TotalCPU={res['total_cpu_ms']:6.2f}ms | Residual={res['residual_ms']:6.2f}ms ({res['residual_pct']:4.1f}%) | Cycles={res['cycle_count']:12,d} | Status={res['gpt_status']}")
    results["Test_B_Sleeping"] = runs_b

    # Run Test C (5 runs)
    print("\n--- TEST C: Sub-Resolution Short Execution (< 15.625ms quantum) ---")
    runs_c = []
    for r in range(5):
        res = run_instrumented(prog_c_exe)
        runs_c.append(res)
        print(f"Run {r+1}: Wall={res['wall_time_ms']:7.2f}ms | UserCPU={res['user_cpu_ms']:6.2f}ms | KernCPU={res['kernel_cpu_ms']:6.2f}ms | TotalCPU={res['total_cpu_ms']:6.2f}ms | Residual={res['residual_ms']:6.2f}ms ({res['residual_pct']:4.1f}%) | Cycles={res['cycle_count']:12,d} | Status={res['gpt_status']}")
    results["Test_C_Sub_Resolution"] = runs_c

    # Print Summary Verification
    print("\n==================================================================")
    print("RESIDUAL AGGREGATION & LINEARITY VERIFICATION SUMMARY")
    print("==================================================================")
    for test_name, runs in [("Test A (CPU-Bound)", runs_a), ("Test B (Sleep)", runs_b), ("Test C (Sub-Resolution)", runs_c)]:
        mean_wall = sum(r["wall_time_ms"] for r in runs) / len(runs)
        mean_user = sum(r["user_cpu_ms"] for r in runs) / len(runs)
        mean_kern = sum(r["kernel_cpu_ms"] for r in runs) / len(runs)
        mean_cpu = sum(r["total_cpu_ms"] for r in runs) / len(runs)
        mean_res = sum(r["residual_ms"] for r in runs) / len(runs)
        arith_diff = mean_wall - mean_cpu
        discrepancy = abs(mean_res - arith_diff)
        print(f"\n{test_name}:")
        print(f"  Mean Wall Time:     {mean_wall:8.3f} ms")
        print(f"  Mean User CPU:      {mean_user:8.3f} ms")
        print(f"  Mean Kernel CPU:    {mean_kern:8.3f} ms")
        print(f"  Mean Total CPU:     {mean_cpu:8.3f} ms")
        print(f"  Mean Residual:      {mean_res:8.3f} ms")
        print(f"  Mean(Wall) - Mean(CPU): {arith_diff:8.3f} ms")
        print(f"  Discrepancy:        {discrepancy:8.6f} ms -> {'PERFECT MATCH (Linearity Preserved)' if discrepancy < 0.001 else 'MISMATCH'}")

    out_file = os.path.join(SCRIPT_DIR, "independent_cpu_validation_results.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"\nIndependent validation complete! Results written to: {out_file}")

if __name__ == "__main__":
    main()
