import os, subprocess, tempfile
from moo.config import CLANG_PATH, OPT_PATH, ACTIONS
from moo.strategy_diagnostic import _run_clang_flag_strategy, _run_opt_passes_strategy, _build_executable, _generate_baseline

test_cases = [
    'TC1_loop_heavy.c',
    'TC2_security_bounds_check.c',
    'TC3_math_intensive.c',
    'TC4_security_null_overflow.c',
    'TC5_recursive_fibonacci.c',
    '26_bubble_sort.c',
    'gemm.c',
    'math_heavy.c',
    'memory_ops.c',
    'loops_branches.c'
]

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
tc_dir = os.path.join(os.path.dirname(base_dir), "test_cases")

print('=== TESTING COMPILER TRANSFORMATION CORRECTNESS & OUTPUT CONSISTENCY ===')

for tc in test_cases:
    src = os.path.join(tc_dir, tc)
    if not os.path.exists(src):
        print(f'{tc:28} | File not found')
        continue
    
    with tempfile.TemporaryDirectory() as td:
        base_info = _generate_baseline(src, td, CLANG_PATH)
        if not base_info.exe_ok:
            print(f'{tc:28} | FAILED TO BUILD BASELINE: {base_info.exe_stderr[:80]}')
            continue
        
        ref_rc = base_info.run_returncode
        ref_out = base_info.run_stdout.strip()
        
        mismatches = []
        for action in ACTIONS:
            strat_dir = os.path.join(td, action.replace(',', '_'))
            os.makedirs(strat_dir, exist_ok=True)
            if action.startswith('-O'):
                ir_path, res, _ = _run_clang_flag_strategy(action, src, strat_dir, CLANG_PATH)
                backend_flag = action
            else:
                ir_path, results, _ = _run_opt_passes_strategy(action, src, strat_dir, CLANG_PATH, OPT_PATH)
                backend_flag = '-O2'
            
            if not ir_path:
                mismatches.append(f'{action}: IR failed')
                continue
            
            exe_path, b_res, _ = _build_executable(ir_path, strat_dir, CLANG_PATH, opt_flag=backend_flag)
            if not exe_path:
                mismatches.append(f'{action}: Build failed')
                continue
            
            run_res = subprocess.run([exe_path], capture_output=True, text=True, timeout=10)
            act_rc = run_res.returncode
            act_out = run_res.stdout.strip()
            
            if act_rc != ref_rc or act_out != ref_out:
                mismatches.append(f'{action} (rc: {act_rc} vs ref {ref_rc}, out: {act_out[:20]} vs {ref_out[:20]})')
        
        if not mismatches:
            print(f'{tc:28} | PASS: ALL 9 STRATEGIES MATCH REFERENCE (rc={ref_rc}, out={ref_out[:25]!r})')
        else:
            print(f'{tc:28} | MISMATCHES: {mismatches}')
