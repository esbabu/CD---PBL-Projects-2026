import os, tempfile
from moo.config import CLANG_PATH, OPT_PATH
from moo.measurement import measure_interleaved
from moo.strategy_diagnostic import _run_clang_flag_strategy, _run_opt_passes_strategy, _build_executable, _generate_baseline

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(os.path.dirname(base_dir), "test_cases", "gemm.c")

with tempfile.TemporaryDirectory() as td:
    # 1. Baseline -O0
    b_info = _generate_baseline(src, td, CLANG_PATH)
    base_exe = b_info.exe_path
    
    # 2. Clang -O2
    d_o2 = os.path.join(td, 'o2')
    os.makedirs(d_o2, exist_ok=True)
    ir_o2, _, _ = _run_clang_flag_strategy('-O2', src, d_o2, CLANG_PATH)
    exe_o2, _, _ = _build_executable(ir_o2, d_o2, CLANG_PATH, opt_flag='-O2')
    
    # 3. Clang -O3
    d_o3 = os.path.join(td, 'o3')
    os.makedirs(d_o3, exist_ok=True)
    ir_o3, _, _ = _run_clang_flag_strategy('-O3', src, d_o3, CLANG_PATH)
    exe_o3, _, _ = _build_executable(ir_o3, d_o3, CLANG_PATH, opt_flag='-O3')
    
    # 4. Custom pass: mem2reg,instcombine,simplifycfg,gvn,loop-unroll
    strat = 'mem2reg,instcombine,simplifycfg,gvn,loop-unroll'
    d_custom = os.path.join(td, 'custom')
    os.makedirs(d_custom, exist_ok=True)
    ir_custom, _, _ = _run_opt_passes_strategy(strat, src, d_custom, CLANG_PATH, OPT_PATH)
    exe_custom, _, _ = _build_executable(ir_custom, d_custom, CLANG_PATH, opt_flag='-O2')
    
    targets = [
        ('-O0 (Baseline)', base_exe),
        ('-O2', exe_o2),
        ('-O3', exe_o3),
        ('Custom LLVM Passes', exe_custom),
    ]
    
    # Test with warmup=4, measure=5
    print('=== INTERLEAVED BENCHMARK OF GEMM.C (warmup=4, measure=5) ===')
    results = measure_interleaved(targets, warmup_runs=4, measure_runs=5)
    
    base_med_ms = results['-O0 (Baseline)'].timing.median_ns / 1e6
    for name, res in results.items():
        t = res.timing
        med_ms = t.median_ns / 1e6
        mean_ms = t.mean_ns / 1e6
        stdev_ms = t.stdev_ns / 1e6
        speedup = base_med_ms / med_ms if med_ms > 0 else 0
        samples_ms = [round(s / 1e6, 2) for s in res.raw_samples_ns]
        print(f'{name:22} | Median: {med_ms:6.2f} ms | Mean: {mean_ms:6.2f} ms | StDev: {stdev_ms:5.2f} ms | CV: {t.cv*100:4.1f}% | Reliable: {res.timing_is_reliable} | Speedup: {speedup:.2f}x')
        print(f'   Samples: {samples_ms}')
