"""
Codes/Python Scripts/scratch/test_cpu_measurement_programs.py
Validation of Process CPU-Time Measurement on Windows using:
Program A: Deterministic CPU-bound workload
Program B: Sleeping workload
"""

import os
import subprocess
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
sys.path.insert(0, PROJECT_ROOT)

from moo.measurement import _run_once, _WIN32_AVAILABLE

print(f"Windows API Available: {_WIN32_AVAILABLE}")

temp_a_c = os.path.join(SCRIPT_DIR, "temp_prog_a.c")
temp_a_exe = os.path.join(SCRIPT_DIR, "temp_prog_a.exe")
temp_b_c = os.path.join(SCRIPT_DIR, "temp_prog_b.c")
temp_b_exe = os.path.join(SCRIPT_DIR, "temp_prog_b.exe")

# Program A: CPU-bound loop running for ~150 ms
src_a = """#include <stdio.h>
int main(void) {
    volatile long long sum = 0;
    for (long long i = 0; i < 60000000LL; i++) {
        sum += (i ^ (i >> 3));
    }
    printf("SUM=%lld\\n", sum);
    return 0;
}
"""
with open(temp_a_c, "w") as f:
    f.write(src_a)

subprocess.run(["clang", temp_a_c, "-O0", "-o", temp_a_exe], check=True)

# Program B: Sleeping for 150 ms
src_b = """#include <stdio.h>
#include <windows.h>
int main(void) {
    Sleep(150);
    printf("SLEEP_OK\\n");
    return 0;
}
"""
with open(temp_b_c, "w") as f:
    f.write(src_b)

subprocess.run(["clang", temp_b_c, "-O0", "-o", temp_b_exe], check=True)

try:
    print("\n--- Program A (CPU-Bound Workload) ---")
    for i in range(3):
        rec_a = _run_once(temp_a_exe)
        wall_ms = rec_a.elapsed_ns / 1e6
        user_ms = rec_a.user_cpu_ns / 1e6 if rec_a.user_cpu_ns is not None else -1
        kern_ms = rec_a.kernel_cpu_ns / 1e6 if rec_a.kernel_cpu_ns is not None else -1
        total_cpu = user_ms + kern_ms
        residual_ms = wall_ms - total_cpu
        print(f"Run {i+1}: Wall={wall_ms:7.2f}ms | UserCPU={user_ms:7.2f}ms | KernCPU={kern_ms:7.2f}ms | TotalCPU={total_cpu:7.2f}ms | Residual={residual_ms:7.2f}ms | Exit={rec_a.return_code}")

    print("\n--- Program B (Sleeping Workload) ---")
    for i in range(3):
        rec_b = _run_once(temp_b_exe)
        wall_ms = rec_b.elapsed_ns / 1e6
        user_ms = rec_b.user_cpu_ns / 1e6 if rec_b.user_cpu_ns is not None else -1
        kern_ms = rec_b.kernel_cpu_ns / 1e6 if rec_b.kernel_cpu_ns is not None else -1
        total_cpu = user_ms + kern_ms
        residual_ms = wall_ms - total_cpu
        print(f"Run {i+1}: Wall={wall_ms:7.2f}ms | UserCPU={user_ms:7.2f}ms | KernCPU={kern_ms:7.2f}ms | TotalCPU={total_cpu:7.2f}ms | Residual={residual_ms:7.2f}ms | Exit={rec_b.return_code}")

finally:
    for p in [temp_a_c, temp_a_exe, temp_b_c, temp_b_exe]:
        if os.path.exists(p):
            os.remove(p)
