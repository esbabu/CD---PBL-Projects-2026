"""
reconcile_backups.py
Performs SHA-256 hashing and structural comparison of:
- TOACD_Phase1_PreEdit_WorkingTree_Backup.zip
- TOACD_Master_Submission_Backup.zip
- Current inner repo working directory
"""
import os
import sys
import zipfile
import hashlib
import json

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# SCRIPT_DIR is <inner_repo>/Codes/Python Scripts/scratch
INNER_REPO = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
OUTER_DIR = os.path.abspath(os.path.join(INNER_REPO, ".."))

ZIP1 = os.path.join(OUTER_DIR, "TOACD_Phase1_PreEdit_WorkingTree_Backup.zip")
ZIP2 = os.path.join(OUTER_DIR, "TOACD_Master_Submission_Backup.zip")

def sha256_file(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def inspect_zip(zip_path):
    info = {}
    with zipfile.ZipFile(zip_path, 'r') as zf:
        for zinfo in zf.infolist():
            if zinfo.is_dir():
                continue
            data = zf.read(zinfo.filename)
            h = hashlib.sha256(data).hexdigest()
            # Normalize path
            norm_name = zinfo.filename.replace('\\', '/')
            info[norm_name] = {
                "size": zinfo.file_size,
                "sha256": h,
            }
    return info

def main():
    print(f"Reconciling backups and current working tree...")
    print(f"Inner repo: {INNER_REPO}")
    print(f"ZIP 1: {ZIP1} (Exists: {os.path.isfile(ZIP1)})")
    print(f"ZIP 2: {ZIP2} (Exists: {os.path.isfile(ZIP2)})")
    
    zip1_sha = sha256_file(ZIP1) if os.path.isfile(ZIP1) else None
    zip2_sha = sha256_file(ZIP2) if os.path.isfile(ZIP2) else None
    print(f"ZIP 1 SHA-256: {zip1_sha}")
    print(f"ZIP 2 SHA-256: {zip2_sha}")
    
    entries1 = inspect_zip(ZIP1) if os.path.isfile(ZIP1) else {}
    entries2 = inspect_zip(ZIP2) if os.path.isfile(ZIP2) else {}
    
    print(f"ZIP 1 entry count (files): {len(entries1)}")
    print(f"ZIP 2 entry count (files): {len(entries2)}")
    
    # Compare entries between ZIP1 and ZIP2
    only_in_1 = sorted(set(entries1.keys()) - set(entries2.keys()))
    only_in_2 = sorted(set(entries2.keys()) - set(entries1.keys()))
    common = sorted(set(entries1.keys()) & set(entries2.keys()))
    
    identical = []
    modified = []
    for f in common:
        if entries1[f]["sha256"] == entries2[f]["sha256"]:
            identical.append(f)
        else:
            modified.append({
                "file": f,
                "zip1_sha": entries1[f]["sha256"],
                "zip2_sha": entries2[f]["sha256"],
                "zip1_size": entries1[f]["size"],
                "zip2_size": entries2[f]["size"],
            })
            
    print(f"Common files: {len(common)}")
    print(f"Identical files: {len(identical)}")
    print(f"Modified files between backups: {len(modified)}")
    print(f"Files only in Backup 1 (Pre-Edit): {len(only_in_1)}")
    print(f"Files only in Backup 2 (Master): {len(only_in_2)}")
    
    out_data = {
        "zip1_path": ZIP1,
        "zip1_sha256": zip1_sha,
        "zip1_total_files": len(entries1),
        "zip2_path": ZIP2,
        "zip2_sha256": zip2_sha,
        "zip2_total_files": len(entries2),
        "identical_count": len(identical),
        "modified_count": len(modified),
        "modified_files": modified,
        "only_in_pre_edit_count": len(only_in_1),
        "only_in_pre_edit_sample": only_in_1[:20],
        "only_in_master_count": len(only_in_2),
        "only_in_master_sample": only_in_2[:20],
    }
    
    out_file = os.path.join(SCRIPT_DIR, "backup_reconciliation_results.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(out_data, f, indent=2)
    print(f"Wrote reconciliation summary to: {out_file}")

if __name__ == "__main__":
    main()
