"""
deep_reconciliation_audit.py
Provides a comprehensive file-by-file reconciliation between:
1. Git HEAD (commit 1ab933e)
2. Current working tree
3. TOACD_Phase1_PreEdit_WorkingTree_Backup.zip
4. TOACD_Master_Submission_Backup.zip
"""
import os
import sys
import zipfile
import hashlib
import subprocess
import json

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INNER_REPO = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
OUTER_DIR = os.path.abspath(os.path.join(INNER_REPO, ".."))

ZIP1 = os.path.join(OUTER_DIR, "TOACD_Phase1_PreEdit_WorkingTree_Backup.zip")
ZIP2 = os.path.join(OUTER_DIR, "TOACD_Master_Submission_Backup.zip")

def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()

def sha256_file(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def get_git_file_content(commit, rel_path):
    try:
        norm_p = rel_path.replace("\\", "/")
        out = subprocess.check_output(["git", "show", f"{commit}:{norm_p}"], cwd=INNER_REPO)
        return out
    except Exception:
        return None

def main():
    print("Executing Deep Git and Backup Reconciliation Audit...")
    
    # 1. Get git status porcelain
    status_out = subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=INNER_REPO, text=True)
    tracked_modified = []
    untracked = []
    for line in status_out.splitlines():
        if not line:
            continue
        code = line[:2]
        path = line[3:].strip().strip('"')
        if code.strip() == "M":
            tracked_modified.append(path)
        elif code.strip() == "??":
            untracked.append(path)

    print(f"Tracked modified files relative to HEAD: {len(tracked_modified)}")
    print(f"Untracked files: {len(untracked)}")

    # 2. Inspect ZIP1 and ZIP2
    zf1 = zipfile.ZipFile(ZIP1, 'r')
    zf2 = zipfile.ZipFile(ZIP2, 'r')

    zip1_names = {zi.filename.replace('\\', '/'): zi for zi in zf1.infolist() if not zi.is_dir()}
    zip2_names = {zi.filename.replace('\\', '/'): zi for zi in zf2.infolist() if not zi.is_dir()}

    print(f"ZIP 1 total file entries: {len(zip1_names)}")
    print(f"ZIP 2 total file entries: {len(zip2_names)}")

    reconciliation = []

    for f in tracked_modified:
        norm_f = f.replace('\\', '/')
        # Working tree hash
        disk_p = os.path.join(INNER_REPO, f)
        wt_hash = sha256_file(disk_p) if os.path.isfile(disk_p) else None
        
        # Git HEAD hash
        head_bytes = get_git_file_content("1ab933e", f)
        head_hash = sha256_bytes(head_bytes) if head_bytes is not None else None
        
        # Zip 1 hash
        z1_hash = sha256_bytes(zf1.read(zip1_names[norm_f])) if norm_f in zip1_names else None
        # Zip 2 hash
        z2_hash = sha256_bytes(zf2.read(zip2_names[norm_f])) if norm_f in zip2_names else None

        reconciliation.append({
            "file": norm_f,
            "in_git_head": head_hash is not None,
            "head_matches_wt": head_hash == wt_hash,
            "in_zip1_pre_edit": z1_hash is not None,
            "in_zip2_master": z2_hash is not None,
            "zip1_matches_zip2": z1_hash == z2_hash,
            "zip1_matches_wt": z1_hash == wt_hash,
            "zip2_matches_wt": z2_hash == wt_hash,
            "wt_hash": wt_hash,
            "head_hash": head_hash,
            "zip1_hash": z1_hash,
            "zip2_hash": z2_hash,
        })

    # Summary analysis
    in_zip2_count = sum(1 for r in reconciliation if r["in_zip2_master"])
    zip1_eq_zip2_count = sum(1 for r in reconciliation if r["zip1_matches_zip2"])
    diff_zip1_zip2 = [r["file"] for r in reconciliation if not r["zip1_matches_zip2"]]

    print(f"\nOf the {len(tracked_modified)} tracked modified files:")
    print(f"  Present in Master Backup (ZIP 2): {in_zip2_count}/{len(tracked_modified)}")
    print(f"  Identical between Pre-Edit and Master: {zip1_eq_zip2_count}/{len(tracked_modified)}")
    print(f"  Differing between Pre-Edit and Master: {diff_zip1_zip2}")

    out_file = os.path.join(SCRIPT_DIR, "deep_reconciliation_audit.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "total_tracked_modified": len(tracked_modified),
            "total_untracked": len(untracked),
            "differing_between_pre_edit_and_master": diff_zip1_zip2,
            "reconciliation": reconciliation,
        }, f, indent=2)
    print(f"Saved full audit to: {out_file}")

if __name__ == "__main__":
    main()
