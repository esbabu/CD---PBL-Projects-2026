"""
heteroscedastic_deep_eval.py
Rigorous investigation of Bootstrap CI coverage under unequal variances (heteroscedasticity).
Evaluates 1000 Monte Carlo trials with n=15 and n=30 sample sizes.
"""
import numpy as np
import scipy.stats as stats
import json
import os

np.random.seed(42)

def sample_median(x):
    return float(np.median(x))

def bootstrap_percentile_ci(data, n_resamples=500, alpha=0.05):
    n = len(data)
    idx = np.random.randint(0, n, size=(n_resamples, n))
    boot_stats = np.median(data[idx], axis=1)
    lo = float(np.percentile(boot_stats, 100 * (alpha / 2.0)))
    hi = float(np.percentile(boot_stats, 100 * (1.0 - alpha / 2.0)))
    return lo, hi

def main():
    print("Evaluating Bootstrap Coverage under Heteroscedasticity (1000 trials)...")
    true_base = 100.0
    true_cand = 80.0
    true_speedup = true_base / true_cand # 1.25

    n_trials = 1000
    results = {}

    for sample_size in [15, 30]:
        hits = 0
        widths = []
        for _ in range(n_trials):
            # Heteroscedastic noise: base sigma=2.0, cand sigma=8.0 (4x variance ratio)
            base_s = np.random.normal(true_base, 2.0, sample_size)
            cand_s = np.random.normal(true_cand, 8.0, sample_size)
            ratios = base_s / cand_s
            lo, hi = bootstrap_percentile_ci(ratios, n_resamples=500, alpha=0.05)
            if lo <= true_speedup <= hi:
                hits += 1
            widths.append(hi - lo)

        cov = hits / n_trials
        # Binomial standard error and 95% Wilson score interval
        se = np.sqrt(cov * (1.0 - cov) / n_trials)
        ci_cov_lo = cov - 1.96 * se
        ci_cov_hi = cov + 1.96 * se

        results[f"n_samples_{sample_size}"] = {
            "n_trials": n_trials,
            "sample_size": sample_size,
            "nominal_coverage": 0.95,
            "empirical_coverage": round(cov, 4),
            "std_error": round(se, 4),
            "coverage_95_ci": [round(ci_cov_lo, 4), round(ci_cov_hi, 4)],
            "mean_ci_width": round(float(np.mean(widths)), 4),
        }
        print(f"Sample size n={sample_size}: Coverage={cov*100:.2f}% (SE={se*100:.2f}%, 95% CI=[{ci_cov_lo*100:.2f}%, {ci_cov_hi*100:.2f}%], mean width={np.mean(widths):.4f})")

    out_file = os.path.join(os.path.dirname(__file__), "heteroscedastic_eval_results.json")
    with open(out_file, "w") as f:
        json.dump(results, f, indent=2)

if __name__ == "__main__":
    main()
