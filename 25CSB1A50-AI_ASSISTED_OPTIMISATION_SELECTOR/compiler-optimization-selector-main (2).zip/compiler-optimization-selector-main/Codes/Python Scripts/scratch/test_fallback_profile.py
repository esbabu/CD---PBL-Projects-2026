import sys, os
sys.path.insert(0, r'compiler-optimization-selector-main\Codes\Python Scripts')
from moo.security.gate import OptimizationSecurityGate
import tempfile

code = """
#include <stdio.h>
#include <assert.h>
int main() {
    volatile int x = 5;
    if (x != 5) {
        assert(0);
    }
    return 0;
}
"""
with tempfile.NamedTemporaryFile('w', suffix='.c', delete=False) as f:
    f.write(code)
    tmp_path = f.name

try:
    from moo.toolchain import CLANG_PATH, OPT_PATH
    gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)
    # Test under LINUX_HARDENED profile
    res = gate.run_gate(source_path=tmp_path, selected_strategy='-O3', security_profile='LINUX_HARDENED')
    print('LINUX_HARDENED decision:', res.decision)
    print('effective_strategy:', res.effective_strategy)
    print('fallback_occurred:', res.fallback_occurred)
    print('candidate_verdict:', res.candidate_security.verdict if res.candidate_security else None)
    print('notes:', res.notes)
finally:
    if os.path.exists(tmp_path):
        os.remove(tmp_path)
