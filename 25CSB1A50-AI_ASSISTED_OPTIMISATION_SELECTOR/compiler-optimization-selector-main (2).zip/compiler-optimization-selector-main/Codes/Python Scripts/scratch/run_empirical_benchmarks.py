"""
Codes/Python Scripts/scratch/run_empirical_benchmarks.py
Empirical Benchmarking of Catalog C Programs across Normal (-O0, -O3), DQN, and LinUCB.
Measures Wall-Clock Time, User CPU Time, Subprocess Overhead, Variance (CV), and Speedups.
"""

from __future__ import annotations

import json
import os
import sys

# Ensure Python Scripts is in sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
sys.path.insert(0, PROJECT_ROOT)

from moo.pipeline import evaluate_program
from moo.multiagent.orchestrator import MultiAgentOrchestrator


CATALOG_PROGRAMS = [
    "nested_loops.c",
    "gemm.c",
    "TC1_loop_heavy.c",
    "matrix_mult.c",
    "quick_sort.c",
    "binary_search.c",
]


def run_benchmarks():
    test_cases_dir = os.path.join(os.path.dirname(PROJECT_ROOT), "test_cases")
    all_results = {}

    print(f"Starting Empirical Benchmark Suite across {len(CATALOG_PROGRAMS)} catalog programs...")

    for prog_name in CATALOG_PROGRAMS:
        prog_path = os.path.join(test_cases_dir, prog_name)
        if not os.path.isfile(prog_path):
            print(f"Warning: File {prog_path} not found. Skipping.")
            continue

        print(f"\n=================================================================")
        print(f"Benchmarking Catalog Program: {prog_name}")
        print(f"=================================================================")

        # 1. Determine strategies for DQN and LinUCB
        orch = MultiAgentOrchestrator()
        dqn_rec, _ = orch.run(
            source_path=prog_path,
            model_family="dqn",
            run_benchmarks=False,
            run_security=True,
            run_regression=False,
        )
        dqn_strat = dqn_rec.effective_strategy or dqn_rec.selected_strategy or "-O2"

        linucb_rec, _ = orch.run(
            source_path=prog_path,
            model_family="linucb",
            run_benchmarks=False,
            run_security=True,
            run_regression=False,
        )
        linucb_strat = linucb_rec.effective_strategy or linucb_rec.selected_strategy or "-O2"

        actions = list(dict.fromkeys(["-O3", dqn_strat, linucb_strat]))
        print(f"Strategies to evaluate: Baseline (-O0), plus actions: {actions}")

        # 2. Run full MOO interleaved evaluation with auto-calibration
        eval_res = evaluate_program(
            source_path=prog_path,
            actions=actions,
            warmup_runs=3,
            measure_runs=10,
            auto_calibrate=True,
        )

        if eval_res.pipeline_error:
            print(f"Evaluation error for {prog_name}: {eval_res.pipeline_error}")
            continue

        prog_data = {
            "program": prog_name,
            "baseline_o0": None,
            "candidates": {},
            "model_selections": {
                "dqn": dqn_strat,
                "linucb": linucb_strat,
            },
        }

        # 3. Process Baseline (-O0)
        base = eval_res.baseline
        if base and base.measurement:
            m = base.measurement
            t = m.get("timing") or {}
            u = m.get("user_cpu_timing") or {}
            k = m.get("kernel_cpu_timing") or {}
            tot = m.get("total_cpu_timing") or {}
            cs = m.get("code_size") or {}

            wall_med_ms = (t.get("median_s", 0.0) * 1000)
            wall_mean_ms = (t.get("mean_s", 0.0) * 1000)
            wall_cv = t.get("cv", 0.0)

            user_med_ms = (u.get("median_s", 0.0) * 1000)
            user_cv = u.get("cv", 0.0)
            kernel_med_ms = (k.get("median_s", 0.0) * 1000)
            total_cpu_med_ms = (tot.get("median_s", 0.0) * 1000) if tot else (user_med_ms + kernel_med_ms)

            # Strict definition: External / Non-Child-CPU Elapsed-Time Residual
            # T_residual = T_wall - (T_user + T_kernel)
            residual_ms = max(0.0, wall_med_ms - (user_med_ms + kernel_med_ms))
            residual_pct = (residual_ms / wall_med_ms * 100.0) if wall_med_ms > 0 else 0.0

            cpu_status = m.get("cpu_status", "UNKNOWN")
            is_sub_resolution = (wall_med_ms < 20.0 or cpu_status == "BELOW_RESOLUTION")

            prog_data["baseline_o0"] = {
                "flags": "-O0",
                "wall_clock": {
                    "median_ms": round(wall_med_ms, 3),
                    "mean_ms": round(wall_mean_ms, 3),
                    "cv": round(wall_cv, 4),
                    "reliable": t.get("timing_is_reliable", False),
                },
                "user_cpu": {
                    "median_ms": round(user_med_ms, 3),
                    "cv": round(user_cv, 4),
                    "status": cpu_status,
                },
                "kernel_cpu": {
                    "median_ms": round(kernel_med_ms, 3),
                },
                "total_cpu": {
                    "median_ms": round(total_cpu_med_ms, 3),
                },
                "residual_elapsed_time": {
                    "residual_ms": round(residual_ms, 3),
                    "residual_pct": round(residual_pct, 1),
                    "definition": "T_wall - (T_user + T_kernel)",
                },
                "code_size": {
                    "bytes": cs.get("primary_value"),
                    "metric": cs.get("primary_metric"),
                },
                "reliability_classification": (
                    "INCONCLUSIVE — sub-resolution duration dominated by OS process overhead (<20ms)"
                    if is_sub_resolution else "RELIABLE"
                ),
            }
            print(f"  baseline (-O0)       | Wall: {wall_med_ms:7.3f}ms (CV={wall_cv*100:4.1f}%) | UserCPU: {user_med_ms:6.3f}ms | KernCPU: {kernel_med_ms:6.3f}ms | Residual: {residual_ms:6.3f}ms ({residual_pct:4.1f}%) | Size: {cs.get('primary_value')} B")

        # 4. Process Candidates
        base_wall_s = (base.measurement.get("timing") or {}).get("median_s") if base and base.measurement else None
        base_user_s = (base.measurement.get("user_cpu_timing") or {}).get("median_s") if base and base.measurement else None
        base_total_s = (base.measurement.get("total_cpu_timing") or {}).get("median_s") if base and base.measurement else None

        o3_cand = next((c for c in eval_res.candidates if c.strategy_name == "-O3"), None)
        o3_wall_s = (o3_cand.measurement.get("timing") or {}).get("median_s") if o3_cand and o3_cand.measurement else None
        o3_user_s = (o3_cand.measurement.get("user_cpu_timing") or {}).get("median_s") if o3_cand and o3_cand.measurement else None

        for cand in eval_res.candidates:
            s_name = cand.strategy_name
            m = cand.measurement or {}
            t = m.get("timing") or {}
            u = m.get("user_cpu_timing") or {}
            k = m.get("kernel_cpu_timing") or {}
            tot = m.get("total_cpu_timing") or {}
            cs = m.get("code_size") or {}

            wall_med_ms = (t.get("median_s", 0.0) * 1000)
            wall_mean_ms = (t.get("mean_s", 0.0) * 1000)
            wall_cv = t.get("cv", 0.0)

            user_med_ms = (u.get("median_s", 0.0) * 1000)
            user_cv = u.get("cv", 0.0)
            kernel_med_ms = (k.get("median_s", 0.0) * 1000)
            total_cpu_med_ms = (tot.get("median_s", 0.0) * 1000) if tot else (user_med_ms + kernel_med_ms)

            residual_ms = max(0.0, wall_med_ms - (user_med_ms + kernel_med_ms))
            residual_pct = (residual_ms / wall_med_ms * 100.0) if wall_med_ms > 0 else 0.0

            cand_wall_s = t.get("median_s")
            cand_user_s = u.get("median_s")
            cand_cpu_status = m.get("cpu_status", "UNKNOWN")

            # Speedups with identical domain checks
            sp_o0_wall = (base_wall_s / cand_wall_s) if (base_wall_s and cand_wall_s and cand_wall_s > 0) else None
            
            if base_user_s and cand_user_s and cand_user_s > 0:
                sp_o0_cpu = round(base_user_s / cand_user_s, 3)
            elif cand_cpu_status == "BELOW_RESOLUTION" or (cand_user_s is not None and cand_user_s == 0):
                sp_o0_cpu = "INCONCLUSIVE (below timer resolution)"
            else:
                sp_o0_cpu = None

            sp_o3_wall = (o3_wall_s / cand_wall_s) if (o3_wall_s and cand_wall_s and cand_wall_s > 0) else None

            if o3_user_s and cand_user_s and cand_user_s > 0:
                sp_o3_cpu = round(o3_user_s / cand_user_s, 3)
            elif cand_cpu_status == "BELOW_RESOLUTION" or (cand_user_s is not None and cand_user_s == 0):
                sp_o3_cpu = "INCONCLUSIVE (below timer resolution)"
            else:
                sp_o3_cpu = None

            is_sub_resolution = (wall_med_ms < 20.0 or cand_cpu_status == "BELOW_RESOLUTION")

            prog_data["candidates"][s_name] = {
                "wall_clock": {
                    "median_ms": round(wall_med_ms, 3),
                    "mean_ms": round(wall_mean_ms, 3),
                    "cv": round(wall_cv, 4),
                    "reliable": t.get("timing_is_reliable", False),
                },
                "user_cpu": {
                    "median_ms": round(user_med_ms, 3),
                    "cv": round(user_cv, 4),
                    "status": cand_cpu_status,
                },
                "kernel_cpu": {
                    "median_ms": round(kernel_med_ms, 3),
                },
                "total_cpu": {
                    "median_ms": round(total_cpu_med_ms, 3),
                },
                "residual_elapsed_time": {
                    "residual_ms": round(residual_ms, 3),
                    "residual_pct": round(residual_pct, 1),
                    "definition": "T_wall - (T_user + T_kernel)",
                },
                "code_size": {
                    "bytes": cs.get("primary_value"),
                    "metric": cs.get("primary_metric"),
                },
                "speedup_vs_o0": {
                    "wall_clock": round(sp_o0_wall, 3) if sp_o0_wall else None,
                    "user_cpu": sp_o0_cpu,
                },
                "speedup_vs_o3": {
                    "wall_clock": round(sp_o3_wall, 3) if sp_o3_wall else None,
                    "user_cpu": sp_o3_cpu,
                },
                "reliability_classification": (
                    "INCONCLUSIVE — sub-resolution duration dominated by OS process overhead (<20ms)"
                    if is_sub_resolution else "RELIABLE"
                ),
            }
            print(f"  {s_name:20s} | Wall: {wall_med_ms:7.3f}ms (CV={wall_cv*100:4.1f}%) | UserCPU: {user_med_ms:6.3f}ms | KernCPU: {kernel_med_ms:6.3f}ms | Residual: {residual_ms:6.3f}ms ({residual_pct:4.1f}%) | Size: {cs.get('primary_value')} B")

        all_results[prog_name] = prog_data

    out_file = "Codes/Python Scripts/scratch/empirical_benchmark_results.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2)

    print(f"\nAll empirical benchmarks completed! Saved to {out_file}.")


if __name__ == "__main__":
    run_benchmarks()
