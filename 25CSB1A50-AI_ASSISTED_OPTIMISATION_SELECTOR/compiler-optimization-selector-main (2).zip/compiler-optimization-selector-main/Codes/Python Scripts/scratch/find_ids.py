import re

with open(r'compiler-optimization-selector-main\Codes\Python Scripts\web\static\index.html', encoding='utf-8') as f:
    html = f.read()

ids = re.findall(r'id=["\']([^"\']+)["\']', html)
print(f"Total IDs: {len(ids)}")
keywords = ['btn', 'run', 'sample', 'theme', 'modal', 'xai', 'profile', 'model', 'mode', 'accordion', 'toast']
matched = [i for i in ids if any(k in i.lower() for k in keywords)]
for m in matched:
    print(m)
