import os
import subprocess
import time

CLANG = r"C:\Program Files\LLVM\bin\clang.exe"
OPT = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

# Original TC1 (512 iterations)
TC1_ORIG = """
void sink(int x);
int main(void) {
    int arr[512];
    int sum = 0;
    for (int i = 0; i < 512; i++) {
        arr[i] = (i * 31) ^ (i >> 3);
    }
    for (int i = 0; i < 512; i++) {
        sum += arr[i] * (i % 7 + 1);
    }
    sink(sum);
    return 0;
}
__attribute__((noinline)) void sink(int x) { (void)x; }
"""

# Scaled TC1 (50,000 outer loop iterations so compute time is ~25ms)
TC1_SCALED = """
#include <stdio.h>
void sink(int x);
int main(void) {
    int arr[512];
    int sum = 0;
    for (int iter = 0; iter < 20000; iter++) {
        for (int i = 0; i < 512; i++) {
            arr[i] = (i * 31) ^ (i >> 3);
        }
        for (int i = 0; i < 512; i++) {
            sum += arr[i] * (i % 7 + 1);
        }
    }
    sink(sum);
    printf("sum = %d\\n", sum);
    return 0;
}
__attribute__((noinline)) void sink(int x) { (void)x; }
"""

workdir = r"scratch\tc1_bench"
os.makedirs(workdir, exist_ok=True)

for name, code in [("TC1_ORIG (512 iters)", TC1_ORIG), ("TC1_SCALED (20,000 iters)", TC1_SCALED)]:
    print(f"\n=== TESTING {name} ===")
    src = os.path.join(workdir, "prog.c")
    with open(src, "w") as f:
        f.write(code)

    # 1. Compile -O0
    exe_o0 = os.path.join(workdir, "prog_o0.exe")
    subprocess.run([CLANG, "-O0", src, "-o", exe_o0], check=True)

    # 2. Compile -O3
    exe_o3 = os.path.join(workdir, "prog_o3.exe")
    subprocess.run([CLANG, "-O3", src, "-o", exe_o3], check=True)

    # 3. Compile TOACD (mem2reg,simplifycfg -> clang -O2)
    ir_o0 = os.path.join(workdir, "prog_o0.ll")
    subprocess.run([CLANG, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src, "-o", ir_o0], check=True)
    ir_opt = os.path.join(workdir, "prog_opt.ll")
    subprocess.run([OPT, "-passes=mem2reg,simplifycfg", "-S", ir_o0, "-o", ir_opt], check=True)
    exe_toacd = os.path.join(workdir, "prog_toacd.exe")
    subprocess.run([CLANG, "-O2", ir_opt, "-o", exe_toacd], check=True)

    # Warmup
    for exe in [exe_o0, exe_o3, exe_toacd]:
        subprocess.run([exe], capture_output=True)

    # Measure 5 runs each
    def measure(exe):
        times = []
        for _ in range(5):
            t0 = time.perf_counter_ns()
            subprocess.run([exe], capture_output=True)
            times.append((time.perf_counter_ns() - t0) / 1e6)
        times.sort()
        return times[2], times

    med_o0, samples_o0 = measure(exe_o0)
    med_o3, samples_o3 = measure(exe_o3)
    med_toacd, samples_toacd = measure(exe_toacd)

    print(f"  clang -O0 : median={med_o0:.2f}ms, samples={[round(s,2) for s in samples_o0]}")
    print(f"  clang -O3 : median={med_o3:.2f}ms, samples={[round(s,2) for s in samples_o3]}")
    print(f"  TOACD -O2 : median={med_toacd:.2f}ms, samples={[round(s,2) for s in samples_toacd]}")
    print(f"  Speedup TOACD vs -O0: {med_o0/med_toacd:.2f}x")
    print(f"  Speedup -O3 vs -O0  : {med_o0/med_o3:.2f}x")
