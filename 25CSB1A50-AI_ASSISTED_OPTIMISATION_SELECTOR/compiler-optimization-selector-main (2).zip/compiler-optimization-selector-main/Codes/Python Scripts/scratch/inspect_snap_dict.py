import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from moo.multiagent.orchestrator import MultiAgentOrchestrator

orch = MultiAgentOrchestrator()
rec, _ = orch.run(source_path=r"scratch\bench_run\gemm.c", run_benchmarks=True, measure_runs=3, warmup_runs=2)
b_snap = rec.baseline_measurement
print("b_snap.measurement_dict keys:", list(b_snap.measurement_dict.keys()) if b_snap.measurement_dict else None)
if b_snap.measurement_dict:
    print("timing sub-dict:", b_snap.measurement_dict.get("timing"))
    print("raw_samples_ns:", b_snap.measurement_dict.get("raw_samples_ns"))
