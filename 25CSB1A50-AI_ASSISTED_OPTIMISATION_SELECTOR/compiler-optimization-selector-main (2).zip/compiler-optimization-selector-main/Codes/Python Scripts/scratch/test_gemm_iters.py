import os
import subprocess
import time

CLANG = r"C:\Program Files\LLVM\bin\clang.exe"
OPT = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

def make_gemm(iters):
    return f"""// Polybench GEMM benchmark
#include <stdio.h>

#define NI 64
#define NJ 64
#define NK 64

void kernel_gemm(int ni, int nj, int nk,
                 double alpha, double beta,
                 double C[NI][NJ],
                 double A[NI][NK],
                 double B[NK][NJ]) {{
  for (int i = 0; i < ni; i++) {{
    for (int j = 0; j < nj; j++) {{
      C[i][j] *= beta;
    }}
    for (int k = 0; k < nk; k++) {{
      for (int j = 0; j < nj; j++) {{
        C[i][j] += alpha * A[i][k] * B[k][j];
      }}
    }}
  }}
}}

int main(void) {{
  static double C[NI][NJ];
  static double A[NI][NK];
  static double B[NK][NJ];

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NK; j++)
      A[i][j] = (double)(i * j % 1024) / 1024.0;

  for (int i = 0; i < NK; i++)
    for (int j = 0; j < NJ; j++)
      B[i][j] = (double)(i * j % 512) / 512.0;

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NJ; j++)
      C[i][j] = 0.5;

  for (int iter = 0; iter < {iters}; iter++) {{
    kernel_gemm(NI, NJ, NK, 1.5, 1.2, C, A, B);
  }}
  printf("C[0][0] = %f\\n", C[0][0]);
  return 0;
}}
"""

workdir = r"scratch\gemm_bench"
os.makedirs(workdir, exist_ok=True)

for iters in [1, 20, 50, 100]:
    print(f"\n==========================================")
    print(f"=== TESTING GEMM WITH {iters} ITERATION(S) ===")
    print(f"==========================================")
    src = os.path.join(workdir, f"gemm_{iters}.c")
    with open(src, "w") as f:
        f.write(make_gemm(iters))

    # Compile O0
    exe_o0 = os.path.join(workdir, f"gemm_{iters}_O0.exe")
    subprocess.run([CLANG, "-O0", src, "-o", exe_o0], check=True)

    # Compile O3
    exe_o3 = os.path.join(workdir, f"gemm_{iters}_O3.exe")
    subprocess.run([CLANG, "-O3", src, "-o", exe_o3], check=True)

    # Compile TOACD (mem2reg,instcombine,simplifycfg,gvn,loop-unroll -> clang -O2)
    ir_o0 = os.path.join(workdir, f"gemm_{iters}_O0.ll")
    subprocess.run([CLANG, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src, "-o", ir_o0], check=True)
    ir_opt = os.path.join(workdir, f"gemm_{iters}_opt.ll")
    subprocess.run([OPT, "-passes=mem2reg,instcombine,simplifycfg,gvn,loop-unroll", "-S", ir_o0, "-o", ir_opt], check=True)
    exe_toacd = os.path.join(workdir, f"gemm_{iters}_toacd.exe")
    subprocess.run([CLANG, "-O2", ir_opt, "-o", exe_toacd], check=True)

    # 2 Warmup runs each
    for _ in range(2):
        for exe in [exe_o0, exe_o3, exe_toacd]:
            subprocess.run([exe], capture_output=True)

    # Interleaved 5 runs
    samples_o0, samples_o3, samples_toacd = [], [], []
    for _ in range(5):
        t0 = time.perf_counter_ns(); subprocess.run([exe_o0], capture_output=True); samples_o0.append((time.perf_counter_ns() - t0)/1e6)
        t0 = time.perf_counter_ns(); subprocess.run([exe_o3], capture_output=True); samples_o3.append((time.perf_counter_ns() - t0)/1e6)
        t0 = time.perf_counter_ns(); subprocess.run([exe_toacd], capture_output=True); samples_toacd.append((time.perf_counter_ns() - t0)/1e6)

    import statistics
    print(f"  clang -O0 : median={statistics.median(samples_o0):.2f}ms, mean={statistics.mean(samples_o0):.2f}ms, samples={[round(s,2) for s in samples_o0]}")
    print(f"  clang -O3 : median={statistics.median(samples_o3):.2f}ms, mean={statistics.mean(samples_o3):.2f}ms, samples={[round(s,2) for s in samples_o3]}")
    print(f"  TOACD -O2 : median={statistics.median(samples_toacd):.2f}ms, mean={statistics.mean(samples_toacd):.2f}ms, samples={[round(s,2) for s in samples_toacd]}")
    med_o0 = statistics.median(samples_o0)
    med_o3 = statistics.median(samples_o3)
    med_toacd = statistics.median(samples_toacd)
    print(f"  Speedup TOACD vs -O0: {med_o0/med_toacd:.2f}x ({'FASTER' if med_o0>med_toacd else 'SLOWER'})")
    print(f"  Speedup -O3 vs -O0  : {med_o0/med_o3:.2f}x ({'FASTER' if med_o0>med_o3 else 'SLOWER'})")
