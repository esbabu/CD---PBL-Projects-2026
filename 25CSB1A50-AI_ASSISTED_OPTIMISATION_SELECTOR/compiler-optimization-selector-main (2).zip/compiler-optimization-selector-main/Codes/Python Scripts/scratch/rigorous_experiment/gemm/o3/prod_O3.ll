; ModuleID = 'C:\Users\rithv\Desktop\New folder\TOACD\compiler-optimization-selector-main\compiler-optimization-selector-main\Codes\Python Scripts\scratch\rigorous_experiment\gemm.c'
source_filename = "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts\\scratch\\rigorous_experiment\\gemm.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.51.36260"

$printf = comdat any

$__local_stdio_printf_options = comdat any

$"??_C@_0O@GMPLCDGC@C?$FL0?$FN?$FL0?$FN?5?$DN?5?$CFf?6?$AA@" = comdat any

@main.C = internal unnamed_addr global [64 x [64 x double]] zeroinitializer, align 16
@main.A = internal unnamed_addr global [64 x [64 x double]] zeroinitializer, align 16
@main.B = internal unnamed_addr global [64 x [64 x double]] zeroinitializer, align 16
@"??_C@_0O@GMPLCDGC@C?$FL0?$FN?$FL0?$FN?5?$DN?5?$CFf?6?$AA@" = linkonce_odr dso_local unnamed_addr constant [14 x i8] c"C[0][0] = %f\0A\00", comdat, align 8
@__local_stdio_printf_options._OptionsStorage = internal global i64 0, align 8

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite) uwtable
define dso_local void @kernel_gemm(i32 noundef %0, i32 noundef %1, i32 noundef %2, double noundef %3, double noundef %4, ptr nofree noundef captures(none) %5, ptr nofree noundef readonly captures(none) %6, ptr nofree noundef readonly captures(none) %7) local_unnamed_addr #0 {
  %9 = icmp sgt i32 %0, 0
  br i1 %9, label %10, label %163

10:                                               ; preds = %8
  %11 = icmp sgt i32 %2, 0
  %12 = icmp sgt i32 %1, 0
  br i1 %11, label %13, label %138

13:                                               ; preds = %10
  br i1 %12, label %14, label %163

14:                                               ; preds = %13
  %15 = zext nneg i32 %0 to i64
  %16 = zext nneg i32 %1 to i64
  %17 = zext nneg i32 %2 to i64
  %18 = shl nuw nsw i64 %16, 3
  %19 = shl nuw nsw i64 %17, 3
  %20 = shl nuw nsw i64 %17, 9
  %21 = getelementptr i8, ptr %7, i64 %20
  %22 = getelementptr i8, ptr %21, i64 %18
  %23 = getelementptr i8, ptr %22, i64 -512
  %24 = getelementptr i8, ptr %5, i64 %18
  %25 = getelementptr i8, ptr %6, i64 %19
  %26 = icmp ult i32 %1, 4
  %27 = and i64 %16, 2147483644
  %28 = insertelement <2 x double> poison, double %4, i64 0
  %29 = shufflevector <2 x double> %28, <2 x double> poison, <2 x i32> zeroinitializer
  %30 = icmp eq i64 %27, %16
  %31 = icmp ult i32 %1, 4
  %32 = and i64 %16, 2147483644
  %33 = icmp eq i64 %32, %16
  %34 = and i64 %16, 1
  %35 = icmp eq i64 %34, 0
  %36 = add nsw i64 %16, -1
  br label %37

37:                                               ; preds = %14, %135
  %38 = phi i64 [ 0, %14 ], [ %136, %135 ]
  %39 = shl nuw nsw i64 %38, 9
  %40 = getelementptr nuw i8, ptr %5, i64 %39
  %41 = getelementptr i8, ptr %24, i64 %39
  %42 = getelementptr i8, ptr %6, i64 %39
  %43 = getelementptr i8, ptr %25, i64 %39
  %44 = getelementptr inbounds nuw [512 x i8], ptr %5, i64 %38
  br i1 %26, label %56, label %45

45:                                               ; preds = %37, %45
  %46 = phi i64 [ %53, %45 ], [ 0, %37 ]
  %47 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 16
  %49 = load <2 x double>, ptr %47, align 8
  %50 = load <2 x double>, ptr %48, align 8
  %51 = fmul <2 x double> %29, %49
  %52 = fmul <2 x double> %29, %50
  store <2 x double> %51, ptr %47, align 8
  store <2 x double> %52, ptr %48, align 8
  %53 = add nuw i64 %46, 4
  %54 = icmp eq i64 %53, %27
  br i1 %54, label %55, label %45, !llvm.loop !7

55:                                               ; preds = %45
  br i1 %30, label %123, label %56

56:                                               ; preds = %37, %55
  %57 = phi i64 [ 0, %37 ], [ %27, %55 ]
  br label %77

58:                                               ; preds = %120, %58
  %59 = phi i64 [ %75, %58 ], [ %121, %120 ]
  %60 = load double, ptr %86, align 8
  %61 = fmul double %3, %60
  %62 = getelementptr inbounds nuw [8 x i8], ptr %87, i64 %59
  %63 = load double, ptr %62, align 8
  %64 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %59
  %65 = load double, ptr %64, align 8
  %66 = tail call double @llvm.fmuladd.f64(double %61, double %63, double %65)
  store double %66, ptr %64, align 8
  %67 = add nuw nsw i64 %59, 1
  %68 = load double, ptr %86, align 8
  %69 = fmul double %3, %68
  %70 = getelementptr inbounds nuw [8 x i8], ptr %87, i64 %67
  %71 = load double, ptr %70, align 8
  %72 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %67
  %73 = load double, ptr %72, align 8
  %74 = tail call double @llvm.fmuladd.f64(double %69, double %71, double %73)
  store double %74, ptr %72, align 8
  %75 = add nuw nsw i64 %59, 2
  %76 = icmp eq i64 %75, %16
  br i1 %76, label %132, label %58, !llvm.loop !11

77:                                               ; preds = %56, %77
  %78 = phi i64 [ %82, %77 ], [ %57, %56 ]
  %79 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %78
  %80 = load double, ptr %79, align 8
  %81 = fmul double %4, %80
  store double %81, ptr %79, align 8
  %82 = add nuw nsw i64 %78, 1
  %83 = icmp eq i64 %82, %16
  br i1 %83, label %123, label %77, !llvm.loop !12

84:                                               ; preds = %132, %123
  %85 = phi i64 [ %133, %132 ], [ 0, %123 ]
  %86 = getelementptr inbounds nuw [8 x i8], ptr %124, i64 %85
  %87 = getelementptr inbounds nuw [512 x i8], ptr %7, i64 %85
  %88 = select i1 %31, i1 true, i1 %131
  br i1 %88, label %109, label %89

89:                                               ; preds = %84
  %90 = load double, ptr %86, align 8, !alias.scope !13
  %91 = fmul double %3, %90
  %92 = insertelement <2 x double> poison, double %91, i64 0
  %93 = shufflevector <2 x double> %92, <2 x double> poison, <2 x i32> zeroinitializer
  br label %94

94:                                               ; preds = %94, %89
  %95 = phi i64 [ 0, %89 ], [ %106, %94 ]
  %96 = getelementptr inbounds nuw [8 x i8], ptr %87, i64 %95
  %97 = getelementptr inbounds nuw i8, ptr %96, i64 16
  %98 = load <2 x double>, ptr %96, align 8, !alias.scope !16
  %99 = load <2 x double>, ptr %97, align 8, !alias.scope !16
  %100 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %95
  %101 = getelementptr inbounds nuw i8, ptr %100, i64 16
  %102 = load <2 x double>, ptr %100, align 8, !alias.scope !18, !noalias !20
  %103 = load <2 x double>, ptr %101, align 8, !alias.scope !18, !noalias !20
  %104 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %93, <2 x double> %98, <2 x double> %102)
  %105 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %93, <2 x double> %99, <2 x double> %103)
  store <2 x double> %104, ptr %100, align 8, !alias.scope !18, !noalias !20
  store <2 x double> %105, ptr %101, align 8, !alias.scope !18, !noalias !20
  %106 = add nuw i64 %95, 4
  %107 = icmp eq i64 %106, %32
  br i1 %107, label %108, label %94, !llvm.loop !21

108:                                              ; preds = %94
  br i1 %33, label %132, label %109

109:                                              ; preds = %84, %108
  %110 = phi i64 [ %32, %108 ], [ 0, %84 ]
  br i1 %35, label %120, label %111

111:                                              ; preds = %109
  %112 = load double, ptr %86, align 8
  %113 = fmul double %3, %112
  %114 = getelementptr inbounds nuw [8 x i8], ptr %87, i64 %110
  %115 = load double, ptr %114, align 8
  %116 = getelementptr inbounds nuw [8 x i8], ptr %44, i64 %110
  %117 = load double, ptr %116, align 8
  %118 = tail call double @llvm.fmuladd.f64(double %113, double %115, double %117)
  store double %118, ptr %116, align 8
  %119 = or disjoint i64 %110, 1
  br label %120

120:                                              ; preds = %111, %109
  %121 = phi i64 [ %110, %109 ], [ %119, %111 ]
  %122 = icmp eq i64 %110, %36
  br i1 %122, label %132, label %58

123:                                              ; preds = %77, %55
  %124 = getelementptr inbounds nuw [512 x i8], ptr %6, i64 %38
  %125 = icmp ult ptr %40, %43
  %126 = icmp ult ptr %42, %41
  %127 = and i1 %125, %126
  %128 = icmp ult ptr %40, %23
  %129 = icmp ult ptr %7, %41
  %130 = and i1 %128, %129
  %131 = or i1 %127, %130
  br label %84

132:                                              ; preds = %120, %58, %108
  %133 = add nuw nsw i64 %85, 1
  %134 = icmp eq i64 %133, %17
  br i1 %134, label %135, label %84, !llvm.loop !22

135:                                              ; preds = %132
  %136 = add nuw nsw i64 %38, 1
  %137 = icmp eq i64 %136, %15
  br i1 %137, label %163, label %37, !llvm.loop !23

138:                                              ; preds = %10
  br i1 %12, label %139, label %163

139:                                              ; preds = %138
  %140 = zext nneg i32 %0 to i64
  %141 = zext nneg i32 %1 to i64
  %142 = icmp ult i32 %1, 4
  %143 = and i64 %141, 2147483644
  %144 = insertelement <2 x double> poison, double %4, i64 0
  %145 = shufflevector <2 x double> %144, <2 x double> poison, <2 x i32> zeroinitializer
  %146 = icmp eq i64 %143, %141
  br label %147

147:                                              ; preds = %139, %164
  %148 = phi i64 [ 0, %139 ], [ %165, %164 ]
  %149 = getelementptr inbounds nuw [512 x i8], ptr %5, i64 %148
  br i1 %142, label %161, label %150

150:                                              ; preds = %147, %150
  %151 = phi i64 [ %158, %150 ], [ 0, %147 ]
  %152 = getelementptr inbounds nuw [8 x i8], ptr %149, i64 %151
  %153 = getelementptr inbounds nuw i8, ptr %152, i64 16
  %154 = load <2 x double>, ptr %152, align 8
  %155 = load <2 x double>, ptr %153, align 8
  %156 = fmul <2 x double> %145, %154
  %157 = fmul <2 x double> %145, %155
  store <2 x double> %156, ptr %152, align 8
  store <2 x double> %157, ptr %153, align 8
  %158 = add nuw i64 %151, 4
  %159 = icmp eq i64 %158, %143
  br i1 %159, label %160, label %150, !llvm.loop !24

160:                                              ; preds = %150
  br i1 %146, label %164, label %161

161:                                              ; preds = %147, %160
  %162 = phi i64 [ 0, %147 ], [ %143, %160 ]
  br label %167

163:                                              ; preds = %164, %135, %13, %138, %8
  ret void

164:                                              ; preds = %167, %160
  %165 = add nuw nsw i64 %148, 1
  %166 = icmp eq i64 %165, %140
  br i1 %166, label %163, label %147, !llvm.loop !23

167:                                              ; preds = %161, %167
  %168 = phi i64 [ %172, %167 ], [ %162, %161 ]
  %169 = getelementptr inbounds nuw [8 x i8], ptr %149, i64 %168
  %170 = load double, ptr %169, align 8
  %171 = fmul double %4, %170
  store double %171, ptr %169, align 8
  %172 = add nuw nsw i64 %168, 1
  %173 = icmp eq i64 %172, %141
  br i1 %173, label %164, label %167, !llvm.loop !25
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fmuladd.f64(double, double, double) #2

; Function Attrs: nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #3 {
  br label %1

1:                                                ; preds = %0, %18
  %2 = phi i64 [ 0, %0 ], [ %19, %18 ]
  %3 = getelementptr inbounds nuw [512 x i8], ptr @main.A, i64 %2
  %4 = insertelement <2 x i64> poison, i64 %2, i64 0
  %5 = shufflevector <2 x i64> %4, <2 x i64> poison, <2 x i32> zeroinitializer
  br label %6

6:                                                ; preds = %6, %1
  %7 = phi i64 [ 0, %1 ], [ %15, %6 ]
  %8 = phi <2 x i64> [ <i64 0, i64 1>, %1 ], [ %16, %6 ]
  %9 = mul nuw nsw <2 x i64> %8, %5
  %10 = trunc <2 x i64> %9 to <2 x i32>
  %11 = and <2 x i32> %10, splat (i32 1023)
  %12 = uitofp nneg <2 x i32> %11 to <2 x double>
  %13 = fmul nnan <2 x double> %12, splat (double f0x3F50000000000000)
  %14 = getelementptr inbounds nuw [8 x i8], ptr %3, i64 %7
  store <2 x double> %13, ptr %14, align 16
  %15 = add nuw i64 %7, 2
  %16 = add nuw nsw <2 x i64> %8, splat (i64 2)
  %17 = icmp eq i64 %15, 64
  br i1 %17, label %18, label %6, !llvm.loop !26

18:                                               ; preds = %6
  %19 = add nuw nsw i64 %2, 1
  %20 = icmp eq i64 %19, 64
  br i1 %20, label %21, label %1, !llvm.loop !27

21:                                               ; preds = %18, %38
  %22 = phi i64 [ %39, %38 ], [ 0, %18 ]
  %23 = getelementptr inbounds nuw [512 x i8], ptr @main.B, i64 %22
  %24 = insertelement <2 x i64> poison, i64 %22, i64 0
  %25 = shufflevector <2 x i64> %24, <2 x i64> poison, <2 x i32> zeroinitializer
  br label %26

26:                                               ; preds = %26, %21
  %27 = phi i64 [ 0, %21 ], [ %35, %26 ]
  %28 = phi <2 x i64> [ <i64 0, i64 1>, %21 ], [ %36, %26 ]
  %29 = mul nuw nsw <2 x i64> %28, %25
  %30 = trunc <2 x i64> %29 to <2 x i32>
  %31 = and <2 x i32> %30, splat (i32 511)
  %32 = uitofp nneg <2 x i32> %31 to <2 x double>
  %33 = fmul nnan <2 x double> %32, splat (double f0x3F60000000000000)
  %34 = getelementptr inbounds nuw [8 x i8], ptr %23, i64 %27
  store <2 x double> %33, ptr %34, align 16
  %35 = add nuw i64 %27, 2
  %36 = add nuw nsw <2 x i64> %28, splat (i64 2)
  %37 = icmp eq i64 %35, 64
  br i1 %37, label %38, label %26, !llvm.loop !28

38:                                               ; preds = %26
  %39 = add nuw nsw i64 %22, 1
  %40 = icmp eq i64 %39, 64
  br i1 %40, label %41, label %21, !llvm.loop !29

41:                                               ; preds = %38, %41
  %42 = phi i64 [ %75, %41 ], [ 0, %38 ]
  %43 = getelementptr inbounds nuw [512 x i8], ptr @main.C, i64 %42
  store <2 x double> splat (double 5.000000e-01), ptr %43, align 16
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 16
  store <2 x double> splat (double 5.000000e-01), ptr %44, align 16
  %45 = getelementptr inbounds nuw i8, ptr %43, i64 32
  store <2 x double> splat (double 5.000000e-01), ptr %45, align 16
  %46 = getelementptr inbounds nuw i8, ptr %43, i64 48
  store <2 x double> splat (double 5.000000e-01), ptr %46, align 16
  %47 = getelementptr inbounds nuw i8, ptr %43, i64 64
  store <2 x double> splat (double 5.000000e-01), ptr %47, align 16
  %48 = getelementptr inbounds nuw i8, ptr %43, i64 80
  store <2 x double> splat (double 5.000000e-01), ptr %48, align 16
  %49 = getelementptr inbounds nuw i8, ptr %43, i64 96
  store <2 x double> splat (double 5.000000e-01), ptr %49, align 16
  %50 = getelementptr inbounds nuw i8, ptr %43, i64 112
  store <2 x double> splat (double 5.000000e-01), ptr %50, align 16
  %51 = getelementptr inbounds nuw i8, ptr %43, i64 128
  store <2 x double> splat (double 5.000000e-01), ptr %51, align 16
  %52 = getelementptr inbounds nuw i8, ptr %43, i64 144
  store <2 x double> splat (double 5.000000e-01), ptr %52, align 16
  %53 = getelementptr inbounds nuw i8, ptr %43, i64 160
  store <2 x double> splat (double 5.000000e-01), ptr %53, align 16
  %54 = getelementptr inbounds nuw i8, ptr %43, i64 176
  store <2 x double> splat (double 5.000000e-01), ptr %54, align 16
  %55 = getelementptr inbounds nuw i8, ptr %43, i64 192
  store <2 x double> splat (double 5.000000e-01), ptr %55, align 16
  %56 = getelementptr inbounds nuw i8, ptr %43, i64 208
  store <2 x double> splat (double 5.000000e-01), ptr %56, align 16
  %57 = getelementptr inbounds nuw i8, ptr %43, i64 224
  store <2 x double> splat (double 5.000000e-01), ptr %57, align 16
  %58 = getelementptr inbounds nuw i8, ptr %43, i64 240
  store <2 x double> splat (double 5.000000e-01), ptr %58, align 16
  %59 = getelementptr inbounds nuw i8, ptr %43, i64 256
  store <2 x double> splat (double 5.000000e-01), ptr %59, align 16
  %60 = getelementptr inbounds nuw i8, ptr %43, i64 272
  store <2 x double> splat (double 5.000000e-01), ptr %60, align 16
  %61 = getelementptr inbounds nuw i8, ptr %43, i64 288
  store <2 x double> splat (double 5.000000e-01), ptr %61, align 16
  %62 = getelementptr inbounds nuw i8, ptr %43, i64 304
  store <2 x double> splat (double 5.000000e-01), ptr %62, align 16
  %63 = getelementptr inbounds nuw i8, ptr %43, i64 320
  store <2 x double> splat (double 5.000000e-01), ptr %63, align 16
  %64 = getelementptr inbounds nuw i8, ptr %43, i64 336
  store <2 x double> splat (double 5.000000e-01), ptr %64, align 16
  %65 = getelementptr inbounds nuw i8, ptr %43, i64 352
  store <2 x double> splat (double 5.000000e-01), ptr %65, align 16
  %66 = getelementptr inbounds nuw i8, ptr %43, i64 368
  store <2 x double> splat (double 5.000000e-01), ptr %66, align 16
  %67 = getelementptr inbounds nuw i8, ptr %43, i64 384
  store <2 x double> splat (double 5.000000e-01), ptr %67, align 16
  %68 = getelementptr inbounds nuw i8, ptr %43, i64 400
  store <2 x double> splat (double 5.000000e-01), ptr %68, align 16
  %69 = getelementptr inbounds nuw i8, ptr %43, i64 416
  store <2 x double> splat (double 5.000000e-01), ptr %69, align 16
  %70 = getelementptr inbounds nuw i8, ptr %43, i64 432
  store <2 x double> splat (double 5.000000e-01), ptr %70, align 16
  %71 = getelementptr inbounds nuw i8, ptr %43, i64 448
  store <2 x double> splat (double 5.000000e-01), ptr %71, align 16
  %72 = getelementptr inbounds nuw i8, ptr %43, i64 464
  store <2 x double> splat (double 5.000000e-01), ptr %72, align 16
  %73 = getelementptr inbounds nuw i8, ptr %43, i64 480
  store <2 x double> splat (double 5.000000e-01), ptr %73, align 16
  %74 = getelementptr inbounds nuw i8, ptr %43, i64 496
  store <2 x double> splat (double 5.000000e-01), ptr %74, align 16
  %75 = add nuw nsw i64 %42, 1
  %76 = icmp eq i64 %75, 64
  br i1 %76, label %77, label %41, !llvm.loop !30

77:                                               ; preds = %41, %384
  %78 = phi i32 [ %385, %384 ], [ 0, %41 ]
  br label %82

79:                                               ; preds = %384
  %80 = load double, ptr @main.C, align 16
  %81 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @"??_C@_0O@GMPLCDGC@C?$FL0?$FN?$FL0?$FN?5?$DN?5?$CFf?6?$AA@", double noundef %80)
  ret i32 0

82:                                               ; preds = %77, %381
  %83 = phi i64 [ %382, %381 ], [ 0, %77 ]
  %84 = getelementptr inbounds nuw [512 x i8], ptr @main.C, i64 %83
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 16
  %86 = load <2 x double>, ptr %84, align 16
  %87 = load <2 x double>, ptr %85, align 16
  %88 = fmul <2 x double> %86, splat (double 1.200000e+00)
  %89 = fmul <2 x double> %87, splat (double 1.200000e+00)
  store <2 x double> %88, ptr %84, align 16
  store <2 x double> %89, ptr %85, align 16
  %90 = getelementptr inbounds nuw i8, ptr %84, i64 32
  %91 = getelementptr inbounds nuw i8, ptr %84, i64 48
  %92 = load <2 x double>, ptr %90, align 16
  %93 = load <2 x double>, ptr %91, align 16
  %94 = fmul <2 x double> %92, splat (double 1.200000e+00)
  %95 = fmul <2 x double> %93, splat (double 1.200000e+00)
  store <2 x double> %94, ptr %90, align 16
  store <2 x double> %95, ptr %91, align 16
  %96 = getelementptr inbounds nuw i8, ptr %84, i64 64
  %97 = getelementptr inbounds nuw i8, ptr %84, i64 80
  %98 = load <2 x double>, ptr %96, align 16
  %99 = load <2 x double>, ptr %97, align 16
  %100 = fmul <2 x double> %98, splat (double 1.200000e+00)
  %101 = fmul <2 x double> %99, splat (double 1.200000e+00)
  store <2 x double> %100, ptr %96, align 16
  store <2 x double> %101, ptr %97, align 16
  %102 = getelementptr inbounds nuw i8, ptr %84, i64 96
  %103 = getelementptr inbounds nuw i8, ptr %84, i64 112
  %104 = load <2 x double>, ptr %102, align 16
  %105 = load <2 x double>, ptr %103, align 16
  %106 = fmul <2 x double> %104, splat (double 1.200000e+00)
  %107 = fmul <2 x double> %105, splat (double 1.200000e+00)
  store <2 x double> %106, ptr %102, align 16
  store <2 x double> %107, ptr %103, align 16
  %108 = getelementptr inbounds nuw i8, ptr %84, i64 128
  %109 = getelementptr inbounds nuw i8, ptr %84, i64 144
  %110 = load <2 x double>, ptr %108, align 16
  %111 = load <2 x double>, ptr %109, align 16
  %112 = fmul <2 x double> %110, splat (double 1.200000e+00)
  %113 = fmul <2 x double> %111, splat (double 1.200000e+00)
  store <2 x double> %112, ptr %108, align 16
  store <2 x double> %113, ptr %109, align 16
  %114 = getelementptr inbounds nuw i8, ptr %84, i64 160
  %115 = getelementptr inbounds nuw i8, ptr %84, i64 176
  %116 = load <2 x double>, ptr %114, align 16
  %117 = load <2 x double>, ptr %115, align 16
  %118 = fmul <2 x double> %116, splat (double 1.200000e+00)
  %119 = fmul <2 x double> %117, splat (double 1.200000e+00)
  store <2 x double> %118, ptr %114, align 16
  store <2 x double> %119, ptr %115, align 16
  %120 = getelementptr inbounds nuw i8, ptr %84, i64 192
  %121 = getelementptr inbounds nuw i8, ptr %84, i64 208
  %122 = load <2 x double>, ptr %120, align 16
  %123 = load <2 x double>, ptr %121, align 16
  %124 = fmul <2 x double> %122, splat (double 1.200000e+00)
  %125 = fmul <2 x double> %123, splat (double 1.200000e+00)
  store <2 x double> %124, ptr %120, align 16
  store <2 x double> %125, ptr %121, align 16
  %126 = getelementptr inbounds nuw i8, ptr %84, i64 224
  %127 = getelementptr inbounds nuw i8, ptr %84, i64 240
  %128 = load <2 x double>, ptr %126, align 16
  %129 = load <2 x double>, ptr %127, align 16
  %130 = fmul <2 x double> %128, splat (double 1.200000e+00)
  %131 = fmul <2 x double> %129, splat (double 1.200000e+00)
  store <2 x double> %130, ptr %126, align 16
  store <2 x double> %131, ptr %127, align 16
  %132 = getelementptr inbounds nuw i8, ptr %84, i64 256
  %133 = getelementptr inbounds nuw i8, ptr %84, i64 272
  %134 = load <2 x double>, ptr %132, align 16
  %135 = load <2 x double>, ptr %133, align 16
  %136 = fmul <2 x double> %134, splat (double 1.200000e+00)
  %137 = fmul <2 x double> %135, splat (double 1.200000e+00)
  store <2 x double> %136, ptr %132, align 16
  store <2 x double> %137, ptr %133, align 16
  %138 = getelementptr inbounds nuw i8, ptr %84, i64 288
  %139 = getelementptr inbounds nuw i8, ptr %84, i64 304
  %140 = load <2 x double>, ptr %138, align 16
  %141 = load <2 x double>, ptr %139, align 16
  %142 = fmul <2 x double> %140, splat (double 1.200000e+00)
  %143 = fmul <2 x double> %141, splat (double 1.200000e+00)
  store <2 x double> %142, ptr %138, align 16
  store <2 x double> %143, ptr %139, align 16
  %144 = getelementptr inbounds nuw i8, ptr %84, i64 320
  %145 = getelementptr inbounds nuw i8, ptr %84, i64 336
  %146 = load <2 x double>, ptr %144, align 16
  %147 = load <2 x double>, ptr %145, align 16
  %148 = fmul <2 x double> %146, splat (double 1.200000e+00)
  %149 = fmul <2 x double> %147, splat (double 1.200000e+00)
  store <2 x double> %148, ptr %144, align 16
  store <2 x double> %149, ptr %145, align 16
  %150 = getelementptr inbounds nuw i8, ptr %84, i64 352
  %151 = getelementptr inbounds nuw i8, ptr %84, i64 368
  %152 = load <2 x double>, ptr %150, align 16
  %153 = load <2 x double>, ptr %151, align 16
  %154 = fmul <2 x double> %152, splat (double 1.200000e+00)
  %155 = fmul <2 x double> %153, splat (double 1.200000e+00)
  store <2 x double> %154, ptr %150, align 16
  store <2 x double> %155, ptr %151, align 16
  %156 = getelementptr inbounds nuw i8, ptr %84, i64 384
  %157 = getelementptr inbounds nuw i8, ptr %84, i64 400
  %158 = load <2 x double>, ptr %156, align 16
  %159 = load <2 x double>, ptr %157, align 16
  %160 = fmul <2 x double> %158, splat (double 1.200000e+00)
  %161 = fmul <2 x double> %159, splat (double 1.200000e+00)
  store <2 x double> %160, ptr %156, align 16
  store <2 x double> %161, ptr %157, align 16
  %162 = getelementptr inbounds nuw i8, ptr %84, i64 416
  %163 = getelementptr inbounds nuw i8, ptr %84, i64 432
  %164 = load <2 x double>, ptr %162, align 16
  %165 = load <2 x double>, ptr %163, align 16
  %166 = fmul <2 x double> %164, splat (double 1.200000e+00)
  %167 = fmul <2 x double> %165, splat (double 1.200000e+00)
  store <2 x double> %166, ptr %162, align 16
  store <2 x double> %167, ptr %163, align 16
  %168 = getelementptr inbounds nuw i8, ptr %84, i64 448
  %169 = getelementptr inbounds nuw i8, ptr %84, i64 464
  %170 = load <2 x double>, ptr %168, align 16
  %171 = load <2 x double>, ptr %169, align 16
  %172 = fmul <2 x double> %170, splat (double 1.200000e+00)
  %173 = fmul <2 x double> %171, splat (double 1.200000e+00)
  store <2 x double> %172, ptr %168, align 16
  store <2 x double> %173, ptr %169, align 16
  %174 = getelementptr inbounds nuw i8, ptr %84, i64 480
  %175 = getelementptr inbounds nuw i8, ptr %84, i64 496
  %176 = load <2 x double>, ptr %174, align 16
  %177 = load <2 x double>, ptr %175, align 16
  %178 = fmul <2 x double> %176, splat (double 1.200000e+00)
  %179 = fmul <2 x double> %177, splat (double 1.200000e+00)
  store <2 x double> %178, ptr %174, align 16
  store <2 x double> %179, ptr %175, align 16
  %180 = getelementptr inbounds nuw [512 x i8], ptr @main.A, i64 %83
  %181 = getelementptr inbounds nuw i8, ptr %84, i64 16
  %182 = getelementptr inbounds nuw i8, ptr %84, i64 32
  %183 = getelementptr inbounds nuw i8, ptr %84, i64 48
  %184 = getelementptr inbounds nuw i8, ptr %84, i64 64
  %185 = getelementptr inbounds nuw i8, ptr %84, i64 80
  %186 = getelementptr inbounds nuw i8, ptr %84, i64 96
  %187 = getelementptr inbounds nuw i8, ptr %84, i64 112
  %188 = getelementptr inbounds nuw i8, ptr %84, i64 128
  %189 = getelementptr inbounds nuw i8, ptr %84, i64 144
  %190 = getelementptr inbounds nuw i8, ptr %84, i64 160
  %191 = getelementptr inbounds nuw i8, ptr %84, i64 176
  %192 = getelementptr inbounds nuw i8, ptr %84, i64 192
  %193 = getelementptr inbounds nuw i8, ptr %84, i64 208
  %194 = getelementptr inbounds nuw i8, ptr %84, i64 224
  %195 = getelementptr inbounds nuw i8, ptr %84, i64 240
  %196 = getelementptr inbounds nuw i8, ptr %84, i64 256
  %197 = getelementptr inbounds nuw i8, ptr %84, i64 272
  %198 = getelementptr inbounds nuw i8, ptr %84, i64 288
  %199 = getelementptr inbounds nuw i8, ptr %84, i64 304
  %200 = getelementptr inbounds nuw i8, ptr %84, i64 320
  %201 = getelementptr inbounds nuw i8, ptr %84, i64 336
  %202 = getelementptr inbounds nuw i8, ptr %84, i64 352
  %203 = getelementptr inbounds nuw i8, ptr %84, i64 368
  %204 = getelementptr inbounds nuw i8, ptr %84, i64 384
  %205 = getelementptr inbounds nuw i8, ptr %84, i64 400
  %206 = getelementptr inbounds nuw i8, ptr %84, i64 416
  %207 = getelementptr inbounds nuw i8, ptr %84, i64 432
  %208 = getelementptr inbounds nuw i8, ptr %84, i64 448
  %209 = getelementptr inbounds nuw i8, ptr %84, i64 464
  %210 = getelementptr inbounds nuw i8, ptr %84, i64 480
  %211 = getelementptr inbounds nuw i8, ptr %84, i64 496
  %212 = load <2 x double>, ptr %84, align 16
  %213 = load <2 x double>, ptr %181, align 16
  %214 = load <2 x double>, ptr %182, align 16
  %215 = load <2 x double>, ptr %183, align 16
  %216 = load <2 x double>, ptr %184, align 16
  %217 = load <2 x double>, ptr %185, align 16
  %218 = load <2 x double>, ptr %186, align 16
  %219 = load <2 x double>, ptr %187, align 16
  %220 = load <2 x double>, ptr %188, align 16
  %221 = load <2 x double>, ptr %189, align 16
  %222 = load <2 x double>, ptr %190, align 16
  %223 = load <2 x double>, ptr %191, align 16
  %224 = load <2 x double>, ptr %192, align 16
  %225 = load <2 x double>, ptr %193, align 16
  %226 = load <2 x double>, ptr %194, align 16
  %227 = load <2 x double>, ptr %195, align 16
  %228 = load <2 x double>, ptr %196, align 16
  %229 = load <2 x double>, ptr %197, align 16
  %230 = load <2 x double>, ptr %198, align 16
  %231 = load <2 x double>, ptr %199, align 16
  %232 = load <2 x double>, ptr %200, align 16
  %233 = load <2 x double>, ptr %201, align 16
  %234 = load <2 x double>, ptr %202, align 16
  %235 = load <2 x double>, ptr %203, align 16
  %236 = load <2 x double>, ptr %204, align 16
  %237 = load <2 x double>, ptr %205, align 16
  %238 = load <2 x double>, ptr %206, align 16
  %239 = load <2 x double>, ptr %207, align 16
  %240 = load <2 x double>, ptr %208, align 16
  %241 = load <2 x double>, ptr %209, align 16
  %242 = load <2 x double>, ptr %210, align 16
  %243 = load <2 x double>, ptr %211, align 16
  br label %244

244:                                              ; preds = %244, %82
  %245 = phi <2 x double> [ %378, %244 ], [ %243, %82 ]
  %246 = phi <2 x double> [ %377, %244 ], [ %242, %82 ]
  %247 = phi <2 x double> [ %372, %244 ], [ %241, %82 ]
  %248 = phi <2 x double> [ %371, %244 ], [ %240, %82 ]
  %249 = phi <2 x double> [ %366, %244 ], [ %239, %82 ]
  %250 = phi <2 x double> [ %365, %244 ], [ %238, %82 ]
  %251 = phi <2 x double> [ %360, %244 ], [ %237, %82 ]
  %252 = phi <2 x double> [ %359, %244 ], [ %236, %82 ]
  %253 = phi <2 x double> [ %354, %244 ], [ %235, %82 ]
  %254 = phi <2 x double> [ %353, %244 ], [ %234, %82 ]
  %255 = phi <2 x double> [ %348, %244 ], [ %233, %82 ]
  %256 = phi <2 x double> [ %347, %244 ], [ %232, %82 ]
  %257 = phi <2 x double> [ %342, %244 ], [ %231, %82 ]
  %258 = phi <2 x double> [ %341, %244 ], [ %230, %82 ]
  %259 = phi <2 x double> [ %336, %244 ], [ %229, %82 ]
  %260 = phi <2 x double> [ %335, %244 ], [ %228, %82 ]
  %261 = phi <2 x double> [ %330, %244 ], [ %227, %82 ]
  %262 = phi <2 x double> [ %329, %244 ], [ %226, %82 ]
  %263 = phi <2 x double> [ %324, %244 ], [ %225, %82 ]
  %264 = phi <2 x double> [ %323, %244 ], [ %224, %82 ]
  %265 = phi <2 x double> [ %318, %244 ], [ %223, %82 ]
  %266 = phi <2 x double> [ %317, %244 ], [ %222, %82 ]
  %267 = phi <2 x double> [ %312, %244 ], [ %221, %82 ]
  %268 = phi <2 x double> [ %311, %244 ], [ %220, %82 ]
  %269 = phi <2 x double> [ %306, %244 ], [ %219, %82 ]
  %270 = phi <2 x double> [ %305, %244 ], [ %218, %82 ]
  %271 = phi <2 x double> [ %300, %244 ], [ %217, %82 ]
  %272 = phi <2 x double> [ %299, %244 ], [ %216, %82 ]
  %273 = phi <2 x double> [ %294, %244 ], [ %215, %82 ]
  %274 = phi <2 x double> [ %293, %244 ], [ %214, %82 ]
  %275 = phi <2 x double> [ %288, %244 ], [ %213, %82 ]
  %276 = phi <2 x double> [ %287, %244 ], [ %212, %82 ]
  %277 = phi i64 [ %379, %244 ], [ 0, %82 ]
  %278 = getelementptr inbounds nuw [8 x i8], ptr %180, i64 %277
  %279 = load double, ptr %278, align 8
  %280 = fmul double %279, 1.500000e+00
  %281 = insertelement <2 x double> poison, double %280, i64 0
  %282 = shufflevector <2 x double> %281, <2 x double> poison, <2 x i32> zeroinitializer
  %283 = getelementptr inbounds nuw [512 x i8], ptr @main.B, i64 %277
  %284 = getelementptr inbounds nuw i8, ptr %283, i64 16
  %285 = load <2 x double>, ptr %283, align 16
  %286 = load <2 x double>, ptr %284, align 16
  %287 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %285, <2 x double> %276)
  %288 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %286, <2 x double> %275)
  %289 = getelementptr inbounds nuw i8, ptr %283, i64 32
  %290 = getelementptr inbounds nuw i8, ptr %283, i64 48
  %291 = load <2 x double>, ptr %289, align 16
  %292 = load <2 x double>, ptr %290, align 16
  %293 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %291, <2 x double> %274)
  %294 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %292, <2 x double> %273)
  %295 = getelementptr inbounds nuw i8, ptr %283, i64 64
  %296 = getelementptr inbounds nuw i8, ptr %283, i64 80
  %297 = load <2 x double>, ptr %295, align 16
  %298 = load <2 x double>, ptr %296, align 16
  %299 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %297, <2 x double> %272)
  %300 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %298, <2 x double> %271)
  %301 = getelementptr inbounds nuw i8, ptr %283, i64 96
  %302 = getelementptr inbounds nuw i8, ptr %283, i64 112
  %303 = load <2 x double>, ptr %301, align 16
  %304 = load <2 x double>, ptr %302, align 16
  %305 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %303, <2 x double> %270)
  %306 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %304, <2 x double> %269)
  %307 = getelementptr inbounds nuw i8, ptr %283, i64 128
  %308 = getelementptr inbounds nuw i8, ptr %283, i64 144
  %309 = load <2 x double>, ptr %307, align 16
  %310 = load <2 x double>, ptr %308, align 16
  %311 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %309, <2 x double> %268)
  %312 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %310, <2 x double> %267)
  %313 = getelementptr inbounds nuw i8, ptr %283, i64 160
  %314 = getelementptr inbounds nuw i8, ptr %283, i64 176
  %315 = load <2 x double>, ptr %313, align 16
  %316 = load <2 x double>, ptr %314, align 16
  %317 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %315, <2 x double> %266)
  %318 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %316, <2 x double> %265)
  %319 = getelementptr inbounds nuw i8, ptr %283, i64 192
  %320 = getelementptr inbounds nuw i8, ptr %283, i64 208
  %321 = load <2 x double>, ptr %319, align 16
  %322 = load <2 x double>, ptr %320, align 16
  %323 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %321, <2 x double> %264)
  %324 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %322, <2 x double> %263)
  %325 = getelementptr inbounds nuw i8, ptr %283, i64 224
  %326 = getelementptr inbounds nuw i8, ptr %283, i64 240
  %327 = load <2 x double>, ptr %325, align 16
  %328 = load <2 x double>, ptr %326, align 16
  %329 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %327, <2 x double> %262)
  %330 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %328, <2 x double> %261)
  %331 = getelementptr inbounds nuw i8, ptr %283, i64 256
  %332 = getelementptr inbounds nuw i8, ptr %283, i64 272
  %333 = load <2 x double>, ptr %331, align 16
  %334 = load <2 x double>, ptr %332, align 16
  %335 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %333, <2 x double> %260)
  %336 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %334, <2 x double> %259)
  %337 = getelementptr inbounds nuw i8, ptr %283, i64 288
  %338 = getelementptr inbounds nuw i8, ptr %283, i64 304
  %339 = load <2 x double>, ptr %337, align 16
  %340 = load <2 x double>, ptr %338, align 16
  %341 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %339, <2 x double> %258)
  %342 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %340, <2 x double> %257)
  %343 = getelementptr inbounds nuw i8, ptr %283, i64 320
  %344 = getelementptr inbounds nuw i8, ptr %283, i64 336
  %345 = load <2 x double>, ptr %343, align 16
  %346 = load <2 x double>, ptr %344, align 16
  %347 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %345, <2 x double> %256)
  %348 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %346, <2 x double> %255)
  %349 = getelementptr inbounds nuw i8, ptr %283, i64 352
  %350 = getelementptr inbounds nuw i8, ptr %283, i64 368
  %351 = load <2 x double>, ptr %349, align 16
  %352 = load <2 x double>, ptr %350, align 16
  %353 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %351, <2 x double> %254)
  %354 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %352, <2 x double> %253)
  %355 = getelementptr inbounds nuw i8, ptr %283, i64 384
  %356 = getelementptr inbounds nuw i8, ptr %283, i64 400
  %357 = load <2 x double>, ptr %355, align 16
  %358 = load <2 x double>, ptr %356, align 16
  %359 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %357, <2 x double> %252)
  %360 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %358, <2 x double> %251)
  %361 = getelementptr inbounds nuw i8, ptr %283, i64 416
  %362 = getelementptr inbounds nuw i8, ptr %283, i64 432
  %363 = load <2 x double>, ptr %361, align 16
  %364 = load <2 x double>, ptr %362, align 16
  %365 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %363, <2 x double> %250)
  %366 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %364, <2 x double> %249)
  %367 = getelementptr inbounds nuw i8, ptr %283, i64 448
  %368 = getelementptr inbounds nuw i8, ptr %283, i64 464
  %369 = load <2 x double>, ptr %367, align 16
  %370 = load <2 x double>, ptr %368, align 16
  %371 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %369, <2 x double> %248)
  %372 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %370, <2 x double> %247)
  %373 = getelementptr inbounds nuw i8, ptr %283, i64 480
  %374 = getelementptr inbounds nuw i8, ptr %283, i64 496
  %375 = load <2 x double>, ptr %373, align 16
  %376 = load <2 x double>, ptr %374, align 16
  %377 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %375, <2 x double> %246)
  %378 = tail call <2 x double> @llvm.fmuladd.v2f64(<2 x double> %282, <2 x double> %376, <2 x double> %245)
  %379 = add nuw nsw i64 %277, 1
  %380 = icmp eq i64 %379, 64
  br i1 %380, label %381, label %244, !llvm.loop !22

381:                                              ; preds = %244
  store <2 x double> %287, ptr %84, align 16
  store <2 x double> %288, ptr %181, align 16
  store <2 x double> %293, ptr %182, align 16
  store <2 x double> %294, ptr %183, align 16
  store <2 x double> %299, ptr %184, align 16
  store <2 x double> %300, ptr %185, align 16
  store <2 x double> %305, ptr %186, align 16
  store <2 x double> %306, ptr %187, align 16
  store <2 x double> %311, ptr %188, align 16
  store <2 x double> %312, ptr %189, align 16
  store <2 x double> %317, ptr %190, align 16
  store <2 x double> %318, ptr %191, align 16
  store <2 x double> %323, ptr %192, align 16
  store <2 x double> %324, ptr %193, align 16
  store <2 x double> %329, ptr %194, align 16
  store <2 x double> %330, ptr %195, align 16
  store <2 x double> %335, ptr %196, align 16
  store <2 x double> %336, ptr %197, align 16
  store <2 x double> %341, ptr %198, align 16
  store <2 x double> %342, ptr %199, align 16
  store <2 x double> %347, ptr %200, align 16
  store <2 x double> %348, ptr %201, align 16
  store <2 x double> %353, ptr %202, align 16
  store <2 x double> %354, ptr %203, align 16
  store <2 x double> %359, ptr %204, align 16
  store <2 x double> %360, ptr %205, align 16
  store <2 x double> %365, ptr %206, align 16
  store <2 x double> %366, ptr %207, align 16
  store <2 x double> %371, ptr %208, align 16
  store <2 x double> %372, ptr %209, align 16
  store <2 x double> %377, ptr %210, align 16
  store <2 x double> %378, ptr %211, align 16
  %382 = add nuw nsw i64 %83, 1
  %383 = icmp eq i64 %382, 64
  br i1 %383, label %384, label %82, !llvm.loop !23

384:                                              ; preds = %381
  %385 = add nuw nsw i32 %78, 1
  %386 = icmp eq i32 %385, 40
  br i1 %386, label %79, label %77, !llvm.loop !31
}

; Function Attrs: inlinehint nounwind uwtable
define linkonce_odr dso_local i32 @printf(ptr noundef %0, ...) local_unnamed_addr #4 comdat {
  %2 = alloca ptr, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #9
  call void @llvm.va_start.p0(ptr nonnull %2)
  %3 = load ptr, ptr %2, align 8
  %4 = call ptr @__acrt_iob_func(i32 noundef 1) #9
  %5 = call ptr @__local_stdio_printf_options(), !inline_history !32
  %6 = load i64, ptr %5, align 8
  %7 = call i32 @__stdio_common_vfprintf(i64 noundef %6, ptr noundef %4, ptr noundef %0, ptr noundef null, ptr noundef %3) #9, !inline_history !32
  call void @llvm.va_end.p0(ptr nonnull %2)
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #9
  ret i32 %7
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #5

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local ptr @__local_stdio_printf_options() local_unnamed_addr #6 comdat {
  ret ptr @__local_stdio_printf_options._OptionsStorage
}

declare dso_local ptr @__acrt_iob_func(i32 noundef) local_unnamed_addr #7

declare dso_local i32 @__stdio_common_vfprintf(i64 noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <2 x double> @llvm.fmuladd.v2f64(<2 x double>, <2 x double>, <2 x double>) #8

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { inlinehint nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #6 = { noinline nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #9 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 23.1.0 (https://github.com/llvm/llvm-project ea7d852a70e8bdfaf601d6626a760f9771b2c4b4)", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts\\scratch\\rigorous_experiment\\gemm.c", directory: "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"clang version 23.1.0 (https://github.com/llvm/llvm-project ea7d852a70e8bdfaf601d6626a760f9771b2c4b4)"}
!7 = distinct !{!7, !8, !9, !10}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!"llvm.loop.isvectorized", i32 1}
!10 = !{!"llvm.loop.unroll.runtime.disable"}
!11 = distinct !{!11, !8, !9}
!12 = distinct !{!12, !8, !10, !9}
!13 = !{!14}
!14 = distinct !{!14, !15}
!15 = distinct !{!15, !"LVerDomain"}
!16 = !{!17}
!17 = distinct !{!17, !15}
!18 = !{!19}
!19 = distinct !{!19, !15}
!20 = !{!14, !17}
!21 = distinct !{!21, !8, !9, !10}
!22 = distinct !{!22, !8}
!23 = distinct !{!23, !8}
!24 = distinct !{!24, !8, !9, !10}
!25 = distinct !{!25, !8, !10, !9}
!26 = distinct !{!26, !8, !9, !10}
!27 = distinct !{!27, !8}
!28 = distinct !{!28, !8, !9, !10}
!29 = distinct !{!29, !8}
!30 = distinct !{!30, !8}
!31 = distinct !{!31, !8}
!32 = distinct !{null}
