; ModuleID = 'C:\Users\rithv\Desktop\New folder\TOACD\compiler-optimization-selector-main\compiler-optimization-selector-main\Codes\Python Scripts\scratch\rigorous_experiment\TC1_loop_heavy.c'
source_filename = "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts\\scratch\\rigorous_experiment\\TC1_loop_heavy.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.51.36260"

$printf = comdat any

$__local_stdio_printf_options = comdat any

$"??_C@_09GEJEEMHD@sum?5?$DN?5?$CFd?6?$AA@" = comdat any

@"??_C@_09GEJEEMHD@sum?5?$DN?5?$CFd?6?$AA@" = linkonce_odr dso_local unnamed_addr constant [10 x i8] c"sum = %d\0A\00", comdat, align 8
@__local_stdio_printf_options._OptionsStorage = internal global i64 0, align 8

; Function Attrs: nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca [512 x i32], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %1) #8
  br label %2

2:                                                ; preds = %50, %0
  %3 = phi i32 [ 0, %0 ], [ %53, %50 ]
  %4 = phi i32 [ 0, %0 ], [ %52, %50 ]
  br label %5

5:                                                ; preds = %5, %2
  %6 = phi i64 [ 0, %2 ], [ %19, %5 ]
  %7 = phi <4 x i32> [ <i32 0, i32 1, i32 2, i32 3>, %2 ], [ %20, %5 ]
  %8 = phi <4 x i32> [ <i32 0, i32 1, i32 2, i32 3>, %2 ], [ %21, %5 ]
  %9 = add <4 x i32> %7, splat (i32 4)
  %10 = lshr <4 x i32> %7, splat (i32 3)
  %11 = lshr <4 x i32> %9, splat (i32 3)
  %12 = mul <4 x i32> %8, splat (i32 31)
  %13 = mul <4 x i32> %8, splat (i32 31)
  %14 = add <4 x i32> %13, splat (i32 124)
  %15 = xor <4 x i32> %12, %10
  %16 = xor <4 x i32> %14, %11
  %17 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %6
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 16
  store <4 x i32> %15, ptr %17, align 4
  store <4 x i32> %16, ptr %18, align 4
  %19 = add nuw i64 %6, 8
  %20 = add <4 x i32> %7, splat (i32 8)
  %21 = add <4 x i32> %8, splat (i32 8)
  %22 = icmp eq i64 %19, 512
  br i1 %22, label %25, label %5, !llvm.loop !7

23:                                               ; preds = %50
  %24 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @"??_C@_09GEJEEMHD@sum?5?$DN?5?$CFd?6?$AA@", i32 noundef %52)
  call void @llvm.lifetime.end.p0(ptr nonnull %1) #8
  ret i32 0

25:                                               ; preds = %5
  %26 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %4, i64 0
  br label %27

27:                                               ; preds = %27, %25
  %28 = phi i64 [ 0, %25 ], [ %47, %27 ]
  %29 = phi <4 x i32> [ %26, %25 ], [ %45, %27 ]
  %30 = phi <4 x i32> [ zeroinitializer, %25 ], [ %46, %27 ]
  %31 = phi <4 x i16> [ <i16 0, i16 1, i16 2, i16 3>, %25 ], [ %48, %27 ]
  %32 = add <4 x i16> %31, splat (i16 4)
  %33 = getelementptr inbounds nuw [4 x i8], ptr %1, i64 %28
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 16
  %35 = load <4 x i32>, ptr %33, align 4
  %36 = load <4 x i32>, ptr %34, align 4
  %37 = urem <4 x i16> %31, splat (i16 7)
  %38 = urem <4 x i16> %32, splat (i16 7)
  %39 = add nuw nsw <4 x i16> %37, splat (i16 1)
  %40 = add nuw nsw <4 x i16> %38, splat (i16 1)
  %41 = zext nneg <4 x i16> %39 to <4 x i32>
  %42 = zext nneg <4 x i16> %40 to <4 x i32>
  %43 = mul <4 x i32> %35, %41
  %44 = mul <4 x i32> %36, %42
  %45 = add <4 x i32> %43, %29
  %46 = add <4 x i32> %44, %30
  %47 = add nuw i64 %28, 8
  %48 = add <4 x i16> %31, splat (i16 8)
  %49 = icmp eq i64 %47, 512
  br i1 %49, label %50, label %27, !llvm.loop !11

50:                                               ; preds = %27
  %51 = add <4 x i32> %46, %45
  %52 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %51)
  %53 = add nuw nsw i32 %3, 1
  %54 = icmp eq i32 %53, 20000
  br i1 %54, label %23, label %2, !llvm.loop !12
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local void @sink(i32 noundef %0) local_unnamed_addr #2 {
  ret void
}

; Function Attrs: inlinehint nounwind uwtable
define linkonce_odr dso_local i32 @printf(ptr noundef %0, ...) local_unnamed_addr #3 comdat {
  %2 = alloca ptr, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %2) #8
  call void @llvm.va_start.p0(ptr nonnull %2)
  %3 = load ptr, ptr %2, align 8
  %4 = call ptr @__acrt_iob_func(i32 noundef 1) #8
  %5 = call ptr @__local_stdio_printf_options(), !inline_history !13
  %6 = load i64, ptr %5, align 8
  %7 = call i32 @__stdio_common_vfprintf(i64 noundef %6, ptr noundef %4, ptr noundef %0, ptr noundef null, ptr noundef %3) #8, !inline_history !13
  call void @llvm.va_end.p0(ptr nonnull %2)
  call void @llvm.lifetime.end.p0(ptr nonnull %2) #8
  ret i32 %7
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #4

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local ptr @__local_stdio_printf_options() local_unnamed_addr #5 comdat {
  ret ptr @__local_stdio_printf_options._OptionsStorage
}

declare dso_local ptr @__acrt_iob_func(i32 noundef) local_unnamed_addr #6

declare dso_local i32 @__stdio_common_vfprintf(i64 noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #7

attributes #0 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { inlinehint nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #5 = { noinline nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 23.1.0 (https://github.com/llvm/llvm-project ea7d852a70e8bdfaf601d6626a760f9771b2c4b4)", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts\\scratch\\rigorous_experiment\\TC1_loop_heavy.c", directory: "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"clang version 23.1.0 (https://github.com/llvm/llvm-project ea7d852a70e8bdfaf601d6626a760f9771b2c4b4)"}
!7 = distinct !{!7, !8, !9, !10}
!8 = !{!"llvm.loop.mustprogress"}
!9 = !{!"llvm.loop.isvectorized", i32 1}
!10 = !{!"llvm.loop.unroll.runtime.disable"}
!11 = distinct !{!11, !8, !9, !10}
!12 = distinct !{!12, !8}
!13 = distinct !{null}
