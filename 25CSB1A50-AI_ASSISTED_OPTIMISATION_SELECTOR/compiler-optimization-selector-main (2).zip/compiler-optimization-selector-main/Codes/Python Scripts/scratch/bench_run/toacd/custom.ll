; ModuleID = 'C:\Users\rithv\Desktop\New folder\TOACD\compiler-optimization-selector-main\compiler-optimization-selector-main\Codes\Python Scripts\scratch\bench_run\o0\baseline.ll'
source_filename = "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts\\scratch\\bench_run\\gemm.c"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.51.36260"

$sprintf = comdat any

$vsprintf = comdat any

$_snprintf = comdat any

$_vsnprintf = comdat any

$printf = comdat any

$_vsprintf_l = comdat any

$_vsnprintf_l = comdat any

$__local_stdio_printf_options = comdat any

$_vfprintf_l = comdat any

$"??_C@_0O@GMPLCDGC@C?$FL0?$FN?$FL0?$FN?5?$DN?5?$CFf?6?$AA@" = comdat any

@main.C = internal global [64 x [64 x double]] zeroinitializer, align 16
@main.A = internal global [64 x [64 x double]] zeroinitializer, align 16
@main.B = internal global [64 x [64 x double]] zeroinitializer, align 16
@"??_C@_0O@GMPLCDGC@C?$FL0?$FN?$FL0?$FN?5?$DN?5?$CFf?6?$AA@" = linkonce_odr dso_local unnamed_addr constant [14 x i8] c"C[0][0] = %f\0A\00", comdat, align 8
@__local_stdio_printf_options._OptionsStorage = internal global i64 0, align 8

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @sprintf(ptr noundef %0, ptr noundef %1, ...) #0 comdat {
  %3 = alloca ptr, align 8
  call void @llvm.va_start.p0(ptr nonnull %3)
  %4 = load ptr, ptr %3, align 8
  %5 = call i32 @_vsprintf_l(ptr noundef %0, ptr noundef %1, ptr noundef null, ptr noundef %4)
  call void @llvm.va_end.p0(ptr %3)
  ret i32 %5
}

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @vsprintf(ptr noundef %0, ptr noundef %1, ptr noundef %2) #0 comdat {
  %4 = call i32 @_vsnprintf_l(ptr noundef %0, i64 noundef -1, ptr noundef %1, ptr noundef null, ptr noundef %2)
  ret i32 %4
}

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @_snprintf(ptr noundef %0, i64 noundef %1, ptr noundef %2, ...) #0 comdat {
  %4 = alloca ptr, align 8
  call void @llvm.va_start.p0(ptr nonnull %4)
  %5 = load ptr, ptr %4, align 8
  %6 = call i32 @_vsnprintf(ptr noundef %0, i64 noundef %1, ptr noundef %2, ptr noundef %5)
  call void @llvm.va_end.p0(ptr %4)
  ret i32 %6
}

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @_vsnprintf(ptr noundef %0, i64 noundef %1, ptr noundef %2, ptr noundef %3) #0 comdat {
  %5 = call i32 @_vsnprintf_l(ptr noundef %0, i64 noundef %1, ptr noundef %2, ptr noundef null, ptr noundef %3)
  ret i32 %5
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @kernel_gemm(i32 noundef %0, i32 noundef %1, i32 noundef %2, double noundef %3, double noundef %4, ptr noundef %5, ptr noundef %6, ptr noundef %7) #0 {
  br label %9

9:                                                ; preds = %43, %8
  %.03 = phi i32 [ 0, %8 ], [ %44, %43 ]
  %10 = icmp slt i32 %.03, %0
  br i1 %10, label %.preheader5, label %45

.preheader5:                                      ; preds = %9
  br label %11

11:                                               ; preds = %.preheader5, %13
  %.02 = phi i32 [ %20, %13 ], [ 0, %.preheader5 ]
  %12 = icmp slt i32 %.02, %1
  br i1 %12, label %13, label %.preheader4

.preheader4:                                      ; preds = %11
  br label %21

13:                                               ; preds = %11
  %14 = sext i32 %.03 to i64
  %15 = getelementptr inbounds [512 x i8], ptr %5, i64 %14
  %16 = sext i32 %.02 to i64
  %17 = getelementptr inbounds [8 x i8], ptr %15, i64 %16
  %18 = load double, ptr %17, align 8
  %19 = fmul double %18, %4
  store double %19, ptr %17, align 8
  %20 = add i32 %.02, 1
  br label %11, !llvm.loop !7

21:                                               ; preds = %.preheader4, %41
  %.01 = phi i32 [ %42, %41 ], [ 0, %.preheader4 ]
  %22 = icmp slt i32 %.01, %2
  br i1 %22, label %.preheader, label %43

.preheader:                                       ; preds = %21
  br label %23

23:                                               ; preds = %.preheader, %25
  %.0 = phi i32 [ %40, %25 ], [ 0, %.preheader ]
  %24 = icmp slt i32 %.0, %1
  br i1 %24, label %25, label %41

25:                                               ; preds = %23
  %26 = sext i32 %.03 to i64
  %27 = getelementptr inbounds [512 x i8], ptr %6, i64 %26
  %28 = sext i32 %.01 to i64
  %29 = getelementptr inbounds [8 x i8], ptr %27, i64 %28
  %30 = load double, ptr %29, align 8
  %31 = fmul double %3, %30
  %32 = getelementptr inbounds [512 x i8], ptr %7, i64 %28
  %33 = sext i32 %.0 to i64
  %34 = getelementptr inbounds [8 x i8], ptr %32, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = getelementptr inbounds [512 x i8], ptr %5, i64 %26
  %37 = getelementptr inbounds [8 x i8], ptr %36, i64 %33
  %38 = load double, ptr %37, align 8
  %39 = call double @llvm.fmuladd.f64(double %31, double %35, double %38)
  store double %39, ptr %37, align 8
  %40 = add i32 %.0, 1
  br label %23, !llvm.loop !9

41:                                               ; preds = %23
  %42 = add i32 %.01, 1
  br label %21, !llvm.loop !10

43:                                               ; preds = %21
  %44 = add i32 %.03, 1
  br label %9, !llvm.loop !11

45:                                               ; preds = %9
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fmuladd.f64(double, double, double) #1

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @main() #0 {
  br label %1

1:                                                ; preds = %15, %0
  %.01 = phi i32 [ 0, %0 ], [ %16, %15 ]
  %2 = icmp slt i32 %.01, 64
  br i1 %2, label %.preheader11, label %.preheader10

.preheader11:                                     ; preds = %1
  br label %3

.preheader10:                                     ; preds = %1
  br label %17

3:                                                ; preds = %.preheader11, %5
  %.02 = phi i32 [ %14, %5 ], [ 0, %.preheader11 ]
  %4 = icmp slt i32 %.02, 64
  br i1 %4, label %5, label %15

5:                                                ; preds = %3
  %6 = mul i32 %.01, %.02
  %7 = srem i32 %6, 1024
  %8 = sitofp i32 %7 to double
  %9 = fmul nnan double %8, f0x3F50000000000000
  %10 = sext i32 %.01 to i64
  %11 = getelementptr inbounds [512 x i8], ptr @main.A, i64 %10
  %12 = sext i32 %.02 to i64
  %13 = getelementptr inbounds [8 x i8], ptr %11, i64 %12
  store double %9, ptr %13, align 8
  %14 = add i32 %.02, 1
  br label %3, !llvm.loop !12

15:                                               ; preds = %3
  %16 = add i32 %.01, 1
  br label %1, !llvm.loop !13

17:                                               ; preds = %.preheader10, %31
  %.03 = phi i32 [ %32, %31 ], [ 0, %.preheader10 ]
  %18 = icmp slt i32 %.03, 64
  br i1 %18, label %.preheader9, label %.preheader8

.preheader9:                                      ; preds = %17
  br label %19

.preheader8:                                      ; preds = %17
  br label %33

19:                                               ; preds = %.preheader9, %21
  %.04 = phi i32 [ %30, %21 ], [ 0, %.preheader9 ]
  %20 = icmp slt i32 %.04, 64
  br i1 %20, label %21, label %31

21:                                               ; preds = %19
  %22 = mul i32 %.03, %.04
  %23 = srem i32 %22, 512
  %24 = sitofp i32 %23 to double
  %25 = fmul nnan double %24, f0x3F60000000000000
  %26 = sext i32 %.03 to i64
  %27 = getelementptr inbounds [512 x i8], ptr @main.B, i64 %26
  %28 = sext i32 %.04 to i64
  %29 = getelementptr inbounds [8 x i8], ptr %27, i64 %28
  store double %25, ptr %29, align 8
  %30 = add i32 %.04, 1
  br label %19, !llvm.loop !14

31:                                               ; preds = %19
  %32 = add i32 %.03, 1
  br label %17, !llvm.loop !15

33:                                               ; preds = %.preheader8, %49
  %.05 = phi i32 [ %50, %49 ], [ 0, %.preheader8 ]
  %34 = icmp slt i32 %.05, 64
  br i1 %34, label %.preheader7, label %.preheader

.preheader7:                                      ; preds = %33
  br label %35

.preheader:                                       ; preds = %33
  br label %51

35:                                               ; preds = %43, %.preheader7
  %.06 = phi i32 [ 0, %.preheader7 ], [ %48, %43 ]
  %36 = icmp samesign ult i32 %.06, 64
  br i1 %36, label %37, label %49

37:                                               ; preds = %35
  %38 = sext i32 %.05 to i64
  %39 = getelementptr inbounds [512 x i8], ptr @main.C, i64 %38
  %40 = sext i32 %.06 to i64
  %41 = getelementptr inbounds [8 x i8], ptr %39, i64 %40
  store double 5.000000e-01, ptr %41, align 8
  %42 = add nuw nsw i32 %.06, 1
  br label %43

43:                                               ; preds = %37
  %44 = sext i32 %.05 to i64
  %45 = getelementptr inbounds [512 x i8], ptr @main.C, i64 %44
  %46 = sext i32 %42 to i64
  %47 = getelementptr inbounds [8 x i8], ptr %45, i64 %46
  store double 5.000000e-01, ptr %47, align 8
  %48 = add nuw nsw i32 %.06, 2
  br label %35, !llvm.loop !16

49:                                               ; preds = %35
  %50 = add i32 %.05, 1
  br label %33, !llvm.loop !17

51:                                               ; preds = %.preheader, %53
  %.0 = phi i32 [ %54, %53 ], [ 0, %.preheader ]
  %52 = icmp slt i32 %.0, 40
  br i1 %52, label %53, label %55

53:                                               ; preds = %51
  call void @kernel_gemm(i32 noundef 64, i32 noundef 64, i32 noundef 64, double noundef 1.500000e+00, double noundef 1.200000e+00, ptr noundef nonnull @main.C, ptr noundef nonnull @main.A, ptr noundef nonnull @main.B)
  %54 = add i32 %.0, 1
  br label %51, !llvm.loop !18

55:                                               ; preds = %51
  %56 = load double, ptr @main.C, align 16
  %57 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @"??_C@_0O@GMPLCDGC@C?$FL0?$FN?$FL0?$FN?5?$DN?5?$CFf?6?$AA@", double noundef %56)
  ret i32 0
}

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @printf(ptr noundef %0, ...) #0 comdat {
  %2 = alloca ptr, align 8
  call void @llvm.va_start.p0(ptr nonnull %2)
  %3 = load ptr, ptr %2, align 8
  %4 = call ptr @__acrt_iob_func(i32 noundef 1) #4
  %5 = call i32 @_vfprintf_l(ptr noundef %4, ptr noundef %0, ptr noundef null, ptr noundef %3)
  call void @llvm.va_end.p0(ptr %2)
  ret i32 %5
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_start.p0(ptr) #2

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @_vsprintf_l(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 comdat {
  %5 = call i32 @_vsnprintf_l(ptr noundef %0, i64 noundef -1, ptr noundef %1, ptr noundef %2, ptr noundef %3)
  ret i32 %5
}

; Function Attrs: nocallback nofree nosync nounwind willreturn
declare void @llvm.va_end.p0(ptr) #2

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @_vsnprintf_l(ptr noundef %0, i64 noundef %1, ptr noundef %2, ptr noundef %3, ptr noundef %4) #0 comdat {
  %6 = call ptr @__local_stdio_printf_options()
  %7 = load i64, ptr %6, align 8
  %8 = or i64 %7, 1
  %9 = call i32 @__stdio_common_vsprintf(i64 noundef %8, ptr noundef %0, i64 noundef %1, ptr noundef %2, ptr noundef %3, ptr noundef %4) #4
  %10 = icmp slt i32 %9, 0
  %. = select i1 %10, i32 -1, i32 %9
  ret i32 %.
}

declare dso_local i32 @__stdio_common_vsprintf(i64 noundef, ptr noundef, i64 noundef, ptr noundef, ptr noundef, ptr noundef) #3

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local ptr @__local_stdio_printf_options() #0 comdat {
  ret ptr @__local_stdio_printf_options._OptionsStorage
}

; Function Attrs: noinline nounwind uwtable
define linkonce_odr dso_local i32 @_vfprintf_l(ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 comdat {
  %5 = call ptr @__local_stdio_printf_options()
  %6 = load i64, ptr %5, align 8
  %7 = call i32 @__stdio_common_vfprintf(i64 noundef %6, ptr noundef %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #4
  ret i32 %7
}

declare dso_local ptr @__acrt_iob_func(i32 noundef) #3

declare dso_local i32 @__stdio_common_vfprintf(i64 noundef, ptr noundef, ptr noundef, ptr noundef, ptr noundef) #3

attributes #0 = { noinline nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn }
attributes #3 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nounwind }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5}
!llvm.ident = !{!6}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "clang version 23.1.0 (https://github.com/llvm/llvm-project ea7d852a70e8bdfaf601d6626a760f9771b2c4b4)", isOptimized: false, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts\\scratch\\bench_run\\gemm.c", directory: "C:\\Users\\rithv\\Desktop\\New folder\\TOACD\\compiler-optimization-selector-main\\compiler-optimization-selector-main\\Codes\\Python Scripts")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 1, !"MaxTLSAlign", i32 65536}
!6 = !{!"clang version 23.1.0 (https://github.com/llvm/llvm-project ea7d852a70e8bdfaf601d6626a760f9771b2c4b4)"}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = distinct !{!10, !8}
!11 = distinct !{!11, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8}
!14 = distinct !{!14, !8}
!15 = distinct !{!15, !8}
!16 = distinct !{!16, !8}
!17 = distinct !{!17, !8}
!18 = distinct !{!18, !8}
