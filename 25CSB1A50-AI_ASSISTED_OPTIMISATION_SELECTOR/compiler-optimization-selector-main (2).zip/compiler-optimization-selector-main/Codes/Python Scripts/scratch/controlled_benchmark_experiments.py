"""
Controlled benchmark experiment runner for TOACD.
Tests 4 distinct program archetypes under identical alternating interleaved conditions:
1. Very short program: 01_hello_world.c
2. Loop-heavy program: TC1_loop_heavy.c
3. Compute-heavy program: gemm.c
4. Memory-intensive program: memory_ops.c
"""

import os
import sys
import json
import time
import subprocess
import tempfile
import shutil

# Ensure workspace is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from moo.measurement import measure_interleaved, TimingStats
from moo.toolchain import verify_toolchain
from optimization_selector import select_with_provenance

CLANG_PATH = r"C:\Program Files\LLVM\bin\clang.exe"
OPT_PATH = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

TEST_PROGRAMS = [
    {
        "category": "Very Short",
        "name": "01_hello_world.c",
        "path": r"compiler-optimization-selector-main/Codes/test_cases/01_hello_world.c",
    },
    {
        "category": "Loop-Heavy",
        "name": "TC1_loop_heavy.c",
        "path": r"compiler-optimization-selector-main/Codes/test_cases/TC1_loop_heavy.c",
    },
    {
        "category": "Compute-Heavy",
        "name": "gemm.c",
        "path": r"compiler-optimization-selector-main/Codes/test_cases/gemm.c",
    },
    {
        "category": "Memory-Intensive",
        "name": "memory_ops.c",
        "path": r"compiler-optimization-selector-main/Codes/test_cases/memory_ops.c",
    },
]

def build_executable(src_path: str, flag_or_passes: str, out_dir: str, name_prefix: str) -> str:
    """Builds an executable for a flag or pass sequence."""
    exe_path = os.path.join(out_dir, f"{name_prefix}.exe")
    if flag_or_passes.startswith("-O"):
        cmd = [CLANG_PATH, flag_or_passes, src_path, "-o", exe_path]
        subprocess.run(cmd, check=True, capture_output=True)
    else:
        # LLVM pass pipeline via opt -> clang backend
        unopt_ll = os.path.join(out_dir, f"{name_prefix}_unopt.ll")
        opt_ll = os.path.join(out_dir, f"{name_prefix}_opt.ll")
        cmd_emit = [CLANG_PATH, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src_path, "-o", unopt_ll]
        subprocess.run(cmd_emit, check=True, capture_output=True)
        cmd_opt = [OPT_PATH, f"-passes={flag_or_passes}", unopt_ll, "-S", "-o", opt_ll]
        subprocess.run(cmd_opt, check=True, capture_output=True)
        cmd_clang = [CLANG_PATH, "-O2", opt_ll, "-o", exe_path]
        subprocess.run(cmd_clang, check=True, capture_output=True)
    return exe_path

def run_experiment():
    results_summary = []
    tmp_root = tempfile.mkdtemp(prefix="toacd_controlled_bench_")

    try:
        for prog in TEST_PROGRAMS:
            cat = prog["category"]
            pname = prog["name"]
            src_path = os.path.abspath(prog["path"])
            print(f"\n=======================================================")
            print(f"Benchmarking Archetype: {cat} ({pname})")
            print(f"=======================================================")

            # 1. Determine AI strategy via deterministic DQN/MOO selector
            sel = select_with_provenance(src_path)
            ai_strat = sel.strategy if sel else "-O2"
            print(f"DQN Selected Strategy: {ai_strat}")

            work_dir = os.path.join(tmp_root, pname.replace(".", "_"))
            os.makedirs(work_dir, exist_ok=True)

            # 2. Build reference (-O0), production (-O3), and AI-optimized executables
            exe_o0 = build_executable(src_path, "-O0", work_dir, "ref_o0")
            exe_o3 = build_executable(src_path, "-O3", work_dir, "prod_o3")
            exe_ai = build_executable(src_path, ai_strat, work_dir, "opt_ai")

            # Reference capture for output validation
            r_ref = subprocess.run([exe_o0], capture_output=True, text=True, timeout=10)
            ref_rc = r_ref.returncode
            ref_stdout = r_ref.stdout

            targets = [
                ("Paired Baseline (-O0)", exe_o0),
                ("Production Reference (-O3)", exe_o3),
                (f"AI Candidate ({ai_strat})", exe_ai),
            ]

            # 3. Execute alternating interleaved measurement (3 warmups, 5 measured runs)
            mresults = measure_interleaved(
                targets=targets,
                warmup_runs=3,
                measure_runs=5,
                timeout_s=10,
                expected_exit_code=ref_rc,
                expected_stdout=ref_stdout,
            )

            res_o0 = mresults["Paired Baseline (-O0)"]
            res_o3 = mresults["Production Reference (-O3)"]
            res_ai = mresults[f"AI Candidate ({ai_strat})"]

            t_o0_med = res_o0.timing.median_s if res_o0.timing else 0.0
            t_o3_med = res_o3.timing.median_s if res_o3.timing else 0.0
            t_ai_med = res_ai.timing.median_s if res_ai.timing else 0.0

            # Formulas:
            # Speedup = Normal Time / Optimized Time
            # Improvement % = ((Normal Time - Optimized Time) / Normal Time) * 100
            speedup_vs_o0 = (t_o0_med / t_ai_med) if t_ai_med > 0 else 1.0
            pct_vs_o0 = ((t_o0_med - t_ai_med) / t_o0_med * 100.0) if t_o0_med > 0 else 0.0

            speedup_vs_o3 = (t_o3_med / t_ai_med) if t_ai_med > 0 else 1.0
            pct_vs_o3 = ((t_o3_med - t_ai_med) / t_o3_med * 100.0) if t_o3_med > 0 else 0.0

            summary_item = {
                "category": cat,
                "name": pname,
                "ai_strategy": ai_strat,
                "baseline_o0": {
                    "raw_samples_ms": [round(s / 1e6, 3) for s in res_o0.raw_samples_ns],
                    "median_ms": round(t_o0_med * 1000, 3),
                    "mean_ms": round(res_o0.timing.mean_s * 1000, 3) if res_o0.timing else 0.0,
                    "min_ms": round(res_o0.timing.min_ns / 1e6, 3) if res_o0.timing else 0.0,
                    "max_ms": round(res_o0.timing.max_ns / 1e6, 3) if res_o0.timing else 0.0,
                    "stdev_ms": round(res_o0.timing.stdev_ns / 1e6, 3) if res_o0.timing else 0.0,
                    "cv_pct": round(res_o0.timing.cv * 100, 2) if res_o0.timing else 0.0,
                    "is_reliable": res_o0.timing_is_reliable,
                    "output_matches": res_o0.output_matches_reference,
                },
                "production_o3": {
                    "raw_samples_ms": [round(s / 1e6, 3) for s in res_o3.raw_samples_ns],
                    "median_ms": round(t_o3_med * 1000, 3),
                    "mean_ms": round(res_o3.timing.mean_s * 1000, 3) if res_o3.timing else 0.0,
                    "min_ms": round(res_o3.timing.min_ns / 1e6, 3) if res_o3.timing else 0.0,
                    "max_ms": round(res_o3.timing.max_ns / 1e6, 3) if res_o3.timing else 0.0,
                    "stdev_ms": round(res_o3.timing.stdev_ns / 1e6, 3) if res_o3.timing else 0.0,
                    "cv_pct": round(res_o3.timing.cv * 100, 2) if res_o3.timing else 0.0,
                    "is_reliable": res_o3.timing_is_reliable,
                    "output_matches": res_o3.output_matches_reference,
                },
                "ai_candidate": {
                    "raw_samples_ms": [round(s / 1e6, 3) for s in res_ai.raw_samples_ns],
                    "median_ms": round(t_ai_med * 1000, 3),
                    "mean_ms": round(res_ai.timing.mean_s * 1000, 3) if res_ai.timing else 0.0,
                    "min_ms": round(res_ai.timing.min_ns / 1e6, 3) if res_ai.timing else 0.0,
                    "max_ms": round(res_ai.timing.max_ns / 1e6, 3) if res_ai.timing else 0.0,
                    "stdev_ms": round(res_ai.timing.stdev_ns / 1e6, 3) if res_ai.timing else 0.0,
                    "cv_pct": round(res_ai.timing.cv * 100, 2) if res_ai.timing else 0.0,
                    "is_reliable": res_ai.timing_is_reliable,
                    "output_matches": res_ai.output_matches_reference,
                },
                "vs_o0": {
                    "speedup": round(speedup_vs_o0, 2),
                    "improvement_pct": round(pct_vs_o0, 1),
                    "verdict": "IMPROVED" if (speedup_vs_o0 >= 1.05 and res_o0.timing_is_reliable and res_ai.timing_is_reliable) else ("REGRESSED" if (speedup_vs_o0 <= 0.95 and res_o0.timing_is_reliable and res_ai.timing_is_reliable) else ("INCONCLUSIVE" if not (res_o0.timing_is_reliable and res_ai.timing_is_reliable) else "PARITY")),
                },
                "vs_o3": {
                    "speedup": round(speedup_vs_o3, 2),
                    "improvement_pct": round(pct_vs_o3, 1),
                    "verdict": "IMPROVED" if (speedup_vs_o3 >= 1.05 and res_o3.timing_is_reliable and res_ai.timing_is_reliable) else ("REGRESSED" if (speedup_vs_o3 <= 0.95 and res_o3.timing_is_reliable and res_ai.timing_is_reliable) else ("INCONCLUSIVE" if not (res_o3.timing_is_reliable and res_ai.timing_is_reliable) else "PARITY")),
                },
            }
            results_summary.append(summary_item)
            print(f"-O0 Baseline: Med={summary_item['baseline_o0']['median_ms']}ms, CV={summary_item['baseline_o0']['cv_pct']}%, Reliable={summary_item['baseline_o0']['is_reliable']}")
            print(f"-O3 Baseline: Med={summary_item['production_o3']['median_ms']}ms, CV={summary_item['production_o3']['cv_pct']}%, Reliable={summary_item['production_o3']['is_reliable']}")
            print(f"AI Candidate: Med={summary_item['ai_candidate']['median_ms']}ms, CV={summary_item['ai_candidate']['cv_pct']}%, Reliable={summary_item['ai_candidate']['is_reliable']}")
            print(f"AI vs -O0   : Speedup={summary_item['vs_o0']['speedup']}x, Improvement={summary_item['vs_o0']['improvement_pct']}%, Verdict={summary_item['vs_o0']['verdict']}")
            print(f"AI vs -O3   : Speedup={summary_item['vs_o3']['speedup']}x, Improvement={summary_item['vs_o3']['improvement_pct']}%, Verdict={summary_item['vs_o3']['verdict']}")

        out_json = os.path.join(os.path.dirname(__file__), "controlled_benchmark_results.json")
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(results_summary, f, indent=2)
        print(f"\nAll 4 experiments complete. Results saved to {out_json}")

    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)

if __name__ == "__main__":
    run_experiment()
