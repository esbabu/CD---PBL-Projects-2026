with open(r'compiler-optimization-selector-main\Codes\Python Scripts\web\static\index.html', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'accordion-xai' in line:
        for j in range(max(0, i-15), min(len(lines), i+15)):
            print(f"{j+1}: {lines[j]}", end="")
        break
