"""
run_all_tests_audit.py
Automated runner and tally script for the TOACD regression test suite.
Runs all Python unittest files and Node.js frontend test files.
Records exact command, exit code, test counts (run, passed, failed, errors, skipped).
"""
import os
import sys
import subprocess
import time
import json
import re

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INNER_REPO = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
MOO_DIR = os.path.join(INNER_REPO, "Codes", "Python Scripts")

PYTHON_UNITTEST_FILES = [
    "moo/tests/test_phase1_measurement_engine.py",
    "moo/tests/test_reliable_benchmarking.py",
    "moo/tests/test_phase2b_generalization.py",
    "moo/tests/test_phase0_events.py",
    "moo/tests/test_stage11_reviewer_context.py",
    "moo/tests/test_stage13_linucb.py",
    "moo/tests/test_stage13_pipeline_integration.py",
    "moo/tests/test_stage14_6_1_linucb_config.py",
    "moo/tests/test_stage14_6_2_integrity.py",
    "moo/tests/test_stage14_activity_integration.py",
    "moo/tests/test_stage14_backend_events.py",
    "moo/tests/test_stage15_1_integrity.py",
    "moo/tests/test_workflow_report.py",
    "web/tests/test_assistant.py",
]

PYTHON_PYTEST_FILES = [
    "moo/tests/test_phase2a_isolation_buildconfig.py",
    "moo/tests/test_phase2c_multifile.py",
    "moo/tests/test_stage12_security.py",
    "moo/tests/test_stage13_metric_integrity.py",
]

PYTHON_STANDALONE_FILES = [
    "moo/tests/test_week13a_security.py",
]

NODE_TEST_FILES = [
    "web/tests/test_phase2a_frontend.js",
    "web/tests/test_stage14_frontend.js",
    "web/tests/test_stage15_frontend.js",
    "web/tests/test_stage15_theme.js",
    "web/tests/test_stage15_xai.js",
    "web/tests/test_toast_system.js",
    "web/tests/test_workflow_progress.js",
    "web/tests/test_workflow_report_ui.js",
]

def run_pytest_suite(rel_path):
    cmd = [sys.executable, "-m", "pytest", "-q", rel_path.replace("/", os.sep)]
    t0 = time.time()
    proc = subprocess.run(cmd, cwd=MOO_DIR, capture_output=True, text=True)
    dur = time.time() - t0
    out = proc.stdout + "\n" + proc.stderr

    m_passed = re.search(r"(\d+) passed", out)
    m_failed = re.search(r"(\d+) failed", out)
    m_errors = re.search(r"(\d+) errors?", out)
    m_skipped = re.search(r"(\d+) skipped", out)

    n_pass = int(m_passed.group(1)) if m_passed else 0
    n_fail = int(m_failed.group(1)) if m_failed else 0
    n_err = int(m_errors.group(1)) if m_errors else 0
    n_skip = int(m_skipped.group(1)) if m_skipped else 0
    n_ran = n_pass + n_fail + n_err + n_skip

    return {
        "file": rel_path,
        "type": "pytest",
        "command": " ".join(cmd),
        "exit_code": proc.returncode,
        "duration_s": round(dur, 2),
        "ran": n_ran,
        "passed": n_pass,
        "failed": n_fail,
        "errors": n_err,
        "skipped": n_skip,
        "raw_output": out[-500:],
    }

def run_standalone_suite(rel_path):
    cmd = [sys.executable, rel_path.replace("/", os.sep)]
    t0 = time.time()
    proc = subprocess.run(cmd, cwd=MOO_DIR, capture_output=True, text=True)
    dur = time.time() - t0
    out = proc.stdout + "\n" + proc.stderr

    # Pattern: Results: X/X passed, Y failed
    m_res = re.search(r"Results:\s*(\d+)/(\d+)\s+passed,\s*(\d+)\s+failed", out)
    if m_res:
        n_pass = int(m_res.group(1))
        n_ran = int(m_res.group(2))
        n_fail = int(m_res.group(3))
    else:
        n_pass = len(re.findall(r"\[PASS\]", out))
        n_fail = len(re.findall(r"\[FAIL\]", out))
        n_ran = n_pass + n_fail

    return {
        "file": rel_path,
        "type": "standalone_python",
        "command": " ".join(cmd),
        "exit_code": proc.returncode,
        "duration_s": round(dur, 2),
        "ran": n_ran,
        "passed": n_pass,
        "failed": n_fail,
        "errors": 0,
        "skipped": 0,
        "raw_output": out[-500:],
    }

def run_python_suite(rel_path):
    cmd = [sys.executable, "-m", "unittest", rel_path.replace("/", os.sep)]
    t0 = time.time()
    proc = subprocess.run(cmd, cwd=MOO_DIR, capture_output=True, text=True)
    dur = time.time() - t0
    
    out = proc.stdout + "\n" + proc.stderr
    # Parse unittest output: "Ran X tests in Ys"
    m_ran = re.search(r"Ran (\d+) tests? in", out)
    n_ran = int(m_ran.group(1)) if m_ran else 0
    
    # Check OK or FAILED
    m_fail = re.search(r"FAILED \((?:failures=(\d+))?(?:, )?(?:errors=(\d+))?(?:, )?(?:skipped=(\d+))?\)", out)
    if m_fail:
        n_fail = int(m_fail.group(1) or 0)
        n_err = int(m_fail.group(2) or 0)
        n_skip = int(m_fail.group(3) or 0)
        n_pass = n_ran - n_fail - n_err - n_skip
    elif "OK" in out:
        m_skip = re.search(r"OK \(skipped=(\d+)\)", out)
        n_skip = int(m_skip.group(1)) if m_skip else 0
        n_fail = 0
        n_err = 0
        n_pass = n_ran - n_skip
    else:
        n_fail = 1 if proc.returncode != 0 else 0
        n_err = 0
        n_skip = 0
        n_pass = max(0, n_ran - n_fail)

    return {
        "file": rel_path,
        "type": "python_unittest",
        "command": " ".join(cmd),
        "exit_code": proc.returncode,
        "duration_s": round(dur, 2),
        "ran": n_ran,
        "passed": n_pass,
        "failed": n_fail,
        "errors": n_err,
        "skipped": n_skip,
        "raw_output": out[-500:],
    }

def run_node_suite(rel_path):
    cmd = ["node", rel_path.replace("/", os.sep)]
    t0 = time.time()
    try:
        proc = subprocess.run(cmd, cwd=MOO_DIR, capture_output=True, text=True, timeout=30)
        dur = time.time() - t0
        out = proc.stdout + "\n" + proc.stderr
        
        # Look for pass / assert patterns in stdout
        # e.g., "All X assertions passed" or counting passes
        m_pass = re.findall(r"PASS|passed|ok|Assertion passed", out, re.IGNORECASE)
        n_ran = max(1, len(m_pass)) if proc.returncode == 0 else 1
        n_failed = 0 if proc.returncode == 0 else 1
        n_passed = n_ran if proc.returncode == 0 else 0
        
        return {
            "file": rel_path,
            "type": "node_js",
            "command": " ".join(cmd),
            "exit_code": proc.returncode,
            "duration_s": round(dur, 2),
            "ran": n_ran,
            "passed": n_passed,
            "failed": n_failed,
            "errors": 0,
            "skipped": 0,
            "raw_output": out[-500:],
        }
    except Exception as exc:
        return {
            "file": rel_path,
            "type": "node_js",
            "command": " ".join(cmd),
            "exit_code": -1,
            "duration_s": 0.0,
            "ran": 0,
            "passed": 0,
            "failed": 1,
            "errors": 1,
            "skipped": 0,
            "raw_output": str(exc),
        }

def main():
    print("Executing TOACD Master Regression Test Audit...")
    results = []
    
    print("\n--- Python Unittest Suites ---")
    for py_file in PYTHON_UNITTEST_FILES:
        full_p = os.path.join(MOO_DIR, py_file)
        if not os.path.isfile(full_p):
            print(f"File not found: {py_file} -> skipping")
            continue
        res = run_python_suite(py_file)
        results.append(res)
        status_str = "PASS" if res["exit_code"] == 0 and res["failed"] == 0 and res["errors"] == 0 else "FAIL"
        print(f"[{status_str:4s}] {py_file:45s} | Ran: {res['ran']:2d} | Passed: {res['passed']:2d} | Failed: {res['failed']:2d} | Errors: {res['errors']:2d} | ({res['duration_s']}s)")

    print("\n--- Python Pytest Suites ---")
    for py_file in PYTHON_PYTEST_FILES:
        full_p = os.path.join(MOO_DIR, py_file)
        if not os.path.isfile(full_p):
            print(f"File not found: {py_file} -> skipping")
            continue
        res = run_pytest_suite(py_file)
        results.append(res)
        status_str = "PASS" if res["exit_code"] == 0 and res["failed"] == 0 and res["errors"] == 0 else "FAIL"
        print(f"[{status_str:4s}] {py_file:45s} | Ran: {res['ran']:2d} | Passed: {res['passed']:2d} | Failed: {res['failed']:2d} | Errors: {res['errors']:2d} | ({res['duration_s']}s)")

    print("\n--- Python Standalone Suites ---")
    for py_file in PYTHON_STANDALONE_FILES:
        full_p = os.path.join(MOO_DIR, py_file)
        if not os.path.isfile(full_p):
            print(f"File not found: {py_file} -> skipping")
            continue
        res = run_standalone_suite(py_file)
        results.append(res)
        status_str = "PASS" if res["exit_code"] == 0 and res["failed"] == 0 and res["errors"] == 0 else "FAIL"
        print(f"[{status_str:4s}] {py_file:45s} | Ran: {res['ran']:2d} | Passed: {res['passed']:2d} | Failed: {res['failed']:2d} | Errors: {res['errors']:2d} | ({res['duration_s']}s)")

    print("\n--- Node.js Frontend Suites ---")
    for js_file in NODE_TEST_FILES:
        full_j = os.path.join(MOO_DIR, js_file)
        if not os.path.isfile(full_j):
            print(f"File not found: {js_file} -> skipping")
            continue
        res = run_node_suite(js_file)
        results.append(res)
        status_str = "PASS" if res["exit_code"] == 0 else "FAIL"
        print(f"[{status_str:4s}] {js_file:45s} | Exit: {res['exit_code']:2d} | Ran: {res['ran']:2d} | Passed: {res['passed']:2d} | ({res['duration_s']}s)")

    total_ran = sum(r["ran"] for r in results)
    total_passed = sum(r["passed"] for r in results)
    total_failed = sum(r["failed"] for r in results)
    total_errors = sum(r["errors"] for r in results)
    total_skipped = sum(r["skipped"] for r in results)

    print("\n=======================================================")
    print("REGRESSION TEST AUDIT SUMMARY:")
    print(f"Total Suites Run:   {len(results)}")
    print(f"Total Tests Run:    {total_ran}")
    print(f"Total Passed:       {total_passed}")
    print(f"Total Failed:       {total_failed}")
    print(f"Total Errors:       {total_errors}")
    print(f"Total Skipped:      {total_skipped}")
    print("=======================================================")

    out_file = os.path.join(SCRIPT_DIR, "regression_audit_results.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "summary": {
                "suites_count": len(results),
                "total_ran": total_ran,
                "total_passed": total_passed,
                "total_failed": total_failed,
                "total_errors": total_errors,
                "total_skipped": total_skipped,
            },
            "suites": results,
        }, f, indent=2)
    print(f"Saved audit log to: {out_file}")

if __name__ == "__main__":
    main()
