app = open(r'compiler-optimization-selector-main\Codes\Python Scripts\web\static\app.js', encoding='utf-8').read()
lines = app.split('\n')
for i, l in enumerate(lines):
    if 'toastmanager =' in l.lower() or 'class toast' in l.lower():
        print(f"{i+1}: {l}")
        for j in range(max(0, i-5), min(len(lines), i+30)):
            print(f"  {j+1}: {lines[j]}")
        break
