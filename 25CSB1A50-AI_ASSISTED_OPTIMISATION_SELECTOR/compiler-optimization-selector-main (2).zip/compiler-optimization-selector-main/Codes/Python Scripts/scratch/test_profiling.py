import sys, os, time
sys.path.insert(0, os.path.abspath('Codes/Python Scripts'))
from web.service import execute_run_task, _RUNS_STORE, DEFAULT_SOURCE_CODE

# Read a test benchmark like nested_loops or TC1_loop_heavy
benchmark_path = os.path.abspath('Codes/test_cases/nested_loops.c')
if os.path.exists(benchmark_path):
    with open(benchmark_path, 'r') as f:
        code = f.read()
else:
    code = DEFAULT_SOURCE_CODE

print(f"Loaded code length: {len(code)}")

for i in range(1, 4):
    print(f"\n================ ITERATION {i} ================")
    # 1. Normal run
    t0 = time.time()
    run_id_norm = f"test_norm_{i}"
    execute_run_task(run_id_norm, code, mode='normal')
    t_norm = time.time() - t0
    view_norm = _RUNS_STORE[run_id_norm]['view']
    opt_timing_norm = view_norm.get('optimized_timing') or {}
    med_norm = (opt_timing_norm.get('median_s') or 0.0) * 1000.0
    samples_norm = opt_timing_norm.get('samples_ms')
    cpu_norm = opt_timing_norm.get('cpu_median_ms')
    res_norm = opt_timing_norm.get('residual_median_ms')
    print(f"[Normal {i}] Pipeline Total: {t_norm:.2f}s | Benchmark Wall: {med_norm:.3f} ms | CPU: {cpu_norm} ms | Residual: {res_norm} ms | Samples: {samples_norm}")

    # 2. AI run (DQN)
    t0 = time.time()
    run_id_ai = f"test_ai_{i}"
    execute_run_task(run_id_ai, code, mode='ai', model_family='dqn')
    t_ai = time.time() - t0
    view_ai = _RUNS_STORE[run_id_ai]['view']
    opt_timing_ai = view_ai.get('optimized_timing') or {}
    med_ai = (opt_timing_ai.get('median_s') or 0.0) * 1000.0
    samples_ai = opt_timing_ai.get('samples_ms')
    cpu_ai = opt_timing_ai.get('cpu_median_ms')
    res_ai = opt_timing_ai.get('residual_median_ms')
    print(f"[AI DQN {i}] Pipeline Total: {t_ai:.2f}s | Benchmark Wall: {med_ai:.3f} ms | CPU: {cpu_ai} ms | Residual: {res_ai} ms | Samples: {samples_ai}")
