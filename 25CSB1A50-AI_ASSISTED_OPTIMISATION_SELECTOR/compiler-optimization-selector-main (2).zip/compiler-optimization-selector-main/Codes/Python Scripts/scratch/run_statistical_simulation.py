"""
Codes/Python Scripts/scratch/run_statistical_simulation.py
Statistical Simulation Framework evaluating Estimators, Bootstrap CIs,
and the v3.5 Ordered Decision Classifier.
"""

from __future__ import annotations

import json
import math
import random
import sys
import numpy as np
from typing import Dict, List, Tuple, Any

# Ensure reproducible simulation
np.random.seed(42)
random.seed(42)


# ---------------------------------------------------------------------------
# 1. Point Estimators
# ---------------------------------------------------------------------------

def sample_median(x: np.ndarray) -> float:
    return float(np.median(x))


def trimmed_mean(x: np.ndarray, proportion: float = 0.10) -> float:
    n = len(x)
    k = int(n * proportion)
    if k == 0:
        return float(np.mean(x))
    sx = np.sort(x)
    return float(np.mean(sx[k:n - k]))


def hodges_lehmann(x: np.ndarray) -> float:
    """Walsh averages median: median_{(i <= j)} (x_i + x_j) / 2."""
    n = len(x)
    walsh = []
    for i in range(n):
        for j in range(i, n):
            walsh.append((x[i] + x[j]) / 2.0)
    return float(np.median(walsh))


def paired_speedup_hl(base: np.ndarray, cand: np.ndarray) -> float:
    """Hodges-Lehmann estimator on paired speedup ratios base_i / cand_i."""
    ratios = base / cand
    return hodges_lehmann(ratios)


# ---------------------------------------------------------------------------
# 2. Bootstrap Confidence Interval Methods
# ---------------------------------------------------------------------------

def bootstrap_percentile_ci(
    data: np.ndarray,
    stat_fn=sample_median,
    n_resamples: int = 1000,
    alpha: float = 0.05
) -> Tuple[float, float]:
    n = len(data)
    boot_stats = np.empty(n_resamples)
    for b in range(n_resamples):
        idx = np.random.randint(0, n, size=n)
        boot_stats[b] = stat_fn(data[idx])
    lo = float(np.percentile(boot_stats, 100 * (alpha / 2.0)))
    hi = float(np.percentile(boot_stats, 100 * (1.0 - alpha / 2.0)))
    return lo, hi


def bootstrap_bca_ci(
    data: np.ndarray,
    stat_fn=sample_median,
    n_resamples: int = 1000,
    alpha: float = 0.05
) -> Tuple[float, float]:
    """
    Bias-Corrected and Accelerated (BCa) bootstrap confidence interval.
    """
    from scipy.stats import norm

    n = len(data)
    orig_stat = stat_fn(data)
    boot_stats = np.empty(n_resamples)
    for b in range(n_resamples):
        idx = np.random.randint(0, n, size=n)
        boot_stats[b] = stat_fn(data[idx])

    # Bias correction parameter z0
    prop_less = np.mean(boot_stats < orig_stat)
    prop_less = max(1e-6, min(1.0 - 1e-6, prop_less))
    z0 = norm.ppf(prop_less)

    # Acceleration parameter a via jackknife
    jack = np.empty(n)
    for i in range(n):
        sub = np.delete(data, i)
        jack[i] = stat_fn(sub)
    jack_mean = np.mean(jack)
    num = np.sum((jack_mean - jack) ** 3)
    denom = 6.0 * (np.sum((jack_mean - jack) ** 2) ** 1.5)
    a = num / denom if denom != 0 else 0.0

    # Adjusted percentiles
    z_lo = norm.ppf(alpha / 2.0)
    z_hi = norm.ppf(1.0 - alpha / 2.0)

    a1 = norm.cdf(z0 + (z0 + z_lo) / (1.0 - a * (z0 + z_lo)))
    a2 = norm.cdf(z0 + (z0 + z_hi) / (1.0 - a * (z0 + z_hi)))

    a1 = max(0.001, min(0.999, a1))
    a2 = max(0.001, min(0.999, a2))

    lo = float(np.percentile(boot_stats, 100 * a1))
    hi = float(np.percentile(boot_stats, 100 * a2))
    return lo, hi


# ---------------------------------------------------------------------------
# 3. v3.5 §17.2 Ordered Statistical Decision Procedure
# ---------------------------------------------------------------------------

class DecisionVerdict:
    SIGNIFICANT_SPEEDUP = "SIGNIFICANT_SPEEDUP"
    PRACTICAL_SPEEDUP = "PRACTICAL_SPEEDUP"
    EQUIVALENT = "EQUIVALENT"
    INCONCLUSIVE = "INCONCLUSIVE"
    PRACTICAL_SLOWDOWN = "PRACTICAL_SLOWDOWN"
    SIGNIFICANT_SLOWDOWN = "SIGNIFICANT_SLOWDOWN"


def classify_speedup_v35(
    speedup: float,
    ci_lo: float,
    ci_hi: float,
    cv_base: float,
    cv_cand: float,
    delta: float = 0.05,
    cv_threshold: float = 0.10,
    max_ci_width: float = 0.20,
) -> str:
    """
    v3.5 §17.2 Ordered Decision Logic.
    Separates effect size and direction from dispersion and statistical uncertainty.
    """
    # High variance check
    if cv_base > cv_threshold or cv_cand > cv_threshold:
        return DecisionVerdict.INCONCLUSIVE

    # Wide confidence interval check
    if (ci_hi - ci_lo) > max_ci_width:
        return DecisionVerdict.INCONCLUSIVE

    # Equivalence region [1 - delta, 1 + delta]
    eq_lo = 1.0 - delta
    eq_hi = 1.0 + delta

    # 1. Significant Speedup: point speedup >= 1 + delta, and CI strictly above 1.0
    if speedup >= eq_hi and ci_lo > 1.0:
        return DecisionVerdict.SIGNIFICANT_SPEEDUP

    # 2. Significant Slowdown: point speedup <= 1 - delta, and CI strictly below 1.0
    if speedup <= eq_lo and ci_hi < 1.0:
        return DecisionVerdict.SIGNIFICANT_SLOWDOWN

    # 3. Practical Speedup: speedup > 1.0, CI strictly above 1.0, but speedup < 1 + delta
    if speedup > 1.0 and ci_lo > 1.0:
        return DecisionVerdict.PRACTICAL_SPEEDUP

    # 4. Practical Slowdown: speedup < 1.0, CI strictly below 1.0, but speedup > 1 - delta
    if speedup < 1.0 and ci_hi < 1.0:
        return DecisionVerdict.PRACTICAL_SLOWDOWN

    # 5. Practical Equivalence: CI strictly contained in [1 - delta, 1 + delta]
    if ci_lo >= eq_lo and ci_hi <= eq_hi:
        return DecisionVerdict.EQUIVALENT

    # 6. CI straddles 1.0 or boundary without satisfying equivalence
    return DecisionVerdict.INCONCLUSIVE


# ---------------------------------------------------------------------------
# 4. Simulation Experiments
# ---------------------------------------------------------------------------

def run_estimator_comparison(n_trials: int = 500, sample_size: int = 15) -> Dict[str, Any]:
    """Compare Median, 10% Trimmed Mean, and Hodges-Lehmann across 5 distributions."""
    distributions = {
        "Gaussian": lambda n: np.random.normal(loc=100.0, scale=5.0, size=n),
        "Lognormal (right-skewed)": lambda n: np.random.lognormal(mean=4.6, sigma=0.1, size=n),
        "Bimodal (cache effects)": lambda n: np.where(np.random.rand(n) < 0.7,
                                                      np.random.normal(95.0, 2.0, n),
                                                      np.random.normal(115.0, 3.0, n)),
        "Heavy-Tailed (Student-t df=3)": lambda n: 100.0 + 4.0 * np.random.standard_t(df=3, size=n),
        "Contaminated (10% outliers)": lambda n: np.where(np.random.rand(n) < 0.9,
                                                          np.random.normal(100.0, 3.0, n),
                                                          np.random.normal(180.0, 25.0, n)),
    }

    results = {}
    for dist_name, gen_fn in distributions.items():
        # Large sample ground truth median
        ground_truth = float(np.median(gen_fn(50000)))

        med_errors = []
        trim_errors = []
        hl_errors = []

        for _ in range(n_trials):
            sample = gen_fn(sample_size)
            m = sample_median(sample)
            t = trimmed_mean(sample, 0.10)
            h = hodges_lehmann(sample)

            med_errors.append(m - ground_truth)
            trim_errors.append(t - ground_truth)
            hl_errors.append(h - ground_truth)

        results[dist_name] = {
            "ground_truth": ground_truth,
            "sample_median": {
                "bias": float(np.mean(med_errors)),
                "variance": float(np.var(med_errors)),
                "rmse": float(np.sqrt(np.mean(np.array(med_errors) ** 2))),
            },
            "trimmed_mean": {
                "bias": float(np.mean(trim_errors)),
                "variance": float(np.var(trim_errors)),
                "rmse": float(np.sqrt(np.mean(np.array(trim_errors) ** 2))),
            },
            "hodges_lehmann": {
                "bias": float(np.mean(hl_errors)),
                "variance": float(np.var(hl_errors)),
                "rmse": float(np.sqrt(np.mean(np.array(hl_errors) ** 2))),
            },
        }
    return results


def run_bootstrap_coverage_experiment(n_trials: int = 300, sample_size: int = 20) -> Dict[str, Any]:
    """Evaluate empirical coverage of Percentile vs BCa bootstrap CIs at 95% nominal level."""
    from scipy.stats import norm

    dists = {
        "Gaussian": lambda n: np.random.normal(100.0, 5.0, n),
        "Lognormal (skewed)": lambda n: np.random.lognormal(4.6, 0.15, n),
        "Contaminated (5% outliers)": lambda n: np.where(np.random.rand(n) < 0.95,
                                                         np.random.normal(100.0, 4.0, n),
                                                         np.random.normal(160.0, 20.0, n)),
    }

    results = {}
    for name, gen_fn in dists.items():
        pop = gen_fn(50000)
        true_med = float(np.median(pop))

        pct_hits = 0
        bca_hits = 0
        widths_pct = []
        widths_bca = []

        for _ in range(n_trials):
            sample = gen_fn(sample_size)
            # Percentile
            lo_p, hi_p = bootstrap_percentile_ci(sample, stat_fn=sample_median, n_resamples=500)
            if lo_p <= true_med <= hi_p:
                pct_hits += 1
            widths_pct.append(hi_p - lo_p)

            # BCa
            lo_b, hi_b = bootstrap_bca_ci(sample, stat_fn=sample_median, n_resamples=500)
            if lo_b <= true_med <= hi_b:
                bca_hits += 1
            widths_bca.append(hi_b - lo_b)

        results[name] = {
            "true_median": true_med,
            "nominal_coverage": 0.95,
            "percentile_coverage": pct_hits / n_trials,
            "percentile_mean_width": float(np.mean(widths_pct)),
            "bca_coverage": bca_hits / n_trials,
            "bca_mean_width": float(np.mean(widths_bca)),
        }
    return results


def run_classifier_validation() -> Dict[str, Any]:
    """Test v3.5 §17.2 decision classifier across distinct test scenarios."""
    scenarios = [
        # (name, speedup, lo, hi, cv_base, cv_cand, expected)
        ("Clear 30% speedup, tight CI", 1.30, 1.25, 1.35, 0.03, 0.03, DecisionVerdict.SIGNIFICANT_SPEEDUP),
        ("Marginal 3% speedup, CI excludes 1.0", 1.03, 1.01, 1.05, 0.02, 0.02, DecisionVerdict.PRACTICAL_SPEEDUP),
        ("Clear 25% slowdown, tight CI", 0.75, 0.70, 0.80, 0.03, 0.03, DecisionVerdict.SIGNIFICANT_SLOWDOWN),
        ("Marginal 3% slowdown, CI excludes 1.0", 0.97, 0.95, 0.99, 0.02, 0.02, DecisionVerdict.PRACTICAL_SLOWDOWN),
        ("Near identical, tight CI inside [0.95, 1.05]", 1.002, 0.985, 1.018, 0.02, 0.02, DecisionVerdict.EQUIVALENT),
        ("Near identical but wide CI spanning 1.0", 1.01, 0.91, 1.12, 0.04, 0.04, DecisionVerdict.INCONCLUSIVE),
        ("High variance baseline (CV=14%)", 1.25, 1.15, 1.35, 0.14, 0.04, DecisionVerdict.INCONCLUSIVE),
        ("Wide CI (width = 0.25 > 0.20)", 1.20, 1.05, 1.30, 0.05, 0.05, DecisionVerdict.INCONCLUSIVE),
    ]

    outcomes = []
    all_matched = True
    for name, sp, lo, hi, cv_b, cv_c, expected in scenarios:
        actual = classify_speedup_v35(sp, lo, hi, cv_b, cv_c)
        match = (actual == expected)
        if not match:
            all_matched = False
        outcomes.append({
            "scenario": name,
            "speedup": sp,
            "ci": [lo, hi],
            "cv": [cv_b, cv_c],
            "expected": expected,
            "actual": actual,
            "correct": match,
        })

    return {
        "all_scenarios_passed": all_matched,
        "scenarios": outcomes,
    }


def run_drift_and_autocorrelation_experiment(n_trials: int = 300, n_runs: int = 15) -> Dict[str, Any]:
    """
    Evaluate Interleaved (AB/BA) vs Sequential (A...A B...B) execution under:
    - Linear environmental / thermal drift (+10% slowdown over run sequence)
    - Autoregressive noise AR(1) with rho = 0.3 and rho = 0.6
    - Heteroscedastic unequal variance (sigma_cand != sigma_base)
    """
    true_base = 100.0
    true_cand = 80.0
    true_speedup = true_base / true_cand  # 1.25

    drift_results = {}

    # Scenario 1: Linear Thermal Drift (+10% drift over 30 total executions)
    seq_biases = []
    inter_biases = []
    for _ in range(n_trials):
        drift_slope = 0.10 / (2 * n_runs)
        # Sequential: all A runs then all B runs
        # A runs experience drift 0 to n_runs * slope
        # B runs experience drift n_runs * slope to 2 * n_runs * slope
        base_seq = np.array([true_base * (1.0 + i * drift_slope) + np.random.normal(0, 2.0) for i in range(n_runs)])
        cand_seq = np.array([true_cand * (1.0 + (n_runs + i) * drift_slope) + np.random.normal(0, 2.0) for i in range(n_runs)])
        sp_seq = sample_median(base_seq) / sample_median(cand_seq)
        seq_biases.append(sp_seq - true_speedup)

        # Interleaved AB/BA: run order alternates
        # Pairs: run 2*i is A, 2*i+1 is B (or vice versa)
        base_inter = []
        cand_inter = []
        for i in range(n_runs):
            t_base_order = 2 * i if i % 2 == 0 else 2 * i + 1
            t_cand_order = 2 * i + 1 if i % 2 == 0 else 2 * i
            base_inter.append(true_base * (1.0 + t_base_order * drift_slope) + np.random.normal(0, 2.0))
            cand_inter.append(true_cand * (1.0 + t_cand_order * drift_slope) + np.random.normal(0, 2.0))
        sp_inter = sample_median(np.array(base_inter)) / sample_median(np.array(cand_inter))
        inter_biases.append(sp_inter - true_speedup)

    drift_results["linear_drift_10pct"] = {
        "true_speedup": true_speedup,
        "sequential_mean_bias": float(np.mean(seq_biases)),
        "sequential_rmse": float(np.sqrt(np.mean(np.array(seq_biases) ** 2))),
        "interleaved_mean_bias": float(np.mean(inter_biases)),
        "interleaved_rmse": float(np.sqrt(np.mean(np.array(inter_biases) ** 2))),
        "bias_reduction_pct": float((1.0 - abs(np.mean(inter_biases)) / abs(np.mean(seq_biases))) * 100.0),
    }

    # Scenario 2: Autoregressive Noise AR(1) with rho = 0.3 and rho = 0.6
    for rho in [0.3, 0.6]:
        ar_errors = []
        for _ in range(n_trials):
            # Generate AR(1) series of length n_runs
            noise = np.zeros(n_runs)
            white = np.random.normal(0, 2.0, n_runs)
            noise[0] = white[0]
            for t in range(1, n_runs):
                noise[t] = rho * noise[t - 1] + white[t]
            sample = true_base + noise
            ar_errors.append(sample_median(sample) - true_base)

        drift_results[f"ar1_rho_{rho}"] = {
            "rho": rho,
            "median_rmse": float(np.sqrt(np.mean(np.array(ar_errors) ** 2))),
            "median_variance": float(np.var(ar_errors)),
        }

    # Scenario 3: Heteroscedastic Unequal Variance (base sigma=2.0, cand sigma=8.0)
    het_biases = []
    het_ci_coverages = []
    for _ in range(n_trials):
        base_het = np.random.normal(true_base, 2.0, n_runs)
        cand_het = np.random.normal(true_cand, 8.0, n_runs)
        sp_est = sample_median(base_het) / sample_median(cand_het)
        het_biases.append(sp_est - true_speedup)
        # Ratio bootstrap CI
        ratios = base_het / cand_het
        lo, hi = bootstrap_percentile_ci(ratios, sample_median, n_resamples=300)
        het_ci_coverages.append(1 if lo <= true_speedup <= hi else 0)

    drift_results["heteroscedastic_unequal_variance"] = {
        "base_std": 2.0,
        "cand_std": 8.0,
        "speedup_rmse": float(np.sqrt(np.mean(np.array(het_biases) ** 2))),
        "bootstrap_ci_coverage": float(np.mean(het_ci_coverages)),
    }

    return drift_results


def main():
    print("Running v3.5 §17.8 Statistical Simulation Suite...")
    print("1. Point Estimator MSE & Bias Evaluation (500 trials)...")
    est_results = run_estimator_comparison(n_trials=500, sample_size=15)

    print("2. Bootstrap Confidence Interval Coverage (300 trials)...")
    boot_results = run_bootstrap_coverage_experiment(n_trials=300, sample_size=20)

    print("3. Ordered Decision Classifier Validation...")
    class_results = run_classifier_validation()

    print("4. Environmental Drift, Autocorrelation & Heteroscedastic Noise Experiment...")
    drift_results = run_drift_and_autocorrelation_experiment(n_trials=300, n_runs=15)

    final_payload = {
        "estimator_comparison": est_results,
        "bootstrap_coverage": boot_results,
        "classifier_validation": class_results,
        "drift_and_autocorrelation": drift_results,
    }

    out_path = "Codes/Python Scripts/scratch/statistical_simulation_results.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(final_payload, f, indent=2)

    print(f"Simulation completed successfully. Output saved to {out_path}.")
    print("\nSummary Results:")
    print("---------------------------------------------------------------------")
    print(f"Classifier Validation: {'PASS (100% Correct)' if class_results['all_scenarios_passed'] else 'FAIL'}")
    print("\nEstimator RMSE across distributions:")
    for dist, data in est_results.items():
        print(f"  {dist:30s} -> Med: {data['sample_median']['rmse']:.3f} | Trim: {data['trimmed_mean']['rmse']:.3f} | HL: {data['hodges_lehmann']['rmse']:.3f}")

    print("\nBootstrap 95% CI Coverage:")
    for dist, data in boot_results.items():
        print(f"  {dist:30s} -> Percentile: {data['percentile_coverage']*100:.1f}% (w={data['percentile_mean_width']:.2f}) | BCa: {data['bca_coverage']*100:.1f}% (w={data['bca_mean_width']:.2f})")


if __name__ == "__main__":
    main()
