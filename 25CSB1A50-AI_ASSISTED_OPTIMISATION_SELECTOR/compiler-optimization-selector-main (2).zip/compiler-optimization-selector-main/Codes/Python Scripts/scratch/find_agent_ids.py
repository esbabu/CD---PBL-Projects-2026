import re
with open(r'compiler-optimization-selector-main\Codes\Python Scripts\web\static\index.html', encoding='utf-8') as f:
    html = f.read()

ids = re.findall(r'id=["\']([^"\']+)["\']', html)
for i in ids:
    if any(k in i.lower() for k in ['agent', 'message', 'activity', 'narrative', 'checklist']):
        print(i)
