import urllib.request, json, time

with urllib.request.urlopen('http://127.0.0.1:8000/api/samples') as r:
    data = json.loads(r.read().decode())
samples = data.get('samples', [])

print(f"Total samples: {len(samples)}")
for item in samples:
    sid = item['id']
    with urllib.request.urlopen(f'http://127.0.0.1:8000/api/sample/{sid}') as r:
        sdata = json.loads(r.read().decode())
    code = sdata.get('source_code', '')
    if not code: continue

    t0 = time.time()
    req = urllib.request.Request(
        'http://127.0.0.1:8000/api/run',
        data=json.dumps({'mode': 'normal', 'program_id': sid, 'source_code': code}).encode(),
        headers={'Content-Type': 'application/json'}
    )
    with urllib.request.urlopen(req) as r:
        rid = json.loads(r.read().decode())['run_id']
    while True:
        time.sleep(0.3)
        with urllib.request.urlopen(f'http://127.0.0.1:8000/api/results/{rid}') as r:
            res = json.loads(r.read().decode())
            if res.get('status') in ('completed', 'failed', 'blocked'):
                dur = time.time() - t0
                med = (res.get('view', {}).get('optimized_timing', {}).get('median_s') or 0) * 1000
                print(f"Sample {sid:25s}: Normal total = {dur:.2f}s | Wall median = {med:.2f} ms")
                break
