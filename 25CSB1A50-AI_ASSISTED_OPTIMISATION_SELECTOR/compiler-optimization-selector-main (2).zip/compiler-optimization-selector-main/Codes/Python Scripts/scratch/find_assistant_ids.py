import re
html = open(r"compiler-optimization-selector-main\Codes\Python Scripts\web\static\index.html", encoding="utf-8").read()
ids = re.findall(r'id=["\']([^"\']+)["\']', html)
for i in ids:
    if 'assistant' in i.lower():
        print(i)
