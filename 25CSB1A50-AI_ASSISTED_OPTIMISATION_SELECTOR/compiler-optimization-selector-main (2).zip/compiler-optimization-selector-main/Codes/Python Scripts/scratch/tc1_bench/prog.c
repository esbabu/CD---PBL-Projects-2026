
#include <stdio.h>
void sink(int x);
int main(void) {
    int arr[512];
    int sum = 0;
    for (int iter = 0; iter < 20000; iter++) {
        for (int i = 0; i < 512; i++) {
            arr[i] = (i * 31) ^ (i >> 3);
        }
        for (int i = 0; i < 512; i++) {
            sum += arr[i] * (i % 7 + 1);
        }
    }
    sink(sum);
    printf("sum = %d\n", sum);
    return 0;
}
__attribute__((noinline)) void sink(int x) { (void)x; }
