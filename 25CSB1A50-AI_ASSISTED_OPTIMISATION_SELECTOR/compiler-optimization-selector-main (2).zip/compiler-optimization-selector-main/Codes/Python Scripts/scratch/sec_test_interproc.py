import os, sys, tempfile, shutil

_scripts_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from moo.project import CProject
from moo.security.ir_artifacts import emit_baseline_ir, emit_candidate_ir
from moo.security.candidate import evaluate_candidate_security
from moo.security.gate import OptimizationSecurityGate, GateDecision
from moo.security.sinks import analyze_module_sinks

workdir = tempfile.mkdtemp(prefix="sec_interproc_test_")
print(f"Testing in {workdir}")

try:
    # -------------------------------------------------------------
    # Case 1: Function defined in one .c and called from another (Benign)
    # -------------------------------------------------------------
    files_1 = {
        "helper.h": "int add(int a, int b);\n",
        "helper.c": '#include "helper.h"\nint add(int a, int b) { return a + b; }\n',
        "main.c": '#include <stdio.h>\n#include "helper.h"\nint main(void) { printf("%d\\n", add(1, 2)); return 0; }\n'
    }
    p1 = CProject.from_files_dict(files_1, target_dir=os.path.join(workdir, "case1"))
    base_ir_1, err_b1 = emit_baseline_ir(p1, os.path.join(workdir, "case1_base"))
    cand_ir_1, err_c1 = emit_candidate_ir("-O2", p1, os.path.join(workdir, "case1_cand"))
    sec_1 = evaluate_candidate_security("-O2", base_ir_1, cand_ir_1)
    gate_1, _, _ = OptimizationSecurityGate().evaluate_gate_decision(sec_1)
    print("Case 1 (Benign cross-file call):")
    print(f"  CandidateVerdict: {sec_1.verdict.value}")
    print(f"  GateDecision: {gate_1.value}")
    print(f"  Base sinks: {sec_1.baseline_sink_count}, Cand sinks: {sec_1.candidate_sink_count}")

    # -------------------------------------------------------------
    # Case 2: Security-sensitive sink in separate TU (abort in helper)
    # -------------------------------------------------------------
    files_2 = {
        "helper.h": "void trigger_sink(int condition);\n",
        "helper.c": """
#include <stdlib.h>
#include "helper.h"
void trigger_sink(int condition) {
    if (condition) {
        abort();
    }
}
""",
        "main.c": """
#include "helper.h"
int main(void) {
    trigger_sink(0);
    return 0;
}
"""
    }
    p2 = CProject.from_files_dict(files_2, target_dir=os.path.join(workdir, "case2"))
    base_ir_2, err_b2 = emit_baseline_ir(p2, os.path.join(workdir, "case2_base"))
    cand_ir_2, err_c2 = emit_candidate_ir("-O2", p2, os.path.join(workdir, "case2_cand"))
    sec_2 = evaluate_candidate_security("-O2", base_ir_2, cand_ir_2)
    gate_2, _, _ = OptimizationSecurityGate().evaluate_gate_decision(sec_2)
    sinks_2 = analyze_module_sinks(base_ir_2, is_path=True)
    print("\nCase 2 (Sink in helper TU with internal guard):")
    print(f"  CandidateVerdict: {sec_2.verdict.value}")
    print(f"  GateDecision: {gate_2.value}")
    print(f"  Base sinks: {sec_2.baseline_sink_count}, Cand sinks: {sec_2.candidate_sink_count}")
    for s in sinks_2.sinks:
        print(f"    Sink: fn={s.function_name}, block={s.basic_block}, is_guarded={s.is_guarded}, class={s.sink_class.value}")

    # -------------------------------------------------------------
    # Case 3: Guard in caller (main) and sink in callee (unconditional inside helper)
    # -------------------------------------------------------------
    files_3 = {
        "helper.h": "void fail_hard(void);\n",
        "helper.c": """
#include <stdlib.h>
#include "helper.h"
void fail_hard(void) {
    abort(); // Unconditional within fail_hard!
}
""",
        "main.c": """
#include "helper.h"
int main(int argc, char **argv) {
    if (argc > 10) {
        fail_hard(); // Guarded in main!
    }
    return 0;
}
"""
    }
    p3 = CProject.from_files_dict(files_3, target_dir=os.path.join(workdir, "case3"))
    base_ir_3, err_b3 = emit_baseline_ir(p3, os.path.join(workdir, "case3_base"))
    cand_ir_3, err_c3 = emit_candidate_ir("-O2", p3, os.path.join(workdir, "case3_cand"))
    sec_3 = evaluate_candidate_security("-O2", base_ir_3, cand_ir_3)
    gate_3, _, _ = OptimizationSecurityGate().evaluate_gate_decision(sec_3)
    sinks_3 = analyze_module_sinks(base_ir_3, is_path=True)
    print("\nCase 3 (Guard in caller, unconditional sink in callee):")
    print(f"  CandidateVerdict: {sec_3.verdict.value}")
    print(f"  GateDecision: {gate_3.value}")
    print(f"  Base sinks: {sec_3.baseline_sink_count}, Cand sinks: {sec_3.candidate_sink_count}")
    for s in sinks_3.sinks:
        print(f"    Sink: fn={s.function_name}, block={s.basic_block}, is_guarded={s.is_guarded}, class={s.sink_class.value}")

    # -------------------------------------------------------------
    # Case 4: Function pointer call across TUs
    # -------------------------------------------------------------
    files_4 = {
        "helper.h": "typedef void (*func_ptr_t)(void);\nvoid register_callback(func_ptr_t cb);\nvoid trigger_callback(void);\n",
        "helper.c": """
#include "helper.h"
static func_ptr_t g_cb = 0;
void register_callback(func_ptr_t cb) { g_cb = cb; }
void trigger_callback(void) { if (g_cb) g_cb(); }
""",
        "main.c": """
#include <stdlib.h>
#include "helper.h"
void my_sink(void) { abort(); }
int main(void) {
    register_callback(my_sink);
    trigger_callback();
    return 0;
}
"""
    }
    p4 = CProject.from_files_dict(files_4, target_dir=os.path.join(workdir, "case4"))
    base_ir_4, err_b4 = emit_baseline_ir(p4, os.path.join(workdir, "case4_base"))
    cand_ir_4, err_c4 = emit_candidate_ir("-O2", p4, os.path.join(workdir, "case4_cand"))
    sec_4 = evaluate_candidate_security("-O2", base_ir_4, cand_ir_4)
    gate_4, _, _ = OptimizationSecurityGate().evaluate_gate_decision(sec_4)
    sinks_4 = analyze_module_sinks(base_ir_4, is_path=True)
    print("\nCase 4 (Function pointer call across TUs):")
    print(f"  CandidateVerdict: {sec_4.verdict.value}")
    print(f"  GateDecision: {gate_4.value}")
    print(f"  Base sinks: {sec_4.baseline_sink_count}, Cand sinks: {sec_4.candidate_sink_count}")
    for s in sinks_4.sinks:
        print(f"    Sink: fn={s.function_name}, block={s.basic_block}, is_guarded={s.is_guarded}, class={s.sink_class.value}")

    # -------------------------------------------------------------
    # Case 5: Unresolved external function
    # -------------------------------------------------------------
    files_5 = {
        "proto.h": "void missing_external(void);\n",
        "main.c": """
#include "proto.h"
int main(void) {
    missing_external();
    return 0;
}
"""
    }
    p5 = CProject.from_files_dict(files_5, target_dir=os.path.join(workdir, "case5"))
    base_ir_5, err_b5 = emit_baseline_ir(p5, os.path.join(workdir, "case5_base"))
    cand_ir_5, err_c5 = emit_candidate_ir("-O2", p5, os.path.join(workdir, "case5_cand"))
    sec_5 = evaluate_candidate_security("-O2", base_ir_5, cand_ir_5)
    gate_5, _, _ = OptimizationSecurityGate().evaluate_gate_decision(sec_5)
    print("\nCase 5 (Unresolved external function declaration):")
    print(f"  Baseline IR: {base_ir_5 is not None}")
    print(f"  Candidate IR: {cand_ir_5 is not None}")
    print(f"  CandidateVerdict: {sec_5.verdict.value}")
    print(f"  GateDecision: {gate_5.value}")

finally:
    shutil.rmtree(workdir, ignore_errors=True)
