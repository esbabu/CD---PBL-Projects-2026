import os
import sys
import json
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from web.service import DEFAULT_SOURCE_CODE, get_sample_source
from moo.multiagent.orchestrator import MultiAgentOrchestrator
from moo.runrecord.projections import to_gui_view

print("=== RUNNING MULTI-AGENT ORCHESTRATOR ON GEMM ===")
orch = MultiAgentOrchestrator()
rec_gemm, _ = orch.run(
    source_path=r"scratch\bench_run\gemm.c",
    warmup_runs=2,
    measure_runs=5,
    timeout_s=10,
    run_benchmarks=True,
)
view_gemm = to_gui_view(rec_gemm)
print("GEMM Selected Strategy:", rec_gemm.selected_strategy)
print("GEMM Effective Strategy:", rec_gemm.effective_strategy)
print("GEMM Baseline Timing:", view_gemm.get("baseline_timing"))
print("GEMM Optimized Timing:", view_gemm.get("optimized_timing"))
print("GEMM Performance Comp:", view_gemm.get("performance_comparison"))

print("\n=== RUNNING MULTI-AGENT ORCHESTRATOR ON TC1 ===")
tc1_path = os.path.normpath(r"..\test_cases\TC1_loop_heavy.c")
rec_tc1, _ = orch.run(
    source_path=tc1_path,
    warmup_runs=2,
    measure_runs=5,
    timeout_s=10,
    run_benchmarks=True,
)
view_tc1 = to_gui_view(rec_tc1)
print("TC1 Selected Strategy:", rec_tc1.selected_strategy)
print("TC1 Effective Strategy:", rec_tc1.effective_strategy)
print("TC1 Baseline Timing:", view_tc1.get("baseline_timing"))
print("TC1 Optimized Timing:", view_tc1.get("optimized_timing"))
print("TC1 Performance Comp:", view_tc1.get("performance_comparison"))
