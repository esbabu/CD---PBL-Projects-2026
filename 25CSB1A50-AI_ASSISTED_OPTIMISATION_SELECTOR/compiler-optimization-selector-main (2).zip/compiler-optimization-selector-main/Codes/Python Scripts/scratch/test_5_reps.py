import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from web.service import execute_run_task, get_run_result, DEFAULT_SOURCE_CODE

run_id = "test_ai_run_5_reps"
execute_run_task(run_id, DEFAULT_SOURCE_CODE, mode="ai", warmup_runs=2, measure_runs=5)
res = get_run_result(run_id)
print("View baseline timing:", res["view"]["baseline_timing"])
print("View optimized timing:", res["view"]["optimized_timing"])
print("Performance comp:", res["view"]["performance_comparison"])
