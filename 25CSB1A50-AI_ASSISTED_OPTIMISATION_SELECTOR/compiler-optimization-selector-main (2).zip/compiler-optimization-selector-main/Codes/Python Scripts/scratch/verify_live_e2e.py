"""
verify_live_e2e.py
Performs end-to-end verification of the live multi-agent application across:
- Normal (-O3)
- DQN
- LinUCB
- Card 1 baseline state isolation
"""
import os
import sys
import json

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INNER_REPO = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
MOO_DIR = os.path.join(INNER_REPO, "Codes", "Python Scripts")
sys.path.insert(0, MOO_DIR)

from moo.multiagent.orchestrator import MultiAgentOrchestrator
from moo.pipeline import evaluate_program

def verify_e2e():
    test_src = os.path.join(INNER_REPO, "Codes", "test_cases", "nested_loops.c")
    print(f"Running End-to-End Verification on: {test_src}")
    
    orch = MultiAgentOrchestrator()
    
    # 1. Normal -O3 Run
    print("\n1. Verifying Normal (-O3) Flow...")
    rec_normal, diag_normal = orch.run(
        source_path=test_src,
        model_family="normal",
        run_benchmarks=True,
        run_security=True,
        run_regression=False,
    )
    assert rec_normal is not None, "Normal run record must not be None"
    assert rec_normal.run_id is not None, "Run ID must be generated"
    assert rec_normal.baseline_measurement is not None, "Card 1 baseline must exist"
    assert "-O0" in rec_normal.baseline_measurement.strategy, f"Baseline strategy must contain -O0, got {rec_normal.baseline_measurement.strategy}"
    print(f"  Normal: effective_strategy={rec_normal.effective_strategy}, baseline={rec_normal.baseline_measurement.strategy}")
    
    # 2. DQN Run
    print("\n2. Verifying DQN Multi-Agent Flow...")
    rec_dqn, diag_dqn = orch.run(
        source_path=test_src,
        model_family="dqn",
        run_benchmarks=True,
        run_security=True,
        run_regression=False,
    )
    assert rec_dqn is not None, "DQN run record must not be None"
    assert rec_dqn.baseline_measurement is not None, "DQN Card 1 baseline must exist"
    assert "-O0" in rec_dqn.baseline_measurement.strategy, f"DQN Baseline strategy must contain -O0, got {rec_dqn.baseline_measurement.strategy}"
    print(f"  DQN: effective_strategy={rec_dqn.effective_strategy}, baseline={rec_dqn.baseline_measurement.strategy}")

    # 3. LinUCB Run
    print("\n3. Verifying LinUCB Multi-Agent Flow...")
    rec_linucb, diag_linucb = orch.run(
        source_path=test_src,
        model_family="linucb",
        run_benchmarks=True,
        run_security=True,
        run_regression=False,
    )
    assert rec_linucb is not None, "LinUCB run record must not be None"
    assert rec_linucb.baseline_measurement is not None, "LinUCB Card 1 baseline must exist"
    assert "-O0" in rec_linucb.baseline_measurement.strategy, f"LinUCB Baseline strategy must contain -O0, got {rec_linucb.baseline_measurement.strategy}"
    print(f"  LinUCB: effective_strategy={rec_linucb.effective_strategy}, baseline={rec_linucb.baseline_measurement.strategy}")

    # 4. Card 1 Baseline Isolation Verification
    print("\n4. Verifying Card 1 Baseline State Isolation...")
    # Verify that rec_normal, rec_dqn, rec_linucb baseline measurements are strictly isolated:
    # 1. Strategy is always baseline (-O0)
    # 2. Status is OK
    # 3. Median execution time is positive
    # 4. Raw samples are preserved independently
    for name, rec in [("Normal", rec_normal), ("DQN", rec_dqn), ("LinUCB", rec_linucb)]:
        base = rec.baseline_measurement
        assert "-O0" in base.strategy, f"{name} baseline strategy mutated to {base.strategy}"
        assert base.median_s > 0, f"{name} baseline median time must be > 0"
        raw_samples = base.measurement_dict.get("raw_samples_ns", [])
        assert len(raw_samples) > 0, f"{name} baseline must contain raw samples in measurement_dict"
        print(f"  Verified {name} baseline isolation: strategy={base.strategy}, median={base.median_s*1000:.3f}ms, n_samples={len(raw_samples)}")

    print("\nALL END-TO-END VERIFICATION CHECKS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    verify_e2e()
