"""
run_targeted_regression_check.py
Runs the required targeted regression check per Section 4 of the prompt:
1. Phase 1 measurement engine (test_phase1_measurement_engine.py)
2. Reliable benchmarking (test_reliable_benchmarking.py)
3. Security tests (test_week13a_security.py & test_stage12_security.py)
4. Statistical simulation (run_statistical_simulation.py)
5. Backup reconciliation (deep_reconciliation_audit.py)
6. Normal / DQN / LinUCB / Baseline isolation (verify_live_e2e.py)
7. Frontend baseline isolation (test_phase2a_frontend.js)
"""
import os
import sys
import subprocess
import time
import json

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INNER_REPO = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "..", ".."))
MOO_DIR = os.path.join(INNER_REPO, "Codes", "Python Scripts")

SUITES = [
    ("Phase 1 Measurement Engine", [sys.executable, "-m", "unittest", "moo/tests/test_phase1_measurement_engine.py"], MOO_DIR),
    ("Reliable Benchmarking", [sys.executable, "-m", "unittest", "moo/tests/test_reliable_benchmarking.py"], MOO_DIR),
    ("Week 13A Security Gate", [sys.executable, "moo/tests/test_week13a_security.py"], MOO_DIR),
    ("Stage 12 Security Verification", [sys.executable, "-m", "pytest", "-q", "moo/tests/test_stage12_security.py"], MOO_DIR),
    ("Statistical Simulation", [sys.executable, "Codes/Python Scripts/scratch/run_statistical_simulation.py"], INNER_REPO),
    ("Deep Backup Reconciliation", [sys.executable, "Codes/Python Scripts/scratch/deep_reconciliation_audit.py"], INNER_REPO),
    ("Live Multi-Agent & Baseline Isolation", [sys.executable, "Codes/Python Scripts/scratch/verify_live_e2e.py"], INNER_REPO),
    ("Frontend Baseline Isolation", ["node", "web/tests/test_phase2a_frontend.js"], MOO_DIR),
]

def main():
    print("==================================================================")
    print("EXECUTING TARGETED REGRESSION CHECK")
    print("==================================================================")
    
    results = []
    all_passed = True

    for name, cmd, cwd in SUITES:
        cmd_str = " ".join(cmd)
        print(f"\nRunning: {name}...")
        print(f"Command: {cmd_str}")
        t0 = time.time()
        proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
        dur = round(time.time() - t0, 2)
        out = (proc.stdout + "\n" + proc.stderr).strip()

        passed = (proc.returncode == 0)
        if not passed:
            all_passed = False

        status_str = "PASS" if passed else "FAIL"
        print(f"[{status_str}] {name} in {dur}s (Exit code: {proc.returncode})")

        results.append({
            "name": name,
            "command": cmd_str,
            "cwd": cwd,
            "exit_code": proc.returncode,
            "duration_s": dur,
            "passed": passed,
            "tail_output": out[-400:] if len(out) > 400 else out,
        })

    print("\n==================================================================")
    print(f"TARGETED REGRESSION SUMMARY: {'ALL PASSED' if all_passed else 'FAILURES DETECTED'}")
    print(f"Total Suites: {len(results)} | Passed: {sum(1 for r in results if r['passed'])} | Failed: {sum(1 for r in results if not r['passed'])}")
    print("==================================================================")

    out_file = os.path.join(SCRIPT_DIR, "targeted_regression_results.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "all_passed": all_passed,
            "suites": results,
        }, f, indent=2)
    print(f"Saved results to: {out_file}")

if __name__ == "__main__":
    main()
