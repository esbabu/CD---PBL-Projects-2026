import os
import sys
import subprocess
import time
import json
import statistics

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from moo.measurement import measure_interleaved, measure_execution
from moo.strategy_diagnostic import _build_executable

CLANG = r"C:\Program Files\LLVM\bin\clang.exe"
OPT = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

SOURCE = r"""#include <stdio.h>

#define NI 64
#define NJ 64
#define NK 64

void kernel_gemm(int ni, int nj, int nk,
                 double alpha, double beta,
                 double C[NI][NJ],
                 double A[NI][NK],
                 double B[NK][NJ]) {
  for (int i = 0; i < ni; i++) {
    for (int j = 0; j < nj; j++) {
      C[i][j] *= beta;
    }
    for (int k = 0; k < nk; k++) {
      for (int j = 0; j < nj; j++) {
        C[i][j] += alpha * A[i][k] * B[k][j];
      }
    }
  }
}

int main(void) {
  static double C[NI][NJ];
  static double A[NI][NK];
  static double B[NK][NJ];

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NK; j++)
      A[i][j] = (double)(i * j % 1024) / 1024.0;

  for (int i = 0; i < NK; i++)
    for (int j = 0; j < NJ; j++)
      B[i][j] = (double)(i * j % 512) / 512.0;

  for (int i = 0; i < NI; i++)
    for (int j = 0; j < NJ; j++)
      C[i][j] = 0.5;

  for (int iter = 0; iter < 40; iter++) {
    kernel_gemm(NI, NJ, NK, 1.5, 1.2, C, A, B);
  }
  printf("C[0][0] = %f\n", C[0][0]);
  return 0;
}
"""

workdir = r"C:\Users\rithv\Desktop\New folder\TOACD\compiler-optimization-selector-main\compiler-optimization-selector-main\Codes\Python Scripts\scratch\bench_run"
os.makedirs(workdir, exist_ok=True)
src_path = os.path.join(workdir, "gemm.c")
with open(src_path, "w") as f:
    f.write(SOURCE)

# 1. Build Baseline (-O0)
dir_o0 = os.path.join(workdir, "o0")
os.makedirs(dir_o0, exist_ok=True)
ir_o0 = os.path.join(dir_o0, "baseline.ll")
subprocess.run([CLANG, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src_path, "-o", ir_o0], check=True)
exe_o0, _, _ = _build_executable(ir_o0, dir_o0, CLANG, "-O0")

# 2. Build Production Reference (-O3)
dir_o3 = os.path.join(workdir, "o3")
os.makedirs(dir_o3, exist_ok=True)
ir_o3 = os.path.join(dir_o3, "prod.ll")
subprocess.run([CLANG, "-O3", "-S", "-emit-llvm", src_path, "-o", ir_o3], check=True)
exe_o3, _, _ = _build_executable(ir_o3, dir_o3, CLANG, "-O3")

# 3. Build TOACD Custom Pipeline
dir_toacd = os.path.join(workdir, "toacd")
os.makedirs(dir_toacd, exist_ok=True)
ir_opt = os.path.join(dir_toacd, "custom.ll")
toacd_passes = "mem2reg,instcombine,simplifycfg,gvn,loop-unroll"
subprocess.run([OPT, f"-passes={toacd_passes}", "-S", ir_o0, "-o", ir_opt], check=True)
exe_toacd, _, _ = _build_executable(ir_opt, dir_toacd, CLANG, "-O2")

# Verify Correctness against Reference
p_ref = subprocess.run([exe_o0], capture_output=True, text=True, timeout=10)
p_o3 = subprocess.run([exe_o3], capture_output=True, text=True, timeout=10)
p_toacd = subprocess.run([exe_toacd], capture_output=True, text=True, timeout=10)

ref_stdout, ref_code = p_ref.stdout, p_ref.returncode
o3_stdout, o3_code = p_o3.stdout, p_o3.returncode
toacd_stdout, toacd_code = p_toacd.stdout, p_toacd.returncode

print("CORRECTNESS CHECK:")
print(f"Baseline -O0 exit: {ref_code}, stdout: {ref_stdout.strip()}")
print(f"Clang -O3    exit: {o3_code}, stdout: {o3_stdout.strip()}")
print(f"TOACD Custom exit: {toacd_code}, stdout: {toacd_stdout.strip()}")
assert o3_stdout == ref_stdout, "O3 stdout divergent"
assert toacd_stdout == ref_stdout, "TOACD stdout divergent"

# Run interleaved measurement across all 3
targets = [
    ("Baseline (clang -O0)", exe_o0),
    ("Production (clang -O3)", exe_o3),
    ("TOACD Custom (opt -> clang -O2)", exe_toacd),
]

measurements = measure_interleaved(targets, warmup_runs=2, measure_runs=5, timeout_s=10)

print("\n--- CONTROLLED EXPERIMENT RESULTS ---")
results_summary = {}
for name, m in measurements.items():
    stats = m.timing
    samples_ms = [round(s / 1e6, 2) for s in m.raw_samples_ns]
    code_size = m.code_size.primary_value if m.code_size else os.path.getsize(m.exe_path)
    res = {
        "samples_ms": samples_ms,
        "median_ms": round(stats.median_s * 1000, 2),
        "mean_ms": round(stats.mean_s * 1000, 2),
        "stdev_ms": round(stats.stdev_ns / 1e6, 2),
        "min_ms": round(stats.min_ns / 1e6, 2),
        "max_ms": round(stats.max_ns / 1e6, 2),
        "cv": round(stats.cv, 4),
        "code_size_bytes": code_size,
        "timing_is_reliable": m.timing_is_reliable,
    }
    results_summary[name] = res
    print(f"\n[{name}]")
    print(f"  Samples (ms) : {samples_ms}")
    print(f"  Median       : {res['median_ms']} ms")
    print(f"  Mean         : {res['mean_ms']} ms ± {res['stdev_ms']} ms")
    print(f"  Range (min-max): {res['min_ms']} ms - {res['max_ms']} ms")
    print(f"  CV           : {res['cv']:.2%}")
    print(f"  Code Size    : {code_size:,} bytes")
    print(f"  Reliable     : {res['timing_is_reliable']}")

# Speedup vs Baseline
base_med = results_summary["Baseline (clang -O0)"]["median_ms"]
o3_med = results_summary["Production (clang -O3)"]["median_ms"]
toacd_med = results_summary["TOACD Custom (opt -> clang -O2)"]["median_ms"]

speedup_o3 = round(base_med / o3_med, 2)
speedup_toacd = round(base_med / toacd_med, 2)

print("\n--- COMPARISON VS BASELINE (-O0) ---")
print(f"Production -O3 Speedup : {speedup_o3}x ({base_med}ms -> {o3_med}ms, {((base_med-o3_med)/base_med)*100:.1f}% reduction)")
print(f"TOACD Custom Speedup   : {speedup_toacd}x ({base_med}ms -> {toacd_med}ms, {((base_med-toacd_med)/base_med)*100:.1f}% reduction)")

with open(os.path.join(workdir, "results.json"), "w") as f:
    json.dump(results_summary, f, indent=2)
