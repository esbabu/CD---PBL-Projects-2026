import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from web.service import execute_run_task, get_run_result, DEFAULT_SOURCE_CODE

print("Testing execute_run_task mode='normal'...")
run_id_norm = "test_normal_run_1"
execute_run_task(run_id_norm, DEFAULT_SOURCE_CODE, mode="normal", warmup_runs=2, measure_runs=3)
res_norm = get_run_result(run_id_norm)
print(f"Normal run status: {res_norm['status']}")
print(f"Normal view timing: {res_norm['view'].get('optimized_timing')}")

print("\nTesting execute_run_task mode='ai'...")
run_id_ai = "test_ai_run_1"
execute_run_task(run_id_ai, DEFAULT_SOURCE_CODE, mode="ai", warmup_runs=2, measure_runs=3)
res_ai = get_run_result(run_id_ai)
print(f"AI run status: {res_ai['status']}")
print(f"AI view baseline timing: {res_ai['view'].get('baseline_timing')}")
print(f"AI view optimized timing: {res_ai['view'].get('optimized_timing')}")
print(f"AI view performance comparison: {res_ai['view'].get('performance_comparison')}")
