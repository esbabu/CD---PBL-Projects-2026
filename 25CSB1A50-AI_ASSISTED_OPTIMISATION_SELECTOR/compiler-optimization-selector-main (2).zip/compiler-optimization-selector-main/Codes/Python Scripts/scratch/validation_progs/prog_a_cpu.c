
#include <stdio.h>
int main(void) {
    volatile unsigned long long acc = 0;
    for (unsigned long long i = 0; i < 500000000ULL; i++) {
        acc += (i ^ (i >> 1));
    }
    printf("ACC=%llu\n", acc);
    return 0;
}
