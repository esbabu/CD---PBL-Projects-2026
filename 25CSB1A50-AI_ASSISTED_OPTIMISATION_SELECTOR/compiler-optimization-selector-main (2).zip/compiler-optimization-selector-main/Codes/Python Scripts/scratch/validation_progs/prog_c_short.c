
#include <stdio.h>
int main(void) {
    volatile int x = 0;
    for (int i = 0; i < 50000; i++) {
        x += (i & 1);
    }
    printf("SHORT_DONE=%d\n", x);
    return 0;
}
