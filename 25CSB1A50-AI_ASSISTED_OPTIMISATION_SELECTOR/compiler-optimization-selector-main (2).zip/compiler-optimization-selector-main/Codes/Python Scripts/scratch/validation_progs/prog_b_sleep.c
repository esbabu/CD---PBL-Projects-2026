
#include <stdio.h>
#include <windows.h>
int main(void) {
    Sleep(200);
    printf("SLEEP_DONE\n");
    return 0;
}
