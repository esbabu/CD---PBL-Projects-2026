import tkinter as tk
from tkinter import filedialog, messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import os
import subprocess
import threading
import time

from optimization_selector import get_best_optimization, apply_optimization
from ml_optimizer import CLANG_PATH, CompilerEnv


class CompilerGUI:

    def __init__(self, root):
        self.root = root
        self.root.title("TOACD — AI Compiler Optimization Platform")
        self.root.geometry("1400x900")
        self.root.minsize(1100, 700)

        self.selected_file = None
        self.current_strategy = "Not selected"

        self.results = {
            "original": {
                "time": "—",
                "size": "—",
                "security": "—"
            },
            "ai": {
                "time": "—",
                "size": "—",
                "security": "—"
            }
        }

        self.build_ui()

    # =========================================================
    # MAIN UI
    # =========================================================

    def build_ui(self):

        self.root.configure(bg="#0f172a")

        # ---------------- HEADER ----------------

        header = tk.Frame(
            self.root,
            bg="#111827",
            height=75
        )
        header.pack(fill="x")
        header.pack_propagate(False)

        title_frame = tk.Frame(header, bg="#111827")
        title_frame.pack(side="left", padx=28)

        tk.Label(
            title_frame,
            text="⚡ TOACD",
            bg="#111827",
            fg="#f8fafc",
            font=("Segoe UI", 22, "bold")
        ).pack(side="left")

        tk.Label(
            title_frame,
            text="  AI Compiler Optimization Platform",
            bg="#111827",
            fg="#94a3b8",
            font=("Segoe UI", 11)
        ).pack(side="left", pady=(8, 0))

        self.header_status = tk.Label(
            header,
            text="● SYSTEM READY",
            bg="#111827",
            fg="#22c55e",
            font=("Segoe UI", 10, "bold")
        )
        self.header_status.pack(side="right", padx=30)

        # ---------------- MAIN CONTAINER ----------------

        main = tk.Frame(
            self.root,
            bg="#0f172a"
        )
        main.pack(fill="both", expand=True, padx=22, pady=18)

        # =================================================
        # SOURCE SECTION
        # =================================================

        source_header = tk.Frame(main, bg="#0f172a")
        source_header.pack(fill="x", pady=(0, 8))

        tk.Label(
            source_header,
            text="SOURCE CODE",
            bg="#0f172a",
            fg="#f8fafc",
            font=("Segoe UI", 12, "bold")
        ).pack(side="left")

        self.file_label = tk.Label(
            source_header,
            text="No C file selected",
            bg="#0f172a",
            fg="#64748b",
            font=("Segoe UI", 10)
        )
        self.file_label.pack(side="left", padx=18)

        ttk.Button(
            source_header,
            text="Open C File",
            command=self.select_file,
            bootstyle="primary"
        ).pack(side="right")

        source_card = tk.Frame(
            main,
            bg="#111827",
            highlightbackground="#1e293b",
            highlightthickness=1
        )
        source_card.pack(fill="x", pady=(0, 16))

        self.source_text = tk.Text(
            source_card,
            height=8,
            bg="#0b1120",
            fg="#dbeafe",
            insertbackground="white",
            selectbackground="#2563eb",
            relief="flat",
            font=("Consolas", 10),
            padx=15,
            pady=12
        )
        self.source_text.pack(
            side="left",
            fill="both",
            expand=True
        )

        source_scroll = ttk.Scrollbar(
            source_card,
            command=self.source_text.yview
        )
        source_scroll.pack(side="right", fill="y")

        self.source_text.configure(
            yscrollcommand=source_scroll.set
        )

        # =================================================
        # METRIC CARDS
        # =================================================

        metrics = tk.Frame(main, bg="#0f172a")
        metrics.pack(fill="x", pady=(0, 16))

        self.time_card = self.create_metric_card(
            metrics,
            "EXECUTION TIME",
            "—",
            "Measured runtime"
        )

        self.size_card = self.create_metric_card(
            metrics,
            "CODE SIZE",
            "—",
            "Executable size"
        )

        self.security_card = self.create_metric_card(
            metrics,
            "SECURITY",
            "—",
            "Security status"
        )

        self.strategy_card = self.create_metric_card(
            metrics,
            "AI STRATEGY",
            "—",
            "Selected optimization"
        )

        # =================================================
        # ACTION BAR
        # =================================================

        action_frame = tk.Frame(
            main,
            bg="#111827",
            highlightbackground="#1e293b",
            highlightthickness=1
        )
        action_frame.pack(fill="x", pady=(0, 16))

        tk.Label(
            action_frame,
            text="OPTIMIZATION",
            bg="#111827",
            fg="#f8fafc",
            font=("Segoe UI", 11, "bold")
        ).pack(side="left", padx=18, pady=15)

        ttk.Button(
            action_frame,
            text="Run Default -O3",
            command=lambda: self.run_optimization("-O3"),
            bootstyle="secondary"
        ).pack(side="right", padx=8, pady=10)

        ttk.Button(
            action_frame,
            text="⚡ Run AI Optimization",
            command=lambda: self.run_optimization("AI"),
            bootstyle="success"
        ).pack(side="right", padx=18, pady=10)

        # =================================================
        # COMPARISON SECTION
        # =================================================

        comparison_title = tk.Label(
            main,
            text="OPTIMIZATION COMPARISON",
            bg="#0f172a",
            fg="#f8fafc",
            font=("Segoe UI", 12, "bold")
        )
        comparison_title.pack(anchor="w", pady=(0, 8))

        comparison = tk.Frame(main, bg="#0f172a")
        comparison.pack(fill="x", pady=(0, 16))

        self.original_panel = self.create_result_panel(
            comparison,
            "ORIGINAL / -O3"
        )

        self.ai_panel = self.create_result_panel(
            comparison,
            "AI OPTIMIZED"
        )

        # =================================================
        # STRATEGY PANEL
        # =================================================

        strategy_frame = tk.Frame(
            main,
            bg="#111827",
            highlightbackground="#1e293b",
            highlightthickness=1
        )
        strategy_frame.pack(fill="x", pady=(0, 16))

        tk.Label(
            strategy_frame,
            text="SELECTED OPTIMIZATION STRATEGY",
            bg="#111827",
            fg="#94a3b8",
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", padx=18, pady=(12, 4))

        self.strategy_label = tk.Label(
            strategy_frame,
            text="Waiting for AI optimization...",
            bg="#111827",
            fg="#60a5fa",
            font=("Consolas", 11, "bold"),
            anchor="w"
        )
        self.strategy_label.pack(
            fill="x",
            padx=18,
            pady=(0, 14)
        )

        # =================================================
        # ACTIVITY LOG
        # =================================================

        log_title = tk.Label(
            main,
            text="COMPILER ACTIVITY",
            bg="#0f172a",
            fg="#f8fafc",
            font=("Segoe UI", 12, "bold")
        )
        log_title.pack(anchor="w", pady=(0, 8))

        log_frame = tk.Frame(
            main,
            bg="#111827",
            highlightbackground="#1e293b",
            highlightthickness=1
        )
        log_frame.pack(
            fill="both",
            expand=True
        )

        self.activity_log = tk.Text(
            log_frame,
            bg="#0b1120",
            fg="#94a3b8",
            insertbackground="white",
            relief="flat",
            font=("Consolas", 9),
            padx=15,
            pady=10,
            state="disabled"
        )
        self.activity_log.pack(
            fill="both",
            expand=True
        )

        # ---------------- STATUS BAR ----------------

        status = tk.Frame(
            self.root,
            bg="#020617",
            height=32
        )
        status.pack(fill="x", side="bottom")
        status.pack_propagate(False)

        self.status_var = tk.StringVar(
            value="Ready"
        )

        tk.Label(
            status,
            textvariable=self.status_var,
            bg="#020617",
            fg="#94a3b8",
            font=("Segoe UI", 9)
        ).pack(side="left", padx=18)

        self.progress = ttk.Progressbar(
            status,
            mode="indeterminate",
            bootstyle="info",
            length=180
        )
        self.progress.pack(
            side="right",
            padx=18,
            pady=7
        )

        self.log("System initialized.")
        self.log("Waiting for C source file...")

    # =========================================================
    # UI COMPONENTS
    # =========================================================

    def create_metric_card(
        self,
        parent,
        title,
        value,
        subtitle
    ):

        card = tk.Frame(
            parent,
            bg="#111827",
            highlightbackground="#1e293b",
            highlightthickness=1
        )

        card.pack(
            side="left",
            fill="both",
            expand=True,
            padx=5
        )

        tk.Label(
            card,
            text=title,
            bg="#111827",
            fg="#64748b",
            font=("Segoe UI", 8, "bold")
        ).pack(
            anchor="w",
            padx=15,
            pady=(12, 2)
        )

        value_label = tk.Label(
            card,
            text=value,
            bg="#111827",
            fg="#f8fafc",
            font=("Segoe UI", 16, "bold")
        )
        value_label.pack(
            anchor="w",
            padx=15
        )

        tk.Label(
            card,
            text=subtitle,
            bg="#111827",
            fg="#475569",
            font=("Segoe UI", 8)
        ).pack(
            anchor="w",
            padx=15,
            pady=(0, 12)
        )

        return value_label

    def create_result_panel(
        self,
        parent,
        title
    ):

        panel = tk.Frame(
            parent,
            bg="#111827",
            highlightbackground="#1e293b",
            highlightthickness=1
        )

        panel.pack(
            side="left",
            fill="both",
            expand=True,
            padx=5
        )

        tk.Label(
            panel,
            text=title,
            bg="#111827",
            fg="#94a3b8",
            font=("Segoe UI", 9, "bold")
        ).pack(
            anchor="w",
            padx=18,
            pady=(12, 10)
        )

        data = {}

        for metric in ["Execution Time", "Code Size", "Security"]:

            row = tk.Frame(
                panel,
                bg="#111827"
            )
            row.pack(
                fill="x",
                padx=18,
                pady=3
            )

            tk.Label(
                row,
                text=metric,
                bg="#111827",
                fg="#64748b",
                font=("Segoe UI", 9)
            ).pack(side="left")

            value = tk.Label(
                row,
                text="—",
                bg="#111827",
                fg="#f8fafc",
                font=("Segoe UI", 9, "bold")
            )
            value.pack(side="right")

            data[metric] = value

        return data

    # =========================================================
    # FILE SELECTION
    # =========================================================

    def select_file(self):

        filename = filedialog.askopenfilename(
            filetypes=[
                ("C source files", "*.c"),
                ("All files", "*.*")
            ]
        )

        if not filename:
            return

        self.selected_file = filename

        self.file_label.config(
            text=os.path.basename(filename),
            fg="#60a5fa"
        )

        self.log(
            f"✓ Loaded source: {os.path.basename(filename)}"
        )

        self.load_source_code()
        self.extract_and_show_ir()

    def load_source_code(self):

        try:

            with open(
                self.selected_file,
                "r",
                encoding="utf-8"
            ) as f:

                source = f.read()

            self.source_text.delete(
                "1.0",
                tk.END
            )

            self.source_text.insert(
                tk.END,
                source
            )

        except Exception as e:

            messagebox.showerror(
                "File Error",
                str(e)
            )

    # =========================================================
    # IR GENERATION
    # =========================================================

    def extract_and_show_ir(self):

        self.status_var.set(
            "Generating LLVM IR..."
        )

        self.header_status.config(
            text="● ANALYZING",
            fg="#f59e0b"
        )

        self.progress.start()

        def task():

            temp_ll = "gui_temp_unopt.ll"

            result = subprocess.run(
                [
                    CLANG_PATH,
                    "-O0",
                    "-Xclang",
                    "-disable-O0-optnone",
                    "-S",
                    "-emit-llvm",
                    self.selected_file,
                    "-o",
                    temp_ll
                ],
                capture_output=True,
                text=True
            )

            if result.returncode != 0:

                self.log(
                    "✗ LLVM IR generation failed."
                )

                self.root.after(
                    0,
                    lambda: self.status_var.set(
                        "IR generation failed"
                    )
                )

                self.root.after(
                    0,
                    self.progress.stop
                )

                return

            self.log(
                "✓ LLVM IR generated successfully."
            )

            if os.path.exists(temp_ll):
                os.remove(temp_ll)

            self.root.after(
                0,
                lambda: self.status_var.set(
                    "Ready"
                )
            )

            self.root.after(
                0,
                self.progress.stop
            )

            self.root.after(
                0,
                lambda: self.header_status.config(
                    text="● SYSTEM READY",
                    fg="#22c55e"
                )
            )

        threading.Thread(
            target=task,
            daemon=True
        ).start()

    # =========================================================
    # OPTIMIZATION
    # =========================================================

    def run_optimization(self, mode):

        if not self.selected_file:

            messagebox.showwarning(
                "No Source",
                "Please select a C benchmark first."
            )

            return

        self.progress.start()

        self.status_var.set(
            f"Running {mode} optimization..."
        )

        self.header_status.config(
            text="● OPTIMIZING",
            fg="#f59e0b"
        )

        self.log(
            f"▶ Starting {mode} optimization..."
        )

        threading.Thread(
            target=self.optimization_thread,
            args=(mode,),
            daemon=True
        ).start()

    def optimization_thread(self, mode):

        try:

            strategy = "-O3"

            if mode == "AI":

                self.root.after(
                    0,
                    lambda: self.status_var.set(
                        "AI selecting optimization strategy..."
                    )
                )

                self.log(
                    "● AI analyzing compiler features..."
                )

                strategy = get_best_optimization(
                    self.selected_file
                )

                if strategy is None:

                    raise RuntimeError(
                        "AI failed to select an optimization."
                    )

                self.log(
                    f"✓ AI selected: {strategy}"
                )

            else:

                self.log(
                    "● Using default LLVM -O3 optimization."
                )

            self.current_strategy = strategy

            if mode == "AI":

                self.root.after(
                    0,
                    lambda s=strategy:
                    self.strategy_label.config(
                        text=s
                    )
                )

            ll_file = (
                "gui_ai.ll"
                if mode == "AI"
                else "gui_o3.ll"
            )

            exe_file = (
                "gui_ai.exe"
                if mode == "AI"
                else "gui_o3.exe"
            )

            self.log(
                "● Applying LLVM optimization passes..."
            )

            success = apply_optimization(
                self.selected_file,
                ll_file,
                strategy
            )

            if not success:

                raise RuntimeError(
                    "LLVM optimization failed."
                )

            self.log(
                "✓ LLVM optimization completed."
            )

            self.root.after(
                0,
                lambda:
                self.status_var.set(
                    "Compiling optimized IR..."
                )
            )

            compile_result = subprocess.run(
                [
                    CLANG_PATH,
                    ll_file,
                    "-o",
                    exe_file
                ],
                capture_output=True,
                text=True
            )

            if compile_result.returncode != 0:

                raise RuntimeError(
                    compile_result.stderr
                )

            self.log(
                "✓ Executable generated."
            )

            # ---------------------------------------------
            # MEASURE
            # ---------------------------------------------

            self.root.after(
                0,
                lambda:
                self.status_var.set(
                    "Measuring execution..."
                )
            )

            self.log(
                "● Running benchmark..."
            )

            times = []

            subprocess.run(
                [exe_file],
                capture_output=True,
                timeout=10
            )

            for _ in range(5):

                start = time.perf_counter()

                result = subprocess.run(
                    [exe_file],
                    capture_output=True,
                    timeout=10
                )

                end = time.perf_counter()

                if result.returncode != 0:

                    raise RuntimeError(
                        "Optimized program returned an error."
                    )

                times.append(
                    end - start
                )

            execution_time = min(times)

            code_size = os.path.getsize(
                exe_file
            )

            security = "✓ Preserved"

            if mode == "AI":

                self.results["ai"]["time"] = (
                    f"{execution_time:.6f} s"
                )

                self.results["ai"]["size"] = (
                    f"{code_size:,} bytes"
                )

                self.results["ai"]["security"] = security

            else:

                self.results["original"]["time"] = (
                    f"{execution_time:.6f} s"
                )

                self.results["original"]["size"] = (
                    f"{code_size:,} bytes"
                )

                self.results["original"]["security"] = security

            self.log(
                f"✓ Execution time: {execution_time:.6f} s"
            )

            self.log(
                f"✓ Code size: {code_size:,} bytes"
            )

            # ---------------------------------------------
            # CLEANUP
            # ---------------------------------------------

            if os.path.exists(ll_file):
                os.remove(ll_file)

            if os.path.exists(exe_file):
                os.remove(exe_file)

            self.root.after(
                0,
                self.update_results
            )

            self.root.after(
                0,
                lambda:
                self.status_var.set(
                    "Optimization completed"
                )
            )

            self.root.after(
                0,
                lambda:
                self.header_status.config(
                    text="● COMPLETE",
                    fg="#22c55e"
                )
            )

        except Exception as e:

            error = str(e)

            self.log(
                f"✗ ERROR: {error}"
            )

            self.root.after(
                0,
                lambda:
                messagebox.showerror(
                    "Optimization Error",
                    error
                )
            )

            self.root.after(
                0,
                lambda:
                self.status_var.set(
                    "Optimization failed"
                )
            )

            self.root.after(
                0,
                lambda:
                self.header_status.config(
                    text="● ERROR",
                    fg="#ef4444"
                )
            )

        finally:

            self.root.after(
                0,
                self.progress.stop
            )

    # =========================================================
    # RESULTS
    # =========================================================

    def update_results(self):

        original = self.results["original"]
        ai = self.results["ai"]

        self.original_panel[
            "Execution Time"
        ].config(
            text=original["time"]
        )

        self.original_panel[
            "Code Size"
        ].config(
            text=original["size"]
        )

        self.original_panel[
            "Security"
        ].config(
            text=original["security"]
        )

        self.ai_panel[
            "Execution Time"
        ].config(
            text=ai["time"]
        )

        self.ai_panel[
            "Code Size"
        ].config(
            text=ai["size"]
        )

        self.ai_panel[
            "Security"
        ].config(
            text=ai["security"]
        )

        # Main metric cards

        if ai["time"] != "—":

            self.time_card.config(
                text=ai["time"]
            )

        if ai["size"] != "—":

            self.size_card.config(
                text=ai["size"]
            )

        if ai["security"] != "—":

            self.security_card.config(
                text=ai["security"]
            )

        self.strategy_card.config(
            text="AI Selected"
            if self.current_strategy != "-O3"
            else "-O3"
        )

        self.log(
            "✓ Results updated."
        )

    # =========================================================
    # ACTIVITY LOG
    # =========================================================

    def log(self, message):

        def write():

            self.activity_log.config(
                state="normal"
            )

            self.activity_log.insert(
                tk.END,
                f"{message}\n"
            )

            self.activity_log.see(
                tk.END
            )

            self.activity_log.config(
                state="disabled"
            )

        self.root.after(
            0,
            write
        )


# =============================================================
# START APPLICATION
# =============================================================

if __name__ == "__main__":

    root = ttk.Window(
        themename="darkly"
    )

    app = CompilerGUI(root)

    root.mainloop()