import os
import shutil
import tempfile
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import subprocess
import time
import re

# Configurations
CLANG_PATH = r"C:\Program Files\LLVM\bin\clang.exe"
# Based on common LLVM passes
PASSES = ["mem2reg", "instcombine", "simplifycfg", "dce", "loop-unroll", "gvn"]
# We'll use combinations of these or just the list itself
ACTIONS = [
    "-O0", "-O1", "-O2", "-O3",
    "mem2reg,instcombine",
    "mem2reg,simplifycfg",
    "mem2reg,instcombine,simplifycfg,dce",
    "mem2reg,instcombine,simplifycfg,gvn,loop-unroll",
    "mem2reg,instcombine,simplifycfg,dce,gvn,loop-unroll"
]

# Simple DQN Model
class DQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x):
        return self.fc(x)

class CompilerEnv:
    def __init__(self, benchmark_path, workdir=None, build_config=None, timeout=5):
        self.timeout = timeout
        from moo.project import CProject
        if isinstance(benchmark_path, CProject):
            self.project = benchmark_path
            self.benchmark_path = benchmark_path.entry_file or (
                benchmark_path.get_absolute_source_paths()[0]
                if benchmark_path.source_files
                else benchmark_path.project_root
            )
            if self.project.build_config and not build_config:
                self.build_config = self.project.build_config
            else:
                self.build_config = build_config
        elif os.path.isdir(str(benchmark_path)):
            self.project = CProject.from_directory(str(benchmark_path), build_config=build_config)
            self.benchmark_path = self.project.entry_file or (
                self.project.get_absolute_source_paths()[0]
                if self.project.source_files
                else str(benchmark_path)
            )
            self.build_config = build_config
        else:
            self.project = CProject.from_single_file(str(benchmark_path), build_config=build_config)
            self.benchmark_path = str(benchmark_path)
            self.build_config = build_config

        if workdir:
            self.workdir = os.path.abspath(workdir)
            self._owns_workdir = False
            os.makedirs(self.workdir, exist_ok=True)
        else:
            self.workdir = tempfile.mkdtemp(prefix="toacd_env_")
            self._owns_workdir = True

        self.ir_path = os.path.join(self.workdir, "temp_unopt.ll")
        self.opt_ir = os.path.join(self.workdir, "temp_opt.ll")
        self.opt_exe = os.path.join(self.workdir, "temp_opt.exe")
        self.step_unopt = os.path.join(self.workdir, "temp_unopt_step.ll")
        
        # Check if raw features are already cached for this exact source code and build config
        cached_features = None
        try:
            from moo.ir_cache import compute_source_hash, get_cached_raw_features
            sha = compute_source_hash(self.project if hasattr(self, "project") else benchmark_path, build_config=build_config)
            cached_features = get_cached_raw_features(sha)
        except Exception:
            pass

        success = self.generate_unoptimized_ir()
        if cached_features is not None:
            self.features = np.array(cached_features, dtype=np.float32)
        elif getattr(self, "_tu_features", None):
            self.features = np.sum(self._tu_features, axis=0, dtype=np.float32)
        elif success and os.path.exists(self.ir_path):
            self.features = self.extract_features(self.ir_path)
            # Store in cache
            try:
                from moo.ir_cache import compute_source_hash, store_cached_baseline_ir
                sha = compute_source_hash(self.project if hasattr(self, "project") else benchmark_path, build_config=build_config)
                with open(self.ir_path, "r", encoding="utf-8", errors="replace") as f:
                    ir_text = f.read()
                store_cached_baseline_ir(sha, ir_text, raw_features=self.features.tolist())
            except Exception:
                pass
        else:
            self.features = np.zeros(8, dtype=np.float32)

    def cleanup(self):
        """Safely clean up files in this environment's isolated working directory."""
        if getattr(self, "_owns_workdir", False) and hasattr(self, "workdir") and os.path.isdir(self.workdir):
            try:
                shutil.rmtree(self.workdir, ignore_errors=True)
            except Exception:
                pass
        else:
            for attr in ("ir_path", "opt_ir", "opt_exe", "step_unopt"):
                path = getattr(self, attr, None)
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass

    def __del__(self):
        try:
            self.cleanup()
        except Exception:
            pass
        
    def generate_unoptimized_ir(self):
        # Invalidate/remove pre-existing artifact before compilation to avoid stale reuse
        if hasattr(self, "ir_path") and os.path.exists(self.ir_path):
            try:
                os.remove(self.ir_path)
            except OSError:
                pass

        # Try retrieving unoptimized IR from in-memory content cache first
        try:
            from moo.ir_cache import compute_source_hash, get_cached_baseline_ir
            cache_target = self.project if hasattr(self, "project") else self.benchmark_path
            sha = compute_source_hash(cache_target, build_config=getattr(self, "build_config", None))
            cached_ir = get_cached_baseline_ir(sha)
            if cached_ir:
                with open(self.ir_path, "w", encoding="utf-8") as f:
                    f.write(cached_ir)
                return True
        except Exception:
            pass

        if not hasattr(self, "project") or not self.project.is_multi_file:
            try:
                cmd = [CLANG_PATH, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm"]
                if getattr(self, "build_config", None):
                    try:
                        cmd.extend(self.build_config.to_clang_args())
                    except Exception:
                        pass
                cmd.extend([self.benchmark_path, "-o", self.ir_path])
                result = subprocess.run(cmd, capture_output=True, text=True)
                # Check clang return code
                if result.returncode != 0:
                    self._last_compiler_error = result.stderr or result.stdout
                    if hasattr(self, "ir_path") and os.path.exists(self.ir_path):
                        try:
                            os.remove(self.ir_path)
                        except OSError:
                            pass
                    return False
                return os.path.exists(self.ir_path)
            except Exception as exc:
                self._last_compiler_error = str(exc)
                if hasattr(self, "ir_path") and os.path.exists(self.ir_path):
                    try:
                        os.remove(self.ir_path)
                    except OSError:
                        pass
                return False
        else:
            # Multi-file compilation and whole-program IR linking
            try:
                from moo.config import LLVM_LINK_PATH
                eff_cfg = self.project.get_effective_build_config()
                flags = eff_cfg.to_clang_args()
                tu_ir_files = []
                sources = self.project.get_absolute_source_paths()
                for idx, src_p in enumerate(sources):
                    tu_ir = os.path.join(self.workdir, f"tu_{idx}_unopt.ll")
                    cmd = [CLANG_PATH, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm"] + flags + [src_p, "-o", tu_ir]
                    r = subprocess.run(cmd, capture_output=True, text=True)
                    if r.returncode != 0 or not os.path.isfile(tu_ir):
                        self._last_compiler_error = r.stderr or r.stdout
                        return False
                    tu_ir_files.append(tu_ir)

                if LLVM_LINK_PATH and os.path.isfile(LLVM_LINK_PATH):
                    cmd_link = [LLVM_LINK_PATH, "-S"] + tu_ir_files + ["-o", self.ir_path]
                    r_link = subprocess.run(cmd_link, capture_output=True, text=True)
                    if r_link.returncode == 0 and os.path.isfile(self.ir_path):
                        return True
                    else:
                        self._last_compiler_error = r_link.stderr or r_link.stdout

                # Fallback if llvm-link is absent: aggregate feature vectors across TUs
                self._tu_features = [self.extract_features(p) for p in tu_ir_files]
                with open(self.ir_path, "w", encoding="utf-8") as f_out:
                    for p in tu_ir_files:
                        with open(p, "r", encoding="utf-8", errors="replace") as f_in:
                            f_out.write(f"; --- TU: {p} ---\n" + f_in.read() + "\n")
                return os.path.isfile(self.ir_path)
            except Exception as exc:
                self._last_compiler_error = str(exc)
                if hasattr(self, "ir_path") and os.path.exists(self.ir_path):
                    try:
                        os.remove(self.ir_path)
                    except OSError:
                        pass
                return False
                return False

    def extract_features(self, ir_file):
        # Using a simplified version of the existing feature extractor
        features = {
            "BasicBlocksCount": 0, "InstructionsCount": 0, "BranchCount": 0,
            "MemInstCount": 0, "MathInstCount": 0, "FloatInstCount": 0,
            "VectorInstCount": 0, "CallInstCount": 0
        }
        if not os.path.exists(ir_file): return np.zeros(8)
        
        try:
            with open(ir_file, 'r') as f:
                for line in f:
                    line = line.split(';')[0].strip()
                    if not line: continue
                    if re.match(r"^[a-zA-Z0-9_.]+:$", line): features["BasicBlocksCount"] += 1
                    parts = line.split()
                    if not parts: continue
                    op = parts[0]
                    if len(parts) >= 3 and parts[1] == "=": op = parts[2]
                    
                    if op in ['br', 'switch']: features["BranchCount"] += 1
                    elif op in ['alloca', 'load', 'store', 'getelementptr']: features["MemInstCount"] += 1
                    elif op in ['add', 'sub', 'mul', 'udiv', 'sdiv', 'urem', 'srem', 'shl', 'lshr', 'ashr', 'and', 'or', 'xor']: features["MathInstCount"] += 1
                    elif op in ['fadd', 'fsub', 'fmul', 'fdiv', 'frem', 'fneg']: features["FloatInstCount"] += 1
                    elif op in ['extractelement', 'insertelement', 'shufflevector']: features["VectorInstCount"] += 1
                    elif op in ['call', 'invoke']: features["CallInstCount"] += 1
                    features["InstructionsCount"] += 1
        except: pass
        return np.array(list(features.values()), dtype=np.float32)

    def step(self, action_idx):
        action = ACTIONS[action_idx]
        workdir = getattr(self, "workdir", None) or os.getcwd()
        opt_ir = getattr(self, "opt_ir", os.path.join(workdir, "temp_opt.ll"))
        opt_exe = getattr(self, "opt_exe", os.path.join(workdir, "temp_opt.exe"))
        
        is_multi = hasattr(self, "project") and self.project.is_multi_file
        if is_multi:
            from moo.config import LLVM_LINK_PATH, OPT_PATH
            eff_cfg = self.project.get_effective_build_config()
            flags = eff_cfg.to_clang_args()
            sources = self.project.get_absolute_source_paths()

            if action.startswith("-O"):
                tu_opt_files = []
                for idx, src_p in enumerate(sources):
                    tu_opt = os.path.join(self.workdir, f"tu_{idx}_opt.ll")
                    cmd = [CLANG_PATH, action, "-S", "-emit-llvm"] + flags + [src_p, "-o", tu_opt]
                    r_tu = subprocess.run(cmd, capture_output=True, text=True)
                    if r_tu.returncode != 0:
                        self._last_compiler_error = r_tu.stderr or r_tu.stdout
                    if os.path.isfile(tu_opt):
                        tu_opt_files.append(tu_opt)
                if LLVM_LINK_PATH and os.path.isfile(LLVM_LINK_PATH) and len(tu_opt_files) == len(sources):
                    cmd_link = [LLVM_LINK_PATH, "-S"] + tu_opt_files + ["-o", opt_ir]
                    r_link = subprocess.run(cmd_link, capture_output=True, text=True)
                    if r_link.returncode != 0:
                        self._last_compiler_error = r_link.stderr or r_link.stdout
            else:
                opt_bin = OPT_PATH or "opt"
                cmd = [opt_bin, f"-passes={action}", self.ir_path, "-S", "-o", opt_ir]
                r_opt = subprocess.run(cmd, capture_output=True, text=True)
                if r_opt.returncode != 0:
                    self._last_compiler_error = r_opt.stderr or r_opt.stdout

            if os.path.exists(opt_ir):
                cmd_exe = [CLANG_PATH, opt_ir] + eff_cfg.get_linker_flags() + ["-o", opt_exe]
                r_exe = subprocess.run(cmd_exe, capture_output=True, text=True)
                if r_exe.returncode != 0:
                    self._last_compiler_error = r_exe.stderr or r_exe.stdout
            elif not os.path.exists(opt_exe):
                cmd_exe = [CLANG_PATH, action] + flags + eff_cfg.get_linker_flags() + sources + ["-o", opt_exe]
                r_exe = subprocess.run(cmd_exe, capture_output=True, text=True)
                if r_exe.returncode != 0:
                    self._last_compiler_error = r_exe.stderr or r_exe.stdout
        else:
            # Single-file optimization
            eff_cfg = self.project.get_effective_build_config() if hasattr(self, "project") else None
            flags = eff_cfg.to_clang_args() if eff_cfg else (self.build_config.to_clang_args() if getattr(self, "build_config", None) else [])
            linker_flags = eff_cfg.get_linker_flags() if eff_cfg else (self.build_config.get_linker_flags() if getattr(self, "build_config", None) and hasattr(self.build_config, "get_linker_flags") else [])

            if action.startswith("-O"):
                cmd = [CLANG_PATH, action, "-S", "-emit-llvm"] + flags + [self.benchmark_path, "-o", opt_ir]
                r_c = subprocess.run(cmd, capture_output=True, text=True)
                if r_c.returncode != 0:
                    self._last_compiler_error = r_c.stderr or r_c.stdout
            else:
                temp_unopt = getattr(self, "step_unopt", os.path.join(workdir, "temp_unopt_step.ll"))
                cmd1 = [CLANG_PATH, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm"] + flags + [self.benchmark_path, "-o", temp_unopt]
                r1 = subprocess.run(cmd1, capture_output=True, text=True)
                if r1.returncode != 0:
                    self._last_compiler_error = r1.stderr or r1.stdout
                cmd = [CLANG_PATH, "-S", "-emit-llvm", "-mllvm", f"-passes={action}", temp_unopt, "-o", opt_ir]
                r2 = subprocess.run(cmd, capture_output=True, text=True)
                if r2.returncode != 0:
                    self._last_compiler_error = r2.stderr or r2.stdout
                if os.path.exists(temp_unopt): os.remove(temp_unopt)
            
            # Compile to executable to measure time
            if os.path.exists(opt_ir):
                cmd_exe = [CLANG_PATH, opt_ir] + linker_flags + ["-o", opt_exe]
                r_exe = subprocess.run(cmd_exe, capture_output=True, text=True)
                if r_exe.returncode != 0:
                    self._last_compiler_error = r_exe.stderr or r_exe.stdout
            elif not os.path.exists(opt_exe):
                cmd_exe = [CLANG_PATH, action] + flags + linker_flags + [self.benchmark_path, "-o", opt_exe]
                r_exe = subprocess.run(cmd_exe, capture_output=True, text=True)
                if r_exe.returncode != 0:
                    self._last_compiler_error = r_exe.stderr or r_exe.stdout
        
        # Measure Performance
        exec_time = 1.0 # default
        code_size = 1e9 # default
        stdout = ""
        stderr = ""
        returncode = None
        timed_out = False
        build_ok = os.path.exists(opt_exe)
        
        if build_ok:
            start = time.time()
            to_val = getattr(self, "timeout", 5) or 5
            try:
                proc = subprocess.run([opt_exe], capture_output=True, text=True, timeout=to_val)
                exec_time = time.time() - start
                returncode = proc.returncode
                stdout = proc.stdout
                stderr = proc.stderr
            except subprocess.TimeoutExpired:
                timed_out = True
                exec_time = float(to_val)
            except Exception as e:
                exec_time = float(to_val)
            try:
                code_size = os.path.getsize(opt_exe)
            except OSError:
                pass
        
        # Security Check
        security_violated = False
        if os.path.exists(opt_ir) and hasattr(self, "benchmark_path") and "security_checks.c" in str(self.benchmark_path):
            with open(opt_ir, 'r') as f:
                ir_content = f.read()
                if "assert_failed" not in ir_content:
                    security_violated = True
        
        # Reward function
        reward = (1.0 / (exec_time + 0.001)) + (10000.0 / (code_size + 1))
        if security_violated:
            reward -= 1000.0
            
        info = {
            "build_ok": build_ok,
            "returncode": returncode,
            "stdout": stdout,
            "stderr": stderr,
            "timed_out": timed_out,
            "compiler_error": getattr(self, "_last_compiler_error", ""),
            "exec_time": exec_time,
            "code_size": code_size,
        }
        return self.features, reward, True, info

def train():
    print("Initializing RL Training...")
    benchmarks = ["loops_branches.c", "security_checks.c", "math_heavy.c"]
    # Filter only existing benchmarks
    benchmarks = [b for b in benchmarks if os.path.exists(os.path.join("Codes/test_cases", b))]
    if not benchmarks:
        # Fallback to current directory if not found in test_cases
        benchmarks = [b for b in ["loops_branches.c", "security_checks.c", "math_heavy.c"] if os.path.exists(b)]

    if not benchmarks:
        print("No benchmarks found for training.")
        return

    model = DQN(8, len(ACTIONS))
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.MSELoss()

    for epoch in range(10):
        total_reward = 0
        for b in benchmarks:
            env = CompilerEnv(b)
            state = torch.FloatTensor(env.features)
            
            # Epsilon-greedy (simplified)
            q_values = model(state)
            action_idx = torch.argmax(q_values).item()
            
            _, reward, done, _ = env.step(action_idx)
            
            # Simple Q-learning update
            target = torch.tensor(reward, dtype=torch.float32)
            loss = criterion(q_values[action_idx], target)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_reward += reward
        print(f"Epoch {epoch+1}, Total Reward: {total_reward:.2f}")

    torch.save(model.state_dict(), "ml_optimizer_model.pth")
    print("Model saved to ml_optimizer_model.pth")

if __name__ == "__main__":
    # Ensure we are in the right directory or use relative paths correctly
    train()
