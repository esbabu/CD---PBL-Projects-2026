import os
import torch
import subprocess
import sys
import re
from ml_optimizer import DQN, ACTIONS, CLANG_PATH, CompilerEnv

MODEL_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "ml_optimizer_model.pth"
)

OPT_PATH = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"


from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class SelectionResultWithProvenance:
    """Provenance-aware optimization selection record."""
    strategy: str
    provenance: str
    model_id: str
    q_value_selected: Optional[float]
    q_value_argmax: Optional[float]
    q_rank: List[Tuple[str, float]] = field(default_factory=list)
    decision_trace: Optional[Any] = None
    xai_result: Optional[Any] = None
    frontier: List[str] = field(default_factory=list)
    moo_active: bool = False
    filtered_out: List[str] = field(default_factory=list)
    ir_features: Optional[Dict[str, float]] = None
    selection_metadata: Dict[str, Any] = field(default_factory=dict)


def select_with_provenance(c_file_path, *, allow_moo=True, features=None, model_family="dqn", linucb_ledger=None, linucb_scaler=None, linucb_config=None, eligible_actions=None, build_config=None):
    """
    Select best optimization with full provenance, Q/UCB-values, DecisionTrace, and XAI.

    Supports both:
    - model_family="dqn": historical comparison baseline (DQN checkpoint)
    - model_family="linucb": adaptive disjoint LinUCB with cold-start priority and SQLite persistence
    """
    from moo.project import CProject
    if isinstance(c_file_path, CProject):
        if not os.path.exists(c_file_path.project_root):
            return None
    elif not os.path.exists(c_file_path):
        return None

    raw_feats = None
    if features is not None:
        raw_feats = list(features)
    else:
        try:
            from moo.ir_cache import compute_source_hash, get_cached_raw_features
            sha = compute_source_hash(c_file_path, build_config=build_config)
            cached_raw = get_cached_raw_features(sha)
            if cached_raw is not None:
                raw_feats = list(cached_raw)
        except Exception:
            pass

    if raw_feats is None:
        try:
            env = CompilerEnv(c_file_path, build_config=build_config)
            raw_feats = env.features.tolist() if hasattr(env.features, "tolist") else list(env.features)
        except Exception as exc:
            print(f"Error extracting features: {exc}")
            return None

    from moo.generalization import adapt_features_for_inference
    adapted_feats = adapt_features_for_inference(raw_feats)
    state = torch.FloatTensor(adapted_feats)

    if str(model_family).lower() == "linucb":
        from moo.bandit import SQLiteEvaluationLedger, LinUCBFeatureScaler
        from moo.bandit.config import (
            load_linucb_deployment_config,
            verify_linucb_scaler_integrity,
            verify_and_load_linucb_scaler,
            verify_linucb_checkpoint_integrity,
        )

        deploy_cfg = linucb_config or load_linucb_deployment_config()

        # Resolve scaler path
        p = os.path.abspath(os.path.dirname(__file__))
        scaler_path = None
        while p and os.path.dirname(p) != p:
            cand = os.path.join(p, "data", "models", "linucb_feature_scaler.json")
            if os.path.exists(cand):
                scaler_path = cand
                break
            p = os.path.dirname(p)
        if not scaler_path or not os.path.exists(scaler_path):
            raise FileNotFoundError("linucb_feature_scaler.json not found")

        # 1. Unified Scaler Verification & Loading from identical byte buffer (no TOCTOU gap)
        if linucb_scaler is None:
            linucb_scaler = verify_and_load_linucb_scaler(scaler_path, deploy_cfg.expected_scaler_sha256)
        else:
            # If an external scaler was passed in, verify the authoritative file hash
            verify_linucb_scaler_integrity(scaler_path, deploy_cfg.expected_scaler_sha256)

        context = linucb_scaler.transform(adapted_feats)

        # 2. Load Checkpoint and verify Checkpoint Integrity before applying deployment alpha
        ledger = linucb_ledger or SQLiteEvaluationLedger()
        bandit_model = ledger.get_active_model()
        verify_linucb_checkpoint_integrity(
            bandit_model,
            deploy_cfg.expected_checkpoint_version,
            deploy_cfg.expected_checkpoint_sha256,
        )

        # 3. Apply deployment parameters to the verified instance (no TOCTOU gap)
        bandit_model.alpha = deploy_cfg.alpha
        bandit_model.reg_lambda = deploy_cfg.reg_lambda

        # 4. Perform action selection on verified instance
        sel_res = bandit_model.select_action(context, eligible_actions=eligible_actions)

        action_idx = sel_res["selected_action_idx"]
        model_id = f"linucb_v{bandit_model.version}"
        q_val_argmax = float(sel_res["ucb_score_selected"])
        q_vals_list = [float(sel_res["all_scores"][i]) for i in range(len(ACTIONS))]
        q_rank = [
            (item["strategy"], float(item["ucb_score"]))
            for item in sel_res["eligible_rankings"]
        ]
        provenance = "LINUCB_COLD_START" if sel_res["selection_method"] == "COLD_START_PRIORITY" else "LINUCB_UCB"
    else:
        model = DQN(8, len(ACTIONS))
        model_id = "production_v0"

        if os.path.exists(MODEL_PATH):
            model.load_state_dict(torch.load(MODEL_PATH, weights_only=True))
        else:
            print(f"Error: {MODEL_PATH} not found.")
            return None

        model.eval()

        with torch.no_grad():
            q_values = model(state)
            action_idx = torch.argmax(q_values).item()

        q_vals_list = q_values.tolist()
        q_val_argmax = float(q_vals_list[action_idx])
        q_rank = sorted(
            zip(ACTIONS, [float(q) for q in q_vals_list]),
            key=lambda pair: pair[1],
            reverse=True,
        )
        provenance = "DQN_ARGMAX"

    try:
        from moo.xai import format_ir_features
        feats_dict = format_ir_features(raw_feats)
    except Exception:
        feats_dict = {f"feat_{i}": float(v) for i, v in enumerate(raw_feats)}

    trace = None
    frontier = []
    moo_active = False
    filtered_out = []

    if allow_moo:
        try:
            import sys
            import os as _os
            _moo_parent = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
            if _moo_parent not in sys.path:
                sys.path.insert(0, _moo_parent)

            from moo.selector_bridge import (
                moo_aware_select_with_trace,
                _load_report_for_trace,
            )

            c_path_str = getattr(c_file_path, "project_root", None) or getattr(c_file_path, "primary_source", None) or str(c_file_path)
            report_data = _load_report_for_trace(c_path_str)
            frontier = list(report_data.get("pareto_frontier", [])) if report_data else []

            result, trace = moo_aware_select_with_trace(
                c_path_str,
                q_vals_list,
                ACTIONS,
                frontier,
                report_data=report_data,
                ir_features=raw_feats,
            )
            print(f"[MOO-aware selector] {result.reason}")
            if result.filtered_out:
                print(f"[MOO-aware selector] MOO filtered: {result.filtered_out}")

            strategy = result.strategy
            moo_active = bool(result.moo_active)
            filtered_out = list(result.filtered_out)

            if moo_active:
                provenance = "LINUCB_MOO" if str(model_family).lower() == "linucb" else "DQN_MOO"
            elif trace and trace.selection_method in (
                "argmax_fallback_no_frontier",
                "argmax_fallback_frontier_mismatch",
            ):
                if str(model_family).lower() != "linucb":
                    provenance = "DQN_ARGMAX"
            elif trace and trace.selection_method == "argmax_fallback_exception":
                provenance = "FALLBACK"

        except Exception as _moo_exc:  # noqa: BLE001
            print(f"[MOO-aware selector] MOO unavailable ({_moo_exc}); using original AI selection.")
            strategy = ACTIONS[action_idx]
            trace = None
            provenance = "FALLBACK"
    else:
        strategy = ACTIONS[action_idx]

    # Find Q-value for selected strategy
    q_value_selected = q_val_argmax
    for s, q in q_rank:
        if s == strategy:
            q_value_selected = q
            break

    # Build transparent selection metadata (no speedup fabrication, strict mathematical names)
    if str(model_family).lower() == "linucb":
        rec_action = sel_res["selected_strategy"]
        rec_action_idx = sel_res["selected_action_idx"]
        chosen_idx = ACTIONS.index(strategy) if strategy in ACTIONS else rec_action_idx
        matching_rank = None
        for item in sel_res.get("eligible_rankings", []):
            if item.get("action_idx") == chosen_idx or item.get("strategy") == strategy:
                matching_rank = item
                break

        if matching_rank:
            pred_rew = float(matching_rank["predicted_reward"])
            uncert = float(matching_rank["uncertainty"])
            u_score = float(matching_rank["ucb_score"])
        else:
            pred_rew = float(sel_res["predicted_reward_selected"])
            uncert = float(sel_res["uncertainty_selected"])
            u_score = float(sel_res["ucb_score_selected"])

        alpha_val = float(sel_res.get("alpha", 1.0))
        bonus_val = alpha_val * uncert
        moo_influenced = bool(moo_active and strategy != rec_action)

        if moo_active:
            sel_pol = "moo_pareto"
        elif sel_res.get("selection_method") == "COLD_START_PRIORITY":
            sel_pol = "cold_start"
        else:
            sel_pol = "linucb_ucb"

        obs_count = int(bandit_model.counts[chosen_idx]) if chosen_idx < len(bandit_model.counts) else 0

        selection_metadata = {
            "model_family": "LinUCB",
            "selected_action": strategy,
            "selected_action_idx": chosen_idx,
            "recommended_action": rec_action,
            "recommended_action_idx": rec_action_idx,
            "moo_influenced": moo_influenced,
            "predicted_reward": pred_rew,
            "exploration_bonus": bonus_val,
            "ucb_score": u_score,
            "selection_policy": sel_pol,
            "alpha": alpha_val,
            "observation_count": obs_count,
            "all_arm_scores": [
                {
                    "action_idx": item["action_idx"],
                    "strategy": item["strategy"],
                    "predicted_reward": float(item["predicted_reward"]),
                    "exploration_bonus": float(sel_res.get("alpha", 1.0)) * float(item["uncertainty"]),
                    "ucb_score": float(item["ucb_score"]),
                }
                for item in sel_res.get("eligible_rankings", [])
            ] if "eligible_rankings" in sel_res else [],
        }
    else:
        rec_action = ACTIONS[action_idx] if action_idx < len(ACTIONS) else strategy
        rec_action_idx = action_idx
        chosen_idx = ACTIONS.index(strategy) if strategy in ACTIONS else 0
        moo_influenced = bool(moo_active and strategy != rec_action)
        sel_pol = "moo_pareto" if moo_active else "dqn_argmax"
        selection_metadata = {
            "model_family": "DQN",
            "selected_action": strategy,
            "selected_action_idx": chosen_idx,
            "recommended_action": rec_action,
            "recommended_action_idx": rec_action_idx,
            "moo_influenced": moo_influenced,
            "predicted_reward": float(q_value_selected),
            "exploration_bonus": 0.0,
            "ucb_score": float(q_value_selected),
            "selection_policy": sel_pol,
            "alpha": 0.0,
            "observation_count": 0,
        }

    # Attach informational profile
    if trace is not None:
        try:
            from moo.program_profiler import profile_program
            prof = profile_program(raw_feats)
            trace.program_profile = prof.to_dict() if prof is not None else None
        except Exception:
            trace.program_profile = None

    # Attach informational XAI
    xai_res = None
    if trace is not None:
        try:
            xai_res = trace.to_xai_result()
        except Exception:
            xai_res = None

    return SelectionResultWithProvenance(
        strategy=strategy,
        provenance=provenance,
        model_id=model_id,
        q_value_selected=q_value_selected,
        q_value_argmax=q_val_argmax,
        q_rank=q_rank,
        decision_trace=trace,
        xai_result=xai_res,
        frontier=frontier,
        moo_active=moo_active,
        filtered_out=filtered_out,
        ir_features=feats_dict,
        selection_metadata=selection_metadata,
    )


def get_best_optimization(c_file_path, *, return_trace=False, return_xai=False):
    sel = select_with_provenance(c_file_path)
    if sel is None:
        if return_trace and return_xai:
            return (None, None, None)
        if return_trace or return_xai:
            return (None, None)
        return None

    if return_trace and return_xai:
        return sel.strategy, sel.decision_trace, sel.xai_result
    if return_xai:
        return sel.strategy, sel.xai_result
    if return_trace:
        return sel.strategy, sel.decision_trace
    return sel.strategy


def get_best_optimization_with_xai(c_file_path):
    """Convenience helper returning (strategy, xai_result)."""
    return get_best_optimization(c_file_path, return_xai=True)


def apply_optimization(input_c, output_ll, action):
    print(f"Applying AI-Selected Optimization: {action}")

    if action.startswith("-O"):
        result = subprocess.run(
            [
                CLANG_PATH,
                action,
                "-S",
                "-emit-llvm",
                input_c,
                "-o",
                output_ll
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            print("Optimization failed:")
            print(result.stderr)
            return False

    else:
        temp_unopt = "temp_unopt_selector.ll"

        result = subprocess.run(
            [
                CLANG_PATH,
                "-O0",
                "-Xclang",
                "-disable-O0-optnone",
                "-S",
                "-emit-llvm",
                input_c,
                "-o",
                temp_unopt
            ],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            print("Failed to generate unoptimized IR:")
            print(result.stderr)
            return False

        cmd = [
            OPT_PATH,
            f"-passes={action}",
            temp_unopt,
            "-S",
            "-o",
            output_ll
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            print(f"Custom optimization failed: {action}")
            print(result.stderr)

            if os.path.exists(temp_unopt):
                os.remove(temp_unopt)

            return False

        if os.path.exists(temp_unopt):
            os.remove(temp_unopt)

    if not os.path.exists(output_ll):
        print("Error: Optimized IR was not created.")
        return False

    print(f"Optimization successful: {action}")
    return True


def main():
    if len(sys.argv) < 2:
        print("Usage: python optimization_selector.py <input_c_file>")
        return

    input_c = sys.argv[1]

    if not os.path.exists(input_c):
        print(f"Error: {input_c} not found.")
        return

    output_ll = os.path.splitext(input_c)[0] + "_ai_opt.ll"

    best_action = get_best_optimization(input_c)

    if best_action is None:
        return

    success = apply_optimization(input_c, output_ll, best_action)

    if success:
        print(f"Optimized IR saved to {output_ll}")
    else:
        print("Optimization was not completed.")


if __name__ == "__main__":
    main()