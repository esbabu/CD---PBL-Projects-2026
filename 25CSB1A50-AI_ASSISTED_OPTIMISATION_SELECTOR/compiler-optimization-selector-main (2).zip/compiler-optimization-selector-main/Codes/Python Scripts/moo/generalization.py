"""
moo.generalization — Deterministic Inference-Time Feature Adaptation for General C Programs.

Part of TOACD Phase 2B: Model & Profiler Generalization Adaptation.

Addresses LIMIT-ML-03 & LIMIT-ML-04:
- Out-of-distribution programs with large instruction counts (>500 instructions)
  can cause Q-value explosion in DQN and hypercube corner saturation in LinUCB.
- This adapter performs deterministic proportional scaling to preserve exact
  feature ratios (densities) while keeping input magnitudes within the original
  training distribution manifold.
- Bit-for-bit identity is strictly guaranteed for in-distribution programs
  (InstructionsCount <= 500).
- Does NOT alter frozen DQN weights, LinUCB checkpoint, or scaler artifacts.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Union
import numpy as np

# Upper bound calibrated to the original training distribution's non-trivial programs.
# gemm.c is 470 instructions; 500.0 provides safe headroom while keeping in-distribution
# programs completely untouched.
IN_DISTRIBUTION_MAX_INSTRUCTIONS: float = 500.0

CANONICAL_FEATURE_ORDER = [
    "BasicBlocksCount",
    "InstructionsCount",
    "BranchCount",
    "MemInstCount",
    "MathInstCount",
    "FloatInstCount",
    "VectorInstCount",
    "CallInstCount",
]


def adapt_features_for_inference(
    raw_features: Union[Sequence[float], np.ndarray, Dict[str, float]],
    max_instructions: float = IN_DISTRIBUTION_MAX_INSTRUCTIONS,
) -> List[float]:
    """
    Deterministic inference-time feature adapter for out-of-distribution programs.

    Parameters
    ----------
    raw_features     : Sequence, ndarray, or dict of the 8 canonical IR features.
    max_instructions : Maximum instruction count before proportional scaling engages.

    Returns
    -------
    List[float] of 8 adapted features ready for model inference.

    Invariants:
    1. If InstructionsCount <= max_instructions: returns raw_features bit-for-bit unchanged.
    2. If InstructionsCount > max_instructions: scales all 8 features by
       (max_instructions / InstructionsCount), preserving exact feature densities.
    3. Handles zero, negative, or incomplete inputs safely without raising exceptions.
    """
    if isinstance(raw_features, dict):
        vec = [float(raw_features.get(name, 0.0)) for name in CANONICAL_FEATURE_ORDER]
    elif isinstance(raw_features, np.ndarray):
        vec = [float(x) for x in raw_features.flatten()[:8]]
    elif isinstance(raw_features, (list, tuple)):
        vec = [float(x) for x in raw_features[:8]]
    else:
        vec = [0.0] * 8

    # Pad if fewer than 8 features
    while len(vec) < 8:
        vec.append(0.0)

    inst_count = float(vec[1])  # InstructionsCount is index 1

    # In-distribution check: pass through bit-for-bit unchanged
    if inst_count <= max_instructions or inst_count <= 0.0:
        return vec

    scale = max_instructions / inst_count
    return [float(x * scale) for x in vec]


def compute_derived_density_metrics(
    raw_features: Union[Sequence[float], np.ndarray, Dict[str, float]],
) -> Dict[str, float]:
    """
    Computes human-interpretable and deterministic instruction density metrics
    from canonical raw features.

    Returns dictionary with densities in [0.0, 1.0].
    """
    if isinstance(raw_features, dict):
        vec = [float(raw_features.get(name, 0.0)) for name in CANONICAL_FEATURE_ORDER]
    elif isinstance(raw_features, np.ndarray):
        vec = [float(x) for x in raw_features.flatten()[:8]]
    elif isinstance(raw_features, (list, tuple)):
        vec = [float(x) for x in raw_features[:8]]
    else:
        vec = [0.0] * 8

    while len(vec) < 8:
        vec.append(0.0)

    bb_count = float(vec[0])
    inst_count = max(float(vec[1]), 1.0)
    branch_count = float(vec[2])
    mem_count = float(vec[3])
    math_count = float(vec[4])
    float_count = float(vec[5])
    vector_count = float(vec[6])
    call_count = float(vec[7])

    compute_total = math_count + float_count

    return {
        "branch_density": round(branch_count / inst_count, 6),
        "compute_density": round(compute_total / inst_count, 6),
        "mem_density": round(mem_count / inst_count, 6),
        "call_density": round(call_count / inst_count, 6),
        "math_density": round(math_count / inst_count, 6),
        "float_density": round(float_count / inst_count, 6),
        "vector_density": round(vector_count / inst_count, 6),
        "basic_block_density": round(bb_count / inst_count, 6),
    }
