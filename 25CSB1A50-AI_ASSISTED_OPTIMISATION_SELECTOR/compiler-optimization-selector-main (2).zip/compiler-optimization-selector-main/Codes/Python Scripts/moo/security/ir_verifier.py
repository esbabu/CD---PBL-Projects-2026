"""
moo.security.ir_verifier — Whole-Module LLVM IR Security Attribute & Heuristic Verifier.

Stage 12 Implementation:
- Scans all defined functions in LLVM IR (.ll) modules.
- Maps functions to their attribute groups (#N).
- Verifies policy attributes (sspstrong for Strong, sspreq for All).
- Detects explicit exclusions (no_stack_protector).
- Scans function bodies for stack arrays (alloca [N x ...]) to audit vulnerable routines.
- Evaluates whole-program coverage metrics without assuming pure register/leaf
  functions must contain stack canaries.
"""

from __future__ import annotations

import dataclasses
from enum import Enum
import os
import re
from typing import Any, Dict, List, Optional, Set, Tuple


class IRVerificationVerdict(str, Enum):
    """Structured verdict for LLVM IR security verification."""
    PASS = "PASS"
    INCONCLUSIVE = "INCONCLUSIVE"
    PROFILE_VIOLATION = "PROFILE_VIOLATION"


@dataclasses.dataclass
class FunctionSecurityInfo:
    """Security attributes and structural risk indicators for an individual IR function."""
    name: str
    attribute_group_id: Optional[str] = None
    attributes: Set[str] = dataclasses.field(default_factory=set)
    has_target_attribute: bool = False
    has_explicit_exclusion: bool = False
    has_stack_array_alloca: bool = False
    has_escaped_alloca: bool = False
    array_alloca_types: List[str] = dataclasses.field(default_factory=list)

    @property
    def is_vulnerable_candidate(self) -> bool:
        """True if function allocates an array or takes address of a local object."""
        return self.has_stack_array_alloca or self.has_escaped_alloca

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "attribute_group_id": self.attribute_group_id,
            "attributes": sorted(list(self.attributes)),
            "has_target_attribute": self.has_target_attribute,
            "has_explicit_exclusion": self.has_explicit_exclusion,
            "has_stack_array_alloca": self.has_stack_array_alloca,
            "has_escaped_alloca": self.has_escaped_alloca,
            "array_alloca_types": list(self.array_alloca_types),
            "is_vulnerable_candidate": self.is_vulnerable_candidate,
        }


@dataclasses.dataclass
class ModuleIRVerificationResult:
    """Whole-module security verification report for an LLVM IR artifact."""
    ir_path: str
    target_policy: str                       # e.g. "sspstrong" or "sspreq"
    verdict: IRVerificationVerdict
    total_defined_functions: int = 0
    functions_with_attribute: int = 0
    explicitly_excluded_functions: int = 0
    attribute_coverage_ratio: float = 0.0
    vulnerable_candidates_detected: int = 0
    vulnerable_candidates_protected: int = 0
    unprotected_vulnerable_functions: List[str] = dataclasses.field(default_factory=list)
    unexpected_omissions: List[str] = dataclasses.field(default_factory=list)
    functions: Dict[str, FunctionSecurityInfo] = dataclasses.field(default_factory=dict)
    limitations: List[str] = dataclasses.field(default_factory=list)
    notes: List[str] = dataclasses.field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ir_path": self.ir_path,
            "target_policy": self.target_policy,
            "verdict": self.verdict.value,
            "summary": {
                "total_defined_functions": self.total_defined_functions,
                "functions_with_attribute": self.functions_with_attribute,
                "explicitly_excluded_functions": self.explicitly_excluded_functions,
                "attribute_coverage_ratio": round(self.attribute_coverage_ratio, 4),
                "vulnerable_candidates_detected": self.vulnerable_candidates_detected,
                "vulnerable_candidates_protected": self.vulnerable_candidates_protected,
            },
            "unprotected_vulnerable_functions": list(self.unprotected_vulnerable_functions),
            "unexpected_omissions": list(self.unexpected_omissions),
            "limitations": list(self.limitations),
            "notes": list(self.notes),
            "functions": {k: v.to_dict() for k, v in self.functions.items()},
        }


# ---------------------------------------------------------------------------
# IR Regex Patterns
# ---------------------------------------------------------------------------

# Match function definition header up to opening brace:
# Group 1: Function symbol name (with or without quotes)
# Group 2: Signature tail between closing parenthesis and opening brace
_FUNC_DEF_REGEX = re.compile(
    r"^define\s+[^@\n]*@([a-zA-Z0-9_$.\x22]+)\s*\((?:[^)]|\n)*?\)([^{]*)\{",
    re.MULTILINE,
)

# Match attribute group definition: attributes #0 = { ... }
_ATTR_GROUP_REGEX = re.compile(
    r"^attributes\s+#(\d+)\s*=\s*\{([^}]+)\}",
    re.MULTILINE,
)

# Match stack array alloca: %3 = alloca [16 x i8], align 1
_ARRAY_ALLOCA_REGEX = re.compile(
    r"alloca\s+\[\s*\d+\s*x\s+[^\]]+\]",
)


# ---------------------------------------------------------------------------
# Verifier Engine
# ---------------------------------------------------------------------------

def verify_module_stack_protector(
    ir_path_or_content: str,
    target_attribute: str = "sspstrong",
    is_path: bool = True,
) -> ModuleIRVerificationResult:
    """
    Parses LLVM IR and performs whole-module stack-protector verification.

    Parameters:
        ir_path_or_content: File path to .ll file or raw IR text content.
        target_attribute: Expected function attribute ("sspstrong", "sspreq", or "ssp").
        is_path: True if ir_path_or_content is a file path, False if raw string.

    Returns:
        ModuleIRVerificationResult with structured findings and metrics.
    """
    ir_path = ir_path_or_content if is_path else "<in_memory>"
    content = ""

    if is_path:
        if not os.path.isfile(ir_path_or_content):
            res = ModuleIRVerificationResult(
                ir_path=ir_path,
                target_policy=target_attribute,
                verdict=IRVerificationVerdict.PROFILE_VIOLATION,
            )
            res.notes.append(f"IR file not found: {ir_path_or_content}")
            return res
        try:
            with open(ir_path_or_content, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as exc:
            res = ModuleIRVerificationResult(
                ir_path=ir_path,
                target_policy=target_attribute,
                verdict=IRVerificationVerdict.PROFILE_VIOLATION,
            )
            res.notes.append(f"Failed to read IR file: {exc}")
            return res
    else:
        content = ir_path_or_content

    # 1. Parse all attribute groups: #0 -> set of attribute strings
    attr_groups: Dict[str, Set[str]] = {}
    for m in _ATTR_GROUP_REGEX.finditer(content):
        group_id = m.group(1)
        raw_attrs = m.group(2)
        # Parse space-separated attributes, key-value pairs, and individual words
        tokens = set(re.findall(r'[a-zA-Z0-9_\-]+(?:\s*=\s*(?:"[^"]*"|[^\s]+))?', raw_attrs))
        words = set(re.findall(r'\b[a-zA-Z0-9_\-]+\b', raw_attrs))
        attr_groups[group_id] = tokens.union(words)

    # 2. Extract function bodies and map attributes
    functions: Dict[str, FunctionSecurityInfo] = {}
    func_matches = list(_FUNC_DEF_REGEX.finditer(content))

    for idx, match in enumerate(func_matches):
        fn_name = match.group(1).strip('"')
        header_tail = match.group(2)
        start_pos = match.end()

        # Find closing brace of function body
        end_pos = len(content)
        if idx + 1 < len(func_matches):
            end_pos = func_matches[idx + 1].start()

        body_slice = content[start_pos:end_pos]
        brace_end = body_slice.find("\n}")
        if brace_end != -1:
            body_slice = body_slice[:brace_end]

        # Extract attribute group IDs (e.g. #0) and direct words in header tail
        attr_group_ids = re.findall(r"#(\d+)", header_tail)
        direct_attrs = set(re.findall(r"\b[a-zA-Z0-9_\-]+\b", header_tail))

        assigned_attrs: Set[str] = set(direct_attrs)
        for gid in attr_group_ids:
            assigned_attrs.update(attr_groups.get(gid, set()))

        primary_group_id = attr_group_ids[0] if attr_group_ids else None

        has_target = target_attribute in assigned_attrs
        # Detect any ssp variant if target attribute is not matched
        has_any_ssp = any("ssp" in a for a in assigned_attrs)
        # An explicit exclusion is when a function has attribute group without any ssp attribute or no_stack_protector
        has_exclusion = "no_stack_protector" in assigned_attrs or bool(attr_group_ids and not has_any_ssp)

        # Scan function body for array allocas
        array_matches = _ARRAY_ALLOCA_REGEX.findall(body_slice)
        has_array_alloca = len(array_matches) > 0

        # Scan for escaped local address by linking allocas to call arguments:
        local_allocas = re.findall(r"(%[a-zA-Z0-9_$.]+)\s*=\s*alloca\b", body_slice)

        # Track 1-level derived pointers: %derived = getelementptr ... %source or %derived = bitcast ... %source
        derived_map: Dict[str, str] = {}
        for m in re.finditer(r"(%[a-zA-Z0-9_$.]+)\s*=\s*(?:getelementptr|bitcast)\b[^;\n]*[ (,\t](%[a-zA-Z0-9_$.]+)", body_slice):
            derived_map[m.group(1)] = m.group(2)

        escaped_allocas: List[str] = []
        for v in local_allocas:
            aliases = {v}
            for d, src in derived_map.items():
                if src == v:
                    aliases.add(d)

            escaped = False
            for alias in aliases:
                pat = rf"(?:call|invoke)\s+[^;\n=]*[ (,\t]{re.escape(alias)}(?=[),\s]|$)"
                if re.search(pat, body_slice):
                    escaped = True
                    break
            if escaped:
                escaped_allocas.append(v)

        has_escaped = len(escaped_allocas) > 0

        fn_info = FunctionSecurityInfo(
            name=fn_name,
            attribute_group_id=primary_group_id,
            attributes=assigned_attrs,
            has_target_attribute=has_target,
            has_explicit_exclusion=has_exclusion,
            has_stack_array_alloca=has_array_alloca,
            has_escaped_alloca=has_escaped,
            array_alloca_types=array_matches,
        )
        functions[fn_name] = fn_info

    # 3. Compute Metrics
    total_funcs = len(functions)
    funcs_with_attr = sum(1 for f in functions.values() if f.has_target_attribute)
    explicit_excluded = sum(1 for f in functions.values() if f.has_explicit_exclusion)
    coverage_ratio = (funcs_with_attr / total_funcs) if total_funcs > 0 else 1.0

    vulnerable_candidates = [f for f in functions.values() if f.is_vulnerable_candidate]
    vulnerable_total = len(vulnerable_candidates)
    vulnerable_protected = sum(1 for f in vulnerable_candidates if f.has_target_attribute)
    unprotected_vulnerable = [f.name for f in vulnerable_candidates if not f.has_target_attribute]

    unexpected_omissions = [
        f.name for f in functions.values()
        if not f.has_target_attribute and not f.has_explicit_exclusion
    ]

    limitations = [
        "IR attribute verification proves compiler frontend policy intent (sspstrong / sspreq).",
        "It confirms the backend will evaluate functions against the stack protector heuristic.",
        "Static IR does NOT prove machine-level canary cookie insertion or runtime OS cookie initialization.",
        "Pointer escape detection is a conservative heuristic tracking direct argument passing and 1-level GEP/bitcast; it does not perform full interprocedural alias analysis or store-to-memory escape tracking.",
    ]
    notes: List[str] = []

    # 4. Determine Verdict according to Approved Policy Semantics
    if total_funcs == 0:
        verdict = IRVerificationVerdict.PASS
        notes.append("Module contains zero defined functions (declarations only).")
    elif len(unprotected_vulnerable) > 0:
        # A function with an identifiable stack buffer or escaped local was NOT protected
        verdict = IRVerificationVerdict.PROFILE_VIOLATION
        notes.append(
            f"PROFILE_VIOLATION: {len(unprotected_vulnerable)} function(s) with stack buffer allocations lack '{target_attribute}'."
        )
    elif coverage_ratio == 1.0:
        verdict = IRVerificationVerdict.PASS
        notes.append(f"PASS: 100% of defined functions carry the required '{target_attribute}' attribute.")
    elif coverage_ratio < 1.0:
        if target_attribute == "sspreq":
            # Policy B (Stack Protector All) requires 100% universal attribute coverage
            verdict = IRVerificationVerdict.PROFILE_VIOLATION
            notes.append(
                f"PROFILE_VIOLATION: Policy B (Stack Protector All) requires 100% coverage; observed {coverage_ratio:.2f}."
            )
        else:
            # Policy A (Strong Heuristic): all vulnerable functions protected, but some non-vulnerable functions omitted
            verdict = IRVerificationVerdict.INCONCLUSIVE
            notes.append(
                f"INCONCLUSIVE: Partial attribute coverage ({coverage_ratio:.2f}). All identifiable stack array functions are protected, but {total_funcs - funcs_with_attr} function(s) lack '{target_attribute}'."
            )
    else:
        verdict = IRVerificationVerdict.INCONCLUSIVE

    return ModuleIRVerificationResult(
        ir_path=ir_path,
        target_policy=target_attribute,
        verdict=verdict,
        total_defined_functions=total_funcs,
        functions_with_attribute=funcs_with_attr,
        explicitly_excluded_functions=explicit_excluded,
        attribute_coverage_ratio=coverage_ratio,
        vulnerable_candidates_detected=vulnerable_total,
        vulnerable_candidates_protected=vulnerable_protected,
        unprotected_vulnerable_functions=unprotected_vulnerable,
        unexpected_omissions=unexpected_omissions,
        functions=functions,
        limitations=limitations,
        notes=notes,
    )
