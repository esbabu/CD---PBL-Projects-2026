"""
moo.security.flag_policy — Security Flag Policy and Platform Capability Engine.

Stage 12 Implementation:
- Security Profiles: STANDARD, WINDOWS_HARDENED, LINUX_HARDENED, CUSTOM
- Platform-aware flag generation and capability validation
- Dynamic FORTIFY_SOURCE capability probing (with 4-state enum)
- Strict compliance gating: mandatory protections must be verified; inconclusive
  or inactive protections fail mandatory profile compliance.
"""

from __future__ import annotations

import dataclasses
from enum import Enum
import os
import platform
import re
import subprocess
import tempfile
from typing import Any, Dict, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SecurityProfile(str, Enum):
    """Supported security profiles for compilation and verification."""
    STANDARD = "STANDARD"
    WINDOWS_HARDENED = "WINDOWS_HARDENED"
    LINUX_HARDENED = "LINUX_HARDENED"
    CUSTOM = "CUSTOM"


class FlagEvidenceLevel(str, Enum):
    """
    Evidence hierarchy for security protection application:
    L0_REQUESTED: Specified in profile or configuration.
    L1_PASSED: Included in the subprocess command line argument list.
    L2_ACCEPTED: Compiler process exited with code 0 with the flag present.
    L3_APPLIED: Protection attribute or call instruction present in generated IR.
    L4_VERIFIED: Independent automated verifier confirmed IR or binary structure.
    """
    L0_REQUESTED = "L0_REQUESTED"
    L1_PASSED = "L1_PASSED"
    L2_ACCEPTED = "L2_ACCEPTED"
    L3_APPLIED = "L3_APPLIED"
    L4_VERIFIED = "L4_VERIFIED"


class FlagVerdict(str, Enum):
    """Verdict for an individual security flag evaluation."""
    PASS = "PASS"
    INCONCLUSIVE = "INCONCLUSIVE"
    NOT_SUPPORTED = "NOT_SUPPORTED"
    NOT_PASSED = "NOT_PASSED"


class CandidateProfileVerdict(str, Enum):
    """Candidate-level security profile compliance verdict."""
    COMPLIANT = "COMPLIANT"
    COMPLIANT_WITH_LIMITATIONS = "COMPLIANT_WITH_LIMITATIONS"
    PROFILE_VIOLATION = "PROFILE_VIOLATION"


class FortifyProbeStatus(str, Enum):
    """
    Outcome of probing toolchain and C library headers for GNU FORTIFY_SOURCE support.
    Only FORTIFY_CONFIRMED satisfies mandatory FORTIFY requirements.
    """
    COMPILER_ERROR = "COMPILER_ERROR"
    FLAG_ACCEPTED_BUT_INACTIVE = "FLAG_ACCEPTED_BUT_INACTIVE"
    FORTIFY_CONFIRMED = "FORTIFY_CONFIRMED"
    PROBE_INCONCLUSIVE = "PROBE_INCONCLUSIVE"


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclasses.dataclass(frozen=True)
class ProtectionRequirement:
    """Specification of an individual security protection requirement."""
    name: str
    flag: str
    mandatory: bool = True
    ir_attribute: Optional[str] = None
    description: str = ""


@dataclasses.dataclass
class FlagValidationResult:
    """Evaluation result for an individual security protection flag."""
    protection_name: str
    flag: str
    mandatory: bool
    evidence_level: FlagEvidenceLevel
    verdict: FlagVerdict
    details: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "protection_name": self.protection_name,
            "flag": self.flag,
            "mandatory": self.mandatory,
            "evidence_level": self.evidence_level.value,
            "verdict": self.verdict.value,
            "details": self.details,
        }


@dataclasses.dataclass
class ProfileValidationSummary:
    """Summary of all flag validations for a candidate compilation under a profile."""
    profile: SecurityProfile
    verdict: CandidateProfileVerdict
    target_platform: str
    flag_results: List[FlagValidationResult] = dataclasses.field(default_factory=list)
    limitations: List[str] = dataclasses.field(default_factory=list)
    notes: List[str] = dataclasses.field(default_factory=list)

    def is_eligible_for_optimization(self) -> bool:
        """
        Only candidates that are strictly COMPLIANT with the active profile
        are eligible for optimization selection.
        """
        return self.verdict == CandidateProfileVerdict.COMPLIANT

    def to_dict(self) -> Dict[str, Any]:
        return {
            "profile": self.profile.value,
            "verdict": self.verdict.value,
            "target_platform": self.target_platform,
            "eligible_for_optimization": self.is_eligible_for_optimization(),
            "flag_results": [r.to_dict() for r in self.flag_results],
            "limitations": list(self.limitations),
            "notes": list(self.notes),
        }


# ---------------------------------------------------------------------------
# Platform and Profile Policy Rules
# ---------------------------------------------------------------------------

def detect_target_platform() -> str:
    """Detect current OS platform name: 'windows', 'linux', or other."""
    sys_name = platform.system().lower()
    if "windows" in sys_name:
        return "windows"
    elif "linux" in sys_name:
        return "linux"
    return sys_name


def get_profile_requirements(
    profile: SecurityProfile,
    target_platform: Optional[str] = None,
    custom_mandatory_flags: Optional[Sequence[str]] = None,
    custom_optional_flags: Optional[Sequence[str]] = None,
) -> List[ProtectionRequirement]:
    """
    Returns the list of ProtectionRequirements for a given profile and platform.
    """
    plat = (target_platform or detect_target_platform()).lower()
    requirements: List[ProtectionRequirement] = []

    if profile == SecurityProfile.STANDARD:
        # Standard profile requires no security hardening flags.
        # Explicit disabling flags are checked separately.
        return []

    elif profile == SecurityProfile.WINDOWS_HARDENED:
        # Windows Hardened requires Stack Protector Strong.
        # It intentionally omits _FORTIFY_SOURCE (unsupported on MSVC UCRT)
        # and SafeStack (unsupported option on Windows Clang target).
        requirements.append(
            ProtectionRequirement(
                name="STACK_PROTECTOR_STRONG",
                flag="-fstack-protector-strong",
                mandatory=True,
                ir_attribute="sspstrong",
                description="Stack protector strong heuristic (lowered to __security_cookie on Windows)",
            )
        )

    elif profile == SecurityProfile.LINUX_HARDENED:
        # Linux Hardened requires Stack Protector Strong and FORTIFY_SOURCE=2.
        requirements.append(
            ProtectionRequirement(
                name="STACK_PROTECTOR_STRONG",
                flag="-fstack-protector-strong",
                mandatory=True,
                ir_attribute="sspstrong",
                description="Stack protector strong heuristic (lowered to __stack_chk_fail on Linux)",
            )
        )
        requirements.append(
            ProtectionRequirement(
                name="FORTIFY_SOURCE",
                flag="-D_FORTIFY_SOURCE=2",
                mandatory=True,
                ir_attribute=None,
                description="GNU FORTIFY_SOURCE=2 call substitution (requires -O1+ and glibc support)",
            )
        )

    elif profile == SecurityProfile.CUSTOM:
        if custom_mandatory_flags:
            for flag in custom_mandatory_flags:
                name = _flag_to_protection_name(flag)
                attr = _flag_to_ir_attribute(flag)
                requirements.append(
                    ProtectionRequirement(
                        name=name,
                        flag=flag,
                        mandatory=True,
                        ir_attribute=attr,
                        description=f"Custom mandatory flag: {flag}",
                    )
                )
        if custom_optional_flags:
            for flag in custom_optional_flags:
                name = _flag_to_protection_name(flag)
                attr = _flag_to_ir_attribute(flag)
                requirements.append(
                    ProtectionRequirement(
                        name=name,
                        flag=flag,
                        mandatory=False,
                        ir_attribute=attr,
                        description=f"Custom optional flag: {flag}",
                    )
                )

    return requirements


def get_profile_flags(
    profile: SecurityProfile,
    target_platform: Optional[str] = None,
    custom_mandatory_flags: Optional[Sequence[str]] = None,
    custom_optional_flags: Optional[Sequence[str]] = None,
) -> List[str]:
    """
    Returns the exact compiler flag strings that must be passed in invocations
    to satisfy the active profile on the target platform.
    """
    reqs = get_profile_requirements(
        profile,
        target_platform=target_platform,
        custom_mandatory_flags=custom_mandatory_flags,
        custom_optional_flags=custom_optional_flags,
    )
    return [r.flag for r in reqs]


def _flag_to_protection_name(flag: str) -> str:
    f = flag.strip()
    if "stack-protector-all" in f:
        return "STACK_PROTECTOR_ALL"
    elif "stack-protector-strong" in f:
        return "STACK_PROTECTOR_STRONG"
    elif "stack-protector" in f:
        return "STACK_PROTECTOR"
    elif "FORTIFY_SOURCE" in f:
        return "FORTIFY_SOURCE"
    elif "safe-stack" in f:
        return "SAFESTACK"
    elif "cfi" in f:
        return "CFI"
    elif "cf-protection" in f:
        return "CET_CF_PROTECTION"
    return f"FLAG_{f.replace('-', '_').replace('=', '_')}"


def _flag_to_ir_attribute(flag: str) -> Optional[str]:
    f = flag.strip()
    if "stack-protector-all" in f:
        return "sspreq"
    elif "stack-protector-strong" in f:
        return "sspstrong"
    elif "stack-protector" in f:
        return "ssp"
    return None


# ---------------------------------------------------------------------------
# Phase 2 — FORTIFY Capability Probe
# ---------------------------------------------------------------------------

_FORTIFY_PROBE_SOURCE = """#include <string.h>

extern void probe_sink(const char *);

int probe_fortify_support(const char *src) {
    char dst[8];
    strcpy(dst, src);
    probe_sink(dst);
    return 0;
}
"""

# Requirement 5: Require an actual call or invoke instruction referencing the fortified function.
# A declaration alone (e.g. declare dso_local ptr @__strcpy_chk) is strictly insufficient.
_FORTIFY_CALL_REGEX = re.compile(
    r"(?:call|invoke)\s+.*@(?:__strcpy_chk|__builtin___strcpy_chk)\b"
)
_UNFORTIFIED_CALL_REGEX = re.compile(
    r"(?:call|invoke)\s+.*@strcpy\b"
)


def run_fortify_capability_probe(
    clang_path: str,
    timeout_s: int = 15,
) -> Tuple[FortifyProbeStatus, str]:
    """
    Empirically probes whether the active Clang toolchain and C library headers
    support GNU FORTIFY_SOURCE call substitution using a known-size local destination.

    Returns:
        (FortifyProbeStatus, diagnostic_details)
    """
    if not clang_path or not os.path.isfile(clang_path):
        return FortifyProbeStatus.COMPILER_ERROR, f"Clang compiler path not found: {clang_path!r}"

    with tempfile.TemporaryDirectory(prefix="toacd_fortify_probe_") as tmpdir:
        src_path = os.path.join(tmpdir, "probe.c")
        ir_path = os.path.join(tmpdir, "probe.ll")

        try:
            with open(src_path, "w", encoding="utf-8") as f:
                f.write(_FORTIFY_PROBE_SOURCE)
        except OSError as exc:
            return FortifyProbeStatus.COMPILER_ERROR, f"Failed to write probe source: {exc}"

        cmd = [
            clang_path,
            "-O2",
            "-D_FORTIFY_SOURCE=2",
            "-S", "-emit-llvm",
            src_path,
            "-o", ir_path,
        ]

        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
        except subprocess.TimeoutExpired:
            return FortifyProbeStatus.COMPILER_ERROR, f"Probe compilation timed out after {timeout_s}s"
        except Exception as exc:
            return FortifyProbeStatus.COMPILER_ERROR, f"Probe execution error: {exc}"

        if res.returncode != 0 or not os.path.isfile(ir_path):
            err_msg = res.stderr.strip()[:300] if res.stderr else f"exit code {res.returncode}"
            return FortifyProbeStatus.COMPILER_ERROR, f"Probe compilation failed: {err_msg}"

        try:
            with open(ir_path, "r", encoding="utf-8", errors="replace") as f:
                ir_text = f.read()
        except OSError as exc:
            return FortifyProbeStatus.COMPILER_ERROR, f"Failed to read probe IR: {exc}"

        # 1. Look for confirmed call or invoke instruction
        if _FORTIFY_CALL_REGEX.search(ir_text):
            return (
                FortifyProbeStatus.FORTIFY_CONFIRMED,
                "GNU FORTIFY_SOURCE verified: actual call to @__strcpy_chk or @__builtin___strcpy_chk emitted in IR",
            )

        # 2. Look for explicit unfortified call instruction (MSVC UCRT / musl behavior)
        if _UNFORTIFIED_CALL_REGEX.search(ir_text):
            return (
                FortifyProbeStatus.FLAG_ACCEPTED_BUT_INACTIVE,
                "Flag -D_FORTIFY_SOURCE=2 accepted by compiler but plain @strcpy call emitted (headers lack GNU FORTIFY wrappers)",
            )

        # 3. Clean compilation but neither target call matched (ambiguous IR or constant-folded)
        return (
            FortifyProbeStatus.PROBE_INCONCLUSIVE,
            "Probe compiled cleanly but neither @__strcpy_chk nor @strcpy call instruction was identified",
        )


_FORTIFY_PROBE_CACHE: Dict[Tuple[str, str], Tuple[FortifyProbeStatus, str]] = {}


def get_cached_fortify_probe(
    clang_path: str,
    target_platform: Optional[str] = None,
    force_refresh: bool = False,
) -> Tuple[FortifyProbeStatus, str]:
    """
    Returns the cached capability probe result for the given clang toolchain and target platform,
    executing the live probe only once per unique toolchain/platform tuple.
    """
    plat = (target_platform or detect_target_platform()).lower()
    cpath = os.path.abspath(clang_path) if (clang_path and os.path.isfile(clang_path)) else (clang_path or "")
    cache_key = (cpath, plat)
    if force_refresh or cache_key not in _FORTIFY_PROBE_CACHE:
        _FORTIFY_PROBE_CACHE[cache_key] = run_fortify_capability_probe(clang_path)
    return _FORTIFY_PROBE_CACHE[cache_key]


# ---------------------------------------------------------------------------
# Phase 1 & 4 — Flag Validation Engine
# ---------------------------------------------------------------------------

def validate_compilation_flags(
    cmd: Sequence[str],
    profile: SecurityProfile,
    compiler_returncode: int,
    target_platform: Optional[str] = None,
    ir_attributes_found: Optional[Sequence[str]] = None,
    custom_mandatory_flags: Optional[Sequence[str]] = None,
    custom_optional_flags: Optional[Sequence[str]] = None,
    strategy_name: str = "",
    allow_degraded_fallback: bool = False,
    fortify_probe_status: Optional[FortifyProbeStatus] = None,
) -> ProfileValidationSummary:
    """
    Validates a compiler invocation command against the active SecurityProfile.
    """
    plat = (target_platform or detect_target_platform()).lower()
    reqs = get_profile_requirements(
        profile,
        target_platform=plat,
        custom_mandatory_flags=custom_mandatory_flags,
        custom_optional_flags=custom_optional_flags,
    )

    cmd_set = set(cmd)
    found_attrs = set(ir_attributes_found or [])
    flag_results: List[FlagValidationResult] = []
    limitations: List[str] = []
    notes: List[str] = []

    has_mandatory_violation = False
    has_mandatory_limitation = False

    # Check for forbidden disabling flags across all profiles
    forbidden_disabling_flags = ["-fno-stack-protector", "/GS-"]
    for forbidden in forbidden_disabling_flags:
        if forbidden in cmd_set:
            has_mandatory_violation = True
            flag_results.append(
                FlagValidationResult(
                    protection_name="NO_SECURITY_DISABLING",
                    flag=forbidden,
                    mandatory=True,
                    evidence_level=FlagEvidenceLevel.L1_PASSED,
                    verdict=FlagVerdict.NOT_SUPPORTED,
                    details=f"Forbidden flag explicitly disabling security is present: {forbidden}",
                )
            )

    if profile == SecurityProfile.STANDARD:
        verdict = (
            CandidateProfileVerdict.PROFILE_VIOLATION
            if has_mandatory_violation
            else CandidateProfileVerdict.COMPLIANT
        )
        return ProfileValidationSummary(
            profile=profile,
            verdict=verdict,
            target_platform=plat,
            flag_results=flag_results,
            limitations=limitations,
            notes=["Standard profile active: no mandatory security hardening flags required."],
        )

    for req in reqs:
        flag_in_cmd = req.flag in cmd_set

        # Check Level 1: Flag passed
        if not flag_in_cmd:
            flag_results.append(
                FlagValidationResult(
                    protection_name=req.name,
                    flag=req.flag,
                    mandatory=req.mandatory,
                    evidence_level=FlagEvidenceLevel.L0_REQUESTED,
                    verdict=FlagVerdict.NOT_PASSED,
                    details=f"Required flag '{req.flag}' was not passed in compiler invocation command.",
                )
            )
            if req.mandatory:
                has_mandatory_violation = True
            continue

        # Check Level 2: Compiler accepted
        if compiler_returncode != 0:
            flag_results.append(
                FlagValidationResult(
                    protection_name=req.name,
                    flag=req.flag,
                    mandatory=req.mandatory,
                    evidence_level=FlagEvidenceLevel.L1_PASSED,
                    verdict=FlagVerdict.NOT_SUPPORTED,
                    details=f"Compiler rejected flag '{req.flag}' with non-zero exit code {compiler_returncode}.",
                )
            )
            if req.mandatory:
                has_mandatory_violation = True
            continue

        # Check Level 3 / Level 4: IR attribute presence
        if req.ir_attribute:
            if req.ir_attribute in found_attrs:
                flag_results.append(
                    FlagValidationResult(
                        protection_name=req.name,
                        flag=req.flag,
                        mandatory=req.mandatory,
                        evidence_level=FlagEvidenceLevel.L4_VERIFIED,
                        verdict=FlagVerdict.PASS,
                        details=f"Flag accepted and expected IR attribute '{req.ir_attribute}' verified across module.",
                    )
                )
            else:
                details_msg = f"Flag '{req.flag}' was accepted by compiler but expected IR attribute '{req.ir_attribute}' was not verified."
                flag_results.append(
                    FlagValidationResult(
                        protection_name=req.name,
                        flag=req.flag,
                        mandatory=req.mandatory,
                        evidence_level=FlagEvidenceLevel.L2_ACCEPTED,
                        verdict=FlagVerdict.INCONCLUSIVE,
                        details=details_msg,
                    )
                )
                if req.mandatory:
                    has_mandatory_violation = True
                    limitations.append(details_msg)
        else:
            # Protections without dedicated function attributes (e.g. FORTIFY_SOURCE)
            if "FORTIFY_SOURCE" in req.name:
                is_baseline_o0 = strategy_name in ("-O0", "baseline", "baseline (-O0)")
                if is_baseline_o0:
                    # Special Rule E-01: Baseline FORTIFY is inactive by libc specification
                    details_msg = "FORTIFY_SOURCE macro accepted at -O0 baseline; inactive without optimization by libc specification."
                    flag_results.append(
                        FlagValidationResult(
                            protection_name=req.name,
                            flag=req.flag,
                            mandatory=req.mandatory,
                            evidence_level=FlagEvidenceLevel.L2_ACCEPTED,
                            verdict=FlagVerdict.INCONCLUSIVE,
                            details=details_msg,
                        )
                    )
                    limitations.append(details_msg)
                    if req.mandatory:
                        has_mandatory_limitation = True
                else:
                    # In an optimized candidate, FORTIFY must be confirmed via live capability probe
                    clang_bin = cmd[0] if cmd else "clang"
                    if fortify_probe_status is not None:
                        probe_status = fortify_probe_status
                        probe_details = f"Supplied test probe status: {probe_status.value}"
                    else:
                        probe_status, probe_details = get_cached_fortify_probe(clang_bin, target_platform=plat)

                    if probe_status == FortifyProbeStatus.FORTIFY_CONFIRMED:
                        flag_results.append(
                            FlagValidationResult(
                                protection_name=req.name,
                                flag=req.flag,
                                mandatory=req.mandatory,
                                evidence_level=FlagEvidenceLevel.L4_VERIFIED,
                                verdict=FlagVerdict.PASS,
                                details="GNU FORTIFY_SOURCE=2 capability confirmed via probe (emitted fortified call).",
                            )
                        )
                    elif probe_status == FortifyProbeStatus.FLAG_ACCEPTED_BUT_INACTIVE:
                        details_msg = (
                            f"FORTIFY_SOURCE=2 flag accepted by compiler, but headers/runtime lack GNU FORTIFY support "
                            f"({probe_details}). Inactive on this platform."
                        )
                        flag_results.append(
                            FlagValidationResult(
                                protection_name=req.name,
                                flag=req.flag,
                                mandatory=req.mandatory,
                                evidence_level=FlagEvidenceLevel.L2_ACCEPTED,
                                verdict=FlagVerdict.NOT_SUPPORTED,
                                details=details_msg,
                            )
                        )
                        if req.mandatory:
                            has_mandatory_violation = True
                            limitations.append(details_msg)
                    elif probe_status == FortifyProbeStatus.COMPILER_ERROR:
                        details_msg = f"FORTIFY capability probe failed due to compiler error: {probe_details}"
                        flag_results.append(
                            FlagValidationResult(
                                protection_name=req.name,
                                flag=req.flag,
                                mandatory=req.mandatory,
                                evidence_level=FlagEvidenceLevel.L1_PASSED,
                                verdict=FlagVerdict.NOT_SUPPORTED,
                                details=details_msg,
                            )
                        )
                        if req.mandatory:
                            has_mandatory_violation = True
                            limitations.append(details_msg)
                    else:  # PROBE_INCONCLUSIVE
                        details_msg = f"FORTIFY capability probe was inconclusive: {probe_details}"
                        flag_results.append(
                            FlagValidationResult(
                                protection_name=req.name,
                                flag=req.flag,
                                mandatory=req.mandatory,
                                evidence_level=FlagEvidenceLevel.L2_ACCEPTED,
                                verdict=FlagVerdict.INCONCLUSIVE,
                                details=details_msg,
                            )
                        )
                        if req.mandatory:
                            has_mandatory_limitation = True
                            limitations.append(details_msg)
            else:
                flag_results.append(
                    FlagValidationResult(
                        protection_name=req.name,
                        flag=req.flag,
                        mandatory=req.mandatory,
                        evidence_level=FlagEvidenceLevel.L2_ACCEPTED,
                        verdict=FlagVerdict.PASS,
                        details=f"Flag '{req.flag}' accepted by compiler.",
                    )
                )

    # Determine overall candidate profile verdict
    if has_mandatory_violation:
        verdict = CandidateProfileVerdict.PROFILE_VIOLATION
    elif has_mandatory_limitation:
        if allow_degraded_fallback:
            verdict = CandidateProfileVerdict.COMPLIANT_WITH_LIMITATIONS
        else:
            # Without explicit override, unverified mandatory protection violates profile
            verdict = CandidateProfileVerdict.PROFILE_VIOLATION
    else:
        verdict = CandidateProfileVerdict.COMPLIANT

    return ProfileValidationSummary(
        profile=profile,
        verdict=verdict,
        target_platform=plat,
        flag_results=flag_results,
        limitations=limitations,
        notes=notes,
    )
