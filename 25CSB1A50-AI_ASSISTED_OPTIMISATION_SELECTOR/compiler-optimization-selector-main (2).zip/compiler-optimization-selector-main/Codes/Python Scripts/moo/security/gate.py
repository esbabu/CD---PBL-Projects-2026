"""
moo.security.gate — Security Gate and Fallback Ladder for Week 13A / Stage 12.

Verdict action rules:
- NOT_APPLICABLE: ACCEPT
- PRESERVED: ACCEPT
- REDUCED: ACCEPT_WITH_WARNINGS (create LOW security event)
- ELIMINATED: REJECT candidate (create OPTIMIZATION_GUARD_VIOLATION event), trigger fallback ladder
- UNKNOWN / ERROR: fail closed to fallback ladder with unverified=True (create GUARD_ERROR event), never claim safe
- Terminal -O0 baseline fallback yields ACCEPT_WITH_WARNINGS with unverified=True

Stage 12 additions:
- GateDecision: BLOCKED and FALLBACK_DEGRADED
- Integration with SecurityProfile, flag_policy, and ir_verifier
- Mandatory protections: non-compliant candidates quarantined from optimization selection
- Strict fail-closed baseline fallback when mandatory protections (like FORTIFY) are inactive
"""

from __future__ import annotations

import dataclasses
from enum import Enum
import os
import tempfile
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .models import CandidateSecurity, CandidateVerdict
from .candidate import evaluate_candidate_security
from .ir_artifacts import emit_baseline_ir, emit_candidate_ir
from .flag_policy import (
    SecurityProfile,
    CandidateProfileVerdict,
    ProfileValidationSummary,
    get_profile_flags,
    validate_compilation_flags,
)
from .ir_verifier import (
    verify_module_stack_protector,
    IRVerificationVerdict,
    ModuleIRVerificationResult,
)
from ..secevent.schema import (
    ThreatDomain,
    AttackType,
    EventSource,
    RiskLevel,
    ActionAttempted,
    ActionTaken,
    SecurityEvent,
)
from ..secevent.risk import Signal, compute_risk_assessment
from ..secevent.log import SecurityEventLog

BASELINE_TERMINAL_STRATEGY = "-O0"


class GateDecision(str, Enum):
    ACCEPT = "ACCEPT"
    ACCEPT_WITH_WARNINGS = "ACCEPT_WITH_WARNINGS"
    FALLBACK = "FALLBACK"
    FALLBACK_DEGRADED = "FALLBACK_DEGRADED"
    REJECT = "REJECT"
    BLOCKED = "BLOCKED"


@dataclasses.dataclass
class GateResult:
    """Outcome of passing through the Security Gate."""
    decision: GateDecision
    effective_strategy: str
    original_strategy: str
    candidate_security: CandidateSecurity
    fallback_occurred: bool = False
    fallback_history: list[str] = dataclasses.field(default_factory=list)
    unverified: bool = False
    security_events: list[SecurityEvent] = dataclasses.field(default_factory=list)
    notes: list[str] = dataclasses.field(default_factory=list)
    security_profile: str = "STANDARD"
    delivered_profile_status: str = "COMPLIANT"
    flag_validation: Optional[Dict[str, Any]] = None
    ir_verification: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision.value if isinstance(self.decision, GateDecision) else str(self.decision),
            "effective_strategy": self.effective_strategy,
            "original_strategy": self.original_strategy,
            "candidate_security": self.candidate_security.to_dict() if self.candidate_security else None,
            "fallback_occurred": self.fallback_occurred,
            "fallback_history": list(self.fallback_history),
            "unverified": self.unverified,
            "security_events": [e.to_dict() for e in self.security_events],
            "notes": list(self.notes),
            "security_profile": self.security_profile,
            "delivered_profile_status": self.delivered_profile_status,
            "flag_validation": self.flag_validation,
            "ir_verification": self.ir_verification,
        }


class OptimizationSecurityGate:
    """
    Enforces candidate security verification and executes fallback ladder if necessary.
    """

    def __init__(
        self,
        event_log: Optional[SecurityEventLog] = None,
        clang_path: Optional[str] = None,
        opt_path: Optional[str] = None,
    ) -> None:
        self.event_log = event_log if event_log is not None else SecurityEventLog()
        self.clang_path = clang_path
        self.opt_path = opt_path

    def evaluate_gate_decision(
        self,
        candidate_sec: CandidateSecurity,
        run_id: Optional[str] = None,
    ) -> tuple[GateDecision, bool, list[SecurityEvent]]:
        """
        Map CandidateVerdict to GateDecision, unverified flag, and security events.
        """
        verdict = candidate_sec.verdict
        events: list[SecurityEvent] = []
        seq = self.event_log.next_sequence

        if verdict in (CandidateVerdict.NOT_APPLICABLE, CandidateVerdict.PRESERVED):
            return GateDecision.ACCEPT, False, []

        elif verdict == CandidateVerdict.REDUCED:
            sig = Signal("G_RED", "guard_reduced", 3, 0.80, evidence=f"Strategy {candidate_sec.strategy_name} merged/folded guards")
            risk = compute_risk_assessment([sig])
            evt = SecurityEvent.create(
                sequence=seq,
                threat_domain=ThreatDomain.OPTIMIZATION_SAFETY,
                attack_type=AttackType.OPTIMIZATION_GUARD_REDUCTION,
                source=EventSource.OPTIMIZATION_SECURITY_GATE,
                risk_level=risk.risk_level,
                score=risk.score,
                confidence=risk.confidence,
                evidence=f"{candidate_sec.merged_sinks} merged, {candidate_sec.folded_sinks} folded guards",
                action_attempted=ActionAttempted.REDUCE_GUARD,
                action_taken=ActionTaken.ALLOW_FLAGGED,
                blocked=False,
                reason="Optimization merged or folded security guards without outright elimination",
                affected_run_id=run_id,
                policy_rules=["GUARD_PRESERVATION_WARN"],
            )
            self.event_log.append(evt)
            events.append(evt)
            return GateDecision.ACCEPT_WITH_WARNINGS, False, events

        elif verdict == CandidateVerdict.ELIMINATED:
            sig = Signal("G_ELIM", "guard_elimination", 7, 0.95, evidence=f"{candidate_sec.eliminated_sinks} guards eliminated")
            risk = compute_risk_assessment([sig])
            evt = SecurityEvent.create(
                sequence=seq,
                threat_domain=ThreatDomain.OPTIMIZATION_SAFETY,
                attack_type=AttackType.OPTIMIZATION_GUARD_ELIMINATION,
                source=EventSource.OPTIMIZATION_SECURITY_GATE,
                risk_level=risk.risk_level,
                score=risk.score,
                confidence=risk.confidence,
                evidence=f"Strategy {candidate_sec.strategy_name} eliminated {candidate_sec.eliminated_sinks} guards",
                action_attempted=ActionAttempted.ELIMINATE_GUARD,
                action_taken=ActionTaken.BLOCK,
                blocked=True,
                reason="Optimization eliminated required security guards (HAZ-003 / CWE-570 violation)",
                affected_run_id=run_id,
                policy_rules=["GUARD_PRESERVATION_HARD"],
            )
            self.event_log.append(evt)
            events.append(evt)
            return GateDecision.FALLBACK, False, events

        elif verdict == CandidateVerdict.UNKNOWN:
            sig = Signal("G_UNK", "guard_unverified", 5, 0.60, evidence=f"Inconclusive verdict: {verdict}")
            risk = compute_risk_assessment([sig])
            evt = SecurityEvent.create(
                sequence=seq,
                threat_domain=ThreatDomain.OPTIMIZATION_SAFETY,
                attack_type=AttackType.GUARD_ERROR,
                source=EventSource.OPTIMIZATION_SECURITY_GATE,
                risk_level=risk.risk_level,
                score=risk.score,
                confidence=risk.confidence,
                evidence="; ".join(candidate_sec.warnings)[:256] or f"Verdict: {verdict}",
                action_attempted=ActionAttempted.UNKNOWN_ACTION,
                action_taken=ActionTaken.BLOCK,
                blocked=True,
                reason="Candidate IR security verification inconclusive (UNKNOWN); failing closed to fallback ladder",
                affected_run_id=run_id,
                policy_rules=["VERIFICATION_INTEGRITY_FAIL_CLOSED"],
            )
            self.event_log.append(evt)
            events.append(evt)
            return GateDecision.FALLBACK, True, events

        else:  # CandidateVerdict.ERROR
            sig = Signal("G_ERR", "guard_error", 6, 0.70, evidence=f"Verification error: {verdict}")
            risk = compute_risk_assessment([sig])
            evt = SecurityEvent.create(
                sequence=seq,
                threat_domain=ThreatDomain.OPTIMIZATION_SAFETY,
                attack_type=AttackType.GUARD_ERROR,
                source=EventSource.OPTIMIZATION_SECURITY_GATE,
                risk_level=risk.risk_level,
                score=risk.score,
                confidence=risk.confidence,
                evidence="; ".join(candidate_sec.warnings)[:256] or f"Verdict: {verdict}",
                action_attempted=ActionAttempted.UNKNOWN_ACTION,
                action_taken=ActionTaken.BLOCK,
                blocked=True,
                reason="Candidate IR security verification failed (ERROR); failing closed to fallback ladder",
                affected_run_id=run_id,
                policy_rules=["VERIFICATION_INTEGRITY_FAIL_CLOSED"],
            )
            self.event_log.append(evt)
            events.append(evt)
            return GateDecision.FALLBACK, True, events

    def run_gate(
        self,
        source_path: str,
        selected_strategy: str,
        q_rank: Optional[Sequence[tuple[str, float]]] = None,
        run_id: Optional[str] = None,
        custom_evaluator: Optional[Callable[[str], CandidateSecurity]] = None,
        security_profile: SecurityProfile | str = SecurityProfile.STANDARD,
        target_platform: Optional[str] = None,
        allow_degraded_fallback: bool = False,
        custom_mandatory_flags: Optional[Sequence[str]] = None,
        custom_optional_flags: Optional[Sequence[str]] = None,
        build_config: Optional[Any] = None,
    ) -> GateResult:
        """
        Execute Security Gate with full Fallback Ladder and Stage 12 Profile Gating.
        """
        if isinstance(security_profile, str):
            try:
                profile_enum = SecurityProfile(security_profile.upper())
            except Exception:
                profile_enum = SecurityProfile.STANDARD
        else:
            profile_enum = security_profile

        sec_flags = get_profile_flags(
            profile_enum,
            target_platform=target_platform,
            custom_mandatory_flags=custom_mandatory_flags,
            custom_optional_flags=custom_optional_flags,
        )

        target_attr = "sspreq" if any("stack-protector-all" in f for f in sec_flags) else "sspstrong"

        fallback_history: list[str] = [selected_strategy]
        all_events: list[SecurityEvent] = []

        # Determine candidates in fallback order:
        # selected -> up to 2 next-best from q_rank -> BASELINE (-O0)
        candidates: list[str] = [selected_strategy]
        if q_rank:
            next_best = [s for s, _ in q_rank if s != selected_strategy and s != BASELINE_TERMINAL_STRATEGY]
            candidates.extend(next_best[:2])
        if BASELINE_TERMINAL_STRATEGY not in candidates:
            candidates.append(BASELINE_TERMINAL_STRATEGY)

        effective_sec: Optional[CandidateSecurity] = None
        effective_decision: GateDecision = GateDecision.FALLBACK
        effective_strat = selected_strategy
        unverified_flag = False
        delivered_status = "COMPLIANT"
        latest_flag_summary: Optional[Dict[str, Any]] = None
        latest_ir_verif: Optional[Dict[str, Any]] = None
        notes: List[str] = []

        with tempfile.TemporaryDirectory() as workdir:
            base_ir, base_err = emit_baseline_ir(
                source_path, workdir, self.clang_path, security_flags=sec_flags, build_config=build_config
            ) if not custom_evaluator else (None, None)

            for cand_strat in candidates:
                # Terminal baseline is handled separately after the candidate loop if no candidate accepted
                if cand_strat == BASELINE_TERMINAL_STRATEGY and len(candidates) > 1:
                    break

                try:
                    if custom_evaluator:
                        cand_sec = custom_evaluator(cand_strat)
                    else:
                        if not base_ir:
                            cand_sec = CandidateSecurity(
                                strategy_name=cand_strat,
                                verdict=CandidateVerdict.ERROR,
                                warnings=[base_err or "Baseline IR emission failed"],
                            )
                        else:
                            cand_ir, cand_err = emit_candidate_ir(
                                cand_strat, source_path, workdir, self.clang_path, self.opt_path, security_flags=sec_flags, build_config=build_config
                            )
                            if not cand_ir:
                                cand_sec = CandidateSecurity(
                                    strategy_name=cand_strat,
                                    verdict=CandidateVerdict.ERROR,
                                    warnings=[cand_err or "Candidate IR compilation failed"],
                                )
                            else:
                                # Stage 12: Profile and IR Verification Gating
                                if profile_enum != SecurityProfile.STANDARD:
                                    ir_res = verify_module_stack_protector(cand_ir, target_attribute=target_attr)
                                    latest_ir_verif = ir_res.to_dict()

                                    attrs_found = [target_attr] if ir_res.verdict == IRVerificationVerdict.PASS else []
                                    mock_cmd = ["clang", cand_strat] + list(sec_flags)
                                    prof_summary = validate_compilation_flags(
                                        cmd=mock_cmd,
                                        profile=profile_enum,
                                        compiler_returncode=0,
                                        target_platform=target_platform,
                                        ir_attributes_found=attrs_found,
                                        custom_mandatory_flags=custom_mandatory_flags,
                                        custom_optional_flags=custom_optional_flags,
                                        strategy_name=cand_strat,
                                        allow_degraded_fallback=allow_degraded_fallback,
                                    )
                                    latest_flag_summary = prof_summary.to_dict()

                                    if not prof_summary.is_eligible_for_optimization():
                                        # Candidate violates mandatory profile requirements -> REJECT from selection
                                        seq = self.event_log.next_sequence
                                        sig = Signal("SEC_PROF_VIOLATION", "profile_violation", 7, 0.95, evidence=f"Strategy {cand_strat} violates {profile_enum.value} requirements")
                                        risk = compute_risk_assessment([sig])
                                        evt = SecurityEvent.create(
                                            sequence=seq,
                                            threat_domain=ThreatDomain.OPTIMIZATION_SAFETY,
                                            attack_type=AttackType.OPTIMIZATION_GUARD_ELIMINATION,
                                            source=EventSource.OPTIMIZATION_SECURITY_GATE,
                                            risk_level=risk.risk_level,
                                            score=risk.score,
                                            confidence=risk.confidence,
                                            evidence="; ".join(prof_summary.limitations or ["Mandatory security requirements not satisfied"]),
                                            action_attempted=ActionAttempted.ELIMINATE_GUARD,
                                            action_taken=ActionTaken.BLOCK,
                                            blocked=True,
                                            reason=f"Candidate strategy '{cand_strat}' does not satisfy mandatory security profile '{profile_enum.value}'",
                                            affected_run_id=run_id,
                                            policy_rules=["MANDATORY_SECURITY_PROFILE_VIOLATION"],
                                        )
                                        self.event_log.append(evt)
                                        all_events.append(evt)

                                        # Record next attempt in history and continue
                                        next_idx = candidates.index(cand_strat) + 1
                                        if next_idx < len(candidates):
                                            fallback_history.append(candidates[next_idx])
                                        continue

                                # Candidate passed profile gating -> evaluate guard sinks
                                cand_sec = evaluate_candidate_security(cand_strat, base_ir, cand_ir)
                except Exception as exc:
                    cand_sec = CandidateSecurity(
                        strategy_name=cand_strat,
                        verdict=CandidateVerdict.ERROR,
                        warnings=[f"Guard evaluation exception: {exc}"],
                    )

                decision, unverified, evts = self.evaluate_gate_decision(cand_sec, run_id=run_id)
                all_events.extend(evts)

                if decision in (GateDecision.ACCEPT, GateDecision.ACCEPT_WITH_WARNINGS):
                    effective_sec = cand_sec
                    effective_decision = decision
                    effective_strat = cand_strat
                    unverified_flag = unverified
                    delivered_status = "COMPLIANT"
                    break
                else:
                    # ELIMINATED or rejected -> continue down ladder
                    next_idx = candidates.index(cand_strat) + 1
                    if next_idx < len(candidates):
                        fallback_history.append(candidates[next_idx])

            # ---------------------------------------------------------------
            # Phase 6: Terminal Baseline Fallback and BLOCKED Decisions
            # ---------------------------------------------------------------
            if effective_sec is None:
                effective_strat = BASELINE_TERMINAL_STRATEGY

                if not base_ir and not custom_evaluator:
                    effective_decision = GateDecision.BLOCKED
                    delivered_status = "BLOCKED"
                    unverified_flag = True
                    notes.append("BLOCKED: Baseline IR compilation failed; no viable compilation exists.")
                    effective_sec = CandidateSecurity(
                        strategy_name=BASELINE_TERMINAL_STRATEGY,
                        verdict=CandidateVerdict.ERROR,
                        warnings=[base_err or "Baseline IR compilation failed"],
                    )
                else:
                    # Evaluate baseline against active security profile
                    base_attrs_found = []
                    if custom_evaluator:
                        base_attrs_found = [target_attr]
                    elif profile_enum != SecurityProfile.STANDARD and base_ir:
                        base_ir_res = verify_module_stack_protector(base_ir, target_attribute=target_attr)
                        latest_ir_verif = base_ir_res.to_dict()
                        if base_ir_res.verdict == IRVerificationVerdict.PASS:
                            base_attrs_found = [target_attr]

                    mock_base_cmd = ["clang", "-O0"] + list(sec_flags)
                    base_prof_summary = validate_compilation_flags(
                        cmd=mock_base_cmd,
                        profile=profile_enum,
                        compiler_returncode=0,
                        target_platform=target_platform,
                        ir_attributes_found=base_attrs_found,
                        custom_mandatory_flags=custom_mandatory_flags,
                        custom_optional_flags=custom_optional_flags,
                        strategy_name="-O0",
                        allow_degraded_fallback=allow_degraded_fallback,
                    )
                    latest_flag_summary = base_prof_summary.to_dict()

                    if profile_enum == SecurityProfile.STANDARD:
                        effective_decision = GateDecision.ACCEPT_WITH_WARNINGS
                        delivered_status = "COMPLIANT"
                        unverified_flag = True
                        notes.append("All optimization candidates failed security gate; standard profile fell back to -O0 baseline.")
                    elif profile_enum == SecurityProfile.WINDOWS_HARDENED:
                        if base_prof_summary.is_eligible_for_optimization():
                            effective_decision = GateDecision.ACCEPT_WITH_WARNINGS
                            delivered_status = "COMPLIANT"
                            notes.append("All optimization candidates failed; fell back to verified Windows Hardened -O0 baseline.")
                        else:
                            effective_decision = GateDecision.BLOCKED
                            delivered_status = "BLOCKED"
                            notes.append("BLOCKED: Baseline -O0 failed mandatory Windows Hardened stack-protector requirements.")
                    elif profile_enum == SecurityProfile.LINUX_HARDENED or (
                        profile_enum == SecurityProfile.CUSTOM and any("FORTIFY" in f for f in sec_flags)
                    ):
                        # Linux Hardened or Custom mandating FORTIFY: FORTIFY is inactive at -O0
                        if allow_degraded_fallback:
                            effective_decision = GateDecision.FALLBACK_DEGRADED
                            delivered_status = "DEGRADED_PROFILE"
                            notes.append(
                                "Delivered with DEGRADED security profile: Candidate -O0 does not provide mandatory "
                                "FORTIFY_SOURCE protection. Accepted under explicit degraded fallback override."
                            )
                        else:
                            effective_decision = GateDecision.BLOCKED
                            delivered_status = "BLOCKED"
                            notes.append(
                                "BLOCKED: All optimization candidates failed security gate; baseline -O0 cannot "
                                "deliver mandatory FORTIFY_SOURCE protection (inactive without optimization)."
                            )
                    else:
                        if base_prof_summary.is_eligible_for_optimization():
                            effective_decision = GateDecision.ACCEPT_WITH_WARNINGS
                            delivered_status = "COMPLIANT"
                        else:
                            effective_decision = GateDecision.BLOCKED
                            delivered_status = "BLOCKED"

                    if custom_evaluator:
                        try:
                            effective_sec = custom_evaluator(BASELINE_TERMINAL_STRATEGY)
                        except Exception as exc:
                            seq = self.event_log.next_sequence
                            sig = Signal("SEC_BASE_EVAL_EXCEPTION", "guard_error", 8, 0.95, evidence=f"Baseline evaluation exception: {exc}")
                            risk = compute_risk_assessment([sig])
                            evt = SecurityEvent.create(
                                sequence=seq,
                                threat_domain=ThreatDomain.OPTIMIZATION_SAFETY,
                                attack_type=AttackType.GUARD_ERROR,
                                source=EventSource.OPTIMIZATION_SECURITY_GATE,
                                risk_level=risk.risk_level,
                                score=risk.score,
                                confidence=risk.confidence,
                                evidence=str(exc),
                                action_attempted=ActionAttempted.UNKNOWN_ACTION,
                                action_taken=ActionTaken.BLOCK,
                                blocked=True,
                                reason=f"Baseline security evaluation exception: {exc}",
                                affected_run_id=run_id,
                                policy_rules=["BASELINE_SECURITY_VERIFICATION_FAILED"],
                            )
                            self.event_log.append(evt)
                            all_events.append(evt)
                            effective_decision = GateDecision.BLOCKED
                            delivered_status = "BLOCKED"
                            unverified_flag = True
                            notes.append(f"BLOCKED: Baseline security evaluation raised an exception: {exc}")
                            effective_sec = CandidateSecurity(
                                strategy_name=BASELINE_TERMINAL_STRATEGY,
                                verdict=CandidateVerdict.ERROR,
                                warnings=[f"Baseline evaluation exception: {exc}"],
                            )
                    else:
                        effective_sec = CandidateSecurity(
                            strategy_name=BASELINE_TERMINAL_STRATEGY,
                            verdict=CandidateVerdict.UNKNOWN if effective_decision == GateDecision.BLOCKED else CandidateVerdict.PRESERVED,
                            warnings=["All optimization candidates failed security gate; terminal baseline evaluated"],
                        )

        fallback_occurred = (effective_strat != selected_strategy)
        if effective_decision == GateDecision.BLOCKED:
            fallback_occurred = False

        notes.append(
            f"Original: {selected_strategy}, Effective: {effective_strat}, Decision: {effective_decision.value}, Profile: {profile_enum.value} ({delivered_status})"
        )

        return GateResult(
            decision=effective_decision,
            effective_strategy=effective_strat,
            original_strategy=selected_strategy,
            candidate_security=effective_sec,
            fallback_occurred=fallback_occurred,
            fallback_history=fallback_history,
            unverified=unverified_flag,
            security_events=all_events,
            notes=notes,
            security_profile=profile_enum.value,
            delivered_profile_status=delivered_status,
            flag_validation=latest_flag_summary,
            ir_verification=latest_ir_verif,
        )
