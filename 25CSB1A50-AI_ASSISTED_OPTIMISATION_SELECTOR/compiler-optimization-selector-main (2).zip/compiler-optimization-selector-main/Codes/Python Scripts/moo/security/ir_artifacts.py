"""
moo.security.ir_artifacts — Deterministic generation of baseline and candidate LLVM IR artifacts.

Reuses toolchain probes and compiler invocation patterns without rewriting existing security modules.
"""

from __future__ import annotations

import os
import subprocess
from typing import Optional, Sequence, Tuple

from ..toolchain import CLANG_PATH, OPT_PATH
from ..strategy_diagnostic import _run_clang_flag_strategy, _run_opt_passes_strategy, _classify_action, _resolve_sources


def get_clang_path() -> Optional[str]:
    """Retrieve verified CLANG_PATH or find in environment."""
    return CLANG_PATH if CLANG_PATH and os.path.isfile(CLANG_PATH) else None


def get_opt_path() -> Optional[str]:
    """Retrieve verified OPT_PATH or find in environment."""
    return OPT_PATH if OPT_PATH and os.path.isfile(OPT_PATH) else None


def emit_baseline_ir(
    source_path: str,
    workdir: str,
    clang_path: Optional[str] = None,
    security_flags: Optional[Sequence[str]] = None,
    build_config: Optional[Any] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Compile source_path into unoptimized baseline LLVM IR (-O0 -disable-O0-optnone).
    Returns (ir_path, error_message).
    """
    clang = clang_path or get_clang_path()
    if not clang:
        return None, "clang compiler not found in environment"

    os.makedirs(workdir, exist_ok=True)
    ir_path = os.path.join(workdir, "baseline.ll")
    sources, comp_flags, _ = _resolve_sources(source_path, build_config=build_config)

    # Fast path: check content-hashed cache ONLY if no security flags are specified
    # (cached baseline IR may not have security attributes like sspstrong).
    if not security_flags:
        try:
            from ..ir_cache import compute_source_hash, get_cached_baseline_ir
            sha = compute_source_hash(source_path, build_config=build_config)
            cached_ir = get_cached_baseline_ir(sha)
            if cached_ir:
                with open(ir_path, "w", encoding="utf-8") as f:
                    f.write(cached_ir)
                return ir_path, None
        except Exception:
            pass

    if len(sources) <= 1:
        cmd = [
            clang,
            "-O0",
            "-Xclang", "-disable-O0-optnone",
            "-S", "-emit-llvm",
        ]
        if security_flags:
            cmd.extend(list(security_flags))
        cmd.extend(comp_flags)
        cmd.extend([
            sources[0],
            "-o", ir_path,
        ])
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if res.returncode == 0 and os.path.isfile(ir_path):
                if not security_flags:
                    try:
                        from ..ir_cache import compute_source_hash, store_cached_baseline_ir
                        sha = compute_source_hash(source_path, build_config=build_config)
                        with open(ir_path, "r", encoding="utf-8", errors="replace") as f:
                            store_cached_baseline_ir(sha, f.read())
                    except Exception:
                        pass
                return ir_path, None
            return None, f"Clang failed (exit {res.returncode}): {res.stderr[:256]}"
        except Exception as exc:
            return None, f"Baseline IR emission error: {exc}"
    else:
        from ..config import LLVM_LINK_PATH
        tu_irs: list[str] = []
        last_res = None
        for idx, src_p in enumerate(sources):
            tu_ir = os.path.join(workdir, f"baseline_tu_{idx}.ll")
            cmd_tu = [
                clang,
                "-O0",
                "-Xclang", "-disable-O0-optnone",
                "-S", "-emit-llvm",
            ]
            if security_flags:
                cmd_tu.extend(list(security_flags))
            cmd_tu.extend(comp_flags)
            cmd_tu.extend([src_p, "-o", tu_ir])
            last_res = subprocess.run(cmd_tu, capture_output=True, text=True, timeout=30)
            if last_res.returncode != 0 or not os.path.isfile(tu_ir):
                return None, f"Clang failed on TU {src_p} (exit {last_res.returncode}): {last_res.stderr[:256]}"
            tu_irs.append(tu_ir)

        if LLVM_LINK_PATH and os.path.isfile(LLVM_LINK_PATH):
            link_cmd = [LLVM_LINK_PATH, "-S"] + tu_irs + ["-o", ir_path]
            res_link = subprocess.run(link_cmd, capture_output=True, text=True, timeout=30)
            if res_link.returncode == 0 and os.path.isfile(ir_path):
                if not security_flags:
                    try:
                        from ..ir_cache import compute_source_hash, store_cached_baseline_ir
                        sha = compute_source_hash(source_path, build_config=build_config)
                        with open(ir_path, "r", encoding="utf-8", errors="replace") as f:
                            store_cached_baseline_ir(sha, f.read())
                    except Exception:
                        pass
                return ir_path, None
            return None, f"llvm-link failed (exit {res_link.returncode}): {res_link.stderr[:256]}"
        return None, "llvm-link not available for multi-file baseline IR linking"


def emit_candidate_ir(
    strategy: str,
    source_path: str,
    workdir: str,
    clang_path: Optional[str] = None,
    opt_path: Optional[str] = None,
    security_flags: Optional[Sequence[str]] = None,
    build_config: Optional[Any] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Compile source_path into candidate optimized LLVM IR for the specified strategy.
    Returns (candidate_ir_path, error_message).
    """
    clang = clang_path or get_clang_path()
    if not clang:
        return None, "clang compiler not found in environment"

    os.makedirs(workdir, exist_ok=True)
    action_type = _classify_action(strategy)
    try:
        if action_type == "clang_flag":
            cand_path, res, _ = _run_clang_flag_strategy(
                strategy, source_path, workdir, clang, security_flags=security_flags, build_config=build_config
            )
            if cand_path and os.path.isfile(cand_path):
                return cand_path, None
            return None, f"Clang flag compilation failed (exit {res.returncode}): {res.stderr[:256]}"
        else:
            opt = opt_path or get_opt_path()
            if not opt:
                return None, "llvm opt tool not found in environment"
            cand_path, results, _ = _run_opt_passes_strategy(
                strategy, source_path, workdir, clang, opt, security_flags=security_flags, build_config=build_config
            )
            if cand_path and os.path.isfile(cand_path):
                return cand_path, None
            last_err = results[-1].stderr if results else "Unknown error"
            return None, f"Opt pass compilation failed: {last_err[:256]}"
    except Exception as exc:
        return None, f"Candidate IR emission error: {exc}"
