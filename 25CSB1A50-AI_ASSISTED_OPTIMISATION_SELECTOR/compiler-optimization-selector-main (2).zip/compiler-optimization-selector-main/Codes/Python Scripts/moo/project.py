"""
moo.project — Multi-File C Project Representation and Safe Ingestion.

Provides structured, secure, and backward-compatible project handling:
- Support for multiple translation units (.c files) and shared headers (.h files).
- Strict workspace and project-root containment (path traversal prevention).
- Clean separation of user source files from compiler intermediate artifacts.
- Deterministic project hashing for cache key generation.
- Full interoperability with single-source workflows and typed BuildConfig.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import logging
import os
import re
from typing import Any, Dict, List, Optional, Sequence, Set, Union

from .build_config import BuildConfig

logger = logging.getLogger(__name__)

# Valid C source and header file extensions
_C_SOURCE_EXTENSIONS: frozenset[str] = frozenset({".c"})
_C_HEADER_EXTENSIONS: frozenset[str] = frozenset({".h", ".hpp", ".inc"})


def _is_strictly_within_root(target_path: str, root_dir: str) -> bool:
    """Check that target_path resolves strictly inside root_dir without escaping."""
    try:
        real_target = os.path.realpath(target_path)
        real_root = os.path.realpath(root_dir)
        return os.path.commonpath([real_target, real_root]) == real_root
    except (ValueError, OSError):
        return False


@dataclasses.dataclass
class CProject:
    """
    Representation of a C project containing one or more translation units.

    Fields:
      project_root : Absolute path to the user's project directory.
      source_files : Relative paths of .c translation units within project_root.
      header_files : Relative paths of .h header files within project_root.
      include_dirs : Relative or absolute include directories.
      build_config : Optional validated BuildConfig (defines, standards, libs).
      name         : Project name (defaults to root directory name).
      artifacts_dir: Isolated working directory for compiler outputs.
      executable_path: Path to the generated binary output.
    """
    project_root: str
    source_files: List[str] = dataclasses.field(default_factory=list)
    header_files: List[str] = dataclasses.field(default_factory=list)
    include_dirs: List[str] = dataclasses.field(default_factory=list)
    build_config: Optional[BuildConfig] = None
    name: str = "c_project"
    artifacts_dir: Optional[str] = None
    executable_path: Optional[str] = None

    def __post_init__(self) -> None:
        self.project_root = os.path.abspath(self.project_root)
        # Normalize relative paths
        self.source_files = [os.path.normpath(f).replace("\\", "/") for f in self.source_files]
        self.header_files = [os.path.normpath(f).replace("\\", "/") for f in self.header_files]

    @property
    def entry_file(self) -> Optional[str]:
        """Return the main entry source file if found, or the first source file."""
        for f in self.source_files:
            base = os.path.basename(f).lower()
            if base in ("main.c", "entry.c"):
                return os.path.normpath(os.path.join(self.project_root, f))
        if self.source_files:
            return os.path.normpath(os.path.join(self.project_root, self.source_files[0]))
        return None

    @property
    def is_multi_file(self) -> bool:
        """True if the project contains more than one translation unit."""
        return len(self.source_files) > 1

    def validate(self) -> List[str]:
        """
        Validate all paths and configuration against security constraints.
        Returns a list of error strings (empty list on success).
        """
        errors: List[str] = []

        if not os.path.isdir(self.project_root):
            errors.append(f"Project root does not exist or is not a directory: {self.project_root!r}")
            return errors

        if not self.source_files:
            errors.append("Project contains no source (.c) files")

        # 1. Source files validation
        for src in self.source_files:
            if not src or not isinstance(src, str):
                errors.append(f"Invalid source file entry: {src!r}")
                continue
            if ".." in src or src.startswith("/") or src.startswith("\\"):
                errors.append(f"Path traversal or absolute path forbidden in source file: {src!r}")
                continue
            full_src = os.path.normpath(os.path.join(self.project_root, src))
            if not _is_strictly_within_root(full_src, self.project_root):
                errors.append(f"Source file escapes project root: {src!r}")
                continue
            if not os.path.isfile(full_src):
                errors.append(f"Source file not found: {src!r}")
                continue
            ext = os.path.splitext(src)[1].lower()
            if ext not in _C_SOURCE_EXTENSIONS:
                errors.append(f"Invalid C source file extension ({ext!r}) for {src!r}")

        # 2. Header files validation
        for hdr in self.header_files:
            if not hdr or not isinstance(hdr, str):
                errors.append(f"Invalid header file entry: {hdr!r}")
                continue
            if ".." in hdr or hdr.startswith("/") or hdr.startswith("\\"):
                errors.append(f"Path traversal or absolute path forbidden in header file: {hdr!r}")
                continue
            full_hdr = os.path.normpath(os.path.join(self.project_root, hdr))
            if not _is_strictly_within_root(full_hdr, self.project_root):
                errors.append(f"Header file escapes project root: {hdr!r}")
                continue
            if not os.path.isfile(full_hdr):
                errors.append(f"Header file not found: {hdr!r}")
                continue
            ext = os.path.splitext(hdr)[1].lower()
            if ext not in _C_HEADER_EXTENSIONS:
                errors.append(f"Invalid C header file extension ({ext!r}) for {hdr!r}")

        # 3. Include directories validation
        for inc in self.include_dirs:
            if not inc or not isinstance(inc, str):
                continue
            if ".." in inc:
                errors.append(f"Path traversal forbidden in include directory: {inc!r}")
                continue
            full_inc = inc if os.path.isabs(inc) else os.path.normpath(os.path.join(self.project_root, inc))
            if not _is_strictly_within_root(full_inc, self.project_root):
                errors.append(f"Include directory escapes project root: {inc!r}")
                continue
            if not os.path.isdir(full_inc):
                errors.append(f"Include directory does not exist: {inc!r}")

        # 4. BuildConfig validation if present
        if self.build_config is not None:
            cfg_errs = self.build_config.validate(workspace_root=self.project_root)
            errors.extend(cfg_errs)

        return errors

    def get_absolute_source_paths(self) -> List[str]:
        """Return list of absolute paths to all source files within project root."""
        return [os.path.normpath(os.path.join(self.project_root, src)) for src in self.source_files]

    def get_absolute_header_paths(self) -> List[str]:
        """Return list of absolute paths to all header files within project root."""
        return [os.path.normpath(os.path.join(self.project_root, hdr)) for hdr in self.header_files]

    def get_effective_include_dirs(self) -> List[str]:
        """
        Compute effective include directories, combining:
        - project root
        - project-specified include dirs
        - auto-detected directories containing headers
        - build_config.include_dirs
        """
        inc_set: List[str] = [self.project_root]

        for d in self.include_dirs:
            full = d if os.path.isabs(d) else os.path.normpath(os.path.join(self.project_root, d))
            if full not in inc_set and os.path.isdir(full):
                inc_set.append(full)

        # Add directories containing discovered header files
        for hdr in self.header_files:
            hdr_dir = os.path.dirname(os.path.normpath(os.path.join(self.project_root, hdr)))
            if hdr_dir and hdr_dir not in inc_set and os.path.isdir(hdr_dir):
                inc_set.append(hdr_dir)

        if self.build_config and self.build_config.include_dirs:
            for inc in self.build_config.include_dirs:
                full = inc if os.path.isabs(inc) else os.path.normpath(os.path.join(self.project_root, inc))
                if full not in inc_set and os.path.isdir(full):
                    inc_set.append(full)

        return inc_set

    def get_effective_build_config(self) -> BuildConfig:
        """
        Return a validated BuildConfig reflecting all project include dirs, defines, and libraries.
        """
        base = self.build_config or BuildConfig()
        eff_inc = self.get_effective_include_dirs()
        return BuildConfig(
            c_standard=base.c_standard,
            include_dirs=eff_inc,
            defines=dict(base.defines),
            libraries=list(base.libraries),
            library_dirs=list(base.library_dirs),
        )

    def compute_project_hash(self) -> str:
        """
        Compute deterministic SHA-256 digest covering all source files,
        headers, relative paths, and build configuration.
        """
        hasher = hashlib.sha256()

        # Deterministically hash each source file (relative path + content bytes)
        for rel_path in sorted(self.source_files):
            hasher.update(f"src:{rel_path}\n".encode("utf-8"))
            full_p = os.path.join(self.project_root, rel_path)
            if os.path.isfile(full_p):
                with open(full_p, "rb") as f:
                    while chunk := f.read(65536):
                        hasher.update(chunk)

        # Deterministically hash each header file
        for rel_hdr in sorted(self.header_files):
            hasher.update(f"hdr:{rel_hdr}\n".encode("utf-8"))
            full_hdr = os.path.join(self.project_root, rel_hdr)
            if os.path.isfile(full_hdr):
                with open(full_hdr, "rb") as f:
                    while chunk := f.read(65536):
                        hasher.update(chunk)

        # Include build configuration (portable content-based representation)
        base = self.build_config or BuildConfig()
        cfg_str = f"c_std:{base.c_standard}|defs:{sorted(base.defines.items())}|libs:{sorted(base.libraries)}|libdirs:{sorted(base.library_dirs)}|inc:{sorted(self.include_dirs)}"
        hasher.update(cfg_str.encode("utf-8"))

        return hasher.hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize project description to a JSON-safe dictionary."""
        return {
            "name": self.name,
            "project_root": self.project_root,
            "source_files": list(self.source_files),
            "header_files": list(self.header_files),
            "include_dirs": list(self.include_dirs),
            "is_multi_file": bool(self.is_multi_file),
            "build_config": self.build_config.to_dict() if self.build_config else None,
        }

    @classmethod
    def from_single_file(cls, source_path: str, build_config: Optional[Any] = None) -> "CProject":
        """
        Construct a backward-compatible CProject from a single C source file.
        """
        abs_src = os.path.abspath(source_path)
        root = os.path.dirname(abs_src)
        basename = os.path.basename(abs_src)
        name = os.path.splitext(basename)[0]

        cfg: Optional[BuildConfig] = None
        if build_config is not None:
            if isinstance(build_config, BuildConfig):
                cfg = build_config
            elif isinstance(build_config, dict):
                cfg = BuildConfig.from_dict(build_config, workspace_root=root)

        return cls(
            project_root=root,
            source_files=[basename],
            header_files=[],
            include_dirs=[root],
            build_config=cfg,
            name=name,
        )

    @classmethod
    def from_directory(
        cls,
        dir_path: str,
        build_config: Optional[Any] = None,
        name: Optional[str] = None,
    ) -> "CProject":
        """
        Recursively scan a directory for .c and .h files to construct a CProject.
        Subdirectories containing headers are automatically indexed.
        """
        abs_root = os.path.abspath(dir_path)
        proj_name = name or os.path.basename(abs_root) or "project"

        sources: List[str] = []
        headers: List[str] = []
        detected_inc_dirs: Set[str] = set()

        for root, dirs, files in os.walk(abs_root):
            # Exclude hidden directories, cache directories, or compiler output folders
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "build", "dist")]
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                full_path = os.path.join(root, file)
                if not _is_strictly_within_root(full_path, abs_root):
                    continue
                rel_path = os.path.relpath(full_path, abs_root).replace("\\", "/")

                if ext in _C_SOURCE_EXTENSIONS:
                    sources.append(rel_path)
                elif ext in _C_HEADER_EXTENSIONS:
                    headers.append(rel_path)
                    rel_dir = os.path.relpath(root, abs_root).replace("\\", "/")
                    detected_inc_dirs.add(rel_dir if rel_dir != "." else "")

        cfg: Optional[BuildConfig] = None
        if build_config is not None:
            if isinstance(build_config, BuildConfig):
                cfg = build_config
            elif isinstance(build_config, dict):
                cfg = BuildConfig.from_dict(build_config, workspace_root=abs_root)

        clean_inc = sorted([d for d in detected_inc_dirs if d])
        return cls(
            project_root=abs_root,
            source_files=sorted(sources),
            header_files=sorted(headers),
            include_dirs=clean_inc,
            build_config=cfg,
            name=proj_name,
        )

    @classmethod
    def from_files_dict(
        cls,
        files_dict: Dict[str, str],
        target_dir: Optional[str] = None,
        project_root: Optional[str] = None,
        build_config: Optional[Any] = None,
        name: Optional[str] = None,
    ) -> "CProject":
        """
        Safely instantiate a multi-file project from an in-memory dictionary of
        {relative_path: content_string}, writing them into target_dir or project_root.
        """
        dest_dir = target_dir or project_root
        if not dest_dir:
            raise ValueError("target_dir or project_root must be provided for from_files_dict")
        abs_target = os.path.abspath(dest_dir)
        os.makedirs(abs_target, exist_ok=True)

        for rel_path, content in files_dict.items():
            clean_rel = os.path.normpath(rel_path).replace("\\", "/")
            if ".." in clean_rel or clean_rel.startswith("/") or clean_rel.startswith("\\"):
                raise ValueError(f"Path traversal detected in file upload payload: {rel_path!r}")

            _, ext = os.path.splitext(clean_rel.lower())
            if ext not in (".c", ".h"):
                raise ValueError(f"Disallowed file extension in project payload: {rel_path!r}")

            full_dest = os.path.normpath(os.path.join(abs_target, clean_rel))
            if not _is_strictly_within_root(full_dest, abs_target):
                raise ValueError(f"File payload escapes target directory: {rel_path!r}")

            os.makedirs(os.path.dirname(full_dest), exist_ok=True)
            with open(full_dest, "w", encoding="utf-8", newline="\n") as f:
                f.write(content)

        return cls.from_directory(abs_target, build_config=build_config, name=name)
