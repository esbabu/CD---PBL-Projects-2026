"""
moo.multiagent — Genuine Multi-Agent AI Communication Package for TOACD.

Coordinates specialized domain agents through structured, typed message exchange
in the following canonical runtime execution sequence:
1. CodeAnalystAgent: Extracts canonical 8 LLVM IR features and static security indicators.
2. ProgramProfilingAgent: Computes deterministic IR instruction-ratio heuristics and program category.
3. OptimizationStrategistAgent: Formulates candidate optimization proposals using DQN or LinUCB.
4. OptimizationReviewerAgent: Audits multi-objective trade-offs and Pareto non-dominance.
5. FinalDecisionAgent: Authoritatively runs OptimizationSecurityGate before physical compilation.
6. BenchmarkAgent: Empirically measures execution latency, code size, and speedup for verified code.

Under the supervision of MultiAgentOrchestrator.
Note: Security Gate verification (FinalDecisionAgent) authoritatively precedes
physical compilation and execution (BenchmarkAgent) to prevent compiling unsafe code.
"""

from __future__ import annotations

from .schema import (
    AgentMessage,
    MessageType,
    ROLE_CODE_ANALYST,
    ROLE_PROGRAM_PROFILING,
    ROLE_OPTIMIZATION_STRATEGIST,
    ROLE_OPTIMIZATION_REVIEWER,
    ROLE_BENCHMARK,
    ROLE_FINAL_DECISION,
    ROLE_ORCHESTRATOR,
    MSG_IR_FEATURES,
    MSG_PROFILE,
    MSG_STRATEGY_PROPOSAL,
    MSG_REVIEW_ACCEPT,
    MSG_REVIEW_REJECT,
    MSG_STRATEGY_REVISED,
    MSG_BENCHMARK_RESULT,
    MSG_FINAL_DECISION,
    MSG_ERROR,
)
from .message_log import MessageLog
from .agents import (
    BaseAgent,
    CodeAnalystAgent,
    ProgramProfilingAgent,
    OptimizationStrategistAgent,
    OptimizationReviewerAgent,
    BenchmarkAgent,
    FinalDecisionAgent,
)
from .orchestrator import MultiAgentOrchestrator

__all__ = [
    "AgentMessage",
    "MessageType",
    "ROLE_CODE_ANALYST",
    "ROLE_PROGRAM_PROFILING",
    "ROLE_OPTIMIZATION_STRATEGIST",
    "ROLE_OPTIMIZATION_REVIEWER",
    "ROLE_BENCHMARK",
    "ROLE_FINAL_DECISION",
    "ROLE_ORCHESTRATOR",
    "MSG_IR_FEATURES",
    "MSG_PROFILE",
    "MSG_STRATEGY_PROPOSAL",
    "MSG_REVIEW_ACCEPT",
    "MSG_REVIEW_REJECT",
    "MSG_STRATEGY_REVISED",
    "MSG_BENCHMARK_RESULT",
    "MSG_FINAL_DECISION",
    "MSG_ERROR",
    "MessageLog",
    "BaseAgent",
    "CodeAnalystAgent",
    "ProgramProfilingAgent",
    "OptimizationStrategistAgent",
    "OptimizationReviewerAgent",
    "BenchmarkAgent",
    "FinalDecisionAgent",
    "MultiAgentOrchestrator",
]
