"""
moo/measurement.py — Execution timing, code-size, energy, and carbon
measurement harness for the TOACD MOO Stage 1 foundation.

Design principles
-----------------
* All measurement sources are EXPLICITLY labelled — we never hide the
  fact that energy / carbon figures are estimated.
* Non-zero return codes are NOT treated as failures; they are recorded
  faithfully.
* Every raw timing sample is preserved; statistics are derived from them.
* Code size comes from llvm-size .text section where available; we fall
  back to raw file size and label the source clearly.
* Energy is estimated via elapsed_time × TDP × utilisation.  A future
  hardware backend can replace estimate_energy() without touching callers.
* Carbon is transparently derived from energy with a configurable grid
  intensity.
"""

from __future__ import annotations

import math
import os
import statistics
import subprocess
import sys
import time
from dataclasses import dataclass, field
from typing import Optional, Any, Union

from . import config

# ---------------------------------------------------------------------------
# Windows Process Handle and CPU-Time API (ctypes) — v3.5 §17.6
# ---------------------------------------------------------------------------
_WIN32_AVAILABLE = False
if os.name == "nt":
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

        PROCESS_QUERY_INFORMATION = 0x0400
        SYNCHRONIZE = 0x00100000

        class _FILETIME(ctypes.Structure):
            _fields_ = [
                ("dwLowDateTime", wintypes.DWORD),
                ("dwHighDateTime", wintypes.DWORD),
            ]

        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE

        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL

        kernel32.GetProcessTimes.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(_FILETIME),
            ctypes.POINTER(_FILETIME),
            ctypes.POINTER(_FILETIME),
            ctypes.POINTER(_FILETIME),
        ]
        kernel32.GetProcessTimes.restype = wintypes.BOOL

        _WIN32_AVAILABLE = True
    except Exception:
        _WIN32_AVAILABLE = False


def _query_process_cpu_times(h_proc: Any) -> tuple[Optional[int], Optional[int], str, Optional[str]]:
    """
    Query user and kernel CPU times in nanoseconds for a process handle.
    Requires a valid Windows process handle with PROCESS_QUERY_INFORMATION.
    Returns (user_cpu_ns, kernel_cpu_ns, cpu_status, error_detail).

    Status values:
      - "OK": CPU times successfully queried with non-zero measurement.
      - "BELOW_RESOLUTION": API call succeeded, but times were below the
        Windows 15.625ms timer interrupt quantum (reports 0ns).
      - "UNAVAILABLE": Not running on NT or process handle not valid.
      - "API_ERROR": GetProcessTimes call failed with Win32 error code.
    """
    if not _WIN32_AVAILABLE:
        return None, None, "UNAVAILABLE", "Win32 API not available on this platform"
    if not h_proc:
        return None, None, "UNAVAILABLE", "Process handle was not obtained"
    try:
        c_time = _FILETIME()
        e_time = _FILETIME()
        k_time = _FILETIME()
        u_time = _FILETIME()
        ok = kernel32.GetProcessTimes(
            h_proc,
            ctypes.byref(c_time),
            ctypes.byref(e_time),
            ctypes.byref(k_time),
            ctypes.byref(u_time),
        )
        if ok:
            user_ns = int(((u_time.dwHighDateTime << 32) | u_time.dwLowDateTime) * 100)
            kernel_ns = int(((k_time.dwHighDateTime << 32) | k_time.dwLowDateTime) * 100)
            if user_ns == 0 and kernel_ns == 0:
                return 0, 0, "BELOW_RESOLUTION", "CPU time below Windows 15.625ms timer interrupt quantum"
            return user_ns, kernel_ns, "OK", None
        else:
            err = ctypes.get_last_error()
            return None, None, "API_ERROR", f"GetProcessTimes failed with Win32 error code {err}"
    except Exception as exc:
        return None, None, "API_ERROR", f"GetProcessTimes exception: {exc}"


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class TimingStats:
    """Descriptive statistics derived from raw timing samples (nanoseconds).

    Week 5 additions (additive — existing fields unchanged):
        cv          : coefficient of variation (median-normalized relative dispersion)
                      = stdev / median.
                      In TOACD execution benchmarking, normalizing by the median
                      rather than the arithmetic mean provides robustness against
                      outlier contamination (e.g. from occasional OS context switches
                      or background Defender scanning), ensuring that transient latency
                      spikes do not artificially suppress or distort the measured noise coefficient.
                      0.0 when n_samples == 1 or median_ns == 0.
                      A high CV (> config.CV_WARN_THRESHOLD) indicates noisy
                      samples; see MeasurementResult.timing_is_reliable.
        n_timeouts  : count of timed runs that hit the per-run timeout and
                      were therefore EXCLUDED from raw_samples_ns.
                      Timed-out runs have their error field set, so they are
                      not added to raw_samples_ns and do not appear in these
                      statistics.  This counter lets callers see how many
                      timeout-excluded runs accompanied this timing result.
    """
    n_samples: int
    median_ns: float
    min_ns: float
    max_ns: float
    mean_ns: float
    stdev_ns: float          # sample stdev; 0.0 when n_samples == 1
    median_s: float          # convenience seconds
    mean_s: float
    # --- Week 5 additions ---
    cv: float = 0.0          # stdev / median; 0.0 when median == 0 or n == 1
    n_timeouts: int = 0      # timed runs that timed out (excluded from raw_samples_ns)
    is_below_resolution: bool = False # True if median is 0 (below timer resolution)

    @staticmethod
    def from_samples(
        samples_ns: list[int],
        n_timeouts: int = 0,
    ) -> "TimingStats":
        """Compute statistics from a list of raw nanosecond timings.

        Parameters
        ----------
        samples_ns  : non-empty list of wall-clock nanosecond measurements
        n_timeouts  : number of those samples that were timeout-flagged
                      (passed in from measure_execution; default 0)
        """
        if not samples_ns:
            raise ValueError("Cannot compute TimingStats from empty sample list")
        n = len(samples_ns)
        med = statistics.median(samples_ns)
        mn = min(samples_ns)
        mx = max(samples_ns)
        mean = statistics.mean(samples_ns)
        std = statistics.stdev(samples_ns) if n > 1 else 0.0
        # CV: ratio of dispersion to central tendency.
        # Defined only when median > 0; otherwise 0.0 (degenerate case).
        cv = (std / float(med)) if (float(med) > 0 and n > 1) else 0.0
        is_below = (float(med) == 0.0)
        return TimingStats(
            n_samples=n,
            median_ns=float(med),
            min_ns=float(mn),
            max_ns=float(mx),
            mean_ns=float(mean),
            stdev_ns=float(std),
            median_s=float(med) / 1e9,
            mean_s=float(mean) / 1e9,
            cv=cv,
            n_timeouts=n_timeouts,
            is_below_resolution=is_below,
        )

    def to_dict(self) -> dict:
        return {
            "n_samples": self.n_samples,
            "median_ns": self.median_ns,
            "min_ns": self.min_ns,
            "max_ns": self.max_ns,
            "mean_ns": self.mean_ns,
            "stdev_ns": self.stdev_ns,
            "median_s": self.median_s,
            "mean_s": self.mean_s,
            # Week 5 additions
            "cv": self.cv,
            "n_timeouts": self.n_timeouts,
            "is_below_resolution": self.is_below_resolution,
        }



@dataclass
class ExecutionRecord:
    """
    Result of running an executable (one warm-up or one measured run).

    A non-zero return_code is NOT automatically invalid; it is recorded
    faithfully and the caller decides what it means.

    Phase 1 additions (v3.5 §17.6):
        wall_time_ns           : monotonic wall-clock elapsed time in nanoseconds
        user_cpu_ns            : process CPU time in user mode (ns); None if unavailable
        kernel_cpu_ns          : process CPU time in kernel mode (ns); None if unavailable
        total_cpu_ns           : total process CPU time (user + kernel ns); None if unavailable
        cpu_time_available     : True if user/kernel CPU times were successfully queried
        cpu_status             : "OK", "BELOW_RESOLUTION", "UNAVAILABLE", "API_ERROR"
        cpu_measurement_error  : error string if API query failed; None on success
        cpu_measurement_source : source description of CPU timing
    """
    return_code: int
    stdout: str
    stderr: str
    elapsed_ns: int          # wall-clock elapsed time in nanoseconds
    timed_out: bool = False
    error: Optional[str] = None   # subprocess-level error (not rc != 0)
    stdout_bytes: bytes = b""
    stderr_bytes: bytes = b""
    user_cpu_ns: Optional[int] = None
    kernel_cpu_ns: Optional[int] = None
    total_cpu_ns: Optional[int] = None
    residual_elapsed_ns: Optional[int] = None
    wall_time_ns: Optional[int] = None
    cpu_time_available: bool = False
    cpu_status: str = "UNAVAILABLE"
    cpu_measurement_error: Optional[str] = None
    cpu_measurement_source: str = "Win32 GetProcessTimes (ctypes, 100ns units)"

    def __post_init__(self) -> None:
        if self.wall_time_ns is None:
            self.wall_time_ns = self.elapsed_ns
        if self.total_cpu_ns is None and self.user_cpu_ns is not None and self.kernel_cpu_ns is not None:
            self.total_cpu_ns = self.user_cpu_ns + self.kernel_cpu_ns
        if self.residual_elapsed_ns is None and self.total_cpu_ns is not None and self.wall_time_ns is not None:
            # External / Non-Child-CPU Elapsed-Time Residual = T_wall - (T_user + T_kernel)
            # Computed without non-linear clamping to maintain exact expectation linearity:
            # mean(residual) == mean(wall) - mean(total_cpu)
            self.residual_elapsed_ns = self.wall_time_ns - self.total_cpu_ns

    def to_dict(self) -> dict:
        return {
            "return_code": self.return_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "elapsed_ns": self.elapsed_ns,
            "wall_time_ns": self.wall_time_ns if self.wall_time_ns is not None else self.elapsed_ns,
            "timed_out": self.timed_out,
            "error": self.error,
            "user_cpu_ns": self.user_cpu_ns,
            "kernel_cpu_ns": self.kernel_cpu_ns,
            "total_cpu_ns": self.total_cpu_ns,
            "residual_elapsed_ns": self.residual_elapsed_ns,
            "cpu_time_available": self.cpu_time_available,
            "cpu_status": self.cpu_status,
            "cpu_measurement_error": self.cpu_measurement_error,
            "cpu_measurement_source": self.cpu_measurement_source,
        }


@dataclass
class CalibrationResult:
    """
    Result of a benchmark timeout calibration run (v3.5 §17.7).

    Captures fixed-timeout calibration observations, median wall-clock time,
    and derives the provisional benchmark timeout.
    """
    success: bool
    t_calib_ns: Optional[float] = None
    t_calib_s: Optional[float] = None
    timeout_s: float = float(config.RUN_TIMEOUT_S)
    calibration_samples_ns: list[int] = field(default_factory=list)
    error: Optional[str] = None
    is_provisional: bool = True
    observations: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "t_calib_ns": self.t_calib_ns,
            "t_calib_s": self.t_calib_s,
            "timeout_s": self.timeout_s,
            "calibration_samples_ns": self.calibration_samples_ns,
            "error": self.error,
            "is_provisional": self.is_provisional,
            "observations": self.observations,
        }


@dataclass
class CodeSizeResult:
    """
    Code size measurement for a compiled executable.

    Prefer .text_size_bytes (PE .text section via llvm-size).
    file_size_bytes is always available as a fallback.
    primary_metric and size_source describe exactly what is being reported.
    """
    file_path: str
    file_size_bytes: int
    text_size_bytes: Optional[int]    # None if llvm-size unavailable
    data_size_bytes: Optional[int]    # .data section
    bss_size_bytes: Optional[int]     # .bss section
    size_source: str                  # e.g. "llvm-size .text" or "file size fallback"
    primary_metric: str               # "text_size_bytes" or "file_size_bytes"
    primary_value: int                # the recommended size figure
    llvm_size_raw: Optional[str] = None   # raw llvm-size output for auditing

    def to_dict(self) -> dict:
        return {
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "text_size_bytes": self.text_size_bytes,
            "data_size_bytes": self.data_size_bytes,
            "bss_size_bytes": self.bss_size_bytes,
            "size_source": self.size_source,
            "primary_metric": self.primary_metric,
            "primary_value": self.primary_value,
            "llvm_size_raw": self.llvm_size_raw,
        }


@dataclass
class EnergyResult:
    """
    Energy estimate for one measurement session.

    energy_is_estimated is ALWAYS True in this implementation; a future
    hardware backend may set it to False.  The energy_source field must
    always describe the origin so audit logs are self-explanatory.
    """
    energy_joules: float
    energy_source: str    # human-readable description of how it was derived
    energy_is_estimated: bool   # True = estimated; False = hardware measured

    def to_dict(self) -> dict:
        return {
            "energy_joules": self.energy_joules,
            "energy_source": self.energy_source,
            "energy_is_estimated": self.energy_is_estimated,
        }


@dataclass
class CarbonResult:
    """
    Carbon footprint derived from energy.

    carbon_is_estimated is True whenever energy_is_estimated is True.
    grid_intensity_g_per_kwh and its source are always stored so results
    are reproducible from a different grid region.
    """
    carbon_grams: float
    grid_intensity_g_per_kwh: float
    grid_intensity_source: str
    energy_source: str          # forwarded from EnergyResult for self-containedness
    carbon_is_estimated: bool   # True when derived from estimated energy

    def to_dict(self) -> dict:
        return {
            "carbon_grams": self.carbon_grams,
            "grid_intensity_g_per_kwh": self.grid_intensity_g_per_kwh,
            "grid_intensity_source": self.grid_intensity_source,
            "energy_source": self.energy_source,
            "carbon_is_estimated": self.carbon_is_estimated,
        }


@dataclass
class MeasurementResult:
    """
    Complete measurement record for one executable under one strategy.

    Fields
    ------
    strategy            — optimization strategy label (e.g. "-O2")
    exe_path            — absolute path of the measured executable
    warmup_runs         — number of warm-up runs performed
    measure_runs        — number of timed runs performed
    raw_samples_ns      — every timed sample in nanoseconds (length == measure_runs,
                          unless some runs timed out or errored)
    timing              — TimingStats derived from raw_samples_ns; None if no
                          valid samples were collected
    last_return_code    — return code of the last measured run
    last_stdout         — stdout of the last measured run
    last_stderr         — stderr of the last measured run
    all_return_codes    — return code from every measured run
    code_size           — CodeSizeResult for the executable
    energy              — EnergyResult (estimated)
    carbon              — CarbonResult derived from energy
    measurement_error   — subprocess-level error string; None on success

    Week 5 additions (additive — all existing fields unchanged):
        n_timeouts          — count of timed runs that hit the per-run timeout.
                              These runs are NOT included in raw_samples_ns
                              because their error field is set; they are counted
                              here so callers can see how many samples were
                              lost to the timeout ceiling.
        n_errors            — count of timed runs that failed at the subprocess
                              level for reasons OTHER than timeout
                              (rec.error is not None and not rec.timed_out).
                              These runs are also excluded from raw_samples_ns.
                              Non-zero return codes are NOT errors here; they
                              are valid measured executions and are timed normally.
        timing_is_reliable  — True only when ALL five conditions hold:
                                1. n_samples >= config.MIN_RELIABLE_SAMPLES
                                2. n_timeouts == 0
                                3. n_errors == 0
                                4. median_ns > 0
                                5. cv <= config.CV_WARN_THRESHOLD
                              False when timing exists but any condition fails.
                              None when no valid timing samples were collected.
                              This field is purely informational — it does NOT
                              alter any existing measurement or calculation.
    """
    strategy: str
    exe_path: str
    warmup_runs: int
    measure_runs: int
    raw_samples_ns: list[int] = field(default_factory=list)
    timing: Optional[TimingStats] = None
    last_return_code: Optional[int] = None
    last_stdout: str = ""
    last_stderr: str = ""
    all_return_codes: list[int] = field(default_factory=list)
    all_stdouts: list[str] = field(default_factory=list)
    all_stdout_bytes: list[bytes] = field(default_factory=list)
    all_stderrs: list[str] = field(default_factory=list)
    output_is_deterministic: bool = True
    output_matches_reference: Optional[bool] = None
    baseline_identity: Optional[str] = None
    compiler_flags: Optional[str] = None
    code_size: Optional[CodeSizeResult] = None
    energy: Optional[EnergyResult] = None
    carbon: Optional[CarbonResult] = None
    measurement_error: Optional[str] = None
    # --- Week 5 additions ---
    n_timeouts: int = 0                       # timeout-flagged timed runs
    n_errors: int = 0                         # subprocess-error timed runs
    timing_is_reliable: Optional[bool] = None # True/False/None — see docstring
    # --- Phase 1 measurement engine additions (v3.5 §17.6) ---
    raw_user_cpu_ns: list[int] = field(default_factory=list)
    raw_kernel_cpu_ns: list[int] = field(default_factory=list)
    raw_total_cpu_ns: list[int] = field(default_factory=list)
    raw_residual_ns: list[int] = field(default_factory=list)
    raw_wall_time_ns: list[int] = field(default_factory=list)
    raw_observations: list[dict] = field(default_factory=list)
    cpu_time_available: bool = False
    cpu_status: str = "UNAVAILABLE"
    cpu_measurement_error: Optional[str] = None
    cpu_measurement_source: str = "Win32 GetProcessTimes (ctypes, 100ns units)"
    user_cpu_timing: Optional[TimingStats] = None
    kernel_cpu_timing: Optional[TimingStats] = None
    total_cpu_timing: Optional[TimingStats] = None
    residual_timing: Optional[TimingStats] = None
    calibration: Optional[CalibrationResult] = None

    def to_dict(self) -> dict:
        return {
            "strategy": self.strategy,
            "exe_path": self.exe_path,
            "warmup_runs": self.warmup_runs,
            "measure_runs": self.measure_runs,
            "raw_samples_ns": self.raw_samples_ns,
            "timing": self.timing.to_dict() if self.timing else None,
            "last_return_code": self.last_return_code,
            "last_stdout": self.last_stdout,
            "last_stderr": self.last_stderr,
            "all_return_codes": self.all_return_codes,
            "all_stdouts": self.all_stdouts,
            "all_stderrs": self.all_stderrs,
            "output_is_deterministic": self.output_is_deterministic,
            "output_matches_reference": self.output_matches_reference,
            "baseline_identity": self.baseline_identity,
            "compiler_flags": self.compiler_flags,
            "code_size": self.code_size.to_dict() if self.code_size else None,
            "energy": self.energy.to_dict() if self.energy else None,
            "carbon": self.carbon.to_dict() if self.carbon else None,
            "measurement_error": self.measurement_error,
            # Week 5 additions
            "n_timeouts": self.n_timeouts,
            "n_errors": self.n_errors,
            "timing_is_reliable": self.timing_is_reliable,
            # Phase 1 measurement engine additions (v3.5 §17.6)
            "raw_user_cpu_ns": self.raw_user_cpu_ns,
            "raw_kernel_cpu_ns": self.raw_kernel_cpu_ns,
            "raw_total_cpu_ns": self.raw_total_cpu_ns,
            "raw_residual_ns": self.raw_residual_ns,
            "raw_wall_time_ns": self.raw_wall_time_ns,
            "raw_observations": self.raw_observations,
            "cpu_time_available": self.cpu_time_available,
            "cpu_status": self.cpu_status,
            "cpu_measurement_error": self.cpu_measurement_error,
            "cpu_measurement_source": self.cpu_measurement_source,
            "user_cpu_timing": self.user_cpu_timing.to_dict() if self.user_cpu_timing else None,
            "kernel_cpu_timing": self.kernel_cpu_timing.to_dict() if self.kernel_cpu_timing else None,
            "total_cpu_timing": self.total_cpu_timing.to_dict() if self.total_cpu_timing else None,
            "residual_timing": self.residual_timing.to_dict() if self.residual_timing else None,
            "calibration": self.calibration.to_dict() if self.calibration else None,
        }



# ---------------------------------------------------------------------------
# Core measurement functions
# ---------------------------------------------------------------------------

def normalize_output(out: str | bytes | None) -> bytes | None:
    """Normalize platform-specific line endings (CRLF and CR to LF) for strict comparison.

    Preserves all other bytes, spaces, and formatting without modification.
    """
    if out is None:
        return None
    b = out if isinstance(out, bytes) else str(out).encode("utf-8")
    return b.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def _run_once(
    exe_path: str,
    timeout_s: int | float = config.RUN_TIMEOUT_S,
    args: list[str] | None = None,
) -> ExecutionRecord:
    """
    Execute *exe_path* once and return an ExecutionRecord.

    Subprocess lifecycle conforms to v3.5 §17.6:
    - Authoritative subprocess.Popen lifecycle.
    - Explicitly queried Windows process handle retained until exit and CPU time retrieval.
    - Bounded waiting via communicate(timeout=...).
    - Normal termination, nonzero exit, crashes, and timeouts handled.
    - Deterministic pipe draining and handle closure.
    - High-resolution wall-clock timing via time.perf_counter_ns().
    """
    cmd = [exe_path] + (args or [])
    h_proc = None
    t0 = time.perf_counter_ns()
    raw_out = b""
    raw_err = b""
    timed_out = False
    error_msg = None
    proc = None

    sandbox_preexec = None
    if sys.platform != "win32":
        def _sandbox_limits():
            try:
                import resource
                resource.setrlimit(resource.RLIMIT_CPU, (5, 5))
                resource.setrlimit(resource.RLIMIT_AS, (268435456, 268435456))
                resource.setrlimit(resource.RLIMIT_FSIZE, (10485760, 10485760))
                resource.setrlimit(resource.RLIMIT_NPROC, (1, 1))
            except Exception:
                pass
        sandbox_preexec = _sandbox_limits

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            preexec_fn=sandbox_preexec,
        )
        open_err = None
        if _WIN32_AVAILABLE and proc is not None and proc.pid:
            try:
                PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
                h_proc = kernel32.OpenProcess(
                    PROCESS_QUERY_INFORMATION | PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE,
                    False, proc.pid
                )
                if not h_proc:
                    open_err = f"OpenProcess returned NULL (Win32 error {ctypes.get_last_error()})"
            except Exception as exc:
                open_err = f"OpenProcess exception: {exc}"
                h_proc = None

        raw_out, raw_err = proc.communicate(timeout=timeout_s)
        elapsed_ns = time.perf_counter_ns() - t0
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        elapsed_ns = time.perf_counter_ns() - t0
        timed_out = True
        rc = -1
        error_msg = f"TimeoutExpired after {timeout_s}s"
        if proc is not None:
            try:
                proc.kill()
                out_drain, err_drain = proc.communicate(timeout=2)
                if out_drain:
                    raw_out = out_drain
                if err_drain:
                    raw_err = err_drain
            except Exception:
                pass
    except Exception as exc:
        elapsed_ns = time.perf_counter_ns() - t0
        rc = -1 if (proc is None or proc.returncode is None) else proc.returncode
        error_msg = str(exc)
        if proc is not None:
            try:
                proc.kill()
                out_drain, err_drain = proc.communicate(timeout=1)
                if out_drain:
                    raw_out = out_drain
                if err_drain:
                    raw_err = err_drain
            except Exception:
                pass
    finally:
        user_cpu_ns = None
        kernel_cpu_ns = None
        cpu_status = "UNAVAILABLE"
        cpu_err = open_err
        if h_proc is not None:
            try:
                user_cpu_ns, kernel_cpu_ns, cpu_status, cpu_err = _query_process_cpu_times(h_proc)
            finally:
                if _WIN32_AVAILABLE:
                    kernel32.CloseHandle(h_proc)
        else:
            if not _WIN32_AVAILABLE:
                cpu_status = "UNAVAILABLE"
                cpu_err = "Win32 API not available on this platform"
            else:
                cpu_status = "UNAVAILABLE"
                cpu_err = open_err or "Process handle could not be obtained"

        if proc is not None:
            try:
                if proc.stdout and not proc.stdout.closed:
                    proc.stdout.close()
                if proc.stderr and not proc.stderr.closed:
                    proc.stderr.close()
            except Exception:
                pass

    raw_out = raw_out or b""
    raw_err = raw_err or b""
    cpu_avail = (cpu_status in ("OK", "BELOW_RESOLUTION") and user_cpu_ns is not None)
    total_cpu = (user_cpu_ns + kernel_cpu_ns) if (user_cpu_ns is not None and kernel_cpu_ns is not None) else None

    return ExecutionRecord(
        return_code=rc,
        stdout=raw_out.decode("utf-8", errors="replace"),
        stderr=raw_err.decode("utf-8", errors="replace"),
        elapsed_ns=elapsed_ns,
        wall_time_ns=elapsed_ns,
        user_cpu_ns=user_cpu_ns,
        kernel_cpu_ns=kernel_cpu_ns,
        total_cpu_ns=total_cpu,
        cpu_time_available=cpu_avail,
        cpu_status=cpu_status,
        cpu_measurement_error=cpu_err,
        cpu_measurement_source="Win32 GetProcessTimes (ctypes, 100ns units)" if _WIN32_AVAILABLE else "None",
        timed_out=timed_out,
        error=error_msg,
        stdout_bytes=raw_out,
        stderr_bytes=raw_err,
    )


def calibrate_benchmark_timeout(
    exe_path: str,
    n_runs: int = 5,
    bootstrap_timeout_s: int | float = config.BOOTSTRAP_TIMEOUT_S,
    args: list[str] | None = None,
    expected_exit_code: Optional[int] = None,
    expected_stdout: Optional[str | bytes] = None,
) -> CalibrationResult:
    """
    Perform fixed-timeout calibration runs per v3.5 §17.7.

    - Every calibration execution runs in a subprocess with a fixed T_bootstrap,
      configured independently of the untrusted binary's runtime.
    - If calibration crashes, times out, exits with unexpected returncode, or fails
      correctness, calibration fails immediately.
    - Successful calibration calculates median wall-clock time T_calib, then uses
      provisional formula: T_run = max(20 * T_calib, 10.0 s).
    - Timeout observations are treated as censored failures, not timing samples.
    """
    if not os.path.isfile(exe_path):
        return CalibrationResult(
            success=False,
            error=f"Executable not found for calibration: {exe_path}",
        )

    expected_bytes = normalize_output(expected_stdout) if expected_stdout is not None else None
    samples_ns: list[int] = []
    observations: list[dict] = []

    for i in range(n_runs):
        rec = _run_once(exe_path, timeout_s=bootstrap_timeout_s, args=args)
        obs = {
            "run_index": i + 1,
            "wall_time_ns": rec.elapsed_ns,
            "user_cpu_ns": rec.user_cpu_ns,
            "kernel_cpu_ns": rec.kernel_cpu_ns,
            "total_cpu_ns": rec.total_cpu_ns,
            "cpu_status": rec.cpu_status,
            "cpu_time_available": rec.cpu_time_available,
            "cpu_measurement_error": rec.cpu_measurement_error,
            "return_code": rec.return_code,
            "timed_out": rec.timed_out,
            "error": rec.error,
        }
        observations.append(obs)

        if rec.timed_out:
            return CalibrationResult(
                success=False,
                error=f"Calibration run {i+1}/{n_runs} timed out after {bootstrap_timeout_s}s",
                observations=observations,
            )
        if rec.error is not None:
            return CalibrationResult(
                success=False,
                error=f"Calibration run {i+1}/{n_runs} failed with subprocess error: {rec.error}",
                observations=observations,
            )
        if expected_exit_code is not None and rec.return_code != expected_exit_code:
            return CalibrationResult(
                success=False,
                error=f"Calibration run {i+1}/{n_runs} exit code mismatch: expected {expected_exit_code}, got {rec.return_code}",
                observations=observations,
            )
        if expected_bytes is not None:
            norm_out = normalize_output(rec.stdout_bytes)
            if norm_out != expected_bytes:
                return CalibrationResult(
                    success=False,
                    error=f"Calibration run {i+1}/{n_runs} output mismatch with expected reference",
                    observations=observations,
                )

        samples_ns.append(rec.elapsed_ns)

    if not samples_ns:
        return CalibrationResult(
            success=False,
            error="No calibration samples collected",
            observations=observations,
        )

    t_calib_ns = float(statistics.median(samples_ns))
    t_calib_s = t_calib_ns / 1e9
    t_run = max(20.0 * t_calib_s, 10.0)

    return CalibrationResult(
        success=True,
        t_calib_ns=t_calib_ns,
        t_calib_s=t_calib_s,
        timeout_s=t_run,
        calibration_samples_ns=samples_ns,
        is_provisional=True,
        observations=observations,
    )


def measure_execution(
    exe_path: str,
    strategy: str = "",
    warmup_runs: int = config.WARMUP_RUNS,
    measure_runs: int = config.MEASURE_RUNS,
    timeout_s: int = config.RUN_TIMEOUT_S,
    args: list[str] | None = None,
    auto_calibrate: bool = False,
    bootstrap_timeout_s: int | float = config.BOOTSTRAP_TIMEOUT_S,
) -> MeasurementResult:
    """
    Measure the execution time of *exe_path*.

    Parameters
    ----------
    exe_path            : absolute path to the compiled executable
    strategy            : label for this measurement (e.g. "-O2")
    warmup_runs         : number of un-timed warm-up executions
    measure_runs        : number of timed executions (raw samples retained)
    timeout_s           : per-run wall-clock timeout in seconds
    args                : extra command-line arguments passed to the executable
    auto_calibrate      : run fixed-timeout calibration before timed runs
    bootstrap_timeout_s : fixed bootstrap timeout for calibration

    Returns
    -------
    MeasurementResult with timing stats, raw samples, and return codes.
    Non-zero return codes are NOT filtered out or replaced with zeros.
    """
    effective_warmup = max(3, warmup_runs) if (warmup_runs >= 3 or warmup_runs == config.WARMUP_RUNS) else warmup_runs
    result = MeasurementResult(
        strategy=strategy,
        exe_path=exe_path,
        warmup_runs=effective_warmup,
        measure_runs=measure_runs,
    )

    if not os.path.isfile(exe_path):
        result.measurement_error = f"Executable not found: {exe_path}"
        return result

    if auto_calibrate:
        calib = calibrate_benchmark_timeout(
            exe_path,
            bootstrap_timeout_s=bootstrap_timeout_s,
            args=args,
        )
        result.calibration = calib
        if not calib.success:
            result.measurement_error = f"Calibration failed: {calib.error}"
            result.n_errors = 1
            return result
        timeout_s = int(math.ceil(calib.timeout_s))

    # --- Warm-up runs (not timed) ---
    for _ in range(effective_warmup):
        _run_once(exe_path, timeout_s=timeout_s, args=args)

    # --- Timed measurement runs ---
    raw_samples: list[int] = []
    raw_user_cpu: list[int] = []
    raw_kernel_cpu: list[int] = []
    raw_total_cpu: list[int] = []
    raw_residuals: list[int] = []
    raw_obs: list[dict] = []
    all_rcs: list[int] = []
    all_stdouts: list[str] = []
    all_stdout_bytes: list[bytes] = []
    all_stderrs: list[str] = []
    last: ExecutionRecord | None = None
    _n_timeouts = 0   # Week 5: runs that timed out (excluded from raw_samples_ns)
    _n_errors = 0     # Week 5: subprocess-error runs, excluding timeouts

    for idx in range(measure_runs):
        rec = _run_once(exe_path, timeout_s=timeout_s, args=args)
        last = rec
        all_rcs.append(rec.return_code)
        all_stdouts.append(rec.stdout)
        all_stdout_bytes.append(rec.stdout_bytes)
        all_stderrs.append(rec.stderr)

        obs = {
            "run_index": idx + 1,
            "wall_time_ns": rec.elapsed_ns,
            "user_cpu_ns": rec.user_cpu_ns,
            "kernel_cpu_ns": rec.kernel_cpu_ns,
            "total_cpu_ns": rec.total_cpu_ns,
            "residual_elapsed_ns": rec.residual_elapsed_ns,
            "cpu_status": rec.cpu_status,
            "cpu_time_available": rec.cpu_time_available,
            "cpu_measurement_error": rec.cpu_measurement_error,
            "return_code": rec.return_code,
            "timed_out": rec.timed_out,
            "error": rec.error,
        }
        raw_obs.append(obs)

        if rec.timed_out:
            _n_timeouts += 1       # timed out: count as timeout ONLY
        elif rec.error is not None:
            _n_errors += 1         # non-timeout subprocess error
        # Non-zero return codes are NOT errors — they are valid timed runs.

        if rec.error is None:
            # Only collect timing for runs with no subprocess-level error.
            # Timed-out runs have their error field set, so they are excluded
            # from raw_samples_ns.
            raw_samples.append(rec.elapsed_ns)
            if rec.user_cpu_ns is not None:
                raw_user_cpu.append(rec.user_cpu_ns)
            if rec.kernel_cpu_ns is not None:
                raw_kernel_cpu.append(rec.kernel_cpu_ns)
            if rec.total_cpu_ns is not None:
                raw_total_cpu.append(rec.total_cpu_ns)
            if rec.residual_elapsed_ns is not None:
                raw_residuals.append(rec.residual_elapsed_ns)

    statuses = [o.get("cpu_status") for o in raw_obs if o.get("cpu_status")]
    if any(s == "OK" for s in statuses):
        agg_status = "OK"
    elif any(s == "BELOW_RESOLUTION" for s in statuses):
        agg_status = "BELOW_RESOLUTION"
    elif any(s == "API_ERROR" for s in statuses):
        agg_status = "API_ERROR"
    else:
        agg_status = "UNAVAILABLE"

    errs = [o.get("cpu_measurement_error") for o in raw_obs if o.get("cpu_measurement_error")]
    agg_err = "; ".join(dict.fromkeys(errs)) if errs else None

    result.raw_samples_ns = raw_samples
    result.raw_wall_time_ns = list(raw_samples)
    result.raw_user_cpu_ns = raw_user_cpu
    result.raw_kernel_cpu_ns = raw_kernel_cpu
    result.raw_total_cpu_ns = raw_total_cpu
    result.raw_residual_ns = raw_residuals
    result.raw_observations = raw_obs
    result.cpu_time_available = bool(raw_user_cpu and agg_status in ("OK", "BELOW_RESOLUTION"))
    result.cpu_status = agg_status
    result.cpu_measurement_error = agg_err
    result.cpu_measurement_source = "Win32 GetProcessTimes (ctypes, 100ns units)" if _WIN32_AVAILABLE else "None"
    result.all_return_codes = all_rcs
    result.all_stdouts = all_stdouts
    result.all_stdout_bytes = all_stdout_bytes
    result.all_stderrs = all_stderrs
    norm_stdout_bytes = [normalize_output(b) for b in all_stdout_bytes]
    result.output_is_deterministic = (len(set(norm_stdout_bytes)) <= 1)
    rc_is_deterministic = (len(set(all_rcs)) <= 1)
    result.n_timeouts = _n_timeouts  # Week 5
    result.n_errors = _n_errors      # Week 5

    if last is not None:
        result.last_return_code = last.return_code
        result.last_stdout = last.stdout
        result.last_stderr = last.stderr
        if last.error:
            result.measurement_error = last.error

    if raw_samples:
        result.timing = TimingStats.from_samples(raw_samples, n_timeouts=_n_timeouts)
        if raw_user_cpu:
            result.user_cpu_timing = TimingStats.from_samples(raw_user_cpu, n_timeouts=_n_timeouts)
        if raw_kernel_cpu:
            result.kernel_cpu_timing = TimingStats.from_samples(raw_kernel_cpu, n_timeouts=_n_timeouts)
        if raw_total_cpu:
            result.total_cpu_timing = TimingStats.from_samples(raw_total_cpu, n_timeouts=_n_timeouts)
        if raw_residuals:
            result.residual_timing = TimingStats.from_samples(raw_residuals, n_timeouts=_n_timeouts)
        # Derive energy and carbon from the median elapsed time (unchanged)
        result.energy = estimate_energy(result.timing.median_s)
        result.carbon = derive_carbon(result.energy)
        # timing_is_reliable — True only when ALL conditions hold:
        # 1. n_samples >= config.MIN_RELIABLE_SAMPLES
        # 2. n_timeouts == 0
        # 3. n_errors == 0
        # 4. median_ns > 0
        # 5. cv <= config.CV_WARN_THRESHOLD
        # 6. output_is_deterministic and rc_is_deterministic
        result.timing_is_reliable = (
            result.timing.n_samples >= config.MIN_RELIABLE_SAMPLES
            and result.n_timeouts == 0
            and result.n_errors == 0
            and result.timing.median_ns > 0
            and result.timing.cv <= config.CV_WARN_THRESHOLD
            and result.output_is_deterministic
            and rc_is_deterministic
        )
    else:
        result.measurement_error = (
            result.measurement_error or "No valid timing samples collected"
        )
        # timing_is_reliable stays None when no valid samples exist

    return result



# ---------------------------------------------------------------------------
# Code size
# ---------------------------------------------------------------------------

def measure_code_size(exe_path: str) -> CodeSizeResult:
    """
    Measure the code size of a compiled executable.

    Primary metric: PE .text section size via llvm-size (when available).
    Fallback: raw file size, clearly labelled.

    The .text, .data, and .bss section sizes are parsed from llvm-size
    output.  The raw llvm-size output is preserved for auditing.

    Returns a CodeSizeResult whose size_source and primary_metric fields
    always describe exactly what is being reported.
    """
    file_size = os.path.getsize(exe_path) if os.path.isfile(exe_path) else 0

    if config.LLVM_SIZE_PATH and os.path.isfile(config.LLVM_SIZE_PATH):
        text_sz, data_sz, bss_sz, raw_out = _run_llvm_size(exe_path)
        if text_sz is not None:
            return CodeSizeResult(
                file_path=exe_path,
                file_size_bytes=file_size,
                text_size_bytes=text_sz,
                data_size_bytes=data_sz,
                bss_size_bytes=bss_sz,
                size_source="llvm-size .text section (PE format)",
                primary_metric="text_size_bytes",
                primary_value=text_sz,
                llvm_size_raw=raw_out,
            )
        # llvm-size ran but parsing failed — fall through to file size
        return CodeSizeResult(
            file_path=exe_path,
            file_size_bytes=file_size,
            text_size_bytes=None,
            data_size_bytes=None,
            bss_size_bytes=None,
            size_source=(
                f"file size fallback (llvm-size ran but output unparseable): {raw_out!r}"
            ),
            primary_metric="file_size_bytes",
            primary_value=file_size,
            llvm_size_raw=raw_out,
        )

    # llvm-size not available
    return CodeSizeResult(
        file_path=exe_path,
        file_size_bytes=file_size,
        text_size_bytes=None,
        data_size_bytes=None,
        bss_size_bytes=None,
        size_source=(
            "file size fallback (llvm-size not found; set TOACD_SIZE_TOOL to enable)"
        ),
        primary_metric="file_size_bytes",
        primary_value=file_size,
        llvm_size_raw=None,
    )


def _run_llvm_size(exe_path: str) -> tuple[Optional[int], Optional[int], Optional[int], str]:
    """
    Run llvm-size on *exe_path* and parse .text / .data / .bss section sizes.

    Returns (text_bytes, data_bytes, bss_bytes, raw_output).
    Any field is None if not found in the output.
    """
    try:
        r = subprocess.run(
            [config.LLVM_SIZE_PATH, exe_path],
            capture_output=True,
            text=True,
            timeout=15,
        )
        raw = (r.stdout + r.stderr).strip()
    except Exception as exc:
        return None, None, None, f"<error: {exc}>"

    # llvm-size --format=sysv output looks like:
    #   section          size      addr
    #   .text            1234      4096
    #   .data             512      8192
    #   .bss              256      12288
    #
    # Default (Berkeley) output looks like:
    #   text    data     bss     dec     hex filename
    #   1234     512     256    2002     7d2  foo.exe
    #
    # We try Berkeley first (simpler), then sysv.

    text_sz = data_sz = bss_sz = None

    lines = raw.splitlines()

    # Try Berkeley (default) format: first non-header line, columns 0/1/2
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.lower().startswith("text"):
            continue
        parts = stripped.split()
        if len(parts) >= 3:
            try:
                text_sz = int(parts[0])
                data_sz = int(parts[1])
                bss_sz  = int(parts[2])
                return text_sz, data_sz, bss_sz, raw
            except ValueError:
                pass

    # Try sysv format: look for lines matching "<name> <size> <addr>"
    import re
    for line in lines:
        m = re.match(r'^\s*(\.\w+)\s+(\d+)\s+', line)
        if not m:
            continue
        name, sz = m.group(1), int(m.group(2))
        if name == ".text":
            text_sz = sz
        elif name == ".data":
            data_sz = sz
        elif name == ".bss":
            bss_sz = sz

    return text_sz, data_sz, bss_sz, raw


# ---------------------------------------------------------------------------
# Energy estimation
# ---------------------------------------------------------------------------

def estimate_energy(elapsed_seconds: float) -> EnergyResult:
    """
    Estimate CPU energy consumption from elapsed wall-clock time.

    Formula (transparent):
        energy_joules = elapsed_seconds × CPU_TDP_WATTS × CPU_UTILISATION

    This is NOT a hardware measurement.  The result is always marked as
    estimated (energy_is_estimated=True).  Override CPU_TDP_WATTS and
    CPU_UTILISATION via environment variables to calibrate for real hardware.

    A future hardware backend (e.g. Intel RAPL, NVML) can replace this
    function without changing any callers.
    """
    energy_joules = elapsed_seconds * config.CPU_TDP_WATTS * config.CPU_UTILISATION
    return EnergyResult(
        energy_joules=energy_joules,
        energy_source=config.ENERGY_SOURCE,
        energy_is_estimated=config.ENERGY_IS_ESTIMATED,
    )


# ---------------------------------------------------------------------------
# Carbon derivation
# ---------------------------------------------------------------------------

def derive_carbon(energy: EnergyResult) -> CarbonResult:
    """
    Derive carbon grams from an EnergyResult and the configured grid intensity.

    Formula (transparent):
        carbon_grams = energy_joules
                       × grid_intensity_g_per_kwh
                       / 3_600_000   [J → kWh conversion]

    The result is marked estimated whenever the energy is estimated.
    All constants and their sources are stored in the result for auditing.
    """
    carbon_grams = (
        energy.energy_joules
        * config.GRID_INTENSITY_G_PER_KWH
        / 3_600_000.0
    )
    return CarbonResult(
        carbon_grams=carbon_grams,
        grid_intensity_g_per_kwh=config.GRID_INTENSITY_G_PER_KWH,
        grid_intensity_source=config.GRID_INTENSITY_SOURCE,
        energy_source=energy.energy_source,
        carbon_is_estimated=energy.energy_is_estimated or config.CARBON_IS_ESTIMATED,
    )


# ---------------------------------------------------------------------------
# Full measurement pipeline (convenience wrapper)
# ---------------------------------------------------------------------------

def measure_all(
    exe_path: str,
    strategy: str = "",
    warmup_runs: int = config.WARMUP_RUNS,
    measure_runs: int = config.MEASURE_RUNS,
    timeout_s: int = config.RUN_TIMEOUT_S,
    args: list[str] | None = None,
    auto_calibrate: bool = False,
    bootstrap_timeout_s: int | float = config.BOOTSTRAP_TIMEOUT_S,
) -> MeasurementResult:
    """
    Run the full measurement pipeline: timing + code size.

    Energy and carbon are derived inside measure_execution from the median
    elapsed time.  Code size is measured separately and attached.

    Returns a complete MeasurementResult.
    """
    result = measure_execution(
        exe_path=exe_path,
        strategy=strategy,
        warmup_runs=warmup_runs,
        measure_runs=measure_runs,
        timeout_s=timeout_s,
        args=args,
        auto_calibrate=auto_calibrate,
        bootstrap_timeout_s=bootstrap_timeout_s,
    )
    # Attach code size (independent of timing; always run even if timing failed)
    if os.path.isfile(exe_path):
        result.code_size = measure_code_size(exe_path)
    return result


def measure_interleaved(
    targets: list[tuple[str, str]],
    warmup_runs: int = config.WARMUP_RUNS,
    measure_runs: int = config.MEASURE_RUNS,
    timeout_s: int = config.RUN_TIMEOUT_S,
    args: list[str] | None = None,
    expected_exit_code: int | None = None,
    expected_stdout: str | bytes | None = None,
    auto_calibrate: bool = False,
    bootstrap_timeout_s: int | float = config.BOOTSTRAP_TIMEOUT_S,
) -> dict[str, MeasurementResult]:
    """
    Measure multiple executables (e.g. baseline and candidate) in an alternating
    interleaved (AB/BA) round-robin order to eliminate environmental, thermal,
    and OS scheduling bias.

    Parameters
    ----------
    targets             : list of (strategy_name, exe_path)
    warmup_runs         : number of un-timed warm-up executions per target
    measure_runs        : number of timed executions per target
    timeout_s           : per-run wall-clock timeout in seconds
    args                : extra command-line arguments
    expected_exit_code  : optional expected return code to validate per run
    expected_stdout     : optional expected stdout (str or bytes) for byte-for-byte validation
    auto_calibrate      : run fixed-timeout calibration before timed runs
    bootstrap_timeout_s : fixed bootstrap timeout for calibration

    Returns
    -------
    dict mapping strategy_name to complete MeasurementResult.
    """
    effective_warmup = max(3, warmup_runs) if (warmup_runs >= 3 or warmup_runs == config.WARMUP_RUNS) else warmup_runs
    effective_measure = max(3, measure_runs)

    valid_targets = [(name, path) for name, path in targets if os.path.isfile(path)]
    results: dict[str, MeasurementResult] = {}

    for name, path in targets:
        if not os.path.isfile(path):
            res = MeasurementResult(
                strategy=name,
                exe_path=path,
                warmup_runs=effective_warmup,
                measure_runs=effective_measure,
            )
            res.measurement_error = f"Executable not found: {path}"
            results[name] = res

    if not valid_targets:
        return results

    # Normalize expected_stdout to bytes with platform-neutral LF line endings
    expected_bytes: Optional[bytes] = normalize_output(expected_stdout)

    # --- Auto-Calibration (v3.5 §17.7) ---
    calibrations: dict[str, CalibrationResult] = {}
    if auto_calibrate:
        calib_failed = False
        for name, path in valid_targets:
            c_res = calibrate_benchmark_timeout(
                path,
                bootstrap_timeout_s=bootstrap_timeout_s,
                args=args,
                expected_exit_code=expected_exit_code,
                expected_stdout=expected_bytes,
            )
            calibrations[name] = c_res
            if not c_res.success:
                calib_failed = True

        if calib_failed:
            failed_reasons = [f"{n}: {c.error}" for n, c in calibrations.items() if not c.success]
            for name, path in targets:
                if name not in results:
                    c_obj = calibrations.get(name)
                    r = MeasurementResult(
                        strategy=name,
                        exe_path=path,
                        warmup_runs=effective_warmup,
                        measure_runs=effective_measure,
                        calibration=c_obj,
                    )
                    r.n_errors = 1
                    if c_obj and not c_obj.success:
                        r.measurement_error = f"Calibration failed: {c_obj.error}"
                    else:
                        r.measurement_error = f"Calibration aborted due to target failure ({'; '.join(failed_reasons)})"
                    results[name] = r
            return results

        max_calib_to = max(c.timeout_s for c in calibrations.values())
        timeout_s = int(math.ceil(max(float(timeout_s), max_calib_to)))

    # --- Phase 1: Warm-up (un-timed) with alternating AB/BA sequence ---
    for w in range(effective_warmup):
        seq = valid_targets if (w % 2 == 0 or len(valid_targets) < 2) else list(reversed(valid_targets))
        for name, path in seq:
            _run_once(path, timeout_s=timeout_s, args=args)

    # --- Phase 2: Interleaved measured runs with alternating AB/BA sequence ---
    samples_by_name: dict[str, list[int]] = {name: [] for name, _ in valid_targets}
    user_cpu_by_name: dict[str, list[int]] = {name: [] for name, _ in valid_targets}
    kernel_cpu_by_name: dict[str, list[int]] = {name: [] for name, _ in valid_targets}
    total_cpu_by_name: dict[str, list[int]] = {name: [] for name, _ in valid_targets}
    residual_by_name: dict[str, list[int]] = {name: [] for name, _ in valid_targets}
    cpu_statuses_by_name: dict[str, list[str]] = {name: [] for name, _ in valid_targets}
    cpu_errors_by_name: dict[str, list[str]] = {name: [] for name, _ in valid_targets}
    obs_by_name: dict[str, list[dict]] = {name: [] for name, _ in valid_targets}
    rcs_by_name: dict[str, list[int]] = {name: [] for name, _ in valid_targets}
    stdouts_by_name: dict[str, list[str]] = {name: [] for name, _ in valid_targets}
    stdout_bytes_by_name: dict[str, list[bytes]] = {name: [] for name, _ in valid_targets}
    stderrs_by_name: dict[str, list[str]] = {name: [] for name, _ in valid_targets}
    last_rec: dict[str, ExecutionRecord] = {}
    timeouts_by_name: dict[str, int] = {name: 0 for name, _ in valid_targets}
    errors_by_name: dict[str, int] = {name: 0 for name, _ in valid_targets}

    for m in range(effective_measure):
        seq = valid_targets if (m % 2 == 0 or len(valid_targets) < 2) else list(reversed(valid_targets))
        for name, path in seq:
            rec = _run_once(path, timeout_s=timeout_s, args=args)
            last_rec[name] = rec
            rcs_by_name[name].append(rec.return_code)
            stdouts_by_name[name].append(rec.stdout)
            stdout_bytes_by_name[name].append(rec.stdout_bytes)
            stderrs_by_name[name].append(rec.stderr)

            obs = {
                "run_index": m + 1,
                "wall_time_ns": rec.elapsed_ns,
                "user_cpu_ns": rec.user_cpu_ns,
                "kernel_cpu_ns": rec.kernel_cpu_ns,
                "total_cpu_ns": rec.total_cpu_ns,
                "residual_elapsed_ns": rec.residual_elapsed_ns,
                "cpu_status": rec.cpu_status,
                "cpu_time_available": rec.cpu_time_available,
                "cpu_measurement_error": rec.cpu_measurement_error,
                "cpu_measurement_source": rec.cpu_measurement_source,
                "return_code": rec.return_code,
                "timed_out": rec.timed_out,
                "error": rec.error,
            }
            obs_by_name[name].append(obs)

            if rec.timed_out:
                timeouts_by_name[name] += 1
            elif rec.error is not None:
                errors_by_name[name] += 1

            if rec.error is None:
                samples_by_name[name].append(rec.elapsed_ns)
                if rec.user_cpu_ns is not None:
                    user_cpu_by_name[name].append(rec.user_cpu_ns)
                if rec.kernel_cpu_ns is not None:
                    kernel_cpu_by_name[name].append(rec.kernel_cpu_ns)
                if rec.total_cpu_ns is not None:
                    total_cpu_by_name[name].append(rec.total_cpu_ns)
                if rec.residual_elapsed_ns is not None:
                    residual_by_name[name].append(rec.residual_elapsed_ns)
                if rec.cpu_status:
                    cpu_statuses_by_name[name].append(rec.cpu_status)
                if rec.cpu_measurement_error:
                    cpu_errors_by_name[name].append(rec.cpu_measurement_error)

    # --- Phase 3: Construct MeasurementResult with statistics & code size ---
    for name, path in valid_targets:
        raw_samples = samples_by_name[name]
        raw_user_samples = user_cpu_by_name[name]
        raw_kernel_samples = kernel_cpu_by_name[name]
        raw_total_samples = total_cpu_by_name[name]
        raw_residual_samples = residual_by_name[name]
        target_stdouts = stdouts_by_name[name]
        target_stdout_bytes = stdout_bytes_by_name[name]
        target_rcs = rcs_by_name[name]

        # Line-ending normalization (CRLF/CR -> LF) preserving all other bytes
        norm_stdout_bytes = [normalize_output(b) for b in target_stdout_bytes]

        out_det = (len(set(norm_stdout_bytes)) <= 1)
        rc_det = (len(set(target_rcs)) <= 1)
        out_match = (expected_bytes is None or all(b == expected_bytes for b in norm_stdout_bytes))
        rc_match = (expected_exit_code is None or all(rc == expected_exit_code for rc in target_rcs))

        statuses = cpu_statuses_by_name[name]
        if any(s == "OK" for s in statuses):
            agg_status = "OK"
        elif any(s == "BELOW_RESOLUTION" for s in statuses):
            agg_status = "BELOW_RESOLUTION"
        elif any(s == "API_ERROR" for s in statuses):
            agg_status = "API_ERROR"
        else:
            agg_status = "UNAVAILABLE"

        errs = cpu_errors_by_name[name]
        agg_err = "; ".join(dict.fromkeys(errs)) if errs else None

        res = MeasurementResult(
            strategy=name,
            exe_path=path,
            warmup_runs=effective_warmup,
            measure_runs=effective_measure,
            calibration=calibrations.get(name),
            raw_samples_ns=raw_samples,
            raw_wall_time_ns=list(raw_samples),
            raw_user_cpu_ns=raw_user_samples,
            raw_kernel_cpu_ns=raw_kernel_samples,
            raw_total_cpu_ns=raw_total_samples,
            raw_residual_ns=raw_residual_samples,
            raw_observations=obs_by_name[name],
            cpu_time_available=bool(raw_user_samples and agg_status in ("OK", "BELOW_RESOLUTION")),
            cpu_status=agg_status,
            cpu_measurement_error=agg_err,
            cpu_measurement_source="Win32 GetProcessTimes (ctypes, 100ns units)" if _WIN32_AVAILABLE else "None",
            all_return_codes=target_rcs,
            all_stdouts=target_stdouts,
            all_stdout_bytes=target_stdout_bytes,
            all_stderrs=stderrs_by_name[name],
            output_is_deterministic=out_det,
            output_matches_reference=out_match,
            n_timeouts=timeouts_by_name[name],
            n_errors=errors_by_name[name],
        )
        l_rec = last_rec.get(name)
        if l_rec is not None:
            res.last_return_code = l_rec.return_code
            res.last_stdout = l_rec.stdout
            res.last_stderr = l_rec.stderr
            if l_rec.error:
                res.measurement_error = l_rec.error

        if not out_match and expected_bytes is not None:
            res.measurement_error = (res.measurement_error or "") + f" [Output mismatch with reference ({name})]"
        if not rc_match and expected_exit_code is not None:
            res.measurement_error = (res.measurement_error or "") + f" [Exit code mismatch: expected {expected_exit_code}, got {set(target_rcs)}]"

        if raw_samples:
            res.timing = TimingStats.from_samples(raw_samples, n_timeouts=timeouts_by_name[name])
            if raw_user_samples:
                res.user_cpu_timing = TimingStats.from_samples(raw_user_samples, n_timeouts=timeouts_by_name[name])
            if raw_kernel_samples:
                res.kernel_cpu_timing = TimingStats.from_samples(raw_kernel_samples, n_timeouts=timeouts_by_name[name])
            if raw_total_samples:
                res.total_cpu_timing = TimingStats.from_samples(raw_total_samples, n_timeouts=timeouts_by_name[name])
            if raw_residual_samples:
                res.residual_timing = TimingStats.from_samples(raw_residual_samples, n_timeouts=timeouts_by_name[name])
            res.energy = estimate_energy(res.timing.median_s)
            res.carbon = derive_carbon(res.energy)
            res.timing_is_reliable = (
                res.timing.n_samples >= config.MIN_RELIABLE_SAMPLES
                and res.n_timeouts == 0
                and res.n_errors == 0
                and res.timing.median_ns > 0
                and res.timing.cv <= config.CV_WARN_THRESHOLD
                and out_det
                and rc_det
                and out_match
                and rc_match
            )
        else:
            res.measurement_error = res.measurement_error or "No valid timing samples collected"

        if os.path.isfile(path):
            res.code_size = measure_code_size(path)

        results[name] = res

    return results
