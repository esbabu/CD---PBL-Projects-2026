"""
moo.build_config — Typed, secure, and validated compiler & linker configuration.

Provides safe configuration parameters for C compilation across TOACD:
- C language standards (e.g., c99, c11, gnu11, gnu17)
- Safe include directories (strictly checked against path traversal)
- Validated preprocessor definitions (-DNAME, -DNAME=VALUE)
- Required linker libraries (e.g., -lm, -lpthread, -lws2_32)
- Safe library search directories (-Lpath)

SECURITY BOUNDS:
- Arbitrary shell execution or shell=True is strictly forbidden.
- Compiler plugins (-Xclang, -load, -fplugin) and arbitrary flags are rejected.
- Path traversal ('..') and out-of-workspace directory escaping are rejected.
- Every compiler and linker argument is verified prior to command formulation.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Set, Union


# Standard C and GNU language standards supported by Clang/LLVM
ALLOWED_C_STANDARDS: frozenset[str] = frozenset({
    "c89", "c90", "c99", "c11", "c17", "c2x", "c23",
    "gnu89", "gnu90", "gnu99", "gnu11", "gnu17", "gnu2x", "gnu23",
})

# Identifier regex for preprocessor macro names
_IDENTIFIER_PATTERN: re.Pattern = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Disallowed characters in macro values (shell metacharacters / injection vectors)
_DISALLOWED_MACRO_VALUE_CHARS: re.Pattern = re.compile(r"[\x00\r\n;&|`$<>]")

# Safe library name pattern (alphanumeric, underscore, hyphen, dot; cannot start with -)
_SAFE_LIBRARY_PATTERN: re.Pattern = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]*$")


def _get_default_allowed_roots() -> List[str]:
    """Return default allowed directory roots for include and library resolution."""
    moo_dir = os.path.dirname(os.path.abspath(__file__))
    scripts_dir = os.path.dirname(moo_dir)
    codes_dir = os.path.dirname(scripts_dir)
    project_root = os.path.dirname(codes_dir)

    roots = [
        os.path.realpath(project_root),
        os.path.realpath(codes_dir),
        os.path.realpath(scripts_dir),
    ]
    # Also allow system temp directory for runtime temp files
    import tempfile
    temp_root = os.path.realpath(tempfile.gettempdir())
    if temp_root not in roots:
        roots.append(temp_root)

    return roots


def _is_path_within_roots(path: str, allowed_roots: Sequence[str]) -> bool:
    """Verify that path strictly resides within at least one approved root directory."""
    real_target = os.path.realpath(path)
    for root in allowed_roots:
        real_root = os.path.realpath(root)
        try:
            common = os.path.commonpath([real_target, real_root])
            if common == real_root:
                return True
        except ValueError:
            # On Windows, ValueError is raised if paths are on different drives
            continue
    return False


@dataclass
class BuildConfig:
    """
    Typed, validated build configuration for compiling C programs.
    """
    c_standard: Optional[str] = None
    include_dirs: List[str] = field(default_factory=list)
    defines: Dict[str, Optional[str]] = field(default_factory=dict)
    libraries: List[str] = field(default_factory=list)
    library_dirs: List[str] = field(default_factory=list)

    def validate(
        self,
        workspace_root: Optional[str] = None,
        extra_allowed_roots: Optional[Sequence[str]] = None,
    ) -> List[str]:
        """
        Validate all configuration fields against security policies.
        Returns a list of validation error messages (empty list on success).
        """
        errors: List[str] = []

        # 1. C Standard Validation
        if self.c_standard is not None:
            clean_std = str(self.c_standard).strip().lower()
            if clean_std not in ALLOWED_C_STANDARDS:
                errors.append(
                    f"Invalid C standard '{self.c_standard}'. Allowed values: {sorted(ALLOWED_C_STANDARDS)}"
                )

        # Build allowed roots list
        allowed_roots = _get_default_allowed_roots()
        if workspace_root:
            allowed_roots.append(os.path.realpath(workspace_root))
        if extra_allowed_roots:
            allowed_roots.extend([os.path.realpath(r) for r in extra_allowed_roots if os.path.exists(r)])

        # 2. Include Directories Validation
        for inc in self.include_dirs:
            if not isinstance(inc, str) or not inc.strip():
                errors.append(f"Invalid include directory entry: {inc!r}")
                continue
            clean_inc = inc.strip()
            # Reject obvious path traversal patterns
            if ".." in clean_inc:
                errors.append(f"Path traversal ('..') forbidden in include directory: {clean_inc!r}")
                continue
            # Resolve relative paths against workspace_root or project root
            base_dir = workspace_root or allowed_roots[0]
            resolved = os.path.realpath(clean_inc if os.path.isabs(clean_inc) else os.path.join(base_dir, clean_inc))
            if not os.path.isdir(resolved):
                errors.append(f"Include directory does not exist or is not a directory: {clean_inc!r} ({resolved})")
                continue
            if not _is_path_within_roots(resolved, allowed_roots):
                errors.append(f"Include directory resides outside approved project locations: {clean_inc!r}")

        # 3. Preprocessor Defines Validation
        for macro_name, macro_val in self.defines.items():
            if not isinstance(macro_name, str) or not _IDENTIFIER_PATTERN.match(macro_name):
                errors.append(f"Invalid preprocessor macro name: {macro_name!r}")
                continue
            if macro_val is not None:
                val_str = str(macro_val)
                if _DISALLOWED_MACRO_VALUE_CHARS.search(val_str):
                    errors.append(f"Disallowed characters in macro value for {macro_name}: {val_str!r}")

        # 4. Required Linker Libraries Validation
        for lib in self.libraries:
            if not isinstance(lib, str) or not lib.strip():
                errors.append(f"Invalid library name: {lib!r}")
                continue
            clean_lib = lib.strip()
            if not _SAFE_LIBRARY_PATTERN.match(clean_lib):
                errors.append(f"Invalid library name pattern (only alphanumeric, underscores, hyphens): {clean_lib!r}")
                continue
            # Prevent injection of compiler / linker flags
            if clean_lib.startswith("-") or "/" in clean_lib or "\\" in clean_lib:
                errors.append(f"Library name cannot start with '-' or contain path separators: {clean_lib!r}")

        # 5. Library Search Directories Validation
        for lib_dir in self.library_dirs:
            if not isinstance(lib_dir, str) or not lib_dir.strip():
                errors.append(f"Invalid library directory entry: {lib_dir!r}")
                continue
            clean_ld = lib_dir.strip()
            if ".." in clean_ld:
                errors.append(f"Path traversal ('..') forbidden in library directory: {clean_ld!r}")
                continue
            base_dir = workspace_root or allowed_roots[0]
            resolved = os.path.realpath(clean_ld if os.path.isabs(clean_ld) else os.path.join(base_dir, clean_ld))
            if not os.path.isdir(resolved):
                errors.append(f"Library directory does not exist or is not a directory: {clean_ld!r}")
                continue
            if not _is_path_within_roots(resolved, allowed_roots):
                errors.append(f"Library directory resides outside approved project locations: {clean_ld!r}")

        return errors

    def get_compiler_flags(self) -> List[str]:
        """
        Produce validated compiler flags (standards, include paths, defines).
        Flags are structured list tokens suitable for subprocess.run(cmd).
        """
        flags: List[str] = []

        # Standard
        if self.c_standard:
            flags.append(f"-std={self.c_standard.strip().lower()}")

        # Include directories
        for inc in self.include_dirs:
            if inc and inc.strip():
                flags.append(f"-I{inc.strip()}")

        # Defines
        for name, val in self.defines.items():
            if val is None or val == "":
                flags.append(f"-D{name}")
            else:
                flags.append(f"-D{name}={val}")

        return flags

    def to_clang_args(self) -> List[str]:
        """Alias for get_compiler_flags() for direct Clang CLI integration."""
        return self.get_compiler_flags()

    def get_linker_flags(self) -> List[str]:
        """
        Produce validated linker flags (-Ldirs, -llibs).
        Flags are structured list tokens suitable for subprocess.run(cmd).
        """
        flags: List[str] = []

        # Library directories
        for ld in self.library_dirs:
            if ld and ld.strip():
                flags.append(f"-L{ld.strip()}")

        # Libraries
        for lib in self.libraries:
            if lib and lib.strip():
                flags.append(f"-l{lib.strip()}")

        return flags

    def to_dict(self) -> Dict[str, Any]:
        """Serialize configuration to a JSON-safe dictionary."""
        return {
            "c_standard": self.c_standard,
            "include_dirs": list(self.include_dirs),
            "defines": dict(self.defines),
            "libraries": list(self.libraries),
            "library_dirs": list(self.library_dirs),
        }

    @classmethod
    def from_dict(
        cls,
        d: Optional[Dict[str, Any]],
        workspace_root: Optional[str] = None,
        extra_allowed_roots: Optional[Sequence[str]] = None,
    ) -> "BuildConfig":
        """
        Construct and validate a BuildConfig instance from dictionary.
        Raises ValueError if validation fails.
        """
        if not d or not isinstance(d, dict):
            return cls()

        raw_std = d.get("c_standard")
        std = str(raw_std).strip().lower() if raw_std else None

        raw_inc = d.get("include_dirs", [])
        inc_dirs = [str(x).strip() for x in raw_inc if x] if isinstance(raw_inc, list) else []

        raw_defs = d.get("defines", {})
        defs: Dict[str, Optional[str]] = {}
        if isinstance(raw_defs, dict):
            for k, v in raw_defs.items():
                defs[str(k).strip()] = str(v) if v is not None else None
        elif isinstance(raw_defs, list):
            for item in raw_defs:
                if "=" in str(item):
                    k, v = str(item).split("=", 1)
                    defs[k.strip()] = v.strip()
                else:
                    defs[str(item).strip()] = None

        raw_libs = d.get("libraries", [])
        libs = [str(x).strip() for x in raw_libs if x] if isinstance(raw_libs, list) else []

        raw_lib_dirs = d.get("library_dirs", [])
        lib_dirs = [str(x).strip() for x in raw_lib_dirs if x] if isinstance(raw_lib_dirs, list) else []

        cfg = cls(
            c_standard=std,
            include_dirs=inc_dirs,
            defines=defs,
            libraries=libs,
            library_dirs=lib_dirs,
        )

        errs = cfg.validate(workspace_root=workspace_root, extra_allowed_roots=extra_allowed_roots)
        if errs:
            raise ValueError(f"Invalid build configuration: {'; '.join(errs)}")

        return cfg

    def to_text_summary(self) -> str:
        """Compact summary string for logging and RunRecord notes."""
        parts = []
        if self.c_standard:
            parts.append(f"std={self.c_standard}")
        if self.include_dirs:
            parts.append(f"includes={len(self.include_dirs)}")
        if self.defines:
            parts.append(f"defs={list(self.defines.keys())}")
        if self.libraries:
            parts.append(f"libs={self.libraries}")
        if self.library_dirs:
            parts.append(f"lib_dirs={len(self.library_dirs)}")
        return f"BuildConfig({', '.join(parts) if parts else 'default'})"
