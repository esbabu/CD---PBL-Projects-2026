"""
moo.tests.test_phase2b_generalization — Comprehensive Validation Suite for TOACD Phase 2B.

Validates:
1. Task A: DQN Inference Adapter (Preserves in-distribution, bounds OOD Q-values, density invariant).
2. Task B: LinUCB OOD Validation (Mitigates hypercube corner saturation, differentiates large programs).
3. Task C: Density-Based Program Profiler (Derived density metrics, non-trivial scaling, call dominance fix).
4. Task D: Security Gate CFG Generalization (Multi-line switch parsing, CFG reachability, indirectbr fail-closed).
5. Task E: BuildConfig Gap Resolution (CompilerEnv and Security Gate macro/include propagation).
"""

from __future__ import annotations

import math
import os
import tempfile
import unittest
import numpy as np
import torch

from ml_optimizer import DQN, ACTIONS, CLANG_PATH
from moo.build_config import BuildConfig
from moo.generalization import (
    IN_DISTRIBUTION_MAX_INSTRUCTIONS,
    adapt_features_for_inference,
    compute_derived_density_metrics,
)
from moo.program_profiler import (
    PROFILE_CALL_ORIENTED,
    PROFILE_COMPUTE_ORIENTED,
    PROFILE_LOOP_ORIENTED,
    PROFILE_MEMORY_ORIENTED,
    PROFILE_MIXED,
    PROFILE_TRIVIAL,
    PROFILE_UNKNOWN,
    ProgramProfile,
    profile_program,
)
from moo.security.gate import GateDecision, OptimizationSecurityGate
from moo.security.ir_parse import parse_llvm_ir
from moo.security.models import CandidateVerdict
from moo.security.sinks import _is_block_guarded, find_sinks


class TestPhase2BGeneralization(unittest.TestCase):
    """Test suite for Phase 2B Model & Profiler Generalization Adaptation."""

    # =========================================================================
    # Task A: DQN Generalization Adapter Tests
    # =========================================================================

    def test_dqn_adapter_in_distribution_identity(self):
        """In-distribution features (<= 500 instructions) must pass through bit-for-bit unchanged."""
        in_dist = [35.0, 247.0, 35.0, 99.0, 23.0, 0.0, 0.0, 0.0]
        adapted = adapt_features_for_inference(in_dist)
        self.assertEqual(in_dist, adapted)

        small = [5.0, 40.0, 5.0, 15.0, 2.0, 0.0, 0.0, 1.0]
        self.assertEqual(small, adapt_features_for_inference(small))

        boundary = [50.0, 500.0, 50.0, 200.0, 30.0, 10.0, 0.0, 5.0]
        self.assertEqual(boundary, adapt_features_for_inference(boundary))

    def test_dqn_adapter_ood_proportional_scaling(self):
        """Out-of-distribution features (> 500 instructions) scale strictly by (500 / InstructionsCount)."""
        large = [150.0, 2500.0, 150.0, 1000.0, 250.0, 50.0, 0.0, 20.0]
        adapted = adapt_features_for_inference(large)
        scale = 500.0 / 2500.0  # 0.2
        expected = [x * scale for x in large]
        for a, e in zip(adapted, expected):
            self.assertAlmostEqual(a, e, places=6)

    def test_dqn_adapter_density_invariance(self):
        """Feature densities (feature / InstructionsCount) must be strictly identical before and after adaptation."""
        large = [600.0, 10000.0, 600.0, 4500.0, 1200.0, 200.0, 50.0, 150.0]
        adapted = adapt_features_for_inference(large)
        raw_densities = compute_derived_density_metrics(large)
        adapted_densities = compute_derived_density_metrics(adapted)
        for k in raw_densities:
            self.assertAlmostEqual(raw_densities[k], adapted_densities[k], places=5)

    def test_dqn_adapter_q_value_bounds(self):
        """Adapted DQN Q-values remain well-conditioned for large programs instead of exploding."""
        # Locate model weights
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        model_path = os.path.join(base_dir, "ml_optimizer_model.pth")
        if not os.path.exists(model_path):
            self.skipTest(f"Model path not found: {model_path}")

        dqn = DQN(8, len(ACTIONS))
        dqn.load_state_dict(torch.load(model_path, weights_only=True))
        dqn.eval()

        huge = [3000.0, 50000.0, 3000.0, 22000.0, 6000.0, 1000.0, 200.0, 800.0]
        # Without adaptation: max Q is > 10,000
        raw_q = dqn(torch.FloatTensor(huge)).tolist()
        self.assertGreater(max(raw_q), 5000.0)

        # With adaptation: max Q is bounded < 200.0
        adapted = adapt_features_for_inference(huge)
        adapted_q = dqn(torch.FloatTensor(adapted)).tolist()
        self.assertLess(max(adapted_q), 250.0)
        self.assertGreater(max(adapted_q), 10.0)

    # =========================================================================
    # Task B: LinUCB Out-of-Distribution Validation Tests
    # =========================================================================

    def test_linucb_ood_saturation_mitigation(self):
        """Adapter prevents distinct large programs from saturating at the hypercube corner [4, 4, ...]."""
        from moo.bandit.config import load_linucb_deployment_config, verify_and_load_linucb_scaler
        p = os.path.abspath(os.path.dirname(__file__))
        scaler_path = None
        while p and os.path.dirname(p) != p:
            cand = os.path.join(p, "data", "models", "linucb_feature_scaler.json")
            if os.path.exists(cand):
                scaler_path = cand
                break
            p = os.path.dirname(p)
        if not scaler_path or not os.path.exists(scaler_path):
            self.skipTest("linucb_feature_scaler.json not found")

        deploy_cfg = load_linucb_deployment_config()
        scaler = verify_and_load_linucb_scaler(scaler_path, deploy_cfg.expected_scaler_sha256)

        huge_branch = [3000.0, 50000.0, 3000.0, 10000.0, 200.0, 0.0, 0.0, 100.0]
        huge_math = [500.0, 50000.0, 500.0, 10000.0, 8000.0, 1500.0, 0.0, 100.0]

        # Raw context vectors saturate: cosine similarity > 0.85
        ctx_b_raw = scaler.transform(huge_branch)
        ctx_m_raw = scaler.transform(huge_math)
        raw_cos = np.dot(ctx_b_raw, ctx_m_raw) / (np.linalg.norm(ctx_b_raw) * np.linalg.norm(ctx_m_raw))
        self.assertGreater(raw_cos, 0.85)

        # Adapted context vectors maintain structural discrimination: cosine similarity < 0.60
        ctx_b_ad = scaler.transform(adapt_features_for_inference(huge_branch))
        ctx_m_ad = scaler.transform(adapt_features_for_inference(huge_math))
        ad_cos = np.dot(ctx_b_ad, ctx_m_ad) / (np.linalg.norm(ctx_b_ad) * np.linalg.norm(ctx_m_ad))
        self.assertLess(ad_cos, 0.60)

    # =========================================================================
    # Task C: Density-Based Program Profiler Tests
    # =========================================================================

    def test_profiler_trivial_preserved(self):
        """Programs with < 35 instructions remain classified as PROFILE_TRIVIAL."""
        f_triv = [0.0, 24.0, 0.0, 2.0, 0.0, 0.0, 0.0, 1.0]
        prof = profile_program(f_triv)
        self.assertEqual(prof.label, PROFILE_TRIVIAL)
        self.assertTrue(prof.is_trivial)
        self.assertIn("branch_density", prof.density_metrics)

    def test_profiler_large_loop_program(self):
        """Large programs with high branch density are classified as loop_oriented, not call_oriented."""
        # 10,000 instructions, 1,500 branches (15% branch density), 20 calls (0.2% call density)
        f_large_loop = [1000.0, 10000.0, 1500.0, 3000.0, 100.0, 0.0, 0.0, 20.0]
        prof = profile_program(f_large_loop)
        self.assertEqual(prof.label, PROFILE_LOOP_ORIENTED)
        self.assertEqual(prof.dominant_feature, "BranchCount")
        self.assertAlmostEqual(prof.density_metrics["branch_density"], 0.15, places=4)

    def test_profiler_large_compute_program(self):
        """Large programs with high math/float density are classified as compute_oriented."""
        # 5,000 instructions, 1,000 math insts (20% compute density), 15 calls
        f_large_comp = [200.0, 5000.0, 100.0, 1500.0, 1000.0, 200.0, 0.0, 15.0]
        prof = profile_program(f_large_comp)
        self.assertEqual(prof.label, PROFILE_COMPUTE_ORIENTED)
        self.assertIn(prof.dominant_feature, ("MathInstCount", "FloatInstCount"))
        self.assertAlmostEqual(prof.density_metrics["compute_density"], 0.24, places=4)

    def test_profiler_large_memory_program(self):
        """Large programs with dominant memory instructions are classified as memory_oriented."""
        # 8,000 instructions, 5,500 memory insts (68.7% memory density)
        f_large_mem = [400.0, 8000.0, 200.0, 5500.0, 100.0, 0.0, 0.0, 10.0]
        prof = profile_program(f_large_mem)
        self.assertEqual(prof.label, PROFILE_MEMORY_ORIENTED)
        self.assertEqual(prof.dominant_feature, "MemInstCount")

    def test_profiler_genuine_call_oriented(self):
        """Programs with high call density (>15% calls) are classified as call_oriented."""
        # 200 instructions, 40 calls (20% call density), low branches and math
        f_call = [20.0, 200.0, 5.0, 40.0, 5.0, 0.0, 0.0, 40.0]
        prof = profile_program(f_call)
        self.assertEqual(prof.label, PROFILE_CALL_ORIENTED)
        self.assertEqual(prof.dominant_feature, "CallInstCount")

    def test_profiler_density_metrics_serialization(self):
        """density_metrics round-trips perfectly through to_dict and from_dict."""
        f = [10.0, 100.0, 15.0, 40.0, 10.0, 5.0, 0.0, 2.0]
        prof = profile_program(f)
        d = prof.to_dict()
        self.assertIn("density_metrics", d)
        reconstructed = ProgramProfile.from_dict(d)
        self.assertEqual(prof.label, reconstructed.label)
        self.assertEqual(prof.density_metrics, reconstructed.density_metrics)

    # =========================================================================
    # Task D: Security Gate CFG Generalization Tests
    # =========================================================================

    def test_security_switch_multiline_parsing(self):
        """Multi-line switch instructions capture all default and case targets in LLVM IR."""
        ir_text = """
define i32 @test_switch(i32 %x) {
entry:
  switch i32 %x, label %default [
    i32 1, label %case1
    i32 2, label %case2
    i32 3, label %case3
  ]

case1:
  ret i32 10

case2:
  ret i32 20

case3:
  ret i32 30

default:
  ret i32 0
}
"""
        parsed = parse_llvm_ir(ir_text, is_path=False)
        self.assertIn("test_switch", parsed.functions)
        fn = parsed.functions["test_switch"]
        entry = fn.blocks["entry"]
        self.assertIsNotNone(entry.terminator)
        self.assertEqual(entry.terminator.opcode, "switch")
        self.assertIn("default", entry.terminator.branch_targets)
        self.assertIn("case1", entry.terminator.branch_targets)
        self.assertIn("case2", entry.terminator.branch_targets)
        self.assertIn("case3", entry.terminator.branch_targets)

    def test_security_switch_guardedness(self):
        """Case blocks reachable only through a switch statement are correctly recognized as guarded."""
        ir_text = """
define i32 @test_guarded_switch(i32 %x) {
entry:
  switch i32 %x, label %default [
    i32 1, label %case1
    i32 2, label %case2
  ]

case1:
  ret i32 10

case2:
  ret i32 20

default:
  ret i32 0
}
"""
        parsed = parse_llvm_ir(ir_text, is_path=False)
        fn = parsed.functions["test_guarded_switch"]
        self.assertFalse(_is_block_guarded(fn, "entry"))
        self.assertTrue(_is_block_guarded(fn, "case1"))
        self.assertTrue(_is_block_guarded(fn, "case2"))
        self.assertTrue(_is_block_guarded(fn, "default"))

    def test_security_identical_destination_switch_unconditional(self):
        """When all switch cases and default target the same block, destination is unconditionally reachable."""
        ir_text = """
declare void @abort()

define i32 @test_identical_switch(i32 %x) {
entry:
  switch i32 %x, label %dest_bb [
    i32 1, label %dest_bb
    i32 2, label %dest_bb
    i32 3, label %dest_bb
  ]

dest_bb:
  call void @abort()
  ret i32 0
}
"""
        parsed = parse_llvm_ir(ir_text, is_path=False)
        fn = parsed.functions["test_identical_switch"]
        self.assertFalse(_is_block_guarded(fn, "entry"))
        self.assertFalse(_is_block_guarded(fn, "dest_bb"), "Identical destination should be unconditionally reached")
        sinks = find_sinks(parsed)
        self.assertEqual(len(sinks), 1)
        self.assertFalse(sinks[0].is_guarded, "Sink in identical destination must not be marked as conditionally guarded")

    def test_security_indirectbr_fails_closed(self):
        """Indirect branches (indirectbr) cannot be statically resolved and safely fail closed to None (UNKNOWN)."""
        ir_text = """
define i32 @test_indirect(ptr %target) {
entry:
  indirectbr ptr %target, [label %b1, label %b2]

b1:
  ret i32 1

b2:
  ret i32 2
}
"""
        parsed = parse_llvm_ir(ir_text, is_path=False)
        fn = parsed.functions["test_indirect"]
        # Entry is unconditional entry
        self.assertFalse(_is_block_guarded(fn, "entry"))
        # Targets following indirectbr cannot be statically verified -> return None
        self.assertIsNone(_is_block_guarded(fn, "b1"))
        self.assertIsNone(_is_block_guarded(fn, "b2"))

    def test_security_loop_cycle_termination(self):
        """Infinite and bounded loops terminate cleanly without recursion or repeated-node errors."""
        ir_text = """
define void @test_loop(i32 %n) {
entry:
  br label %loop

loop:
  %i = phi i32 [ 0, %entry ], [ %next, %loop ]
  %next = add i32 %i, 1
  %cond = icmp slt i32 %next, %n
  br i1 %cond, label %loop, label %exit

exit:
  ret void
}
"""
        parsed = parse_llvm_ir(ir_text, is_path=False)
        fn = parsed.functions["test_loop"]
        self.assertFalse(_is_block_guarded(fn, "entry"))
        self.assertFalse(_is_block_guarded(fn, "loop"))  # Unconditionally branched into from entry
        self.assertTrue(_is_block_guarded(fn, "exit"))   # Condition-guarded exit

    # =========================================================================
    # Task E: BuildConfig Gap Resolution Tests
    # =========================================================================

    def test_compiler_env_buildconfig_macro(self):
        """CompilerEnv successfully compiles and extracts features when required macro is provided."""
        from ml_optimizer import CompilerEnv

        src_code = """
#ifndef REQUIRED_MACRO
#error "REQUIRED_MACRO was not defined!"
#endif
int main(void) {
    int x = REQUIRED_MACRO;
    return x * 2;
}
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            c_file = os.path.join(tmpdir, "macro_test.c")
            with open(c_file, "w") as f:
                f.write(src_code)

            # 1. Without macro: CompilerEnv compilation fails and produces all-zero features
            env_fail = CompilerEnv(c_file)
            self.assertEqual(env_fail.features.tolist(), [0.0] * 8)

            # 2. With macro via BuildConfig: CompilerEnv compiles successfully and extracts features
            cfg = BuildConfig(defines={"REQUIRED_MACRO": "42"})
            env_pass = CompilerEnv(c_file, build_config=cfg)
            self.assertGreater(env_pass.features[1], 0.0)  # InstructionsCount > 0

    def test_security_gate_buildconfig_propagation(self):
        """Security Gate successfully evaluates programs requiring custom macros via BuildConfig."""
        src_code = """
#ifndef GATE_VERIFY_MACRO
#error "GATE_VERIFY_MACRO missing!"
#endif
int main(void) {
    int a = GATE_VERIFY_MACRO;
    return a;
}
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            c_file = os.path.join(tmpdir, "gate_macro_test.c")
            with open(c_file, "w") as f:
                f.write(src_code)

            gate = OptimizationSecurityGate(clang_path=CLANG_PATH)

            # 1. Without BuildConfig: baseline IR emission fails, candidate evaluates to ERROR
            res_fail = gate.run_gate(
                source_path=c_file,
                selected_strategy="-O2",
                run_id="test_gate_no_cfg",
            )
            # When baseline fails, it fails closed (FALLBACK or BLOCKED)
            self.assertIn(res_fail.decision, (GateDecision.FALLBACK, GateDecision.FALLBACK_DEGRADED, GateDecision.BLOCKED))

            # 2. With BuildConfig: compiles successfully, evaluates cleanly
            cfg = BuildConfig(defines={"GATE_VERIFY_MACRO": "100"})
            res_pass = gate.run_gate(
                source_path=c_file,
                selected_strategy="-O2",
                run_id="test_gate_with_cfg",
                build_config=cfg,
            )
            self.assertIsNotNone(res_pass)
            self.assertEqual(res_pass.delivered_profile_status, "COMPLIANT")
            self.assertIn(res_pass.decision, (GateDecision.ACCEPT, GateDecision.ACCEPT_WITH_WARNINGS))


if __name__ == "__main__":
    unittest.main()
