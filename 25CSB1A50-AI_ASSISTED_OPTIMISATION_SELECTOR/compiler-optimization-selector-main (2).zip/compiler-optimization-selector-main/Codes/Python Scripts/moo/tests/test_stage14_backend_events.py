"""
moo.tests.test_stage14_backend_events — Unit tests for Stage 14.2 Backend Event Infrastructure.

Covers:
1. Recursive payload sanitization (nested dicts, lists, sets, tuples, objects).
2. Windows absolute path leakage removal (e.g. C:\\Users\\... -> filename).
3. POSIX absolute path leakage removal (e.g. /home/... -> filename).
4. Temporary directory name sanitization (toacd_web_*).
5. Internal Python memory address sanitization (<... at 0x...>).
6. Preservation of legitimate C source code and small hex literals (0x10, 0xFF).
7. JSON-serializability guarantee of sanitized payloads.
8. EventEnvelope validation of stage, sequence, and payload serialization.
9. PipelineStage enum contains PIPELINE_TIMING without breaking consumers.
10. Cascading stage failure handling (upstream abort cascades stage_skipped to downstream stages).
11. Exactly one terminal event emission per run.
"""

from __future__ import annotations

import os
import sys
import json
import unittest
from typing import Any, Dict, List

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from web.events import (
    EventEnvelope,
    SCHEMA_VERSION,
    PipelineStage,
    StageStatus,
    RunState,
    EventType,
    sanitize_string,
    sanitize_event_payload,
)
from moo.multiagent.orchestrator import MultiAgentOrchestrator
from moo.multiagent.schema import AgentMessage, MessageType, ROLE_ORCHESTRATOR
from moo.multiagent.agents import CodeAnalystAgent


class TestPayloadSanitization(unittest.TestCase):
    """Verifies that sensitive host paths and memory addresses are recursively stripped."""

    def test_windows_path_sanitization_in_errors(self):
        err = r"C:\Users\admin\Desktop\TOACD\compiler-optimization-selector-main\test_cases\gemm.c:12:4: error: use of undeclared identifier 'x'"
        sanitized = sanitize_string(err)
        self.assertNotIn("Users", sanitized)
        self.assertNotIn("admin", sanitized)
        self.assertNotIn("Desktop", sanitized)
        self.assertEqual(sanitized, "gemm.c:12:4: error: use of undeclared identifier 'x'")

    def test_posix_path_sanitization(self):
        err = "/home/developer/workspace/toacd/gemm.c:45:10: warning: unused variable"
        sanitized = sanitize_string(err)
        self.assertNotIn("home", sanitized)
        self.assertNotIn("developer", sanitized)
        self.assertEqual(sanitized, "gemm.c:45:10: warning: unused variable")

    def test_posix_extended_roots_sanitization(self):
        """Covers user-specified roots: /usr/local/bin/clang, /opt/llvm/bin/clang, /root/, /mnt/, /workspace/, /etc/"""
        self.assertEqual(sanitize_string("/usr/local/bin/clang"), "clang")
        self.assertEqual(sanitize_string("/opt/llvm/bin/clang"), "clang")
        self.assertEqual(sanitize_string("/usr/local/bin/opt: error: invalid pass"), "opt: error: invalid pass")
        self.assertEqual(sanitize_string("/root/"), "<sanitized_path>")
        self.assertEqual(sanitize_string("/mnt/"), "<sanitized_path>")
        self.assertEqual(sanitize_string("/workspace/"), "<sanitized_path>")
        self.assertEqual(sanitize_string("/etc/"), "<sanitized_path>")
        self.assertEqual(sanitize_string("/root/repo/code.c:10:2: note:"), "code.c:10:2: note:")
        self.assertEqual(sanitize_string("/workspace/src/gemm.c:5:1:"), "gemm.c:5:1:")
        self.assertEqual(sanitize_string("/etc/llvm/config.json: warning:"), "config.json: warning:")

    def test_windows_unc_paths_sanitization(self):
        """Covers Windows UNC paths with backslashes and forward slashes."""
        self.assertEqual(sanitize_string(r"\\server\share\builds\test.c:5:1:"), "test.c:5:1:")
        self.assertEqual(sanitize_string("//server/share/builds/test.c:5:1:"), "test.c:5:1:")
        self.assertEqual(sanitize_string(r"\\server\share\data"), "<sanitized_path>")
        self.assertEqual(sanitize_string("//server/share/output"), "<sanitized_path>")

    def test_windows_forward_slashes_and_root_files(self):
        """Covers Windows paths using forward slashes and root-level files."""
        self.assertEqual(sanitize_string("C:/Users/admin/gemm.c:12:4: error: syntax"), "gemm.c:12:4: error: syntax")
        self.assertEqual(sanitize_string("c:/gemm.c:1:1: error:"), "gemm.c:1:1: error:")
        self.assertEqual(sanitize_string(r"C:\gemm.c:1:1: error:"), "gemm.c:1:1: error:")
        self.assertEqual(sanitize_string("Output directory: C:/Users/admin/Desktop/output"), "Output directory: <sanitized_path>")

    def test_dictionary_keys_containing_paths(self):
        """Covers sanitization of paths in dictionary keys and nested structures."""
        payload = {
            r"C:\Users\admin\gemm.c": {"lines": 120},
            "/workspace/project/main.c": {"functions": 3},
            "/opt/llvm/bin/clang": {"version": "23.1.0"},
        }
        sanitized = sanitize_event_payload(payload)
        self.assertIn("gemm.c", sanitized)
        self.assertIn("main.c", sanitized)
        self.assertIn("clang", sanitized)
        self.assertNotIn("Users", str(sanitized.keys()))
        self.assertNotIn("workspace", str(sanitized.keys()))
        self.assertNotIn("opt", str(sanitized.keys()))

    def test_temporary_directory_sanitization(self):
        temp_path = r"C:\Users\rithv\AppData\Local\Temp\toacd_web_abc123def456\input.c"
        sanitized = sanitize_string(temp_path)
        self.assertNotIn("toacd_web_", sanitized)
        self.assertNotIn("AppData", sanitized)
        self.assertEqual(sanitized, "input.c")

    def test_python_memory_address_sanitization(self):
        repr_str = "<CompilerEnv object at 0x0000021A58EF8B20>"
        sanitized = sanitize_string(repr_str)
        self.assertNotIn("0x0000021A58EF8B20", sanitized)
        self.assertIn("0x<mem_address>", sanitized)

    def test_pointer_address_sanitization(self):
        ptr_dump = "Segfault occurred at address 0x00007fffa1b2c3d4 in opt"
        sanitized = sanitize_string(ptr_dump)
        self.assertNotIn("0x00007fffa1b2c3d4", sanitized)
        self.assertIn("0x<mem_addr>", sanitized)

    def test_preserves_legitimate_source_code_and_small_hex(self):
        code = (
            "#include <stdio.h>\n"
            "#define MASK 0x12345678\n"
            "#define BYTE 0xFF\n"
            "#define SMALL 0x10\n"
            "int main(void) {\n"
            "    float slope = (y2 - y1) / (x2 - x1) / 2.0;\n"
            "    // Line comment with / slash / elements\n"
            "    /* Block comment / with / slashes */\n"
            "    printf(\"val: %d\\n\", BYTE);\n"
            "    return 0;\n"
            "}\n"
        )
        sanitized = sanitize_string(code)
        self.assertEqual(sanitized, code)
        self.assertIn("0xFF", sanitized)
        self.assertIn("0x10", sanitized)
        self.assertIn("0x12345678", sanitized)
        self.assertIn("#include <stdio.h>", sanitized)
        self.assertIn("(y2 - y1) / (x2 - x1) / 2.0", sanitized)

    def test_recursive_dictionary_and_list_sanitization(self):
        payload = {
            "source_path": r"C:\Users\dev\AppData\Local\Temp\toacd_web_test123\kernel.c",
            "nested": {
                "compiler_diagnostics": [
                    r"C:\Users\dev\workspace\kernel.c:1:1: note: in expansion of macro",
                    "/var/log/llvm/toacd_web_test123/compile.log"
                ],
                "ptr": "0x000001B2C3D4E5F6",
                "obj": "<DecisionTrace at 0x000001B2C3D4E5F6>",
                "numbers": [1, 2.5, True, None],
                "set_data": {r"C:\test\file.c", "valid_string"}
            }
        }
        sanitized = sanitize_event_payload(payload)
        # Verify JSON serializable
        serialized = json.dumps(sanitized)
        self.assertIsInstance(serialized, str)
        self.assertNotIn("Users", serialized)
        self.assertNotIn("toacd_web_", serialized)
        self.assertNotIn("0x000001B2C3D4E5F6", serialized)
        self.assertEqual(sanitized["source_path"], "kernel.c")
        self.assertEqual(sanitized["nested"]["compiler_diagnostics"][0], "kernel.c:1:1: note: in expansion of macro")


class TestEnvelopeValidationAndTimingEnum(unittest.TestCase):
    """Verifies schema validation and pipeline_timing enum compatibility."""

    def test_pipeline_timing_enum_exists(self):
        self.assertEqual(PipelineStage.PIPELINE_TIMING.value, "pipeline_timing")
        self.assertIn(PipelineStage.PIPELINE_TIMING, list(PipelineStage))

    def test_envelope_validation_with_pipeline_timing(self):
        env = EventEnvelope(
            schema_version=SCHEMA_VERSION,
            event_id="evt_test_0001",
            run_id="run_test",
            program_id="gemm",
            seq=1,
            timestamp="2026-11-18T00:00:00Z",
            event_type=EventType.STAGE_COMPLETED.value,
            stage=PipelineStage.PIPELINE_TIMING.value,
            status=StageStatus.COMPLETED.value,
            payload={"ca_ms": 12.5, "total_ms": 105.0}
        )
        env.validate()
        self.assertEqual(env.stage, "pipeline_timing")

    def test_envelope_rejects_non_serializable_payload(self):
        class NonSerializable:
            pass

        env = EventEnvelope(
            schema_version=SCHEMA_VERSION,
            event_id="evt_test_0002",
            run_id="run_test",
            program_id="gemm",
            seq=2,
            timestamp="2026-11-18T00:00:00Z",
            event_type=EventType.STAGE_COMPLETED.value,
            stage=PipelineStage.PROFILING.value,
            status=StageStatus.COMPLETED.value,
            payload={"bad": NonSerializable()}
        )
        with self.assertRaises(ValueError):
            env.validate()


class TestCascadingStageFailure(unittest.TestCase):
    """Verifies that early stage failures cleanly cascade stage_skipped to all downstream stages."""

    def test_code_analyst_error_cascades_skips(self):
        class FailingCodeAnalyst(CodeAnalystAgent):
            def analyze(self, source_path: str, run_id: str, step: int) -> AgentMessage:
                return AgentMessage.create(
                    sender=self.name,
                    recipient=ROLE_ORCHESTRATOR,
                    message_type=MessageType.MSG_ERROR,
                    payload={"error": "Simulated source file missing", "stage": "code_analysis"},
                    run_id=run_id,
                    step=step,
                )

        stages_emitted: List[tuple] = []

        def on_stage(stage: str, status: str, payload: dict | None):
            stages_emitted.append((stage, status, payload or {}))

        orch = MultiAgentOrchestrator(code_analyst=FailingCodeAnalyst())
        record, log = orch.run(
            source_path="nonexistent_test.c",
            run_benchmarks=True,
            on_stage=on_stage,
        )

        # Expected: profiling started, profiling failed, then strategy_selection,
        # agent_review, security_verification, benchmarking, regression_analysis all skipped
        stage_names = [s[0] for s in stages_emitted]
        stage_statuses = [s[1] for s in stages_emitted]

        self.assertEqual(stages_emitted[0], ("profiling", "started", {"source_path": "nonexistent_test.c"}))
        self.assertEqual(stages_emitted[1][0], "profiling")
        self.assertEqual(stages_emitted[1][1], "failed")

        downstream = ["strategy_selection", "agent_review", "security_verification", "benchmarking", "regression_analysis"]
        for ds in downstream:
            self.assertIn(ds, stage_names)
            # Find status
            status_entry = [s for s in stages_emitted if s[0] == ds][0]
            self.assertEqual(status_entry[1], "skipped")
            self.assertIn("reason", status_entry[2])


if __name__ == "__main__":
    unittest.main()
