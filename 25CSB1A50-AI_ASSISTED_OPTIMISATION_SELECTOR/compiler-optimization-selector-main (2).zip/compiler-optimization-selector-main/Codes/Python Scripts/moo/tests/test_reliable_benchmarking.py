"""
Unit tests for TOACD reliable benchmarking pipeline.

Verifies:
1. Warmup exclusion (warmup runs not present in raw_samples_ns).
2. Interleaved execution (alternating execution to eliminate thermal/cache drift).
3. Statistical metrics (median, mean, stdev, CV, min, max).
4. Timing reliability detection (high variance correctly flags is_reliable=False).
5. Projection completeness (to_gui_view correctly exposes mean, stdev, CV, samples, flags).
"""

import unittest
import os
import sys
import shutil
import tempfile
from typing import List

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from moo.measurement import (
    TimingStats,
    MeasurementResult,
    measure_execution,
    measure_interleaved,
)
from moo.runrecord.schema import (
    RunRecord,
    MeasurementSnapshot,
    MeasurementStatus,
    RunStatus,
)
from moo.runrecord.projections import to_gui_view


class TestReliableBenchmarking(unittest.TestCase):

    def test_timing_stats_normal(self):
        """Verify standard statistical calculations on nanosecond samples."""
        samples_ns = [10_000_000, 10_200_000, 9_800_000, 10_100_000, 9_900_000]
        stats = TimingStats.from_samples(samples_ns)
        self.assertEqual(stats.n_samples, 5)
        self.assertEqual(stats.median_ns, 10_000_000.0)
        self.assertAlmostEqual(stats.mean_ns, 10_000_000.0, delta=1.0)
        self.assertEqual(stats.min_ns, 9_800_000.0)
        self.assertEqual(stats.max_ns, 10_200_000.0)
        self.assertIsNotNone(stats.stdev_ns)
        self.assertLess(stats.cv, 0.05)

    def test_timing_stats_high_variance(self):
        """Verify that high variance (CV >= 15%) is correctly computed in TimingStats."""
        samples_ns = [5_000_000, 25_000_000, 8_000_000, 30_000_000, 6_000_000]
        stats = TimingStats.from_samples(samples_ns)
        self.assertGreater(stats.cv, 0.15)

    def test_warmup_exclusion(self):
        """Verify that warmup runs are excluded from measured samples."""
        tmpdir = tempfile.mkdtemp(prefix="test_warmup_")
        try:
            exe_path = os.path.join(tmpdir, "mock_prog.bat")
            with open(exe_path, "w") as f:
                f.write("@echo off\r\necho OK\r\n")

            warmup_runs = 3
            measure_runs = 5
            res = measure_execution(
                exe_path,
                warmup_runs=warmup_runs,
                measure_runs=measure_runs,
                timeout_s=5,
            )
            self.assertIsNotNone(res.timing)
            self.assertEqual(len(res.raw_samples_ns), 5, "raw_samples_ns must strictly contain measure_runs, not warmups")
            self.assertEqual(res.warmup_runs, 3)
            self.assertEqual(res.measure_runs, 5)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_interleaved_measurement(self):
        """Verify interleaved measurement executes both candidates fairly."""
        tmpdir = tempfile.mkdtemp(prefix="test_interleaved_")
        try:
            exe1 = os.path.join(tmpdir, "prog1.bat")
            exe2 = os.path.join(tmpdir, "prog2.bat")
            with open(exe1, "w") as f:
                f.write("@echo off\r\necho P1\r\n")
            with open(exe2, "w") as f:
                f.write("@echo off\r\necho P2\r\n")

            executables = [
                ("baseline (-O0)", exe1),
                ("custom_opt", exe2),
            ]
            results = measure_interleaved(
                executables,
                warmup_runs=2,
                measure_runs=4,
                timeout_s=5,
            )
            self.assertEqual(len(results), 2)
            self.assertIn("baseline (-O0)", results)
            self.assertIn("custom_opt", results)
            self.assertEqual(len(results["baseline (-O0)"].raw_samples_ns), 4)
            self.assertEqual(len(results["custom_opt"].raw_samples_ns), 4)
            self.assertIsNotNone(results["baseline (-O0)"].timing.median_ns)
            self.assertIsNotNone(results["custom_opt"].timing.median_ns)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_to_gui_view_projections(self):
        """Verify to_gui_view exposes statistical breakdown, exact flags, and comparison verdict."""
        record = RunRecord(
            run_id="run_test_stat_view",
            source_file="test.c",
            source_hash="sha256_mock_hash",
            selected_strategy="-O2",
            benchmark_status=RunStatus.OK,
            baseline_status=MeasurementStatus.OK,
            optimized_status=MeasurementStatus.OK,
            baseline_measurement=MeasurementSnapshot(
                strategy="baseline (-O0)",
                status=MeasurementStatus.OK,
                median_s=0.040,
                code_size_bytes=10000,
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={
                    "mean_ns": 40_200_000,
                    "stdev_ns": 500_000,
                    "min_ns": 39_500_000,
                    "max_ns": 41_000_000,
                    "cv": 0.0124,
                    "samples_ns": [40_000_000, 40_200_000, 39_500_000, 41_000_000, 40_300_000],
                },
            ),
            optimized_measurement=MeasurementSnapshot(
                strategy="-O2",
                status=MeasurementStatus.OK,
                median_s=0.015,
                code_size_bytes=8500,
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={
                    "mean_ns": 15_100_000,
                    "stdev_ns": 200_000,
                    "min_ns": 14_900_000,
                    "max_ns": 15_400_000,
                    "cv": 0.0132,
                    "samples_ns": [15_000_000, 15_100_000, 14_900_000, 15_400_000, 15_100_000],
                },
            ),
        )

        view = to_gui_view(record)
        self.assertIsNotNone(view["baseline_timing"])
        self.assertIsNotNone(view["optimized_timing"])
        self.assertIsNotNone(view["performance_comparison"])

        base_t = view["baseline_timing"]
        self.assertEqual(base_t["compiler_flags"], "clang -O0")
        self.assertEqual(base_t["mean_s"], 0.0402)
        self.assertEqual(base_t["cv"], 0.0124)
        self.assertEqual(len(base_t["samples_ms"]), 5)

        opt_t = view["optimized_timing"]
        self.assertEqual(opt_t["compiler_flags"], "clang -O2")
        self.assertEqual(opt_t["mean_s"], 0.0151)
        self.assertEqual(len(opt_t["samples_ms"]), 5)

        comp = view["performance_comparison"]
        self.assertAlmostEqual(comp["speedup_ratio"], 2.667, places=2)
        self.assertEqual(comp["verdict"], "IMPROVED")
        self.assertTrue(comp["is_reliable"])
        self.assertEqual(comp["delta_size_bytes"], -1500)

    def test_output_mismatch_fails_correctness(self):
        """P5.1: Verify output mismatch sets output_matches_reference=False and timing_is_reliable=False."""
        tmpdir = tempfile.mkdtemp(prefix="test_mismatch_")
        try:
            exe_ref = os.path.join(tmpdir, "ref.bat")
            exe_bad = os.path.join(tmpdir, "bad.bat")
            with open(exe_ref, "w") as f:
                f.write("@echo off\r\necho EXPECTED_HASH_42\r\n")
            with open(exe_bad, "w") as f:
                f.write("@echo off\r\necho CORRUPTED_OUTPUT_99\r\n")

            targets = [
                ("baseline (-O0)", exe_ref),
                ("candidate", exe_bad),
            ]
            results = measure_interleaved(
                targets=targets,
                warmup_runs=1,
                measure_runs=3,
                timeout_s=5,
                expected_stdout="EXPECTED_HASH_42\r\n",
                expected_exit_code=0,
            )
            self.assertTrue(results["baseline (-O0)"].output_matches_reference)
            self.assertFalse(results["candidate"].output_matches_reference)
            self.assertFalse(results["candidate"].timing_is_reliable)
            self.assertIn("Output mismatch with reference", results["candidate"].measurement_error)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_nondeterministic_output_detected(self):
        """P5.2: Verify that non-deterministic output across samples is detected and flags unreliable."""
        tmpdir = tempfile.mkdtemp(prefix="test_nondet_")
        try:
            exe_nondet = os.path.join(tmpdir, "nondet.bat")
            # Uses python inline to output high-resolution timestamp, guaranteeing different stdout on each run
            with open(exe_nondet, "w") as f:
                f.write('@python -c "import time; print(time.time_ns())"\r\n')

            targets = [("candidate_nondet", exe_nondet)]
            results = measure_interleaved(
                targets=targets,
                warmup_runs=1,
                measure_runs=4,
                timeout_s=5,
            )
            res = results["candidate_nondet"]
            self.assertFalse(res.output_is_deterministic)
            self.assertFalse(res.timing_is_reliable)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_unexpected_exit_code_invalidates_candidate(self):
        """P5.3: Verify unexpected exit code forces rc_match=False and timing_is_reliable=False."""
        tmpdir = tempfile.mkdtemp(prefix="test_rc_")
        try:
            exe_crash = os.path.join(tmpdir, "crash.bat")
            with open(exe_crash, "w") as f:
                f.write("@echo off\r\nexit /b 42\r\n")

            targets = [("crashing_cand", exe_crash)]
            results = measure_interleaved(
                targets=targets,
                warmup_runs=1,
                measure_runs=3,
                timeout_s=5,
                expected_exit_code=0,
            )
            res = results["crashing_cand"]
            self.assertFalse(res.timing_is_reliable)
            self.assertIn("Exit code mismatch", res.measurement_error)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_dual_baseline_projections_generated(self):
        """P5.4: Verify both baseline comparisons (vs -O0 and vs -O3) are independently projected."""
        record = RunRecord(
            run_id="run_dual_base",
            source_file="gemm.c",
            source_hash="sha256_gemm",
            selected_strategy="-O2",
            benchmark_status=RunStatus.OK,
            baseline_status=MeasurementStatus.OK,
            production_status=MeasurementStatus.OK,
            optimized_status=MeasurementStatus.OK,
            baseline_measurement=MeasurementSnapshot(
                strategy="baseline (-O0)",
                status=MeasurementStatus.OK,
                median_s=0.060,
                code_size_bytes=12000,
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [60_000_000] * 5, "cv": 0.01},
            ),
            production_measurement=MeasurementSnapshot(
                strategy="-O3",
                status=MeasurementStatus.OK,
                median_s=0.030,
                code_size_bytes=9000,
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [30_000_000] * 5, "cv": 0.02},
            ),
            optimized_measurement=MeasurementSnapshot(
                strategy="-O2",
                status=MeasurementStatus.OK,
                median_s=0.020,
                code_size_bytes=8000,
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [20_000_000] * 5, "cv": 0.015},
            ),
        )

        view = to_gui_view(record)
        self.assertIn("perf_comp_o0", view)
        self.assertIn("perf_comp_o3", view)

        comp_o0 = view["perf_comp_o0"]
        self.assertEqual(comp_o0["baseline_identity"], "paired_o0")
        self.assertAlmostEqual(comp_o0["speedup_ratio"], 3.0, places=2)
        self.assertEqual(comp_o0["verdict"], "IMPROVED")

        comp_o3 = view["perf_comp_o3"]
        self.assertEqual(comp_o3["baseline_identity"], "production_o3")
        self.assertAlmostEqual(comp_o3["speedup_ratio"], 1.5, places=2)
        self.assertEqual(comp_o3["verdict"], "IMPROVED")

    def test_high_variance_measurements_cannot_be_improved(self):
        """P5.5: High variance measurements (CV > 10%) must receive INCONCLUSIVE verdict despite apparent speedup."""
        record = RunRecord(
            run_id="run_noisy_win",
            source_file="noisy.c",
            source_hash="sha256_noisy",
            selected_strategy="-O2",
            benchmark_status=RunStatus.OK,
            baseline_status=MeasurementStatus.OK,
            optimized_status=MeasurementStatus.OK,
            baseline_measurement=MeasurementSnapshot(
                strategy="baseline (-O0)",
                status=MeasurementStatus.OK,
                median_s=0.050,
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [50_000_000] * 5, "cv": 0.01},
            ),
            optimized_measurement=MeasurementSnapshot(
                strategy="-O2",
                status=MeasurementStatus.OK,
                median_s=0.010, # Apparent 5x speedup
                timing_is_reliable=False, # Flawed by high noise
                n_samples=5,
                measurement_dict={"samples_ns": [5_000_000, 30_000_000, 7_000_000, 25_000_000, 6_000_000], "cv": 0.75},
            ),
        )

        view = to_gui_view(record)
        comp = view["performance_comparison"]
        self.assertEqual(comp["verdict"], "INCONCLUSIVE", "High variance measurement must NEVER be given IMPROVED verdict")
        self.assertFalse(comp["is_reliable"])
        self.assertEqual(comp["significance"], "UNRELIABLE")

    def test_missing_reliability_treated_as_unreliable(self):
        """P5.6: Missing or None timing_is_reliable must be treated as unreliable, never as confirmed reliable."""
        record = RunRecord(
            run_id="run_missing_rel",
            source_file="test.c",
            source_hash="sha256_test",
            selected_strategy="-O2",
            benchmark_status=RunStatus.OK,
            baseline_status=MeasurementStatus.OK,
            optimized_status=MeasurementStatus.OK,
            baseline_measurement=MeasurementSnapshot(
                strategy="baseline (-O0)",
                status=MeasurementStatus.OK,
                median_s=0.040,
                timing_is_reliable=None, # Missing/uncomputed
            ),
            optimized_measurement=MeasurementSnapshot(
                strategy="-O2",
                status=MeasurementStatus.OK,
                median_s=0.020,
                timing_is_reliable=None, # Missing/uncomputed
            ),
        )
        view = to_gui_view(record)
        comp = view["performance_comparison"]
        self.assertEqual(comp["verdict"], "INCONCLUSIVE")
        self.assertFalse(comp["is_reliable"])

    def test_dual_baselines_never_mix_or_cross_contaminate(self):
        """P5.7: Verify that paired -O0 and production -O3 baselines never mix or contaminate each other."""
        record = RunRecord(
            run_id="run_strict_separation",
            source_file="kernel.c",
            source_hash="sha256_kernel",
            selected_strategy="-O2",
            benchmark_status=RunStatus.OK,
            baseline_status=MeasurementStatus.OK,
            production_status=MeasurementStatus.OK,
            optimized_status=MeasurementStatus.OK,
            baseline_measurement=MeasurementSnapshot(
                strategy="baseline (-O0)",
                status=MeasurementStatus.OK,
                median_s=0.050,  # 50 ms
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [50_000_000] * 5, "cv": 0.01},
            ),
            production_measurement=MeasurementSnapshot(
                strategy="-O3",
                status=MeasurementStatus.OK,
                median_s=0.025,  # 25 ms
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [25_000_000] * 5, "cv": 0.01},
            ),
            optimized_measurement=MeasurementSnapshot(
                strategy="-O2",
                status=MeasurementStatus.OK,
                median_s=0.020,  # 20 ms
                timing_is_reliable=True,
                n_samples=5,
                measurement_dict={"samples_ns": [20_000_000] * 5, "cv": 0.01},
            ),
        )

        view = to_gui_view(record)

        # 1. Check paired -O0 comparison
        comp_o0 = view["perf_comp_o0"]
        self.assertEqual(comp_o0["baseline_identity"], "paired_o0")
        self.assertEqual(comp_o0["baseline_flags"], "clang -O0")
        self.assertAlmostEqual(comp_o0["speedup_ratio"], 2.50, places=2) # 50 / 20 = 2.5x
        self.assertAlmostEqual(comp_o0["improvement_pct"], 60.0, places=1) # (50-20)/50 * 100 = 60%

        # 2. Check production -O3 comparison
        comp_o3 = view["perf_comp_o3"]
        self.assertEqual(comp_o3["baseline_identity"], "production_o3")
        self.assertEqual(comp_o3["baseline_flags"], "clang -O3")
        self.assertAlmostEqual(comp_o3["speedup_ratio"], 1.25, places=2) # 25 / 20 = 1.25x
        self.assertAlmostEqual(comp_o3["improvement_pct"], 20.0, places=1) # (25-20)/25 * 100 = 20%

        # 3. Invariants: comparisons must never cross-pollinate
        self.assertNotEqual(comp_o0["speedup_ratio"], comp_o3["speedup_ratio"])
        self.assertNotEqual(comp_o0["baseline_flags"], comp_o3["baseline_flags"])

    def test_line_ending_crlf_lf_equivalence(self):
        """Verify CRLF (Windows) and LF (Unix) line endings are recognized as equivalent."""
        tmpdir = tempfile.mkdtemp(prefix="test_crlf_")
        try:
            exe_crlf = os.path.join(tmpdir, "win.bat")
            with open(exe_crlf, "w") as f:
                f.write("@echo off\r\necho C[0][0] = 734.885784\r\n")

            targets = [("candidate_crlf", exe_crlf)]
            # Reference expected_stdout uses Unix LF '\n'
            results = measure_interleaved(
                targets=targets,
                warmup_runs=3,
                measure_runs=5,
                timeout_s=5,
                expected_stdout="C[0][0] = 734.885784\n",
                expected_exit_code=0,
            )
            res = results["candidate_crlf"]
            self.assertTrue(res.output_matches_reference, "CRLF target must match LF reference")
            self.assertTrue(res.output_is_deterministic)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_line_ending_cr_lf_equivalence(self):
        """Verify CR (legacy Mac) and LF line endings are recognized as equivalent."""
        from moo.measurement import normalize_output
        cr_bytes = b"Line 1\rLine 2\r"
        lf_bytes = b"Line 1\nLine 2\n"
        crlf_bytes = b"Line 1\r\nLine 2\r\n"
        self.assertEqual(normalize_output(cr_bytes), normalize_output(lf_bytes))
        self.assertEqual(normalize_output(crlf_bytes), normalize_output(lf_bytes))

    def test_meaningful_numerical_mismatch_fails_correctness(self):
        """Verify that genuine numerical differences are NOT ignored by line-ending normalization."""
        tmpdir = tempfile.mkdtemp(prefix="test_diff_num_")
        try:
            exe_cand = os.path.join(tmpdir, "cand.bat")
            with open(exe_cand, "w") as f:
                f.write("@echo off\r\necho C[0][0] = 734.885785\r\n")

            targets = [("cand", exe_cand)]
            results = measure_interleaved(
                targets=targets,
                warmup_runs=1,
                measure_runs=3,
                timeout_s=5,
                expected_stdout="C[0][0] = 734.885784\n",
                expected_exit_code=0,
            )
            res = results["cand"]
            self.assertFalse(res.output_matches_reference, "Numerical difference must fail correctness")
            self.assertFalse(res.timing_is_reliable)
            self.assertIn("Output mismatch with reference", res.measurement_error)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_whitespace_differences_are_not_stripped(self):
        """Verify that trailing spaces and formatting differences are strictly preserved and fail."""
        tmpdir = tempfile.mkdtemp(prefix="test_diff_ws_")
        try:
            exe_cand = os.path.join(tmpdir, "cand_ws.bat")
            with open(exe_cand, "w") as f:
                f.write("@echo off\r\necho result = 42 \r\n") # trailing space before newline

            targets = [("cand_ws", exe_cand)]
            results = measure_interleaved(
                targets=targets,
                warmup_runs=1,
                measure_runs=3,
                timeout_s=5,
                expected_stdout="result = 42\n", # no trailing space
                expected_exit_code=0,
            )
            res = results["cand_ws"]
            self.assertFalse(res.output_matches_reference, "Extra whitespace must NOT be silently stripped")
            self.assertFalse(res.timing_is_reliable)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
