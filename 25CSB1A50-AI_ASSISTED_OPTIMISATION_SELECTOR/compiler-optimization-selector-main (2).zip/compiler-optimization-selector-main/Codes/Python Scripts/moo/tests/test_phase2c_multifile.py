"""
moo.tests.test_phase2c_multifile — Comprehensive Verification Suite for Phase 2C.

Verifies:
1. CProject data model, validation, path traversal rejection, and deterministic hashing.
2. Scenario 1: Multiple source files sharing a common header.
3. Scenario 2: Nested include directories with relative and configured paths.
4. Scenario 3: Macro-dependent compilation with BuildConfig defines.
5. Scenario 4: Multiple translation units with cross-file function calls.
6. Scenario 5: Standard/math library linking (-lm or standard math).
7. Scenario 6: Missing header rejection (fail-closed compiler error).
8. Scenario 7: Missing function definition (linker failure handling).
9. Scenario 8: Duplicate symbol definition (linker failure handling).
10. Scenario 9: Invalid syntax in one translation unit (graceful diagnostic).
11. Scenario 10: Incorrect candidate output (correctness validator rejection).
12. Scenario 11: Runtime crash handling (SIGSEGV/abort handling without hanging).
13. Scenario 12: Timeout handling (infinite loop execution terminates safely).
14. Backward compatibility: single-file C programs continue working identically.
15. End-to-end MultiAgentOrchestrator execution on multi-file CProject.
"""

import os
import sys
import tempfile
import shutil
import subprocess
import pytest
from unittest import mock

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from moo.project import CProject
from moo.build_config import BuildConfig
from moo.ir_cache import compute_source_hash
from moo.toolchain import verify_toolchain, probe_llvm_link
from moo.config import CLANG_PATH
from ml_optimizer import CompilerEnv
from moo.pipeline import evaluate_program, _check_correctness_simple
from moo.multiagent.orchestrator import MultiAgentOrchestrator


@pytest.fixture
def tmp_project_dir():
    d = tempfile.mkdtemp(prefix="toacd_p2c_test_")
    yield d
    shutil.rmtree(d, ignore_errors=True)


# =========================================================================
# 0. CProject Construction, Security & Traversal Protection
# =========================================================================

def test_cproject_from_files_dict_security_traversal(tmp_project_dir):
    """Path traversal sequences (..) in files dict must be rejected fail-closed."""
    malicious_files = {
        "../outside.c": "int evil = 1;",
        "main.c": "int main() { return 0; }",
    }
    with pytest.raises(ValueError, match="traversal|escapes"):
        CProject.from_files_dict(malicious_files, project_root=tmp_project_dir)


def test_cproject_invalid_extensions(tmp_project_dir):
    """Disallowed file extensions must be rejected fail-closed."""
    bad_files = {
        "script.sh": "#!/bin/sh\nexit 0;",
        "main.c": "int main() { return 0; }",
    }
    with pytest.raises(ValueError, match="Disallowed file extension"):
        CProject.from_files_dict(bad_files, project_root=tmp_project_dir)


def test_symlink_pointing_outside_root(tmp_project_dir):
    """Symlink pointing to an external file must be detected and rejected."""
    outside_dir = tempfile.mkdtemp(prefix="outside_")
    outside_file = os.path.join(outside_dir, "outside.c")
    try:
        with open(outside_file, "w") as f:
            f.write("int outside_fn() { return 42; }")

        link_name = "symlink_escape.c"
        link_path = os.path.join(tmp_project_dir, link_name)
        try:
            os.symlink(outside_file, link_path)
            # Live symlink created
            proj = CProject(project_root=tmp_project_dir, source_files=[link_name])
            errs = proj.validate()
            assert any("escapes project root" in e for e in errs)
        except OSError:
            # Fall back to mock if OS permission denies symlink creation
            with mock.patch("os.path.realpath", side_effect=lambda p: outside_file if link_name in str(p) else os.path.abspath(p)):
                with mock.patch("os.path.isfile", return_value=True):
                    proj = CProject(project_root=tmp_project_dir, source_files=[link_name])
                    errs = proj.validate()
                    assert any("escapes project root" in e for e in errs)
    finally:
        shutil.rmtree(outside_dir, ignore_errors=True)


def test_nested_symlink_pointing_outside_root(tmp_project_dir):
    """Symlink within a nested subdirectory pointing outside must be rejected."""
    outside_dir = tempfile.mkdtemp(prefix="outside_nested_")
    outside_hdr = os.path.join(outside_dir, "secret.h")
    try:
        with open(outside_hdr, "w") as f:
            f.write("#define SECRET 999")

        nested_dir = os.path.join(tmp_project_dir, "sub", "include")
        os.makedirs(nested_dir, exist_ok=True)
        link_rel = "sub/include/symlink_secret.h"
        link_path = os.path.join(tmp_project_dir, "sub", "include", "symlink_secret.h")
        main_c = os.path.join(tmp_project_dir, "main.c")
        with open(main_c, "w") as f:
            f.write("int main() { return 0; }")

        try:
            os.symlink(outside_hdr, link_path)
            proj = CProject(project_root=tmp_project_dir, source_files=["main.c"], header_files=[link_rel])
            errs = proj.validate()
            assert any("escapes project root" in e for e in errs)
        except OSError:
            with mock.patch("os.path.realpath", side_effect=lambda p: outside_hdr if "symlink_secret" in str(p) else os.path.abspath(p)):
                with mock.patch("os.path.isfile", return_value=True):
                    proj = CProject(project_root=tmp_project_dir, source_files=["main.c"], header_files=[link_rel])
                    errs = proj.validate()
                    assert any("escapes project root" in e for e in errs)
    finally:
        shutil.rmtree(outside_dir, ignore_errors=True)


def test_symlinked_include_directory_rejection(tmp_project_dir):
    """Include directory escaping project root via symlink or absolute path must be rejected."""
    outside_dir = tempfile.mkdtemp(prefix="outside_inc_")
    try:
        main_c = os.path.join(tmp_project_dir, "main.c")
        with open(main_c, "w") as f:
            f.write("int main() { return 0; }")

        proj = CProject(project_root=tmp_project_dir, source_files=["main.c"], include_dirs=[outside_dir])
        errs = proj.validate()
        assert any("Include directory escapes project root" in e for e in errs)
    finally:
        shutil.rmtree(outside_dir, ignore_errors=True)


def test_normal_nested_directory_accepted(tmp_project_dir):
    """Legitimate nested directories inside project root must be accepted without errors."""
    sub_src = os.path.join(tmp_project_dir, "src", "math")
    sub_inc = os.path.join(tmp_project_dir, "include")
    os.makedirs(sub_src, exist_ok=True)
    os.makedirs(sub_inc, exist_ok=True)

    with open(os.path.join(sub_src, "math.c"), "w") as f:
        f.write("#include \"math.h\"\nint add(int a, int b) { return a + b; }")
    with open(os.path.join(sub_inc, "math.h"), "w") as f:
        f.write("int add(int a, int b);")
    with open(os.path.join(tmp_project_dir, "main.c"), "w") as f:
        f.write("#include \"math.h\"\nint main() { return add(1, 2); }")

    proj = CProject.from_directory(tmp_project_dir)
    errs = proj.validate()
    assert errs == []
    assert "main.c" in proj.source_files
    assert any("math.c" in s for s in proj.source_files)
    assert any("math.h" in h for h in proj.header_files)


def test_cproject_deterministic_hashing(tmp_project_dir):
    """Project hashing must be deterministic regardless of insertion order."""
    files_a = {
        "b.c": "int f_b() { return 2; }",
        "a.c": "int f_a() { return 1; }",
        "common.h": "#define VAL 10",
    }
    files_b = {
        "common.h": "#define VAL 10",
        "a.c": "int f_a() { return 1; }",
        "b.c": "int f_b() { return 2; }",
    }
    dir_a = os.path.join(tmp_project_dir, "proj_a")
    dir_b = os.path.join(tmp_project_dir, "proj_b")
    os.makedirs(dir_a, exist_ok=True)
    os.makedirs(dir_b, exist_ok=True)

    proj_a = CProject.from_files_dict(files_a, project_root=dir_a)
    proj_b = CProject.from_files_dict(files_b, project_root=dir_b)

    hash_a = compute_source_hash(proj_a)
    hash_b = compute_source_hash(proj_b)
    assert hash_a == hash_b
    assert len(hash_a) == 64


# =========================================================================
# Scenario 1: Multiple source files sharing a header
# =========================================================================

def test_scenario_1_shared_header(tmp_project_dir):
    """Multiple source files sharing a common header compile and extract features."""
    files = {
        "types.h": """
#ifndef TYPES_H
#define TYPES_H
int compute_add(int a, int b);
#endif
""",
        "compute.c": """
#include "types.h"
int compute_add(int a, int b) {
    return a + b;
}
""",
        "main.c": """
#include <stdio.h>
#include "types.h"
int main(void) {
    int res = compute_add(10, 20);
    printf("res=%d\\n", res);
    return 0;
}
""",
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    assert env.features is not None
    assert len(env.features) == 8
    # InstructionsCount is at index 1, CallInstCount is at index 7
    assert env.features[1] > 0
    assert env.features[7] > 0
    env.cleanup()


# =========================================================================
# Scenario 2: Nested include directories
# =========================================================================

def test_scenario_2_nested_include_dirs(tmp_project_dir):
    """Headers in nested subdirectories are found and compiled cleanly."""
    inc_dir = os.path.join(tmp_project_dir, "include", "nested")
    src_dir = os.path.join(tmp_project_dir, "src")
    os.makedirs(inc_dir, exist_ok=True)
    os.makedirs(src_dir, exist_ok=True)

    header_path = os.path.join(inc_dir, "deep_algo.h")
    with open(header_path, "w", encoding="utf-8") as f:
        f.write("int deep_multiplier(int x);\n")

    algo_path = os.path.join(src_dir, "deep_algo.c")
    with open(algo_path, "w", encoding="utf-8") as f:
        f.write('#include "deep_algo.h"\nint deep_multiplier(int x) { return x * 3; }\n')

    main_path = os.path.join(src_dir, "main.c")
    with open(main_path, "w", encoding="utf-8") as f:
        f.write('#include <stdio.h>\n#include "deep_algo.h"\nint main(void) { printf("%d\\n", deep_multiplier(7)); return 0; }\n')

    bcfg = BuildConfig(include_dirs=["include/nested"])
    proj = CProject.from_directory(tmp_project_dir, build_config=bcfg)
    assert len(proj.source_files) == 2
    assert len(proj.header_files) == 1

    env = CompilerEnv(proj)
    assert env.features[1] > 0
    env.cleanup()


# =========================================================================
# Scenario 3: Macro-dependent compilation
# =========================================================================

def test_scenario_3_macro_dependent_compilation(tmp_project_dir):
    """BuildConfig defines (-DMATRIX_SIZE=32) configure compilation correctly."""
    files = {
        "matrix.h": """
#ifndef MATRIX_SIZE
#error "MATRIX_SIZE not defined!"
#endif
int get_matrix_size(void);
""",
        "matrix.c": """
#include "matrix.h"
int get_matrix_size(void) {
    return MATRIX_SIZE;
}
""",
        "main.c": """
#include <stdio.h>
#include "matrix.h"
int main(void) {
    printf("size=%d\\n", get_matrix_size());
    return 0;
}
""",
    }
    bcfg = BuildConfig(defines={"MATRIX_SIZE": "32"})
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir, build_config=bcfg)
    env = CompilerEnv(proj)
    assert env.features[1] > 0
    env.cleanup()


# =========================================================================
# Scenario 4: Cross-file function calls & linking
# =========================================================================

def test_scenario_4_cross_file_calls(tmp_project_dir):
    """Multiple translation units with cross-file calls compile, step, and execute."""
    files = {
        "ops.h": "int square(int x);\nint cube(int x);\n",
        "square.c": '#include "ops.h"\nint square(int x) { return x * x; }\n',
        "cube.c": '#include "ops.h"\nint cube(int x) { return x * square(x); }\n',
        "main.c": """
#include <stdio.h>
#include "ops.h"
int main(void) {
    printf("cube(3)=%d\\n", cube(3));
    return 0;
}
""",
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    next_state, reward, done, info = env.step(1)  # -O1
    assert done is True
    assert info.get("build_ok") is True
    assert info.get("returncode") == 0
    assert "cube(3)=27" in info.get("stdout", "")
    env.cleanup()


# =========================================================================
# Scenario 5: External library linking
# =========================================================================

def test_scenario_5_math_library_linking(tmp_project_dir):
    """Math library calls compile and execute under BuildConfig libraries."""
    files = {
        "main.c": """
#include <stdio.h>
#include <math.h>
int main(void) {
    double v = sqrt(16.0);
    printf("sqrt=%f\\n", v);
    return 0;
}
"""
    }
    bcfg = BuildConfig(libraries=["m"] if os.name != "nt" else [])
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir, build_config=bcfg)
    env = CompilerEnv(proj)
    next_state, reward, done, info = env.step(2)  # -O2
    assert done is True
    assert info.get("build_ok") is True
    assert "sqrt=4.000000" in info.get("stdout", "")
    env.cleanup()


# =========================================================================
# Scenario 6: Missing header rejection
# =========================================================================

def test_scenario_6_missing_header_rejection(tmp_project_dir):
    """Compilation fails cleanly when an essential header is missing."""
    files = {
        "main.c": """
#include "non_existent_header.h"
int main(void) {
    return 0;
}
"""
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    # Features fall back to zeros when compilation fails
    assert all(f == 0 for f in env.features)
    next_state, reward, done, info = env.step(1)
    assert info.get("build_ok") is False
    env.cleanup()


# =========================================================================
# Scenario 7: Missing function definition (linker failure handling)
# =========================================================================

def test_scenario_7_missing_function_definition(tmp_project_dir):
    """Undefined symbols cause a link failure that is cleanly captured."""
    files = {
        "proto.h": "int missing_impl(void);\n",
        "main.c": """
#include "proto.h"
int main(void) {
    return missing_impl();
}
"""
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    next_state, reward, done, info = env.step(1)
    assert done is True
    assert info.get("build_ok") is False
    err = info.get("compiler_error", "").lower()
    assert "unresolved external" in err or "undefined reference" in err or "symbol" in err
    env.cleanup()


# =========================================================================
# Scenario 8: Duplicate symbol definition (linker failure handling)
# =========================================================================

def test_scenario_8_duplicate_symbol_definition(tmp_project_dir):
    """Duplicate symbol definition across translation units causes clean linker failure."""
    files = {
        "tu1.c": "int duplicate_var = 42;\n",
        "tu2.c": "int duplicate_var = 84;\n",
        "main.c": "int main(void) { return 0; }\n",
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    next_state, reward, done, info = env.step(1)
    assert done is True
    assert info.get("build_ok") is False
    err = info.get("compiler_error", "").lower()
    assert "already defined" in err or "multiple definition" in err or "duplicate" in err or "redefinition" in err
    env.cleanup()


# =========================================================================
# Scenario 9: Invalid syntax in one translation unit
# =========================================================================

def test_scenario_9_invalid_syntax_in_tu(tmp_project_dir):
    """Syntax error in one TU is caught gracefully without unhandled exceptions."""
    files = {
        "ok.c": "int helper(void) { return 1; }\n",
        "broken.c": "int bad_syntax( { return 2; }\n",
        "main.c": "int main(void) { return 0; }\n",
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    assert all(f == 0 for f in env.features)
    next_state, reward, done, info = env.step(1)
    assert info.get("build_ok") is False
    env.cleanup()


# =========================================================================
# Scenario 10: Incorrect candidate output (correctness validator rejection)
# =========================================================================

def test_scenario_10_correctness_validator_rejection(tmp_project_dir):
    """Optimization that changes output is marked failed by the correctness validator."""
    # Build candidate executable that outputs something differing from reference
    cand_c = os.path.join(tmp_project_dir, "cand.c")
    with open(cand_c, "w") as f:
        f.write('#include <stdio.h>\nint main(void) { printf("DIFFERENT_OUTPUT\\n"); return 0; }\n')
    cand_exe = os.path.join(tmp_project_dir, "cand.exe")
    subprocess.run([CLANG_PATH, cand_c, "-o", cand_exe], capture_output=True)

    correct, rc, note, out = _check_correctness_simple(
        candidate_exe=cand_exe,
        ref_exit_code=0,
        ref_stdout="ORIGINAL_OUTPUT\n",
        timeout_s=5,
    )
    assert correct is False
    assert "stdout differs" in note.lower() or "incorrect" in note.lower() or "exit code" in note.lower()


# =========================================================================
# Scenario 11: Runtime crash handling
# =========================================================================

def test_scenario_11_runtime_crash_handling(tmp_project_dir):
    """Runtime crash (e.g. abort()) is safely captured without hanging."""
    files = {
        "main.c": """
#include <stdlib.h>
int main(void) {
    abort();
    return 0;
}
"""
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj)
    next_state, reward, done, info = env.step(1)
    assert done is True
    assert info.get("build_ok") is True
    assert info.get("returncode") != 0
    env.cleanup()


# =========================================================================
# Scenario 12: Timeout handling
# =========================================================================

def test_scenario_12_timeout_handling(tmp_project_dir):
    """Infinite loop execution is terminated within the timeout without hanging the process."""
    files = {
        "loop.h": "void run_forever(void);\n",
        "loop.c": '#include "loop.h"\nvoid run_forever(void) { volatile int x = 0; while (1) { x++; } }\n',
        "main.c": """
#include "loop.h"
int main(void) {
    run_forever();
    return 0;
}
""",
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    env = CompilerEnv(proj, timeout=2)
    next_state, reward, done, info = env.step(1)
    assert done is True
    assert info.get("timed_out") is True
    env.cleanup()


# =========================================================================
# 13. Backward Compatibility: Single-File C Programs
# =========================================================================

def test_backward_compatibility_single_file(tmp_project_dir):
    """Single-file C program passes through CompilerEnv and evaluate_program seamlessly."""
    single_file = os.path.join(tmp_project_dir, "standalone.c")
    with open(single_file, "w", encoding="utf-8") as f:
        f.write("""
#include <stdio.h>
int main(void) {
    int acc = 0;
    for (int i = 0; i < 50; i++) acc += i;
    printf("acc=%d\\n", acc);
    return 0;
}
""")
    env = CompilerEnv(single_file)
    assert env.project.is_multi_file is False
    assert len(env.features) == 8
    assert env.features[1] > 0
    next_state, reward, done, info = env.step(2)
    assert done is True
    assert info.get("build_ok") is True
    assert "acc=1225" in info.get("stdout", "")
    env.cleanup()


# =========================================================================
# 14. End-to-End MultiAgentOrchestrator Execution on Multi-File Project
# =========================================================================

def test_multiagent_orchestrator_multifile_e2e(tmp_project_dir):
    """MultiAgentOrchestrator runs full 6-agent pipeline on a multi-file CProject."""
    files = {
        "math_ops.h": "int sum_range(int n);\n",
        "math_ops.c": """
#include "math_ops.h"
int sum_range(int n) {
    int total = 0;
    for (int i = 1; i <= n; i++) {
        total += i;
    }
    return total;
}
""",
        "main.c": """
#include <stdio.h>
#include "math_ops.h"
int main(void) {
    int s = sum_range(100);
    printf("total=%d\\n", s);
    return 0;
}
""",
    }
    proj = CProject.from_files_dict(files, project_root=tmp_project_dir)
    orch = MultiAgentOrchestrator()
    record, msg_log = orch.run(
        source_path=proj,
        selected_strategy="-O2",
        run_benchmarks=True,
        run_security=True,
        run_regression=False,
        run_adaptive=False,
        run_agentic=False,
        warmup_runs=1,
        measure_runs=2,
        timeout_s=10,
    )

    assert record is not None
    assert record.is_multi_file is True
    assert len(record.project_files) >= 2
    assert record.effective_strategy in ("-O2", "-O3", "-O1")
    assert record.security_gate is not None
    assert record.security_gate["decision"] in ("PASS", "FALLBACK", "ACCEPT")
    assert record.baseline_measurement is not None
    assert record.optimized_measurement is not None
