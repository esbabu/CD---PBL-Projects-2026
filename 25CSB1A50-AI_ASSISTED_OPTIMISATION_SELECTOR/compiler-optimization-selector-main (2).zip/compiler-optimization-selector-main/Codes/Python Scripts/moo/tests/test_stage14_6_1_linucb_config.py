"""
moo.tests.test_stage14_6_1_linucb_config — Stage 14.6.1 LinUCB Deployment Configuration Tests.

Verifies:
1. Production inference loads validation-selected alpha = 0.1 from centralized config.
2. Missing or invalid deployment configurations fail clearly with descriptive exceptions.
3. Checkpoint learned parameters (A, b, thetas, counts) and SQLite version remain strictly unchanged.
4. Feature scaler hash and parameters remain strictly unchanged.
5. DQN remains the application's default and its behavior is completely unchanged.
6. LinUCB mathematical provenance (predicted reward, bonus, UCB score) is accurate under alpha = 0.1.
7. MOO override provenance correctly distinguishes recommended vs selected action.
8. Security Gate authority and fallback ladder remain unchanged.
"""

from __future__ import annotations

import os
import sys
import json
import tempfile
import hashlib
import unittest
from unittest.mock import MagicMock, patch

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from moo.bandit.config import (
    LinUCBDeploymentConfig,
    load_linucb_deployment_config,
    find_models_dir,
)
from moo.bandit.persistence import SQLiteEvaluationLedger
from moo.bandit.features import LinUCBFeatureScaler
from optimization_selector import select_with_provenance, ACTIONS


class TestStage1461LinUCBConfig(unittest.TestCase):
    """Test suite for Stage 14.6.1 LinUCB Deployment Configuration Alignment."""

    def setUp(self):
        self.models_dir = find_models_dir()
        self.scaler_path = os.path.join(self.models_dir, "linucb_feature_scaler.json")
        self.config_path = os.path.join(self.models_dir, "linucb_deployment_config.json")
        self.raw_feats = [47.0, 470.0, 47.0, 224.0, 16.0, 4.0, 0.0, 20.0]
        # Locate sample C file
        p = os.path.abspath(_scripts_dir)
        self.c_file = os.path.join(os.path.dirname(p), "Codes", "test_cases", "gemm.c")
        if not os.path.exists(self.c_file):
            for root, _, files in os.walk(os.path.dirname(p)):
                if "gemm.c" in files:
                    self.c_file = os.path.join(root, "gemm.c")
                    break

    def test_production_inference_loads_alpha_0_1(self):
        """Requirement 1: Verify production LinUCB inference loads alpha = 0.1."""
        deploy_cfg = load_linucb_deployment_config()
        self.assertEqual(deploy_cfg.alpha, 0.1)
        self.assertEqual(deploy_cfg.reg_lambda, 1.0)

        sel = select_with_provenance(self.c_file, features=self.raw_feats, model_family="linucb", allow_moo=False)
        self.assertIsNotNone(sel)
        meta = sel.selection_metadata
        self.assertEqual(meta["model_family"], "LinUCB")
        self.assertAlmostEqual(meta["alpha"], 0.1, places=4)
        self.assertEqual(meta["selected_action_idx"], 2)
        self.assertEqual(meta["selected_action"], "-O2")
        self.assertAlmostEqual(meta["predicted_reward"], 0.497250, places=4)
        self.assertAlmostEqual(meta["exploration_bonus"], 0.104201, places=4)
        self.assertAlmostEqual(meta["ucb_score"], 0.601451, places=4)

    def test_missing_deployment_config_fails_clearly(self):
        """Requirement 2a: Missing deployment configuration raises FileNotFoundError with clear message."""
        nonexistent = os.path.join(tempfile.gettempdir(), "nonexistent_config_12345.json")
        with self.assertRaises(FileNotFoundError) as ctx:
            load_linucb_deployment_config(config_path=nonexistent)
        self.assertIn("LinUCB deployment configuration not found", str(ctx.exception))

    def test_invalid_deployment_config_fails_clearly(self):
        """Requirement 2b: Malformed or non-positive alpha fails clearly with ValueError."""
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".json") as tf:
            json.dump({
                "schema_version": "1.0",
                "model_family": "linucb",
                "deployment_target": "production_inference",
                "inference_alpha": -0.5,
                "inference_reg_lambda": 1.0,
                "checkpoint_provenance": {
                    "expected_version": 47,
                    "expected_sha256": "8A03189E1AFB056D1776A2EDBEB7AA403DE080536CE4758390D1A01D4EADE449"
                },
                "scaler_provenance": {
                    "expected_scaler_path": "data/models/linucb_feature_scaler.json",
                    "expected_scaler_sha256": "EF2687750C8F8B6087ECB44407623EB5B59AC35D60426A5CB7E9F573C06DD812"
                }
            }, tf)
            tmp_path = tf.name

        try:
            with self.assertRaises(ValueError) as ctx:
                load_linucb_deployment_config(config_path=tmp_path)
            self.assertIn("Invalid LinUCB deployment alpha", str(ctx.exception))
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def test_checkpoint_learned_parameters_unmodified(self):
        """Requirement 3: Checkpoint learned parameters and SQLite state hash remain untouched."""
        ledger = SQLiteEvaluationLedger()
        model = ledger.get_active_model()
        self.assertEqual(model.version, 47)
        self.assertEqual(model.counts, [3, 5, 5, 6, 6, 5, 4, 6, 7])
        self.assertEqual(sum(model.counts), 47)

        # Direct database query for SHA-256
        conn = ledger._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT version, sha256 FROM linucb_checkpoint WHERE version=47;")
        row = cursor.fetchone()
        conn.close()
        self.assertIsNotNone(row)
        ver, sha = row
        self.assertEqual(ver, 47)
        self.assertEqual(sha, "8A03189E1AFB056D1776A2EDBEB7AA403DE080536CE4758390D1A01D4EADE449")

    def test_scaler_unmodified(self):
        """Requirement 4: Feature scaler hash matches frozen Stage 13.4 SHA-256."""
        with open(self.scaler_path, "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest().upper()
        self.assertEqual(h, "EF2687750C8F8B6087ECB44407623EB5B59AC35D60426A5CB7E9F573C06DD812")

    def test_dqn_default_behavior_unchanged(self):
        """Requirement 5: DQN default behavior remains completely intact with 0 exploration bonus."""
        sel = select_with_provenance(self.c_file, features=self.raw_feats, model_family="dqn", allow_moo=False)
        self.assertIsNotNone(sel)
        meta = sel.selection_metadata
        self.assertEqual(meta["model_family"], "DQN")
        self.assertEqual(meta["exploration_bonus"], 0.0)
        self.assertEqual(meta["alpha"], 0.0)
        self.assertEqual(meta["selection_policy"], "dqn_argmax")

    def test_linucb_provenance_remains_accurate(self):
        """Requirement 6: LinUCB provenance accurately exposes all arms under alpha = 0.1."""
        sel = select_with_provenance(self.c_file, features=self.raw_feats, model_family="linucb", allow_moo=False)
        meta = sel.selection_metadata
        self.assertEqual(meta["selected_action"], "-O2")
        self.assertEqual(meta["recommended_action"], "-O2")
        self.assertFalse(meta["moo_influenced"])
        self.assertEqual(meta["selection_policy"], "linucb_ucb")

        # Verify all 9 arms are present in all_arm_scores
        arm_scores = meta["all_arm_scores"]
        self.assertEqual(len(arm_scores), 9)
        top_arm = arm_scores[0]
        self.assertEqual(top_arm["action_idx"], 2)
        self.assertEqual(top_arm["strategy"], "-O2")
        self.assertAlmostEqual(top_arm["ucb_score"], 0.601451, places=4)

    def test_moo_override_provenance_remains_accurate(self):
        """Requirement 7: MOO override is accurately tracked when Pareto selection differs from LinUCB."""
        mock_result = MagicMock()
        mock_result.strategy = "-O3"
        mock_result.moo_active = True
        mock_result.filtered_out = []
        mock_result.reason = "Pareto frontier selection override"

        mock_trace = MagicMock()
        mock_trace.selection_method = "moo_pareto"
        mock_trace.to_xai_result.return_value = None

        with patch("moo.selector_bridge.moo_aware_select_with_trace", return_value=(mock_result, mock_trace)):
            sel = select_with_provenance(self.c_file, features=self.raw_feats, model_family="linucb", allow_moo=True)

        meta = sel.selection_metadata
        self.assertEqual(meta["selected_action"], "-O3")
        self.assertEqual(meta["recommended_action"], "-O2")
        self.assertTrue(meta["moo_influenced"])
        self.assertEqual(meta["selection_policy"], "moo_pareto")

    def test_security_gate_authority_unchanged(self):
        """Requirement 8: Security gate authority disclaimer and decision mapping remain unchanged."""
        from moo.security.gate import OptimizationSecurityGate
        gate = OptimizationSecurityGate()
        self.assertTrue(hasattr(gate, "evaluate_gate_decision"))
        self.assertTrue(hasattr(gate, "run_gate"))


if __name__ == "__main__":
    unittest.main()
