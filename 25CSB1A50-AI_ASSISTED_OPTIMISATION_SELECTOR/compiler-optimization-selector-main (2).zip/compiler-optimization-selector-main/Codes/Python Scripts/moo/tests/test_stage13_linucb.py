"""
Codes/Python Scripts/moo/tests/test_stage13_linucb.py
Comprehensive Focused Test Suite for TOACD Stage 13.3 LinUCB & SQLite Persistence.

Covers all 18 mandatory phases and requirements:
1. Feature transformation (log1p, clamping, bias, dimension=9)
2. Training-only scaler fitting
3. Cold-start coverage policy (priority [3, 2, 1, 7, 6, 8, 4, 5, 0] with N_min=1)
4. UCB calculation mathematical fidelity
5. Per-action update (rank-one covariance, unselected actions unchanged)
6. Multi-objective reward calculation (weights 0.85/0.15, clamping)
7. Invalid reward rejection (non-finite or <= 0 measurements)
8. Security Gate rejection authority (ineligible, reward=0)
9. Correctness mismatch rejection
10. CV reliability threshold enforcement (CV <= 10.0%)
11. Duplicate evaluation token idempotency
12. Restart recovery across ledger instances
13. Checkpoint SHA-256 integrity validation
14. Transaction rollback atomicity
15. Concurrent update conflict resolution (multi-process synchronization)
16. Stale checkpoint detection
17. Cholesky positive-definiteness verification
18. Held-out test split strict isolation
"""

from __future__ import annotations

import os
import sys
import json
import math
import tempfile
import sqlite3
import unittest
import numpy as np

# Ensure Codes/Python Scripts is on sys.path
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS_DIR = os.path.dirname(os.path.dirname(_CURRENT_DIR))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)

from moo.bandit.model import (
    DisjointLinUCB,
    ACTIONS,
    COLD_START_PRIORITY,
    NUM_ACTIONS,
    DIMENSION_D,
    N_MIN
)
from moo.bandit.features import LinUCBFeatureScaler, CANONICAL_8_FEATURE_NAMES
from moo.bandit.reward import compute_linucb_reward, evaluate_eligibility_and_reward
from moo.bandit.persistence import SQLiteEvaluationLedger

class TestStage13LinUCB(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "test_ledger.db")
        self.scaler_path = os.path.join(self.temp_dir.name, "test_scaler.json")

    def tearDown(self):
        self.temp_dir.cleanup()

    # 1. Feature Transformation Test
    def test_01_feature_transformation(self):
        scaler = LinUCBFeatureScaler()
        scaler.means = [2.0] * 8
        scaler.stds = [1.0] * 8
        scaler.fitted = True

        raw_feats = [10.0, 100.0, 10.0, 50.0, 5.0, 0.0, 0.0, 2.0]
        ctx = scaler.transform(raw_feats)

        self.assertEqual(ctx.shape, (DIMENSION_D,))
        self.assertEqual(ctx[8], 1.0)  # Bias term
        for i in range(8):
            self.assertTrue(-4.0 <= ctx[i] <= 4.0)

        # Verify log1p non-linear scaling
        expected_log0 = math.log1p(10.0)
        expected_z0 = max(-4.0, min(4.0, (expected_log0 - 2.0) / 1.0))
        self.assertAlmostEqual(ctx[0], expected_z0, places=5)

    # 2. Training-Only Scaler Fitting Test
    def test_02_training_only_scaler_fitting(self):
        # Create a mock train manifest with 60 programs
        progs = []
        for i in range(60):
            progs.append({
                "program_id": f"prog_{i}",
                "features": {name: (i + 1) * 10 for name in CANONICAL_8_FEATURE_NAMES}
            })
        manifest_data = {"programs": progs}
        m_path = os.path.join(self.temp_dir.name, "mock_train_manifest.json")
        with open(m_path, "w") as f:
            json.dump(manifest_data, f)

        scaler = LinUCBFeatureScaler()
        scaler.fit_from_train_manifest(m_path)
        self.assertTrue(scaler.fitted)
        self.assertEqual(scaler.fitted_program_count, 60)
        self.assertEqual(len(scaler.means), 8)
        self.assertEqual(len(scaler.stds), 8)

        # Attempting to fit on invalid count raises ValueError
        invalid_manifest = os.path.join(self.temp_dir.name, "invalid_manifest.json")
        with open(invalid_manifest, "w") as f:
            json.dump({"programs": progs[:20]}, f)
        with self.assertRaises(ValueError):
            scaler.fit_from_train_manifest(invalid_manifest)

    # 3. Cold-Start Coverage Policy Test
    def test_03_cold_start_coverage(self):
        model = DisjointLinUCB(alpha=1.0)
        ctx = np.zeros(DIMENSION_D)
        ctx[-1] = 1.0

        # Initially, all N_a == 0 -> must follow exact priority: [3, 2, 1, 7, 6, 8, 4, 5, 0]
        for expected_action in COLD_START_PRIORITY:
            sel = model.select_action(ctx)
            self.assertEqual(sel["selected_action_idx"], expected_action)
            self.assertEqual(sel["selection_method"], "COLD_START_PRIORITY")
            # Update selected action so N_a becomes 1
            model.apply_update(expected_action, ctx, reward=0.5)

        # After all eligible actions have N_a >= 1, selection must switch to LINUCB_UCB_ARGMAX
        sel_post = model.select_action(ctx)
        self.assertEqual(sel_post["selection_method"], "LINUCB_UCB_ARGMAX")

    # 4. UCB Calculation Mathematical Fidelity Test
    def test_04_ucb_calculation_math(self):
        model = DisjointLinUCB(alpha=1.5, reg_lambda=1.0)
        # Set all counts to 1 to bypass cold-start
        model.counts = [1] * NUM_ACTIONS

        ctx = np.ones(DIMENSION_D)
        # For an unused action: A_a = I, b_a = 0 -> theta = 0
        # Expected UCB = 0 + 1.5 * sqrt(1^T I 1) = 1.5 * sqrt(9) = 1.5 * 3 = 4.5
        sel = model.select_action(ctx)
        self.assertAlmostEqual(sel["uncertainty_selected"], 3.0, places=5)
        self.assertAlmostEqual(sel["ucb_score_selected"], 4.5, places=5)

    # 5. Per-Action Update Isolation Test
    def test_05_per_action_update_isolation(self):
        model = DisjointLinUCB(alpha=1.0, reg_lambda=1.0)
        ctx = np.array([1.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0])
        action_to_update = 3

        a0_before = model.A[0].copy()
        b0_before = model.b[0].copy()

        model.apply_update(action_to_update, ctx, reward=0.8)

        # Action 3 must be updated
        self.assertEqual(model.counts[action_to_update], 1)
        expected_A3 = np.eye(DIMENSION_D) + np.outer(ctx, ctx)
        expected_b3 = 0.8 * ctx
        np.testing.assert_allclose(model.A[action_to_update], expected_A3)
        np.testing.assert_allclose(model.b[action_to_update], expected_b3)

        # Action 0 must remain completely untouched
        self.assertEqual(model.counts[0], 0)
        np.testing.assert_allclose(model.A[0], a0_before)
        np.testing.assert_allclose(model.b[0], b0_before)

    # 6. Multi-Objective Reward Calculation Test
    def test_06_reward_calculation(self):
        # 2x speedup (T_cand = 50, T_base = 100 -> delta_time = 0.5)
        # 10% code size reduction (S_cand = 90, S_base = 100 -> delta_size = 0.1)
        # Expected reward = 0.85 * 0.5 + 0.15 * 0.1 = 0.425 + 0.015 = 0.440
        r = compute_linucb_reward(100.0, 50.0, 100.0, 90.0)
        self.assertAlmostEqual(r, 0.440, places=5)

        # Clamping check: 10x slowdown (delta_time = -9.0 clamped to -1.0)
        # Size explosion (delta_size = -5.0 clamped to -0.5)
        # Expected = 0.85 * (-1.0) + 0.15 * (-0.5) = -0.85 - 0.075 = -0.925
        r_clamp = compute_linucb_reward(100.0, 1000.0, 100.0, 600.0)
        self.assertAlmostEqual(r_clamp, -0.925, places=5)

    # 7. Invalid Reward Rejection Test
    def test_07_invalid_reward_rejection(self):
        # Zero baseline time
        r, ok, reason = evaluate_eligibility_and_reward(0.0, 50.0, 100.0, 90.0, cv_pct=5.0, security_passed=True, correctness_passed=True)
        self.assertFalse(ok)
        self.assertEqual(r, 0.0)
        self.assertIn("INVALID_BASELINE_TIME", reason)

        # NaN candidate time
        r, ok, reason = evaluate_eligibility_and_reward(100.0, float("nan"), 100.0, 90.0, cv_pct=5.0, security_passed=True, correctness_passed=True)
        self.assertFalse(ok)
        self.assertEqual(r, 0.0)
        self.assertIn("INVALID_CANDIDATE_TIME", reason)

    # 8. Security Gate Rejection Test
    def test_08_security_gate_rejection(self):
        r, ok, reason = evaluate_eligibility_and_reward(
            t_baseline=100.0, t_candidate=50.0, s_baseline=100.0, s_candidate=90.0,
            cv_pct=2.0, security_passed=False, correctness_passed=True
        )
        self.assertFalse(ok)
        self.assertEqual(r, 0.0)
        self.assertEqual(reason, "SECURITY_GATE_REJECTED")

    # 9. Correctness Mismatch Test
    def test_09_correctness_mismatch_rejection(self):
        r, ok, reason = evaluate_eligibility_and_reward(
            t_baseline=100.0, t_candidate=50.0, s_baseline=100.0, s_candidate=90.0,
            cv_pct=2.0, security_passed=True, correctness_passed=False
        )
        self.assertFalse(ok)
        self.assertEqual(r, 0.0)
        self.assertEqual(reason, "CORRECTNESS_MISMATCH")

    # 10. CV Threshold Enforcement Test
    def test_10_cv_threshold_enforcement(self):
        # CV <= 10.0% -> PASS
        r_ok, ok, _ = evaluate_eligibility_and_reward(100.0, 50.0, 100.0, 90.0, cv_pct=9.95, security_passed=True, correctness_passed=True)
        self.assertTrue(ok)
        self.assertGreater(r_ok, 0.0)

        # CV > 10.0% -> FAIL
        r_bad, bad_ok, reason = evaluate_eligibility_and_reward(100.0, 50.0, 100.0, 90.0, cv_pct=10.05, security_passed=True, correctness_passed=True)
        self.assertFalse(bad_ok)
        self.assertEqual(r_bad, 0.0)
        self.assertIn("RELIABILITY_THRESHOLD_EXCEEDED", reason)

    # 11. Duplicate Evaluation Token Idempotency Test
    def test_11_duplicate_token_idempotency(self):
        ledger = SQLiteEvaluationLedger(self.db_path)
        ctx = np.ones(DIMENSION_D)
        token = "token_eval_unique_001"

        # First commit -> Success
        ok, reason, ver = ledger.record_update_transaction(token, "prog_1", action_idx=3, context=ctx, reward=0.5)
        self.assertTrue(ok)
        self.assertEqual(ver, 1)

        # Second commit with identical token -> Must be rejected as duplicate
        ok2, reason2, ver2 = ledger.record_update_transaction(token, "prog_1", action_idx=3, context=ctx, reward=0.5)
        self.assertFalse(ok2)
        self.assertEqual(reason2, "DUPLICATE_EVALUATION_TOKEN")
        self.assertEqual(ver2, 1)  # Version must NOT advance

    # 12. Restart Recovery Test
    def test_12_restart_recovery(self):
        ledger1 = SQLiteEvaluationLedger(self.db_path)
        ctx = np.array([0.5] * 8 + [1.0])
        ledger1.record_update_transaction("token_01", "prog_1", action_idx=3, context=ctx, reward=0.75)
        ledger1.record_update_transaction("token_02", "prog_2", action_idx=2, context=ctx, reward=0.45)

        m1 = ledger1.get_active_model()
        self.assertEqual(m1.version, 2)
        self.assertEqual(m1.counts[3], 1)
        self.assertEqual(m1.counts[2], 1)

        # Simulate full process restart with fresh ledger object pointing to same DB
        ledger2 = SQLiteEvaluationLedger(self.db_path)
        m2 = ledger2.get_active_model()

        self.assertEqual(m2.version, 2)
        self.assertEqual(m2.counts[3], 1)
        self.assertEqual(m2.counts[2], 1)
        np.testing.assert_allclose(m1.A[3], m2.A[3])
        np.testing.assert_allclose(m1.b[3], m2.b[3])

    # 13. Checkpoint SHA-256 Validation Test
    def test_13_checkpoint_hash_validation(self):
        ledger = SQLiteEvaluationLedger(self.db_path)
        # Corrupt the state blob in SQLite directly
        conn = sqlite3.connect(self.db_path)
        conn.execute("UPDATE linucb_checkpoint SET state_blob = '{\"corrupted\": true}' WHERE version = 0;")
        conn.commit()
        conn.close()

        # Reopening ledger must detect SHA-256 corruption and raise RuntimeError
        with self.assertRaises(RuntimeError) as cm:
            _ = SQLiteEvaluationLedger(self.db_path)
        self.assertIn("SHA-256 mismatch", str(cm.exception))

    # 14. Transaction Rollback Atomicity Test
    def test_14_transaction_rollback(self):
        ledger = SQLiteEvaluationLedger(self.db_path)
        active_before = ledger.get_active_model().clone()

        # Submit an invalid context vector with NaNs to trigger Cholesky failure
        bad_ctx = np.array([float("nan")] * DIMENSION_D)
        ok, reason, ver = ledger.record_update_transaction("token_bad", "prog_bad", action_idx=0, context=bad_ctx, reward=0.5)

        self.assertFalse(ok)
        self.assertIn("TRANSACTION_FAILED", reason)

        # In-memory model must remain untouched
        active_after = ledger.get_active_model()
        self.assertEqual(active_after.version, active_before.version)
        self.assertEqual(active_after.counts, active_before.counts)

    # 15. Concurrent Update Conflicts (Multi-Process Sync) Test
    def test_15_concurrent_update_sync(self):
        # Two ledger instances simulating separate worker processes
        proc1 = SQLiteEvaluationLedger(self.db_path)
        proc2 = SQLiteEvaluationLedger(self.db_path)

        ctx = np.ones(DIMENSION_D)

        # Proc 1 updates model (version 0 -> 1)
        ok1, _, ver1 = proc1.record_update_transaction("token_p1", "prog_1", action_idx=1, context=ctx, reward=0.5)
        self.assertTrue(ok1)
        self.assertEqual(ver1, 1)

        # Proc 2 was idle and its in-memory version is still 0.
        # Now Proc 2 attempts update: checkpoint-version tracking must reload version 1,
        # apply the update on top of version 1, and commit version 2.
        ok2, _, ver2 = proc2.record_update_transaction("token_p2", "prog_2", action_idx=2, context=ctx, reward=0.6)
        self.assertTrue(ok2)
        self.assertEqual(ver2, 2)

        # Proc 1 syncs and sees version 2 with both updates applied
        m1 = proc1.get_active_model()
        self.assertEqual(m1.version, 2)
        self.assertEqual(m1.counts[1], 1)
        self.assertEqual(m1.counts[2], 1)

    # 16. Stale Checkpoint Detection Test
    def test_16_stale_checkpoint_detection(self):
        proc1 = SQLiteEvaluationLedger(self.db_path)
        proc2 = SQLiteEvaluationLedger(self.db_path)
        ctx = np.ones(DIMENSION_D)

        proc1.record_update_transaction("token_p1", "prog_1", action_idx=3, context=ctx, reward=0.8)
        self.assertEqual(proc1.get_active_model().version, 1)

        # Proc 2 has stale model (version 0)
        self.assertEqual(proc2.active_model.version, 0)
        proc2.sync_with_latest_checkpoint()
        self.assertEqual(proc2.active_model.version, 1)

    # 17. Cholesky Positive-Definiteness Test
    def test_17_cholesky_positive_definiteness(self):
        model = DisjointLinUCB()
        model.validate_positive_definite()  # Fresh model passes

        # Force one covariance matrix to be non-positive-definite
        model.A[0] = -np.eye(DIMENSION_D)
        with self.assertRaises(ValueError) as cm:
            model.validate_positive_definite()
        self.assertIn("not positive-definite", str(cm.exception))

    # 18. Held-Out Test Split Isolation Test
    def test_18_held_out_test_isolation(self):
        scaler = LinUCBFeatureScaler()
        # Verify scaler cannot be fit on test manifest
        data_dir = os.path.join(_SCRIPTS_DIR, "..", "..", "data", "manifests")
        test_manifest = os.path.join(data_dir, "test_manifest.json")
        if os.path.exists(test_manifest):
            with self.assertRaises(ValueError):
                # test manifest has 30 programs, which triggers count invariant rejection
                scaler.fit_from_train_manifest(test_manifest)

if __name__ == "__main__":
    unittest.main()
