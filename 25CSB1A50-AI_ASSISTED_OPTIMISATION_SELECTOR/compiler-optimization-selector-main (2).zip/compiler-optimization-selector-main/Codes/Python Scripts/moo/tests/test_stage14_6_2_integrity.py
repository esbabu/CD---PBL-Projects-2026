"""
moo.tests.test_stage14_6_2_integrity — Stage 14.6.2 Configuration Integrity & Training/Deployment Separation Tests.

Verifies:
1. Missing deployment config raises FileNotFoundError without fallback (fail-closed).
2. Malformed JSON or missing required fields in deployment config raise ValueError.
3. Checkpoint version mismatch raises RuntimeError.
4. Checkpoint SHA-256 mismatch raises RuntimeError.
5. Scaler SHA-256 mismatch raises RuntimeError.
6. Missing scaler file raises FileNotFoundError.
7. Error messages report failed integrity check using base filename without leaking full host paths.
8. Training alpha parameter in train_linucb is decoupled from deployment config (alpha_train defaults to 1.0).
9. Production LinUCB inference succeeds with verified integrity and selects Arm #2 (-O2).
10. Active model instance verified is the exact instance used for inference (no TOCTOU gap).
"""

from __future__ import annotations

import os
import sys
import json
import tempfile
import hashlib
import unittest
from unittest.mock import MagicMock, patch

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from moo.bandit.config import (
    LinUCBDeploymentConfig,
    load_linucb_deployment_config,
    find_models_dir,
    verify_linucb_scaler_integrity,
    verify_linucb_checkpoint_integrity,
)
from moo.bandit.persistence import SQLiteEvaluationLedger
from moo.bandit.model import DisjointLinUCB
from optimization_selector import select_with_provenance, ACTIONS


class TestStage1462Integrity(unittest.TestCase):
    """Test suite for Stage 14.6.2 Configuration Integrity & Training/Deployment Separation."""

    def setUp(self):
        self.models_dir = find_models_dir()
        self.scaler_path = os.path.join(self.models_dir, "linucb_feature_scaler.json")
        self.config_path = os.path.join(self.models_dir, "linucb_deployment_config.json")
        self.raw_feats = [47.0, 470.0, 47.0, 224.0, 16.0, 4.0, 0.0, 20.0]

        # Locate sample C file
        p = os.path.abspath(_scripts_dir)
        self.c_file = os.path.join(os.path.dirname(p), "Codes", "test_cases", "gemm.c")
        if not os.path.exists(self.c_file):
            for root, _, files in os.walk(os.path.dirname(p)):
                if "gemm.c" in files:
                    self.c_file = os.path.join(root, "gemm.c")
                    break

    def test_missing_deployment_config_fails_closed(self):
        """Test 1: Missing deployment configuration raises FileNotFoundError without fallback."""
        nonexistent = os.path.join(tempfile.gettempdir(), "missing_linucb_deploy_config_9999.json")
        with self.assertRaises(FileNotFoundError) as ctx:
            load_linucb_deployment_config(config_path=nonexistent)
        err = str(ctx.exception)
        self.assertIn("LinUCB deployment configuration not found", err)
        # Verify error message uses basename to prevent leaking sensitive directories
        self.assertIn("missing_linucb_deploy_config_9999.json", err)

    def test_malformed_deployment_config_json_raises_value_error(self):
        """Test 2a: Malformed JSON syntax in deployment config raises ValueError."""
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".json") as tf:
            tf.write("{ this is not valid json :(")
            tmp_path = tf.name

        try:
            with self.assertRaises(ValueError) as ctx:
                load_linucb_deployment_config(config_path=tmp_path)
            self.assertIn("Failed to read LinUCB deployment configuration", str(ctx.exception))
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def test_missing_required_fields_raises_value_error(self):
        """Test 2b: Deployment config missing schema required fields raises ValueError."""
        required_fields = [
            "schema_version",
            "model_family",
            "deployment_target",
            "inference_alpha",
            "inference_reg_lambda",
            "checkpoint_provenance",
            "scaler_provenance",
        ]

        valid_base = {
            "schema_version": "1.0",
            "model_family": "linucb",
            "deployment_target": "production_inference",
            "inference_alpha": 0.1,
            "inference_reg_lambda": 1.0,
            "checkpoint_provenance": {
                "expected_version": 47,
                "expected_sha256": "8A03189E1AFB056D1776A2EDBEB7AA403DE080536CE4758390D1A01D4EADE449"
            },
            "scaler_provenance": {
                "expected_scaler_path": "data/models/linucb_feature_scaler.json",
                "expected_scaler_sha256": "EF2687750C8F8B6087ECB44407623EB5B59AC35D60426A5CB7E9F573C06DD812"
            }
        }

        for field in required_fields:
            corrupted = dict(valid_base)
            del corrupted[field]
            with tempfile.NamedTemporaryFile("w", delete=False, suffix=".json") as tf:
                json.dump(corrupted, tf)
                tmp_path = tf.name

            try:
                with self.assertRaises(ValueError) as ctx:
                    load_linucb_deployment_config(config_path=tmp_path)
                self.assertIn(f"missing required field: '{field}'", str(ctx.exception))
            finally:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)

    def test_checkpoint_version_mismatch_raises_runtime_error(self):
        """Test 3: Checkpoint active version mismatch raises RuntimeError."""
        model = DisjointLinUCB(alpha=1.0)
        model.version = 46  # Mismatch: expected 47

        with self.assertRaises(RuntimeError) as ctx:
            verify_linucb_checkpoint_integrity(
                active_model=model,
                expected_version=47,
                expected_sha256=model.compute_sha256(),
            )
        err = str(ctx.exception)
        self.assertIn("version mismatch", err)
        self.assertIn("expected version 47, active model version 46", err)

    def test_checkpoint_sha256_mismatch_raises_runtime_error(self):
        """Test 4: Checkpoint computed SHA-256 mismatch raises RuntimeError."""
        ledger = SQLiteEvaluationLedger()
        model = ledger.get_active_model()
        tampered_sha256 = "0000000000000000000000000000000000000000000000000000000000000000"

        with self.assertRaises(RuntimeError) as ctx:
            verify_linucb_checkpoint_integrity(
                active_model=model,
                expected_version=47,
                expected_sha256=tampered_sha256,
            )
        err = str(ctx.exception)
        self.assertIn("SHA-256 mismatch", err)
        self.assertIn("0000000000000000", err)

    def test_scaler_sha256_mismatch_raises_runtime_error(self):
        """Test 5: Scaler SHA-256 hash mismatch raises RuntimeError."""
        with tempfile.NamedTemporaryFile("wb", delete=False, suffix=".json") as tf:
            tf.write(b'{"tampered": true}')
            tampered_path = tf.name

        try:
            with self.assertRaises(RuntimeError) as ctx:
                verify_linucb_scaler_integrity(
                    scaler_path=tampered_path,
                    expected_sha256="EF2687750C8F8B6087ECB44407623EB5B59AC35D60426A5CB7E9F573C06DD812",
                )
            err = str(ctx.exception)
            self.assertIn("scaler integrity verification failed", err)
            # Verify no path leakage of parent directories
            self.assertIn(os.path.basename(tampered_path), err)
            self.assertNotIn(os.path.dirname(tampered_path), err)
        finally:
            if os.path.exists(tampered_path):
                os.remove(tampered_path)

    def test_missing_scaler_file_raises_file_not_found_error(self):
        """Test 6: Missing scaler file raises FileNotFoundError with sanitized message."""
        nonexistent = os.path.join(tempfile.gettempdir(), "nonexistent_scaler_9999.json")
        with self.assertRaises(FileNotFoundError) as ctx:
            verify_linucb_scaler_integrity(
                scaler_path=nonexistent,
                expected_sha256="EF2687750C8F8B6087ECB44407623EB5B59AC35D60426A5CB7E9F573C06DD812",
            )
        err = str(ctx.exception)
        self.assertIn("not found", err)
        self.assertIn("nonexistent_scaler_9999.json", err)

    def test_training_alpha_decoupled_from_deployment_config(self):
        """Test 7: Verify train_linucb does not import deployment config and accepts independent alpha_train."""
        from moo.bandit import train_linucb
        import inspect

        # Inspect train_linucb module symbols
        self.assertFalse(hasattr(train_linucb, "load_linucb_deployment_config"))

        # Inspect signature of train_linucb_on_corpus
        sig = inspect.signature(train_linucb.train_linucb_on_corpus)
        self.assertIn("alpha_train", sig.parameters)
        self.assertEqual(sig.parameters["alpha_train"].default, 1.0)
        self.assertIn("reg_lambda", sig.parameters)
        self.assertEqual(sig.parameters["reg_lambda"].default, 1.0)

    def test_production_linucb_inference_integrity_verified_selection(self):
        """Test 8: Production LinUCB inference passes integrity verification and selects Arm #2 (-O2)."""
        sel = select_with_provenance(self.c_file, features=self.raw_feats, model_family="linucb", allow_moo=False)
        self.assertIsNotNone(sel)
        meta = sel.selection_metadata

        # Provenance verification
        self.assertEqual(meta["model_family"], "LinUCB")
        self.assertAlmostEqual(meta["alpha"], 0.1, places=4)
        self.assertEqual(meta["selected_action_idx"], 2)
        self.assertEqual(meta["selected_action"], "-O2")
        self.assertEqual(meta["selection_policy"], "linucb_ucb")

        # Mathematical verification
        self.assertAlmostEqual(meta["predicted_reward"], 0.497250, places=4)
        self.assertAlmostEqual(meta["exploration_bonus"], 0.104201, places=4)
        self.assertAlmostEqual(meta["ucb_score"], 0.601451, places=4)

    def test_inference_aborts_on_corrupted_scaler_in_production(self):
        """Test 9: select_with_provenance fails immediately if scaler is tampered."""
        with patch("moo.bandit.config.verify_and_load_linucb_scaler", side_effect=RuntimeError("Simulated Scaler Tampering")):
            with self.assertRaises(RuntimeError) as ctx:
                select_with_provenance(self.c_file, features=self.raw_feats, model_family="linucb", allow_moo=False)
            self.assertIn("Simulated Scaler Tampering", str(ctx.exception))

    def test_inference_aborts_on_corrupted_checkpoint_in_production(self):
        """Test 10: select_with_provenance fails immediately if checkpoint is tampered."""
        with patch("moo.bandit.config.verify_linucb_checkpoint_integrity", side_effect=RuntimeError("Simulated Checkpoint Tampering")):
            with self.assertRaises(RuntimeError) as ctx:
                select_with_provenance(self.c_file, features=self.raw_feats, model_family="linucb", allow_moo=False)
            self.assertIn("Simulated Checkpoint Tampering", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
