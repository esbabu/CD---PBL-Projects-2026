"""
moo/tests/test_stage13_metric_integrity.py — Unit tests for Stage 13.4.1 Metric Integrity.
"""

import os
import sys

# Ensure Python Scripts directory is on sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import json
import hashlib
import numpy as np
import pytest

from moo.bandit.audit_metrics import audit_and_recalculate

def test_stage13_metric_audit_execution():
    res = audit_and_recalculate()
    assert "corrected_aggregate_summary" in res
    assert "statistical_hypothesis_tests" in res
    assert "hash_verifications" in res

def test_o3_self_relative_speedup_is_one():
    res = audit_and_recalculate()
    o3_summary = res["corrected_aggregate_summary"]["LLVM_O3"]
    assert o3_summary["geomean_speedup_vs_o3"] == 1.0000
    assert o3_summary["ci95_speedup_vs_o3"] == [1.0000, 1.0000]

def test_raw_binary_sizes_exist_and_positive():
    res = audit_and_recalculate()
    for m, data in res["corrected_aggregate_summary"].items():
        assert data["geomean_binary_size_bytes"] > 0
        assert data["binary_size_ratio_vs_o3"] > 0
        assert data["total_programs"] == 30

def test_paired_samples_exclude_inconclusive():
    res = audit_and_recalculate()
    stats = res["statistical_hypothesis_tests"]
    assert stats["linucb_vs_dqn"]["paired_conclusive_sample_size"] == 22
    assert stats["linucb_vs_o3"]["paired_conclusive_sample_size"] == 20

def test_oracle_regret_bounds():
    res = audit_and_recalculate()
    for m, data in res["corrected_aggregate_summary"].items():
        assert data["mean_oracle_regret_pct"] >= 0.0
        assert data["median_oracle_regret_pct"] >= 0.0

def test_checkpoint_and_hash_invariance():
    res = audit_and_recalculate()
    hashes = res["hash_verifications"]
    assert hashes["dqn_hash_intact"] is True
    assert hashes["scaler_hash_intact"] is True
    assert hashes["linucb_version_frozen"] is True
    assert hashes["linucb_checkpoint_version"] == 47
