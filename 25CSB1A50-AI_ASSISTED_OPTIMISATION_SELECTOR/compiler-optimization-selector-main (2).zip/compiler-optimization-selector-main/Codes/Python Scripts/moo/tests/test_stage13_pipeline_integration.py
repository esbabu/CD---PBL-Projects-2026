"""
Codes/Python Scripts/moo/tests/test_stage13_pipeline_integration.py
Pipeline Integration Test for TOACD Stage 13.3 LinUCB & 6-Agent Architecture.

Verifies:
1. Full 6-agent message flow using LinUCB model family.
2. OptimizationSecurityGate authority and terminal fallback preservation.
3. End-to-end evaluation token generation and transactional ledger recording.
4. Hard eligibility gates (Security, Correctness, CV > 10%) preventing model updates.
5. Invariance of historical DQN comparison path and checkpoint hash.
"""

from __future__ import annotations

import os
import sys
import tempfile
import hashlib
import unittest

_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS_DIR = os.path.dirname(os.path.dirname(_CURRENT_DIR))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)

from optimization_selector import select_with_provenance
from moo.multiagent.agents import (
    OptimizationStrategistAgent,
    OptimizationReviewerAgent,
    FinalDecisionAgent
)
from moo.bandit import (
    SQLiteEvaluationLedger,
    LinUCBFeatureScaler,
    evaluate_eligibility_and_reward
)

def _find_data_dir() -> str:
    p = os.path.abspath(os.path.dirname(__file__))
    while p and os.path.dirname(p) != p:
        cand = os.path.join(p, "data")
        if os.path.exists(cand):
            return cand
        p = os.path.dirname(p)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data"))

class TestStage13PipelineIntegration(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.temp_dir.name, "integration_ledger.db")
        self.ledger = SQLiteEvaluationLedger(self.db_path)
        data_dir = _find_data_dir()
        self.test_c_file = os.path.join(
            data_dir,
            "benchmarks",
            "corpus_60_train",
            "la_2mm.c"
        )
        self.scaler_path = os.path.join(
            data_dir,
            "models",
            "linucb_feature_scaler.json"
        )
        self.scaler = LinUCBFeatureScaler()
        if os.path.exists(self.scaler_path):
            self.scaler.load(self.scaler_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_pipeline_linucb_proposal_and_flow(self):
        """Verifies OptimizationStrategistAgent generates LinUCB proposals cleanly."""
        strategist = OptimizationStrategistAgent()
        msg = strategist.initial_proposal(
            source_path=self.test_c_file,
            run_id="run_test_001",
            step=1,
            model_family="linucb"
        )

        self.assertIsNotNone(msg)
        payload = msg.payload
        self.assertIn("LINUCB", payload.get("provenance", ""))
        self.assertTrue(payload.get("strategy") in ["-O3", "-O2", "-O1", "-O0", "mem2reg,instcombine", "mem2reg,simplifycfg", "mem2reg,instcombine,simplifycfg,dce", "mem2reg,instcombine,simplifycfg,gvn,loop-unroll", "mem2reg,instcombine,simplifycfg,dce,gvn,loop-unroll"])
        self.assertTrue(payload.get("model_id", "").startswith("linucb_"))
        self.assertGreater(len(payload.get("q_rank", [])), 0)

    def test_pipeline_security_gate_authority(self):
        """Verifies FinalDecisionAgent runs OptimizationSecurityGate and blocks unsafe strategies."""
        final_agent = FinalDecisionAgent()
        msg = final_agent.decide(
            source_path=self.test_c_file,
            selected_strategy="-O3",
            q_rank=[("-O3", 4.0), ("-O0", 1.0)],
            decision_trace={},
            run_id="run_test_sec_001",
            step=2,
            run_security=True,
            security_profile="WINDOWS_HARDENED"
        )

        self.assertIsNotNone(msg)
        effective = msg.payload.get("effective_strategy")
        self.assertIsNotNone(effective)
        # Security Gate result is present
        self.assertIn("security_gate_result", msg.payload)

    def test_eligible_evaluation_records_update(self):
        """Verifies verified compliant run successfully commits update to ledger."""
        raw_feats = [50, 400, 50, 200, 20, 5, 0, 15]
        ctx = self.scaler.transform(raw_feats)

        r, ok, reason = evaluate_eligibility_and_reward(
            t_baseline=100.0,
            t_candidate=60.0,
            s_baseline=100.0,
            s_candidate=95.0,
            cv_pct=3.5,
            security_passed=True,
            correctness_passed=True
        )
        self.assertTrue(ok)
        self.assertEqual(reason, "ELIGIBLE_STABLE")

        token = "eval_tok_integration_pass_001"
        tx_ok, tx_reason, new_ver = self.ledger.record_update_transaction(
            token=token,
            program_id="la_2mm",
            action_idx=3,
            context=ctx,
            reward=r
        )
        self.assertTrue(tx_ok)
        self.assertEqual(new_ver, 1)
        self.assertTrue(self.ledger.has_token(token))

    def test_ineligible_evaluation_blocks_update(self):
        """Verifies that if CV > 10% or correctness fails, no ledger transaction is executed."""
        r, ok, reason = evaluate_eligibility_and_reward(
            t_baseline=100.0,
            t_candidate=60.0,
            s_baseline=100.0,
            s_candidate=95.0,
            cv_pct=15.0,  # Exceeds threshold!
            security_passed=True,
            correctness_passed=True
        )
        self.assertFalse(ok)
        self.assertIn("RELIABILITY_THRESHOLD_EXCEEDED", reason)

        # Attempting update should not be done when ok is False
        # Ledger version remains 0
        self.assertEqual(self.ledger.get_active_model().version, 0)

    def test_dqn_checkpoint_unmodified(self):
        """Verifies DQN checkpoint SHA-256 remains exactly the authoritative hash."""
        dqn_path = os.path.join(_SCRIPTS_DIR, "ml_optimizer_model.pth")
        self.assertTrue(os.path.exists(dqn_path))
        with open(dqn_path, "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest().upper()
        expected = "A576AAC033D5A78E7A0B63D4FC53752F5798F4422F38B9AF378065B27A23C99A"
        self.assertEqual(h, expected)

if __name__ == "__main__":
    unittest.main()
