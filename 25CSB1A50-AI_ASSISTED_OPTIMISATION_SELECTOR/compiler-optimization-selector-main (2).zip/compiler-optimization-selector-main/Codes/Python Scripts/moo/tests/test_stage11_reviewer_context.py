"""
moo/tests/test_stage11_reviewer_context.py — Stage 11 Phase 1 Regression Tests.

Validates:
1. ProgramProfile schema alignment in analyze_ir_profile_tool (modern schema with label, all_features, InstructionsCount, BranchCount).
2. Backward compatibility with legacy schema (deterministic_profile, instruction_count, loop_count).
3. Robust handling of missing, empty, or malformed profile data without unhandled exceptions.
4. OptimizationReviewerAgent payload inspection proving genuine profile and instruction count reception.
5. End-to-end MultiAgentOrchestrator data forwarding without duplicate IR generation or profile loss.
"""

import os
import sys
import unittest
import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS_DIR = os.path.dirname(os.path.dirname(_HERE))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)

from moo.agentic.schema import AgentContext, EvidenceTier, FindingSeverity
from moo.agentic.tools import analyze_ir_profile_tool
from moo.multiagent.schema import (
    AgentMessage,
    ROLE_OPTIMIZATION_STRATEGIST,
    ROLE_OPTIMIZATION_REVIEWER,
    MSG_STRATEGY_PROPOSAL,
    MSG_REVIEW_ACCEPT,
)
from moo.multiagent.agents import (
    OptimizationReviewerAgent,
    OptimizationStrategistAgent,
    FinalDecisionAgent,
)
from moo.multiagent.orchestrator import MultiAgentOrchestrator
from moo.runrecord.schema import RunRecord, RunStatus


class TestStage11ReviewerContext(unittest.TestCase):
    """Regression test suite for Stage 11 Phase 1."""

    def test_analyze_ir_profile_tool_modern_schema_compute_oriented(self):
        """Verifies modern ProgramProfile schema correctly populates profile label, inst_count, loop_count."""
        modern_profile = {
            "label": "compute_oriented",
            "dominant_feature": "MathInstCount",
            "dominant_feature_value": 8.0,
            "profile_method": "ir_heuristic_threshold",
            "is_trivial": False,
            "all_features": {
                "BasicBlocksCount": 10.0,
                "InstructionsCount": 118.0,
                "BranchCount": 10.0,
                "MemInstCount": 53.0,
                "MathInstCount": 8.0,
                "FloatInstCount": 0.0,
                "VectorInstCount": 0.0,
                "CallInstCount": 2.0,
            },
        }

        ctx = AgentContext(
            program_id="p_compute",
            source_hash="h_compute",
            selected_strategy="mem2reg,instcombine,simplifycfg,gvn,loop-unroll",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=modern_profile,
        )

        findings = analyze_ir_profile_tool(ctx)
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f.category, "IR_PROFILE")
        self.assertEqual(f.severity, FindingSeverity.INFO)

        # Must NOT fall back to 'unknown' or 0 instructions
        self.assertNotIn("'unknown'", f.message)
        self.assertNotIn("0 instructions", f.message)
        self.assertIn("compute_oriented", f.message)
        self.assertIn("118 instructions", f.message)
        self.assertIn("10 branches", f.message)
        self.assertIn("loop count unavailable", f.message)
        self.assertNotIn("10 loops", f.message)

        # Verify details dictionary distinguishes branch_count from loop_count
        self.assertEqual(f.details.get("profile"), "compute_oriented")
        self.assertEqual(f.details.get("instruction_count"), 118)
        self.assertEqual(f.details.get("branch_count"), 10)
        self.assertIsNone(f.details.get("loop_count"))
        self.assertIn("all_features", f.details)

    def test_analyze_ir_profile_tool_modern_schema_loop_oriented_with_o3(self):
        """Verifies loop_oriented profile selected with -O3 triggers the expected WARNING finding."""
        loop_profile = {
            "label": "loop_oriented",
            "dominant_feature": "BranchCount",
            "dominant_feature_value": 12.0,
            "profile_method": "ir_heuristic_threshold",
            "is_trivial": False,
            "all_features": {
                "BasicBlocksCount": 12.0,
                "InstructionsCount": 89.0,
                "BranchCount": 12.0,
                "MemInstCount": 30.0,
                "MathInstCount": 4.0,
                "FloatInstCount": 0.0,
                "VectorInstCount": 0.0,
                "CallInstCount": 1.0,
            },
        }

        ctx = AgentContext(
            program_id="p_loop",
            source_hash="h_loop",
            selected_strategy="-O3",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=loop_profile,
        )

        findings = analyze_ir_profile_tool(ctx)
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f.category, "IR_PROFILE")
        self.assertEqual(f.severity, FindingSeverity.WARNING)
        self.assertIn("loop-oriented", f.message.lower())
        self.assertAlmostEqual(f.details.get("branch_ratio", 0.0), 12.0 / 89.0, places=3)

    def test_analyze_ir_profile_tool_modern_schema_trivial_with_o3(self):
        """Verifies trivial profile selected with -O3 triggers the small routine advisory."""
        trivial_profile = {
            "label": "trivial",
            "dominant_feature": "InstructionsCount",
            "dominant_feature_value": 30.0,
            "profile_method": "ir_heuristic_threshold",
            "is_trivial": True,
            "all_features": {
                "BasicBlocksCount": 0.0,
                "InstructionsCount": 30.0,
                "BranchCount": 0.0,
                "MemInstCount": 10.0,
                "MathInstCount": 3.0,
                "FloatInstCount": 0.0,
                "VectorInstCount": 0.0,
                "CallInstCount": 0.0,
            },
        }

        ctx = AgentContext(
            program_id="p_triv",
            source_hash="h_triv",
            selected_strategy="-O3",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=trivial_profile,
        )

        findings = analyze_ir_profile_tool(ctx)
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f.severity, FindingSeverity.INFO)
        self.assertIn("trivial routine selected with -o3", f.message.lower())
        self.assertEqual(f.details.get("instruction_count"), 30)

    def test_analyze_ir_profile_tool_legacy_schema_compatibility(self):
        """Verifies that legacy profile schema (deterministic_profile, instruction_count) remains 100% functional."""
        legacy_profile_cf = {
            "deterministic_profile": "control_flow_heavy",
            "branch_ratio": 0.35,
            "instruction_count": 250,
            "loop_count": 2,
        }
        ctx_cf = AgentContext(
            program_id="p_legacy_cf",
            source_hash="h_legacy_cf",
            selected_strategy="-O3",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=legacy_profile_cf,
        )
        findings_cf = analyze_ir_profile_tool(ctx_cf)
        self.assertEqual(len(findings_cf), 1)
        self.assertEqual(findings_cf[0].severity, FindingSeverity.WARNING)
        self.assertIn("control-flow", findings_cf[0].message.lower())
        self.assertEqual(findings_cf[0].details.get("instruction_count"), 250)

        legacy_profile_mem = {
            "deterministic_profile": "memory_intensive",
            "memory_ops_ratio": 0.45,
            "instruction_count": 150,
            "loop_count": 5,
        }
        ctx_mem = AgentContext(
            program_id="p_legacy_mem",
            source_hash="h_legacy_mem",
            selected_strategy="-Os",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=legacy_profile_mem,
        )
        findings_mem = analyze_ir_profile_tool(ctx_mem)
        self.assertEqual(len(findings_mem), 1)
        self.assertEqual(findings_mem[0].severity, FindingSeverity.INFO)
        self.assertIn("memory intensive", findings_mem[0].message.lower())

    def test_analyze_ir_profile_tool_malformed_and_missing_data(self):
        """Verifies safe graceful degradation on missing, empty, or malformed profile data."""
        # 1. None profile
        ctx_none = AgentContext(
            program_id="p_none",
            source_hash="h_none",
            selected_strategy="-O2",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=None,
        )
        f_none = analyze_ir_profile_tool(ctx_none)
        self.assertEqual(len(f_none), 1)
        self.assertEqual(f_none[0].category, "DATA_GAP")

        # 2. Empty dict
        ctx_empty = AgentContext(
            program_id="p_empty",
            source_hash="h_empty",
            selected_strategy="-O2",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile={},
        )
        f_empty = analyze_ir_profile_tool(ctx_empty)
        self.assertEqual(len(f_empty), 1)
        self.assertEqual(f_empty[0].category, "DATA_GAP")

        # 3. Malformed non-integer instruction count
        ctx_bad = AgentContext(
            program_id="p_bad",
            source_hash="h_bad",
            selected_strategy="-O2",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile={
                "label": "compute_oriented",
                "all_features": {"InstructionsCount": "not_an_int", "BranchCount": [1, 2]},
            },
        )
        f_bad = analyze_ir_profile_tool(ctx_bad)
        self.assertEqual(len(f_bad), 1)
        self.assertEqual(f_bad[0].category, "IR_PROFILE")
        self.assertEqual(f_bad[0].details.get("instruction_count"), 0)
        self.assertIsNone(f_bad[0].details.get("branch_count"))
        self.assertIsNone(f_bad[0].details.get("loop_count"))

    def test_reviewer_receives_genuine_profile_payload(self):
        """Verifies that OptimizationReviewerAgent receives and inspects genuine profile data."""
        reviewer = OptimizationReviewerAgent()

        modern_profile = {
            "label": "compute_oriented",
            "dominant_feature": "MathInstCount",
            "dominant_feature_value": 8.0,
            "profile_method": "ir_heuristic_threshold",
            "is_trivial": False,
            "all_features": {
                "BasicBlocksCount": 10.0,
                "InstructionsCount": 118.0,
                "BranchCount": 10.0,
                "MemInstCount": 53.0,
                "MathInstCount": 8.0,
                "FloatInstCount": 0.0,
                "VectorInstCount": 0.0,
                "CallInstCount": 2.0,
            },
        }

        proposal = AgentMessage.create(
            sender=ROLE_OPTIMIZATION_STRATEGIST,
            recipient=ROLE_OPTIMIZATION_REVIEWER,
            message_type=MSG_STRATEGY_PROPOSAL,
            payload={
                "strategy": "mem2reg,instcombine,simplifycfg,gvn,loop-unroll",
                "provenance": "DQN_ARGMAX",
                "model_id": "production_v0",
                "revision_number": 0,
                "program_profile": modern_profile,
            },
            run_id="run_rev_test",
            step=4,
        )

        review_msg = reviewer.review_proposal(
            proposal,
            step=5,
            program_profile=modern_profile,
        )

        self.assertEqual(review_msg.message_type, MSG_REVIEW_ACCEPT)
        findings = review_msg.payload.get("findings", [])
        ir_findings = [f for f in findings if f.get("category") == "IR_PROFILE"]
        self.assertEqual(len(ir_findings), 1)
        ir_f = ir_findings[0]

        # Verify no silent fallback to unknown or 0 instructions
        self.assertNotIn("'unknown'", ir_f["message"])
        self.assertNotIn("0 instructions", ir_f["message"])
        self.assertIn("compute_oriented", ir_f["message"])
        self.assertIn("118 instructions", ir_f["message"])
        self.assertIn("10 branches", ir_f["message"])
        self.assertIn("loop count unavailable", ir_f["message"])
        self.assertNotIn("10 loops", ir_f["message"])
        self.assertEqual(ir_f["details"]["branch_count"], 10)
        self.assertIsNone(ir_f["details"]["loop_count"])

        # Verify forwarded payload contains program_profile
        self.assertEqual(review_msg.payload.get("program_profile"), modern_profile)

    def test_branch_count_vs_loop_count_distinction(self):
        """Verifies that BranchCount is never reported as loop_count and loop count availability is explicit."""
        # Case A: Only BranchCount is present -> loop_count is None and reported unavailable
        profile_branches_only = {
            "label": "compute_oriented",
            "all_features": {"InstructionsCount": 50.0, "BranchCount": 15.0},
        }
        ctx_a = AgentContext(
            program_id="p_br_only",
            source_hash="h1",
            selected_strategy="-O0",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=profile_branches_only,
        )
        f_a = analyze_ir_profile_tool(ctx_a)[0]
        self.assertEqual(f_a.details["branch_count"], 15)
        self.assertIsNone(f_a.details["loop_count"])
        self.assertIn("15 branches (loop count unavailable)", f_a.message)
        self.assertNotIn("15 loops", f_a.message)

        # Case B: Both BranchCount and loop_count present -> both reported accurately
        profile_both = {
            "label": "loop_oriented",
            "loop_count": 3,
            "all_features": {"InstructionsCount": 80.0, "BranchCount": 20.0},
        }
        ctx_b = AgentContext(
            program_id="p_both",
            source_hash="h2",
            selected_strategy="-O0",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=profile_both,
        )
        f_b = analyze_ir_profile_tool(ctx_b)[0]
        self.assertEqual(f_b.details["branch_count"], 20)
        self.assertEqual(f_b.details["loop_count"], 3)
        self.assertIn("20 branches, and 3 loops", f_b.message)

        # Case C: Only loop_count present (legacy) -> loop_count reported, branch_count is None
        profile_loops_only = {
            "deterministic_profile": "compute_intensive",
            "instruction_count": 60,
            "loop_count": 4,
        }
        ctx_c = AgentContext(
            program_id="p_loops_only",
            source_hash="h3",
            selected_strategy="-O0",
            tiers_available=[EvidenceTier.TIER_1_STATIC_SELECTION],
            program_profile=profile_loops_only,
        )
        f_c = analyze_ir_profile_tool(ctx_c)[0]
        self.assertIsNone(f_c.details["branch_count"])
        self.assertEqual(f_c.details["loop_count"], 4)
        self.assertIn("4 loops", f_c.message)
        self.assertNotIn("branches", f_c.message)

    def test_orchestrator_end_to_end_data_forwarding(self):
        """Verifies full orchestrator pipeline passes genuine profile and features without loss."""
        test_c = os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                "..",
                "..",
                "..",
                "test_cases",
                "16_bitwise_ops.c",
            )
        )
        if not os.path.exists(test_c):
            pytest.skip(f"Test case {test_c} not found")

        orchestrator = MultiAgentOrchestrator()
        record, msg_log = orchestrator.run(
            source_path=test_c,
            run_benchmarks=False,  # Skip benchmarking to focus on agent coordination
            run_security=True,
        )

        self.assertIsInstance(record, RunRecord)
        self.assertIn(record.overall_status, [RunStatus.OK, RunStatus.UNKNOWN])

        # 1. Check Strategist proposal message
        strat_msgs = [m for m in msg_log.messages if m.sender == ROLE_OPTIMIZATION_STRATEGIST]
        self.assertGreaterEqual(len(strat_msgs), 1)
        first_proposal = strat_msgs[0]
        self.assertIn("program_profile", first_proposal.payload)
        self.assertIsNotNone(first_proposal.payload["program_profile"])
        self.assertEqual(first_proposal.payload["program_profile"]["label"], "trivial")

        # 2. Check Reviewer message
        rev_msgs = [m for m in msg_log.messages if m.sender == ROLE_OPTIMIZATION_REVIEWER]
        self.assertGreaterEqual(len(rev_msgs), 1)
        first_review = rev_msgs[0]
        self.assertEqual(first_review.payload["decision"], "ACCEPT")
        findings = first_review.payload["findings"]
        ir_findings = [f for f in findings if f.get("category") == "IR_PROFILE"]
        self.assertEqual(len(ir_findings), 1)
        ir_f = ir_findings[0]

        # Must record genuine trivial profile with genuine instructions and branches
        self.assertNotIn("'unknown'", ir_f["message"])
        self.assertIn("trivial", ir_f["message"])
        self.assertIn("30 instructions", ir_f["message"])
        self.assertIn("0 branches (loop count unavailable)", ir_f["message"])
        self.assertNotIn("0 loops", ir_f["message"])
        self.assertEqual(ir_f["details"]["branch_count"], 0)
        self.assertIsNone(ir_f["details"]["loop_count"])

        # 3. Check FinalDecisionAgent message
        final_msgs = [m for m in msg_log.messages if m.sender == "FinalDecisionAgent"]
        self.assertGreaterEqual(len(final_msgs), 1)
        final_payload = final_msgs[0].payload
        self.assertIn("program_profile", final_payload)
        self.assertIsNotNone(final_payload["program_profile"])


if __name__ == "__main__":
    unittest.main()
