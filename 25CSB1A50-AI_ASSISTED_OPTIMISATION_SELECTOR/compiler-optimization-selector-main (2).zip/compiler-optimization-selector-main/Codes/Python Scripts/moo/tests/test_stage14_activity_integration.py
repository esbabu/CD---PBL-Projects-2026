"""
moo.tests.test_stage14_activity_integration — Stage 14 AI Activity & Frontend Integration Tests.

Validates:
1. Architectural Invariant: Exactly six canonical agents (NO 7th agent).
2. LinUCB Transparency: Structured selection metadata exposed without speedup fabrication.
3. DQN Backward Compatibility: Q-values and zero exploration bonus preserved.
4. Benchmark Sub-step Progress Callbacks: Non-blocking progress events during warmup and measurement.
5. Deterministic Regression Stage Enrichment: Rich comparative metrics in stage_completed payload.
6. Event Validation: EventType.STAGE_PROGRESS and StageStatus.PROGRESS serialize cleanly.
"""

from __future__ import annotations

import os
import sys
import unittest
from unittest.mock import MagicMock, patch
from typing import Any, Dict, List

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from web.events import (
    EventEnvelope,
    PipelineStage,
    StageStatus,
    EventType,
    RunState,
    sanitize_event_payload,
)
from moo.multiagent.orchestrator import MultiAgentOrchestrator
from moo.multiagent.agents import (
    CodeAnalystAgent,
    ProgramProfilingAgent,
    OptimizationStrategistAgent,
    OptimizationReviewerAgent,
    BenchmarkAgent,
    FinalDecisionAgent,
)
from moo.multiagent.schema import AgentMessage, MessageType


class TestStage14ActivityIntegration(unittest.TestCase):
    """Integration and invariant test suite for Stage 14 AI Activity."""

    def test_canonical_six_agents_invariant(self):
        """Invariant: Exactly six canonical agents are instantiated; NO 7th agent."""
        orch = MultiAgentOrchestrator()
        agent_attrs = [
            orch.code_analyst,
            orch.profiling_agent,
            orch.strategist,
            orch.reviewer,
            orch.benchmark_agent,
            orch.decision_agent,
        ]
        self.assertEqual(len(agent_attrs), 6, "Must have exactly 6 canonical agent instances")
        self.assertIsInstance(orch.code_analyst, CodeAnalystAgent)
        self.assertIsInstance(orch.profiling_agent, ProgramProfilingAgent)
        self.assertIsInstance(orch.strategist, OptimizationStrategistAgent)
        self.assertIsInstance(orch.reviewer, OptimizationReviewerAgent)
        self.assertIsInstance(orch.benchmark_agent, BenchmarkAgent)
        self.assertIsInstance(orch.decision_agent, FinalDecisionAgent)

        # Verify no RegressionAuditAgent or 7th agent attribute exists on orchestrator
        self.assertFalse(hasattr(orch, "regression_agent"), "Must not introduce regression_agent")
        self.assertFalse(hasattr(orch, "audit_agent"), "Must not introduce audit_agent")

    def test_linucb_transparency_metadata_structure(self):
        """
        Verify LinUCB selection metadata strictly provides mathematical quantities
        (predicted_reward, exploration_bonus, ucb_score) and NEVER fabricates speedup estimates.
        """
        strategist = OptimizationStrategistAgent()

        mock_sel = MagicMock()
        mock_sel.strategy = "-O3"
        mock_sel.provenance = "LINUCB_UCB"
        mock_sel.model_id = "linucb_v2"
        mock_sel.q_rank = [("-O3", 1.25), ("-O2", 1.10)]
        mock_sel.decision_trace = None
        mock_sel.xai_result = None
        mock_sel.selection_metadata = {
            "model_family": "LinUCB",
            "selected_action": "-O3",
            "selected_action_idx": 3,
            "predicted_reward": 0.8521,
            "exploration_bonus": 0.3979,
            "ucb_score": 1.2500,
            "selection_policy": "linucb_ucb",
            "alpha": 0.5,
            "observation_count": 12,
            "all_arm_scores": [],
        }

        with patch("optimization_selector.select_with_provenance", return_value=mock_sel):
            msg = strategist.initial_proposal(
                source_path="dummy.c",
                run_id="run_test",
                step=1,
                ir_features={"total_instructions": 50.0},
                model_family="linucb",
            )

        payload = msg.payload
        self.assertEqual(payload.get("model_family"), "LinUCB")
        self.assertEqual(payload.get("selected_action_idx"), 3)
        self.assertEqual(payload.get("selected_action_name"), "-O3")
        self.assertAlmostEqual(payload.get("predicted_reward"), 0.8521, places=4)
        self.assertAlmostEqual(payload.get("exploration_bonus"), 0.3979, places=4)
        self.assertAlmostEqual(payload.get("ucb_score"), 1.2500, places=4)
        self.assertEqual(payload.get("selection_policy"), "linucb_ucb")

        # Crucial transparency check: verify keys do NOT label reward as speedup
        self.assertNotIn("predicted_speedup", payload, "Must not label reward as predicted_speedup")
        self.assertNotIn("estimated_speedup", payload, "Must not fabricate estimated_speedup")

    def test_dqn_metadata_backward_compatibility(self):
        """Verify DQN mode preserves backward compatibility with zero exploration bonus."""
        strategist = OptimizationStrategistAgent()

        mock_sel = MagicMock()
        mock_sel.strategy = "-O2"
        mock_sel.provenance = "DQN_ARGMAX"
        mock_sel.model_id = "production_v0"
        mock_sel.q_rank = [("-O2", 0.94)]
        mock_sel.decision_trace = None
        mock_sel.xai_result = None
        mock_sel.selection_metadata = {
            "model_family": "DQN",
            "selected_action": "-O2",
            "selected_action_idx": 2,
            "predicted_reward": 0.9400,
            "exploration_bonus": 0.0,
            "ucb_score": 0.9400,
            "selection_policy": "dqn_argmax",
            "alpha": 0.0,
            "observation_count": 0,
        }

        with patch("optimization_selector.select_with_provenance", return_value=mock_sel):
            msg = strategist.initial_proposal(
                source_path="dummy.c",
                run_id="run_test",
                step=1,
                ir_features={"total_instructions": 50.0},
                model_family="dqn",
            )

        payload = msg.payload
        self.assertEqual(payload.get("model_family"), "DQN")
        self.assertEqual(payload.get("selected_action_idx"), 2)
        self.assertAlmostEqual(payload.get("predicted_reward"), 0.9400, places=4)
        self.assertEqual(payload.get("exploration_bonus"), 0.0)
        self.assertAlmostEqual(payload.get("ucb_score"), 0.9400, places=4)
        self.assertEqual(payload.get("selection_policy"), "dqn_argmax")

    def test_benchmark_agent_progress_reporting(self):
        """Verify BenchmarkAgent invokes on_progress during warmup and measurement."""
        bench_agent = BenchmarkAgent()
        progress_events = []

        def on_progress(p: Dict[str, Any]):
            progress_events.append(dict(p))

        mock_eval_res = MagicMock()
        mock_eval_res.to_dict.return_value = {
            "baseline": {"median_s": 0.012, "timing_is_reliable": True, "build_ok": True},
            "optimized": {"median_s": 0.010, "timing_is_reliable": True, "build_ok": True},
        }

        with patch("moo.pipeline.evaluate_program", return_value=mock_eval_res):
            bench_agent.benchmark(
                source_path="gemm.c",
                strategy="-O3",
                run_id="run_bench_01",
                step=5,
                warmup_runs=2,
                measure_runs=5,
                on_progress=on_progress,
            )

        self.assertGreaterEqual(len(progress_events), 2, "Expected at least 2 progress events")
        phases = [p["phase"] for p in progress_events]
        self.assertIn("warmup", phases)
        self.assertIn("measurement", phases)
        for p in progress_events:
            self.assertEqual(p["strategy"], "-O3")

    def test_regression_analysis_payload_enrichment(self):
        """Verify stage_completed for regression_analysis delivers structured metrics."""
        orch = MultiAgentOrchestrator()
        emitted_stages = []

        def on_stage(stage: str, status: str, payload: Optional[Dict[str, Any]]):
            emitted_stages.append((stage, status, payload or {}))

        # Mock sub-agents for deterministic lightweight test
        analyst_msg = AgentMessage.create(
            "CodeAnalystAgent", "Orchestrator", "IR_FEATURES",
            {
                "features": {"total_instructions": 100.0, "vectorizable_loops": 2.0},
                "raw_features": [100.0, 2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "ir_features": {"total_instructions": 100.0, "vectorizable_loops": 2.0},
            },
            run_id="run_test",
            step=1,
        )
        profile_msg = AgentMessage.create(
            "ProgramProfilingAgent", "Orchestrator", "PROGRAM_PROFILE",
            {
                "profile": {"label": "compute_bound", "dominant_feature": "instructions"}
            },
            run_id="run_test",
            step=2,
        )
        strat_msg = AgentMessage.create(
            "OptimizationStrategistAgent", "Reviewer", "STRATEGY_PROPOSAL",
            {
                "strategy": "-O3",
                "model_family": "LinUCB",
                "selected_action_idx": 3,
                "predicted_reward": 0.82,
                "exploration_bonus": 0.15,
                "ucb_score": 0.97,
                "selection_policy": "linucb_ucb",
            },
            run_id="run_test",
            step=3,
        )
        rev_msg = AgentMessage.create(
            "OptimizationReviewerAgent", "Orchestrator", "REVIEW_ACCEPT",
            {
                "strategy": "-O3",
                "decision": "ACCEPT",
            },
            run_id="run_test",
            step=4,
        )
        bench_msg = AgentMessage.create(
            "BenchmarkAgent", "Orchestrator", "BENCHMARK_RESULT",
            {
                "strategy": "-O3",
                "status": "OK",
                "moo_result": {
                    "source_file": "dummy.c",
                    "source_sha256": "abc123sha",
                    "status": "ok",
                    "baseline": {
                        "strategy_name": "-O0",
                        "build_ok": True,
                        "correct": True,
                        "measurement": {
                            "timing": {
                                "median_s": 0.020,
                                "timing_is_reliable": True,
                                "cv": 0.015,
                            },
                            "code_size": {
                                "primary_value": 1500,
                            },
                        },
                    },
                    "candidates": [
                        {
                            "strategy_name": "-O3",
                            "build_ok": True,
                            "correct": True,
                            "pareto_status": "FRONTIER",
                            "measurement": {
                                "timing": {
                                    "median_s": 0.010,
                                    "timing_is_reliable": True,
                                    "cv": 0.012,
                                },
                                "code_size": {
                                    "primary_value": 1200,
                                },
                            },
                        }
                    ],
                    "pareto_frontier": ["-O3"],
                },
            },
            run_id="run_test",
            step=5,
        )
        decision_msg = AgentMessage.create(
            "FinalDecisionAgent", "Orchestrator", "FINAL_DECISION",
            {
                "effective_strategy": "-O3",
                "fallback_occurred": False,
                "security_gate_result": {"decision": "PASS", "overall_verdict": "PASS"},
            },
            run_id="run_test",
            step=6,
        )

        orch.code_analyst.analyze = MagicMock(return_value=analyst_msg)
        orch.profiling_agent.profile = MagicMock(return_value=profile_msg)
        orch.strategist.initial_proposal = MagicMock(return_value=strat_msg)
        orch.reviewer.review_proposal = MagicMock(return_value=rev_msg)
        orch.benchmark_agent.benchmark = MagicMock(return_value=bench_msg)
        orch.decision_agent.decide = MagicMock(return_value=decision_msg)

        orch.run(
            source_path="dummy.c",
            run_benchmarks=True,
            run_security=True,
            run_regression=True,
            on_stage=on_stage,
            model_family="linucb",
        )

        # Find regression_analysis completed stage
        regr_completed = [
            (st, stat, p) for (st, stat, p) in emitted_stages
            if st == "regression_analysis" and stat == "completed"
        ]
        self.assertEqual(len(regr_completed), 1, "Must emit exactly one regression_analysis completed event")
        _, _, payload = regr_completed[0]

        self.assertIn("overall_status", payload)
        self.assertEqual(payload["selected_strategy"], "-O3")
        self.assertEqual(payload["is_conclusive"], True)
        self.assertAlmostEqual(payload["speedup_vs_baseline"], 2.0, places=2)
        self.assertAlmostEqual(payload["timing_ratio"], 0.5, places=2)
        self.assertAlmostEqual(payload["timing_cv"], 0.015, places=3)
        self.assertEqual(payload["code_size_delta_bytes"], -300)
        self.assertIn("comparison_summary", payload)

    def test_linucb_moo_provenance_without_moo_influence(self):
        """
        Phase B: Test LinUCB selection provenance when MOO does not override the recommendation.
        Verifies selected_action matches recommended_action, moo_influenced is False,
        and selection_policy reflects LinUCB UCB or cold_start.
        """
        strategist = OptimizationStrategistAgent()

        mock_sel = MagicMock()
        mock_sel.strategy = "-O3"
        mock_sel.provenance = "LINUCB_UCB"
        mock_sel.model_id = "linucb_v2"
        mock_sel.q_rank = [("-O3", 1.25), ("-O2", 1.10)]
        mock_sel.decision_trace = None
        mock_sel.xai_result = None
        mock_sel.selection_metadata = {
            "model_family": "LinUCB",
            "selected_action": "-O3",
            "selected_action_idx": 3,
            "recommended_action": "-O3",
            "recommended_action_idx": 3,
            "moo_influenced": False,
            "predicted_reward": 0.8521,
            "exploration_bonus": 0.3979,
            "ucb_score": 1.2500,
            "selection_policy": "linucb_ucb",
            "alpha": 0.5,
            "observation_count": 12,
            "all_arm_scores": [],
        }

        with patch("optimization_selector.select_with_provenance", return_value=mock_sel):
            msg = strategist.initial_proposal(
                source_path="dummy.c",
                run_id="run_test",
                step=1,
                ir_features={"total_instructions": 50.0},
                model_family="linucb",
            )

        payload = msg.payload
        self.assertEqual(payload["selected_action_name"], "-O3")
        self.assertEqual(payload["recommended_action"], "-O3")
        self.assertEqual(payload["selected_action_idx"], 3)
        self.assertEqual(payload["recommended_action_idx"], 3)
        self.assertFalse(payload["moo_influenced"])
        self.assertEqual(payload["selection_policy"], "linucb_ucb")

    def test_linucb_moo_provenance_with_moo_influence(self):
        """
        Phase B: Test LinUCB selection provenance when MOO Pareto frontier overrides bandit recommendation.
        Verifies:
        - selected_action is the final MOO-selected strategy.
        - recommended_action retains LinUCB's original recommendation without misrepresentation.
        - moo_influenced is True.
        - selection_policy is 'moo_pareto'.
        """
        strategist = OptimizationStrategistAgent()

        mock_sel = MagicMock()
        mock_sel.strategy = "-O3"
        mock_sel.provenance = "LINUCB_MOO"
        mock_sel.model_id = "linucb_v2"
        mock_sel.q_rank = [("-O1", 1.45), ("-O3", 1.25)]
        mock_sel.decision_trace = None
        mock_sel.xai_result = None
        mock_sel.selection_metadata = {
            "model_family": "LinUCB",
            "selected_action": "-O3",
            "selected_action_idx": 3,
            "recommended_action": "-O1",
            "recommended_action_idx": 1,
            "moo_influenced": True,
            "predicted_reward": 0.8521,
            "exploration_bonus": 0.3979,
            "ucb_score": 1.2500,
            "selection_policy": "moo_pareto",
            "alpha": 0.5,
            "observation_count": 12,
            "all_arm_scores": [],
        }

        with patch("optimization_selector.select_with_provenance", return_value=mock_sel):
            msg = strategist.initial_proposal(
                source_path="dummy.c",
                run_id="run_test",
                step=1,
                ir_features={"total_instructions": 50.0},
                model_family="linucb",
            )

        payload = msg.payload
        self.assertEqual(payload["strategy"], "-O3")
        self.assertEqual(payload["selected_action_name"], "-O3")
        self.assertEqual(payload["selected_action_idx"], 3)
        # LinUCB original recommendation is cleanly preserved and not misrepresented
        self.assertEqual(payload["recommended_action"], "-O1")
        self.assertEqual(payload["recommended_action_idx"], 1)
        self.assertTrue(payload["moo_influenced"])
        self.assertEqual(payload["selection_policy"], "moo_pareto")

    def test_dqn_moo_provenance_with_moo_influence(self):
        """
        Phase B: Test DQN provenance when MOO Pareto filtering overrides DQN argmax recommendation.
        """
        strategist = OptimizationStrategistAgent()

        mock_sel = MagicMock()
        mock_sel.strategy = "-O2"
        mock_sel.provenance = "DQN_MOO"
        mock_sel.model_id = "production_v0"
        mock_sel.q_rank = [("-O0", 1.10), ("-O2", 0.94)]
        mock_sel.decision_trace = None
        mock_sel.xai_result = None
        mock_sel.selection_metadata = {
            "model_family": "DQN",
            "selected_action": "-O2",
            "selected_action_idx": 2,
            "recommended_action": "-O0",
            "recommended_action_idx": 0,
            "moo_influenced": True,
            "predicted_reward": 0.9400,
            "exploration_bonus": 0.0,
            "ucb_score": 0.9400,
            "selection_policy": "moo_pareto",
            "alpha": 0.0,
            "observation_count": 0,
        }

        with patch("optimization_selector.select_with_provenance", return_value=mock_sel):
            msg = strategist.initial_proposal(
                source_path="dummy.c",
                run_id="run_test",
                step=1,
                ir_features={"total_instructions": 50.0},
                model_family="dqn",
            )

        payload = msg.payload
        self.assertEqual(payload["strategy"], "-O2")
        self.assertEqual(payload["selected_action_name"], "-O2")
        self.assertEqual(payload["selected_action_idx"], 2)
        self.assertEqual(payload["recommended_action"], "-O0")
        self.assertEqual(payload["recommended_action_idx"], 0)
        self.assertTrue(payload["moo_influenced"])
        self.assertEqual(payload["selection_policy"], "moo_pareto")

    def test_stage_progress_envelope_validation(self):
        """Verify EventEnvelope validates STAGE_PROGRESS and StageStatus.PROGRESS."""
        self.assertEqual(EventType.STAGE_PROGRESS.value, "stage_progress")
        self.assertEqual(StageStatus.PROGRESS.value, "progress")

        from web.events import SCHEMA_VERSION
        env = EventEnvelope(
            schema_version=SCHEMA_VERSION,
            event_id="evt_prog_0001",
            run_id="run_env_test",
            program_id="gemm",
            seq=3,
            timestamp="2026-11-18T00:00:00Z",
            event_type=EventType.STAGE_PROGRESS.value,
            stage=PipelineStage.BENCHMARKING.value,
            status=StageStatus.PROGRESS.value,
            payload={"phase": "warmup", "iteration": 1, "total": 3, "strategy": "-O3"},
        )
        env.validate()
        self.assertEqual(env.stage, "benchmarking")
        self.assertEqual(env.status, "progress")
        self.assertEqual(env.event_type, "stage_progress")


if __name__ == "__main__":
    unittest.main()
