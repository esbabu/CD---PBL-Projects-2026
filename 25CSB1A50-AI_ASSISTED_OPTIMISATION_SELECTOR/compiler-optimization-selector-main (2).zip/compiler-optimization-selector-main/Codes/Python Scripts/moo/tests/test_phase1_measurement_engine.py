"""
Codes/Python Scripts/moo/tests/test_phase1_measurement_engine.py
Phase 1 Focused Test Suite for Subprocess Execution and Raw Timing.

Test Requirements Covered:
1. Normal process completion.
2. Nonzero exit code.
3. Process crash.
4. Timeout.
5. stdout/stderr capture.
6. Pipe saturation without deadlock.
7. Process-handle cleanup.
8. CPU-time retrieval where supported.
9. Calibration failure.
10. Successful calibration and timeout calculation.
11. Raw observation recording.
12. Compilation excluded from execution timing.
13. Existing Normal/DQN/LinUCB integration.
14. Existing benchmark API compatibility.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
import unittest

# Ensure moo package is importable
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_MOO_PARENT = os.path.dirname(os.path.dirname(_SCRIPT_DIR))  # .../Python Scripts/
if _MOO_PARENT not in sys.path:
    sys.path.insert(0, _MOO_PARENT)

from moo import config
from moo.measurement import (
    _run_once,
    calibrate_benchmark_timeout,
    measure_execution,
    measure_interleaved,
    measure_all,
    ExecutionRecord,
    MeasurementResult,
    CalibrationResult,
    TimingStats,
    _WIN32_AVAILABLE,
)


class TestPhase1MeasurementEngine(unittest.TestCase):
    """Test suite validating the 14 Phase 1 measurement requirements."""

    def test_01_normal_process_completion(self):
        """Requirement 1: Normal process completion."""
        cmd = [sys.executable, "-c", "import sys; sys.exit(0)"]
        # Use python script wrapper as executable
        rec = _run_once(cmd[0], timeout_s=10, args=cmd[1:])
        self.assertEqual(rec.return_code, 0)
        self.assertFalse(rec.timed_out)
        self.assertIsNone(rec.error)
        self.assertGreater(rec.elapsed_ns, 0)
        self.assertGreater(rec.wall_time_ns, 0)
        self.assertEqual(rec.wall_time_ns, rec.elapsed_ns)

    def test_02_nonzero_exit_code(self):
        """Requirement 2: Nonzero exit code."""
        cmd = [sys.executable, "-c", "import sys; sys.exit(42)"]
        rec = _run_once(cmd[0], timeout_s=10, args=cmd[1:])
        # Nonzero exit code is recorded faithfully and NOT treated as a subprocess error
        self.assertEqual(rec.return_code, 42)
        self.assertFalse(rec.timed_out)
        self.assertIsNone(rec.error)
        self.assertGreater(rec.elapsed_ns, 0)

    def test_03_process_crash(self):
        """Requirement 3: Process crash."""
        # Force an access violation / hard crash in child process
        cmd = [sys.executable, "-c", "import ctypes; ctypes.string_at(0)"]
        rec = _run_once(cmd[0], timeout_s=10, args=cmd[1:])
        self.assertNotEqual(rec.return_code, 0)
        self.assertFalse(rec.timed_out)
        # Process crash should not cause unhandled exceptions in the measurement harness
        self.assertGreater(rec.elapsed_ns, 0)

    def test_04_timeout(self):
        """Requirement 4: Bounded timeout and direct child termination."""
        cmd = [sys.executable, "-c", "import time; time.sleep(10)"]
        t_start = time.perf_counter()
        rec = _run_once(cmd[0], timeout_s=0.5, args=cmd[1:])
        t_elapsed = time.perf_counter() - t_start

        self.assertTrue(rec.timed_out)
        self.assertEqual(rec.return_code, -1)
        self.assertIsNotNone(rec.error)
        self.assertIn("TimeoutExpired", rec.error)
        # Timeout must be bounded close to 0.5s, well before the 10s sleep
        self.assertLess(t_elapsed, 4.0)
        self.assertGreaterEqual(t_elapsed, 0.4)

    def test_05_stdout_stderr_capture(self):
        """Requirement 5: stdout/stderr capture."""
        expected_out = "HELLO_TOACD_STDOUT\n"
        expected_err = "HELLO_TOACD_STDERR\n"
        code = (
            "import sys\n"
            "sys.stdout.write('HELLO_TOACD_STDOUT\\n')\n"
            "sys.stderr.write('HELLO_TOACD_STDERR\\n')\n"
        )
        cmd = [sys.executable, "-c", code]
        rec = _run_once(cmd[0], timeout_s=10, args=cmd[1:])
        self.assertEqual(rec.return_code, 0)
        # Verify captured string and bytes (handling platform-specific CRLF/LF)
        self.assertEqual(rec.stdout.replace("\r\n", "\n"), expected_out)
        self.assertEqual(rec.stderr.replace("\r\n", "\n"), expected_err)
        self.assertIn(b"HELLO_TOACD_STDOUT", rec.stdout_bytes)
        self.assertIn(b"HELLO_TOACD_STDERR", rec.stderr_bytes)

    def test_06_pipe_saturation_without_deadlock(self):
        """Requirement 6: Pipe saturation without deadlock."""
        # 1 MiB of output saturates default OS pipe buffers (typically 64KB on Windows/Linux)
        data_size = 1024 * 1024
        code = f"import sys; sys.stdout.write('A' * {data_size})"
        cmd = [sys.executable, "-c", code]
        t0 = time.time()
        rec = _run_once(cmd[0], timeout_s=15, args=cmd[1:])
        elapsed = time.time() - t0

        self.assertEqual(rec.return_code, 0)
        self.assertFalse(rec.timed_out)
        self.assertEqual(len(rec.stdout_bytes), data_size)
        self.assertLess(elapsed, 10.0)

    def test_07_process_handle_cleanup(self):
        """Requirement 7: Process-handle cleanup."""
        # Run 25 subprocesses rapidly and ensure all handles are closed deterministically
        cmd = [sys.executable, "-c", "import sys; sys.exit(0)"]
        for _ in range(25):
            rec = _run_once(cmd[0], timeout_s=5, args=cmd[1:])
            self.assertEqual(rec.return_code, 0)
            self.assertFalse(rec.timed_out)

    def test_08_cpu_time_retrieval_where_supported(self):
        """Requirement 8: CPU-time retrieval where supported."""
        # Run a CPU-bound loop
        code = "import time; [x**2 for x in range(1500000)]"
        cmd = [sys.executable, "-c", code]
        rec = _run_once(cmd[0], timeout_s=10, args=cmd[1:])
        self.assertEqual(rec.return_code, 0)

        if _WIN32_AVAILABLE:
            self.assertTrue(rec.cpu_time_available)
            self.assertIsNotNone(rec.user_cpu_ns)
            self.assertIsNotNone(rec.kernel_cpu_ns)
            self.assertGreater(rec.user_cpu_ns, 0)
            self.assertGreaterEqual(rec.kernel_cpu_ns, 0)
        else:
            self.assertFalse(rec.cpu_time_available)
            self.assertIsNone(rec.user_cpu_ns)
            self.assertIsNone(rec.kernel_cpu_ns)

    def test_09_calibration_failure(self):
        """Requirement 9: Calibration failure on crash, timeout, or exit code mismatch."""
        # Case A: Timeout during calibration (using direct python process to avoid grandchild survival)
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as tf:
            tf.write("import time; time.sleep(10)\n")
            py_path = tf.name
        try:
            res = calibrate_benchmark_timeout(
                sys.executable,
                n_runs=2,
                bootstrap_timeout_s=0.5,
                args=[py_path],
            )
            self.assertFalse(res.success)
            self.assertIsNotNone(res.error)
            self.assertIn("timed out", res.error)
        finally:
            os.remove(py_path)

        # Case B: Exit code mismatch during calibration
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as tf:
            tf.write("import sys; sys.exit(7)\n")
            py_path = tf.name
        try:
            res = calibrate_benchmark_timeout(
                sys.executable,
                n_runs=2,
                bootstrap_timeout_s=5,
                args=[py_path],
                expected_exit_code=0,
            )
            self.assertFalse(res.success)
            self.assertIsNotNone(res.error)
            self.assertIn("exit code mismatch", res.error)
        finally:
            os.remove(py_path)

    def test_10_successful_calibration_and_timeout_calculation(self):
        """Requirement 10: Successful calibration and timeout calculation."""
        with tempfile.NamedTemporaryFile("w", suffix=".bat", delete=False) as tf:
            tf.write("@echo off\necho OK\nexit /b 0\n")
            bat_path = tf.name
        try:
            res = calibrate_benchmark_timeout(
                bat_path,
                n_runs=5,
                bootstrap_timeout_s=10,
                expected_exit_code=0,
                expected_stdout="OK\n",
            )
            self.assertTrue(res.success)
            self.assertIsNone(res.error)
            self.assertIsNotNone(res.t_calib_s)
            self.assertGreater(res.t_calib_s, 0)
            self.assertEqual(len(res.calibration_samples_ns), 5)
            self.assertEqual(len(res.observations), 5)
            self.assertTrue(res.is_provisional)
            # Timeout formula per v3.5 §17.7: max(20 * T_calib, 10.0 s)
            expected_timeout = max(20.0 * res.t_calib_s, 10.0)
            self.assertAlmostEqual(res.timeout_s, expected_timeout, places=5)
            self.assertGreaterEqual(res.timeout_s, 10.0)
        finally:
            os.remove(bat_path)

    def test_11_raw_observation_recording(self):
        """Requirement 11: Raw observation recording."""
        with tempfile.NamedTemporaryFile("w", suffix=".bat", delete=False) as tf:
            tf.write("@echo off\necho RUN\nexit /b 0\n")
            bat_path = tf.name
        try:
            mres = measure_execution(bat_path, strategy="test_raw", warmup_runs=1, measure_runs=5)
            self.assertEqual(len(mres.raw_observations), 5)
            self.assertEqual(len(mres.raw_samples_ns), 5)
            for idx, obs in enumerate(mres.raw_observations):
                self.assertEqual(obs["run_index"], idx + 1)
                self.assertGreater(obs["wall_time_ns"], 0)
                self.assertEqual(obs["return_code"], 0)
                self.assertFalse(obs["timed_out"])
                self.assertIsNone(obs["error"])
        finally:
            os.remove(bat_path)

    def test_12_compilation_excluded_from_execution_timing(self):
        """Requirement 12: Compilation excluded from execution timing."""
        clang = config.CLANG_PATH
        if not clang or not os.path.isfile(clang):
            self.skipTest("clang not available on host")

        source_code = "int main(void) { return 0; }\n"
        tmpdir = tempfile.mkdtemp(prefix="toacd_test_comp_")
        try:
            src_file = os.path.join(tmpdir, "test.c")
            exe_file = os.path.join(tmpdir, "test.exe")
            with open(src_file, "w", encoding="utf-8") as f:
                f.write(source_code)

            # Measure compilation time
            t_comp_start = time.perf_counter_ns()
            c_proc = subprocess.run([clang, "-O0", src_file, "-o", exe_file], capture_output=True)
            t_comp_ns = time.perf_counter_ns() - t_comp_start
            self.assertEqual(c_proc.returncode, 0)
            self.assertTrue(os.path.isfile(exe_file))

            # Measure execution time via harness
            mres = measure_execution(exe_file, strategy="-O0", warmup_runs=1, measure_runs=3)
            self.assertIsNotNone(mres.timing)

            # Verify that execution timing boundary is distinct and does not include compilation
            # Compilation of C with clang takes > 50ms; execution of return 0 takes ~10-40ms
            self.assertGreater(t_comp_ns, 0)
            self.assertGreater(mres.timing.median_ns, 0)
            # Compilation time is tracked separately outside measure_execution
            self.assertNotIn("compilation_ns", mres.timing.to_dict())
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_13_normal_dqn_linucb_integration(self):
        """Requirement 13: Normal / DQN / LinUCB pipeline integration compatibility."""
        from moo.runrecord.builder import RunRecordBuilder, _measurement_snapshot_from_dict
        from moo.runrecord.schema import MeasurementStatus

        # Test creating a MeasurementSnapshot with the new MeasurementResult fields
        mres = MeasurementResult(
            strategy="-O3",
            exe_path="dummy.exe",
            warmup_runs=1,
            measure_runs=3,
            raw_samples_ns=[20000000, 21000000, 20500000],
            raw_wall_time_ns=[20000000, 21000000, 20500000],
            raw_user_cpu_ns=[15000000, 16000000, 15500000],
            raw_kernel_cpu_ns=[4000000, 4500000, 4200000],
            cpu_time_available=True,
            timing=TimingStats.from_samples([20000000, 21000000, 20500000]),
            last_return_code=0,
        )
        snap = _measurement_snapshot_from_dict(mres.to_dict(), "-O3")
        self.assertEqual(snap.strategy, "-O3")
        self.assertEqual(snap.status, MeasurementStatus.OK)
        self.assertAlmostEqual(snap.median_s, 0.0205, places=4)

        # Build RunRecord using mres.to_dict()
        builder = RunRecordBuilder(source_path="dummy.c", run_id="test_run_123")
        builder.set_optimized_measurement("-O3", mres.to_dict())
        record = builder.build()
        self.assertIsNotNone(record.optimized_measurement)
        self.assertEqual(record.optimized_measurement.strategy, "-O3")
        self.assertEqual(record.optimized_measurement.status, MeasurementStatus.OK)

    def test_14_existing_benchmark_api_compatibility(self):
        """Requirement 14: Existing benchmark API compatibility."""
        with tempfile.NamedTemporaryFile("w", suffix=".bat", delete=False) as tf:
            tf.write("@echo off\necho API_OK\nexit /b 0\n")
            bat_path = tf.name
        try:
            # 1. measure_execution signature and return types
            res = measure_execution(bat_path, strategy="-O0", warmup_runs=1, measure_runs=3)
            self.assertIsInstance(res, MeasurementResult)
            d = res.to_dict()
            # Must contain legacy keys
            for key in ["strategy", "exe_path", "warmup_runs", "measure_runs", "raw_samples_ns", "timing", "all_return_codes"]:
                self.assertIn(key, d)
            # Must contain new Phase 1 keys
            for key in ["raw_wall_time_ns", "raw_user_cpu_ns", "raw_kernel_cpu_ns", "raw_observations", "cpu_time_available"]:
                self.assertIn(key, d)

            # 2. measure_interleaved signature and return types
            inter_res = measure_interleaved([("base", bat_path), ("cand", bat_path)], warmup_runs=1, measure_runs=3)
            self.assertIn("base", inter_res)
            self.assertIn("cand", inter_res)
            self.assertIsInstance(inter_res["base"], MeasurementResult)
            self.assertIsInstance(inter_res["cand"], MeasurementResult)
            self.assertEqual(len(inter_res["base"].raw_observations), 3)
        finally:
            os.remove(bat_path)

    def test_15_auto_calibrate_pipeline_integration(self):
        """Requirement 15: Auto-calibration integration in measure_interleaved and measure_execution."""
        with tempfile.NamedTemporaryFile("w", suffix=".bat", delete=False) as tf:
            tf.write("@echo off\necho CALIB_INTERLEAVED_OK\nexit /b 0\n")
            bat_path = tf.name
        try:
            # Test auto_calibrate=True on measure_execution
            mres = measure_execution(bat_path, strategy="-O3", warmup_runs=1, measure_runs=3, auto_calibrate=True)
            self.assertIsNotNone(mres.calibration)
            self.assertTrue(mres.calibration.success)
            self.assertGreaterEqual(mres.calibration.timeout_s, 10.0)

            # Test auto_calibrate=True on measure_interleaved
            targets = [("base", bat_path), ("cand", bat_path)]
            inter_res = measure_interleaved(targets, warmup_runs=1, measure_runs=3, auto_calibrate=True)
            self.assertIn("base", inter_res)
            self.assertIn("cand", inter_res)
            self.assertTrue(inter_res["base"].calibration.success)
            self.assertTrue(inter_res["cand"].calibration.success)
            self.assertGreaterEqual(inter_res["base"].calibration.timeout_s, 10.0)
            self.assertGreaterEqual(inter_res["cand"].calibration.timeout_s, 10.0)
        finally:
            os.remove(bat_path)

    @unittest.skipUnless(_WIN32_AVAILABLE, "Windows-specific API mock test")
    def test_16_cpu_time_api_error_mocked(self):
        """Audit Requirement: Mock GetProcessTimes failure -> API_ERROR."""
        import moo.measurement as mm
        with unittest.mock.patch.object(mm.kernel32, "GetProcessTimes", return_value=0):
            with unittest.mock.patch("ctypes.get_last_error", return_value=5):  # ERROR_ACCESS_DENIED
                u, k, status, err = mm._query_process_cpu_times(12345)
                self.assertIsNone(u)
                self.assertIsNone(k)
                self.assertEqual(status, "API_ERROR")
                self.assertIn("error code 5", err)

    @unittest.skipUnless(_WIN32_AVAILABLE, "Windows-specific API mock test")
    def test_17_cpu_time_below_resolution_mocked(self):
        """Audit Requirement: Mock GetProcessTimes returning 0ns -> BELOW_RESOLUTION."""
        import moo.measurement as mm
        def fake_get_process_times(h, c, e, k, u):
            return 1

        with unittest.mock.patch.object(mm.kernel32, "GetProcessTimes", side_effect=fake_get_process_times):
            u, k, status, err = mm._query_process_cpu_times(12345)
            self.assertEqual(u, 0)
            self.assertEqual(k, 0)
            self.assertEqual(status, "BELOW_RESOLUTION")
            self.assertIn("timer interrupt quantum", err)

    @unittest.skipUnless(_WIN32_AVAILABLE, "Windows-specific API mock test")
    def test_18_cpu_time_ok_mocked(self):
        """Audit Requirement: Mock GetProcessTimes returning 15.625ms -> OK."""
        import moo.measurement as mm
        def fake_get_process_times(h, c, e, k, u):
            # 156250 in 100ns units = 15,625,000 ns = 15.625 ms
            u._obj.dwLowDateTime = 156250
            u._obj.dwHighDateTime = 0
            k._obj.dwLowDateTime = 78125
            k._obj.dwHighDateTime = 0
            return 1

        with unittest.mock.patch.object(mm.kernel32, "GetProcessTimes", side_effect=fake_get_process_times):
            u, k, status, err = mm._query_process_cpu_times(12345)
            self.assertEqual(u, 15625000)
            self.assertEqual(k, 7812500)
            self.assertEqual(status, "OK")
            self.assertIsNone(err)

    @unittest.skipUnless(_WIN32_AVAILABLE, "Windows-specific timing comparison test")
    def test_19_controlled_programs_cpu_vs_sleeping(self):
        """Audit Requirement: Controlled Program A (CPU-bound) vs Program B (sleeping)."""
        # Program A: CPU-bound loop ~150ms
        cmd_a = [sys.executable, "-c", "import time; t0 = time.perf_counter(); x = 0\nwhile time.perf_counter() - t0 < 0.15: x += 1"]
        rec_a = _run_once(cmd_a[0], timeout_s=10, args=cmd_a[1:])
        self.assertEqual(rec_a.return_code, 0)
        self.assertGreater(rec_a.elapsed_ns, 100_000_000)
        self.assertIn(rec_a.cpu_status, ("OK", "BELOW_RESOLUTION"))
        self.assertIsNotNone(rec_a.user_cpu_ns)
        self.assertGreater(rec_a.user_cpu_ns, 0)

        # Program B: Sleeping process ~150ms
        cmd_b = [sys.executable, "-c", "import time; time.sleep(0.15)"]
        rec_b = _run_once(cmd_b[0], timeout_s=10, args=cmd_b[1:])
        self.assertEqual(rec_b.return_code, 0)
        self.assertGreater(rec_b.elapsed_ns, 140_000_000)
        user_b = rec_b.user_cpu_ns or 0
        kern_b = rec_b.kernel_cpu_ns or 0
        residual_b = rec_b.elapsed_ns - (user_b + kern_b)
        self.assertGreater(residual_b, 100_000_000)

    def test_20_residual_calculation_and_aggregation(self):
        """Audit Requirement: Residual calculation unclamped linearity and aggregation."""
        # 1. Unclamped calculation in ExecutionRecord
        rec = ExecutionRecord(
            return_code=0,
            stdout="ok",
            stderr="",
            elapsed_ns=100_000_000,
            wall_time_ns=100_000_000,
            user_cpu_ns=70_000_000,
            kernel_cpu_ns=10_000_000,
        )
        self.assertEqual(rec.total_cpu_ns, 80_000_000)
        self.assertEqual(rec.residual_elapsed_ns, 20_000_000)

        # 2. Timer tick quantization overshoot produces negative residual without zero-clamping
        rec_overshoot = ExecutionRecord(
            return_code=0,
            stdout="ok",
            stderr="",
            elapsed_ns=8_000_000,
            wall_time_ns=8_000_000,
            user_cpu_ns=15_625_000,
            kernel_cpu_ns=0,
        )
        self.assertEqual(rec_overshoot.total_cpu_ns, 15_625_000)
        self.assertEqual(rec_overshoot.residual_elapsed_ns, -7_625_000)
        self.assertLess(rec_overshoot.residual_elapsed_ns, 0)  # Verify NOT clamped to 0

        # 3. Linearity of expectation across aggregate MeasurementResult
        samples_wall = [100_000_000, 110_000_000, 90_000_000]
        samples_cpu = [80_000_000, 85_000_000, 75_000_000]
        samples_res = [w - c for w, c in zip(samples_wall, samples_cpu)]

        t_stats = TimingStats.from_samples(samples_wall)
        cpu_stats = TimingStats.from_samples(samples_cpu)
        res_stats = TimingStats.from_samples(samples_res)

        res_result = MeasurementResult(
            strategy="-O2",
            exe_path="/bin/fake",
            warmup_runs=1,
            measure_runs=3,
            timing=t_stats,
            raw_samples_ns=samples_wall,
            total_cpu_timing=cpu_stats,
            raw_total_cpu_ns=samples_cpu,
            residual_timing=res_stats,
            raw_residual_ns=samples_res,
        )

        self.assertIsNotNone(res_result.residual_timing)
        self.assertAlmostEqual(
            res_result.residual_timing.mean_ns,
            res_result.timing.mean_ns - res_result.total_cpu_timing.mean_ns,
            delta=1e-5
        )
        d = res_result.to_dict()
        self.assertIn("residual_timing", d)
        self.assertIn("raw_residual_ns", d)

    def test_21_residual_projection_and_cross_mode_consistency(self):
        """Verify to_gui_view correctly projects residual and cpu metrics and supports cross-mode consistency."""
        from moo.runrecord.builder import RunRecordBuilder
        from moo.runrecord.projections import to_gui_view

        samples_wall = [50_000_000, 52_000_000, 48_000_000]
        samples_cpu = [40_000_000, 41_000_000, 39_000_000]
        samples_res = [w - c for w, c in zip(samples_wall, samples_cpu)]

        t_base = TimingStats.from_samples(samples_wall)
        cpu_base = TimingStats.from_samples(samples_cpu)
        res_base = TimingStats.from_samples(samples_res)

        base_res = MeasurementResult(
            strategy="baseline (-O0)",
            exe_path="/bin/fake_base",
            warmup_runs=1,
            measure_runs=3,
            timing=t_base,
            raw_samples_ns=samples_wall,
            total_cpu_timing=cpu_base,
            raw_total_cpu_ns=samples_cpu,
            residual_timing=res_base,
            raw_residual_ns=samples_res,
            cpu_status="OK",
            cpu_time_available=True,
        )

        samples_opt_wall = [25_000_000, 26_000_000, 24_000_000]
        samples_opt_cpu = [20_000_000, 21_000_000, 19_000_000]
        samples_opt_res = [w - c for w, c in zip(samples_opt_wall, samples_opt_cpu)]

        t_opt = TimingStats.from_samples(samples_opt_wall)
        cpu_opt = TimingStats.from_samples(samples_opt_cpu)
        res_opt = TimingStats.from_samples(samples_opt_res)

        opt_res = MeasurementResult(
            strategy="-O3",
            exe_path="/bin/fake_opt",
            warmup_runs=1,
            measure_runs=3,
            timing=t_opt,
            raw_samples_ns=samples_opt_wall,
            total_cpu_timing=cpu_opt,
            raw_total_cpu_ns=samples_opt_cpu,
            residual_timing=res_opt,
            raw_residual_ns=samples_opt_res,
            cpu_status="OK",
            cpu_time_available=True,
        )

        builder = RunRecordBuilder("test.c", run_id="test_run_res_01")
        builder.set_baseline_measurement(base_res.to_dict())
        builder.set_optimized_measurement("-O3", opt_res.to_dict())
        builder.set_production_from_moo({"candidates": [{"strategy_name": "-O3", "measurement": opt_res.to_dict()}]}, "-O3")
        builder.add_note("[STAGE_TIMINGS] comp=15.2ms bench=45.1ms total=60.3ms")
        rec = builder.build()

        view = to_gui_view(rec)
        self.assertIn("baseline_timing", view)
        self.assertIn("optimized_timing", view)
        self.assertIn("production_timing", view)
        self.assertIn("stage_timings", view)

        # Baseline projections
        b_view = view["baseline_timing"]
        self.assertEqual(b_view["cpu_status"], "OK")
        self.assertTrue(b_view["cpu_time_available"])
        self.assertAlmostEqual(b_view["residual_median_ms"], 10.0, places=2)
        self.assertAlmostEqual(b_view["cpu_median_ms"], 40.0, places=2)

        # Optimized projections
        o_view = view["optimized_timing"]
        self.assertEqual(o_view["cpu_status"], "OK")
        self.assertTrue(o_view["cpu_time_available"])
        self.assertAlmostEqual(o_view["residual_median_ms"], 5.0, places=2)
        self.assertAlmostEqual(o_view["cpu_median_ms"], 20.0, places=2)

        # Comparison projections
        perf = view["performance_comparison"]
        self.assertIn("delta_residual_ms", perf)
        self.assertIn("delta_cpu_ms", perf)
        self.assertAlmostEqual(perf["delta_residual_ms"], 5.0, places=2)
        self.assertAlmostEqual(perf["delta_cpu_ms"], 20.0, places=2)

        # Stage timings
        st = view["stage_timings"]
        self.assertEqual(st.get("comp"), 15.2)
        self.assertEqual(st.get("bench"), 45.1)
        self.assertEqual(st.get("total"), 60.3)


if __name__ == "__main__":
    unittest.main()
