"""
moo/tests/test_stage12_security.py — Comprehensive Test Suite for Stage 12.

Covers:
A. Security Flag Policy & Profiles (Standard, Windows Hardened, Linux Hardened, Custom)
B. FORTIFY_SOURCE Capability Probe & 4-State Outcomes
C. Stack Protector IR Verifier (Strong vs All, whole-program coverage, vulnerable function audit)
D. Fallback & BLOCKED State Semantics (Fail-closed default, Degraded Fallback override)
E. Security Gate Integration & Agent Determinism
"""

from __future__ import annotations

import os
import re
import tempfile
import pytest

from moo.security.flag_policy import (
    SecurityProfile,
    FlagEvidenceLevel,
    FlagVerdict,
    CandidateProfileVerdict,
    FortifyProbeStatus,
    get_profile_flags,
    get_profile_requirements,
    validate_compilation_flags,
    run_fortify_capability_probe,
    _FORTIFY_CALL_REGEX,
    _UNFORTIFIED_CALL_REGEX,
)
from moo.security.ir_verifier import (
    IRVerificationVerdict,
    verify_module_stack_protector,
)
from moo.security.gate import (
    OptimizationSecurityGate,
    GateDecision,
    GateResult,
    BASELINE_TERMINAL_STRATEGY,
)
from moo.security.models import CandidateSecurity, CandidateVerdict
from moo.secevent.schema import AttackType
from moo.toolchain import CLANG_PATH, OPT_PATH


# ===========================================================================
# Group A: Security Flag Policy & Profile Requirements
# ===========================================================================

class TestFlagPolicyAndProfiles:
    """Tests for platform-aware flag policy and profile requirements."""

    def test_standard_profile_requires_no_hardening_flags(self):
        flags = get_profile_flags(SecurityProfile.STANDARD)
        assert flags == []

        reqs = get_profile_requirements(SecurityProfile.STANDARD)
        assert len(reqs) == 0

    def test_windows_hardened_profile_flags(self):
        flags = get_profile_flags(SecurityProfile.WINDOWS_HARDENED, target_platform="windows")
        assert "-fstack-protector-strong" in flags
        assert "-D_FORTIFY_SOURCE=2" not in flags
        assert "-fsanitize=safe-stack" not in flags

    def test_linux_hardened_profile_flags(self):
        flags = get_profile_flags(SecurityProfile.LINUX_HARDENED, target_platform="linux")
        assert "-fstack-protector-strong" in flags
        assert "-D_FORTIFY_SOURCE=2" in flags

    def test_custom_profile_respects_mandatory_flags(self):
        custom_m = ["-fstack-protector-all", "-fsanitize=cfi"]
        flags = get_profile_flags(
            SecurityProfile.CUSTOM,
            custom_mandatory_flags=custom_m,
        )
        assert "-fstack-protector-all" in flags
        assert "-fsanitize=cfi" in flags

    def test_standard_profile_passes_clean_compilation(self):
        summary = validate_compilation_flags(
            cmd=["clang", "-O2", "src.c"],
            profile=SecurityProfile.STANDARD,
            compiler_returncode=0,
        )
        assert summary.verdict == CandidateProfileVerdict.COMPLIANT
        assert summary.is_eligible_for_optimization()

    def test_forbidden_disabling_flag_causes_profile_violation(self):
        summary = validate_compilation_flags(
            cmd=["clang", "-O2", "-fno-stack-protector", "src.c"],
            profile=SecurityProfile.STANDARD,
            compiler_returncode=0,
        )
        assert summary.verdict == CandidateProfileVerdict.PROFILE_VIOLATION
        assert not summary.is_eligible_for_optimization()

    def test_missing_mandatory_flag_causes_not_passed_and_violation(self):
        summary = validate_compilation_flags(
            cmd=["clang", "-O2", "src.c"],  # missing -fstack-protector-strong
            profile=SecurityProfile.WINDOWS_HARDENED,
            compiler_returncode=0,
            target_platform="windows",
        )
        assert summary.verdict == CandidateProfileVerdict.PROFILE_VIOLATION
        assert any(r.verdict == FlagVerdict.NOT_PASSED for r in summary.flag_results)
        assert not summary.is_eligible_for_optimization()

    def test_compiler_rejection_causes_not_supported_and_violation(self):
        summary = validate_compilation_flags(
            cmd=["clang", "-O2", "-fstack-protector-strong", "src.c"],
            profile=SecurityProfile.WINDOWS_HARDENED,
            compiler_returncode=1,  # compiler error
            target_platform="windows",
        )
        assert summary.verdict == CandidateProfileVerdict.PROFILE_VIOLATION
        assert any(r.verdict == FlagVerdict.NOT_SUPPORTED for r in summary.flag_results)


# ===========================================================================
# Group B: FORTIFY_SOURCE Capability Probe & Regex Assertions
# ===========================================================================

class TestFortifyCapabilityProbe:
    """Tests for the corrected FORTIFY capability probe regex and classification."""

    def test_fortify_regex_matches_valid_chk_call(self):
        ir_text = "  %call = call ptr @__strcpy_chk(ptr noundef %dst, ptr noundef %src, i64 8)"
        assert _FORTIFY_CALL_REGEX.search(ir_text) is not None

    def test_fortify_regex_matches_builtin_chk_call(self):
        ir_text = "  %call = call ptr @__builtin___strcpy_chk(ptr %d, ptr %s, i64 8)"
        assert _FORTIFY_CALL_REGEX.search(ir_text) is not None

    def test_fortify_regex_matches_invoke_instruction(self):
        ir_text = "  %res = invoke ptr @__strcpy_chk(ptr %d, ptr %s, i64 8) to label %ok unwind label %err"
        assert _FORTIFY_CALL_REGEX.search(ir_text) is not None

    def test_fortify_regex_rejects_declaration_only(self):
        # A declaration alone without a call must NOT match the call/invoke regex
        ir_decl = "declare dso_local ptr @__strcpy_chk(ptr, ptr, i64)"
        assert _FORTIFY_CALL_REGEX.search(ir_decl) is None

    def test_unfortified_regex_matches_plain_strcpy_call(self):
        ir_plain = "  %call = call ptr @strcpy(ptr %dst, ptr %src)"
        assert _UNFORTIFIED_CALL_REGEX.search(ir_plain) is not None
        assert _FORTIFY_CALL_REGEX.search(ir_plain) is None

    def test_fortify_regex_rejects_unrelated_symbols_and_helpers(self):
        negatives = [
            "call void @my_strcpy_chk_helper()",
            "call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 8, i1 false)",
            "store i32 1, ptr @some_chk_flag",
            "call ptr @__strcpy_chk_custom()",
            "call ptr @strncpy_chk()",
        ]
        for neg in negatives:
            assert _FORTIFY_CALL_REGEX.search(neg) is None, f"False positive on: {neg}"

    def test_live_fortify_probe_on_windows_returns_flag_accepted_but_inactive(self):
        if not CLANG_PATH or not os.path.isfile(CLANG_PATH):
            pytest.skip("clang compiler not available")

        status, details = run_fortify_capability_probe(CLANG_PATH)
        # On Windows MSVC UCRT, FORTIFY is accepted by clang but inactive in headers
        assert status == FortifyProbeStatus.FLAG_ACCEPTED_BUT_INACTIVE
        assert "plain @strcpy" in details or "inactive" in details

    def test_invalid_clang_path_returns_compiler_error(self):
        status, details = run_fortify_capability_probe("non_existent_clang_binary_xyz.exe")
        assert status == FortifyProbeStatus.COMPILER_ERROR


# ===========================================================================
# Group C: Stack Protector IR Verifier (Strong vs All)
# ===========================================================================

class TestStackProtectorIRVerifier:
    """Tests for whole-module IR function attribute verification and risk auditing."""

    def test_verifier_passes_on_sspstrong_module(self):
        ir_content = """
define dso_local i32 @fn_arithmetic(i32 %a, i32 %b) #0 {
  %3 = add i32 %a, %b
  ret i32 %3
}

define dso_local void @fn_buffer(ptr %src) #0 {
  %buf = alloca [16 x i8], align 1
  call void @sink(ptr %buf)
  ret void
}

declare void @sink(ptr)

attributes #0 = { sspstrong uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        assert res.verdict == IRVerificationVerdict.PASS
        assert res.attribute_coverage_ratio == 1.0
        assert res.total_defined_functions == 2
        assert res.functions_with_attribute == 2
        assert len(res.unprotected_vulnerable_functions) == 0

    def test_verifier_flags_unprotected_buffer_function_as_profile_violation(self):
        # Function @fn_buffer has an array alloca but attribute group #1 LACKS sspstrong
        ir_content = """
define dso_local i32 @fn_leaf(i32 %a) #0 {
  ret i32 %a
}

define dso_local void @fn_buffer(ptr %src) #1 {
  %buf = alloca [16 x i8], align 1
  call void @sink(ptr %buf)
  ret void
}

declare void @sink(ptr)

attributes #0 = { sspstrong uwtable }
attributes #1 = { uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        assert res.verdict == IRVerificationVerdict.PROFILE_VIOLATION
        assert "fn_buffer" in res.unprotected_vulnerable_functions

    def test_verifier_reports_inconclusive_when_non_buffer_function_omitted_in_strong(self):
        # Under Strong, leaf function lacks sspstrong, but buffer function has it.
        # This is INCONCLUSIVE (partial coverage) rather than an outright violation.
        ir_content = """
define dso_local i32 @fn_leaf(i32 %a) #1 {
  ret i32 %a
}

define dso_local void @fn_buffer(ptr %src) #0 {
  %buf = alloca [16 x i8], align 1
  call void @sink(ptr %buf)
  ret void
}

declare void @sink(ptr)

attributes #0 = { sspstrong uwtable }
attributes #1 = { uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        assert res.verdict == IRVerificationVerdict.INCONCLUSIVE
        assert res.attribute_coverage_ratio == 0.5
        assert len(res.unprotected_vulnerable_functions) == 0

    def test_policy_b_requires_universal_sspreq(self):
        # Under Policy B (sspreq), even partial non-buffer omissions are a PROFILE_VIOLATION
        ir_content = """
define dso_local i32 @fn_leaf(i32 %a) #1 {
  ret i32 %a
}

define dso_local void @fn_buffer(ptr %src) #0 {
  %buf = alloca [16 x i8], align 1
  call void @sink(ptr %buf)
  ret void
}

declare void @sink(ptr)

attributes #0 = { sspreq uwtable }
attributes #1 = { uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspreq", is_path=False)
        assert res.verdict == IRVerificationVerdict.PROFILE_VIOLATION

    def test_live_clang_compilation_verifies_sspstrong_in_ir(self):
        if not CLANG_PATH or not os.path.isfile(CLANG_PATH):
            pytest.skip("clang compiler not available")

        src = """
int add(int a, int b) { return a + b; }
void with_arr(char *p) { char b[16]; for(int i=0;i<16;i++) b[i]=p[i]; }
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            c_file = os.path.join(tmpdir, "test.c")
            ll_file = os.path.join(tmpdir, "test.ll")
            with open(c_file, "w") as f:
                f.write(src)

            import subprocess
            cmd = [CLANG_PATH, "-O2", "-fstack-protector-strong", "-S", "-emit-llvm", c_file, "-o", ll_file]
            r = subprocess.run(cmd, capture_output=True, text=True)
            assert r.returncode == 0
            assert os.path.isfile(ll_file)

            res = verify_module_stack_protector(ll_file, target_attribute="sspstrong", is_path=True)
            assert res.verdict == IRVerificationVerdict.PASS
            assert res.attribute_coverage_ratio == 1.0


# ===========================================================================
# Group D: Fallback and BLOCKED Semantics
# ===========================================================================

class TestFallbackAndBlockedSemantics:
    """Tests for fallback ladder decisions, degraded profile overrides, and BLOCKED state."""

    def test_standard_profile_fallback_to_O0_is_compliant(self):
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        # Custom evaluator that rejects optimized candidate
        def eval_fail(cand):
            if cand != BASELINE_TERMINAL_STRATEGY:
                return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.ELIMINATED)
            return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.PRESERVED)

        res = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[("-O2", 0.8)],
            custom_evaluator=eval_fail,
            security_profile=SecurityProfile.STANDARD,
        )
        assert res.decision == GateDecision.ACCEPT_WITH_WARNINGS
        assert res.effective_strategy == BASELINE_TERMINAL_STRATEGY
        assert res.fallback_occurred is True
        assert res.delivered_profile_status == "COMPLIANT"

    def test_windows_hardened_fallback_to_O0_passes(self):
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        def eval_fail(cand):
            if cand != BASELINE_TERMINAL_STRATEGY:
                return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.ELIMINATED)
            return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.PRESERVED)

        res = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[],
            custom_evaluator=eval_fail,
            security_profile=SecurityProfile.WINDOWS_HARDENED,
            target_platform="windows",
        )
        assert res.decision in (GateDecision.ACCEPT_WITH_WARNINGS, GateDecision.FALLBACK)
        assert res.effective_strategy == BASELINE_TERMINAL_STRATEGY
        assert res.delivered_profile_status == "COMPLIANT"

    def test_linux_hardened_fails_closed_to_blocked_by_default(self):
        # On Linux Hardened, FORTIFY is mandatory. At -O0, FORTIFY is inactive.
        # Without allow_degraded_fallback, run must terminate in BLOCKED.
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        def eval_fail(cand):
            if cand != BASELINE_TERMINAL_STRATEGY:
                return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.ELIMINATED)
            return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.PRESERVED)

        res = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[],
            custom_evaluator=eval_fail,
            security_profile=SecurityProfile.LINUX_HARDENED,
            target_platform="linux",
            allow_degraded_fallback=False,  # default strict
        )
        assert res.decision == GateDecision.BLOCKED
        assert res.delivered_profile_status == "BLOCKED"
        assert any("BLOCKED" in n for n in res.notes)

    def test_linux_hardened_allows_degraded_fallback_with_explicit_override(self):
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        def eval_fail(cand):
            if cand != BASELINE_TERMINAL_STRATEGY:
                return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.ELIMINATED)
            return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.PRESERVED)

        res = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[],
            custom_evaluator=eval_fail,
            security_profile=SecurityProfile.LINUX_HARDENED,
            target_platform="linux",
            allow_degraded_fallback=True,  # explicit override
        )
        assert res.decision == GateDecision.FALLBACK_DEGRADED
        assert res.delivered_profile_status == "DEGRADED_PROFILE"
        assert res.effective_strategy == BASELINE_TERMINAL_STRATEGY
        assert any("DEGRADED" in n for n in res.notes)


# ===========================================================================
# Group E: Security Gate Integration & Agent Determinism
# ===========================================================================

class TestSecurityGateIntegration:
    """Tests that security decisions are deterministic and preserved in records."""

    def test_gate_result_serializes_stage12_fields(self):
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        def eval_ok(cand):
            return CandidateSecurity(strategy_name=cand, verdict=CandidateVerdict.PRESERVED)

        res = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O2",
            custom_evaluator=eval_ok,
            security_profile=SecurityProfile.STANDARD,
        )
        d = res.to_dict()
        assert "security_profile" in d
        assert "delivered_profile_status" in d
        assert "flag_validation" in d
        assert "ir_verification" in d
        assert d["security_profile"] == "STANDARD"
        assert d["delivered_profile_status"] == "COMPLIANT"

    def test_final_decision_agent_respects_gate_rejection(self):
        from moo.multiagent.agents import FinalDecisionAgent

        agent = FinalDecisionAgent()
        msg = agent.decide(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[("-O2", 0.9)],
            decision_trace={},
            run_id="run_test_12",
            step=1,
            run_security=True,
            toolchain_ok=True,
            security_profile="WINDOWS_HARDENED",
        )
        payload = msg.payload
        assert "security_gate_result" in payload
        assert "effective_strategy" in payload


# ===========================================================================
# Group F: Stage 12.1 Integration Corrections & Safety Guarantees
# ===========================================================================

class TestStage12_1_IntegrationCorrections:
    """Tests for Stage 12.1 integration corrections: propagation, consistency, FORTIFY probe, and escape heuristic."""

    def test_profile_propagation_through_multiagent_orchestrator(self):
        from moo.multiagent.orchestrator import MultiAgentOrchestrator
        from unittest.mock import MagicMock, patch

        orch = MultiAgentOrchestrator()
        # Mock decision_agent.decide to verify received profile parameter
        with patch.object(orch.decision_agent, "decide", wraps=orch.decision_agent.decide) as mock_decide:
            # We mock the source existence and toolchain
            with tempfile.NamedTemporaryFile(suffix=".c", delete=False) as tf:
                tf.write(b"int main() { return 0; }\n")
                src_path = tf.name

            try:
                record, _ = orch.run(
                    source_path=src_path,
                    selected_strategy="-O2",
                    run_benchmarks=False,
                    security_profile="WINDOWS_HARDENED",
                )
                assert mock_decide.called
                _, kwargs = mock_decide.call_args
                assert kwargs.get("security_profile") == "WINDOWS_HARDENED"
                assert record.security_gate is not None
                assert record.security_gate.get("security_profile") == "WINDOWS_HARDENED"
            finally:
                if os.path.isfile(src_path):
                    os.unlink(src_path)

    def test_invalid_profile_name_raises_value_error(self):
        from moo.multiagent.orchestrator import MultiAgentOrchestrator
        from moo.runrecord.orchestrator import PipelineOrchestrator

        orch = MultiAgentOrchestrator()
        with pytest.raises(ValueError, match="Invalid security_profile"):
            orch.run("any.c", security_profile="INVALID_SUPER_PROFILE")

        pipe_orch = PipelineOrchestrator()
        with pytest.raises(ValueError, match="Invalid security_profile"):
            pipe_orch.execute_pipeline("any.c", security_profile="NON_EXISTENT_PROFILE")

    def test_profile_propagation_through_pipeline_orchestrator(self):
        from moo.runrecord.orchestrator import PipelineOrchestrator
        from unittest.mock import patch

        pipe_orch = PipelineOrchestrator()
        with tempfile.NamedTemporaryFile(suffix=".c", delete=False) as tf:
            tf.write(b"int main() { return 0; }\n")
            src_path = tf.name

        try:
            with patch("moo.security.gate.OptimizationSecurityGate.run_gate") as mock_gate:
                from moo.security.gate import GateResult, GateDecision
                from moo.security.models import CandidateSecurity, CandidateVerdict
                mock_gate.return_value = GateResult(
                    decision=GateDecision.ACCEPT,
                    effective_strategy="-O2",
                    original_strategy="-O2",
                    candidate_security=CandidateSecurity(strategy_name="-O2", verdict=CandidateVerdict.PRESERVED),
                    security_profile="WINDOWS_HARDENED",
                )
                record = pipe_orch.execute_pipeline(
                    source_path=src_path,
                    selected_strategy="-O2",
                    run_benchmarks=False,
                    security_profile="WINDOWS_HARDENED",
                )
                assert mock_gate.called
                _, kwargs = mock_gate.call_args
                assert kwargs.get("security_profile") == "WINDOWS_HARDENED"
        finally:
            if os.path.isfile(src_path):
                os.unlink(src_path)

    def test_fortify_probe_integration_blocks_windows_msvc_ucrt(self):
        # On Windows host with MSVC UCRT, probe returns FLAG_ACCEPTED_BUT_INACTIVE.
        # This MUST produce NOT_SUPPORTED and PROFILE_VIOLATION for mandatory FORTIFY (e.g. LINUX_HARDENED).
        summary = validate_compilation_flags(
            cmd=["clang", "-O2", "-fstack-protector-strong", "-D_FORTIFY_SOURCE=2"],
            profile=SecurityProfile.LINUX_HARDENED,
            compiler_returncode=0,
            target_platform="windows",
            ir_attributes_found=["sspstrong"],
            strategy_name="-O2",
        )
        assert summary.verdict == CandidateProfileVerdict.PROFILE_VIOLATION
        assert not summary.is_eligible_for_optimization()
        fortify_res = [r for r in summary.flag_results if r.protection_name == "FORTIFY_SOURCE"][0]
        assert fortify_res.verdict == FlagVerdict.NOT_SUPPORTED

    def test_fortify_probe_mock_states_determines_eligibility(self):
        # Test FORTIFY_CONFIRMED -> PASS
        ok_summary = validate_compilation_flags(
            cmd=["clang", "-O2", "-fstack-protector-strong", "-D_FORTIFY_SOURCE=2"],
            profile=SecurityProfile.LINUX_HARDENED,
            compiler_returncode=0,
            target_platform="linux",
            ir_attributes_found=["sspstrong"],
            strategy_name="-O2",
            fortify_probe_status=FortifyProbeStatus.FORTIFY_CONFIRMED,
        )
        assert ok_summary.verdict == CandidateProfileVerdict.COMPLIANT
        assert ok_summary.is_eligible_for_optimization()

        # Test COMPILER_ERROR -> NOT_SUPPORTED & VIOLATION
        err_summary = validate_compilation_flags(
            cmd=["clang", "-O2", "-fstack-protector-strong", "-D_FORTIFY_SOURCE=2"],
            profile=SecurityProfile.LINUX_HARDENED,
            compiler_returncode=0,
            target_platform="linux",
            ir_attributes_found=["sspstrong"],
            strategy_name="-O2",
            fortify_probe_status=FortifyProbeStatus.COMPILER_ERROR,
        )
        assert err_summary.verdict == CandidateProfileVerdict.PROFILE_VIOLATION
        assert not err_summary.is_eligible_for_optimization()

        # Test PROBE_INCONCLUSIVE -> INCONCLUSIVE & VIOLATION (without degraded override)
        inc_summary = validate_compilation_flags(
            cmd=["clang", "-O2", "-fstack-protector-strong", "-D_FORTIFY_SOURCE=2"],
            profile=SecurityProfile.LINUX_HARDENED,
            compiler_returncode=0,
            target_platform="linux",
            ir_attributes_found=["sspstrong"],
            strategy_name="-O2",
            fortify_probe_status=FortifyProbeStatus.PROBE_INCONCLUSIVE,
        )
        assert inc_summary.verdict == CandidateProfileVerdict.PROFILE_VIOLATION
        assert not inc_summary.is_eligible_for_optimization()

    def test_unrelated_scalar_alloca_does_not_trigger_false_violation(self):
        # Function has a scalar int alloca AND calls a function passing an unrelated global ptr.
        # The scalar alloca variable %x is NOT passed to the call.
        # It must NOT be flagged as an escaped vulnerable candidate!
        ir_content = """
define dso_local i32 @fn_scalar_math(i32 %a) #0 {
  %x = alloca i32, align 4
  store i32 %a, ptr %x, align 4
  call void @sink(ptr @global_buf)
  ret i32 %a
}

declare void @sink(ptr)
@global_buf = external global [16 x i8]

attributes #0 = { uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        fn = res.functions["fn_scalar_math"]
        assert fn.has_stack_array_alloca is False
        assert fn.has_escaped_alloca is False
        assert fn.is_vulnerable_candidate is False
        # Since it is not vulnerable, omission of sspstrong in a leaf function with coverage < 1.0
        # yields INCONCLUSIVE rather than PROFILE_VIOLATION
        assert res.verdict == IRVerificationVerdict.INCONCLUSIVE

    def test_actual_local_array_alloca_passed_to_call_detected_as_escaped(self):
        ir_content = """
define dso_local void @fn_escaped(ptr %src) #0 {
  %buf = alloca [16 x i8], align 1
  call void @sink(ptr %buf)
  ret void
}

declare void @sink(ptr)
attributes #0 = { sspstrong uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        fn = res.functions["fn_escaped"]
        assert fn.has_escaped_alloca is True
        assert fn.is_vulnerable_candidate is True
        assert res.verdict == IRVerificationVerdict.PASS

    def test_pointer_passed_through_gep_detected_as_escaped(self):
        ir_content = """
define dso_local void @fn_gep_escaped(ptr %src) #0 {
  %buf = alloca [16 x i8], align 1
  %arraydecay = getelementptr inbounds [16 x i8], ptr %buf, i64 0, i64 0
  call void @sink(ptr %arraydecay)
  ret void
}

declare void @sink(ptr)
attributes #0 = { sspstrong uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        fn = res.functions["fn_gep_escaped"]
        assert fn.has_escaped_alloca is True
        assert fn.is_vulnerable_candidate is True
        assert res.verdict == IRVerificationVerdict.PASS

    def test_unsupported_escape_pattern_store_to_global_records_limitation(self):
        ir_content = """
define dso_local void @fn_store_escape(ptr %src) #0 {
  %buf = alloca [16 x i8], align 1
  store ptr %buf, ptr @global_ptr, align 8
  ret void
}

@global_ptr = external global ptr
attributes #0 = { sspstrong uwtable }
"""
        res = verify_module_stack_protector(ir_content, target_attribute="sspstrong", is_path=False)
        # Verify that limitation is explicitly documented in report
        assert any("interprocedural alias" in lim or "store-to-memory" in lim for lim in res.limitations)


# ===========================================================================
# Group F: Stage 12.2 Terminal Baseline Exception Handling
# ===========================================================================

class TestStage12_2_TerminalBaselineExceptionHandling:
    """Regression tests for Stage 12.2 terminal baseline exception handling."""

    def test_custom_evaluator_exception_on_baseline_fails_closed_to_blocked(self):
        """
        Stage 12.2: Ensure that an unhandled exception in an optional custom_evaluator
        during terminal -O0 baseline fallback does not crash the gate and fails closed
        to GateDecision.BLOCKED.
        """
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        def mock_raising(strat: str) -> CandidateSecurity:
            raise RuntimeError("Corrupted LLVM IR stream during baseline evaluation")

        result = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[("-O2", 0.85)],
            custom_evaluator=mock_raising,
            security_profile=SecurityProfile.STANDARD,
        )

        assert result.decision == GateDecision.BLOCKED
        assert result.delivered_profile_status == "BLOCKED"
        assert result.unverified is True
        assert result.effective_strategy == BASELINE_TERMINAL_STRATEGY
        assert result.candidate_security is not None
        assert result.candidate_security.verdict == CandidateVerdict.ERROR
        assert any("Corrupted LLVM IR stream" in w for w in result.candidate_security.warnings)
        assert any(e.attack_type == AttackType.GUARD_ERROR and e.blocked is True for e in result.security_events)
        assert any("BLOCKED: Baseline security evaluation raised an exception" in n for n in result.notes)

    def test_baseline_exception_cannot_authorize_unverified_candidate(self):
        """
        Stage 12.2: Verify that an exception during baseline evaluation prevents
        the candidate from being marked COMPLIANT or ACCEPTED.
        """
        gate = OptimizationSecurityGate(clang_path=CLANG_PATH, opt_path=OPT_PATH)

        def mock_evaluator(strat: str) -> CandidateSecurity:
            if strat == "-O3":
                return CandidateSecurity(strategy_name="-O3", verdict=CandidateVerdict.ELIMINATED)
            raise ValueError("Unexpected error evaluating baseline")

        result = gate.run_gate(
            source_path="mock.c",
            selected_strategy="-O3",
            q_rank=[],
            custom_evaluator=mock_evaluator,
            security_profile=SecurityProfile.WINDOWS_HARDENED,
            target_platform="windows",
        )

        assert result.decision == GateDecision.BLOCKED
        assert result.delivered_profile_status == "BLOCKED"
        assert result.unverified is True
        assert result.fallback_occurred is False
        assert any(e.attack_type == AttackType.GUARD_ERROR for e in result.security_events)

