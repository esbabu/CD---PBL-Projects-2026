"""
moo.tests.test_phase2a_isolation_buildconfig — Verification Suite for Phase 2A.

Covers:
1. Temporary file isolation (LIMIT-ISO-06)
2. Concurrent CompilerEnv execution without file collisions
3. Cleanup safety (ensuring one instance cannot delete another's artifacts)
4. Valid and invalid compiler configuration (C standards, defines, libraries)
5. Path traversal rejection in include_dirs and library_dirs
6. Safe handling of missing include paths
7. Compilation with safe BuildConfig flags
8. Backward compatibility when build_config is None
"""

import os
import sys
import tempfile
import threading
import subprocess
import pytest
import numpy as np

# Ensure Python Scripts dir is in sys.path
_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from ml_optimizer import CompilerEnv, CLANG_PATH
from moo.build_config import BuildConfig, ALLOWED_C_STANDARDS


# Sample valid C program
SAMPLE_C_CODE = """
#include <stdio.h>
#ifndef NI
#define NI 8
#endif

int main(void) {
    int sum = 0;
    for (int i = 0; i < NI; i++) {
        sum += i;
    }
    printf("sum=%d\\n", sum);
    return 0;
}
"""


def test_temp_isolation_unique_workdir():
    """Verify that each CompilerEnv instance receives a distinct, isolated working directory."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "test1.c")
        with open(src, "w") as f:
            f.write(SAMPLE_C_CODE)

        env1 = CompilerEnv(src)
        env2 = CompilerEnv(src)

        assert env1.workdir != env2.workdir, "CompilerEnv instances must have distinct workdirs"
        assert os.path.isdir(env1.workdir), "env1 workdir must exist"
        assert os.path.isdir(env2.workdir), "env2 workdir must exist"
        assert env1.ir_path != env2.ir_path, "ir_path must be isolated per instance"
        assert not os.path.isabs("temp_unopt.ll") or not os.path.exists("temp_unopt.ll")

        # Cleanup
        env1.cleanup()
        env2.cleanup()
        assert not os.path.exists(env1.workdir)
        assert not os.path.exists(env2.workdir)


def test_temp_isolation_concurrent_runs():
    """Simulate concurrent optimization runs and verify intermediate artifacts do not collide."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "concurrent.c")
        with open(src, "w") as f:
            f.write(SAMPLE_C_CODE)

        results = {}
        errors = []

        def worker(idx):
            try:
                env = CompilerEnv(src)
                # Ensure files were generated in env's isolated workdir
                ir_exists = os.path.isfile(env.ir_path)
                feats = list(env.features)
                workdir = env.workdir
                env.cleanup()
                results[idx] = {
                    "ir_exists": ir_exists,
                    "feats": feats,
                    "workdir": workdir,
                }
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Concurrent workers encountered errors: {errors}"
        assert len(results) == 5, "All 5 concurrent workers must finish"

        # Verify all 5 workdirs were distinct
        workdirs = [results[i]["workdir"] for i in range(5)]
        assert len(set(workdirs)) == 5, "All concurrent workdirs must be strictly unique"
        for i in range(5):
            assert results[i]["ir_exists"] is True, f"Worker {i} should have generated IR"
            assert len(results[i]["feats"]) == 8, f"Worker {i} must extract 8 features"


def test_cleanup_safety_caller_provided_workdir():
    """Verify that when caller provides workdir, cleanup deletes artifacts without destroying workdir."""
    with tempfile.TemporaryDirectory() as caller_dir:
        src = os.path.join(caller_dir, "test2.c")
        with open(src, "w") as f:
            f.write(SAMPLE_C_CODE)

        other_file = os.path.join(caller_dir, "preserve_me.txt")
        with open(other_file, "w") as f:
            f.write("Important data")

        env = CompilerEnv(src, workdir=caller_dir)
        assert env.workdir == os.path.abspath(caller_dir)
        assert os.path.isfile(env.ir_path)

        env.cleanup()
        assert os.path.isdir(caller_dir), "Caller-provided workdir must NOT be deleted by cleanup"
        assert os.path.isfile(other_file), "Non-artifact caller files must be preserved"
        assert not os.path.exists(env.ir_path), "Instance IR file must be cleaned up"


def test_build_config_valid_standards():
    """Verify allowed C standards generate proper compiler flags."""
    for std in ["c99", "c11", "c17", "gnu11", "gnu17"]:
        cfg = BuildConfig(c_standard=std)
        errs = cfg.validate()
        assert len(errs) == 0, f"Standard {std} should be valid"
        flags = cfg.get_compiler_flags()
        assert flags == [f"-std={std}"]


def test_build_config_invalid_standards_rejected():
    """Verify invalid or dangerous C standards are rejected."""
    for bad_std in ["c++11", "-O3", "rm -rf", "c2000", "; echo hack"]:
        cfg = BuildConfig(c_standard=bad_std)
        errs = cfg.validate()
        assert len(errs) > 0, f"Bad standard {bad_std} must be rejected"


def test_build_config_defines_sanitization():
    """Verify preprocessor macro definitions are validated and formatted."""
    cfg = BuildConfig(
        defines={"NI": "64", "DEBUG": None, "VERSION": "2"}
    )
    errs = cfg.validate()
    assert len(errs) == 0, f"Valid defines should pass: {errs}"
    flags = cfg.get_compiler_flags()
    assert "-DNI=64" in flags
    assert "-DDEBUG" in flags
    assert "-DVERSION=2" in flags


def test_build_config_disallowed_macro_values():
    """Verify shell injection metacharacters in macro values are rejected."""
    bad_defines = {
        "HACK": "1; cat /etc/passwd",
        "INJECT": "test`id`",
        "PIPE": "val | sh",
        "NEWLINE": "foo\nbar",
    }
    for k, v in bad_defines.items():
        cfg = BuildConfig(defines={k: v})
        errs = cfg.validate()
        assert len(errs) > 0, f"Dangerous macro value {v!r} must be rejected"


def test_build_config_invalid_macro_names():
    """Verify non-identifier macro names are rejected."""
    bad_names = ["123NUM", "NI-VAL", "NI.VAL", "-DNI", "NI;HACK"]
    for bad in bad_names:
        cfg = BuildConfig(defines={bad: "1"})
        errs = cfg.validate()
        assert len(errs) > 0, f"Invalid macro name {bad!r} must be rejected"


def test_build_config_path_traversal_rejection():
    """Verify path traversal (..) in include_dirs is strictly rejected."""
    traversal_dirs = [
        "../outside",
        "../../etc",
        "foo/../../bar",
        "..\\windows\\system32",
    ]
    for d in traversal_dirs:
        cfg = BuildConfig(include_dirs=[d])
        errs = cfg.validate()
        assert any("Path traversal" in e for e in errs), f"Path traversal in {d!r} must be caught"


def test_build_config_missing_include_dir_rejection():
    """Verify non-existent include directory is safely rejected."""
    cfg = BuildConfig(include_dirs=["non_existent_subdir_xyz_123"])
    errs = cfg.validate()
    assert any("does not exist" in e for e in errs)


def test_build_config_libraries_validation():
    """Verify safe library names are accepted and injection attempts are rejected."""
    valid_cfg = BuildConfig(libraries=["m", "pthread", "ws2_32", "kernel32"])
    assert len(valid_cfg.validate()) == 0
    flags = valid_cfg.get_linker_flags()
    assert flags == ["-lm", "-lpthread", "-lws2_32", "-lkernel32"]

    # Injections
    bad_libs = ["-Wl,-plugin=foo.so", "/lib/hack.so", "m; rm -rf", "-O3"]
    for bad in bad_libs:
        bad_cfg = BuildConfig(libraries=[bad])
        errs = bad_cfg.validate()
        assert len(errs) > 0, f"Injected library {bad!r} must be rejected"


def test_compilation_with_build_config():
    """Verify Clang compiles with BuildConfig compiler flags and macro definitions."""
    if not CLANG_PATH or not os.path.isfile(CLANG_PATH):
        pytest.skip("clang.exe not available in test environment")

    code_with_macro = """
    #include <stdio.h>
    int main(void) {
        printf("CUSTOM_MACRO=%d\\n", CUSTOM_MACRO);
        return 0;
    }
    """
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "macro_test.c")
        with open(src, "w") as f:
            f.write(code_with_macro)

        cfg = BuildConfig(
            c_standard="c11",
            defines={"CUSTOM_MACRO": "99"},
        )
        exe = os.path.join(tmp_dir, "out.exe")
        cmd = [CLANG_PATH] + cfg.get_compiler_flags() + [src, "-o", exe]
        r = subprocess.run(cmd, capture_output=True, text=True)
        assert r.returncode == 0, f"Compilation failed: {r.stderr}"
        assert os.path.isfile(exe)

        run_r = subprocess.run([exe], capture_output=True, text=True, timeout=5)
        assert run_r.returncode == 0
        assert "CUSTOM_MACRO=99" in run_r.stdout


def test_backward_compatibility_none_config():
    """Verify that build_config=None maintains identical default behavior."""
    from moo.pipeline import evaluate_program
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "test_compat.c")
        with open(src, "w") as f:
            f.write(SAMPLE_C_CODE)

        res = evaluate_program(source_path=src, actions=["-O0"], warmup_runs=1, measure_runs=1)
        assert res.baseline is not None
        assert res.baseline.build_ok is True
        assert res.baseline.reference_exit_code == 0


def test_both_candidate_strategies_with_build_config():
    """Verify both _run_clang_flag_strategy and _run_opt_passes_strategy propagate BuildConfig."""
    if not CLANG_PATH or not os.path.isfile(CLANG_PATH):
        pytest.skip("clang.exe not available")

    from moo.strategy_diagnostic import (
        _run_clang_flag_strategy,
        _run_opt_passes_strategy,
        _build_executable,
        _generate_baseline,
        OPT_PATH,
    )

    code_requiring_macro = """
    #ifndef REQUIRED_MACRO
    #error "REQUIRED_MACRO is not defined!"
    #endif
    #include <stdio.h>
    int main(void) {
        printf("VAL=%d\\n", REQUIRED_MACRO);
        return 0;
    }
    """
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "require_macro.c")
        with open(src, "w") as f:
            f.write(code_requiring_macro)

        cfg = BuildConfig(defines={"REQUIRED_MACRO": "42"})

        # Without BuildConfig: both candidate strategies MUST FAIL
        ir1_fail, res1_fail, _ = _run_clang_flag_strategy("-O1", src, tmp_dir, CLANG_PATH, build_config=None)
        assert ir1_fail is None
        assert res1_fail.returncode != 0

        # With BuildConfig: _run_clang_flag_strategy MUST SUCCEED
        dir_clang = os.path.join(tmp_dir, "clang_strat")
        os.makedirs(dir_clang, exist_ok=True)
        ir1_ok, res1_ok, cmd1 = _run_clang_flag_strategy("-O1", src, dir_clang, CLANG_PATH, build_config=cfg)
        assert ir1_ok is not None and os.path.isfile(ir1_ok)
        assert res1_ok.returncode == 0
        assert "-DREQUIRED_MACRO=42" in cmd1

        # With BuildConfig: _run_opt_passes_strategy MUST SUCCEED (if opt available)
        if OPT_PATH and os.path.isfile(OPT_PATH):
            dir_opt = os.path.join(tmp_dir, "opt_strat")
            os.makedirs(dir_opt, exist_ok=True)
            ir2_ok, results2, cmds2 = _run_opt_passes_strategy("mem2reg", src, dir_opt, CLANG_PATH, OPT_PATH, build_config=cfg)
            assert ir2_ok is not None and os.path.isfile(ir2_ok)
            assert all(r.returncode == 0 for r in results2)
            assert "-DREQUIRED_MACRO=42" in cmds2[0]

        # Test _build_executable with BuildConfig
        exe_path, exe_res, exe_cmd = _build_executable(ir1_ok, dir_clang, CLANG_PATH, opt_flag="-O1", build_config=cfg)
        assert exe_path is not None and os.path.isfile(exe_path)
        assert exe_res.returncode == 0

        # Test _generate_baseline with BuildConfig
        base_dir = os.path.join(tmp_dir, "baseline")
        os.makedirs(base_dir, exist_ok=True)
        base_info = _generate_baseline(src, base_dir, CLANG_PATH, build_config=cfg)
        assert base_info.ir_ok is True
        assert base_info.exe_ok is True
        assert base_info.run_ok is True
        assert "VAL=42" in base_info.run_stdout


def test_compiler_env_step_with_build_config():
    """Verify CompilerEnv.step applies BuildConfig for both clang_flag and opt_passes actions."""
    if not CLANG_PATH or not os.path.isfile(CLANG_PATH):
        pytest.skip("clang.exe not available")

    code_requiring_macro = """
    #ifndef ENV_STEP_MACRO
    #error "ENV_STEP_MACRO is not defined!"
    #endif
    #include <stdio.h>
    int main(void) {
        printf("STEP=%d\\n", ENV_STEP_MACRO);
        return 0;
    }
    """
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "env_step_test.c")
        with open(src, "w") as f:
            f.write(code_requiring_macro)

        cfg = BuildConfig(defines={"ENV_STEP_MACRO": "100"})
        env = CompilerEnv(src, build_config=cfg)
        assert env.features is not None
        assert len(env.features) == 8

        # Test clang_flag strategy step: action 0 is -O0, action 1 is -O1
        res_step_clang = env.step(1)
        assert os.path.isfile(env.opt_ir)
        assert os.path.isfile(env.opt_exe)

        # Test opt_passes strategy step: action 4 is mem2reg
        res_step_opt = env.step(4)
        assert os.path.isfile(env.opt_ir)
        assert os.path.isfile(env.opt_exe)

        env.cleanup()


def test_security_gate_candidate_emission_with_build_config():
    """Verify Security Gate emission functions propagate BuildConfig correctly."""
    if not CLANG_PATH or not os.path.isfile(CLANG_PATH):
        pytest.skip("clang.exe not available")

    from moo.security.ir_artifacts import emit_baseline_ir, emit_candidate_ir

    code_requiring_macro = """
    #ifndef GATE_TEST_MACRO
    #error "GATE_TEST_MACRO is not defined!"
    #endif
    int main(void) {
        return GATE_TEST_MACRO;
    }
    """
    with tempfile.TemporaryDirectory() as tmp_dir:
        src = os.path.join(tmp_dir, "gate_test.c")
        with open(src, "w") as f:
            f.write(code_requiring_macro)

        cfg = BuildConfig(defines={"GATE_TEST_MACRO": "7"})

        # Baseline emission
        base_ir, err_base = emit_baseline_ir(src, tmp_dir, build_config=cfg)
        assert base_ir is not None and os.path.isfile(base_ir)
        assert err_base is None

        # Candidate emission clang_flag
        cand1_ir, err1 = emit_candidate_ir("-O2", src, tmp_dir, build_config=cfg)
        assert cand1_ir is not None and os.path.isfile(cand1_ir)
        assert err1 is None

        # Candidate emission opt_passes
        cand2_ir, err2 = emit_candidate_ir("mem2reg", src, tmp_dir, build_config=cfg)
        assert cand2_ir is not None and os.path.isfile(cand2_ir)
        assert err2 is None

