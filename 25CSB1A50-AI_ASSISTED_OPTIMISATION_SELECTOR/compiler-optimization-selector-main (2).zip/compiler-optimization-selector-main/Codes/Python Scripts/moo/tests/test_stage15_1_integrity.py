"""
moo.tests.test_stage15_1_integrity — Stage 15.1 Integrity Hardening Tests.

Verifies:
1. Unified scaler byte-buffer loading (single read, hash verification, in-memory deserialization, no TOCTOU).
2. Scaler rejection on modified content, missing file, and invalid JSON.
3. Production inference uses the unified scaler loading path.
4. Training alpha and lambda validation (rejects zero, negative, NaN, inf, invalid types).
5. Training CLI argument validator rejects non-positive/non-finite inputs cleanly.
"""

from __future__ import annotations

import os
import sys
import json
import math
import tempfile
import hashlib
import unittest
import argparse
from unittest.mock import MagicMock, patch

_current_dir = os.path.dirname(os.path.abspath(__file__))
_scripts_dir = os.path.dirname(os.path.dirname(_current_dir))
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

from moo.bandit.config import (
    LinUCBDeploymentConfig,
    load_linucb_deployment_config,
    find_models_dir,
    verify_linucb_scaler_integrity,
    verify_and_load_linucb_scaler,
    verify_linucb_checkpoint_integrity,
)
from moo.bandit.features import LinUCBFeatureScaler, CANONICAL_8_FEATURE_NAMES
from moo.bandit.train_linucb import train_linucb_on_corpus, positive_finite_float
from optimization_selector import select_with_provenance


class TestStage151Integrity(unittest.TestCase):
    """Test suite for Stage 15.1 Integrity Hardening."""

    def setUp(self):
        self.models_dir = find_models_dir()
        self.scaler_path = os.path.join(self.models_dir, "linucb_feature_scaler.json")
        self.config_path = os.path.join(self.models_dir, "linucb_deployment_config.json")
        self.deploy_cfg = load_linucb_deployment_config(self.config_path)
        self.raw_feats = [47.0, 470.0, 47.0, 224.0, 16.0, 4.0, 0.0, 20.0]

        # Locate sample C file
        p = os.path.abspath(_scripts_dir)
        self.c_file = os.path.join(os.path.dirname(p), "Codes", "test_cases", "gemm.c")
        if not os.path.exists(self.c_file):
            for root, _, files in os.walk(os.path.dirname(p)):
                if "gemm.c" in files:
                    self.c_file = os.path.join(root, "gemm.c")
                    break

    # =========================================================================
    # 1. Scaler Integrity & Unified Byte-Buffer Loading Tests
    # =========================================================================

    def test_unified_scaler_loading_success(self):
        """Scaler loads and transforms correctly using verify_and_load_linucb_scaler."""
        scaler = verify_and_load_linucb_scaler(
            self.scaler_path, self.deploy_cfg.expected_scaler_sha256
        )
        self.assertIsInstance(scaler, LinUCBFeatureScaler)
        self.assertTrue(scaler.fitted)
        self.assertEqual(len(scaler.means), 8)
        self.assertEqual(len(scaler.stds), 8)

        # Transformation produces exact 9-dim context vector with bias = 1.0
        ctx = scaler.transform(self.raw_feats)
        self.assertEqual(ctx.shape, (9,))
        self.assertEqual(ctx[-1], 1.0)

    def test_scaler_file_read_exactly_once(self):
        """Verify that verify_and_load_linucb_scaler reads the file exactly once."""
        open_count = 0
        real_open = open

        def counting_open(*args, **kwargs):
            nonlocal open_count
            if args and args[0] == self.scaler_path:
                open_count += 1
            return real_open(*args, **kwargs)

        with patch("builtins.open", side_effect=counting_open):
            scaler = verify_and_load_linucb_scaler(
                self.scaler_path, self.deploy_cfg.expected_scaler_sha256
            )
            self.assertIsNotNone(scaler)

        # Must be opened exactly once in binary mode (no second load from disk)
        self.assertEqual(open_count, 1)

    def test_scaler_modified_content_rejected(self):
        """Modified scaler content fails SHA-256 integrity verification."""
        with tempfile.NamedTemporaryFile("wb", delete=False, suffix=".json") as tf:
            tf.write(b'{"tampered": true}')
            tmp_path = tf.name

        try:
            with self.assertRaises(RuntimeError) as ctx:
                verify_and_load_linucb_scaler(
                    tmp_path, self.deploy_cfg.expected_scaler_sha256
                )
            self.assertIn("scaler integrity verification failed", str(ctx.exception))
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def test_scaler_missing_file_rejected(self):
        """Missing scaler file raises FileNotFoundError without path leakage."""
        nonexistent = os.path.join(tempfile.gettempdir(), "nonexistent_scaler_xyz.json")
        with self.assertRaises(FileNotFoundError) as ctx:
            verify_and_load_linucb_scaler(
                nonexistent, self.deploy_cfg.expected_scaler_sha256
            )
        err = str(ctx.exception)
        self.assertIn("nonexistent_scaler_xyz.json", err)
        self.assertIn("not found", err)

    def test_scaler_invalid_json_rejected(self):
        """Malformed JSON with matching artificial hash raises ValueError."""
        corrupted_content = b"{ this is corrupt json :"
        h = hashlib.sha256(corrupted_content).hexdigest().upper()

        with tempfile.NamedTemporaryFile("wb", delete=False, suffix=".json") as tf:
            tf.write(corrupted_content)
            tmp_path = tf.name

        try:
            with self.assertRaises(ValueError) as ctx:
                verify_and_load_linucb_scaler(tmp_path, h)
            self.assertIn("Failed to parse LinUCB feature scaler JSON", str(ctx.exception))
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def test_scaler_missing_fields_rejected(self):
        """JSON missing means or stds raises ValueError."""
        incomplete_json = json.dumps({"means": [1.0] * 8}).encode("utf-8")
        h = hashlib.sha256(incomplete_json).hexdigest().upper()

        with tempfile.NamedTemporaryFile("wb", delete=False, suffix=".json") as tf:
            tf.write(incomplete_json)
            tmp_path = tf.name

        try:
            with self.assertRaises(ValueError) as ctx:
                verify_and_load_linucb_scaler(tmp_path, h)
            self.assertIn("missing required 'means' or 'stds' fields", str(ctx.exception))
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def test_production_inference_uses_unified_scaler_path(self):
        """Verify that select_with_provenance calls verify_and_load_linucb_scaler."""
        with patch("moo.bandit.config.verify_and_load_linucb_scaler", wraps=verify_and_load_linucb_scaler) as mock_load:
            sel = select_with_provenance(
                self.c_file,
                features=self.raw_feats,
                model_family="linucb",
                allow_moo=False,
            )
            self.assertIsNotNone(sel)
            self.assertTrue(mock_load.called)
            self.assertEqual(sel.selection_metadata["selected_action"], "-O2")

    # =========================================================================
    # 2. Training Parameter & CLI Validation Tests
    # =========================================================================

    def test_training_parameter_validation_rejects_invalid_alpha(self):
        """train_linucb_on_corpus rejects zero, negative, NaN, and infinite alpha."""
        invalid_alphas = [0.0, -0.1, -1.0, float("nan"), float("inf"), float("-inf"), "1.0", None, False]
        for val in invalid_alphas:
            with self.assertRaises(ValueError) as ctx:
                train_linucb_on_corpus(alpha_train=val)
            self.assertIn("Invalid alpha_train", str(ctx.exception))

    def test_training_parameter_validation_rejects_invalid_lambda(self):
        """train_linucb_on_corpus rejects zero, negative, NaN, and infinite lambda."""
        invalid_lambdas = [0.0, -0.5, -10.0, float("nan"), float("inf"), float("-inf"), "1.0", None, False]
        for val in invalid_lambdas:
            with self.assertRaises(ValueError) as ctx:
                train_linucb_on_corpus(reg_lambda=val)
            self.assertIn("Invalid reg_lambda", str(ctx.exception))

    def test_training_cli_validator_accepts_positive_finite_float(self):
        """positive_finite_float accepts valid numbers > 0."""
        self.assertEqual(positive_finite_float("0.1"), 0.1)
        self.assertEqual(positive_finite_float("1.0"), 1.0)
        self.assertEqual(positive_finite_float("100.5"), 100.5)

    def test_training_cli_validator_rejects_invalid_strings(self):
        """positive_finite_float raises ArgumentTypeError on non-positive/non-finite inputs."""
        invalid_inputs = ["0", "0.0", "-0.1", "-5", "nan", "inf", "-inf", "abc", ""]
        for inp in invalid_inputs:
            with self.assertRaises(argparse.ArgumentTypeError) as ctx:
                positive_finite_float(inp)
            err = str(ctx.exception)
            self.assertTrue("positive finite number" in err or "not a valid numeric float" in err)


if __name__ == "__main__":
    unittest.main()
