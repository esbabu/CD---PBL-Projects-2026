"""
moo.bandit.config — Centralized Deployment Configuration & Integrity Verification for LinUCB.

Separates learned checkpoint state (A matrices, b vectors, counts) from deployment-time
hyperparameters (validated exploration parameter alpha, regularization lambda).
Strictly enforces fail-closed validation and verifies checkpoint/scaler integrity before inference.
"""

from __future__ import annotations

import os
import json
import hashlib
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any

logger = logging.getLogger("toacd.moo.bandit.config")

DEFAULT_DEPLOYMENT_CONFIG_NAME = "linucb_deployment_config.json"


@dataclass(frozen=True)
class LinUCBDeploymentConfig:
    """Deployment-time inference configuration for Disjoint LinUCB."""
    alpha: float
    reg_lambda: float
    schema_version: str
    model_family: str
    deployment_target: str
    expected_checkpoint_version: int
    expected_checkpoint_sha256: str
    expected_scaler_path: str
    expected_scaler_sha256: str
    config_path: str
    validation_provenance: Dict[str, Any]

    def validate(self) -> None:
        """Validate parameter ranges and strictly enforce fail-closed checks."""
        if not isinstance(self.alpha, (int, float)) or self.alpha <= 0.0 or self.alpha >= float("inf"):
            raise ValueError(f"Invalid LinUCB deployment alpha: {self.alpha}. Must be positive finite float.")
        if not isinstance(self.reg_lambda, (int, float)) or self.reg_lambda <= 0.0 or self.reg_lambda >= float("inf"):
            raise ValueError(f"Invalid LinUCB deployment reg_lambda: {self.reg_lambda}. Must be positive finite float.")
        if not isinstance(self.expected_checkpoint_version, int) or self.expected_checkpoint_version < 0:
            raise ValueError(f"Invalid expected_checkpoint_version: {self.expected_checkpoint_version}. Must be non-negative int.")
        if not isinstance(self.expected_checkpoint_sha256, str) or len(self.expected_checkpoint_sha256) != 64:
            raise ValueError(f"Invalid expected_checkpoint_sha256: must be 64-character hex string.")
        if not isinstance(self.expected_scaler_sha256, str) or len(self.expected_scaler_sha256) != 64:
            raise ValueError(f"Invalid expected_scaler_sha256: must be 64-character hex string.")


def find_models_dir() -> str:
    """Locate data/models directory reliably."""
    p = os.path.abspath(os.path.dirname(__file__))
    while p and os.path.dirname(p) != p:
        cand = os.path.join(p, "data", "models")
        if os.path.exists(cand):
            return cand
        p = os.path.dirname(p)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "models"))


def load_linucb_deployment_config(config_path: Optional[str] = None) -> LinUCBDeploymentConfig:
    """
    Load and validate the authorized LinUCB deployment inference configuration.

    STRICT FAIL-CLOSED POLICY:
    - Requires linucb_deployment_config.json.
    - Zero silent fallback to tuning reports or training defaults.
    - Fails explicitly with FileNotFoundError if missing.
    - Fails explicitly with ValueError if malformed, incomplete, or invalid.
    """
    models_dir = find_models_dir()
    effective_path = config_path or os.path.join(models_dir, DEFAULT_DEPLOYMENT_CONFIG_NAME)

    if not os.path.exists(effective_path):
        raise FileNotFoundError(
            f"LinUCB deployment configuration not found: '{os.path.basename(effective_path)}'. "
            "Production inference requires an authoritative deployment configuration."
        )

    try:
        with open(effective_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as exc:
        raise ValueError(
            f"Failed to read LinUCB deployment configuration from '{os.path.basename(effective_path)}': {exc}"
        ) from exc

    if not isinstance(data, dict):
        raise ValueError(
            f"LinUCB deployment configuration in '{os.path.basename(effective_path)}' must be a JSON object, got {type(data).__name__}"
        )

    # Required top-level fields — do not silently substitute defaults
    required_fields = [
        "schema_version",
        "model_family",
        "deployment_target",
        "inference_alpha",
        "inference_reg_lambda",
        "checkpoint_provenance",
        "scaler_provenance",
    ]
    for field in required_fields:
        if field not in data:
            raise ValueError(
                f"LinUCB deployment configuration '{os.path.basename(effective_path)}' missing required field: '{field}'"
            )

    chk_prov = data["checkpoint_provenance"]
    if not isinstance(chk_prov, dict) or "expected_version" not in chk_prov or "expected_sha256" not in chk_prov:
        raise ValueError(
            f"LinUCB deployment configuration '{os.path.basename(effective_path)}' invalid checkpoint_provenance: missing expected_version or expected_sha256"
        )

    scaler_prov = data["scaler_provenance"]
    if not isinstance(scaler_prov, dict) or "expected_scaler_path" not in scaler_prov or "expected_scaler_sha256" not in scaler_prov:
        raise ValueError(
            f"LinUCB deployment configuration '{os.path.basename(effective_path)}' invalid scaler_provenance: missing expected_scaler_path or expected_scaler_sha256"
        )

    cfg = LinUCBDeploymentConfig(
        alpha=float(data["inference_alpha"]),
        reg_lambda=float(data["inference_reg_lambda"]),
        schema_version=str(data["schema_version"]),
        model_family=str(data["model_family"]),
        deployment_target=str(data["deployment_target"]),
        expected_checkpoint_version=int(chk_prov["expected_version"]),
        expected_checkpoint_sha256=str(chk_prov["expected_sha256"]).strip().upper(),
        expected_scaler_path=str(scaler_prov["expected_scaler_path"]),
        expected_scaler_sha256=str(scaler_prov["expected_scaler_sha256"]).strip().upper(),
        config_path=effective_path,
        validation_provenance=data.get("validation_provenance", {}),
    )
    cfg.validate()
    return cfg


def verify_and_load_linucb_scaler(scaler_path: str, expected_sha256: str) -> Any:
    """
    Verify feature scaler file exists, hashes to expected_sha256, and deserializes
    directly from the exact verified bytes into a LinUCBFeatureScaler instance.
    Prevents TOCTOU gaps by reading the file exactly once into memory as bytes.
    Fails closed before inference without exposing sensitive host directory paths.
    """
    base_name = os.path.basename(scaler_path)
    if not os.path.exists(scaler_path):
        raise FileNotFoundError(
            f"LinUCB feature scaler '{base_name}' not found. Cannot proceed with inference."
        )

    try:
        with open(scaler_path, "rb") as f:
            raw_bytes = f.read()
    except Exception as exc:
        raise RuntimeError(
            f"Failed to read LinUCB feature scaler '{base_name}': {exc}"
        ) from exc

    actual_hash = hashlib.sha256(raw_bytes).hexdigest().upper()
    if actual_hash != expected_sha256.upper():
        raise RuntimeError(
            f"LinUCB feature scaler integrity verification failed for '{base_name}': "
            f"expected SHA-256 {expected_sha256[:16]}..., computed {actual_hash[:16]}..."
        )

    try:
        data = json.loads(raw_bytes.decode("utf-8"))
    except Exception as exc:
        raise ValueError(
            f"Failed to parse LinUCB feature scaler JSON from '{base_name}': {exc}"
        ) from exc

    from .features import LinUCBFeatureScaler
    return LinUCBFeatureScaler.from_dict(data)


def verify_linucb_scaler_integrity(scaler_path: str, expected_sha256: str) -> None:
    """
    Verify feature scaler file exists and its SHA-256 matches deployment configuration.
    Fails closed before inference without exposing full internal directory paths in error.
    """
    verify_and_load_linucb_scaler(scaler_path, expected_sha256)


def verify_linucb_checkpoint_integrity(
    active_model: Any,
    expected_version: int,
    expected_sha256: str,
) -> None:
    """
    Verify the actual active model checkpoint matches deployment configuration version and SHA-256.
    Fails closed before inference without exposing sensitive internal paths.
    """
    if active_model is None:
        raise RuntimeError("LinUCB active checkpoint model is None. Cannot proceed with inference.")

    if active_model.version != expected_version:
        raise RuntimeError(
            f"LinUCB checkpoint integrity verification failed: version mismatch "
            f"(expected version {expected_version}, active model version {active_model.version})"
        )

    actual_sha = active_model.compute_sha256().upper()
    if actual_sha != expected_sha256.upper():
        raise RuntimeError(
            f"LinUCB checkpoint integrity verification failed: SHA-256 mismatch "
            f"(expected {expected_sha256[:16]}..., computed {actual_sha[:16]}...)"
        )
