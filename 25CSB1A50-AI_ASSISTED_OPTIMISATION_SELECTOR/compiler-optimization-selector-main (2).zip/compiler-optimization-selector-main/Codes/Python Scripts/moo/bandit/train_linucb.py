"""
moo/bandit/train_linucb.py — Training runner for TOACD Stage 13.4 Phase 0.

Strictly trains LinUCB using ONLY eligible programs in corpus_60_train (train_manifest.json).
Never accesses or evaluates validation or held-out test splits.
"""

from __future__ import annotations

import os
import sys

# Ensure parent Python Scripts directory is on sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import json
import math
import argparse
import time
import subprocess
import tempfile
import numpy as np
from typing import Dict, List, Any, Optional

from ml_optimizer import ACTIONS, CLANG_PATH
from moo.measurement import measure_execution, measure_code_size
from moo.bandit.features import LinUCBFeatureScaler
from moo.bandit.model import DisjointLinUCB, NUM_ACTIONS
from moo.bandit.persistence import SQLiteEvaluationLedger
from moo.bandit.reward import compute_linucb_reward

OPT_PATH = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

def _find_data_dir() -> str:
    p = os.path.abspath(os.path.dirname(__file__))
    while p and os.path.dirname(p) != p:
        cand = os.path.join(p, "data")
        if os.path.exists(cand) and os.path.exists(os.path.join(cand, "manifests")):
            return cand
        p = os.path.dirname(p)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data"))

def compile_strategy(src_path: str, action: str, out_exe: str, work_dir: str) -> bool:
    """Compile a C source file under a given action flag or pass pipeline."""
    try:
        if action.startswith("-O"):
            cmd = [CLANG_PATH, action, src_path, "-o", out_exe]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return r.returncode == 0
        else:
            unopt_ll = os.path.join(work_dir, "unopt.ll")
            opt_ll = os.path.join(work_dir, "opt.ll")
            r1 = subprocess.run(
                [CLANG_PATH, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src_path, "-o", unopt_ll],
                capture_output=True, text=True, timeout=60
            )
            if r1.returncode != 0:
                return False
            r2 = subprocess.run(
                [OPT_PATH, f"-passes={action}", unopt_ll, "-S", "-o", opt_ll],
                capture_output=True, text=True, timeout=60
            )
            if r2.returncode != 0:
                return False
            r3 = subprocess.run(
                [CLANG_PATH, "-O2", opt_ll, "-o", out_exe],
                capture_output=True, text=True, timeout=60
            )
            return r3.returncode == 0
    except Exception:
        return False

def train_linucb_on_corpus(alpha_train: float = 1.0, reg_lambda: float = 1.0) -> Dict[str, Any]:
    import math
    if (
        not isinstance(alpha_train, (int, float))
        or isinstance(alpha_train, bool)
        or math.isnan(alpha_train)
        or math.isinf(alpha_train)
        or alpha_train <= 0.0
    ):
        raise ValueError(
            f"Invalid alpha_train: {alpha_train}. Must be a positive finite float (> 0)."
        )

    if (
        not isinstance(reg_lambda, (int, float))
        or isinstance(reg_lambda, bool)
        or math.isnan(reg_lambda)
        or math.isinf(reg_lambda)
        or reg_lambda <= 0.0
    ):
        raise ValueError(
            f"Invalid reg_lambda: {reg_lambda}. Must be a positive finite float (> 0)."
        )

    data_dir = _find_data_dir()
    manifest_path = os.path.join(data_dir, "manifests", "train_manifest.json")
    scaler_path = os.path.join(data_dir, "models", "linucb_feature_scaler.json")
    ledger_db = os.path.join(data_dir, "ledger", "evaluation_ledger.db")

    if not os.path.exists(manifest_path):
        raise FileNotFoundError(f"Train manifest not found: {manifest_path}")

    # 1. Load scaler
    scaler = LinUCBFeatureScaler()
    scaler.load(scaler_path)

    # 2. Connect to SQLite ledger
    ledger = SQLiteEvaluationLedger(ledger_db)
    active_model = ledger.get_active_model()
    # Training alpha is strictly decoupled from deployment configuration
    active_model.alpha = float(alpha_train)

    with open(manifest_path, "r", encoding="utf-8") as f:
        train_data = json.load(f)["programs"]

    records = []
    accepted_count = 0
    rejected_count = 0

    print(f"Starting LinUCB training on {len(train_data)} programs from corpus_60_train...")

    for idx, p in enumerate(train_data):
        prog_id = p["program_id"]
        rel_path = p["relative_path"]
        src_path = os.path.abspath(os.path.join(os.path.dirname(data_dir), rel_path))
        features = p["features"]
        calib = p["calibration"]
        expected_chk = calib.get("expected_checksum", "")

        # 1. Extract context vector
        ctx = scaler.transform(features)

        # 2. Query LinUCB model for action
        sel = active_model.select_action(ctx)
        a_idx = sel["selected_action_idx"]
        a_name = ACTIONS[a_idx]
        is_cold = sel.get("selection_method") == "COLD_START_PRIORITY"

        eval_tok = f"tok_train_{idx:03d}_{prog_id}_{a_idx}"

        # 3. Baseline stability check
        if calib.get("status") != "CALIBRATED_STABLE" or calib.get("baseline_cv_pct", 100.0) > 10.0:
            status = "REJECTED_UNRELIABLE_BASELINE_CV"
            rejected_count += 1
            records.append({
                "program_id": prog_id,
                "action_idx": a_idx,
                "action_name": a_name,
                "status": status,
                "reward": 0.0,
                "baseline_cv_pct": calib.get("baseline_cv_pct"),
                "is_cold_start": is_cold
            })
            continue

        # 4. Compile and evaluate candidate
        with tempfile.TemporaryDirectory(prefix=f"toacd_train_{prog_id}_") as tmp:
            cand_exe = os.path.join(tmp, f"cand_{a_idx}.exe")
            base_exe = os.path.join(tmp, "base_O0.exe")

            # Compile candidate
            if not compile_strategy(src_path, a_name, cand_exe, tmp):
                status = "REJECTED_BUILD_FAILURE"
                rejected_count += 1
                records.append({
                    "program_id": prog_id,
                    "action_idx": a_idx,
                    "action_name": a_name,
                    "status": status,
                    "reward": 0.0,
                    "is_cold_start": is_cold
                })
                continue

            # Compile reference baseline for size comparison
            if not compile_strategy(src_path, "-O0", base_exe, tmp):
                status = "REJECTED_BASELINE_BUILD_FAILURE"
                rejected_count += 1
                records.append({
                    "program_id": prog_id,
                    "action_idx": a_idx,
                    "action_name": a_name,
                    "status": status,
                    "reward": 0.0,
                    "is_cold_start": is_cold
                })
                continue

            # Measure code size
            base_size = measure_code_size(base_exe).primary_value
            cand_size = measure_code_size(cand_exe).primary_value

            # Measure candidate runtime (3 warmups, 5 timed runs)
            m_res = measure_execution(cand_exe, strategy=a_name, warmup_runs=3, measure_runs=5, timeout_s=30)

            # Verification checks
            if m_res.last_return_code != 0:
                status = "REJECTED_RUNTIME_CRASH"
                rejected_count += 1
                records.append({
                    "program_id": prog_id,
                    "action_idx": a_idx,
                    "action_name": a_name,
                    "status": status,
                    "reward": 0.0,
                    "is_cold_start": is_cold
                })
                continue

            # Check correctness digest
            if expected_chk and expected_chk not in m_res.last_stdout:
                status = "REJECTED_CORRECTNESS_DIGEST_MISMATCH"
                rejected_count += 1
                records.append({
                    "program_id": prog_id,
                    "action_idx": a_idx,
                    "action_name": a_name,
                    "status": status,
                    "reward": 0.0,
                    "is_cold_start": is_cold
                })
                continue

            # Check candidate CV
            cand_cv_pct = m_res.timing.cv * 100.0
            if cand_cv_pct > 10.0:
                status = "REJECTED_CANDIDATE_NOISY_CV"
                rejected_count += 1
                records.append({
                    "program_id": prog_id,
                    "action_idx": a_idx,
                    "action_name": a_name,
                    "status": status,
                    "reward": 0.0,
                    "candidate_cv_pct": round(cand_cv_pct, 2),
                    "is_cold_start": is_cold
                })
                continue

            # Compute reward
            t_base = calib["baseline_median_ms"] / 1000.0
            t_cand = m_res.timing.median_s
            reward = compute_linucb_reward(t_base, t_cand, float(base_size), float(cand_size))

            # Commit update via SQLite copy-and-swap
            success, reason, new_ver = ledger.record_update_transaction(
                token=eval_tok,
                program_id=prog_id,
                action_idx=a_idx,
                context=ctx,
                reward=reward,
                status="ELIGIBLE_STABLE"
            )
            if not success:
                print(f"Update transaction failed for {prog_id}: {reason}")
                status = f"REJECTED_TRANSACTION_FAILED: {reason}"
                rejected_count += 1
                records.append({
                    "program_id": prog_id,
                    "action_idx": a_idx,
                    "action_name": a_name,
                    "status": status,
                    "reward": 0.0,
                    "is_cold_start": is_cold
                })
                continue

            active_model = ledger.get_active_model()
            active_model.alpha = float(alpha_train)
            accepted_count += 1

            records.append({
                "program_id": prog_id,
                "action_idx": a_idx,
                "action_name": a_name,
                "status": "ACCEPTED",
                "reward": round(reward, 4),
                "speedup_vs_base": round(t_base / max(t_cand, 1e-6), 3),
                "cand_median_ms": round(t_cand * 1000.0, 2),
                "cand_cv_pct": round(cand_cv_pct, 2),
                "size_reduction_pct": round((base_size - cand_size) / max(base_size, 1) * 100.0, 2),
                "is_cold_start": is_cold,
                "model_version": new_ver
            })

            print(f"[{idx+1}/60] {prog_id}: Action {a_idx} ({a_name}) -> Reward={reward:.4f} (Accepted, v{new_ver})")

    # Retrieve final checkpoint info
    conn = ledger._get_connection()
    c = conn.cursor()
    c.execute("SELECT version, sha256 FROM linucb_checkpoint ORDER BY version DESC LIMIT 1;")
    final_ver, final_sha = c.fetchone()
    conn.close()

    report = {
        "training_programs_total": len(train_data),
        "accepted_updates": accepted_count,
        "rejected_updates": rejected_count,
        "action_counts": active_model.counts,
        "final_checkpoint_version": final_ver,
        "final_checkpoint_sha256": final_sha,
        "records": records
    }

    report_path = os.path.join(data_dir, "models", "linucb_training_report.json")
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print("\nTraining completed successfully!")
    print(f"Accepted: {accepted_count}, Rejected: {rejected_count}")
    print(f"Final Action Counts: {active_model.counts}")
    print(f"Final Checkpoint: Version {final_ver}, SHA256: {final_sha}")

    return report

def positive_finite_float(val: str) -> float:
    """Validator for CLI arguments requiring positive finite float (> 0)."""
    import math
    try:
        f = float(val)
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError(f"'{val}' is not a valid numeric float")
    if math.isnan(f) or math.isinf(f) or f <= 0.0:
        raise argparse.ArgumentTypeError(
            f"Value must be a positive finite number (> 0), got: '{val}'"
        )
    return f

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train LinUCB on corpus_60_train")
    parser.add_argument(
        "--alpha",
        type=positive_finite_float,
        default=1.0,
        help="Exploration parameter during training (must be positive finite float > 0, default: 1.0)",
    )
    parser.add_argument(
        "--lambda",
        dest="reg_lambda",
        type=positive_finite_float,
        default=1.0,
        help="L2 regularization lambda (must be positive finite float > 0, default: 1.0)",
    )
    args = parser.parse_args()
    train_linucb_on_corpus(alpha_train=args.alpha, reg_lambda=args.reg_lambda)
