"""
moo/bandit/reward.py
Multi-Objective Reward Function & Strict Eligibility Verification for LinUCB.

Mathematical Formulation:
  rho_time = T_candidate / T_baseline
  delta_time = 1.0 - rho_time

  rho_size = S_candidate / S_baseline
  delta_size = 1.0 - rho_size

  reward = 0.85 * clamp(delta_time, -1.0, 1.0)
         + 0.15 * clamp(delta_size, -0.5, 0.5)

Hard Eligibility Constraints (Any failure forbids model update):
- Security Gate rejection
- Correctness mismatch (checksum or exit code)
- Build or link failure
- Crash or timeout
- Invalid baseline measurements (<= 0 or non-finite)
- Invalid candidate measurements (<= 0 or non-finite)
- Benchmark measurement variance CV > 10.0%
"""

from __future__ import annotations

import math
from typing import Tuple, Dict, Any, Optional

def compute_linucb_reward(
    t_baseline: float,
    t_candidate: float,
    s_baseline: float,
    s_candidate: float
) -> float:
    """
    Computes the multi-objective reward for a valid, verified execution.
    Requires validated positive finite inputs.
    """
    rho_time = t_candidate / t_baseline
    delta_time = 1.0 - rho_time
    clamped_delta_time = max(-1.0, min(1.0, delta_time))

    rho_size = s_candidate / s_baseline
    delta_size = 1.0 - rho_size
    clamped_delta_size = max(-0.5, min(0.5, delta_size))

    reward = 0.85 * clamped_delta_time + 0.15 * clamped_delta_size
    return float(reward)

def evaluate_eligibility_and_reward(
    t_baseline: float,
    t_candidate: float,
    s_baseline: float,
    s_candidate: float,
    cv_pct: float,
    security_passed: bool,
    correctness_passed: bool,
    build_success: bool = True,
    timeout: bool = False
) -> Tuple[float, bool, str]:
    """
    Evaluates hard eligibility constraints and calculates LinUCB reward.
    Returns:
      (reward: float, is_eligible: bool, reason: str)

    If is_eligible is False, reward is 0.0 and no bandit update is permitted.
    """
    # 1. Security Gate authority check
    if not security_passed:
        return 0.0, False, "SECURITY_GATE_REJECTED"

    # 2. Correctness verification (functional equivalence)
    if not correctness_passed:
        return 0.0, False, "CORRECTNESS_MISMATCH"

    # 3. Build & execution health
    if not build_success:
        return 0.0, False, "BUILD_OR_LINK_FAILURE"

    if timeout:
        return 0.0, False, "EXECUTION_TIMEOUT"

    # 4. Numerical validation of baseline measurements
    if not (isinstance(t_baseline, (int, float)) and math.isfinite(t_baseline) and t_baseline > 0.0):
        return 0.0, False, "INVALID_BASELINE_TIME"

    if not (isinstance(s_baseline, (int, float)) and math.isfinite(s_baseline) and s_baseline > 0.0):
        return 0.0, False, "INVALID_BASELINE_SIZE"

    # 5. Numerical validation of candidate measurements
    if not (isinstance(t_candidate, (int, float)) and math.isfinite(t_candidate) and t_candidate > 0.0):
        return 0.0, False, "INVALID_CANDIDATE_TIME"

    if not (isinstance(s_candidate, (int, float)) and math.isfinite(s_candidate) and s_candidate > 0.0):
        return 0.0, False, "INVALID_CANDIDATE_SIZE"

    # 6. Benchmark reliability contract: CV <= 10.0%
    if not (isinstance(cv_pct, (int, float)) and math.isfinite(cv_pct) and cv_pct >= 0.0):
        return 0.0, False, "INVALID_CV_MEASUREMENT"

    if cv_pct > 10.0:
        return 0.0, False, f"RELIABILITY_THRESHOLD_EXCEEDED (CV = {cv_pct:.2f}% > 10.0%)"

    # All eligibility constraints passed -> compute reward
    reward = compute_linucb_reward(t_baseline, t_candidate, s_baseline, s_candidate)
    return reward, True, "ELIGIBLE_STABLE"
