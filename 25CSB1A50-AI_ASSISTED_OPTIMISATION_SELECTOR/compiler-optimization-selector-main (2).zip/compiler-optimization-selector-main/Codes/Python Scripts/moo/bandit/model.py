"""
moo/bandit/model.py
Disjoint Linear Upper Confidence Bound (LinUCB) Implementation for Compiler Optimization Selection.

Mathematical Architecture:
- Disjoint models for 9 optimization actions
- Context dimension d = 9 (8 canonical IR features + 1.0 bias)
- Covariance matrix A_a in R^{9x9}, initialized to lambda * I_9 (lambda = 1.0)
- Reward vector b_a in R^9, initialized to 0_9
- Ridge regression coefficients: theta_a = A_a^{-1} b_a
- Upper Confidence Bound: UCB_a(x) = theta_a^T x + alpha * sqrt(x^T A_a^{-1} x)
- Cold-start coverage policy: Deterministic priority [3, 2, 1, 7, 6, 8, 4, 5, 0] with N_min = 1
- Numerical validation: Cholesky positive-definiteness on all A_a matrices
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
from typing import Dict, List, Tuple, Any, Optional, Set
import numpy as np

# Canonical 9 Optimization Actions in TOACD
ACTIONS = [
    "-O0",                                                 # Action 0
    "-O1",                                                 # Action 1
    "-O2",                                                 # Action 2
    "-O3",                                                 # Action 3
    "mem2reg,instcombine",                                 # Action 4
    "mem2reg,simplifycfg",                                 # Action 5
    "mem2reg,instcombine,simplifycfg,dce",                 # Action 6
    "mem2reg,instcombine,simplifycfg,gvn,loop-unroll",      # Action 7
    "mem2reg,instcombine,simplifycfg,dce,gvn,loop-unroll"   # Action 8
]

NUM_ACTIONS = len(ACTIONS)
DIMENSION_D = 9

# Approved cold-start priority order
COLD_START_PRIORITY = [3, 2, 1, 7, 6, 8, 4, 5, 0]
N_MIN = 1

class DisjointLinUCB:
    def __init__(
        self,
        alpha: float = 1.0,
        reg_lambda: float = 1.0,
        version: int = 0
    ):
        self.alpha = float(alpha)
        self.reg_lambda = float(reg_lambda)
        self.version = int(version)

        # Per-action statistics
        self.A: List[np.ndarray] = [
            np.eye(DIMENSION_D, dtype=np.float64) * self.reg_lambda
            for _ in range(NUM_ACTIONS)
        ]
        self.b: List[np.ndarray] = [
            np.zeros(DIMENSION_D, dtype=np.float64)
            for _ in range(NUM_ACTIONS)
        ]
        self.counts: List[int] = [0] * NUM_ACTIONS
        self.thetas: List[np.ndarray] = [
            np.zeros(DIMENSION_D, dtype=np.float64)
            for _ in range(NUM_ACTIONS)
        ]

    def clone(self) -> DisjointLinUCB:
        """Create a deep copy of the model state for isolated copy-and-swap transactions."""
        cloned = DisjointLinUCB(alpha=self.alpha, reg_lambda=self.reg_lambda, version=self.version)
        cloned.A = [a.copy() for a in self.A]
        cloned.b = [b.copy() for b in self.b]
        cloned.counts = list(self.counts)
        cloned.thetas = [t.copy() for t in self.thetas]
        return cloned

    def validate_positive_definite(self):
        """
        Validates dimensions, finite values, and positive-definiteness
        of all action covariance matrices using Cholesky decomposition.
        Raises ValueError if any matrix is invalid or non-positive-definite.
        """
        for a_idx in range(NUM_ACTIONS):
            A_mat = self.A[a_idx]
            b_vec = self.b[a_idx]
            cnt = self.counts[a_idx]

            if A_mat.shape != (DIMENSION_D, DIMENSION_D):
                raise ValueError(f"Action {a_idx} A matrix dimension mismatch: {A_mat.shape}")
            if b_vec.shape != (DIMENSION_D,):
                raise ValueError(f"Action {a_idx} b vector dimension mismatch: {b_vec.shape}")
            if not np.all(np.isfinite(A_mat)):
                raise ValueError(f"Action {a_idx} A matrix contains non-finite values.")
            if not np.all(np.isfinite(b_vec)):
                raise ValueError(f"Action {a_idx} b vector contains non-finite values.")
            if not (isinstance(cnt, int) and cnt >= 0):
                raise ValueError(f"Action {a_idx} invalid observation count: {cnt}")

            # Cholesky factorization test: fails if not strictly positive-definite
            try:
                _ = np.linalg.cholesky(A_mat)
            except np.linalg.LinAlgError as err:
                raise ValueError(f"Action {a_idx} covariance matrix is not positive-definite: {err}") from err

    def select_action(
        self,
        context: np.ndarray,
        eligible_actions: Optional[List[int]] = None
    ) -> Dict[str, Any]:
        """
        Selects the optimal action for given context vector under deterministic cold-start
        coverage and Upper Confidence Bound scoring.

        Returns detailed selection record with UCB components and selection reason.
        """
        if context.shape != (DIMENSION_D,):
            raise ValueError(f"Expected context shape ({DIMENSION_D},), got {context.shape}")

        if eligible_actions is None:
            eligible_set = set(range(NUM_ACTIONS))
        else:
            eligible_set = set(eligible_actions)
            if not eligible_set:
                raise ValueError("eligible_actions cannot be empty")

        # 1. Deterministic Cold-Start Coverage Check
        # Check if any eligible action has N_a < N_MIN
        unexplored_eligible = [
            a for a in COLD_START_PRIORITY
            if a in eligible_set and self.counts[a] < N_MIN
        ]

        if unexplored_eligible:
            selected_a = unexplored_eligible[0]
            selection_method = "COLD_START_PRIORITY"
            reason = f"Deterministic cold-start coverage: action {selected_a} ({ACTIONS[selected_a]}) has N={self.counts[selected_a]} < {N_MIN}."
        else:
            selection_method = "LINUCB_UCB_ARGMAX"
            selected_a = -1
            reason = "Standard LinUCB exploitation + uncertainty bonus."

        # 2. Compute UCB scores and components for all actions
        scores = {}
        predicted_rewards = {}
        uncertainties = {}

        for a_idx in range(NUM_ACTIONS):
            A_inv = np.linalg.inv(self.A[a_idx])
            theta = A_inv @ self.b[a_idx]
            self.thetas[a_idx] = theta

            # Predicted expected reward
            mu_hat = float(theta @ context)
            # Uncertainty variance: x^T A_a^{-1} x
            var = float(context @ A_inv @ context)
            # Ensure non-negative variance
            std = math.sqrt(max(0.0, var))
            ucb = mu_hat + self.alpha * std

            scores[a_idx] = ucb
            predicted_rewards[a_idx] = mu_hat
            uncertainties[a_idx] = std

        # In cold-start, add deterministic priority tie-breaker (eps < 1e-5)
        # to ensure downstream ranking and argmax match approved COLD_START_PRIORITY
        priority_map = {action: idx for idx, action in enumerate(COLD_START_PRIORITY)}
        for a_idx in range(NUM_ACTIONS):
            if self.counts[a_idx] < N_MIN and a_idx in priority_map:
                tie_breaker = 1e-6 * (NUM_ACTIONS - priority_map[a_idx])
                scores[a_idx] += tie_breaker

        # If not cold start, select highest UCB among eligible actions
        if selection_method != "COLD_START_PRIORITY":
            best_score = -float("inf")
            for a_idx in eligible_set:
                if scores[a_idx] > best_score:
                    best_score = scores[a_idx]
                    selected_a = a_idx

        # Generate ranked list of eligible actions
        eligible_ranked = sorted(
            [(a, scores[a], predicted_rewards[a], uncertainties[a], ACTIONS[a]) for a in eligible_set],
            key=lambda x: x[1],
            reverse=True
        )

        return {
            "selected_action_idx": selected_a,
            "selected_strategy": ACTIONS[selected_a],
            "selection_method": selection_method,
            "reason": reason,
            "ucb_score_selected": scores[selected_a],
            "predicted_reward_selected": predicted_rewards[selected_a],
            "uncertainty_selected": uncertainties[selected_a],
            "observation_count_selected": self.counts[selected_a],
            "alpha": self.alpha,
            "eligible_rankings": [
                {
                    "action_idx": item[0],
                    "strategy": item[4],
                    "ucb_score": item[1],
                    "predicted_reward": item[2],
                    "uncertainty": item[3]
                }
                for item in eligible_ranked
            ],
            "all_scores": scores,
            "model_version": self.version
        }

    def apply_update(self, action_idx: int, context: np.ndarray, reward: float):
        """
        Applies rank-one LinUCB update to specified action:
          A_a <- A_a + x x^T
          b_a <- b_a + r x
          N_a <- N_a + 1
          theta_a <- A_a^{-1} b_a
        """
        if not (0 <= action_idx < NUM_ACTIONS):
            raise IndexError(f"Invalid action_idx: {action_idx}")
        if context.shape != (DIMENSION_D,):
            raise ValueError(f"Expected context shape ({DIMENSION_D},), got {context.shape}")
        if not (isinstance(reward, (int, float)) and math.isfinite(reward)):
            raise ValueError(f"Invalid reward value: {reward}")

        x = context.astype(np.float64)
        x_outer = np.outer(x, x)

        self.A[action_idx] = self.A[action_idx] + x_outer
        self.b[action_idx] = self.b[action_idx] + reward * x
        self.counts[action_idx] += 1
        self.thetas[action_idx] = np.linalg.inv(self.A[action_idx]) @ self.b[action_idx]

        # Validate positive-definiteness after update
        self.validate_positive_definite()

    def to_dict(self) -> Dict[str, Any]:
        """Serializes model state into a JSON-compatible dictionary."""
        return {
            "alpha": self.alpha,
            "reg_lambda": self.reg_lambda,
            "version": self.version,
            "counts": self.counts,
            "A": [a.tolist() for a in self.A],
            "b": [b.tolist() for b in self.b],
            "thetas": [t.tolist() for t in self.thetas]
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> DisjointLinUCB:
        """Reconstructs DisjointLinUCB model from dictionary."""
        model = cls(
            alpha=data["alpha"],
            reg_lambda=data["reg_lambda"],
            version=data.get("version", 0)
        )
        model.counts = [int(c) for c in data["counts"]]
        model.A = [np.array(a, dtype=np.float64) for a in data["A"]]
        model.b = [np.array(b, dtype=np.float64) for b in data["b"]]
        model.thetas = [np.array(t, dtype=np.float64) for t in data["thetas"]]
        model.validate_positive_definite()
        return model

    def compute_sha256(self) -> str:
        """Computes deterministic cryptographic hash of the model state."""
        state_dict = self.to_dict()
        canonical_json = json.dumps(state_dict, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest().upper()
