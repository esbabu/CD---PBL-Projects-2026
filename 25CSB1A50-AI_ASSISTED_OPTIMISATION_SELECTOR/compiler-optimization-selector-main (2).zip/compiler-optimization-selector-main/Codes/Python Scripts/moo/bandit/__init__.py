"""
moo.bandit package
Disjoint LinUCB, Feature Scaler, Reward Verification, and SQLite Persistence.
"""

from .model import DisjointLinUCB, ACTIONS, COLD_START_PRIORITY, NUM_ACTIONS, DIMENSION_D
from .features import LinUCBFeatureScaler, CANONICAL_8_FEATURE_NAMES
from .reward import compute_linucb_reward, evaluate_eligibility_and_reward
from .persistence import SQLiteEvaluationLedger
from .config import (
    LinUCBDeploymentConfig,
    load_linucb_deployment_config,
    verify_linucb_scaler_integrity,
    verify_and_load_linucb_scaler,
    verify_linucb_checkpoint_integrity,
)

__all__ = [
    "DisjointLinUCB",
    "ACTIONS",
    "COLD_START_PRIORITY",
    "NUM_ACTIONS",
    "DIMENSION_D",
    "LinUCBFeatureScaler",
    "CANONICAL_8_FEATURE_NAMES",
    "compute_linucb_reward",
    "evaluate_eligibility_and_reward",
    "SQLiteEvaluationLedger",
    "LinUCBDeploymentConfig",
    "load_linucb_deployment_config",
    "verify_linucb_scaler_integrity",
    "verify_and_load_linucb_scaler",
    "verify_linucb_checkpoint_integrity",
]
