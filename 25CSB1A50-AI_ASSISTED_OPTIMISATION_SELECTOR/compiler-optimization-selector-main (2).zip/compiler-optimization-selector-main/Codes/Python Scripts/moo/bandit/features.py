"""
moo/bandit/features.py
Canonical 8-Feature Transformation & Training-Only Scaler for Disjoint LinUCB.

Feature Transformation:
1. Non-linear scaling: x_tilde = log(1 + max(0, x))
2. Training-only z-score normalization: z = (x_tilde - mu) / sigma
3. Extreme outlier clamping: z = clamp(z, -4.0, 4.0)
4. Bias appending: x_bandit = [z_0, ..., z_7, 1.0]^T in R^9
"""

from __future__ import annotations

import os
import json
import math
from typing import Dict, List, Any, Union
import numpy as np

CANONICAL_8_FEATURE_NAMES = [
    "BasicBlocksCount",
    "InstructionsCount",
    "BranchCount",
    "MemInstCount",
    "MathInstCount",
    "FloatInstCount",
    "VectorInstCount",
    "CallInstCount"
]

DIMENSION_D = 9

class LinUCBFeatureScaler:
    def __init__(self):
        self.means: List[float] = []
        self.stds: List[float] = []
        self.fitted_on_corpus: str = ""
        self.fitted_program_count: int = 0
        self.fitted: bool = False

    def fit_from_train_manifest(self, train_manifest_path: str):
        """
        Fit scaler statistics EXCLUSIVELY on the 60-program training manifest.
        Strictly forbids data leakage from validation or held-out test splits.
        """
        if not os.path.exists(train_manifest_path):
            raise FileNotFoundError(f"Training manifest not found: {train_manifest_path}")

        with open(train_manifest_path, "r", encoding="utf-8") as f:
            manifest_data = json.load(f)

        programs = manifest_data.get("programs", [])
        if len(programs) != 60:
            raise ValueError(f"Expected exactly 60 training programs, found {len(programs)}")

        # Extract raw features in canonical order
        raw_matrix = []
        for p in programs:
            feats = p.get("features", {})
            row = [float(feats.get(name, 0.0)) for name in CANONICAL_8_FEATURE_NAMES]
            raw_matrix.append(row)

        raw_np = np.array(raw_matrix, dtype=np.float64)
        # Apply step 1: log1p(max(0, x))
        log_np = np.log1p(np.maximum(0.0, raw_np))

        # Compute training-only means and standard deviations
        self.means = np.mean(log_np, axis=0).tolist()
        self.stds = np.std(log_np, axis=0, ddof=1).tolist()
        # Avoid division by zero for sparse/zero features (e.g. VectorInstCount)
        self.stds = [s if s > 1e-6 else 1.0 for s in self.stds]

        self.fitted_on_corpus = "corpus_60_train"
        self.fitted_program_count = len(programs)
        self.fitted = True

    def transform(self, raw_features: Union[Dict[str, float], List[float], np.ndarray]) -> np.ndarray:
        """
        Transforms raw 8 canonical features into a 9-dimensional context vector:
        8 normalized and clamped features + 1.0 bias.
        """
        if not self.fitted:
            raise RuntimeError("LinUCBFeatureScaler must be fitted or loaded before transform()")

        if isinstance(raw_features, dict):
            raw_vec = [float(raw_features.get(name, 0.0)) for name in CANONICAL_8_FEATURE_NAMES]
        elif isinstance(raw_features, (list, tuple)):
            if len(raw_features) < 8:
                raise ValueError(f"Expected at least 8 canonical features, got {len(raw_features)}")
            raw_vec = [float(x) for x in raw_features[:8]]
        elif isinstance(raw_features, np.ndarray):
            raw_vec = raw_features.flatten()[:8].astype(np.float64).tolist()
        else:
            raise TypeError(f"Unsupported features type: {type(raw_features)}")

        # Step 1: log1p(max(0, x))
        log_feats = [math.log1p(max(0.0, x)) for x in raw_vec]

        # Step 2 & 3: z-score normalization and clamp to [-4.0, +4.0]
        z_scores = []
        for val, mu, sig in zip(log_feats, self.means, self.stds):
            z = (val - mu) / sig
            z_clamped = max(-4.0, min(4.0, z))
            z_scores.append(z_clamped)

        # Step 4: Append bias = 1.0
        context_vector = np.array(z_scores + [1.0], dtype=np.float64)
        assert context_vector.shape == (DIMENSION_D,), f"Context vector dimension mismatch: {context_vector.shape}"
        return context_vector

    def save(self, file_path: str):
        """Save scaler metadata and parameters to JSON."""
        data = {
            "canonical_features": CANONICAL_8_FEATURE_NAMES,
            "dimension": DIMENSION_D,
            "fitted_on_corpus": self.fitted_on_corpus,
            "fitted_program_count": self.fitted_program_count,
            "means": self.means,
            "stds": self.stds
        }
        os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LinUCBFeatureScaler":
        """Construct and populate a scaler directly from parsed dictionary data."""
        if not isinstance(data, dict):
            raise ValueError(f"Scaler data must be a dictionary, got {type(data).__name__}")
        if "means" not in data or "stds" not in data:
            raise ValueError("Scaler data missing required 'means' or 'stds' fields")
        scaler = cls()
        try:
            scaler.means = [float(x) for x in data["means"]]
            scaler.stds = [float(x) for x in data["stds"]]
        except (ValueError, TypeError) as exc:
            raise ValueError(f"Invalid means or stds values in scaler data: {exc}") from exc
        if len(scaler.means) != len(CANONICAL_8_FEATURE_NAMES) or len(scaler.stds) != len(CANONICAL_8_FEATURE_NAMES):
            raise ValueError(
                f"Expected {len(CANONICAL_8_FEATURE_NAMES)} means and stds, got {len(scaler.means)} and {len(scaler.stds)}"
            )
        scaler.fitted_on_corpus = str(data.get("fitted_on_corpus", ""))
        scaler.fitted_program_count = int(data.get("fitted_program_count", 0))
        scaler.fitted = True
        return scaler

    def load(self, file_path: str):
        """Load scaler metadata and parameters from JSON."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Scaler file not found: {file_path}")
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        loaded = self.from_dict(data)
        self.means = loaded.means
        self.stds = loaded.stds
        self.fitted_on_corpus = loaded.fitted_on_corpus
        self.fitted_program_count = loaded.fitted_program_count
        self.fitted = True
