"""
moo/bandit/tuning.py
Validation Corpus Hyperparameter Tuning for LinUCB Exploration Parameter Alpha.

Rules:
- Evaluates alpha candidates exclusively on the 20-program validation set (val_manifest.json).
- Never fits scalers or updates bandit models using validation or test data.
- Never reads or touches the 30-program held-out test set (corpus_30_test / test_manifest.json).
"""

from __future__ import annotations

import os
import json
import numpy as np
from typing import Dict, List, Any

from .model import DisjointLinUCB, ACTIONS, NUM_ACTIONS
from .features import LinUCBFeatureScaler
from .reward import compute_linucb_reward

def _find_data_dir() -> str:
    p = os.path.abspath(os.path.dirname(__file__))
    while p and os.path.dirname(p) != p:
        cand = os.path.join(p, "data")
        if os.path.exists(cand) and os.path.exists(os.path.join(cand, "manifests")):
            return cand
        p = os.path.dirname(p)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data"))

DEFAULT_MANIFEST_DIR = os.path.join(_find_data_dir(), "manifests")

def run_alpha_tuning(
    manifest_dir: Optional[str] = None,
    alpha_candidates: Optional[List[float]] = None
) -> Dict[str, Any]:
    """
    Evaluates alpha candidates across the 20-program validation set.
    """
    m_dir = manifest_dir or DEFAULT_MANIFEST_DIR
    train_manifest = os.path.join(m_dir, "train_manifest.json")
    val_manifest = os.path.join(m_dir, "val_manifest.json")

    if not os.path.exists(train_manifest):
        raise FileNotFoundError(f"Train manifest not found: {train_manifest}")
    if not os.path.exists(val_manifest):
        raise FileNotFoundError(f"Val manifest not found: {val_manifest}")

    if alpha_candidates is None:
        alpha_candidates = [0.1, 0.2, 0.5, 1.0, 1.5, 2.0]

    # Load scaler fitted on train
    scaler = LinUCBFeatureScaler()
    scaler.fit_from_train_manifest(train_manifest)

    # Load train data for simulated pre-training
    with open(train_manifest, "r", encoding="utf-8") as f:
        train_data = json.load(f)["programs"]

    # Filter only CALIBRATED_STABLE training programs
    stable_train = [p for p in train_data if p["calibration"]["status"] == "CALIBRATED_STABLE"]

    # Load validation data
    with open(val_manifest, "r", encoding="utf-8") as f:
        val_data = json.load(f)["programs"]

    results = []
    best_alpha = 1.0
    best_score = -float("inf")

    for alpha in alpha_candidates:
        model = DisjointLinUCB(alpha=alpha, reg_lambda=1.0)

        # Pre-train bandit on stable training programs using their empirical -O3 speedup
        for p in stable_train:
            ctx = scaler.transform(p["features"])
            speedup = p["calibration"]["speedup_vs_o0"]
            t_base = p["calibration"]["baseline_median_ms"]
            t_cand = t_base / max(speedup, 0.1)
            # Simulated Action 3 (-O3) reward
            r = compute_linucb_reward(t_base, t_cand, 1000.0, 1000.0)
            model.apply_update(3, ctx, r)

        # Evaluate on validation set
        val_rewards = []
        action_coverage = set()

        for p in val_data:
            ctx = scaler.transform(p["features"])
            sel = model.select_action(ctx)
            chosen_a = sel["selected_action_idx"]
            action_coverage.add(chosen_a)

            # Simulated validation score based on speedup
            speedup = p["calibration"].get("speedup_vs_o0", 1.0)
            t_base = p["calibration"]["baseline_median_ms"]
            # Reward is higher if selected action is high-performing optimization
            if chosen_a in (1, 2, 3, 7, 8):
                t_cand = t_base / max(speedup, 1.0)
            else:
                t_cand = t_base
            r = compute_linucb_reward(t_base, t_cand, 1000.0, 1000.0)
            val_rewards.append(r)

        mean_reward = float(np.mean(val_rewards))
        cov_count = len(action_coverage)
        combined_score = mean_reward + 0.05 * cov_count

        results.append({
            "alpha": alpha,
            "mean_val_reward": round(mean_reward, 4),
            "distinct_actions_selected": cov_count,
            "combined_score": round(combined_score, 4)
        })

        if combined_score > best_score:
            best_score = combined_score
            best_alpha = alpha

    report = {
        "best_alpha": best_alpha,
        "alpha_candidates": alpha_candidates,
        "evaluation_split": "corpus_20_val",
        "validation_programs_count": len(val_data),
        "results": results
    }

    out_file = os.path.join(
        os.path.dirname(m_dir),
        "models",
        "linucb_tuning_report.json"
    )
    os.makedirs(os.path.dirname(out_file), exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    return report
