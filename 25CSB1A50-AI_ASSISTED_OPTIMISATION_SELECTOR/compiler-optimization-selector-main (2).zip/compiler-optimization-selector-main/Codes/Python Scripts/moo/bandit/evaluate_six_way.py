"""
moo/bandit/evaluate_six_way.py — Controlled Six-Way Intelligence Evaluation on Held-Out Test Corpus.

Evaluates 6 methods across the 30-program held-out test split (test_manifest.json):
1. Historical DQN (baseline checkpoint ml_optimizer_model.pth)
2. LinUCB (trained on corpus_60_train, alpha=0.1)
3. LLVM -O3 (industrial reference)
4. Deterministic Heuristic (IR profile rule-based tree)
5. Uniform Random (pseudo-random baseline, seed=42)
6. Supervised Ridge Regression (trained on corpus_60_train)

Strict Test Isolation:
- Zero model updates during evaluation.
- No scaler retraining.
- No alpha tuning.
- All 6 methods evaluated under identical measurement protocol (3 warmups, 5 timed runs, CV <= 10%).
"""

from __future__ import annotations

import os
import sys

# Ensure parent Python Scripts directory is on sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import json
import time
import subprocess
import tempfile
import numpy as np
from typing import Dict, List, Any, Optional

from ml_optimizer import ACTIONS, CLANG_PATH
from optimization_selector import select_with_provenance
from moo.measurement import measure_execution, measure_code_size
from moo.bandit.features import LinUCBFeatureScaler
from moo.bandit.persistence import SQLiteEvaluationLedger
from moo.bandit.baselines import (
    DeterministicHeuristicSelector,
    UniformRandomSelector,
    SupervisedRidgeRegressor,
)

OPT_PATH = r"C:\Users\rithv\Downloads\clang+llvm-23.1.0-x86_64-pc-windows-msvc\clang+llvm-23.1.0-x86_64-pc-windows-msvc\bin\opt.exe"

def _find_data_dir() -> str:
    p = os.path.abspath(os.path.dirname(__file__))
    while p and os.path.dirname(p) != p:
        cand = os.path.join(p, "data")
        if os.path.exists(cand) and os.path.exists(os.path.join(cand, "manifests")):
            return cand
        p = os.path.dirname(p)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data"))

def compile_strategy(src_path: str, action: str, out_exe: str, work_dir: str) -> bool:
    try:
        if action.startswith("-O"):
            cmd = [CLANG_PATH, action, src_path, "-o", out_exe]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return r.returncode == 0
        else:
            unopt_ll = os.path.join(work_dir, "unopt.ll")
            opt_ll = os.path.join(work_dir, "opt.ll")
            r1 = subprocess.run(
                [CLANG_PATH, "-O0", "-Xclang", "-disable-O0-optnone", "-S", "-emit-llvm", src_path, "-o", unopt_ll],
                capture_output=True, text=True, timeout=60
            )
            if r1.returncode != 0:
                return False
            r2 = subprocess.run(
                [OPT_PATH, f"-passes={action}", unopt_ll, "-S", "-o", opt_ll],
                capture_output=True, text=True, timeout=60
            )
            if r2.returncode != 0:
                return False
            r3 = subprocess.run(
                [CLANG_PATH, "-O2", opt_ll, "-o", out_exe],
                capture_output=True, text=True, timeout=60
            )
            return r3.returncode == 0
    except Exception:
        return False

def run_six_way_evaluation(output_json_path: Optional[str] = None) -> Dict[str, Any]:
    data_dir = _find_data_dir()
    train_manifest_path = os.path.join(data_dir, "manifests", "train_manifest.json")
    test_manifest_path = os.path.join(data_dir, "manifests", "test_manifest.json")
    scaler_path = os.path.join(data_dir, "models", "linucb_feature_scaler.json")
    ledger_db = os.path.join(data_dir, "ledger", "evaluation_ledger.db")

    if not os.path.exists(test_manifest_path):
        raise FileNotFoundError(f"Test manifest not found: {test_manifest_path}")

    # Load frozen components
    scaler = LinUCBFeatureScaler()
    scaler.load(scaler_path)

    ledger = SQLiteEvaluationLedger(ledger_db)
    linucb_model = ledger.get_active_model()
    from moo.bandit.config import load_linucb_deployment_config
    linucb_model.alpha = load_linucb_deployment_config().alpha  # validation-tuned (0.1)

    # Instantiate Baselines
    heuristic_sel = DeterministicHeuristicSelector()
    random_sel = UniformRandomSelector(seed=42)
    ridge_sel = SupervisedRidgeRegressor(reg_lambda=1.0)
    ridge_sel.fit_from_training_manifest(train_manifest_path, scaler)

    with open(test_manifest_path, "r", encoding="utf-8") as f:
        test_progs = json.load(f)["programs"]

    print(f"Beginning 6-way evaluation across {len(test_progs)} held-out test programs...")

    METHODS = [
        "Historical_DQN",
        "LinUCB",
        "LLVM_O3",
        "Deterministic_Heuristic",
        "Uniform_Random",
        "Supervised_Ridge"
    ]

    method_results = {m: [] for m in METHODS}
    per_program_results = []

    for idx, p in enumerate(test_progs):
        prog_id = p["program_id"]
        rel_path = p["relative_path"]
        src_path = os.path.abspath(os.path.join(os.path.dirname(data_dir), rel_path))
        features = p["features"]
        calib = p["calibration"]
        expected_chk = calib.get("expected_checksum", "")
        baseline_med_ms = calib.get("baseline_median_ms", 100.0)
        o3_med_ms = calib.get("o3_mean_ms", baseline_med_ms)

        ctx = scaler.transform(features)

        # 1. Determine selections for all 6 methods
        # A. Historical DQN
        dqn_res = select_with_provenance(src_path, features=list(features.values()), model_family="dqn")
        dqn_action_name = dqn_res.strategy if dqn_res else "-O2"
        dqn_a_idx = ACTIONS.index(dqn_action_name) if dqn_action_name in ACTIONS else 2

        # B. LinUCB (Frozen model, no update)
        linucb_res = linucb_model.select_action(ctx)
        linucb_a_idx = linucb_res["selected_action_idx"]
        linucb_action_name = ACTIONS[linucb_a_idx]

        # C. LLVM -O3
        o3_a_idx = 3
        o3_action_name = "-O3"

        # D. Deterministic Heuristic
        heur_a_idx = heuristic_sel.select(features)
        heur_action_name = ACTIONS[heur_a_idx]

        # E. Uniform Random
        rand_a_idx = random_sel.select(features)
        rand_action_name = ACTIONS[rand_a_idx]

        # F. Supervised Ridge
        ridge_a_idx = ridge_sel.select(ctx)
        ridge_action_name = ACTIONS[ridge_a_idx]

        selections = {
            "Historical_DQN": (dqn_a_idx, dqn_action_name),
            "LinUCB": (linucb_a_idx, linucb_action_name),
            "LLVM_O3": (o3_a_idx, o3_action_name),
            "Deterministic_Heuristic": (heur_a_idx, heur_action_name),
            "Uniform_Random": (rand_a_idx, rand_action_name),
            "Supervised_Ridge": (ridge_a_idx, ridge_action_name),
        }

        prog_eval = {
            "program_id": prog_id,
            "baseline_median_ms": baseline_med_ms,
            "methods": {}
        }

        # Cache compiled executables per action for this program
        with tempfile.TemporaryDirectory(prefix=f"toacd_eval_{prog_id}_") as tmp:
            action_executables = {}

            # Distinct actions selected by methods on this program
            distinct_actions = set(val[1] for val in selections.values())
            # Ensure baseline -O0 is available for reference size
            if "-O0" not in distinct_actions:
                distinct_actions.add("-O0")

            # Compile all needed actions
            compile_success = True
            for act in distinct_actions:
                exe_name = os.path.join(tmp, f"exe_{act.replace(',', '_')}.exe")
                if compile_strategy(src_path, act, exe_name, tmp):
                    action_executables[act] = exe_name
                else:
                    compile_success = False

            base_exe = action_executables.get("-O0")
            base_size = measure_code_size(base_exe).primary_value if base_exe else 1000

            # Evaluate each method
            for m_name in METHODS:
                a_idx, a_name = selections[m_name]
                exe = action_executables.get(a_name)

                if not exe or not os.path.exists(exe):
                    rec = {
                        "action_idx": a_idx,
                        "action_name": a_name,
                        "build_ok": False,
                        "correctness_ok": False,
                        "security_ok": True,
                        "status": "BUILD_FAILED",
                        "median_ms": None,
                        "cv_pct": None,
                        "speedup_vs_o0": 0.0,
                        "speedup_vs_o3": 0.0,
                        "binary_size": None
                    }
                else:
                    m_res = measure_execution(exe, strategy=a_name, warmup_runs=3, measure_runs=5, timeout_s=30)
                    sz = measure_code_size(exe).primary_value
                    ret_ok = (m_res.last_return_code == 0)
                    chk_ok = (not expected_chk) or (expected_chk in m_res.last_stdout)
                    cv_pct = m_res.timing.cv * 100.0
                    is_conclusive = ret_ok and chk_ok and (cv_pct <= 10.0)

                    t_cand_ms = m_res.timing.median_s * 1000.0
                    sp_o0 = baseline_med_ms / max(t_cand_ms, 1e-4) if is_conclusive else 0.0
                    sp_o3 = o3_med_ms / max(t_cand_ms, 1e-4) if is_conclusive else 0.0

                    rec = {
                        "action_idx": a_idx,
                        "action_name": a_name,
                        "build_ok": True,
                        "correctness_ok": bool(ret_ok and chk_ok),
                        "security_ok": True,
                        "status": "VALID_CONCLUSIVE" if is_conclusive else "INCONCLUSIVE",
                        "median_ms": round(t_cand_ms, 2),
                        "cv_pct": round(cv_pct, 2),
                        "speedup_vs_o0": round(sp_o0, 3),
                        "speedup_vs_o3": round(sp_o3, 3),
                        "binary_size": sz
                    }

                method_results[m_name].append(rec)
                prog_eval["methods"][m_name] = rec

        per_program_results.append(prog_eval)
        print(f"[{idx+1}/30] {prog_id}: LinUCB->{selections['LinUCB'][1]} ({prog_eval['methods']['LinUCB']['status']}), DQN->{selections['Historical_DQN'][1]}")

    # Compute Empirical Oracle per program
    for p_idx, prog_eval in enumerate(per_program_results):
        concl_speedups = [
            prog_eval["methods"][m]["speedup_vs_o0"]
            for m in METHODS
            if prog_eval["methods"][m]["status"] == "VALID_CONCLUSIVE"
        ]
        best_sp = max(concl_speedups) if concl_speedups else 1.0
        prog_eval["oracle_speedup_vs_o0"] = round(best_sp, 3)

        for m_name in METHODS:
            m_sp = prog_eval["methods"][m_name]["speedup_vs_o0"]
            regret = (best_sp - m_sp) / max(best_sp, 1e-4) if prog_eval["methods"][m_name]["status"] == "VALID_CONCLUSIVE" else 1.0
            prog_eval["methods"][m_name]["oracle_regret"] = round(max(regret, 0.0), 4)

    # Compute Aggregate Metrics
    aggregate_summary = {}

    for m_name in METHODS:
        recs = method_results[m_name]
        conclusive_recs = [r for r in recs if r["status"] == "VALID_CONCLUSIVE"]
        conclusive_count = len(conclusive_recs)
        inconclusive_count = len(recs) - conclusive_count

        correctness_rate = np.mean([1.0 if r["correctness_ok"] else 0.0 for r in recs]) * 100.0
        security_rate = 100.0  # all evaluated actions are security-vetted

        # Speedups
        sp_o0_list = [r["speedup_vs_o0"] for r in conclusive_recs if r["speedup_vs_o0"] > 0]
        sp_o3_list = [r["speedup_vs_o3"] for r in conclusive_recs if r["speedup_vs_o3"] > 0]
        cv_list = [r["cv_pct"] for r in conclusive_recs if r["cv_pct"] is not None]

        # Geometric means
        geomean_sp_o0 = float(np.exp(np.mean(np.log(sp_o0_list)))) if sp_o0_list else 1.0
        geomean_sp_o3 = float(np.exp(np.mean(np.log(sp_o3_list)))) if sp_o3_list else 1.0
        mean_cv = float(np.mean(cv_list)) if cv_list else 0.0

        # Mean Oracle Regret
        regrets = [p["methods"][m_name]["oracle_regret"] for p in per_program_results if p["methods"][m_name]["status"] == "VALID_CONCLUSIVE"]
        mean_oracle_regret = float(np.mean(regrets)) if regrets else 1.0

        # 95% Confidence interval on speedup vs O0
        if len(sp_o0_list) > 1:
            log_sp = np.log(sp_o0_list)
            sem = np.std(log_sp, ddof=1) / np.sqrt(len(log_sp))
            ci_low_sp0 = float(np.exp(np.mean(log_sp) - 1.96 * sem))
            ci_high_sp0 = float(np.exp(np.mean(log_sp) + 1.96 * sem))
        else:
            ci_low_sp0, ci_high_sp0 = geomean_sp_o0, geomean_sp_o0

        # Action Distribution & Entropy
        action_indices = [r["action_idx"] for r in recs]
        counts = np.bincount(action_indices, minlength=len(ACTIONS))
        probs = counts / np.sum(counts)
        non_zero_probs = probs[probs > 0]
        entropy = float(-np.sum(non_zero_probs * np.log(non_zero_probs)) / np.log(len(ACTIONS))) if len(non_zero_probs) > 1 else 0.0

        aggregate_summary[m_name] = {
            "total_programs": len(recs),
            "conclusive_count": conclusive_count,
            "inconclusive_count": inconclusive_count,
            "correctness_pass_rate_pct": round(correctness_rate, 2),
            "security_eligibility_rate_pct": round(security_rate, 2),
            "geomean_speedup_vs_o0": round(geomean_sp_o0, 4),
            "ci95_speedup_vs_o0": [round(ci_low_sp0, 4), round(ci_high_sp0, 4)],
            "geomean_speedup_vs_o3": round(geomean_sp_o3, 4),
            "mean_oracle_regret_pct": round(mean_oracle_regret * 100.0, 2),
            "mean_cv_pct": round(mean_cv, 2),
            "action_counts": counts.tolist(),
            "normalized_entropy": round(entropy, 4)
        }

    # Statistical Comparison: LinUCB vs DQN and LinUCB vs O3 (Wilcoxon signed-rank / paired t-test)
    from scipy import stats
    lin_sp = [r["speedup_vs_o0"] for r in method_results["LinUCB"]]
    dqn_sp = [r["speedup_vs_o0"] for r in method_results["Historical_DQN"]]
    o3_sp = [r["speedup_vs_o0"] for r in method_results["LLVM_O3"]]

    # Paired test LinUCB vs DQN
    try:
        t_stat_dqn, p_val_dqn = stats.ttest_rel(lin_sp, dqn_sp)
        wilc_stat_dqn, wilc_p_dqn = stats.wilcoxon(np.array(lin_sp) - np.array(dqn_sp))
    except Exception:
        t_stat_dqn, p_val_dqn, wilc_stat_dqn, wilc_p_dqn = None, None, None, None

    # Paired test LinUCB vs O3
    try:
        t_stat_o3, p_val_o3 = stats.ttest_rel(lin_sp, o3_sp)
        wilc_stat_o3, wilc_p_o3 = stats.wilcoxon(np.array(lin_sp) - np.array(o3_sp))
    except Exception:
        t_stat_o3, p_val_o3, wilc_stat_o3, wilc_p_o3 = None, None, None, None

    statistical_analysis = {
        "linucb_vs_dqn": {
            "paired_ttest_stat": float(t_stat_dqn) if t_stat_dqn is not None else None,
            "paired_ttest_pval": float(p_val_dqn) if p_val_dqn is not None else None,
            "wilcoxon_stat": float(wilc_stat_dqn) if wilc_stat_dqn is not None else None,
            "wilcoxon_pval": float(wilc_p_dqn) if wilc_p_dqn is not None else None,
        },
        "linucb_vs_o3": {
            "paired_ttest_stat": float(t_stat_o3) if t_stat_o3 is not None else None,
            "paired_ttest_pval": float(p_val_o3) if p_val_o3 is not None else None,
            "wilcoxon_stat": float(wilc_stat_o3) if wilc_stat_o3 is not None else None,
            "wilcoxon_pval": float(wilc_p_o3) if wilc_p_o3 is not None else None,
        }
    }

    full_evaluation_report = {
        "evaluation_name": "TOACD Stage 13.4 Six-Way Controlled Evaluation",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "held_out_corpus_size": len(test_progs),
        "methods_evaluated": METHODS,
        "aggregate_summary": aggregate_summary,
        "statistical_analysis": statistical_analysis,
        "per_program_results": per_program_results
    }

    out_path = output_json_path or os.path.join(data_dir, "models", "six_way_evaluation_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(full_evaluation_report, f, indent=2)

    print(f"\nSix-Way Evaluation finished. Report saved to: {out_path}")
    return full_evaluation_report

if __name__ == "__main__":
    run_six_way_evaluation()
