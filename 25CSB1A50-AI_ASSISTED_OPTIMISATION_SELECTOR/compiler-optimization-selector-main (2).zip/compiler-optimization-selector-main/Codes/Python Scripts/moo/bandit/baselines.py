"""
moo/bandit/baselines.py — Baseline selectors for Stage 13.4 Controlled Evaluation.

Implements:
1. DeterministicHeuristicSelector (IR-structural rule-based decision tree)
2. UniformRandomSelector (stochastic baseline with reproducible seed)
3. SupervisedRidgeRegressor (offline supervised ridge regression baseline)
"""

from __future__ import annotations

import os
import json
import numpy as np
from typing import Dict, List, Any, Optional

from ml_optimizer import ACTIONS
from moo.program_profiler import profile_program, PROFILE_LOOP_ORIENTED, PROFILE_COMPUTE_ORIENTED, PROFILE_MEMORY_ORIENTED, PROFILE_TRIVIAL, PROFILE_MIXED, PROFILE_CALL_ORIENTED
from moo.bandit.features import LinUCBFeatureScaler

class DeterministicHeuristicSelector:
    """
    Deterministic rule-based decision tree mapping IR structure to compiler actions.
    """
    def __init__(self):
        pass

    def select(self, features: Dict[str, float], eligible_actions: Optional[List[int]] = None) -> int:
        if eligible_actions is None:
            eligible_actions = list(range(len(ACTIONS)))

        profile = profile_program(features)
        lbl = profile.label

        if lbl in (PROFILE_LOOP_ORIENTED, PROFILE_COMPUTE_ORIENTED):
            pref = 3  # -O3
        elif lbl == PROFILE_MEMORY_ORIENTED:
            pref = 6  # mem2reg,instcombine,simplifycfg,dce
        elif lbl == PROFILE_TRIVIAL:
            pref = 1  # -O1
        elif lbl in (PROFILE_MIXED, PROFILE_CALL_ORIENTED):
            pref = 2  # -O2
        else:
            pref = 2  # -O2

        if pref in eligible_actions:
            return pref
        # Fallback to first eligible
        return eligible_actions[0]

class UniformRandomSelector:
    """
    Uniform random action selector with reproducible pseudo-random seed.
    """
    def __init__(self, seed: int = 42):
        self.rng = np.random.RandomState(seed)

    def select(self, features: Dict[str, float], eligible_actions: Optional[List[int]] = None) -> int:
        if eligible_actions is None:
            eligible_actions = list(range(len(ACTIONS)))
        return int(self.rng.choice(eligible_actions))

class SupervisedRidgeRegressor:
    """
    Offline supervised Ridge Regression baseline trained on training corpus labels.
    """
    def __init__(self, reg_lambda: float = 1.0):
        self.reg_lambda = reg_lambda
        self.weights = None  # shape: (d, num_actions)
        self.is_fitted = False

    def fit_from_training_manifest(self, train_manifest_path: str, scaler: LinUCBFeatureScaler):
        """Fit ridge weights on the 60 training programs."""
        with open(train_manifest_path, "r", encoding="utf-8") as f:
            programs = json.load(f)["programs"]

        X = []
        Y = []

        for p in programs:
            ctx = scaler.transform(p["features"])
            X.append(ctx)

            # Generate target speedups/rewards for all 9 actions
            calib = p.get("calibration", {})
            speedup_o3 = calib.get("speedup_vs_o0", 1.0)
            status = calib.get("status", "CALIBRATED_STABLE")

            y_prog = np.zeros(len(ACTIONS))
            if status == "CALIBRATED_STABLE":
                y_prog[0] = 0.0  # -O0 baseline
                y_prog[1] = 0.5 * (speedup_o3 - 1.0)  # -O1
                y_prog[2] = 0.8 * (speedup_o3 - 1.0)  # -O2
                y_prog[3] = 1.0 * (speedup_o3 - 1.0)  # -O3
                y_prog[4] = 0.4 * (speedup_o3 - 1.0)  # mem2reg,instcombine
                y_prog[5] = 0.3 * (speedup_o3 - 1.0)  # mem2reg,simplifycfg
                y_prog[6] = 0.6 * (speedup_o3 - 1.0)  # mem2reg,instcombine,simplifycfg,dce
                y_prog[7] = 0.85 * (speedup_o3 - 1.0) # mem2reg,instcombine,simplifycfg,gvn,loop-unroll
                y_prog[8] = 0.9 * (speedup_o3 - 1.0)  # mem2reg,instcombine,simplifycfg,dce,gvn,loop-unroll
            Y.append(y_prog)

        X = np.array(X)  # (N, d)
        Y = np.array(Y)  # (N, K)

        N, d = X.shape
        K = Y.shape[1]

        # W = (X^T X + lambda I)^(-1) X^T Y
        reg_I = self.reg_lambda * np.eye(d)
        A = X.T @ X + reg_I
        self.weights = np.linalg.solve(A, X.T @ Y)  # shape (d, K)
        self.is_fitted = True

    def select(self, context: np.ndarray, eligible_actions: Optional[List[int]] = None) -> int:
        if not self.is_fitted or self.weights is None:
            raise RuntimeError("SupervisedRidgeRegressor is not fitted.")
        if eligible_actions is None:
            eligible_actions = list(range(len(ACTIONS)))

        preds = context @ self.weights  # shape (K,)
        best_a = None
        best_val = -float("inf")

        for a in eligible_actions:
            if preds[a] > best_val:
                best_val = preds[a]
                best_a = a

        return best_a if best_a is not None else eligible_actions[0]
