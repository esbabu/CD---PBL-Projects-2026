"""
moo/bandit/persistence.py
SQLite ACID Evaluation Ledger & Multi-Process Checkpoint Synchronization.

Guarantees:
- SQLite WAL mode (PRAGMA journal_mode=WAL) with busy_timeout=5000ms
- BEGIN IMMEDIATE transaction isolation
- Evaluation token idempotency across application restarts
- Strict Checkpoint-Version Tracking: stale in-memory models cannot overwrite newer state
- 11-step transactional copy-and-swap: in-memory state is only replaced after DB commit
- Cryptographic SHA-256 state integrity verification on load and commit
"""

from __future__ import annotations

import os
import sqlite3
import json
import time
import hashlib
from typing import Tuple, Dict, Any, Optional
import numpy as np

from .model import DisjointLinUCB, NUM_ACTIONS, DIMENSION_D

def _find_data_dir() -> str:
    p = os.path.abspath(os.path.dirname(__file__))
    while p and os.path.dirname(p) != p:
        cand = os.path.join(p, "data")
        if os.path.exists(cand):
            return cand
        p = os.path.dirname(p)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "data"))

DEFAULT_LEDGER_PATH = os.path.join(_find_data_dir(), "ledger", "evaluation_ledger.db")

class SQLiteEvaluationLedger:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = os.path.abspath(db_path or DEFAULT_LEDGER_PATH)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.active_model: Optional[DisjointLinUCB] = None
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10.0, isolation_level=None)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        return conn

    def _init_db(self):
        """Initializes tables and loads latest checkpoint or creates initial checkpoint."""
        conn = self._get_connection()
        try:
            with conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS evaluation_tokens (
                        token TEXT PRIMARY KEY,
                        program_id TEXT NOT NULL,
                        action_id INTEGER NOT NULL,
                        reward REAL NOT NULL,
                        status TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    );
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS linucb_checkpoint (
                        version INTEGER PRIMARY KEY,
                        state_blob TEXT NOT NULL,
                        sha256 TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    );
                """)

            # Load latest checkpoint if available
            cursor = conn.cursor()
            cursor.execute("SELECT version, state_blob, sha256 FROM linucb_checkpoint ORDER BY version DESC LIMIT 1;")
            row = cursor.fetchone()

            if row:
                ver, blob, sha = row
                # Verify SHA-256 integrity
                computed_sha = hashlib.sha256(blob.encode("utf-8")).hexdigest().upper()
                if computed_sha != sha:
                    raise RuntimeError(f"Corrupt LinUCB checkpoint detected at version {ver}: SHA-256 mismatch!")
                data = json.loads(blob)
                self.active_model = DisjointLinUCB.from_dict(data)
                self.active_model.version = ver
            else:
                # Initialize new LinUCB model (version 0)
                initial_model = DisjointLinUCB(version=0)
                state_dict = initial_model.to_dict()
                blob = json.dumps(state_dict, sort_keys=True, separators=(",", ":"))
                sha = hashlib.sha256(blob.encode("utf-8")).hexdigest().upper()
                now_str = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

                with conn:
                    conn.execute(
                        "INSERT INTO linucb_checkpoint (version, state_blob, sha256, updated_at) VALUES (?, ?, ?, ?);",
                        (0, blob, sha, now_str)
                    )
                self.active_model = initial_model
        finally:
            conn.close()

    def get_active_model(self) -> DisjointLinUCB:
        """Returns the current active model, syncing with DB if a newer checkpoint exists."""
        self.sync_with_latest_checkpoint()
        assert self.active_model is not None
        return self.active_model

    def sync_with_latest_checkpoint(self):
        """Checks DB for newer checkpoint and updates in-memory model if necessary."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT version, state_blob, sha256 FROM linucb_checkpoint ORDER BY version DESC LIMIT 1;")
            row = cursor.fetchone()
            if row:
                ver, blob, sha = row
                if self.active_model is None or ver > self.active_model.version:
                    computed_sha = hashlib.sha256(blob.encode("utf-8")).hexdigest().upper()
                    if computed_sha != sha:
                        raise RuntimeError(f"Corrupt checkpoint at version {ver}: SHA mismatch")
                    data = json.loads(blob)
                    loaded_model = DisjointLinUCB.from_dict(data)
                    loaded_model.version = ver
                    self.active_model = loaded_model
        finally:
            conn.close()

    def record_update_transaction(
        self,
        token: str,
        program_id: str,
        action_idx: int,
        context: np.ndarray,
        reward: float,
        status: str = "ELIGIBLE_STABLE"
    ) -> Tuple[bool, str, int]:
        """
        Executes an ACID copy-and-swap LinUCB model update transaction.

        Returns:
          (success: bool, reason: str, model_version: int)
        """
        if not token or not str(token).strip():
            return False, "EMPTY_EVALUATION_TOKEN", -1

        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            # 1. BEGIN IMMEDIATE transaction to acquire exclusive write lock
            cursor.execute("BEGIN IMMEDIATE;")

            # 2. Check evaluation-token uniqueness
            cursor.execute("SELECT 1 FROM evaluation_tokens WHERE token = ?;", (token,))
            if cursor.fetchone() is not None:
                cursor.execute("ROLLBACK;")
                curr_ver = self.active_model.version if self.active_model else 0
                return False, "DUPLICATE_EVALUATION_TOKEN", curr_ver

            # 3. Read latest committed checkpoint from DB
            cursor.execute("SELECT version, state_blob, sha256 FROM linucb_checkpoint ORDER BY version DESC LIMIT 1;")
            latest_row = cursor.fetchone()
            if not latest_row:
                cursor.execute("ROLLBACK;")
                return False, "CHECKPOINT_TABLE_EMPTY", -1

            latest_ver, latest_blob, latest_sha = latest_row

            # Verify integrity
            computed_sha = hashlib.sha256(latest_blob.encode("utf-8")).hexdigest().upper()
            if computed_sha != latest_sha:
                cursor.execute("ROLLBACK;")
                return False, "CHECKPOINT_CORRUPTION_DETECTED", latest_ver

            # 4. Checkpoint-Version Tracking & Multi-Process Synchronization:
            # Reconstruct the latest state from DB to guarantee no stale in-memory overwrite
            db_model = DisjointLinUCB.from_dict(json.loads(latest_blob))
            db_model.version = latest_ver

            # 5. Create isolated copy for proposed update
            proposed_model = db_model.clone()

            # 6. Apply proposed LinUCB update
            proposed_model.apply_update(action_idx, context, reward)
            proposed_model.version = latest_ver + 1

            # 7. Validate dimensions, finite values, and positive-definiteness via Cholesky
            proposed_model.validate_positive_definite()

            # 8. Serialize and compute SHA-256 hash
            proposed_state = proposed_model.to_dict()
            blob_to_write = json.dumps(proposed_state, sort_keys=True, separators=(",", ":"))
            new_sha = hashlib.sha256(blob_to_write.encode("utf-8")).hexdigest().upper()
            now_str = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

            # 9. Insert evaluation token
            cursor.execute(
                "INSERT INTO evaluation_tokens (token, program_id, action_id, reward, status, created_at) VALUES (?, ?, ?, ?, ?, ?);",
                (token, program_id, int(action_idx), float(reward), status, now_str)
            )

            # 10. Insert updated checkpoint
            cursor.execute(
                "INSERT INTO linucb_checkpoint (version, state_blob, sha256, updated_at) VALUES (?, ?, ?, ?);",
                (proposed_model.version, blob_to_write, new_sha, now_str)
            )

            # 11. COMMIT transaction
            cursor.execute("COMMIT;")

            # 12. Only after successful commit, swap active in-memory model state
            self.active_model = proposed_model
            return True, "TRANSACTION_COMMITTED", proposed_model.version

        except Exception as exc:
            try:
                cursor.execute("ROLLBACK;")
            except Exception:
                pass
            curr_ver = self.active_model.version if self.active_model else 0
            return False, f"TRANSACTION_FAILED: {exc}", curr_ver
        finally:
            conn.close()

    def has_token(self, token: str) -> bool:
        """Check if an evaluation token has already been processed."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM evaluation_tokens WHERE token = ?;", (token,))
            return cursor.fetchone() is not None
        finally:
            conn.close()
