"""
moo.ir_cache — Content-Hashed Baseline IR & Feature Cache for TOACD.

Eliminates redundant Clang/opt subprocess executions by caching unoptimized
LLVM IR (-O0 -disable-O0-optnone) and extracted canonical 8-feature vectors,
keyed strictly by the SHA-256 hash of the C source code.

Properties:
- Purely additive performance layer; does NOT change any compiler decisions.
- Automatically invalidates whenever source code content changes.
- Thread-safe and bounded to prevent memory leaks.
"""

from __future__ import annotations

import hashlib
import logging
import os
import threading
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_MAX_CACHE_ENTRIES = 64
_lock = threading.Lock()

# Cache stores: hash -> {"ir_text": str, "features": dict, "raw_features": list}
_IR_CACHE: Dict[str, Dict[str, Any]] = {}
_CACHE_HITS: int = 0
_CACHE_MISSES: int = 0


def compute_source_hash(source_path_or_content: Any, build_config: Optional[Any] = None) -> str:
    """
    Computes SHA-256 digest of source content/project and optional build configuration.
    If the parameter is a CProject, computes the deterministic project hash.
    If the parameter is an existing directory, treats it as a CProject directory.
    If the parameter is an existing file path, hashes file bytes;
    otherwise hashes the string content directly.
    """
    if hasattr(source_path_or_content, "compute_project_hash"):
        return source_path_or_content.compute_project_hash()

    if isinstance(source_path_or_content, str) and os.path.isdir(source_path_or_content):
        try:
            from .project import CProject
            proj = CProject.from_directory(source_path_or_content, build_config=build_config)
            return proj.compute_project_hash()
        except Exception:
            pass

    hasher = hashlib.sha256()
    try:
        if isinstance(source_path_or_content, str) and os.path.isfile(source_path_or_content):
            with open(source_path_or_content, "rb") as f:
                while chunk := f.read(65536):
                    hasher.update(chunk)
            if build_config is not None:
                try:
                    flags = " ".join(build_config.to_clang_args())
                    hasher.update(b"|bc:" + flags.encode("utf-8", errors="replace"))
                except Exception:
                    pass
            return hasher.hexdigest()
    except Exception:
        pass

    # Treat as raw string content
    raw_str = str(source_path_or_content)
    hasher.update(raw_str.encode("utf-8", errors="replace"))
    if build_config is not None:
        try:
            flags = " ".join(build_config.to_clang_args())
            hasher.update(b"|bc:" + flags.encode("utf-8", errors="replace"))
        except Exception:
            pass
    return hasher.hexdigest()


def get_cached_baseline_ir(source_hash: str) -> Optional[str]:
    """Retrieve cached unoptimized LLVM IR text if available."""
    global _CACHE_HITS, _CACHE_MISSES
    with _lock:
        entry = _IR_CACHE.get(source_hash)
        if entry and "ir_text" in entry and entry["ir_text"]:
            _CACHE_HITS += 1
            return entry["ir_text"]
        _CACHE_MISSES += 1
        return None


def store_cached_baseline_ir(
    source_hash: str,
    ir_text: str,
    features: Optional[Dict[str, float]] = None,
    raw_features: Optional[List[float]] = None,
) -> None:
    """Stores unoptimized LLVM IR text and optional features for source hash."""
    if not source_hash or not ir_text:
        return
    with _lock:
        if len(_IR_CACHE) >= _MAX_CACHE_ENTRIES:
            # Pop oldest entry (FIFO / simple eviction)
            first_key = next(iter(_IR_CACHE))
            _IR_CACHE.pop(first_key, None)

        entry = _IR_CACHE.setdefault(source_hash, {})
        entry["ir_text"] = ir_text
        if features is not None:
            entry["features"] = dict(features)
        if raw_features is not None:
            entry["raw_features"] = list(raw_features)


def get_cached_ir_features(source_hash: str) -> Optional[Dict[str, float]]:
    """Retrieve cached 8-count IR features dict if available."""
    with _lock:
        entry = _IR_CACHE.get(source_hash)
        if entry and "features" in entry:
            return dict(entry["features"])
        return None


def get_cached_raw_features(source_hash: str) -> Optional[List[float]]:
    """Retrieve cached raw float list of 8 features if available."""
    with _lock:
        entry = _IR_CACHE.get(source_hash)
        if entry and "raw_features" in entry:
            return list(entry["raw_features"])
        return None


def store_cached_ir_features(
    source_hash: str,
    features: Dict[str, float],
    raw_features: Optional[List[float]] = None,
) -> None:
    """Stores extracted IR features for source hash."""
    if not source_hash:
        return
    with _lock:
        if len(_IR_CACHE) >= _MAX_CACHE_ENTRIES:
            first_key = next(iter(_IR_CACHE))
            _IR_CACHE.pop(first_key, None)

        entry = _IR_CACHE.setdefault(source_hash, {})
        entry["features"] = dict(features)
        if raw_features is not None:
            entry["raw_features"] = list(raw_features)


def invalidate_cache(source_hash: Optional[str] = None) -> None:
    """Invalidates all entries or a specific hash."""
    global _IR_CACHE, _CACHE_HITS, _CACHE_MISSES
    with _lock:
        if source_hash:
            _IR_CACHE.pop(source_hash, None)
        else:
            _IR_CACHE.clear()
            _CACHE_HITS = 0
            _CACHE_MISSES = 0


def get_cache_stats() -> Dict[str, Any]:
    """Returns hit/miss and occupancy statistics."""
    with _lock:
        return {
            "entries": len(_IR_CACHE),
            "hits": _CACHE_HITS,
            "misses": _CACHE_MISSES,
        }
