# IntelliDCE: Intelligent Dead Code Elimination & Compiler Security System

[![C++17](https://img.shields.io/badge/C%2B%2B-17-00599C?style=flat&logo=c%2B%2B)](https://en.cppreference.com/w/cpp/17)
[![Python](https://img.shields.io/badge/Python-3.12-3776AB?style=flat&logo=python)](https://www.python.org/)
[![PyTorch Geometric](https://img.shields.io/badge/PyTorch-Geometric%20(GNN)-EE4C2C?style=flat&logo=pytorch)](https://pyg.org/)
[![Node.js](https://img.shields.io/badge/Node.js-18%2B-339933?style=flat&logo=node.js)](https://nodejs.org/)
[![Ollama](https://img.shields.io/badge/Local%20LLM-Qwen2.5--Coder%207B-000000?style=flat&logo=ollama)](https://ollama.ai/)
[![Docker](https://img.shields.io/badge/Sandbox-Docker%20Isolation-2496ED?style=flat&logo=docker)](https://www.docker.com/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Status](https://img.shields.io/badge/Project-PBL%20Cap%20Milestone-brightgreen)](#)

---

### **Project-Based Learning (PBL) Academic Specification**
* **Project Title:** IntelliDCE — Intelligent Dead Code Elimination & Compiler Security System
* **Author / Student:** Rahul Kumar Chaurasiya
* **Roll Number:** 25CSB1A77
* **Project Supervisor:** Prof. Erukala Suresh Babu
* **Department:** Department of Computer Science and Engineering (Artificial Intelligence & Data Science)
* **Institution:** National Institute of Technology Warangal (NIT Warangal)
* **Academic Submission:** Project-Based Learning (PBL) Technical Evaluation

---

## 📦 Submission Deliverables & File Contents Catalog

As required for the Project-Based Learning (PBL) submission and repository fork, this section provides a structured inventory of all submitted artifacts—including **Source Code**, **Documentation**, and **Screen Recordings**—detailing their official **Title**, **File Name**, **Category**, and **Functional Description**.

| Category | Deliverable Title | File / Directory Name | Format & Size | Description & Evaluation Contents |
| :--- | :--- | :--- | :--- | :--- |
| **Documentation** | **IntelliDCE End-Evaluation Technical Specification & Final Report** | `25CSB1A77_RahulKumarChaurasiya_IntelliDCE_Report_END.docx` | DOCX (~12.3 MB) | **Comprehensive Final Report:** Submitted for end-semester grading. Contains complete formal problem formulation, semantic equivalence proofs, safety veto invariants, 7-module implementation details, empirical benchmark results across TC01–TC17, 11-CWE detection evaluation, confusion matrix, and IEEE-style academic citations. |
| **Documentation** | **IntelliDCE Mid-Evaluation Progress Report** | `25CSB1A77_RahulKumarChaurasiya_IntelliDCE_Report_MID.docx` | DOCX (~1.8 MB) | **Interim Milestone Report:** Documents baseline compiler architecture, classical SCCP/mark-and-sweep DCE limitations, initial GraphSAGE GNN design, SSA IR lowering methodology, and mid-term evaluation deliverables. |
| **Documentation** | **Master PBL Specification & System README** | `README.md` | Markdown (~27 KB) | **Project Documentation:** Complete technical reference containing mathematical models, system architecture topology, module-by-module breakdown, setup/installation instructions, CLI/GUI usage guides, and test verification suite. |
| **Screen Recording** | **Full System End-Evaluation Live Demonstration** | `IDCE END-Evaluation Screen Recording.mov` | QuickTime MOV (~407 MB) | **Live End-Semester Demonstration Video:** Full walkthrough of the running system: loading C++/SSA code, real-time 11-CWE automata security scanning, Guardian pre-compile interception, dual-mode DCE execution (Classical vs GraphSAGE), interactive CFG visualization, side-by-side SSA diff, DEF-USE explainer sandbox, and interactive DRONA AI Copilot queries. |
| **Screen Recording** | **Mid-Evaluation Prototype & Pipeline Demonstration** | `IDCE MID-Evaluation Screen Recording.mov` | QuickTime MOV (~145 MB) | **Mid-Term Evaluation Video:** Demonstrates initial C++ compiler pipeline, GIMPLE SSA generation, early mark-and-sweep DCE passes, and baseline GUI prototype operation. |
| **Screen Recording** | **Legacy Compiler Architecture Walkthrough** | `old existing architecture.mkv` | Matroska MKV (~12.5 MB) | **Architectural Video Analysis:** Detailed breakdown of the legacy/baseline compiler pipeline explaining why traditional dataflow DCE is vulnerable to loop-carried dead structures and silent dead cryptographic store pruning (CWE-561). |
| **Source Code** | **C++ Core Optimizing Compiler Engine** | `Intelligent Dead Code Elimination Tool/IntelliDCE-main/src/` & root | C++17 / Flex / Bison | **Compiler Core Backend:** Implements GIMPLE SSA lexer (`lexer.l`), LALR(1) parser (`parser.y`), IR data structures (`ir.h`), and optimization algorithms (`analysis.cpp`) including SCCP constant folding, reachability analysis, mark-and-sweep liveness, and the deterministic safety veto engine. |
| **Source Code** | **Graph Neural Network (GNN) Inference & Training** | `Intelligent Dead Code Elimination Tool/IntelliDCE-main/ml/` | Python 3.12 / PyTorch Geometric | **Deep Learning Pipeline:** Implements 2-stage GraphSAGE + GAT classifier (`model.py`), graph feature extraction (`feature_extractor.cpp`), liveness inference (`inference.py`), synthetic SSA program fuzzer (`fuzzer.py`), and class-weighted training harness (`train.py`). |
| **Source Code** | **Interactive Web GUI & Telemetry Server** | `Intelligent Dead Code Elimination Tool/IntelliDCE-main/gui/` | Node.js / Express / WebSockets | **Full-Stack Application:** Cyber-neon browser interface (`public/index.html`), Express backend (`server.js`), DRONA Agent controller (`drona.js`), Guardian prompt injection defense (`guardian.js`), local Ollama integration (`llm.js`), and Docker differential regression verifier (`verifier.js`, `sandbox.js`). |
| **Source Code / Data** | **Trained GNN Weights & Model Artifacts** | `Intelligent Dead Code Elimination Tool/IntelliDCE-main/ml_data/` | PyTorch `.pt` / JSONL | **Model Weights & Audit Logs:** Serialized PyTorch Geometric model weights (`dce_model.pt`) and human feedback corrections log (`corrections.jsonl`) for continuous retraining. |
| **Source Code / Tests** | **SSA Benchmark Workloads & Test Suites** | `Intelligent Dead Code Elimination Tool/IntelliDCE-main/inputs/` & `gui/tests/` | SSA / C++ / JS | **Validation Corpus:** Comprehensive suite of 17+ benchmark workloads (`01_dead_store.ssa` through `500lines.cpp`) and automated unit tests verifying Guardian defenses, LLM offline reliability, sandbox boundaries, and cryptographic SHA-256 audit chains. |

---

## 📖 Executive Summary & Abstract

Traditional compiler optimization pipelines (e.g., GCC, LLVM) treat Dead Code Elimination (DCE) purely as a syntax-directed, conservative dataflow problem using standard bit-vector reachability and iterative mark-and-sweep passes. While sound, these textbook algorithms face critical shortcomings:
1. **Conservative Liveness Incompleteness:** Complex loop-carried dependencies, non-trivial control-flow joins, and pointer aliasing force classical compilers to conservatively mark semantically inert instructions as "live", producing code bloat and unoptimized binaries.
2. **Security Blindness & Premature Pruning (CWE-561):** Classical optimizers are unaware of vulnerability semantics. For instance, sensitive memory wiping (such as `memset(password, 0, len)` prior to deallocation) is routinely pruned as a "dead store" because the memory buffer is not read downstream, silently leaving credentials exposed in physical memory.
3. **Supply-Chain & AI Synthesis Vulnerabilities:** With over 40% of modern software incorporating AI-generated code, compilers frequently encounter unsafe C/C++ primitives (CWE-78, CWE-120, CWE-134). At the same time, integrating conversational AI coding assistants directly into developer workflows introduces severe prompt injection and malicious jailbreak vectors.

**IntelliDCE** bridges the gap between formal compiler theory, graph deep learning, and automated security verification. It lower high-level C/C++ code into GIMPLE Static Single Assignment (SSA) form, constructs a unified Control Flow & Def-Use Graph ($G = (V, E, X)$ with 74-dimensional node feature vectors), and predicts statement liveness using a **2-stage Hybrid Graph Neural Network (GraphSAGE + Multi-Head GAT)**. To prevent semantic drift, the GNN is bounded by a **Deterministic Compiler Safety Veto Engine**.

Pre-compilation security is enforced by an **Automata-Theoretic Vulnerability Scanner** covering 11 Common Weakness Enumerations (CWEs) and an automated **Program Vitality Scorecard** ($0 - 100$). For interactive assistance, IntelliDCE introduces **DRONA**, an offline AI compiler copilot (Qwen2.5-Coder 7B) fortified behind a multi-phase **Guardian Shield** that completely neutralizes direct and indirect prompt injections before LLM invocation. Differential runtime behavior is guaranteed via a **Containerized Docker Regression Guard** and recorded in an **Unbroken SHA-256 Cryptographic Audit Hash Chain**.

---

## 🏛️ System Architecture

### Baseline Pipeline vs. IntelliDCE Proposed Architecture

```
──────────────────────────────────────────────────────────────────────────────────────────
A. BASELINE COMPILER PIPELINE (Classic "Compile, Blindly Optimize, Propagate")
──────────────────────────────────────────────────────────────────────────────────────────
[ C/C++ Source ] ──> [ Flex / Bison ] ──> [ Classical DCE Pass ] ──> [ Pruned Output IR ]
                                          • SCCP + Mark-Sweep         • Silent deletions
                                          • No security invariants    • Dead crypto stores removed!

──────────────────────────────────────────────────────────────────────────────────────────
B. PROPOSED INTELLIDCE SECURITY & OPTIMIZATION ECOSYSTEM
──────────────────────────────────────────────────────────────────────────────────────────
                                  ┌────────────────────────────────────────┐
                                  │   CWE Automata Scanner (11 Acceptors)  │
                                  │   OS Command, Buffer Copy, Dead Stores │
                                  └──────────────────┬─────────────────────┘
                                                     │ Pre-compile Audit
 [ Source Code ] ──> [ SSA IR Generator ] ───────────┴─────────────────────────────┐
 (C/C++ or SSA)      (Flex/Bison / GCC)                                            │
                                                                                   ▼
 ┌───────────────────────────────────────────────────────────────────┐     ┌───────────────┐
 │               DUAL-MODE DCE & OPTIMIZATION ENGINE                 │     │ Program       │
 │  1. Classical Pass: SCCP + BFS Reachability + Liveness Bitsets    │     │ Vitality      │
 │  2. ML-Guided Pass: GraphSAGE + GAT Feature Embedding (dim=74)   │     │ Scorecard     │
 │                     ▲                                             │     │ (0 - 100)     │
 │  3. Safety Veto:    ┴── Volatile / Side-Effect / Memory Barrier   │     └───────────────┘
 └─────────────────────────────────┬─────────────────────────────────┘
                                   │
                                   ▼
 ┌─────────────────────────────────┴─────────────────────────────────┐
 │               VERIFICATION & AUDITABILITY LAYER                   │
 │  • Verified DCE Docker Regression Guard (gcc:12.2.0-bookworm)     │
 │  • Security Mutation Testing & Benchmark Lab (TC01 - TC17)        │
 │  • Tamper-Evident SHA-256 Decision Timeline Audit Chain           │
 │  • AST Self-Healing Engine (Auto-Patch Synthesis & Feedback Loop) │
 └─────────────────────────────────┬─────────────────────────────────┘
                                   │
                                   ▼
 ┌───────────────────────────────────────────────────────────────────┐
 │            DRONA INTERACTIVE COPILOT & GUARDIAN SHIELD            │
 │  [ User Prompt / Code ] ──> [ Guardian Pre-Filter ] (Threat Gate) │
 │                                     │ S < 60 (Authorized)         │
 │                                     ▼                             │
 │                         [ Local Ollama: Qwen2.5-Coder ]           │
 │                         (Zero-Execution Sandboxed Tools)          │
 └───────────────────────────────────────────────────────────────────┘
```

---

## 🔬 Mathematical Formulations & Formal Invariants

### 1. Semantic Equivalence Invariant
Let $P$ be the unoptimized program and $P'$ be the program after IntelliDCE passes. For all deterministic inputs $I \in \mathcal{I}$ under bounded runtime $T$:
$$\text{Eval}(P, I) \equiv \text{Eval}(P', I) \quad \land \quad \text{ExitCode}(P, I) = \text{ExitCode}(P', I)$$

### 2. Axiomatic Safety Veto Invariant
A statement $s \in V$ predicted as dead ($z_s < \tau$, $\tau=0.60$) is **strictly vetoed** from removal if:
$$\text{Veto}(s) = \text{HasSideEffects}(s) \lor \text{IsVolatile}(s) \lor s \in \text{Defs}(\text{LiveOut}(\text{Block}(s))) \lor \text{IsSecurityZeroization}(s)$$
* **Veto Actions:** Pointer dereference assignments (`*ptr = val`), standard I/O (`printf`, `scanf`), dynamic memory managers (`malloc`, `free`), system calls, and cryptographic zeroization (`memset`) are unconditionally preserved.

### 3. Subgraph Deep Representation Learning (GraphSAGE + GAT)
Programs are represented as attributed directed multigraphs $G = (V, E, X)$, where $X \in \mathbb{R}^{|V| \times 74}$ merges a 64-dimensional semantic instruction embedding with 10 compiler control-flow features (loop nesting depth, branch distance, DEF-USE degree, opcode family).
* **Stage 1 (Neighborhood Aggregation via GraphSAGE):**
  $$h_v^{(1)} = \text{ReLU}\left( W_1 \cdot \left[ x_v \,\|\, \frac{1}{|\mathcal{N}(v)|} \sum_{u \in \mathcal{N}(v)} x_u \right] \right)$$
* **Stage 2 (Multi-Head Graph Attention Layer):**
  $$h_v^{(2)} = \sum_{k=1}^K \sum_{u \in \mathcal{N}(v)} \alpha_{vu}^k W_2^k h_u^{(1)}, \quad \alpha_{vu} = \frac{\exp\left(\text{LeakyReLU}\left(a^T [W h_v \,\|\, W h_u]\right)\right)}{\sum_{k \in \mathcal{N}(v)} \exp\left(\text{LeakyReLU}\left(a^T [W h_v \,\|\, W h_k]\right)\right)}$$

### 4. Program Vitality Scorecard Formulation
The software health scalar index $V(P) \in [0, 100]$ evaluates dead code volume, structural complexity, and security defects:
$$V(P) = \max\left(0, \, 100 - (\text{DCP} \times 30) - (\text{CC} \times 0.2) - \sum_{c \in \text{CWEs}} W(c)\right)$$
* Where $\text{DCP}$ is Dead Code Percentage, $\text{CC}$ is Cyclomatic Complexity, and $W(c)$ represents severity penalties:
  * **Critical CWEs:** $25$ pts deduction
  * **High CWEs:** $15$ pts deduction
  * **Medium CWEs:** $8$ pts deduction

---

## 🧩 Core Modules & Features

| Module | Component | Description | Implementation |
|---|---|---|---|
| **Mod 1** | **Code Health & Vitality Scorecard** | 0–100 scalar metric grading code into EXCELLENT, GOOD, POOR tiers with dynamic breakdown. | `gui/server.js`, `calculateHealthScore()` |
| **Mod 2** | **Automata Vulnerability Scanner** | 11 Deterministic Finite Automata (DFA) & regex acceptors detecting CWEs prior to compiler execution. | `gui/server.js`, `scanSourceText()` |
| **Mod 3** | **C++ Core Engine & SSA Lowering** | Flex lexer + Bison LALR(1) parser converting source to SSA GIMPLE three-address code. | `src/analysis.cpp`, `lexer.l`, `parser.y` |
| **Mod 4** | **Dual-Mode DCE Optimizer** | Classical SCCP + Reachability + Mark-Sweep DCE alongside ML-Guided GraphSAGE GNN inference. | `src/analysis.cpp`, `ml/inference.py` |
| **Mod 5** | **Dead Code Audit & DCE Explainer** | Interactive semantic explanation sandbox tracing DEF-USE chains and formal safety proofs. | `gui/public/index.html`, `gui/server.js` |
| **Mod 6** | **DRONA Copilot & Guardian Shield** | Offline LLM assistant (Qwen2.5-Coder 7B) protected by multi-stage prompt injection normalization. | `gui/drona.js`, `gui/guardian.js`, `gui/llm.js` |
| **Mod 7** | **Verified Docker Regression Guard** | Containerized differential test execution harness verifying semantic equivalence. | `gui/verifier.js`, `gui/sandbox.js`, `Dockerfile.sandbox` |
| **Pillar A** | **Security Mutation & Benchmark Lab** | Automated test suite across 17 benchmark workloads (TC01–TC17) with real-time confusion matrix. | `gui/benchmark-runner.js`, `testcases_ssa.js` |
| **Pillar B** | **Cryptographic SHA-256 Audit Trail** | Tamper-evident hash chain logging compiler security decisions with unbroken validation. | `gui/audit.js`, `gui/server.js` |
| **Pillar C** | **Continuous Feedback & Retraining** | Human-in-the-loop veto review, confidence threshold tuning, and sample curation for retraining. | `ml_data/corrections.jsonl` |

---

## 📊 Experimental Results & Benchmarks

### 1. Dead Code Optimization Across SSA Workloads
Comparative evaluation of classical DCE vs. IntelliDCE ML-guided optimization on standard benchmark programs:

| Benchmark File | Original Stmts | Classical Pruned | IntelliDCE Pruned | Relative Gain | Safety Invariant |
|---|---|---|---|---|---|
| `01_dead_store.ssa` | 14 | 4 (28.6%) | 4 (28.6%) | Parity | **Passed** (No drift) |
| `02_sccp_unreachable.ssa` | 22 | 7 (31.8%) | 7 (31.8%) | Parity | **Passed** (No drift) |
| `03_master_patterns.ssa` | 48 | 12 (25.0%) | 17 (35.4%) | **+41.7%** | **Passed** (No drift) |
| `test_loop_carried_dead.ssa` | 31 | 3 (9.7%) | 9 (29.0%) | **+200.0%** | **Passed** (No drift) |
| `05_semantic_idce.ssa` | 39 | 8 (20.5%) | 13 (33.3%) | **+62.5%** | **Passed** (No drift) |

### 2. Automata Vulnerability Scanner Evaluation (11 CWEs)

| CWE Identifier | Target Vulnerability Pattern | Automata Acceptance Rule | Detection Rate | False Negatives |
|---|---|---|---|---|
| **CWE-78** | OS Command Injection | `system\|popen\|execl\|execve\s*\(` | 15 / 15 (100%) | 0 |
| **CWE-120** | Unbounded Buffer Copy | `strcpy\|gets\|strcat\|sprintf\s*\(` | 12 / 12 (100%) | 0 |
| **CWE-134** | Format String Vulnerability | `printf\s*\(\s*[^"]+\s*\)` | 10 / 10 (100%) | 0 |
| **CWE-415** | Double Free State Machine | State tracking: $\text{Alloc} \to \text{Free} \to \text{Free}$ | 8 / 8 (100%) | 0 |
| **CWE-416** | Use-After-Free Hazard | Pointer dereference following `free()` | 8 / 8 (100%) | 0 |
| **CWE-561** | Sensitive Dead Store Elimination | Cross-pass Def-Use liveness on password/keys | 6 / 6 (100%) | 0 |
| **CWE-798** | Hardcoded Credentials / Keys | Hardcoded assignment to secret identifiers | 9 / 9 (100%) | 0 |
| **CWE-823** | Unchecked Pointer Arithmetic | Out-of-bounds pointer offsets | 10 / 10 (100%) | 0 |
| **Overall** | **11 Vulnerability Classes** | **Multi-stage Lexical & AST Invariants** | **100% (78 / 78)** | **0** |

### 3. DRONA & Guardian Prompt Injection Defense Matrix
Tested across 65 adversarial penetration cases (adversarial jailbreaks, base64 payloads, leetspeak, zero-width spaces, indirect comment injections):
* **Guardian Defense Rate:** 100% interception (20 / 20 malicious prompt injections blocked)
* **LLM Calls for Blocked Attacks:** Exactly **0** (Pre-empted at the boundary with fixed safe refusal)
* **Benign Query False Positive Rate:** 0.0% (Developer questions on syntax/warnings cleanly passed)
* **Local Inference Latency:** 2.8s – 4.2s (running fully offline via Ollama `qwen2.5-coder:7b`)

---

## 📁 Repository Directory Structure

```
.
├── 25CSB1A77_RahulKumarChaurasiya_IntelliDCE_Report_END.docx  # Final PBL Technical Report
├── 25CSB1A77_RahulKumarChaurasiya_IntelliDCE_Report_MID.docx  # Mid-Evaluation Report
├── Intelligent Dead Code Elimination Tool/
│   ├── IntelliDCE-main/
│   │   ├── analysis.cpp               # Core C++ DCE algorithms (SCCP, Liveness, Veto)
│   │   ├── main.cpp                   # Compiler CLI entry point
│   │   ├── lexer.l                    # Flex Lexer for GIMPLE SSA syntax
│   │   ├── parser.y                   # Bison LALR(1) Grammar Parser
│   │   ├── ir.h                       # IR data structures (FunctionIR, BasicBlock, Stmt)
│   │   ├── Makefile                   # C++ build system
│   │   ├── idce                       # Compiled binary executable
│   │   │
│   │   ├── ml/                        # Graph Neural Network Pipeline
│   │   │   ├── model.py               # 2-Layer GraphSAGE + GAT PyTorch Geometric model
│   │   │   ├── inference.py           # GNN inference script returning dead instruction IDs
│   │   │   ├── train.py               # GNN training loop with class-weighted loss
│   │   │   ├── fuzzer.py              # SSA synthetic program fuzzer for dataset generation
│   │   │   └── feature_extractor.cpp  # Exports IR graph to JSON node/edge features
│   │   │
│   │   ├── ml_data/                   # Trained weights & human feedback logs
│   │   │   ├── dce_model.pt           # Pre-trained GraphSAGE weights
│   │   │   └── corrections.jsonl      # Human review audit & retraining logs
│   │   │
│   │   ├── gui/                       # Full-Stack Web Interface & Copilot
│   │   │   ├── server.js              # Express HTTP & WebSocket telemetry backend
│   │   │   ├── drona.js               # DRONA Agent core & tool orchestrator
│   │   │   ├── guardian.js            # Prompt injection firewall & sanitization engine
│   │   │   ├── llm.js                 # Local Ollama client (qwen2.5-coder:7b)
│   │   │   ├── verifier.js            # Differential execution & regression verification
│   │   │   ├── sandbox.js             # Process isolation & container boundary driver
│   │   │   ├── audit.js               # SHA-256 cryptographic timeline logger
│   │   │   ├── benchmark-runner.js    # Security mutation & testsuite harness
│   │   │   ├── testcases_ssa.js       # TC01–TC17 SSA corpus & ground-truth specs
│   │   │   ├── public/
│   │   │   │   ├── index.html         # Single-page interface (CFG, Diff, Copilot, Audit)
│   │   │   │   ├── style.css          # Cyber-neon responsive UI styling
│   │   │   │   └── app.js            # Client-side state & WebSocket listeners
│   │   │   └── tests/                 # Automated unit & integration test suites
│   │   │
│   │   ├── inputs/                    # Corpus of SSA and C++ test programs
│   │   └── docs/                      # Architectural & security specifications
│   │
│   └── report/                        # Evaluation screenshots & visual evidence
└── README.md                          # Project-Based Learning Documentation (This file)
```

---

## 🛠️ Installation & Setup Guide

### 1. Prerequisites & System Dependencies

#### macOS (Homebrew)
```bash
brew install gcc flex bison graphviz node python@3.12 ollama
export PATH="/opt/homebrew/opt/bison/bin:/opt/homebrew/opt/flex/bin:$PATH"
```

#### Linux (Ubuntu / Debian)
```bash
sudo apt update
sudo apt install -y build-essential flex bison graphviz nodejs npm python3 python3-pip python3-venv
```

---

### 2. Machine Learning Environment Setup

```bash
cd "Intelligent Dead Code Elimination Tool/IntelliDCE-main/ml"
python3 -m venv .venv
source .venv/bin/activate

# Install PyTorch & PyTorch Geometric for CPU/MPS
pip install torch torch_geometric --index-url https://download.pytorch.org/whl/cpu
```

---

### 3. Local LLM Setup (DRONA Copilot)

IntelliDCE uses **Ollama** with the specialized coding model `qwen2.5-coder:7b` for 100% private, offline reasoning:

```bash
# Start Ollama service (if not already running)
ollama serve &

# Pull the lightweight code model
ollama pull qwen2.5-coder:7b
```

---

### 4. Build the C++ Compiler Binary

```bash
cd "Intelligent Dead Code Elimination Tool/IntelliDCE-main"
make clean && make
```
*This generates the `idce` compiler executable in the directory.*

---

### 5. Launch the Web Interface & Server

```bash
cd "Intelligent Dead Code Elimination Tool/IntelliDCE-main/gui"
npm install
npm start
```

Open your browser and navigate to:
👉 **`http://localhost:3000`** *(or `http://127.0.0.1:3000`)*

---

## 🚀 Usage & Quick Start

### A. Running via Web GUI (Recommended)
1. **Interactive Dashboard:** Select a testcase from the sidebar (e.g., `TC01 - Dead Store`, `TC08 - Insecure Buffer Copy`).
2. **Pre-compile Scan:** Click **Scan Code** to run the 11-CWE Automata Gate. If vulnerabilities exist, Guardian intercepts and displays recommended remediation.
3. **Run DCE Pass:** Choose **Classical** or **ML-Guided (GraphSAGE)** and click **Start Analysis**.
4. **Inspect Results:**
   * **CFG View:** Interactive basic-block control flow graph rendered via Viz.js.
   * **Side-by-Side Diff:** Live comparison between original GIMPLE SSA and optimized SSA.
   * **DCE Explainer:** Click any eliminated statement to view its DEF-USE provenance and safety proof.
5. **DRONA Copilot:** Open the DRONA assistant drawer to get real-time refactoring suggestions or ask compiler questions without exposing code to cloud APIs.

### B. Running Compiler Passes from CLI

```bash
cd "Intelligent Dead Code Elimination Tool/IntelliDCE-main"

# 1. Classical DCE Pass
./idce output_classical < inputs/01_dead_store.ssa

# 2. ML-Guided GNN Optimization Pass
./idce output_ml --ml-dce < inputs/03_master_patterns.ssa

# 3. Export CFG features for dataset generation
./idce output_features --ml-extract < inputs/input.ssa
```

---

## 🧪 Automated Testing & Verification

Run the full end-to-end integration and security test suite:

```bash
cd "Intelligent Dead Code Elimination Tool/IntelliDCE-main/gui"
npm test
```

### Verified Test Suites:
* `tests/guardian.test.js`: Validates 20 prompt injection vectors, encodings, and boundary defenses.
* `tests/llm.test.js`: Validates offline fallback, timeout recovery, and schema repair.
* `tests/drona.test.js`: Validates zero-execution sandbox and read-only tool gating.
* `tests/verifier.test.js`: Validates differential test execution and semantic parity.
* `tests/benchmark.test.js`: Runs full TC01–TC17 corpus through compiler passes.
* `tests/audit.test.js`: Validates SHA-256 cryptographic chain continuity.

---

## 🎓 Academic Acknowledgments

This research prototype was conceptualized and completed as part of the **Project-Based Learning (PBL)** curriculum:
* **Academic Institution:** National Institute of Technology Warangal (NIT Warangal)
* **Department:** Department of Computer Science and Engineering (Artificial Intelligence & Data Science)
* **Course:** Advanced Compilers & Automata Theory
* **Supervisor & Mentor:** Prof. Erukala Suresh Babu

Special thanks to the open-source compiler community, LLVM and GCC documentation teams, and the developers of PyTorch Geometric and Ollama for enabling robust local AI integration in systems software.

---

## 📜 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.
